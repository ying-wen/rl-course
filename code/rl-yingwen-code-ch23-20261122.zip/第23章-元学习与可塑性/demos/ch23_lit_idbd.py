# -*- coding: utf-8 -*-
"""第 23 章文献原型：Sutton (1992) IDBD 的两个实验（AAAI-92，pp. 171-176）。

实验 1（原文图 3）：20 个输入各取 N(0,1)；目标 y* = s1 x1 + ... + s5 x5（si = +-1），
其余 15 个输入系数为 0。每 20 个样本随机挑 5 个 si 中的一个翻转符号（相关输入集合固定）。
每次运行先跑 20,000 个样本，再在其后 10,000 个样本上算均方误差（MSE）。
LMS 扫固定步长 alpha；IDBD 扫元步长 theta，初始 alpha_i = 0.05。

实验 2（原文图 4、图 5）：theta = 0.001，跑 250,000 个样本，记录各输入最后的步长；
另用固定步长扫描（只给 5 个相关输入同一步长，无关输入步长为 0；这是本课的做法），
看误差最小点在哪里。

只用 numpy。用法：
    python3 demos/ch23_lit_idbd.py [运行次数，默认 100]
输出写 assets/ch23-lit-idbd/results.json。
"""
import json, os, sys, time
import numpy as np
np.seterr(all='ignore')                    # 大元步长时 IDBD 会发散，记为 nan

N_IN, N_REL, FLIP_EVERY = 20, 5, 20


def stream(rng, runs, T):
    """逐步产生 (x, y)；返回生成器。各运行独立。"""
    s = np.where(rng.random((runs, N_REL)) < .5, -1., 1.)
    for t in range(T):
        if t > 0 and t % FLIP_EVERY == 0:
            k = rng.integers(0, N_REL, size=runs)
            s[np.arange(runs), k] *= -1
        x = rng.standard_normal((runs, N_IN))
        y = (s * x[:, :N_REL]).sum(1)
        yield t, x, y


def run_lms(alphas, runs, rng, T=30000, burn=20000, mask=None):
    """alphas: (P,) 固定步长；返回每个步长的 MSE 均值与标准误（over runs）。
    mask: (N_IN,) 0/1，步长只施加在 mask=1 的输入上（实验 2 的扫描用）。"""
    P = len(alphas)
    a = np.asarray(alphas)[:, None, None] * (np.ones(N_IN) if mask is None else mask)
    w = np.zeros((P, runs, N_IN))
    se = np.zeros((P, runs))
    for t, x, y in stream(rng, runs, T):
        d = y - (w * x).sum(-1)               # (P, runs)
        if t >= burn:
            se += d * d
        w += a * d[..., None] * x
    mse = se / (T - burn)
    mse[~(mse < 1e6)] = np.inf                 # 发散（含溢出）记为 inf
    return mse.mean(1), mse.std(1, ddof=1) / np.sqrt(runs)


def run_idbd(thetas, runs, rng, T=30000, burn=20000, alpha0=.05, keep_alpha=False, every=0):
    P = len(thetas); trace = []
    th = np.asarray(thetas)[:, None, None]
    beta = np.full((P, runs, N_IN), np.log(alpha0))
    w = np.zeros((P, runs, N_IN)); h = np.zeros((P, runs, N_IN))
    se = np.zeros((P, runs))
    for t, x, y in stream(rng, runs, T):
        d = y - (w * x).sum(-1)
        if t >= burn:
            se += d * d
        dx = d[..., None] * x
        beta += th * dx * h
        a = np.exp(beta)
        w += a * dx
        h = h * np.maximum(0., 1. - a * x * x) + a * dx
        if every and (t + 1) % every == 0:
            trace.append((t + 1, float(a[0, :, :N_REL].mean()), float(a[0, :, N_REL:].mean())))
    mse = se / (T - burn)
    ok = np.isfinite(mse)                      # 发散的运行记为 nan，单独计数
    mean = np.array([m[o].mean() if o.any() else np.nan for m, o in zip(mse, ok)])
    sem = np.array([m[o].std(ddof=1) / np.sqrt(o.sum()) if o.sum() > 1 else np.nan for m, o in zip(mse, ok)])
    out = (mean, sem, (~ok).sum(1))
    if keep_alpha:
        out = out + (np.exp(beta), trace)
    return out


def main():
    runs = int(sys.argv[1]) if len(sys.argv) > 1 else 100
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    outdir = os.path.join(root, 'assets', 'ch23-lit-idbd'); os.makedirs(outdir, exist_ok=True)
    t0 = time.time(); res = {'runs': runs, 'setting': {
        'inputs': N_IN, 'relevant': N_REL, 'flip_every': FLIP_EVERY,
        'exp1': 'burn 20000, MSE on next 10000; IDBD alpha0 = 0.05',
        'exp2': 'theta = 0.001, 250000 samples; fixed-alpha sweep only on 5 relevant inputs (this course)'}}

    # 实验 1
    lms_a = [.005, .01, .02, .03, .04, .05, .06, .08, .1]
    idbd_t = [.0005, .001, .002, .005, .01, .02, .03]
    m, e = run_lms(lms_a, runs, np.random.default_rng(1))
    res['exp1_lms'] = [{'alpha': a, 'mse': float(x), 'se': float(s)} for a, x, s in zip(lms_a, m, e)]
    m, e, nd = run_idbd(idbd_t, runs, np.random.default_rng(2))
    res['exp1_idbd'] = [{'theta': a, 'mse': float(x), 'se': float(s), 'diverged': int(k)}
                        for a, x, s, k in zip(idbd_t, m, e, nd)]
    res['exp1_best_lms'] = min(res['exp1_lms'], key=lambda r: r['mse'])
    res['exp1_best_idbd'] = min([r for r in res['exp1_idbd'] if r['diverged'] == 0], key=lambda r: r['mse'])
    print('exp1 done %.1fs' % (time.time() - t0)); sys.stdout.flush()

    # 实验 2：最后的步长
    _, _, _, alph, trace = run_idbd([.001], runs, np.random.default_rng(3), T=250000, burn=249999,
                                    keep_alpha=True, every=10000)
    res['exp2_alpha_trace'] = [{'t': t, 'relevant_mean': r, 'irrelevant_mean': i} for t, r, i in trace]
    alph = alph[0]                                 # (runs, N_IN)
    rel = alph[:, :N_REL].ravel(); irr = alph[:, N_REL:].ravel()
    res['exp2_alpha'] = {'relevant_mean': float(rel.mean()), 'relevant_sd': float(rel.std(ddof=1)),
                         'irrelevant_max': float(irr.max()), 'irrelevant_mean': float(irr.mean())}
    print('exp2 alpha done %.1fs' % (time.time() - t0)); sys.stdout.flush()

    # 实验 2：固定步长扫描（只施加在相关输入上）
    sweep = [.06, .08, .10, .11, .12, .13, .14, .15, .16, .18, .20]
    mask = np.r_[np.ones(N_REL), np.zeros(N_IN - N_REL)]
    m, e = run_lms(sweep, runs, np.random.default_rng(4), mask=mask)
    res['exp2_fixed_sweep'] = [{'alpha': a, 'mse': float(x), 'se': float(s)} for a, x, s in zip(sweep, m, e)]
    res['exp2_fixed_best'] = min(res['exp2_fixed_sweep'], key=lambda r: r['mse'])
    res['seconds'] = round(time.time() - t0, 1)
    for k in ('exp1_lms', 'exp1_idbd', 'exp2_fixed_sweep'):
        for r in res[k]:
            for q in ('mse', 'se'):
                if not np.isfinite(r[q]): r[q] = None   # None 表示有运行发散
    with open(os.path.join(outdir, 'results.json'), 'w') as f:
        json.dump(res, f, ensure_ascii=False, indent=1)
    print(json.dumps({k: res[k] for k in ['exp1_best_lms', 'exp1_best_idbd', 'exp2_alpha', 'exp2_fixed_best', 'seconds']}, indent=1))


if __name__ == '__main__':
    main()
