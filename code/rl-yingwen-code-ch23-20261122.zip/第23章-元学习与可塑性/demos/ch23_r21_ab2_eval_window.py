"""第 23 章 23.8 节：评价窗口改变“最好的步长”。

Run from rl-course:
    python demos/ch23_r21_ab2_eval_window.py

Writes
    assets/ch23-r21/ab2-eval-window.pdf   (page ch23-r21-ab2-horizon)

11-21 审阅站请求 r1121-133704（第 23 章作者批注：怎样检验学到的元规则有效）。
设定与 ch23_r21_ab2_stream_change.py 相同：共享预测器 w=0 起步，每趟回报 4 或 1
各半（均值 2.5，方差 2.25）；第 500 趟后右指示回报 1->3（均值 3.5，方差 .25）。
固定步长 a 时按均值与方差递推精确计算（不抽样）：
    m <- (1-a) m + a mu,  v <- (1-a)^2 v + a^2 sigma^2,
超额误差 = (m - mu_next)^2 + v，即预测与下一趟均值之差的平方的期望。
对每个评价窗口求平均超额误差最小的 a，并画 L(a)/min L。
"""
from pathlib import Path
import sys

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter

sys.path.insert(0, str(Path(__file__).resolve().parent))
from plot_fonts import use_course_fonts, CJK_FAMILY, no_leading_zero  # noqa: E402

TEAL, RED, GOLD, MUTED, INK = "#096B76", "#AA412D", "#A27618", "#52666E", "#182E38"
OUT = Path(__file__).resolve().parent.parent / "assets" / "ch23-r21" / "ab2-eval-window.pdf"

T, TC = 1000, 500
MU = (2.5, 3.5)
S2 = (2.25, .25)


def excess(a):
    """Expected excess error before each pass t = 1..T for fixed step size a."""
    m = v = 0.0
    out = np.empty(T)
    for t in range(T):
        k = 0 if t < TC else 1
        m = (1 - a) * m + a * MU[k]
        v = (1 - a) ** 2 * v + a * a * S2[k]
        kn = 0 if t + 1 < TC else 1
        out[t] = (m - MU[kn]) ** 2 + v
    return out


def main():
    use_course_fonts()
    grid = np.linspace(.005, 1, 996)
    curves = np.array([excess(a) for a in grid])
    windows = [
        ("前 20 趟", slice(0, 20), GOLD, "-"),
        ("整条 1000 趟", slice(0, T), TEAL, "-"),
        ("换后 20 趟", slice(TC, TC + 20), RED, "--"),
    ]
    fig, ax = plt.subplots(figsize=(3.1, 2.35))
    for name, sl, col, ls in windows:
        L = curves[:, sl].mean(axis=1)
        i = int(L.argmin())
        print(f"{name}: best a = {grid[i]:.3f}, min L = {L[i]:.4f}")
        ax.plot(grid, L / L[i], color=col, lw=1.4, ls=ls)
        ax.plot(grid[i], 1, "o", color=col, ms=4)
    # labels placed by hand to avoid overlap
    ax.text(.37, 2.62, "整条 1000 趟\n最好 .07", color=TEAL, fontsize=8.5, fontfamily=CJK_FAMILY, ha="left", va="bottom")
    ax.text(.30, 1.92, "前 20 趟\n最好 .31", color=GOLD, fontsize=8.5, fontfamily=CJK_FAMILY, ha="left", va="bottom")
    ax.text(.66, 1.02, "换后 20 趟\n最好 .38", color=RED, fontsize=8.5, fontfamily=CJK_FAMILY, ha="left", va="bottom")
    ax.set_xlim(0, 1)
    ax.set_ylim(.9, 3.2)
    ax.set_xticks([0, .25, .5, .75, 1])
    ax.set_yticks([1, 2, 3])
    ax.xaxis.set_major_formatter(FuncFormatter(no_leading_zero))
    ax.set_xlabel("写定步长 $a$", fontfamily=CJK_FAMILY, fontsize=9.5)
    ax.set_ylabel("误差 / 该窗口最小值", fontfamily=CJK_FAMILY, fontsize=9.5)
    ax.tick_params(labelsize=8.5)
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    fig.tight_layout(pad=.3)
    OUT.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(OUT)
    print("wrote", OUT)


if __name__ == "__main__":
    main()
