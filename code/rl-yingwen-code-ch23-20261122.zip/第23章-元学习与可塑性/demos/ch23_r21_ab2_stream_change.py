"""11-21 请求 r1121-133704（第 23 章 p1870 ch23-bridge-plasticity）：连续经验流上元梯度调步长，世界改变后能否调回。

Run from rl-course:  python demos/ch23_r21_ab2_stream_change.py
Writes assets/ch23-r21/ab2-stream-change.pdf
与 ch23_r21_stream_stepsize.py（章首页）同一设定，另加第 T 趟的奖励改变。

仓库主例：共享预测器 w，每趟一个回报 G（左指示 4、右指示 1，各半随机），
内层 w <- (1-a) w + a G，敏感度 s <- (G-w) + (1-a) s，
外层每趟先用 (w-G) s 更新 a（元步长 .025，a 截在 [0,1]），再写入。
第 T 趟起 W->C 奖励由 1 改为 3（右指示回报 1 -> 3）。对照：写定 a=.5。
"""
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent))
from plot_fonts import use_course_fonts, no_leading_zero, CJK_FAMILY

A0, AM, T, RUNS = .5, .025, 500, 1000
TEAL, RED, MUTED = "#096B76", "#AA412D", "#52666E"
OUT = Path(__file__).resolve().parent.parent / "assets" / "ch23-r21"


def run(G, meta=True):
    w = s = 0.
    a = A0
    H, W = [a], [w]
    for k, g in enumerate(G):
        if k > 0 and meta:
            a = min(max(a - AM * (w - g) * s, 0.), 1.)
        s = (g - w) + (1 - a) * s
        w = (1 - a) * w + a * g
        H.append(a)
        W.append(w)
    return np.array(H), np.array(W)


def main():
    rng = np.random.default_rng(0)
    A, Em, Ef = [], [], []
    for _ in range(RUNS):
        left = rng.random(2 * T) < .5
        G = np.where(left, 4., 1.)
        G[T:] = np.where(left[T:], 4., 3.)
        mean = np.r_[np.full(T, 2.5), np.full(T + 1, 3.5)]  # 第 T 趟后的预测对新均值计误差
        h, w = run(G)
        _, wf = run(G, meta=False)
        A.append(h)
        Em.append(np.abs(w - mean))
        Ef.append(np.abs(wf - mean))
    A, Em, Ef = map(np.array, (A, Em, Ef))
    med = np.median(A, 0)
    q1, q3 = np.percentile(A, [25, 75], 0)
    for n in [2, 20, 100, 500]:
        print(f'pass {n}: median a {med[n]:.3f}, IQR [{q1[n]:.3f},{q3[n]:.3f}], '
              f'frac<.25 {(A[:, n] < .25).mean():.3f}, frac==0 {(A[:, n] == 0).mean():.3f}')
    for d in [1, 2, 3, 5, 10, 20, 50, 100, 500]:
        n = T + d
        print(f'after change +{d}: median a {med[n]:.3f}, median err meta {np.median(Em[:, n]):.3f}, '
              f'fixed {np.median(Ef[:, n]):.3f}, mean err meta {Em[:, n].mean():.3f} fixed {Ef[:, n].mean():.3f}')

    use_course_fonts()
    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(3.4, 2.8))  # 页上宽约 6cm，字按 .69 缩放
    x = np.arange(2 * T + 1)
    ax1.fill_between(x, q1, q3, color=TEAL, alpha=.22, lw=0)
    ax1.plot(x, med, color=TEAL, lw=1.4)
    ax1.axhline(.5, color=MUTED, lw=.8, ls='--')
    ax1.axvline(T, color=RED, lw=.8)
    ax1.text(T + 15, .58, '奖励 1→3', fontsize=11, color=RED, fontfamily=CJK_FAMILY)
    ax1.text(30, .54, '写定 .5', fontsize=11, color=MUTED, fontfamily=CJK_FAMILY)
    ax1.set_xlim(0, 2 * T)
    ax1.set_ylim(0, .7)
    ax1.set_yticks([0, .2, .4, .6])
    ax1.set_xlabel('趟数', fontsize=11.5, fontfamily=CJK_FAMILY, labelpad=1)
    ax1.set_title('步长：中位数与四分位带', fontsize=11.5, fontfamily=CJK_FAMILY)
    ax1.yaxis.set_major_formatter(FuncFormatter(no_leading_zero))
    d = np.arange(0, 61)
    ax2.plot(d, np.median(Ef[:, T + d], 0), color=MUTED, lw=1.2, ls='--', label='写定 .5')
    ax2.plot(d, np.median(Em[:, T + d], 0), color=TEAL, lw=1.4, label='元梯度调')
    ax2.set_xlim(0, 60)
    ax2.set_ylim(0, 1.1)
    ax2.set_yticks([0, .5, 1])
    ax2.set_xlabel('奖励改变后的趟数', fontsize=11.5, fontfamily=CJK_FAMILY, labelpad=1)
    ax2.set_title('预报误差 $|w-\\bar G|$ 的中位数', fontsize=11.5, fontfamily=CJK_FAMILY)
    ax2.yaxis.set_major_formatter(FuncFormatter(no_leading_zero))
    ax2.legend(prop={'family': CJK_FAMILY, 'size': 11}, frameon=False, loc='upper right')
    for ax in (ax1, ax2):
        ax.tick_params(labelsize=10.5, length=2)
        for sp in ('top', 'right'):
            ax.spines[sp].set_visible(False)
    fig.tight_layout(pad=.2, h_pad=.3)
    OUT.mkdir(parents=True, exist_ok=True)
    out = OUT / 'ab2-stream-change.pdf'
    fig.savefig(out)
    print('saved', out)


if __name__ == '__main__':
    main()
