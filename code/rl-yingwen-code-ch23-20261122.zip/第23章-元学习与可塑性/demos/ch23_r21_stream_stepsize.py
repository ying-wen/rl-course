"""第 23 章章首左图：一条不重置的经验流上，元梯度把共享预测器的步长调到哪里。

Run from rl-course:
    python demos/ch23_r21_stream_stepsize.py

Writes
    assets/ch23-r21/stream-stepsize.pdf   (page ch23-opening；23.6 节桥接页可复用)

11-21 审阅站请求 r1121-133704（第 23 章 1845 页）。
设定：每趟在转角向左一次；指示等概率为左或右，回报 G=4 或 1（八步记录的两趟）。
共享预测器 w <- w + alpha (G - w)，初值 w=0、alpha=.5；元步长 .025；
每趟先用写入前的预测给本趟回报计分，元梯度 (w - G) s，再写入；
敏感度按完整递推 s <- (G - w) + (1 - alpha) s（23.1 节式②）；alpha 截在 [0, 1]。
对照：每次都从 w=0 重做“左得 4、右得 1”两趟，再做一次元更新，alpha 趋于 .25。
"""
from pathlib import Path
import sys

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter, FixedLocator, NullFormatter

sys.path.insert(0, str(Path(__file__).resolve().parent))
from plot_fonts import use_course_fonts, CJK_FAMILY, no_leading_zero  # noqa: E402

TEAL, RED, GOLD, MUTED, INK = "#096B76", "#AA412D", "#A27618", "#52666E", "#182E38"
OUT = Path(__file__).resolve().parent.parent / "assets" / "ch23-r21"
BETA, A0, K, RUNS = .025, .5, 500, 1000


def stream(rng):
    """alpha after k meta-updates, k = 0..K, on one continuing stream."""
    a, w, s = A0, 0., 0.
    out = [a]
    G = np.where(rng.random(K + 1) < .5, 4., 1.)
    w, s = w + a * (G[0] - w), G[0] - w          # 第一趟只写入，s=4
    for g in G[1:]:
        a = min(max(a - BETA * (w - g) * s, 0.), 1.)
        s = (g - w) + (1 - a) * s
        w = w + a * (g - w)
        out.append(a)
    return np.array(out)


def reset_sequence(n):
    a, seq = A0, [A0]
    for _ in range(n):
        w, s = a * 4., 4.                          # 从 w=0 写入 G=4
        a = a - BETA * (w - 1.) * s                # 后来的 G=1 计分
        seq.append(a)
    return np.array(seq)


def main():
    rng = np.random.default_rng(23)
    R = np.array([stream(rng) for _ in range(RUNS)])
    med = np.median(R, axis=0)
    q25, q75 = np.percentile(R, [25, 75], axis=0)
    reset = reset_sequence(K)
    for k in (1, 20, 100, 500):
        print(f"k={k:3d}  median {med[k]:.3f}  IQR [{q25[k]:.3f}, {q75[k]:.3f}]"
              f"  frac<.25 {np.mean(R[:, k] < .25):.2f}  reset {reset[k]:.3f}")
    print("mean after first update", R[:, 1].mean().round(3))

    use_course_fonts()
    fig, ax = plt.subplots(figsize=(3.6, 1.75))
    k = np.arange(1, K + 1)
    ax.fill_between(k, q25[1:], q75[1:], color=TEAL, alpha=.18, lw=0)
    ax.plot(k, med[1:], color=TEAL, lw=1.6)
    ax.plot(k, reset[1:], color=MUTED, lw=1.1, ls=(0, (3, 2)))
    ax.axhline(.25, color=MUTED, lw=.5, ls=':')
    ax.set_xscale('log')
    ax.set_xlim(1, K)
    ax.set_ylim(0, .62)
    ax.xaxis.set_major_locator(FixedLocator([1, 10, 100, 500]))
    ax.xaxis.set_major_formatter(FuncFormatter(lambda x, _p=None: f'{x:g}'))
    ax.xaxis.set_minor_formatter(NullFormatter())
    ax.yaxis.set_major_locator(FixedLocator([0, .25, .5]))
    ax.yaxis.set_major_formatter(FuncFormatter(no_leading_zero))
    ax.tick_params(labelsize=9.5, length=2.5, width=.6)
    for sp in ('top', 'right'):
        ax.spines[sp].set_visible(False)
    for sp in ('left', 'bottom'):
        ax.spines[sp].set_linewidth(.6)
    ax.set_xlabel('元更新次数（每趟一次）', fontsize=10.5, fontfamily=CJK_FAMILY, labelpad=1)
    ax.set_ylabel('步长', fontsize=10.5, fontfamily=CJK_FAMILY, labelpad=2)
    ax.text(1.15, .14, '每次从 $w=0$ 重做两趟', color=MUTED, fontsize=9.5,
            fontfamily=CJK_FAMILY, ha='left')
    ax.text(480, .47, '一条经验流\n中位数与四分位带', color=TEAL, fontsize=9.5,
            fontfamily=CJK_FAMILY, ha='right', va='center', linespacing=1.1)
    fig.tight_layout(pad=.25)
    OUT.mkdir(parents=True, exist_ok=True)
    fig.savefig(OUT / 'stream-stepsize.pdf')
    print('wrote', OUT / 'stream-stepsize.pdf')


if __name__ == '__main__':
    main()
