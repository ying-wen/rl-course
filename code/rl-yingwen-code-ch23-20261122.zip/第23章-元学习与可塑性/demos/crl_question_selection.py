"""Select an event GVF for a route model from a single continuing stream.

Run: python3 demos/crl_question_selection.py
The environment generates an independent junction after each two-step route.
Only a completed straight route reports the three sensor events. The learner
fits every candidate on randomized probes. The other trips measure the
payoff of choosing a route with one of these estimates. No simulator queries.
"""
import csv
import json
from math import sqrt
from pathlib import Path
from random import Random
from statistics import mean, stdev

CHANNELS = 3
TRIPS = 1024
PAIRS = 96
PROBE = 0.15
REVIEW = 16  # number of newly completed probes between choices of reader
OUT = Path(__file__).resolve().parents[1] / "assets/crl-question-selection"


class EventQuestion:
    """GVF: under the straight route, does this sensor fire before arrival?"""
    def __init__(self):
        # Laplace smoothing for event probabilities, neutral prior for reward.
        self.events = [1, 1]
        self.samples = [2, 2]
        self.rewards = [0, 0]
        self.outcomes = [1, 1]
        self.loss = 0.

    def expected_reward(self, cue):
        prob_event = self.events[cue] / self.samples[cue]
        return ((1 - prob_event) * self.rewards[0] / self.outcomes[0] +
                prob_event * self.rewards[1] / self.outcomes[1])

    def observe(self, cue, event, reward):
        # Score the pre-transition prediction before fitting either estimator.
        self.loss += (self.expected_reward(cue) - reward) ** 2
        self.samples[cue] += 1
        self.events[cue] += event
        self.rewards[event] += reward
        self.outcomes[event] += 1


class Junctions:
    def __init__(self, seed):
        self.rng = Random(2 * seed)
        self.relevant = self.rng.randrange(CHANNELS)  # hidden to the controller

    def cues(self):
        self.current = [self.rng.randrange(2) for _ in range(CHANNELS)]
        return self.current

    def complete(self, straight):
        # Draw once per route for paired worlds, disclose only executed outcomes.
        events = [int(self.rng.random() < (.10, .65)[cue]) for cue in self.current]
        if straight:
            return 1 - 4 * events[self.relevant], events
        return 0, None


def run(seed, rank_by_loss, read_model):
    world, rng = Junctions(seed), Random(2 * seed + 1)
    candidates = [EventQuestion() for _ in range(CHANNELS)]
    active = rng.randrange(CHANNELS)
    probes = total = probe_total = useful_reads = straight_trips = 0
    for _ in range(TRIPS):
        cues = world.cues()
        probe = rng.random() < PROBE
        modeled = candidates[active].expected_reward(cues[active])
        marginal = probe_total / max(probes, 1)
        straight = probe or (modeled if read_model else marginal) > 0
        reward, events = world.complete(straight)
        total += reward
        straight_trips += int(straight)
        useful_reads += int(active == world.relevant)  # evaluator-only count
        if probe:
            probes += 1
            probe_total += reward
            for j, candidate in enumerate(candidates):
                candidate.observe(cues[j], events[j], reward)
            if probes % REVIEW == 0:
                ranked = min(range(CHANNELS), key=lambda j: candidates[j].loss)
                uniform = rng.randrange(CHANNELS)
                active = ranked if rank_by_loss else uniform
    return dict(reward=total, rate=total/(2*TRIPS), probes=probes,
                scored=CHANNELS*probes, selections=probes//REVIEW,
                straights=straight_trips, relevant_fraction=useful_reads/TRIPS)


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    records = []
    comparisons = {}
    for read in (False, True):
        delta = []
        for seed in range(PAIRS):
            a = run(seed, True, read)
            b = run(seed, False, read)
            assert (a['probes'], a['scored'], a['selections']) == (b['probes'], b['scored'], b['selections'])
            if not read:
                assert (a['reward'], a['straights']) == (b['reward'], b['straights'])
            for method, record in [('error', a), ('uniform', b)]:
                records.append(dict(seed=seed, use_model=int(read), selection=method, **record))
            delta.append(a['rate'] - b['rate'])
        comparisons[str(int(read))] = dict(mean=mean(delta), se=stdev(delta)/sqrt(PAIRS))
    with (OUT/'paired.csv').open('w',newline='') as out:
        writer=csv.DictWriter(out, fieldnames=records[0])
        writer.writeheader()
        writer.writerows(records)
    summary=dict(pairs=PAIRS, primitive_steps=TRIPS*2, probe_probability=PROBE,
                 comparisons_rate_per_step=comparisons,
                 active_relevant_fraction={m:mean(r['relevant_fraction'] for r in records
                      if r['use_model'] and r['selection']==m) for m in ('error','uniform')})
    (OUT/'summary.json').write_text(json.dumps(summary, indent=2)+'\n')
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
