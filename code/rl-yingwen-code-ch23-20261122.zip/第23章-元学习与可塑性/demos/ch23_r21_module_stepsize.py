"""第 23 章 23.2 节：步长分到多细——整个智能体一个、每个模块一个、每个参数一个。

Run from rl-course:
    python demos/ch23_r21_module_stepsize.py

Writes
    assets/ch23-r21/module-stepsize.pdf   (page ch23-r21-granularity)

11-21 审阅站请求 r1121-133704（第 23 章作者批注：各模块不同学习率）。
设定：线性预测 y = w*.x + 噪声，10 个输入 x_i ~ N(0,1)，噪声方差 1。
模块甲（前 5 个权重）的目标每步随机游走，标准差 .05；模块乙（后 5 个）目标固定。
元规则为分组 IDBD（Sutton 1992 的式子，按组求和）：
    beta_g <- beta_g + theta * sum_{i in g} delta x_i h_i,  alpha_i = exp(beta_{g(i)})
    w_i <- w_i + alpha_i delta x_i,  h_i <- h_i [1 - alpha_i x_i^2]^+ + alpha_i delta x_i
theta = .01，起始步长 .05，20000 步，20 个种子；误差取最后 5000 步的平均平方误差。
对照：整组写定步长 .005/.01/.02/.03/.05。
"""
from pathlib import Path
import sys

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter, FixedLocator, NullLocator

sys.path.insert(0, str(Path(__file__).resolve().parent))
from plot_fonts import use_course_fonts, CJK_FAMILY, no_leading_zero  # noqa: E402

TEAL, RED, GOLD, MUTED, INK = "#096B76", "#AA412D", "#A27618", "#52666E", "#182E38"
OUT = Path(__file__).resolve().parent.parent / "assets" / "ch23-r21"
T, SEEDS, N = 20000, 20, 10
GROUPS = {'agent': np.zeros(N, int), 'module': np.array([0] * 5 + [1] * 5), 'param': np.arange(N)}


def run(groups, seed, theta=.01, a0=.05, drift=.05):
    rng = np.random.default_rng(seed)
    wstar = rng.normal(0, 1, N)
    w, h = np.zeros(N), np.zeros(N)
    G = groups.max() + 1
    beta = np.full(G, np.log(a0))
    alpha_tr, err = np.empty((T, N)), np.empty(T)
    for t in range(T):
        wstar[:5] += rng.normal(0, drift, 5)
        x = rng.normal(0, 1, N)
        d = wstar @ x + rng.normal() - w @ x
        beta = beta + theta * np.bincount(groups, weights=d * x * h, minlength=G)
        a = np.exp(beta[groups])
        w = w + a * d * x
        h = h * np.clip(1 - a * x * x, 0, None) + a * d * x
        alpha_tr[t], err[t] = a, d * d
    return alpha_tr, err


def main():
    res = {}
    for k, g in GROUPS.items():
        A, E = [], []
        for s in range(SEEDS):
            a, e = run(g, s)
            A.append(a), E.append(e[-5000:].mean())
        A = np.array(A)
        res[k] = (np.median(A[:, :, :5].mean(2), 0), np.median(A[:, :, 5:].mean(2), 0))
        print(f"{k:6s} mse {np.mean(E):.3f} ± {np.std(E) / np.sqrt(SEEDS):.3f}"
              f"  final alpha A {res[k][0][-1]:.4f}  B {res[k][1][-1]:.4f}")
    for a0 in (.005, .01, .02, .03, .05):
        E = [run(GROUPS['agent'], s, theta=0, a0=a0)[1][-5000:].mean() for s in range(SEEDS)]
        print(f"fixed {a0:.3f} mse {np.mean(E):.3f}")

    use_course_fonts()
    fig, ax = plt.subplots(figsize=(3.7, 1.95))
    t = np.arange(1, T + 1)[::50]
    ax.plot(t, res['agent'][0][::50], color=MUTED, lw=1.4)
    ax.plot(t, res['module'][0][::50], color=TEAL, lw=1.6)
    ax.plot(t, res['module'][1][::50], color=RED, lw=1.6)
    ax.plot(t, res['param'][0][::50], color=TEAL, lw=1.0, ls=(0, (3, 2)))
    ax.plot(t, res['param'][1][::50], color=RED, lw=1.0, ls=(0, (3, 2)))
    ax.set_yscale('log')
    ax.set_xlim(0, T)
    ax.set_ylim(.002, .13)
    ax.yaxis.set_major_locator(FixedLocator([.003, .01, .03]))
    ax.yaxis.set_minor_locator(NullLocator())
    ax.yaxis.set_major_formatter(FuncFormatter(no_leading_zero))
    ax.xaxis.set_major_locator(FixedLocator([0, 10000, 20000]))
    ax.xaxis.set_major_formatter(FuncFormatter(lambda x, _p=None: f'{x / 1e4:g} 万' if x else '0'))
    ax.tick_params(labelsize=9.5, length=2.5, width=.6)
    for sp in ('top', 'right'):
        ax.spines[sp].set_visible(False)
    for sp in ('left', 'bottom'):
        ax.spines[sp].set_linewidth(.6)
    ax.set_xlabel('步数', fontsize=10.5, fontfamily=CJK_FAMILY, labelpad=1)
    ax.set_ylabel('步长（对数）', fontsize=10.5, fontfamily=CJK_FAMILY, labelpad=2)
    kw = dict(fontsize=9.5, fontfamily=CJK_FAMILY, ha='right')
    ax.text(T * .99, .047, '模块甲（目标在漂）', color=TEAL, va='bottom', **kw)
    ax.text(T * .99, .0255, '整体一个步长', color=MUTED, va='top', **kw)
    ax.text(T * .03, .088, '实线：每个模块一个　虚线：每个参数一个', color=INK,
            fontsize=9.5, fontfamily=CJK_FAMILY, ha='left')
    ax.text(T * .99, .0022, '模块乙（目标不动）', color=RED, **kw)
    fig.tight_layout(pad=.25)
    OUT.mkdir(parents=True, exist_ok=True)
    fig.savefig(OUT / 'module-stepsize.pdf')
    print('wrote', OUT / 'module-stepsize.pdf')


if __name__ == '__main__':
    main()
