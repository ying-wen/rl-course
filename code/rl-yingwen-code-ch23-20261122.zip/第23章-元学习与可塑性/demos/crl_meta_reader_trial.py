"""Closed-loop duration meta-learning on the chapter 15 continuing three-station task.

Run: python3 demos/crl_meta_reader_trial.py
Writes paired seed returns, time courses, divergence events and the summary in
assets/crl-meta-reader-trial. CPU only. No replay. The predictive derivative
conditions on the realized trajectory and truncates at completed trip blocks.
"""
import argparse
import csv
import json
from pathlib import Path

import numpy as np

from crl_joint_v12 import AT_STATION, COORDS, EPS_HIGH, EPS_LOW, N, NEXT, SLIP, STATIONS

OUT = Path(__file__).resolve().parents[1] / "assets" / "crl-meta-reader-trial"
REGIMES = ("stable", "corridor_delay")
READERS = ("completed", "td")
RATES = ("fixed", "adaptive")
ALPHA = .08
META_RATE = .03
HUBER = 4.
BLOCK = 64
DELAY = .65
TOLL_TENTHS = np.array([10, 2, 30])
station_at = np.array([AT_STATION.get(i, -1) for i in range(N)])
is_c_corridor = np.array([x >= 2 for x, y in COORDS])


def choose(values, explore, sample, tie, eps):
    """Uniform exploration and uniform greedy ties. values may include -inf."""
    legal = np.isfinite(values)
    best = values == values.max(axis=1)[:, None]
    mask = np.where((explore < eps)[:, None], legal, best)
    rank = (np.where(explore < eps, sample, tie) * mask.sum(axis=1)).astype(int)
    return (mask.cumsum(axis=1) > rank[:, None]).argmax(axis=1)


def save_csv(name, rows):
    with (OUT / name).open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def check_derivative():
    """Frozen sample path with termination, continuation and self-transition."""
    trips = [[(0, 0, False), (0, 1, False), (1, 1, True)],
             [(1, 0, False), (0, 0, True)], [(0, 1, False), (1, 0, True)],
             [(1, 1, True)], [(1, 0, False), (0, 1, True)]]
    def replay(beta):
        w = np.ones(2)
        h = np.zeros(2)
        loss = gradient = 0.
        for trip in trips:
            i = trip[0][0]
            residual = w[i] - len(trip)
            slope = np.clip(residual, -HUBER, HUBER)
            loss += .5 * residual**2 if abs(residual) <= HUBER else HUBER * (abs(residual) - .5 * HUBER)
            gradient += slope * h[i]
            for i, j, done in trip:
                delta = 1 + (not done) * w[j] - w[i]
                dh = (not done) * h[j] - h[i]
                h[i] += np.exp(beta) * (delta + dh)
                w[i] += np.exp(beta) * delta
        return loss, gradient
    beta = np.log(ALPHA)
    eps = 1e-5
    fd = (replay(beta + eps)[0] - replay(beta - eps)[0]) / (2 * eps)
    err = abs(fd - replay(beta)[1])
    assert err < 1e-7
    return err


def trial(seeds, steps, interval, seed_base):
    n = len(seeds)
    # A step-indexed stream per seed keeps random numbers paired after routes diverge.
    # This is simulator-only randomness. Each learner observes its actual transition.
    # Each keyed uniform is in [0,1) and independent across primitive clocks.
    rngs = [np.random.default_rng(seed_base + seed) for seed in seeds]
    noise = np.stack([rng.random((steps + 1, 9), dtype=np.float32) for rng in rngs], axis=1)
    m = 8 * n
    ids = np.arange(m)
    sidx = ids % n
    changing = ids // (4*n)
    td_read = (ids // (2*n)) % 2
    adaptive = (ids // n) % 2
    skill = np.zeros((m, 3, N, 4))
    K = np.ones((m, 3, N, 3))
    H = np.zeros_like(K)
    Rhat = np.zeros((m, 3, 3))
    Kbar = np.ones_like(Rhat)
    tail = np.zeros((m, 3))
    rho = np.zeros(m)
    beta = np.full(m, np.log(ALPHA))
    gsum = np.zeros(m)
    counts = np.zeros(m, int)
    start = np.zeros(m, int)
    goal = 1 + (noise[0, sidx, 8] >= .5).astype(int)
    pos = STATIONS[start].copy()
    last = start.copy()
    duration = np.zeros(m, int)
    trip_reward = np.zeros(m)
    entry_pred = np.ones(m)
    entry_h = np.zeros(m)
    squared_error = np.zeros(m)
    phase_error = np.zeros((2,m))
    phase_trips = np.zeros((2,m),int)
    total = np.zeros(m, int)
    halfway = total.copy()
    first_div = np.full((2, 2, n), -1, int)
    first_detail = []
    traces, outcomes = [], []
    diagonal = np.arange(3)
    # Gather the six possible start/target pairs (and unused diagonal) in each world.
    istart = diagonal[:,None]
    itarget = diagonal[None,:]

    for step in range(1, steps+1):
        u = noise[step, sidx]
        gid = (ids, goal, pos, last)
        alpha = np.exp(beta)
        act = choose(skill[ids,goal,pos], u[:,0], u[:,1], u[:,2], EPS_LOW)
        executed = np.where(u[:,3] < SLIP, (4*u[:,4]).astype(int), act)
        dest = NEXT[pos,executed]
        phase = int(step > steps // 2)
        stall = phase * changing.astype(bool) * (is_c_corridor[pos] | is_c_corridor[dest]) * (u[:,5] < DELAY)
        dest = np.where(stall, pos, dest)
        nl = np.where(station_at[dest]>=0, station_at[dest], last)
        reward = np.where(nl != last, TOLL_TENTHS[nl], 0)
        done = dest == STATIONS[goal]
        cont = ~done
        gid_next = (ids, goal, dest, nl)
        td_err = 1 + cont * K[gid_next] - K[gid]
        # Read current and successor before either write (including self loops).
        dh = cont * H[gid_next] - H[gid]
        H[gid] += alpha * (td_err + dh)
        K[gid] += alpha * td_err
        skill[ids,goal,pos,act] += .16*(-1 + cont*skill[ids,goal,dest].max(axis=1) - skill[ids,goal,pos,act])

        total += reward
        duration += 1
        trip_reward += reward/10
        rho += .002 * (reward/10 - rho)
        d = ids[done]
        if len(d):
            trip = (d,start[d],goal[d])
            Rhat[trip] += .08 * (trip_reward[d] - Rhat[trip])
            Kbar[trip] += .08 * (duration[d] - Kbar[trip])
            residual = entry_pred[d] - duration[d]
            squared_error[d] += residual**2
            phase_error[phase,d] += residual**2
            phase_trips[phase,d] += 1
            counts[d] += 1
            gsum[d] += np.clip(residual, -HUBER, HUBER)*entry_h[d]
            end = d[(counts[d] % BLOCK) == 0]
            proposal = np.clip(beta[end] - META_RATE*gsum[end]/BLOCK, np.log(.01), np.log(.32))
            beta[end] = np.where(adaptive[end], proposal, np.log(ALPHA))
            H[end] = 0
            gsum[end] = 0

        model_td = K[ids[:,None,None], itarget, STATIONS[istart], istart]
        model_t = np.where(td_read[:,None,None], model_td, Kbar)
        # One synchronous sweep; 6 legal option scores per primitive time step.
        old_tail = tail.copy()
        scores = Rhat - rho[:,None,None]*model_t + old_tail[:,None,:]
        scores[:,diagonal,diagonal] = -np.inf
        best = scores.max(axis=2)
        tail += .08*(best - best[:,0,None] - tail)
        # Keep pre-sweep decision scores. No second model call or extra backup.
        candidate = choose(scores[ids,goal], u[:,6], u[:,7], u[:,8], EPS_HIGH)
        if len(d):
            old_goal = goal[d].copy()
            start[d], goal[d] = old_goal, candidate[d]
            entry_pred[d] = K[d,goal[d],dest[d],nl[d]]
            entry_h[d] = H[d,goal[d],dest[d],nl[d]]
            duration[d], trip_reward[d] = 0, 0
        pos, last = dest, nl

        # At the first different target both past trajectories and this arrival agree.
        goals = goal.reshape(2,2,2,n)
        diff = (goals[:,:,0] != goals[:,:,1]) & (first_div < 0)
        if np.any(diff):
            first_div[diff] = step
            for regime, reader, k in zip(*np.nonzero(diff)):
                ix = ((regime*2+reader)*2)*n+k
                station = start[ix]
                ix_meta = ix+n
                assert done[ix] and done[ix_meta] and start[ix_meta] == station
                opts = [g for g in range(3) if g!=station]
                j,k2 = opts
                assert total[ix] == total[ix_meta] and np.array_equal(Rhat[ix],Rhat[ix_meta]) and rho[ix] == rho[ix_meta]
                direct = -rho[ix]*((model_t[ix_meta,station,j]-model_t[ix_meta,station,k2]) -
                                   (model_t[ix,station,j] - model_t[ix,station,k2]))
                indirect = (old_tail[ix_meta,j] - old_tail[ix_meta,k2]) - (old_tail[ix,j] - old_tail[ix,k2])
                observed_gap_shift = (scores[ix_meta,station,j]-scores[ix_meta,station,k2]) - (scores[ix,station,j]-scores[ix,station,k2])
                assert np.isclose(direct+indirect, observed_gap_shift)
                first_detail.append(dict(prefix_reward=total[ix]/10,initial_rate_at_split=float(rho[ix]),gap_shift_from_current_duration=float(direct),
                    gap_shift_from_accumulated_tail=float(indirect),regime=REGIMES[regime], reader=READERS[reader],
                    seed=seeds[k], step=step, station=int(station),
                    fixed_goal=int(goal[ix]), adaptive_goal=int(goal[ix_meta]),
                    fixed_duration_1=float(model_t[ix,station,opts[0]]),
                    adaptive_duration_1=float(model_t[ix_meta,station,opts[0]]),
                    fixed_duration_2=float(model_t[ix,station,opts[1]]),
                    adaptive_duration_2=float(model_t[ix_meta,station,opts[1]]),
                    candidate_1=opts[0],candidate_2=opts[1],
                    fixed_score_gap=float(scores[ix,station,opts[0]]-scores[ix,station,opts[1]]),
                    adaptive_score_gap=float(scores[ix_meta,station,opts[0]]-scores[ix_meta,station,opts[1]])))
        # Diagnostic reader is deliberately isolated from all acting state.
        assert np.array_equal(goals[:,0,0], goals[:,0,1])
        assert np.array_equal(act.reshape(2,2,2,n)[:,0,0], act.reshape(2,2,2,n)[:,0,1])
        assert np.array_equal(total.reshape(2,2,2,n)[:,0,0], total.reshape(2,2,2,n)[:,0,1])
        if step == steps//2:
            halfway = total.copy()
            for cube in (total, goal, beta, counts):
                assert np.array_equal(cube.reshape(2,4,n)[0], cube.reshape(2,4,n)[1])
        if step % interval == 0 or step == steps:
            for i in range(m):
                traces.append(dict(regime=REGIMES[changing[i]],reader=READERS[td_read[i]],rule=RATES[adaptive[i]],
                                seed=seeds[sidx[i]],step=step,reward=total[i]/10,log_step_size=beta[i],
                                completed_trips=counts[i],duration_square_error=squared_error[i]))
    arrays = [skill, K, H, Rhat, Kbar, tail]
    for i in range(m):
        reg, read, met = changing[i], td_read[i], adaptive[i]
        outcomes.append(dict(regime=REGIMES[reg],reader=READERS[read],rule=RATES[met],seed=seeds[sidx[i]],
            steps=steps,total_reward=total[i]/10,first_half_reward=halfway[i]/10,
            second_half_reward=(total[i]-halfway[i])/10,completed_options=counts[i],
            duration_rmse=np.sqrt(squared_error[i]/max(counts[i],1)),
            second_half_duration_rmse=np.sqrt(phase_error[1,i]/max(phase_trips[1,i],1)),
            final_alpha=np.exp(beta[i]),first_choice_divergence=int(first_div[reg,read,sidx[i]]),
            duration_td_writes=steps,sensitivity_writes=steps,skill_writes=steps,
            rate_writes=steps,planning_option_scores=6*steps,relative_value_writes=3*steps,
            completed_model_writes=2*counts[i],meta_proposals=counts[i]//BLOCK,
            float_slots_in_tables=sum(v[i].size for v in arrays),
            float_slots_in_tables_and_persistent_scalars=sum(v[i].size for v in arrays)+6))
    lookup = {(r["regime"], r["reader"], r["rule"], r["seed"]): r for r in outcomes}
    for detail in first_detail:
        for rule in RATES:
            whole = lookup[detail["regime"],detail["reader"],rule,detail["seed"]]["total_reward"]
            detail[rule+"_reward_after_first_split"] = round(whole - detail["prefix_reward"], 8)
    return outcomes, traces, first_detail


def analyze(rows, steps):
    by = {(r["regime"],r["reader"],r["rule"],r["seed"]):r for r in rows}
    seeds = sorted({r["seed"] for r in rows})
    # Paired percentile bootstrap over independent lifetimes, one index matrix per comparison.
    bootstrap = np.random.default_rng(7125).integers(len(seeds), size=(20000, len(seeds)))
    def mean_interval(xs):
        xs = np.asarray(xs)
        m = xs.mean()
        lo, hi = np.quantile(xs[bootstrap].mean(axis=1), [.025, .975])
        return dict(mean=float(m),se=float(xs.std(ddof=1)/np.sqrt(len(xs))),lo=float(lo),hi=float(hi))
    report = {}
    for regime in REGIMES:
        for reader in READERS:
            fixed = [by[regime,reader,"fixed",s] for s in seeds]
            meta = [by[regime,reader,"adaptive",s] for s in seeds]
            g = lambda a,k: np.array([r[k] for r in a])
            report[regime+"_"+reader] = dict(
                fixed_reward_per_1000=float(1000*g(fixed,"total_reward").mean()/steps),
                adaptive_reward_per_1000=float(1000*g(meta,"total_reward").mean()/steps),
                paired_gain_per_1000=mean_interval(1000*(g(meta,"total_reward")-g(fixed,"total_reward"))/steps),
                paired_first_half_per_1000=mean_interval(2000*(g(meta,"first_half_reward")-g(fixed,"first_half_reward"))/steps),
                paired_second_half_per_1000=mean_interval(2000*(g(meta,"second_half_reward")-g(fixed,"second_half_reward"))/steps),
                fixed_realized_duration_rmse=float(g(fixed,"duration_rmse").mean()),
                adaptive_realized_duration_rmse=float(g(meta,"duration_rmse").mean()),
                paired_realized_duration_rmse=mean_interval(g(meta,"duration_rmse")-g(fixed,"duration_rmse")),
                final_alpha_mean=float(g(meta,"final_alpha").mean()),
                first_different_choice_seeds=int((g(meta,"first_choice_divergence")>=0).sum()),
                median_first_different_choice=float(np.median(g(meta,"first_choice_divergence")[g(meta,"first_choice_divergence")>=0])) if np.any(g(meta,"first_choice_divergence")>=0) else None,
                mean_completion_counts=[float(g(k,"completed_options").mean()) for k in (fixed,meta)])
    return report


def plot_results(report, output):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib import font_manager

    installed = {font.name for font in font_manager.fontManager.ttflist}
    font = next((name for name in ("PingFang SC", "Noto Sans CJK SC", "Songti SC",
                                   "WenQuanYi Zen Hei", "Microsoft YaHei") if name in installed), None)
    if font is None:
        # Fonts affect presentation only; the numeric experiment remains reproducible.
        print("Install a Chinese font to render the figure.")
        return
    with plt.rc_context({"font.family":font, "axes.unicode_minus":False, "pdf.fonttype":42, "svg.fonttype":"path"}):
        fig, axes = plt.subplots(1,2,figsize=(9.4,3.05),layout="constrained")
        fig.suptitle("自适应步长减固定步长　·　点为配对均值，横线为 95% 区间",fontsize=13)
        for ax in axes:
            ax.spines[["top","right","left"]].set_visible(False)
            ax.set_ylim(-.54,1.58)
            ax.set_yticks([1,0],labels=["平稳","支路变慢"])
            ax.tick_params(axis="y",length=0)
            ax.axvline(0,color="#94a2a5",ls="--",lw=1,zorder=0)
        for y,reg in zip([1,0],REGIMES):
            for axis,read,key in [(axes[0],"completed","paired_realized_duration_rmse"),
                                  (axes[1],"td","paired_gain_per_1000")]:
                d = report[reg+"_"+read][key]
                color = "#176e70" if axis is axes[0] else "#a0512a"
                axis.errorbar(d["mean"],y,xerr=[[d["mean"]-d["lo"]],[d["hi"]-d["mean"]]],
                              fmt="o",color=color,lw=2,ms=6,capsize=4)
        axes[0].set(title="A　规划器读取完成行程估计",xlabel="逐步预测的时长 RMSE 差（步）",xlim=(-.056,.007))
        axes[1].set(title="B　规划器读取逐步时长预测",xlabel="全程主奖励差（每千个原始步）",xlim=(-1.45,.25))
        for ax in axes:
            ax.tick_params(labelsize=11)
            ax.title.set_fontsize(14)
            ax.xaxis.label.set_fontsize(11)
        for ext in ("svg","pdf","png"):
            fig.savefig(output/("meta-reader-effects."+ext), bbox_inches="tight", dpi=155)
        plt.close(fig)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seeds",type=int,default=64)
    parser.add_argument("--steps",type=int,default=24000)
    parser.add_argument("--batch",type=int,default=64)
    parser.add_argument("--seed-base",type=int,default=140000)
    parser.add_argument("--out",type=Path,default=OUT)
    args = parser.parse_args()
    if args.seeds < 2 or args.steps < 100 or args.steps%2 or args.batch < 1:
        raise ValueError("Require at least two seeds, an even horizon >=100, and positive batch size.")
    globals()["OUT"] = args.out
    OUT.mkdir(parents=True,exist_ok=True)
    outcomes, curves, divergences = [], [], []
    for first in range(0,args.seeds,args.batch):
        s = list(range(first,min(first+args.batch,args.seeds)))
        result = trial(s,args.steps,min(1000,args.steps),args.seed_base)
        for store, seq in zip([outcomes,curves,divergences],result):
            store.extend(seq)
    save_csv("runs.csv",outcomes)
    save_csv("curves.csv",curves)
    if divergences: save_csv("first-divergences.csv",divergences)
    summary = dict(horizon=args.steps,seeds=args.seeds,seed_base=args.seed_base,
                   block=BLOCK,alpha0=ALPHA,meta_rate=META_RATE,huber=HUBER,wait_probability=DELAY,
                   finite_difference_error=check_derivative(),conditions=analyze(outcomes,args.steps))
    (OUT/"results.json").write_text(json.dumps(summary,ensure_ascii=False,indent=2)+"\n")
    plot_results(summary["conditions"], OUT)
    print(json.dumps(summary,ensure_ascii=False,indent=2))


if __name__ == "__main__":
    main()
