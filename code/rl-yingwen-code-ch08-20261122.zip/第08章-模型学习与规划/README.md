# 第 8 章　模型学习与规划：程序

本目录可以单独运行：在本目录下执行下面的命令即可，结果写回本目录的 `assets/`。目录由 `rl-course/tools/export_chapter_code.py` 从课程目录生成，改程序请改课程目录里的原件，再重新导出。

## 准备

```sh
python3 -m pip install -r requirements.txt
```

需要的第三方包：matplotlib、numpy、torch。复现附录要求 Python 3.10 或更新版本；核验时用的版本见下表。

## 运行（与复现附录相同）

```sh
python3 demos/mud_planning.py --output assets/mud-planning
python3 demos/mud_planning.py --dyna-step
python3 demos/route_search.py --output assets/mud-planning/search.json
python3 demos/classic_v8_foundations.py
python3 demos/classic_v13_mechanisms.py
python3 demos/prediction_information_budget.py --plot
python3 demos/td_control.py
python3 demos/v18_methods.py
python3 demos/classic_v10_derivations.py
python3 demos/ch08_trajectory_sampling.py --out demos/ch08-trajectory-sampling-results
python3 demos/classic_v6_lab.py
python3 demos/shortcut_exploration.py
python3 demos/multiscale_models.py
python3 demos/continual_figures.py
```

## 本目录的程序

| 程序 | 说明 | 核验 |
|---|---|---|
| `demos/mud_planning.py` | Two route policies in the course mud maze. Only the S4 success rate is learned. | 通过（1 秒） |
| `demos/classic_v8_foundations.py` | Reproducible calculations for chapters 2--8 (standard library only). | 通过（0 秒） |
| `demos/classic_v13_mechanisms.py` | Exact teaching calculations for MDPs, TD, traces, and model-based planning. | 通过（2 秒） |
| `demos/prediction_information_budget.py` | Matched real-interaction budgets for predicting a one-state episodic value. | 通过（2 秒） |
| `demos/td_control.py` | Auditable numbers and small runs for chapter 03 (Python standard library). | 通过（3 秒） |
| `demos/v18_methods.py` | One-update scientific diagrams for chapters 7--11; no training runs. | 通过（3 秒） |
| `demos/classic_v10_derivations.py` | Reproducible chapter 2–8 derivations on the unchanged mud task. | 通过（0 秒） |
| `demos/ch08_trajectory_sampling.py` | Chapter 8: uniform sweeps versus on-policy trajectory sampling. | 超时：300 秒内未跑完（启动正常） |
| `demos/route_search.py` | Depth-limited lookahead at S7, using the two route policies of mud_world. | 通过（0 秒） |
| `demos/classic_v6_lab.py` | Visible learning states for chapters 2--8. Local, small, reproducible runs. | 通过（2 秒） |
| `demos/shortcut_exploration.py` | Dyna in the shortcut maze, Sutton & Barto, 2nd edition, Fig. 8.5. | 通过（26 秒） |
| `demos/multiscale_models.py` | Compare recursive and direct prediction with exactly the same observed paths. | 通过（5 秒） |
| `demos/continual_figures.py` | Render original figures from formulas and multiscale CSV; requires matplotlib. | 通过（3 秒） |
| `demos/ch08_td_stepsize_budget.py` | Step-size control for the p436 experiment (ch08, vision-model-planning). | 通过（9 秒） |
| `demos/ch08_dyna_maze.py` | Dyna-Q on the Sutton-Barto Dyna maze (Example 8.1), rerun for the course. | 通过（52 秒） |
| `demos/ch08_planning_budget_mud.py` | Dyna-Q on the mud world: planning budget B = 0, 5, 20 per real step. | 出错 |
| `demos/mud_world.py` | The lecture's 3 x 3 mud maze, with an exact model and sampled predictions. | 通过（0 秒） |
| `demos/classic_foundations.py` | Small exact checks for chapters 2--8; standard library, no training. | 通过（0 秒） |
| `demos/classic_v9_checks.py` | Independent checks for v9 chapters 2–8; no training or old-output writes. | 通过（0 秒） |
| `demos/ch08_sample_vs_expected.py` | Chapter 8, p. "样本更新与期望更新": redraw of Sutton and Barto (2nd ed.) | 通过（1 秒） |

被上面程序 import 的本课模块：`demos/course15_traces.py`、`demos/dqn_model_v11.py`、`demos/plot_fonts.py`、`demos/ppo_sac_v11_lab.py`、`demos/sample14_pg.py`、`demos/sample14_sac.py`、`demos/v17_methods.py`。

表中后 7 个程序复现附录本章一节没有列出，来自课件、阅读稿、CODE-MAP 或文件名前缀（第三部分另含学习器阶梯）。

## 复现附录本章一节

本章的模拟结果包括泥地上的真实尝试记录、Dyna 运行、规划预算比较、轨迹采样、捷径迷宫，以及同一预算下的预测误差。规划路径、前瞻搜索、跨训练集的选路概率和模型误差分解则在给定的计数上精确计算。

表末两行的递归与直接多步预测比较原在 8B 节，现属第 22 章 22.0 节，程序同时为第 12 章所用。捷径迷宫的超参数取自外部代码，见表后。

| 位置 | 结果 | 设置 | 程序 | 数据与输出 |
|---|---|---|---|---|
| 8.1 节“转移模型与 Bellman 更新”（课件 `dyna-original`） | S4 向上的逐次真实尝试记录，前十次中两次到达 G，计数模型 $\hat p=2/10$ | 本课的模拟：从 S4 重复尝试向上，真实成功概率 .1，共 80 次尝试，随机数种子 2 | `demos/mud_planning.py` | `assets/mud-planning/real-trials.csv`、`assets/mud-planning/reader.json`（`trials`） |
| 8.1 节（计数模型的独立诊断） | $N=10,100,1000$ 时 S4 成功率 0、.06、.097，经验模型中的旧策略价值 0、.38961、.51789，真实价值 .52632 | 本课的模拟：每个状态动作各做 $N$ 次独立转移试验，随机数种子 7；再在经验模型上精确评价旧策略 | `demos/classic_v8_foundations.py` | `assets/v8-classic/results.json`（`learned_model_rows`） |
| 8.1 节“模型的期望更新与样本更新”“模型误差与模型内部的抽样误差” | 冻结 $V_Q(\mathrm{S4})=.5$ 时真实目标均值 .505、模型目标均值 .560，偏差 .055；模型抽样方差 .0484 按 $1/K$ 下降，偏差平方不变 | 真实成功概率 .1，模型 $\hat p=.2$；精确计算，无训练 | `demos/classic_v13_mechanisms.py` | `assets/classic-v13/model-error-budget.png`、`assets/classic-v13/results.json`（`model_budget`） |
| 8.1 节“同一批真实转移能学到多准”（课件 `vision-model-planning`） | 四种方法的 RMSE 随真实行动数的变化；8 步时一步 TD .408、MC .436，128 步时 .249、.083 | 本课的模拟：固定策略在 S4 向上，$p=.1$，$\gamma=.9$；真实行动预算 8 至 2048；一步 TD（步长 $1/t$）、四步 TD、每次访问 MC 与拟合模型共用同一条轨迹；独立重复 256 次（种子 0–255） | `demos/prediction_information_budget.py` | `assets/prediction-information/learning.svg`、`assets/prediction-information/runs.json`、`assets/prediction-information/predictions.csv` |
| 8.2 节“Dyna-Q 与模拟经验” | 第十一次真实尝试留在 S4：$Q(\mathrm{S4},\uparrow)$ 由 .400 到 .410，$\hat p$ 由 2/10 到 2/11；随后一次模型查询得 .418 或 .528，条件均值 .438 | 前十次的计数与 $Q(\mathrm{S4},\uparrow)=.4$，步长 .2；第十一次尝试取自随机数种子 2 的同一试验序列 | `demos/mud_planning.py`（`--dyna-step`） | 只在终端输出，不写文件 |
| 8.2 节“规划更新是学到模型上的 DP 回溯” | $\hat p=.2$ 时期望更新 $W_4=.470097$、$W_8=.596430$、$W_{16}=.639504$，$W_8$ 首次越过干路 .59049 | 在计数模型上从 $W_0=0$ 反复做期望更新；精确计算，无训练 | `demos/mud_planning.py` | `assets/mud-planning/path.csv` |
| 8.2 节“规划计算与真实策略价值”（课件 `ch08-planning-budget-mud`、`learning-36`） | 每个真实步规划 0、5、20 次时冻结贪心策略价值 $.379\pm.200$、$.355\pm.249$、$.308\pm.269$（样本标准差）；Q 更新总数 1500、9000、31500 | 本课的模拟：泥地 Dyna-Q，从 S7 出发，1500 个真实步，$\alpha=.2$，$\epsilon=.2$，$\gamma=.9$，规划抽样用种子加 100000，独立重复 10 次（种子 0–9）；冻结策略用精确模型评价。作图程序把三组均值与标准差直接写在代码中 | `demos/td_control.py`；`demos/v18_methods.py`（作图） | `demos/03-results/planning-0.csv`、`demos/03-results/planning-5.csv`、`demos/03-results/planning-20.csv`、`demos/03-results/raw-runs.json`、`demos/03-results/manifest.json`、`assets/v18-methods/planning-budget.png` |
| 8.3 节“优先扫描与搜索控制”（课件 `classic-v10-dyna-computation`） | 三次模型查询的目标与更新：.18 后写入 .036，.0324 后写入 .00648 | 给定 Q 表与步长 .2 的有限算术 | `demos/classic_v10_derivations.py` | `assets/classic-v10/derivations.json`（`dyna_schedule`） |
| 8.3 节“轨迹采样”（课件 `ch08-trajectory-sampling`） | $b=3$ 时均匀扫描 .938、1.643、2.001、2.369、3.314，轨迹采样 1.451、1.868、2.004、2.115、2.907；领先到约 1250 次；$b=1$ 时 20000 次为 7.820 比 7.029；更新最多的 1% 与 10% 状态动作对占 28.5% 与 57.8% 的计算 | 本课的模拟：按 Sutton 与 Barto §8.6 的随机任务，1000 个状态、每状态 2 个动作，分支 $b=1$ 与 $b=3$，每次转移以 .1 终止，期望更新预算 20000，每 250 次精确评价一次起点价值，独立重复 200 次（每次一个新任务，NumPy 随机数种子 20261118） | `demos/ch08_trajectory_sampling.py` | `demos/ch08-trajectory-sampling-results/results.json`（百分比由 `sorted_counts_mean` 算出） |
| 8.4 节“后台规划与决策时搜索”（课件 `planning-two-uses`） | $\hat p=2/10$ 时前瞻五步泥路 .47010；六步干路 .59049 胜过泥路 .51847；九步泥路 .59643 胜出；真实回报干路 .59049、泥路 .47368 | 只拟合 S4 成功率，取前十次真实尝试；分数精确运算的深度受限前瞻，选定路线另用环境模型评价 | `demos/route_search.py` | `assets/mud-planning/search.json` |
| 8.4 节“想得多不一定走得好”（课件 `v17-methods-model-decision`） | $k=7$ 泥路估值 .57837，$k=8$ 为 .59643 改选泥路；再读六次失败后 .45111，改回干路；$p=.1$、$N=10$ 时约 26.4% 的训练集选泥路 | 前 10 次与前 16 次真实尝试（随机数种子 2）的计数模型上做 $k$ 次期望更新；跨训练集的选路概率按二项分布精确加权 | `demos/mud_planning.py` | `assets/mud-planning/planning.svg`、`assets/mud-planning/path.csv`、`assets/mud-planning/population.csv`、`assets/mud-planning/reader.json`（`table`） |
| 8.6 节“环境变化下的 Dyna-Q+” | 两万步后的最大动作价值与贪心箭头；$Q(\mathrm{S4},\uparrow)=.53445$；真实记录 165 次成功、1416 次停留，经验模型给出 .53816，环境给出 .52632 | 本课的模拟：Dyna-Q，从 S7 重置，初值 1，$\alpha=.05$，$\epsilon=.2$，每个真实步 5 次规划更新，20000 个真实转移，单次运行，随机数种子 7；冻结策略用精确模型评价 | `demos/classic_v6_lab.py` | `assets/v6-classic/dyna-policy.png`、`assets/v6-classic/results.json`（`dyna`，计数在 `mud_up_counts`） |
| 8.6 节“Dyna-Q+与捷径探索”（课件 `ch08-dyna-plus-algorithm`、`classic-v13-dyna-plus`） | 开墙前到达终点 Dyna-Q 113.90、Dyna-Q+ 135.35 次，开墙后 164.55、228.85 次；Dyna-Q 3 次运行进入新格、0 次穿过；Dyna-Q+ 20 次全部穿过，首次穿过延迟中位数 375 步 | 本课的模拟：6×9 捷径迷宫，第 3000 步后打开缺口，共 6000 个真实步，每个真实步 50 次规划，$\alpha=1$，$\gamma=.95$，$\epsilon=.1$，$\kappa=.001$，独立重复 20 次（种子 0–19） | `demos/shortcut_exploration.py` | `assets/shortcut-exploration/shortcut.png`、`assets/shortcut-exploration/results.json`、`assets/shortcut-exploration/curves.csv`、`assets/shortcut-exploration/runs.csv`、`assets/shortcut-exploration/events.csv` |
| 第 22 章 22.0 节“模型误差的传播上界”，图 22.0a（原 8B.2 节） | 收缩系统 $f(x)=.5x$、$\widehat f(x)=.4x$ 的实际误差 0、.1、.09、.061、.0369，Lipschitz 上界向 .2 增长 | 从起点 1 逐步递推，精确计算，无训练 | `demos/multiscale_models.py`；`demos/continual_figures.py`（作图） | `demos/multiscale-results/counterexample.csv`、`assets/continual/contractive-counterexample.png` |
| 第 22 章 22.0 节“递归与直接预测的同数据比较”，两张误差表与图 22.0b（原 8B.5 节） | 正确模型类、$N=32$ 时 $k=1,8,16$ 的均值 MSE：递归 .000114、.001577、.001182，直接 .001298、.005882、.006612；$N=256$、16 步 .000137 与 .000774。遗漏截距时为 .05549、1.00266、1.47058 与 .04145、.71348、.97269；$N=256$、16 步 1.46094 与 .94841 | 本课的模拟：两种线性过程（$a=.9,c_0=0,\sigma=.2$；$a=.8,c_0=.2,\sigma=.1$），每个训练集 $N=32$ 或 256 条轨迹、每条 16 个转移，起点取自 Uniform$[-1,1]$；递归一步与直接 $k$ 步均为无截距最小二乘，误差按起点分布精确积分；独立重复 300 次（基准种子 602810） | `demos/multiscale_models.py`；`demos/continual_figures.py`（作图） | `demos/multiscale-results/linear-32.csv`、`demos/multiscale-results/linear-256.csv`、`demos/multiscale-results/omitted_intercept-32.csv`、`demos/multiscale-results/omitted_intercept-256.csv`、`demos/multiscale-results/summary.json`、`demos/multiscale-results/raw.csv`、`demos/multiscale-results/manifest.json`、`assets/continual/multiscale-results.png` |

外部代码（出处）：捷径迷宫的超参数取自 Shangtong Zhang 与 Kenta Shimada 的 `chapter08/maze.py`（figure_8_5），https://github.com/ShangtongZhang/reinforcement-learning-an-introduction/blob/master/chapter08/maze.py ；本课的程序为独立实现，随机数流、开墙时刻与统计量另行规定。Dyna 架构图、Dyna 迷宫图（图 8.2）、图 8.7 与捷径迷宫图取自 Sutton 与 Barto；统一视角图取自 Sutton 与 Barto 第一版图 10.1。

运行：
```sh
python3 demos/mud_planning.py --output assets/mud-planning
python3 demos/mud_planning.py --dyna-step
python3 demos/route_search.py --output assets/mud-planning/search.json
python3 demos/classic_v8_foundations.py
python3 demos/classic_v13_mechanisms.py
python3 demos/prediction_information_budget.py --plot
python3 demos/td_control.py
python3 demos/v18_methods.py
python3 demos/classic_v10_derivations.py
python3 demos/ch08_trajectory_sampling.py --out demos/ch08-trajectory-sampling-results
python3 demos/classic_v6_lab.py
python3 demos/shortcut_exploration.py
python3 demos/multiscale_models.py
python3 demos/continual_figures.py
```

## 参考数据

`assets/`（以及 `demos/NN-results/`）下复制了 57 个数据文件（json、csv 等），即课程目前使用的结果；图片没有复制，运行程序会重新画出。重跑会覆盖这些文件，可以先另存一份再对照。
