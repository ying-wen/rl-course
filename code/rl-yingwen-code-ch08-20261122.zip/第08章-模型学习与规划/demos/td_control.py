"""Auditable numbers and small runs for chapter 03 (Python standard library).

Run from the project root:
    python3 demos/td_control.py

This imports the lecture's unchanged mud_world.py. The simulator has a model;
the model-free learners see only sampled transitions. Exact-model evaluation
is a separate diagnostic, never used by their training updates.
"""
from __future__ import annotations

import csv
import json
import math
import random
import statistics
from collections import Counter, defaultdict
from pathlib import Path

import mud_world as world

OUT = Path(__file__).parent / "03-results"
ACT = tuple(world.ACTIONS)
GAMMA = world.GAMMA
TRUTH = world.evaluate(world.OLD)
TRAJECTORY = [
    ("S7", "up", 0.0, "S4", False),
    ("S4", "up", 0.0, "S4", False),
    ("S4", "up", 0.0, "S4", False),
    ("S4", "up", 1.0, "G", True),
]


def sample(s, a, rng):
    x, total = rng.random(), 0.0
    choices = world.outcomes(s, a)
    for p, nxt, r, done in choices:
        total += p
        if x < total:
            return nxt, r, done
    raise AssertionError("transition probabilities did not sum to one")


def returns(trajectory):
    result, g = [], 0.0
    for _, _, r, _, _ in reversed(trajectory):
        g = r + GAMMA * g
        result.append(g)
    return list(reversed(result))


def hand_checks():
    gs = returns(TRAJECTORY)
    assert all(abs(x-y) < 1e-12 for x,y in zip(gs,[.729,.81,.9,1.]))
    first_s4, every_s4 = gs[1], statistics.mean(gs[1:])
    assert abs(every_s4 - 2.71/3) < 1e-12
    v = {"S7": .4, "S4": .5, "G": 0.0}
    updates = []
    for s,a,r,nxt,done in TRAJECTORY:
        before = v[s]
        target = r + GAMMA * (0.0 if done else v[nxt])
        v[s] += .2 * (target - v[s])
        updates.append(dict(s=s,a=a,r=r,next=nxt,target=target,before=before,after=v[s]))
    assert abs(v["S7"]-.41) < 1e-12
    assert abs(v["S4"]-.58416) < 1e-12
    # Fixed-table forward/backward identity, including repeated visits.
    frozen = {"S7": .4, "S4": .5, "G": 0.0}
    lam, forward, backward = .8, defaultdict(float), defaultdict(float)
    trace, deltas, lambda_returns = defaultdict(float), [], []
    for t,(s,a,r,nxt,done) in enumerate(TRAJECTORY):
        horizons = []
        for n in range(1,len(TRAJECTORY)-t+1):
            target = sum(GAMMA**k * TRAJECTORY[t+k][2] for k in range(n))
            if t+n < len(TRAJECTORY):
                target += GAMMA**n * frozen[TRAJECTORY[t+n][0]]
            horizons.append(target)
        h = len(horizons)
        weights = [(1-lam)*lam**k for k in range(h-1)] + [lam**(h-1)]
        assert abs(sum(weights)-1) < 1e-12
        gl = sum(w*g for w,g in zip(weights,horizons))
        lambda_returns.append(gl)
        forward[s] += gl-frozen[s]
        delta = r+GAMMA*frozen[nxt]-frozen[s]
        deltas.append(delta)
        for old in list(trace): trace[old] *= GAMMA*lam
        trace[s] += 1
        for old,z in trace.items(): backward[old] += delta*z
    assert max(abs(forward[s]-backward[s]) for s in forward) < 1e-12
    assert abs(trace["S7"]-.72**3) < 1e-12
    assert abs(trace["S4"]-(1+.72+.72**2)) < 1e-12
    one_step_mean = .9*(.9*.5)+.1*1
    one_step_var = .9*(.9*.5-one_step_mean)**2+.1*(1-one_step_mean)**2
    mc_mean = .1/(1-.9*GAMMA)
    mc_var = .1/(1-.9*GAMMA**2)-mc_mean**2
    qnext = [.5,.1,.2,.7]  # ACT = up,right,down,left
    pi = [.05,.05,.05,.85]
    expected_q = sum(p*q for p,q in zip(pi,qnext))
    assert abs(expected_q-.635) < 1e-12
    assert abs(GAMMA*expected_q-.5715) < 1e-12
    assert abs(sum(.5*w*g for w,g in [(1.6,1),(.4,3)])-1.4) < 1e-12
    return dict(
        trajectory=TRAJECTORY, returns=gs, first_visit_s4=first_s4,
        every_visit_s4=every_s4, online_td_updates=updates,
        fixed_v_nstep_s7=[.45,.405,.3645,.729],
        lambda_value=.8, lambda_returns=lambda_returns,
        frozen_forward_error_sum=dict(forward), frozen_backward_error_sum=dict(backward),
        final_accumulating_traces=dict(trace),
        conditional_target_s4=dict(mc_mean=mc_mean,mc_variance=mc_var,
            td_mean=one_step_mean,td_variance=one_step_var,
            td_bias=one_step_mean-TRUTH["S4"]),
        control_targets=dict(sarsa_sample_up=.45,expected_sarsa=.5715,q_learning=.63),
        exact_values=TRUTH,
    )


def prediction_run(seed, episodes=1000):
    rng = random.Random(seed)
    mc,td = dict.fromkeys(world.STATES,0.0),dict.fromkeys(world.STATES,0.0)
    rows, steps = [],0
    for ep in range(1,episodes+1):
        trajectory = []
        s = "S7"
        while True:
            a = world.OLD[s]
            nxt,r,done = sample(s,a,rng)
            trajectory.append((s,a,r,nxt,done))
            # Immediate TD update, before the next real transition.
            target = r+GAMMA*(0 if done else td[nxt])
            td[s] += .05*(target-td[s])
            steps += 1
            if done: break
            s = nxt
        seen = set()
        for (s,_,_,_,_),g in zip(trajectory,returns(trajectory)):
            if s in seen: continue  # first visit within this episode
            seen.add(s)
            mc[s] += .05*(g-mc[s])
        if ep == 1 or ep%10 == 0:
            rmse = lambda v: math.sqrt(sum((v[s]-TRUTH[s])**2 for s in ("S7","S4"))/2)
            rows.append(dict(episode=ep,environment_steps=steps,mc_rmse=rmse(mc),td_rmse=rmse(td)))
    return rows


def greedy(q,s):
    return max(ACT,key=lambda a:q[s,a])  # deterministic tie-breaking for evaluation


def choose(q,s,rng,epsilon=.2):
    if rng.random()<epsilon:return rng.choice(ACT)
    best=max(q[s,a] for a in ACT)
    return rng.choice([a for a in ACT if q[s,a]==best])


def control_run(seed, planning, steps=1500):
    # Separate planner RNG prevents its draws from consuming environment RNG.
    rng, plan_rng = random.Random(seed), random.Random(seed+100000)
    q=defaultdict(float)
    counts=defaultdict(Counter)
    s,rows="S7",[]

    def update(s,a,r,nxt,done):
        target=r+GAMMA*(0 if done else max(q[nxt,b] for b in ACT))
        q[s,a]+=.2*(target-q[s,a])

    for t in range(1,steps+1):
        a=choose(q,s,rng)
        nxt,r,done=sample(s,a,rng)
        update(s,a,r,nxt,done)  # one direct RL update
        counts[s,a][nxt,r,done]+=1
        for _ in range(planning):
            u,c=plan_rng.choice(list(counts))
            choices=counts[u,c]
            (v,reward,terminal),=plan_rng.choices(list(choices),weights=list(choices.values()),k=1)
            update(u,c,reward,v,terminal)
        s="S7" if done else nxt
        if t==1 or t%50==0:
            policy={state:greedy(q,state) for state in world.STATES}
            # Independent exact diagnostic of the FROZEN greedy policy.
            value=world.evaluate(policy)["S7"]
            assert -.000001 <= value <= GAMMA**5+1e-9
            rows.append(dict(environment_steps=t,q_updates=t*(planning+1),
                             greedy_v_s7=value,planning=planning))
    return rows


def aggregate(runs,xkey,metrics):
    rows=[]
    for i in range(len(runs[0])):
        row={xkey:runs[0][i][xkey]}
        for metric in metrics:
            values=[r[i][metric] for r in runs]
            row[metric+"_mean"]=statistics.mean(values)
            row[metric+"_std"]=statistics.stdev(values)
        rows.append(row)
    return rows


def write_csv(path,rows):
    with path.open("w",newline="") as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)


def main():
    OUT.mkdir(parents=True,exist_ok=True)
    checks=hand_checks()
    # Independent complete episodes validate the analytic reference.
    rng=random.Random(173)
    sampled=[]
    for _ in range(10000):
        s,g,discount="S7",0.0,1.0
        while True:
            nxt,r,done=sample(s,world.OLD[s],rng)
            g+=discount*r;discount*=GAMMA
            if done:break
            s=nxt
        sampled.append(g)
    se=statistics.stdev(sampled)/math.sqrt(len(sampled))
    assert abs(statistics.mean(sampled)-TRUTH["S7"])<6*se
    prediction=[prediction_run(seed) for seed in range(10)]
    write_csv(OUT/"prediction.csv",aggregate(prediction,"episode",["mc_rmse","td_rmse","environment_steps"]))
    control={}
    for n in [0,5,20]:
        control[str(n)]=[control_run(seed,n) for seed in range(10)]
        write_csv(OUT/f"planning-{n}.csv",aggregate(control[str(n)],"environment_steps",["greedy_v_s7","q_updates"]))
    manifest=dict(
        task="3x3 mud maze, one blocked central cell; S4 sticky with probability 0.9",
        reward="1 only on entering true terminal G, 0 otherwise",gamma=GAMMA,start="S7",
        prediction=dict(seeds=list(range(10)),episodes=1000,alpha=.05,
            policy="fixed OLD; only S7 and S4 are visited",mc="first-visit constant-alpha",
            metric="RMSE against exact v_pi on {S7,S4}, per training episode",
            bands="sample standard deviation across independent training seeds; not confidence intervals"),
        control=dict(seeds=list(range(10)),environment_steps=1500,alpha=.2,epsilon=.2,
            planning_steps_per_real_transition=[0,5,20],
            model="empirical count distribution over observed (next state,reward,terminated) outcomes",
            metric="exact-model v at S7 of frozen greedy policy; model not supplied to training",
            tie_breaking="random among greedy ties for behavior; first ACT entry for frozen evaluation",
            bands="sample standard deviation across training seeds; not confidence intervals",
            caution="Different planning counts imply different compute budgets and closed-loop data; not a compute-matched ranking"),
        reference_check=dict(episodes=10000,seed=173,sample_mean=statistics.mean(sampled),standard_error=se),
        code="demos/td_control.py",world="demos/mud_world.py",
        provenance="Newly executed teaching demonstration, not a reproduction of a published benchmark.")
    (OUT/"hand-checks.json").write_text(json.dumps(checks,indent=2)+"\n")
    (OUT/"manifest.json").write_text(json.dumps(manifest,indent=2)+"\n")
    (OUT/"raw-runs.json").write_text(json.dumps(dict(prediction=prediction,control=control),indent=2)+"\n")
    print("All hand, frozen forward/backward, support/IS and exact-value checks passed.")
    print("Sampled v_pi(S7):",statistics.mean(sampled),"+/-",se,"(one standard error)")
    print("Final control mean v(S7):", {n:statistics.mean(run[-1]["greedy_v_s7"] for run in runs) for n,runs in control.items()})
    print("Output:",OUT)


if __name__=="__main__": main()
