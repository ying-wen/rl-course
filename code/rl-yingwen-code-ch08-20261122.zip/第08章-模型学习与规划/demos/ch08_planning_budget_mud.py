"""Dyna-Q on the mud world: planning budget B = 0, 5, 20 per real step.

11-21 审阅站请求 r1121-112759（第 8 章 p443）。本课重跑，替换旧页上的 10 次运行。
Run: python3 demos/ch08_planning_budget_mud.py 1000 out.json
Setting as td_control.control_run: start S7, alpha=.2, epsilon=.2 (random greedy
tie-break while acting), gamma=.9, 1500 real steps; count model; planning picks a
seen (s,a) uniformly and samples (s',r,done) by relative counts. Seeds 0..N-1 for
acting, seed+100000 for planning. The final greedy policy (ties by ACT order) is
evaluated exactly with the true kernel (mud_world.evaluate). Each run ends with one
of three values: dry .5905, mud 9/19=.474, or 0 (the greedy policy never reaches G).
"""
import sys,json,random,statistics
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
import td_control as T, mud_world as W
from collections import defaultdict,Counter
ACT=T.ACT; G=W.GAMMA
def run(seed,planning,steps=1500):
    rng,plan_rng=random.Random(seed),random.Random(seed+100000)
    q=defaultdict(float);counts=defaultdict(Counter);s="S7"
    def upd(s,a,r,nxt,done):
        tgt=r+G*(0 if done else max(q[nxt,b] for b in ACT)); q[s,a]+=.2*(tgt-q[s,a])
    for t in range(1,steps+1):
        a=T.choose(q,s,rng); nxt,r,done=T.sample(s,a,rng); upd(s,a,r,nxt,done); counts[s,a][nxt,r,done]+=1
        for _ in range(planning):
            u,c=plan_rng.choice(list(counts)); ch=counts[u,c]
            (v,rw,te),=plan_rng.choices(list(ch),weights=list(ch.values()),k=1); upd(u,c,rw,v,te)
        s="S7" if done else nxt
    pol={st:T.greedy(q,st) for st in W.STATES}
    val=W.evaluate(pol)["S7"]
    # diagnose path from S7 under greedy
    path=[];st="S7";seen=set()
    while st!="G" and st not in seen:
        seen.add(st);a=pol[st];path.append((st,a));
        outs=W.outcomes(st,a); nx=outs[-1][1]; st=nx if nx!=st else st
        if nx==path[-1][0]: break
    # tie info at loop state
    last=path[-1][0]; qs={a:round(q[last,a],4) for a in ACT}
    return dict(seed=seed,B=planning,v=val,pol=pol,path=path,qs_last=qs,
                q_S7={a:round(q['S7',a],4) for a in ACT},n_eps=None)
N=int(sys.argv[1]) if len(sys.argv)>1 else 200
out={}
for B in [0,5,20]:
    out[B]=[run(s,B) for s in range(N)]
json.dump({str(k):v for k,v in out.items()},open(sys.argv[2],'w'))
for B,rs in out.items():
    vs=[r['v'] for r in rs]
    dry=sum(abs(v-G**5)<1e-6 for v in vs); mud=sum(abs(v-9/19)<1e-6 for v in vs); zero=sum(v<1e-9 for v in vs)
    oth=N-dry-mud-zero
    print(B,'mean %.3f sd %.3f'%(statistics.mean(vs),statistics.stdev(vs)),'dry',dry,'mud',mud,'zero',zero,'other',oth, sorted(set(round(v,4) for v in vs)))
