"""Small exact checks for chapters 2--8; standard library, no training.

Run from any directory: python3 /path/to/demos/classic_foundations.py
Uses the unchanged mud_world.py for the environment definition only.
The matrix solver and backups below independently calculate its values.
"""
from __future__ import annotations
import json
import math
import random
from pathlib import Path
import mud_world as env


def solve(a, b):
    a = [list(row) + [rhs] for row, rhs in zip(a, b)]
    n = len(a)
    for k in range(n):
        pivot = max(range(k, n), key=lambda i: abs(a[i][k]))
        a[k], a[pivot] = a[pivot], a[k]
        assert abs(a[k][k]) > 1e-14
        scale = a[k][k]
        a[k] = [x / scale for x in a[k]]
        for i in range(n):
            if i != k:
                scale = a[i][k]
                a[i] = [x - scale*y for x, y in zip(a[i], a[k])]
    return [row[-1] for row in a]


def exact(policy):
    states = env.STATES
    index = {s: i for i, s in enumerate(states)}
    a = [[float(i == j) for j in range(len(states))] for i in range(len(states))]
    b = [0.0] * len(states)
    for s in states:
        i = index[s]
        for p, nxt, r, done in env.outcomes(s, policy[s]):
            b[i] += p*r
            if not done:
                a[i][index[nxt]] -= env.GAMMA*p
    return dict(zip(states, solve(a, b)))


def backup(v, s, a):
    return sum(p*(r + (0.0 if terminal else env.GAMMA*v[nxt]))
               for p, nxt, r, terminal in env.outcomes(s, a))


def main():
    checks = []
    def close(name, x, y, tol=1e-11):
        assert abs(x-y) <= tol, (name, x, y)
        checks.append(name)
    old, new = exact(env.OLD), exact(env.NEW)
    close('old S4 linear solve vs geometric series', old['S4'], 10/19)
    close('old S7', old['S7'], 9/19)
    close('new S7 six-transition discounted return', new['S7'], .9**5)
    for s in env.STATES:
        close('new greedy fixed point '+s, new[s], max(backup(new,s,a) for a in env.ACTIONS))
        assert new[s] >= old[s]-1e-12
    v = dict.fromkeys(env.STATES, 0.)
    snapshots = {}
    for k in range(1, 201):
        v = {s: backup(v,s,env.OLD[s]) for s in env.STATES}
        if k in [1,3,6]: snapshots[k] = v.copy()
    for s in env.STATES:
        close('synchronous vs matrix '+s, v[s], old[s])
    rng = random.Random(7)
    for _ in range(500):
        u = {s:rng.uniform(-2,2) for s in env.STATES}
        w = {s:rng.uniform(-2,2) for s in env.STATES}
        d = max(abs(u[s]-w[s]) for s in env.STATES)
        assert max(abs(backup(u,s,env.OLD[s])-backup(w,s,env.OLD[s])) for s in env.STATES) <= .9*d+1e-12
    checks.append('500 independent contraction inequalities')
    close('incremental sample mean', .75+(0-.75)/5, (1+1+0+1+0)/5)
    alpha=.2; xs=[0.]*20+[1.]*5; m=0.
    for x in xs: m += alpha*(x-m)
    close('exponential weights',m,sum(alpha*(1-alpha)**(len(xs)-1-i)*x for i,x in enumerate(xs)))
    rewards=[0.,0.,0.,1.]; states=['S7','S4','S4','S4','G']
    returns=[]; g=0.
    for r in reversed(rewards): g=r+.9*g;returns.append(g)
    returns.reverse()
    for i,expected in enumerate([.729,.81,.9,1.]):close('return '+str(i),returns[i],expected)
    close('first visit MC S4',returns[1],.81)
    close('every visit MC S4',(sum(returns[1:])/3),(.81+.9+1)/3)
    td={'S7':.4,'S4':.5,'G':0.}; online=[]
    for s,r,nxt in zip(states,rewards,states[1:]):
        target=r+.9*td[nxt];td[s]+=.2*(target-td[s]);online.append(td[s])
    for actual,expected in zip(online,[.41,.49,.4802,.58416]):close('online TD '+str(expected),actual,expected)
    frozen={'S7':.4,'S4':.5,'G':0.}
    targets=[sum(.9**k*rewards[k] for k in range(n))+(0 if n==4 else .9**n*frozen[states[n]]) for n in range(1,5)]
    for x,y in zip(targets,[.45,.405,.3645,.729]):close('n step target '+str(y),x,y)
    lam=.8; forward=dict.fromkeys(env.STATES,0.)
    for k,s in enumerate(states[:-1]):
        length=4-k
        ns=[sum(.9**j*rewards[k+j] for j in range(n))+(0 if n==length else .9**n*frozen[states[k+n]]) for n in range(1,length+1)]
        gl=sum((1-lam)*lam**(n-1)*ns[n-1] for n in range(1,length))+lam**(length-1)*ns[-1]
        forward[s] += gl-frozen[s]
    trace=dict.fromkeys(env.STATES,0.);backward=trace.copy()
    for s,r,nxt in zip(states,rewards,states[1:]):
        trace={x:.9*lam*z for x,z in trace.items()};trace[s]+=1
        delta=r+.9*frozen[nxt]-frozen[s]
        for x in trace: backward[x]+=delta*trace[x]
    for s in env.STATES:close('frozen forward backward '+s,forward[s],backward[s])
    close('lambda target',forward['S7']+.4,.574704)
    q=[.5,.1,.2,.7]; pi=[.05,.05,.05,.85]
    close('Sarsa target',.9*q[0],.45)
    close('Expected Sarsa target',.9*sum(p*x for p,x in zip(pi,q)),.5715)
    close('Q learning target',.9*max(q),.63)
    b=[.5,.5];target=[0.,1.];rs=[1.,2.]
    close('enumerated IS identity',sum(pb*(pt/pb)*r for pb,pt,r in zip(b,target,rs)),2.)
    close('8 step rare IS mean',(1/256)*256,1.)
    close('8 step rare IS variance',(1/256)*256**2-1,255.)
    mean=.9*.45+.1; var=.9*(.45-mean)**2+.1*(1-mean)**2
    close('model expectation and TD target mean',mean,.505)
    close('TD target variance',var,.027225)
    mcmean=.1/(1-.9**2); mcsecond=.1/(1-.9**3); mcvar=mcsecond-mcmean**2
    counts=[9,1]; model_probs=[x/sum(counts) for x in counts]
    close('empirical stochastic model expectation',sum(p*y for p,y in zip(model_probs,[.45,1.])),mean)
    close('lambda .5 exercise',.5*.45+.25*.405+.125*.3645+.125*.729,.4629375)
    close('updated model frequencies exercise',(9/11)*.45+2/11,.55)
    close('epsilon .4 Expected Sarsa',.9*(.1*(.5+.1+.2)+.7*.7),.513)
    ordinary=sum(p*g for p,g in zip([0.,2.],[1.,2.]))/2
    weighted=sum(p*g for p,g in zip([0.,2.],[1.,2.]))/2
    close('ordinary IS exercise',ordinary,2.)
    close('weighted IS exercise',weighted,2.)
    current=0.; mass=0.
    for ratio,g in [(2.,1.),(.5,3.),(0.,2.),(1.,4.)]:
        if ratio:
            mass+=ratio;current+=ratio/mass*(g-current)
    close('incremental weighted mean vs direct',(2*1+.5*3+1*4)/3.5,current)
    eps=.2; true_q=[.5,.1,.2,.7]
    old_pi=[.25]*4; new_pi=[eps/4]*4;new_pi[3]+=1-eps
    assert sum(p*q for p,q in zip(new_pi,true_q)) >= sum(p*q for p,q in zip(old_pi,true_q))
    checks.append('epsilon-soft policy improvement arithmetic')
    result={'scope':'Exact calculations and finite numerical checks; no control training.',
            'environment':'unchanged demos/mud_world.py; gamma .9, terminal entry reward 1',
            'checks_passed':len(checks),'checks':checks,'old_values':old,'new_values':new,
            'synchronous_snapshots':snapshots,'returns':returns,'online_td':online,
            'n_step_targets':targets,'lambda_forward':forward,'lambda_backward':backward,
            'TD_target_mean':mean,'TD_target_variance':var,'MC_mean':mcmean,'MC_variance':mcvar}
    path=Path(__file__).with_name('classic-foundations-results.json')
    path.write_text(json.dumps(result,ensure_ascii=False,indent=2))
    print(json.dumps({'checks_passed':len(checks),'MC_variance':mcvar,'results':str(path)},ensure_ascii=False))

if __name__=='__main__':main()
