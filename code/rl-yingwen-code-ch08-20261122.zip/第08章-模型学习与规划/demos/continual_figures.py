#!/usr/bin/env python3
"""Render original figures from formulas and multiscale CSV; requires matplotlib."""
from pathlib import Path
import csv
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from plot_fonts import chinese_font
from matplotlib.patches import Rectangle, FancyArrowPatch
ROOT=Path(__file__).resolve().parents[1]; OUT=ROOT/'assets/continual';OUT.mkdir(exist_ok=True)
FONT=chinese_font()
plt.rcParams.update({'font.family':FONT.get_name(),'axes.unicode_minus':False,'font.size':11,'svg.fonttype':'path','axes.spines.top':False,'axes.spines.right':False})
T,R,G='#087E8B','#C65335','#C4942A'
def save(fig,name):
 fig.savefig(OUT/(name+'.svg'),bbox_inches='tight');fig.savefig(OUT/(name+'.png'),dpi=150,bbox_inches='tight');plt.close(fig)
def read(name):
 with (ROOT/'demos/multiscale-results'/name).open() as f:return [{k:float(v) for k,v in x.items()} for x in csv.DictReader(f)]
fig,axs=plt.subplots(2,2,figsize=(11,6.8),layout='constrained')
for j,case in enumerate(['linear','omitted_intercept']):
 for i,n in enumerate([32,256]):
  ax=axs[i,j];d=read(f'{case}-{n}.csv');x=[r['k'] for r in d]
  for key,c,label in [('recursive',T,'递归一步'),('direct',R,'直接多步')]:
   y=[r[key] for r in d];se=[r[key+'_se'] for r in d];ax.plot(x,y,color=c,label=label,lw=2)
   ax.fill_between(x,[a-1.96*b for a,b in zip(y,se)],[a+1.96*b for a,b in zip(y,se)],color=c,alpha=.16)
  ax.set(title=('正确线性类' if case=='linear' else '两种模型都遗漏截距')+f'，N={n}',xlabel='预测步数 k',ylabel='条件均值 MSE');ax.grid(alpha=.18)
  if i==j==0:ax.legend(frameon=False)
fig.suptitle('同一批观测轨迹；300个独立训练集的均值与 ±1.96 标准误',fontsize=15)
save(fig,'multiscale-results')
fig,ax=plt.subplots(figsize=(8.5,4),layout='constrained');d=read('counterexample.csv');x=[r['k'] for r in d]
ax.plot(x,[r['contractive'] for r in d],'-o',color=T,label=r'实际误差 $|0.5^k-0.4^k|$',ms=4)
ax.plot(x,[r['bound_contract'] for r in d],'--',color=R,label='一致误差传播上界',lw=2)
ax.set(xlabel='递推步数 k',ylabel='状态绝对误差',title='两条轨迹都收缩到0：实际误差可以下降');ax.legend(frameon=False);ax.grid(alpha=.2)
save(fig,'contractive-counterexample')
fig,ax=plt.subplots(figsize=(8.5,4),layout='constrained')
for initial,color in [(0,T),(1,G),(2,R)]:
 rewards=[1 if (initial+t)%3==2 else 0 for t in range(18)]
 cum=[0]
 for r in rewards:cum.append(cum[-1]+r)
 ax.step(range(19),cum,where='post',color=color,label='起点 '+['A','B','C'][initial],lw=2)
ax.plot(range(19),[t/3 for t in range(19)],'--',color='#61757D',label='共同长期增长 T/3')
ax.set(xlabel='原子时间 T',ylabel='累计奖励',title='相同长期斜率，仍有起点的有限差异');ax.legend(frameon=False,ncol=2);ax.grid(alpha=.18)
save(fig,'average-rate-bias')
fig,ax=plt.subplots(figsize=(10,3.2),layout='constrained');ax.set(xlim=(-.6,12.5),ylim=(-.6,2.7));ax.set_yticks([.5,1.7],['B：每3步奖3','A：每1步奖2']);ax.set_xlabel('同一条原子时间轴')
for y,period,amount,c in [(1.7,1,2,T),(.5,3,3,R)]:
 for start in range(0,12,period):
  ax.add_patch(Rectangle((start,y-.25),period-.06,.5,facecolor=c,alpha=.18,edgecolor=c))
  ax.plot(start+period,y,'o',color=c,ms=5+amount);ax.text(start+period,y+.34,'+'+str(amount),color=c,ha='center',fontsize=9)
ax.set_xticks(range(13));ax.grid(axis='x',alpha=.15);ax.spines['left'].set_visible(False)
ax.set_title('12个原子时间单位：A得24，B得12；一次调用并非同一时长')
save(fig,'option-duration')
fig,ax=plt.subplots(figsize=(10,3.8),layout='constrained');ax.axis('off');ax.set(xlim=(0,10),ylim=(0,3))
for y,last,nextv,c in [(2.3,'… 1','1',T),(.7,'… 2','2',R)]:
 ax.text(.1,y,last,color=c,fontsize=20,ha='left',va='center')
 ax.annotate('',xy=(3.1,y),xytext=(1,y),arrowprops={'arrowstyle':'->','color':c,'lw':2})
 ax.text(3.8,y,'相同的一步预测\nP(1)=P(2)=P(3)=1/3',ha='center',va='center',fontsize=11)
 ax.annotate('',xy=(6.4,y),xytext=(4.8,y),arrowprops={'arrowstyle':'->','color':c,'lw':2})
 ax.text(6.5,y,'观察到 3',ha='left',va='center',fontsize=15)
 ax.annotate('',xy=(8.9,y),xytext=(7.8,y),arrowprops={'arrowstyle':'->','color':c,'lw':2})
 ax.text(9.2,y,nextv,color=c,fontsize=23,ha='center',va='center')
ax.text(5,1.5,'合并两条历史，就无法在见到3后正确更新',ha='center',va='center',fontsize=12)
ax.set_title('当前一步答案相同，未来递推仍需要区分过去',fontsize=15)
save(fig,'state-recursion')
print(OUT)
