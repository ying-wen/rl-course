"""Chapter 8: uniform sweeps versus on-policy trajectory sampling.

Standalone: python3 demos/ch08_trajectory_sampling.py --out demos/ch08-trajectory-sampling-results
Dependencies: numpy. Task family follows Sutton and Barto (2nd ed.), section 8.6:
n states, 2 actions per state, each action leads to one of b fixed successor
states (equally likely); every transition ends the episode with probability .1;
each of the b+1 outcomes of (s, a) has its own reward drawn from N(0, 1);
undiscounted; start state 0. Both methods apply expected updates
    Q(s,a) <- .1 r_T(s,a) + .9/b * sum_j [ r_j(s,a) + max_a' Q(s_j, a') ].
Uniform: cycle through all (s, a) pairs in a fixed order.
On-policy: simulate episodes from state 0 with epsilon-greedy (eps = .1) on the
current Q, update every pair encountered.
Metric: value of state 0 under the greedy policy of the current Q (exact
policy evaluation), averaged over tasks. Also records how often each (s, a)
was updated after the full budget.
"""
from __future__ import annotations
import argparse, json
from pathlib import Path
import numpy as np

TERM = .1


def make_task(rng, n, b):
    succ = rng.integers(0, n, size=(n, 2, b))
    rew = rng.normal(0, 1, size=(n, 2, b))
    rterm = rng.normal(0, 1, size=(n, 2))
    return succ, rew, rterm


def expected_update(Q, succ, rew, rterm, s, a, b):
    nxt = succ[s, a]
    return TERM * rterm[s, a] + (1 - TERM) / b * float(np.sum(rew[s, a] + Q[nxt].max(axis=1)))


def greedy_value(Q, succ, rew, rterm, b, iters=400):
    n = Q.shape[0]
    pi = Q.argmax(axis=1)
    idx = np.arange(n)
    S = succ[idx, pi]                      # n x b
    r = TERM * rterm[idx, pi] + (1 - TERM) * rew[idx, pi].mean(axis=1)
    v = np.zeros(n)
    for _ in range(iters):                 # contraction factor .9
        v = r + (1 - TERM) * v[S].mean(axis=1)
    return v[0]


def run_task(rng, n, b, budget, every, eps=.1):
    succ, rew, rterm = make_task(rng, n, b)
    out = {}
    for method in ("uniform", "onpolicy"):
        Q = np.zeros((n, 2))
        count = np.zeros((n, 2), dtype=np.int64)
        curve = [greedy_value(Q, succ, rew, rterm, b)]
        s = 0
        pairs = [(i, a) for i in range(n) for a in (0, 1)]
        for t in range(1, budget + 1):
            if method == "uniform":
                si, a = pairs[(t - 1) % len(pairs)]
            else:
                si = s
                a = int(rng.integers(2)) if rng.random() < eps else int(np.argmax(Q[si]) if Q[si, 0] != Q[si, 1] else rng.integers(2))
            Q[si, a] = expected_update(Q, succ, rew, rterm, si, a, b)
            count[si, a] += 1
            if method == "onpolicy":
                s = 0 if rng.random() < TERM else int(succ[si, a, rng.integers(b)])
            if t % every == 0:
                curve.append(greedy_value(Q, succ, rew, rterm, b))
        out[method] = (np.array(curve), np.sort(count.ravel())[::-1])
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="demos/ch08-trajectory-sampling-results")
    ap.add_argument("--tasks", type=int, default=200)
    ap.add_argument("--n", type=int, default=1000)
    ap.add_argument("--budget", type=int, default=20000)
    ap.add_argument("--every", type=int, default=250)
    args = ap.parse_args()
    rng = np.random.default_rng(20261118)
    res = {}
    for b in (1, 3):
        curves = {"uniform": [], "onpolicy": []}
        counts = {"uniform": [], "onpolicy": []}
        for _ in range(args.tasks):
            r = run_task(rng, args.n, b, args.budget, args.every)
            for m in curves:
                curves[m].append(r[m][0]); counts[m].append(r[m][1])
        res[f"b{b}"] = {
            m: {"curve": np.mean(curves[m], axis=0).round(4).tolist(),
                "curve_se": (np.std(curves[m], axis=0, ddof=1) / np.sqrt(args.tasks)).round(4).tolist(),
                "sorted_counts_mean": np.mean(counts[m], axis=0).round(2).tolist()}
            for m in curves}
    res["settings"] = vars(args)
    out = Path(args.out); out.mkdir(parents=True, exist_ok=True)
    (out / "results.json").write_text(json.dumps(res))
    for b in ("b1", "b3"):
        for m in ("uniform", "onpolicy"):
            c = res[b][m]["curve"]
            print(b, m, "curve", c[::2])
        oc = np.array(res[b]["onpolicy"]["sorted_counts_mean"])
        tot = oc.sum()
        print(b, "onpolicy share of updates on top 1%/10% pairs:",
              round(oc[:len(oc)//100].sum() / tot, 3), round(oc[:len(oc)//10].sum() / tot, 3),
              "pairs with <1 mean update:", int((oc < 1).sum()), "max", oc[0])


if __name__ == "__main__":
    main()
