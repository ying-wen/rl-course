"""Two route policies in the course mud maze. Only the S4 success rate is learned.

python demos/mud_planning.py --output results/mud-planning
Repeated trials can start at S4. Each training record is one real attempt.
A planning update averages the two outcomes of the frozen empirical model.
"""
import argparse
import csv
import json
from math import comb
from pathlib import Path
from random import Random
from statistics import mean, stdev

from mud_world import GAMMA, OLD, NEW, outcomes

TRUE_P = next(prob for prob, _, _, done in outcomes('S4', 'up') if done)
# The dry route and all transitions except S4-up are known to the planner.
DRY = GAMMA ** 5


def muddy_action_value(p, sweeps=None):
    """S7 enters S4 for zero reward; at S4 keep trying until G."""
    if sweeps is None:
        return GAMMA * p / (1 - GAMMA * (1-p))
    v = 0.0
    for _ in range(sweeps):
        v = p + (1-p) * GAMMA * v
    return GAMMA * v


def policy(p_est, sweeps):
    # An exact tie keeps the known detour.
    return 'mud' if muddy_action_value(p_est, sweeps) > DRY else 'dry'


def deploy(route, rng):
    """Evaluate in the original maze with fresh transitions, until arrival."""
    rules = OLD if route == 'mud' else NEW
    s, weight = 'S7', 1.0
    while True:
        choices = outcomes(s,rules[s])
        u, mass = rng.random(), 0.
        for chance, nxt, reward, done in choices:
            mass += chance
            if u < mass:
                break
        if done:
            return weight * reward
        s, weight = nxt, weight * GAMMA


def fresh_trials(n, rng):
    return [int(rng.random() < TRUE_P) for _ in range(n)]


def eleventh_attempt(trials):
    """One direct update, then one planning update conditional on the same pair."""
    # At S4 the current up value is .4; an alternative action has value .5.
    # A terminal outcome (reward 1) has no bootstrap term.
    alpha, best_other, q = .2, .5, .4

    def update(old, success):
        target = 1.0 if success else GAMMA * max(old, best_other)
        return old + alpha * (target - old)

    real = update(q, trials[10])
    model_p = sum(trials[:11]) / 11
    stay, reach_goal = update(real, False), update(real, True)
    mean_after_planning = (1 - model_p) * stay + model_p * reach_goal
    return real, model_p, stay, reach_goal, mean_after_planning


def selection_distribution(true_p, n, sweeps):
    """Exact binomial average over every possible set of n real trials."""
    choose_mud = sum(comb(n,j) * true_p**j * (1-true_p)**(n-j)
                     for j in range(n+1) if policy(j/n, sweeps)=='mud')
    route_value = muddy_action_value(true_p)
    expected = choose_mud * route_value + (1-choose_mud)*DRY
    return choose_mud, expected, max(route_value, DRY)-expected


def results():
    trials = fresh_trials(80, Random(2))
    path = []
    for n in (10,16,40,80):
        success = sum(trials[:n])
        for k in range(33):
            model_q = muddy_action_value(success/n, k)
            selected = policy(success/n,k)
            path.append(dict(n=n, success=success, k=k, model_mud=model_q,
                             route=selected, return_true=muddy_action_value(TRUE_P) if selected=='mud' else DRY))
    population = []
    for true_p in (.10,.25):
        for n in (5,10,16,25,50,100,200):
            for k in (1,4,8,16,None):
                prob, expected, regret = selection_distribution(true_p,n,k)
                population.append(dict(true_p=true_p,n=n,k=('exact' if k is None else k),
                                       choose_mud=prob,expected_return=expected,regret=regret))
    return trials, path, population


def figure(rows, out):
    # 11-21 审阅站请求 r1121-112759：改用课件字体（plot_fonts.use_course_fonts），
    # 图幅缩到 4.1x2.55 英寸，使课件上 4.08cm 高时刻度约 7.5pt、标签约 8pt。
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from matplotlib.ticker import FuncFormatter
    from plot_fonts import use_course_fonts, no_leading_zero, CJK_FAMILY
    use_course_fonts()
    plt.rcParams.update({'font.size':11,'axes.spines.top':False,'axes.spines.right':False,
                         'svg.hashsalt':'mud-planning'})
    fig, (value, ret) = plt.subplots(2,1,figsize=(4.1,2.55),sharex=True,layout='constrained',
                                     gridspec_kw={'height_ratios':[1.55,1]})
    for n, color in ((10,'#aa492c'),(16,'#0c746e')):
        run=[r for r in rows if r['n']==n and r['k']<=18]
        k=[r['k'] for r in run]
        value.plot(k,[r['model_mud'] for r in run],color=color,lw=2,label=f"{run[0]['success']} / {n} 次成功")
        ret.step(k,[r['return_true'] for r in run],where='post',color=color,lw=2)
    value.axhline(DRY,ls=':',color='#414b54',lw=1.3)
    value.text(.3, DRY+.03,'干路 .590',fontsize=11)
    value.set_ylabel('模型内\n泥路估值',fontsize=11)
    value.set_ylim(-.04,.73)
    value.set_yticks((0,.2,.4,.6))
    value.yaxis.set_major_formatter(FuncFormatter(no_leading_zero))
    value.legend(loc='lower right',fontsize=10.5,frameon=False,handlelength=1.4)
    for ax in (value,ret):
        ax.axvline(8,ls='--',color='#666',lw=.9);ax.grid(axis='y',alpha=.12)
    ret.set(ylim=(.45,.62),yticks=(.474,.5905),yticklabels=('.474','.590'),xticks=(0,4,8,12,16))
    ret.set_xlabel('固定模型中的期望更新次数 $k$',fontfamily=CJK_FAMILY,fontsize=11)
    ret.set_ylabel('部署后\n真实回报',fontsize=11)
    fig.savefig(out/'planning.pdf',metadata={'CreationDate':None,'ModDate':None})
    fig.savefig(out/'planning.svg',metadata={'Date':None})
    plt.close(fig)


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path)
    parser.add_argument('--dyna-step', action='store_true', help='Trace the 11th real trial and one model query.')
    args=parser.parse_args()
    if args.dyna_step:
        real, model_p, stay, goal, expectation = eleventh_attempt(fresh_trials(11, Random(2)))
        print(f'Q after real observation: {real:.3f}; model success probability: {model_p:.6f}')
        print(f'Q after one model query: stay {stay:.3f}, reach goal {goal:.3f}, mean {expectation:.3f}')
        raise SystemExit(0)
    trials,path,population=results()
    print('First 16 observed S4 outcomes (1 reaches G):', ''.join(map(str,trials[:16])))
    for n,k in ((10,7),(10,8),(16,8)):
        print(next(row for row in path if row['n']==n and row['k']==k))
    for route in ('mud','dry'):
        rng=Random(27)
        returns=[deploy(route,rng) for _ in range(20000)]
        print(f'{route}: deployment mean={mean(returns):.6f}, SE={stdev(returns)/len(returns)**.5:.6f}')
    if args.output:
        out=args.output
        out.mkdir(parents=True,exist_ok=True)
        for name,rows in [('path',path),('population',population),
                          ('real-trials',[{'attempt':i,'success':y} for i,y in enumerate(trials,1)])]:
            with (out/(name+'.csv')).open('w',newline='') as f:
                writer=csv.DictWriter(f,fieldnames=rows[0].keys())
                writer.writeheader()
                writer.writerows(rows)
        display_rows = [row for row in population if row['n'] in (10, 100) and row['k']=='exact']
        (out/'reader.json').write_text(json.dumps({'trials':trials,'table':display_rows}, indent=2)+'\n')
        figure(path,out)
