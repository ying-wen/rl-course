"""CPU teaching lab: actual neural PPO and SAC on a 12-step position regulator.

From any directory:
  python /absolute/path/ppo_sac_v11_lab.py --check
  python /absolute/path/ppo_sac_v11_lab.py --train --seeds 0 1 2
  python /absolute/path/ppo_sac_v11_lab.py --plot
Dependencies: Python 3.9+, numpy>=1.26, torch>=2.2, matplotlib. No Gym or GPU.
The environment's dynamics are used ONLY by stepping/evaluation, never as labels.
Outputs default to ../assets/ppo-sac-v11 relative to this file. Training and
evaluation use separate RNG streams; checkpoints contain learned network weights.
"""
from __future__ import annotations
import argparse
import copy
import json
import math
from pathlib import Path
import time
import numpy as np
import torch
from torch import nn
from torch.distributions import Categorical, Normal

H, GAMMA = 12, .97
ROOT = Path(__file__).resolve().parents[1]
DEFAULT_OUT = ROOT / "assets" / "ppo-sac-v11"
torch.set_num_threads(1)


def tensor(x):
    return torch.as_tensor(x, dtype=torch.float32)


def net(inp, out):
    return nn.Sequential(nn.Linear(inp, 32), nn.Tanh(), nn.Linear(32, 32),
                         nn.Tanh(), nn.Linear(32, out))


def observation(x, remaining):
    return np.column_stack([x, np.full_like(x, remaining / H)]).astype(np.float32)


def step(x, a):
    """a is the normalized executed action; .25 is dynamics, not density scaling."""
    nx = np.clip(x + .25 * a, -1.5, 1.5)
    return nx, -(nx ** 2 + .03 * a ** 2)


class PPO(nn.Module):
    def __init__(self):
        super().__init__()
        self.actor, self.critic = net(2, 3), net(2, 1)

    def dist(self, s):
        return Categorical(logits=self.actor(s))


class SAC(nn.Module):
    def __init__(self):
        super().__init__()
        self.actor, self.q1, self.q2 = net(2, 2), net(3, 1), net(3, 1)

    def sample(self, s):
        mu, log_std = self.actor(s).chunk(2, -1)
        log_std = log_std.clamp(-5, 1)
        dist = Normal(mu, log_std.exp())
        u = dist.rsample()  # u=mu+std*epsilon, retaining the action derivative
        a = u.tanh()
        # Stable log(1-tanh(u)^2), without an epsilon-induced density change.
        log_jac = 2 * (math.log(2) - u - nn.functional.softplus(-2 * u))
        logp = (dist.log_prob(u) - log_jac).sum(-1)
        return a, logp

    def minimum_q(self, s, a):
        sa = torch.cat([s, a], -1)
        return torch.minimum(self.q1(sa), self.q2(sa)).squeeze(-1)


def gae(reward, value, next_value, bootstrap, continuation, lam=.95):
    """Arrays [time, parallel episode]. Two masks have distinct meanings."""
    delta = reward + GAMMA * bootstrap * next_value - value
    adv = np.zeros_like(delta)
    tail = np.zeros(delta.shape[1])
    for t in reversed(range(len(delta))):
        tail = delta[t] + GAMMA * lam * continuation[t] * tail
        adv[t] = tail
    return adv, adv + value


@torch.no_grad()
def evaluate(model, kind, seed=9000, starts=None, repeats=128, alpha=0.):
    """Frozen stochastic policy; outputs external and soft discounted returns."""
    with torch.random.fork_rng():
        torch.manual_seed(seed)
        rng = np.random.default_rng(seed)
        x = rng.uniform(-1, 1, repeats) if starts is None else np.repeat(starts, repeats)
        returns, soft = np.zeros(len(x)), np.zeros(len(x))
        positions, actions = [x.copy()], []
        for t in range(H):
            s = tensor(observation(x, H-t))
            if kind == "ppo":
                d = model.dist(s)
                idx = d.sample()
                a, logp = idx.numpy()-1., d.log_prob(idx).numpy()
            elif kind == "sac":
                aa, lp = model.sample(s)
                a, logp = aa[:, 0].numpy(), lp.numpy()
            else:
                if kind == "random_discrete":
                    a = rng.choice([-1., 0., 1.], len(x))
                elif kind == "random_continuous":
                    a = rng.uniform(-1, 1, len(x))
                elif kind == "feedback_discrete":
                    a = np.round(np.clip(-x/.25, -1, 1))
                elif kind == "feedback_continuous":
                    a = np.clip(-x/.25, -1, 1)
                else:
                    a = np.zeros(len(x))
                logp = np.zeros(len(x))
            x, r = step(x, a)
            returns += GAMMA**t*r
            soft += GAMMA**t*(r-alpha*logp)
            positions.append(x.copy()); actions.append(a.copy())
        return {"return": returns, "soft_return": soft,
                "x": np.asarray(positions), "a": np.asarray(actions)}


def train_ppo(seed, updates, out, audit=None):
    torch.manual_seed(seed)
    rng = np.random.default_rng(seed)
    m = PPO()
    actor_opt = torch.optim.Adam(m.actor.parameters(), lr=.001)
    value_opt = torch.optim.Adam(m.critic.parameters(), lr=.003)
    n = 32
    curves = [[0, evaluate(m, "ppo")["return"].mean(), 0, 0]]
    for it in range(1, updates+1):
        x = rng.uniform(-1, 1, n)
        starts = x.copy() if audit is not None else None
        states, acts, rewards, old_logp, values, old_probs = [], [], [], [], [], []
        # Behavior parameters do not change during the entire rollout.
        with torch.no_grad():
            for t in range(H):
                s = tensor(observation(x, H-t)); dist = m.dist(s); a = dist.sample()
                states.append(s); acts.append(a); old_logp.append(dist.log_prob(a))
                old_probs.append(dist.probs); values.append(m.critic(s).squeeze(-1).numpy())
                x, r = step(x, a.numpy()-1.); rewards.append(r)
        value, reward = np.asarray(values), np.asarray(rewards)
        nv = np.vstack([value[1:], np.zeros((1, n))])
        mask = np.ones_like(reward); mask[-1] = 0  # true H-step termination
        adv, ret = gae(reward, value, nv, mask, mask)
        s, a = torch.cat(states), torch.cat(acts)
        logp_old, probs_old = torch.cat(old_logp), torch.cat(old_probs)
        advantage, target = tensor(adv.ravel()), tensor(ret.ravel())
        weights = tensor(np.repeat(GAMMA**np.arange(H), n))
        # The optional observer reads the frozen batch without sampling actions.
        trace = None
        if audit is not None:
            trace = audit(it, m, starts, s, a, probs_old, logp_old, advantage, weights)
            if trace is not None:
                trace(0, m, False)
        allow_actor, kl = True, 0.
        for epoch in range(8):
            actor_updated = allow_actor
            for ix in rng.permutation(H*n).reshape(-1, 96):
                dist = m.dist(s[ix])
                ratio = (dist.log_prob(a[ix])-logp_old[ix]).exp()
                clipped = torch.minimum(ratio*advantage[ix],
                                         ratio.clamp(.8, 1.2)*advantage[ix])
                # H*transition mean = episode mean of gamma^t weighted sums.
                loss_pi = -H*(weights[ix]*clipped).mean()
                if allow_actor:
                    actor_opt.zero_grad(); loss_pi.backward()
                    nn.utils.clip_grad_norm_(m.actor.parameters(), .5); actor_opt.step()
                loss_v = .5*(m.critic(s[ix]).squeeze(-1)-target[ix]).square().mean()
                value_opt.zero_grad(); loss_v.backward(); value_opt.step()
            with torch.no_grad():
                new_log = m.dist(s).logits
                kl = (probs_old*(probs_old.log()-new_log)).sum(-1).mean().item()
                allow_actor = allow_actor and kl < .03
                if trace is not None:
                    trace(epoch+1, m, actor_updated)
        if it % 5 == 0 or it == updates:
            score = evaluate(m, "ppo")["return"].mean()
            with torch.no_grad():
                final_logp = new_log.gather(1, a[:, None]).squeeze(1)
                final_ratio = (final_logp - logp_old).exp()
                outside = ((final_ratio < .8) | (final_ratio > 1.2)).float().mean().item()
            curves.append([it*H*n, score, kl, outside])
    torch.save(m.state_dict(), out/f"ppo-seed-{seed}.pt")
    return np.asarray(curves), m


def train_sac(seed, steps, out, fixed_alpha=None):
    torch.manual_seed(seed)
    rng = np.random.default_rng(seed)
    m = SAC(); target = copy.deepcopy(m)
    for p in target.parameters(): p.requires_grad_(False)
    qparams = list(m.q1.parameters()) + list(m.q2.parameters())
    oq = torch.optim.Adam(qparams, lr=.001)
    op = torch.optim.Adam(m.actor.parameters(), lr=.001)
    log_alpha = torch.tensor(math.log(.1), requires_grad=True)
    oa = torch.optim.Adam([log_alpha], lr=.001)
    target_entropy = -.7  # differential entropy in normalized action coordinate
    capacity = 10000
    replay = np.zeros((capacity, 7), np.float32) # s(2),a,r,s'(2),m
    alpha = .1 if fixed_alpha is None else fixed_alpha
    curves = [[0, evaluate(m, "sac")["return"].mean(), alpha, 0.]]
    x, t, updates = float(rng.uniform(-1, 1)), 0, 0
    for k in range(1, steps+1):
        s = observation(np.array([x]), H-t)
        with torch.no_grad():
            a = rng.uniform(-1, 1) if k <= 500 else m.sample(tensor(s))[0].item()
        nx, r = step(x, a); ns = observation(np.array([nx]), H-t-1)
        mask = float(t+1 < H)
        replay[(k-1)%capacity] = [*s[0], a, r, *ns[0], mask]
        x, t = (nx, t+1) if mask else (float(rng.uniform(-1, 1)), 0)
        if k >= 500:
            batch = tensor(replay[rng.integers(0, min(k, capacity), size=128)])
            bs, ba, br, bn, bm = batch[:, :2], batch[:, 2:3], batch[:, 3], batch[:, 4:6], batch[:, 6]
            alpha_t = tensor(fixed_alpha) if fixed_alpha is not None else log_alpha.exp().detach()
            # Current actor provides next action. Entire target is fixed for Q regression.
            with torch.no_grad():
                next_a, next_lp = m.sample(bn)
                y = br + GAMMA*bm*(target.minimum_q(bn, next_a)-alpha_t*next_lp)
            sa = torch.cat([bs, ba], -1)
            qloss = .5*((m.q1(sa).squeeze()-y).square().mean() +
                        (m.q2(sa).squeeze()-y).square().mean())
            oq.zero_grad(); qloss.backward(); oq.step()
            # Freeze Q weights, but DO NOT wrap Q(s,a_theta) in no_grad.
            for p in qparams: p.requires_grad_(False)
            new_a, logp = m.sample(bs)
            policy_loss = (alpha_t*logp-m.minimum_q(bs, new_a)).mean()
            op.zero_grad(); policy_loss.backward(); op.step()
            for p in qparams: p.requires_grad_(True)
            if fixed_alpha is None:
                # Exact chain derivative of dual loss under alpha=exp(log_alpha).
                alpha_loss = -(log_alpha.exp()*(logp.detach()+target_entropy)).mean()
                oa.zero_grad(); alpha_loss.backward(); oa.step()
            with torch.no_grad():
                for q, tq in zip(list(m.q1.parameters())+list(m.q2.parameters()),
                                 list(target.q1.parameters())+list(target.q2.parameters())):
                    tq.mul_(.99).add_(q, alpha=.01)
            updates += 1
        if k % 500 == 0 or k == steps:
            alpha = fixed_alpha if fixed_alpha is not None else log_alpha.exp().item()
            score = evaluate(m, "sac")["return"].mean()
            curves.append([k, score, alpha, updates])
    torch.save({"model": m.state_dict(), "alpha": alpha}, out/f"sac-seed-{seed}.pt")
    return np.asarray(curves), m, alpha


def checks():
    """Independent numerical references: finite differences/quadrature/expansion."""
    results = {}
    # GAE recursive implementation versus directly enumerated TD sum.
    r = np.array([[1.], [2.], [3.]]); v = np.array([[.2], [.5], [.7]])
    nv = np.array([[.5], [.7], [4.]])
    boot = np.ones_like(r); cont = np.ones_like(r); cont[-1] = 0
    a, _ = gae(r, v, nv, boot, cont, .6)
    d = r+GAMMA*nv-v
    direct = np.array([sum((GAMMA*.6)**j*d[t+j, 0] for j in range(3-t)) for t in range(3)])
    assert np.max(np.abs(a[:, 0]-direct)) < 1e-12
    terminal = boot.copy(); terminal[-1] = 0
    at, _ = gae(r, v, nv, terminal, cont, 1.)
    assert abs(at[0, 0] - (1+GAMMA*2+GAMMA**2*3-.2)) < 1e-12
    results["GAE_direct_sum_and_terminal_vs_truncation"] = True
    # An external reset may bootstrap from the final observation, never from
    # the reset observation or the next episode's advantage.
    rr=np.array([[1.], [100.]]);vv=np.zeros_like(rr);nnv=np.array([[4.], [0.]])
    cut,_=gae(rr,vv,nnv,np.array([[1.],[0.]]),np.zeros_like(rr),1.)
    assert abs(cut[0,0]-(1+GAMMA*4)) < 1e-12
    results["GAE_external_reset_does_not_leak_next_episode"] = True
    # Piecewise clipped objective derivative with respect to log ratio.
    for advantage in [-2., 2.]:
        for ratio in [.6, .95, 1.4]:
            z = torch.tensor(math.log(ratio), dtype=torch.float64, requires_grad=True)
            objective = torch.minimum(z.exp()*advantage, z.exp().clamp(.8,1.2)*advantage)
            objective.backward()
            f = lambda zz: min(math.exp(zz)*advantage, np.clip(math.exp(zz),.8,1.2)*advantage)
            fd = (f(z.item()+1e-6)-f(z.item()-1e-6))/2e-6
            assert abs(z.grad.item()-fd) < 1e-8
    results["PPO_piecewise_autograd_vs_finite_difference"] = True
    # Occupancy approximation in two-step problem: J=1+2pq.
    p, q, po, qo = .8, .8, .5, .25
    true_gain = 2*(p*q-po*qo)
    surrogate = 2*qo*(p-po)+2*po*(q-qo)
    assert abs((true_gain-surrogate)-2*(p-po)*(q-qo)) < 1e-12
    results["occupancy_true_gain_surrogate"] = [true_gain, surrogate]
    # Change-of-variables density integrates to one on a finite interval.
    a = np.linspace(-.9999999, .9999999, 200001); u = np.arctanh(a)
    density = np.exp(-u*u/2)/math.sqrt(2*math.pi)/(1-a*a)
    integral = np.sum((density[:-1]+density[1:])*.5*np.diff(a))
    assert abs(integral-1) < 2e-5
    results["squashed_normal_quadrature_mass"] = float(integral)
    # Reparameterized derivative independently checked with fixed quadrature noise.
    eps = torch.tensor([-.8, .1, 1.2], dtype=torch.float64)
    z = torch.tensor(.3, dtype=torch.float64, requires_grad=True)
    def objective(mu):
        u = mu+.6*eps; a = u.tanh()
        lp = -.5*eps.square()-math.log(.6)-.5*math.log(2*math.pi)-torch.log1p(-a.square())
        return (.2*lp+(a-.4).square()).mean()
    objective(z).backward()
    fd = (objective(.3+1e-6)-objective(.3-1e-6)).item()/2e-6
    assert abs(z.grad.item()-fd) < 1e-8
    results["SAC_pathwise_gradient_finite_difference"] = True
    # Scalar dual loss derivative: low entropy must increase temperature.
    for entropy in [-1.2, .2]:
        z = torch.tensor(math.log(.1), requires_grad=True)
        loss = z.exp()*(entropy-(-.7)); loss.backward()
        next_alpha = (z-.1*z.grad).exp().item()
        assert (next_alpha > .1) == (entropy < -.7)
    results["temperature_dual_sign"] = True
    results["all_passed"] = True
    return results


def plot(out, seeds):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    plt.rcParams.update({"font.size": 11, "axes.spines.top":False,"axes.spines.right":False})
    colors = {"ppo":"#087e8b", "sac":"#c65335"}
    summary = {"seeds": seeds, "gamma":GAMMA, "horizon":H, "evaluation":"frozen stochastic policies; 128 episodes; seed 9000"}
    summary["baselines"]={name:float(evaluate(None,name)["return"].mean()) for name in ["zero","random_discrete","random_continuous","feedback_discrete","feedback_continuous"]}
    fig, axes = plt.subplots(1, 2, figsize=(12.5, 3.6), layout="constrained")
    for ax, kind in zip(axes, ["ppo", "sac"]):
        curves = np.stack([np.load(out/f"{kind}-seed-{seed}-curve.npy") for seed in seeds])
        for row in curves: ax.plot(row[:,0], row[:,1], color=colors[kind], alpha=.25, lw=1)
        mean = curves[:,:,1].mean(0)
        ax.plot(curves[0,:,0], mean, color=colors[kind], lw=2.3, label=f"{kind.upper()}: seed mean")
        rand = "random_discrete" if kind=="ppo" else "random_continuous"
        feedback = "feedback_discrete" if kind=="ppo" else "feedback_continuous"
        for name, style, color in [(rand, ":", "#61757d"), ("zero", "--", "#999999"), (feedback,"-.","#c4942a")]:
            val = evaluate(None,name)["return"].mean()
            ax.axhline(val, ls=style, color=color, label=name.replace("_"," "))
        ax.set(xlabel="real environment transitions", ylabel="discounted external return", title=kind.upper()+" / separate action spaces")
        ax.legend(fontsize=8)
        summary[kind] = {"steps":int(curves[0,-1,0]), "initial_returns":curves[:,0,1].tolist(), "final_returns":curves[:,-1,1].tolist()}
        if kind=="ppo":summary[kind]["max_KL_at_recorded_evaluations"]=float(curves[:,:,2].max())
    fig.savefig(out/"learning.png",dpi=180); plt.close(fig)
    ppo=PPO(); ppo.load_state_dict(torch.load(out/f"ppo-seed-{seeds[0]}.pt",weights_only=True))
    sac=SAC(); ck=torch.load(out/f"sac-seed-{seeds[0]}.pt",weights_only=True); sac.load_state_dict(ck["model"]); alpha=ck["alpha"]
    grid=np.linspace(-1,1,41); s=tensor(observation(grid,H))
    pe=evaluate(ppo,"ppo",seed=9911,starts=grid,repeats=256)
    se=evaluate(sac,"sac",seed=9911,starts=grid,repeats=256,alpha=alpha)
    with torch.no_grad(), torch.random.fork_rng():
        torch.manual_seed(9912)
        probs=ppo.dist(s).probs.numpy(); pv=ppo.critic(s).squeeze().numpy()
        mu=sac.actor(s)[:,0].tanh().numpy()
        sr=s.repeat_interleave(1024,dim=0); aa, lp=sac.sample(sr)
        sv=(sac.minimum_q(sr,aa)-alpha*lp).reshape(len(grid),1024).mean(1).numpy()
    fig,axes=plt.subplots(2,2,figsize=(12,6.4),layout="constrained")
    for j,l in enumerate(["left (-1)","stay (0)","right (+1)"]): axes[0,0].plot(grid,probs[:,j],label=l)
    axes[0,0].set(title="PPO learned probabilities (12 steps left)",ylabel="probability"); axes[0,0].legend(fontsize=9)
    axes[0,1].plot(grid,mu,color=colors["sac"],label="tanh(mu): policy median")
    axes[0,1].set(title="SAC learned action median",ylabel="normalized action"); axes[0,1].legend(fontsize=9)
    axes[1,0].plot(grid,pv,label="learned V"); axes[1,0].plot(grid,pe["return"].reshape(len(grid),256).mean(1),"--",label="MC return of frozen policy")
    axes[1,0].set(title="PPO value versus independent rollouts",ylabel="external value"); axes[1,0].legend(fontsize=9)
    axes[1,1].plot(grid,sv,label="E[min Q - alpha log pi]"); axes[1,1].plot(grid,se["soft_return"].reshape(len(grid),256).mean(1),"--",label="MC soft return; final alpha frozen")
    axes[1,1].set(title=f"SAC soft value / final alpha={alpha:.3f}",ylabel="soft value"); axes[1,1].legend(fontsize=9)
    for ax in axes.ravel(): ax.set_xlabel("position x"); ax.axvline(0,color=".8",lw=.7)
    fig.savefig(out/"policy-value.png",dpi=180); plt.close(fig)
    for kind in ["ppo", "sac"]:
        fig, ax = plt.subplots(1,2,figsize=(12,3.5),layout="constrained")
        if kind == "ppo":
            for j,l in enumerate(["left (-1)","stay (0)","right (+1)"]): ax[0].plot(grid,probs[:,j],label=l)
            ax[0].set(title="Learned action probabilities",ylabel="probability")
            ax[1].plot(grid,pv,label="learned V")
            ax[1].plot(grid,pe["return"].reshape(len(grid),256).mean(1),"--",label="MC return of frozen policy")
            ax[1].set(title="Value: estimate and observed return",ylabel="external value")
        else:
            ax[0].plot(grid,mu,color=colors["sac"],label="tanh(mu): policy median")
            ax[0].set(title="Learned action median",ylabel="normalized action")
            ax[1].plot(grid,sv,label="E[min Q - alpha log pi]")
            ax[1].plot(grid,se["soft_return"].reshape(len(grid),256).mean(1),"--",label="MC soft return; final alpha frozen")
            ax[1].set(title=f"Soft value / alpha={alpha:.3f}",ylabel="soft value")
        for axis in ax:
            axis.set_xlabel("position x (12 steps left)");axis.legend(fontsize=9);axis.axvline(0,color=".8",lw=.7)
        fig.savefig(out/f"{kind}-policy-value.png",dpi=180);plt.close(fig)
    np.savez(out/"policy-value-data.npz",x=grid,ppo_probs=probs,ppo_v=pv,ppo_mc=pe["return"],sac_median=mu,sac_v=sv,sac_mc_soft=se["soft_return"],alpha=alpha)
    fig,axes=plt.subplots(1,2,figsize=(12,3.6),layout="constrained")
    for ax,model,kind in zip(axes,[ppo,sac],["ppo","sac"]):
        traj=evaluate(model,kind,seed=9201,starts=np.array([-.9,.9]),repeats=1)
        for j in range(2): ax.plot(np.arange(H+1),traj["x"][:,j],"o-",ms=4,label=f"start {traj['x'][0,j]:+.1f}")
        ax.axhline(0,color=".5",ls=":"); ax.set(xlabel="decision time",ylabel="position",title=kind.upper()+": two sampled learned trajectories",ylim=(-1.1,1.1));ax.legend(fontsize=9)
        np.savez(out/f"{kind}-trajectories.npz",**traj)
    fig.savefig(out/"task-trajectories.png",dpi=180);plt.close(fig)
    for kind,model in [("ppo",ppo),("sac",sac)]:
        fig,ax=plt.subplots(1,2,figsize=(12,3.5),layout="constrained")
        curves=np.stack([np.load(out/f"{kind}-seed-{seed}-curve.npy") for seed in seeds])
        for row in curves: ax[0].plot(row[:,0],row[:,1],color=colors[kind],alpha=.25,lw=1)
        ax[0].plot(curves[0,:,0],curves[:,:,1].mean(0),color=colors[kind],lw=2.3,label="three-seed mean")
        suffix="discrete" if kind=="ppo" else "continuous"
        for name,style,color in [("random_"+suffix,":","#61757d"),("zero","--","#999999"),("feedback_"+suffix,"-.","#c4942a")]:
            ax[0].axhline(evaluate(None,name)["return"].mean(),ls=style,color=color,label=name.replace("_"," "))
        ax[0].set(xlabel="real transitions",ylabel="discounted external return",title="Frozen stochastic policy evaluation");ax[0].legend(fontsize=8)
        tr=evaluate(model,kind,seed=9201,starts=np.array([-.9,.9]),repeats=1)
        for j in range(2): ax[1].plot(np.arange(H+1),tr["x"][:,j],"o-",ms=4,label=f"start {tr['x'][0,j]:+.1f}")
        ax[1].axhline(0,color=".5",ls=":");ax[1].set(xlabel="decision time",ylabel="position",title="Two sampled final-policy trajectories",ylim=(-1.1,1.1));ax[1].legend(fontsize=9)
        fig.savefig(out/f"{kind}-learning.png",dpi=180);plt.close(fig)
    fig,axes=plt.subplots(1,2,figsize=(12,3.4),layout="constrained")
    for seed in seeds:
        p=np.load(out/f"ppo-seed-{seed}-curve.npy");q=np.load(out/f"sac-seed-{seed}-curve.npy")
        axes[0].plot(p[1:,0],p[1:,2],label=f"seed {seed}");axes[1].plot(q[:,0],q[:,2],label=f"seed {seed}")
    axes[0].axhline(.03,ls="--",color=".5",label="stop further actor epochs")
    axes[0].set(title="PPO measured mean KL after epoch",ylabel="KL(old || current)",xlabel="real transitions");axes[0].legend(fontsize=8)
    axes[1].set(title="SAC learned temperature",ylabel="alpha",xlabel="real transitions");axes[1].legend(fontsize=8)
    fig.savefig(out/"diagnostics.png",dpi=180);plt.close(fig)
    summary["sac"]["final_alpha_seed0"]=alpha
    summary["ppo"]["value_slice_MC_RMSE_seed0"]=float(np.sqrt(np.mean((pv-pe["return"].reshape(len(grid),256).mean(1))**2)))
    summary["sac"]["soft_value_slice_MC_RMSE_seed0"]=float(np.sqrt(np.mean((sv-se["soft_return"].reshape(len(grid),256).mean(1))**2)))
    summary["boundaries"]="Three fixed-task seeds; different action spaces/budgets/objectives. No algorithm ranking or continual-learning claim."
    (out/"summary.json").write_text(json.dumps(summary,indent=2)+"\n")
    print(json.dumps(summary,indent=2))


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--check",action="store_true");ap.add_argument("--train",action="store_true");ap.add_argument("--plot",action="store_true")
    ap.add_argument("--seeds",nargs="+",type=int,default=[0,1,2]);ap.add_argument("--ppo-updates",type=int,default=100);ap.add_argument("--sac-steps",type=int,default=10000)
    ap.add_argument("--fixed-alpha",type=float,default=None);ap.add_argument("--out",type=Path,default=DEFAULT_OUT)
    args=ap.parse_args();args.out.mkdir(parents=True,exist_ok=True)
    if args.check:
        result=checks();(args.out/"math-checks.json").write_text(json.dumps(result,indent=2)+"\n");print(json.dumps(result))
    if args.train:
        start=time.time()
        for seed in args.seeds:
            p,_=train_ppo(seed,args.ppo_updates,args.out);np.save(args.out/f"ppo-seed-{seed}-curve.npy",p)
            print(f"PPO seed {seed}: {p[-1,1]:.4f}",flush=True)
            s,_,_=train_sac(seed,args.sac_steps,args.out,args.fixed_alpha);np.save(args.out/f"sac-seed-{seed}-curve.npy",s)
            print(f"SAC seed {seed}: {s[-1,1]:.4f}",flush=True)
        (args.out/"run-config.json").write_text(json.dumps({**vars(args),"out":str(args.out),"torch":torch.__version__,"numpy":np.__version__,"elapsed_seconds":time.time()-start,"threads":1,"device":"cpu","H":H,"gamma":GAMMA},indent=2)+"\n")
    if args.plot: plot(args.out,args.seeds)
    if not any([args.check,args.train,args.plot]): ap.print_help()


if __name__=="__main__": main()
