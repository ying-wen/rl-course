"""Chapter 8, p. "样本更新与期望更新": redraw of Sutton and Barto (2nd ed.)
Figure 8.7 with the course fonts and Chinese labels.

Setting of section 8.5: b equally likely successors, successor values exact,
initial error 1. An expected update costs b computations of max_a' Q(s', a')
and removes the error at once. After t sample updates with step 1/t
(a sample average) the RMS error is sqrt((b - 1) / (b t)).
The horizontal axis counts computations in units of b.

Run: python3 demos/ch08_sample_vs_expected.py
Writes assets/ch08-planning/sample-vs-expected.pdf
"""
from pathlib import Path
import sys

import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

sys.path.insert(0, str(Path(__file__).resolve().parent))
from plot_fonts import CJK_FAMILY, no_leading_zero, use_course_fonts

TEAL, RED, MUTED, INK = '#096B76', '#AA412D', '#52666E', '#182E38'
OUT = Path(__file__).resolve().parent.parent / 'assets' / 'ch08-planning' / 'sample-vs-expected.pdf'


def sample_curve(b, xmax=2.0):
    t = np.arange(1, int(round(xmax * b)) + 1)
    x = np.concatenate([[0.0], t / b])
    err = np.concatenate([[1.0], np.sqrt((b - 1) / (b * t))])
    return x, err


def main():
    use_course_fonts()
    fig, ax = plt.subplots(figsize=(3.3, 2.25))
    ax.plot([0, 1, 1, 2], [1, 1, 0, 0], color=INK, lw=1.4, label='期望更新')
    shades = {10: '#2F7F88', 100: '#4F959D', 1000: '#6FA8AE', 10000: '#8DBBC0'}
    for b, c in shades.items():
        x, e = sample_curve(b)
        ax.plot(x, e, color=c, lw=1.1)
        if b <= 100:
            k = np.searchsorted(x, .32)
            ax.text(.33, e[k] + .015, f'$b={b}$', color=c, fontsize=7.5, va='bottom')
    ax.annotate('$b=1000,\\ 10000$', xy=(1.15, .025), xytext=(1.2, .15),
                color=MUTED, fontsize=7.5, arrowprops=dict(arrowstyle='-', color=MUTED, lw=.6))
    x, e = sample_curve(2)
    ax.plot(x, e, color=RED, lw=1.5, marker='o', ms=2.6)
    ax.text(1.52, e[3] + .04, '泥地 $b=2$', color=RED, fontsize=8.5, fontfamily=CJK_FAMILY)
    ax.text(.03, 1.03, '期望更新', color=INK, fontsize=8.5, va='bottom')
    ax.set_xlim(0, 2.05)
    ax.set_ylim(0, 1.15)
    ax.set_xticks([0, .5, 1, 1.5, 2])
    ax.set_xticklabels(['0', '$b/2$', '$b$', '$3b/2$', '$2b$'])
    ax.set_yticks([0, .25, .5, .75, 1])
    ax.yaxis.set_major_formatter(plt.FuncFormatter(no_leading_zero))
    ax.set_xlabel('计算次数（以 $b$ 为单位）', fontsize=9, fontfamily=CJK_FAMILY)
    ax.set_ylabel('均方根误差', fontsize=9)
    ax.tick_params(labelsize=8, length=2.5)
    for side in ('top', 'right'):
        ax.spines[side].set_visible(False)
    fig.tight_layout(pad=.3)
    OUT.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(OUT)
    print('wrote', OUT)
    for b in (2, 10, 100, 1000, 10000):
        print(b, 'error at x=1 (t=b):', round(float(np.sqrt((b - 1) / (b * b))), 4))


if __name__ == '__main__':
    main()
