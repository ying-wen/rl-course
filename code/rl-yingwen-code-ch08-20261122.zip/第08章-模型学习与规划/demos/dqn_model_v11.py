#!/usr/bin/env python3
"""CPU learning experiments for chapters 10 and 12, not paper reproductions.

Run: python3 demos/dqn_model_v11.py [--test-only] [--output DIRECTORY]
Dependencies: numpy, matplotlib. All seeds, raw evaluations and weights saved.
The grid oracle is used ONLY by evaluation; DQN receives sampled transitions.
"""
from pathlib import Path
from collections import deque
import argparse, csv, hashlib, itertools, json, sys, time
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
GAMMA = .97
WALLS = {(2, 1), (2, 2), (2, 3)}
STATES = [(x, y) for y in range(5) for x in range(5) if (x, y) not in WALLS]
INDEX = {s: i for i, s in enumerate(STATES)}
GOAL = INDEX[(4, 4)]
STARTS = [i for i in range(len(STATES)) if i != GOAL]
DELTAS = [(0, 1), (1, 0), (0, -1), (-1, 0)]
FEATURES = np.eye(len(STATES))
U = np.array([-1., 0., 1.])
SEQUENCES = np.array(list(itertools.product(U, repeat=4)))

def csv_save(path, fields, rows):
    with path.open('w', newline='') as f:
        w = csv.writer(f); w.writerow(fields); w.writerows(rows)

def transition(s, a):
    if s == GOAL:
        return GOAL, 0., True
    x, y = STATES[s]; dx, dy = DELTAS[a]
    sp = INDEX.get((x + dx, y + dy), s)
    return sp, (1. if sp == GOAL else -.02), sp == GOAL

def oracle():
    q = np.zeros((len(STATES), 4))
    for _ in range(2000):
        nq = np.zeros_like(q)
        for s in STARTS:
            for a in range(4):
                sp, r, done = transition(s, a)
                nq[s, a] = r + GAMMA * (not done) * q[sp].max()
        if np.max(np.abs(nq-q)) < 1e-12:
            return nq
        q = nq
    raise AssertionError('Value iteration did not converge')

def evaluate(q, random_seed=None):
    """All 21 nonterminal starts. 64-step reported return has no invented tail."""
    rng = np.random.default_rng(random_seed)
    returns, successes = [], []
    for s0 in STARTS:
        s, ret, done = s0, 0., False
        for t in range(64):
            a = int(rng.integers(4)) if random_seed is not None else int(q[s].argmax())
            s, r, done = transition(s, a); ret += GAMMA**t*r
            if done: break
        returns.append(ret); successes.append(done)
    return float(np.mean(returns)), float(np.mean(successes))

class MLP:
    def __init__(self, rng):
        self.p = [rng.normal(0, .2, (len(STATES), 32)), np.zeros(32),
                  rng.normal(0, .1, (32, 4)), np.zeros(4)]
        self.m = [np.zeros_like(x) for x in self.p]
        self.v = [np.zeros_like(x) for x in self.p]
        self.k = 0

    def forward(self, x):
        h = np.tanh(x @ self.p[0] + self.p[1])
        return h @ self.p[2] + self.p[3]

    def loss_grad(self, x, actions, targets):
        h = np.tanh(x @ self.p[0] + self.p[1])
        q = h @ self.p[2] + self.p[3]
        err = q[np.arange(len(x)), actions] - targets
        dq = np.zeros_like(q); dq[np.arange(len(x)), actions] = err/len(x)
        dh = (dq @ self.p[2].T)*(1-h*h)
        return float(np.mean(err*err)/2), [x.T @ dh, dh.sum(0), h.T @ dq, dq.sum(0)]

    def update(self, x, actions, targets, lr=.001):
        loss, grads = self.loss_grad(x, actions, targets)
        self.k += 1
        for p, m, v, g in zip(self.p, self.m, self.v, grads):
            m *= .9; m += .1*g; v *= .999; v += .001*g*g
            p -= lr*(m/(1-.9**self.k))/(np.sqrt(v/(1-.999**self.k))+1e-8)
        return loss

def run_grid(out, qstar, steps=10000):
    rows, weights, snapshots = [], {}, {}
    checkpoints = set(range(0, steps+1, 250))
    for seed in range(5):
        for method in ['DQN', 'tabular']:
            rng = np.random.default_rng(seed)
            net, target = MLP(rng), MLP(rng)
            target.p = [p.copy() for p in net.p]
            q = np.zeros_like(qstar) if method == 'tabular' else net.forward(FEATURES)
            # Columns: state, action, reward, next_state, true terminal flag.
            replay = np.zeros((2000, 5)); size = 0
            s = int(rng.choice(STARTS)); age = 0; updates = 0; copies = 0
            for t in range(steps+1):
                if t in checkpoints:
                    q = net.forward(FEATURES) if method == 'DQN' else q
                    ret, success = evaluate(q)
                    error = np.mean(np.abs(q[STARTS]-qstar[STARTS]))
                    opt = np.mean([qstar[s, q[s].argmax()] >= qstar[s].max()-1e-9 for s in STARTS])
                    rows.append([method, seed, t, ret, success, error, opt, updates, copies])
                    if seed == 0 and method == 'DQN' and t in [0, 1000, 3000, steps]:
                        snapshots[t] = q.copy()
                if t == steps: break
                eps = 1 - .9*min(t/6000, 1)
                qs = net.forward(FEATURES[s:s+1])[0] if method == 'DQN' else q[s]
                a = int(rng.integers(4)) if rng.random() < eps else int(qs.argmax())
                sp, r, done = transition(s, a)
                if method == 'DQN':
                    replay[t % len(replay)] = s, a, r, sp, done
                    size = min(size+1, len(replay))
                    if size >= 128:
                        batch = replay[rng.integers(size, size=32)]
                        si, ai, ri, spi, terminal = batch.T
                        y = ri + GAMMA*(1-terminal)*target.forward(FEATURES[spi.astype(int)]).max(1)
                        net.update(FEATURES[si.astype(int)], ai.astype(int), y)
                        updates += 1
                        if updates % 100 == 0:
                            target.p = [p.copy() for p in net.p]; copies += 1
                else:
                    y = r + GAMMA*(not done)*q[sp].max()
                    q[s, a] += .2*(y-q[s, a]); updates += 1
                s, age = sp, age+1
                if done or age == 64:
                    # External collection cutoff: transition still bootstraps.
                    s, age = int(rng.choice(STARTS)), 0
            if method == 'DQN':
                weights.update({f'seed{seed}_p{i}': p for i, p in enumerate(net.p)})
    csv_save(out/'grid-evaluations.csv', ['method','seed','env_steps','discounted_return','success','q_mae','optimal_action_fraction','updates','target_copies'], rows)
    csv_save(out/'grid-q-map.csv', ['checkpoint','x','y','up','right','down','left','value','action'],
             [[t,*STATES[s],*q[s],q[s].max(),q[s].argmax()] for t,q in snapshots.items() for s in STARTS])
    np.savez(out/'grid-weights.npz', **weights)
    # Figure 1: real learning, seed spread and unequal compute acknowledged.
    fig, axs = plt.subplots(1,2,figsize=(11.8,3.9),layout='constrained')
    for method, color in [('DQN','#087E8B'),('tabular','#C65335')]:
        a=np.array([r[2:7] for r in rows if r[0]==method], float).reshape(5,-1,5)
        for ax, col in zip(axs,[1,3]):
            mean, sd = a[:,:,col].mean(0), a[:,:,col].std(0,ddof=1)
            ax.plot(a[0,:,0],mean,label=method,color=color)
            ax.fill_between(a[0,:,0],mean-sd,mean+sd,color=color,alpha=.15)
    random_returns=[evaluate(qstar,10000+i)[0] for i in range(100)]
    axs[0].axhline(evaluate(qstar)[0],color='#61757D',ls='--',label='optimal oracle')
    axs[0].axhline(np.mean(random_returns),color='#C4942A',ls=':',label='uniform random (100 runs)')
    axs[0].set_ylabel('64-step discounted evaluation return')
    axs[1].set_ylabel('Mean absolute Q error (oracle for analysis)')
    for ax in axs: ax.set_xlabel('Real training transitions'); ax.grid(alpha=.2); ax.legend(fontsize=8)
    fig.savefig(out/'grid-learning.pdf'); fig.savefig(out/'grid-learning.png',dpi=160); plt.close(fig)
    # Figure 2: value color, greedy arrows and actual greedy route from (0,0).
    fig, axs = plt.subplots(1,4,figsize=(12,3.5),layout='constrained')
    for ax,(t,q) in zip(axs,snapshots.items()):
        draw_grid(ax,q); ax.set_title(f'DQN seed 0: {t:,} steps')
    fig.colorbar(plt.cm.ScalarMappable(norm=matplotlib.colors.Normalize(-.1,1),cmap='YlGnBu'),ax=axs,shrink=.75,label='max Q(s,a)')
    fig.savefig(out/'grid-maps.pdf'); fig.savefig(out/'grid-maps.png',dpi=170); plt.close(fig)
    final = {method: [r for r in rows if r[0]==method and r[2]==steps] for method in ['DQN','tabular']}
    return {'steps_per_seed':steps,'seeds':list(range(5)),'mean_final_return':{m:float(np.mean([r[3] for r in z])) for m,z in final.items()},'mean_final_q_mae':{m:float(np.mean([r[5] for r in z])) for m,z in final.items()},'mean_final_success':{m:float(np.mean([r[4] for r in z])) for m,z in final.items()},'oracle_return':evaluate(qstar)[0],'random_return':float(np.mean(random_returns)),'dqn_updates':final['DQN'][0][-2],'dqn_target_copies':final['DQN'][0][-1]}

def draw_grid(ax,q):
    values=np.full((5,5),np.nan)
    for s in STARTS:
        x,y=STATES[s]; values[y,x]=q[s].max()
    ax.imshow(values,origin='lower',extent=(-.5,4.5,-.5,4.5),vmin=-.1,vmax=1,cmap='YlGnBu')
    for x,y in WALLS: ax.add_patch(plt.Rectangle((x-.5,y-.5),1,1,color='#182E38'))
    for s in STARTS:
        x,y=STATES[s]; dx,dy=DELTAS[int(q[s].argmax())]
        ax.arrow(x,y,dx*.25,dy*.25,width=.025,head_width=.16,color='white',length_includes_head=True)
    ax.text(4,4,'G',ha='center',va='center',color='#C65335',weight='bold',fontsize=14)
    route=[(0,0)]; s=INDEX[(0,0)]
    for _ in range(16):
        sp,_,done=transition(s,int(q[s].argmax())); route.append(STATES[sp])
        if done or sp == s: break
        s=sp
    ax.plot(*zip(*route),color='#E6A719',lw=2,marker='o',markersize=2)
    ax.set_xticks(range(5));ax.set_yticks(range(5));ax.set_aspect('equal')

def model_fit(data):
    x=np.array([[r[0],r[1],1.] for r in data]); y=np.array([r[2] for r in data])
    return np.linalg.lstsq(x,y,rcond=None)[0]

def plan(x, coef, horizon=4):
    sequences=SEQUENCES if horizon==4 else np.array(list(itertools.product(U,repeat=horizon)))
    states=np.full(len(sequences),x,dtype=float); cost=np.zeros(len(sequences))
    for k in range(horizon):
        actions=sequences[:,k]; states=coef[0]*states+coef[1]*actions+coef[2]
        cost += states**2+.15*actions**2
    i=int(cost.argmin())
    return float(sequences[i,0]), float(cost[i]), sequences[i].copy()

def run_model(out):
    true=np.array([.85,.6,.15]); changed=np.array([.85,.6,-.3])
    fits, control, data_rows, prediction_rows, curves = [], [], [], [], []
    for seed in range(10):
        rng=np.random.default_rng(100+seed); data=[]
        x=float(rng.uniform(-2,2))
        # Random-action consecutive trajectories, reset every 20 samples.
        for t in range(240):
            if t%20==0: x=float(rng.uniform(-2,2))
            u=float(rng.choice(U)); xp=true@[x,u,1]+rng.normal(0,.03)
            data.append((x,u,xp)); data_rows.append([seed,t,x,u,xp]); x=xp
        fit=model_fit(data); fits.append(fit)
        for n in [4,8,16,32,64,128,240]:
            f=model_fit(data[:n])
            # Independent noiseless conditional-mean query grid, not training error.
            queries=np.array([[x,u,1] for x in np.linspace(-2,2,41) for u in U])
            rmse=np.sqrt(np.mean((queries@f-queries@true)**2))
            curves.append([seed,n,rmse,*f])
        if seed==0:
            for u in U:
                for x in np.linspace(-2,2,41): prediction_rows.append([x,u,true@[x,u,1],fit@[x,u,1]])
        for method in ['zero','learned MPC','oracle MPC','adaptive MPC']:
            x=2.; recent=deque(data[-40:], maxlen=40); noise=np.random.default_rng(2000+seed).normal(0,.03,160)
            for t in range(160):
                coef=true if t<80 else changed
                if method=='zero': u=0.; used=fit
                else:
                    used=coef if method=='oracle MPC' else (model_fit(list(recent)) if method=='adaptive MPC' else fit)
                    u,_,_=plan(x,used)
                xp=coef@[x,u,1]+noise[t]; cost=xp*xp+.15*u*u
                control.append([method,seed,t,x,u,xp,cost,*used])
                recent.append((x,u,xp)); x=xp
    csv_save(out/'model-real-transitions.csv',['seed','t','x','u','next_x'],data_rows)
    csv_save(out/'model-fit-curve.csv',['seed','samples','mean_prediction_rmse','a','b','c'],curves)
    csv_save(out/'model-map.csv',['x','u','true_mean','learned_mean'],prediction_rows)
    csv_save(out/'mpc-control.csv',['method','seed','t','x','u','next_x','cost','a_used','b_used','c_used'],control)
    fig,axs=plt.subplots(1,2,figsize=(11.7,3.7),layout='constrained')
    a=np.array(curves).reshape(10,7,6)
    axs[0].plot(a[0,:,1],a[:,:,2].mean(0),color='#087E8B',marker='o')
    axs[0].fill_between(a[0,:,1],np.maximum(0,a[:,:,2].mean(0)-a[:,:,2].std(0,ddof=1)),a[:,:,2].mean(0)+a[:,:,2].std(0,ddof=1),alpha=.2,color='#087E8B')
    axs[0].set(xlabel='Real transitions used for fit',ylabel='Conditional-mean RMSE',yscale='log')
    arr=np.array(prediction_rows)
    for u,color in zip(U,['#C65335','#087E8B','#C4942A']):
        z=arr[arr[:,1]==u]; axs[1].plot(z[:,0],z[:,2],color=color,alpha=.4,lw=4)
        axs[1].plot(z[:,0],z[:,3],color=color,ls='--',label=f'learned, u={u:g}')
    axs[1].set(xlabel='Current position x',ylabel='Predicted next position');axs[1].legend(fontsize=8)
    for ax in axs:ax.grid(alpha=.2)
    fig.savefig(out/'model-learning.pdf');fig.savefig(out/'model-learning.png',dpi=160);plt.close(fig)
    fig,axs=plt.subplots(1,2,figsize=(11.8,3.6),layout='constrained')
    summary={}
    for method,color in [('zero','#61757D'),('learned MPC','#C65335'),('adaptive MPC','#087E8B'),('oracle MPC','#C4942A')]:
        arr=np.array([r[2:] for r in control if r[0]==method],float).reshape(10,160,8)
        axs[0].plot(arr[0,:,0],arr[0,:,3],label=method,color=color)
        means=arr[:,:,4].reshape(10,16,10).mean(2)
        mean,sd=means.mean(0),means.std(0,ddof=1)
        axs[1].plot(np.arange(16)*10+4.5,mean,color=color,label=method)
        axs[1].fill_between(np.arange(16)*10+4.5,mean-sd,mean+sd,color=color,alpha=.12)
        summary[method]={'cost_before':float(arr[:,:80,4].mean()),'cost_after':float(arr[:,80:,4].mean()),'cost_last40':float(arr[:,120:,4].mean())}
    axs[0].set(xlabel='Real control step',ylabel='Actual next position (seed 0)')
    axs[1].set(xlabel='Real control step',ylabel='Mean cost per step (10-step bins)')
    for ax in axs:ax.axvline(79.5,color='black',ls=':');ax.grid(alpha=.2);ax.legend(fontsize=7)
    fig.savefig(out/'mpc-control.pdf');fig.savefig(out/'mpc-control.png',dpi=160);plt.close(fig)
    return {'training_samples':240,'seeds':list(range(10)),'horizon':4,'candidate_sequences':81,'model_queries_per_decision':324,'initial_true_coefficients':true.tolist(),'changed_coefficients':changed.tolist(),'seed0_fit':fits[0].tolist(),'results':summary,'shift_time':80,'adaptive_window':40,'noise_sd':.03}

def tests():
    rng=np.random.default_rng(812); net=MLP(rng)
    x=FEATURES[[0,1,3]]; actions=np.array([0,2,1]); targets=np.array([.5,-.2,.9])
    loss,grads=net.loss_grad(x,actions,targets); errors=[]
    for p,g in zip(net.p,grads):
        for _ in range(5):
            ix=tuple(rng.integers(n) for n in p.shape);old=p[ix];h=1e-6
            p[ix]=old+h;plus=net.loss_grad(x,actions,targets)[0]
            p[ix]=old-h;minus=net.loss_grad(x,actions,targets)[0];p[ix]=old
            errors.append(abs((plus-minus)/(2*h)-g[ix]))
    assert max(errors)<1e-7
    assert transition(INDEX[(1,2)],1)[0]==INDEX[(1,2)]
    assert transition(INDEX[(3,4)],1)==(GOAL,1.,True)
    # Independent closed form from shortest path lengths, not Bellman iteration.
    distances={GOAL:0}; frontier=[GOAL]
    while frontier:
        sp=frontier.pop(0)
        for s in STARTS:
            if s not in distances and any(transition(s,a)[0]==sp for a in range(4)):
                distances[s]=distances[sp]+1;frontier.append(s)
    q=oracle()
    for s in STARTS:
        d=distances[s]; value=-.02*(1-GAMMA**(d-1))/(1-GAMMA)+GAMMA**(d-1)
        assert abs(q[s].max()-value)<1e-10
    # Terminal ignores any target, external cutoff keeps it.
    assert 1+GAMMA*(1-1)*999 == 1
    assert abs(1+GAMMA*(1-0)*5-5.85)<1e-12
    data=[(1.,0.,1.),(0.,1.,.75),(-1.,-1.,-1.2),(2.,1.,2.45)]
    fit=model_fit(data); design=np.array([[x,u,1] for x,u,_ in data]); y=np.array([xp for _,_,xp in data])
    assert np.max(np.abs(design.T@(design@fit-y)))<1e-12
    coef=np.array([.85,.6,.15]); x0=1.4
    def bellman(x,h):
        if h==0:return 0.
        return min((xp:=coef@[x,u,1])**2+.15*u*u+bellman(xp,h-1) for u in U)
    assert abs(plan(x0,coef)[1]-bellman(x0,4))<1e-12
    return {'gradient_max_fd_error':max(errors),'shortest_path_oracle':True,'terminal_and_cutoff':True,'ols_normal_equations':True,'mpc_vs_recursive_bellman':True}

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,default=ROOT/'assets/dqn-model-v11');parser.add_argument('--test-only',action='store_true');args=parser.parse_args()
    checked=tests()
    if args.test_only:print(json.dumps(checked,indent=2));return
    args.output.mkdir(parents=True,exist_ok=True);start=time.perf_counter()
    results={'validation':checked,'grid':run_grid(args.output,oracle()),'model':run_model(args.output),'seconds':time.perf_counter()-start,
             'provenance':{'python':sys.version.split()[0],'numpy':np.__version__,'matplotlib':matplotlib.__version__,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()},
             'scope':'Original teaching tasks; no Atari/CNN, Dreamer, or robot benchmark reproduction.',
             'grid_protocol':'22-state one-hot input, tanh hidden32, four outputs, Adam .001, replay2000, warmup128, batch32, one update/transition, copy100 updates; tabular one online update/transition alpha .2; 64-step external cutoff bootstraps.'}
    (args.output/'results.json').write_text(json.dumps(results,indent=2)+'\n')
    print(json.dumps(results,indent=2))

if __name__=='__main__':main()
