"""The lecture's 3 x 3 mud maze, with an exact model and sampled predictions.

Run with Python 3.9+ (standard library only):
    python3 demos/mud_world.py --episodes 10000 --seed 7

The topology follows Machado's CMPUT 365 w26 lecture_5.pdf, p. 9.
The lecture explicitly chooses reward, discount, and the two policies below.
Outputs are generated from the model / samples, not a benchmark reproduction.
"""

from __future__ import annotations
import argparse
import json
import random
from pathlib import Path

POSITIONS = {
    "S1": (0, 0), "S2": (1, 0), "G": (2, 0),
    "S3": (0, 1), "S4": (2, 1),
    "S5": (0, 2), "S6": (1, 2), "S7": (2, 2),
}
AT = {xy: s for s, xy in POSITIONS.items()}
STATES = tuple(s for s in POSITIONS if s != "G")
ACTIONS = {"up": (0, -1), "right": (1, 0), "down": (0, 1), "left": (-1, 0)}
GAMMA = 0.9
OLD = dict(zip(STATES, ["right", "right", "up", "up", "up", "left", "up"]))
NEW = {**OLD, "S7": "left"}


def outcomes(s: str, a: str):
    """Return (probability, next state, reward, terminated) alternatives.

    A visit to G has already ended the episode. In S4, 90% of action
    attempts fail to move; the remaining 10% follow the ordinary grid rule.
    """
    if s == "G":
        raise ValueError("G is terminal; reset before requesting an action")
    x, y = POSITIONS[s]
    dx, dy = ACTIONS[a]
    nxt = AT.get((x + dx, y + dy), s)
    move = (0.1 if s == "S4" else 1.0, nxt, float(nxt == "G"), nxt == "G")
    return [(0.9, s, 0.0, False), move] if s == "S4" else [move]


def backup(v, s, a):
    """Expected one-step return. The value of a true terminal state is zero."""
    return sum(p * (r + GAMMA * (0.0 if done else v[nxt]))
               for p, nxt, r, done in outcomes(s, a))


def evaluate(policy, tol=1e-13):
    """Synchronous iterative policy evaluation; all targets use the old table."""
    v = dict.fromkeys(STATES, 0.0)
    for _ in range(10000):
        updated = {s: backup(v, s, policy[s]) for s in STATES}
        error = max(abs(updated[s] - v[s]) for s in STATES)
        v = updated
        if error < tol:
            return v
    raise RuntimeError("Policy evaluation did not converge")


def rollout(policy, rng):
    """Generate one complete episode starting at S7."""
    s, trajectory = "S7", []
    for _ in range(100000):
        choices = outcomes(s, policy[s])
        u, mass = rng.random(), 0.0
        selected = choices[-1]
        for item in choices:
            mass += item[0]
            if u < mass:
                selected = item
                break
        _, nxt, r, done = selected
        trajectory.append((s, r, nxt, done))
        if done:
            return trajectory
        s = nxt
    raise RuntimeError("Episode exceeded the safety bound")


def sampled_predictions(episodes, seed):
    """MC and TD(0) use the same episodes and alpha=0.05.

    MC uses every visit and waits for the complete return. TD processes
    the recorded transitions in order. Because OLD stays fixed, its numerical
    updates equal those made online along that same trajectory. This
    single-seed demonstration is not a performance ranking.
    """
    rng = random.Random(seed)
    mc, td = dict.fromkeys(STATES, 0.0), dict.fromkeys(STATES, 0.0)
    alpha, points, steps = 0.05, [], 0
    all_first_returns = []
    for ep in range(1, episodes + 1):
        trajectory = rollout(OLD, rng)
        for s, r, nxt, done in trajectory:
            target = r + GAMMA * (0.0 if done else td[nxt])
            td[s] += alpha * (target - td[s])
        # Compute all returns before applying MC updates in chronological order.
        returns, g = [], 0.0
        for s, r, nxt, done in reversed(trajectory):
            g = r + GAMMA * g
            returns.append(g)
        returns.reverse()
        for (s, _, _, _), g in zip(trajectory, returns):
            mc[s] += alpha * (g - mc[s])
        all_first_returns.append(returns[0])
        steps += len(trajectory)
        if ep <= 20 or ep % max(1, episodes // 200) == 0:
            points.append({"episode": ep, "environment_steps": steps,
                           "mc_S7": mc["S7"], "td_S7": td["S7"]})
    mean = sum(all_first_returns) / episodes
    var = sum((g - mean) ** 2 for g in all_first_returns) / max(episodes - 1, 1)
    return {"alpha": alpha, "points": points, "return_mean": mean,
            "return_standard_error": (var / episodes) ** 0.5,
            "environment_steps": steps}


def draw_values(old_v, new_v, path):
    """A data-derived SVG. Values are model calculations, not learned returns."""
    parts = ['<svg xmlns="http://www.w3.org/2000/svg" width="1000" height="460" viewBox="0 0 1000 460">',
             '<rect width="1000" height="460" fill="white"/>',
             '<g font-family="Arial,sans-serif" fill="#182E38">']
    arrow = {"up": "↑", "right": "→", "down": "↓", "left": "←"}
    for offset, title, policy, v in [(55, "Old policy: try the mud", OLD, old_v),
                                    (555, "Improved policy: take the detour", NEW, new_v)]:
        parts.append(f'<text x="{offset}" y="32" font-size="21">{title}</text>')
        for x in range(3):
            for y in range(3):
                px, py = offset + 110 * x, 55 + 110 * y
                s = AT.get((x, y))
                fill = "#182E38" if s is None else "#F6E5CA" if s == "S4" else "#EAF4F3"
                parts.append(f'<rect x="{px}" y="{py}" width="110" height="110" fill="{fill}" stroke="#61757D"/>')
                if s:
                    parts.append(f'<text x="{px+8}" y="{py+22}" font-size="15">{s}</text>')
                    label = "terminal" if s == "G" else f'{v[s]:.4f}'
                    parts.append(f'<text x="{px+55}" y="{py+57}" text-anchor="middle" font-size="22">{label}</text>')
                    if s != "G":
                        parts.append(f'<text x="{px+55}" y="{py+92}" text-anchor="middle" font-size="26">{arrow[policy[s]]}</text>')
    parts.extend(['<text x="55" y="420" font-size="16">Reward 1 on entering G; 0 otherwise. Discount 0.9. S4 sticks with probability 0.9.</text>',
                  '<text x="55" y="445" font-size="16">Exact-model policy evaluation. Values are expected discounted returns; G has value 0.</text>', '</g></svg>'])
    path.write_text("\n".join(parts), encoding="utf-8")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--episodes", type=int, default=10000)
    parser.add_argument("--seed", type=int, default=7)
    parser.add_argument("--output", type=Path, default=Path(__file__).parent / "results")
    args = parser.parse_args()
    if args.episodes < 2:
        parser.error("--episodes must be at least 2")
    old_v, new_v = evaluate(OLD), evaluate(NEW)
    assert abs(old_v["S4"] - 10 / 19) < 1e-10
    assert abs(old_v["S7"] - 9 / 19) < 1e-10
    assert abs(new_v["S7"] - GAMMA**5) < 1e-10
    assert abs(backup(old_v, "S7", "left") - GAMMA**5) < 1e-10
    assert new_v["S7"] > old_v["S7"]
    sampled = sampled_predictions(args.episodes, args.seed)
    args.output.mkdir(parents=True, exist_ok=True)
    result = {"gamma": GAMMA, "seed": args.seed, "episodes": args.episodes,
              "old_policy": OLD, "new_policy": NEW,
              "old_exact_values": old_v, "new_exact_values": new_v,
              "sampled_predictions": sampled,
              "interpretation": "Exact-model values and one-seed prediction demo; not a multi-seed algorithm comparison."}
    (args.output / "mud-world.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    draw_values(old_v, new_v, args.output / "mud-world-values.svg")
    print(f'Old V(S7) = {old_v["S7"]:.9f}; new = {new_v["S7"]:.9f}')
    print(f'Sampled old-policy return = {sampled["return_mean"]:.6f} '
          f'+/- {sampled["return_standard_error"]:.6f} (one standard error)')
    print(f'Wrote model and samples to {args.output.resolve()}')


if __name__ == "__main__":
    main()
