#!/usr/bin/env python3
"""Finite, CPU-only checks for the chapter 7--11 argument repairs.

No training or historical data are changed. Output is relative to this script,
so the command also works from an independent working directory.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]


def maximum_error(a, b):
    error = float(np.max(np.abs(np.asarray(a) - np.asarray(b))))
    assert error < 1e-10, error
    return error


def lambda_weights():
    """Direct length-mixture coefficients against each TD error coefficient."""
    largest = 0.0
    cases = 0
    for length in range(1, 15):
        for lam in (0.0, 0.3, 0.8, 1.0):
            weights = np.r_[
                (1-lam)*lam**np.arange(length-1), lam**(length-1)
            ]
            largest = max(largest, maximum_error(weights.sum(), 1))
            for j in range(length):
                largest = max(largest, maximum_error(weights[j:].sum(), lam**j))
            cases += 1
    return {"length_lambda_cases": cases, "max_error": largest}


def model_decisions():
    """Waiting-time enumeration and a linear-system evaluation are independent."""
    gamma = 0.9
    left = gamma**5
    values = {}
    for p in (0.1, 0.2):
        upward = gamma*p/(1-gamma*(1-p))
        waiting = sum(p*(1-p)**j*gamma**(j+1) for j in range(1000))
        P = np.array([[0, 1], [0, 1-p]])
        r = np.array([0, p])
        matrix = np.linalg.solve(np.eye(2)-gamma*P, r)[0]
        maximum_error(upward, waiting)
        maximum_error(upward, matrix)
        values[str(p)] = upward
    threshold = left*(1-gamma)/(gamma*(1-left))
    maximum_error(gamma*threshold/(1-gamma*(1-threshold)), left)
    assert values["0.1"] < left < values["0.2"]
    # Verify every arrow of the displayed policy in the original maze.
    import mud_world
    states = mud_world.STATES; actions = tuple(mud_world.ACTIONS)
    def modeled_backup(v, state, action):
        outcomes = mud_world.outcomes(state, action)
        if state == 'S4':
            outcomes = [(.8, state, 0., False), (.2, *outcomes[1][1:])]
        return sum(p*(r+gamma*(0 if terminal else v[nxt]))
                   for p, nxt, r, terminal in outcomes)
    v = dict.fromkeys(states, 0.)
    for _ in range(500):
        v = {s: max(modeled_backup(v, s, a) for a in actions) for s in states}
    greedy = {s: max(actions, key=lambda a: modeled_backup(v, s, a)) for s in states}
    assert greedy == mud_world.OLD
    evaluation = mud_world.evaluate(greedy)
    maximum_error(evaluation['S7'], values['0.1'])
    return {"q_up_true": values["0.1"], "q_up_model": values["0.2"],
            "q_left": left, "true_policy_loss": left-values["0.1"],
            "success_probability_ranking_threshold": threshold,
            "model_greedy_policy": greedy, "true_evaluation_of_model_policy": evaluation}


def planning_residuals():
    rng = np.random.default_rng(8317)
    gamma = 0.87
    largest_violation = 0.0
    for _ in range(100):
        P = rng.dirichlet(np.ones(3), size=(3, 2))
        Phat = rng.dirichlet(np.ones(3), size=(3, 2))
        r = rng.normal(size=(3, 2)); rhat = r+rng.normal(scale=.1, size=(3, 2))
        T = lambda w: (r+gamma*(P@w)).max(axis=1)
        That = lambda w: (rhat+gamma*(Phat@w)).max(axis=1)
        v = np.zeros(3)
        for _ in range(300):
            v = T(v)
        W = rng.normal(size=3)
        for _ in range(4):
            W = That(W)
        model = np.max(np.abs(T(W)-That(W)))
        plan = np.max(np.abs(That(W)-W))
        bound = (model+plan)/(1-gamma)
        violation = float(np.max(np.abs(v-W))-bound)
        assert violation < 1e-10
        largest_violation = max(largest_violation, violation)
    return {"random_model_pairs": 100, "max_positive_bound_violation": largest_violation}


def weighting_and_projection():
    X = np.array([[1., 0.], [1., 1.], [0., 1.]])
    mu = np.array([.2, .3, .5]); nu = np.array([.6, .3, .1])
    value = np.array([-.8, .4, 1.2]); w = np.array([.1, -.2])
    direction = sum(nu[s]*(mu[s]/nu[s])*(value[s]-X[s]@w)*X[s] for s in range(3))
    def loss(q): return .5*np.dot(mu, (value-X@q)**2)
    h = 1e-6
    fd = np.array([(loss(w+h*e)-loss(w-h*e))/(2*h) for e in np.eye(2)])
    fd_error = maximum_error(direction, -fd)
    gamma = .8
    P = np.array([[.1, .6, .3], [.2, .2, .6], [.5, .1, .4]])
    r = np.array([1., -.2, .3]); D = np.diag(mu)
    A = X.T@D@(np.eye(3)-gamma*P)@X; b = X.T@D@r
    td = np.linalg.solve(A, b)
    residual = r+gamma*P@X@td-X@td
    Pi = X@np.linalg.solve(X.T@D@X, X.T@D)
    orthogonality = maximum_error(X.T@D@residual, np.zeros(2))
    projected = maximum_error(Pi@(r+gamma*P@X@td), X@td)
    assert np.max(np.abs(residual)) > .01
    return {"state_ratio_gradient_fd_error": fd_error,
            "normal_equation_residual": orthogonality,
            "projected_fixed_point_error": projected,
            "pointwise_bellman_residual": residual.tolist()}


def fitted_q_and_multistep():
    """Enumerate labels to test the conditional variance identity."""
    d = np.array([.25, .75]); outcome_p = np.array([.3, .7])
    labels = np.array([[.5, 1.7], [-.2, 2.1]])
    q = np.array([.4, .8]); means = labels@outcome_p
    direct = sum(d[s]*outcome_p[j]*(q[s]-labels[s, j])**2
                 for s in range(2) for j in range(2))
    bias = np.dot(d, (q-means)**2)
    variance = sum(d[s]*np.dot(outcome_p, (labels[s]-means[s])**2) for s in range(2))
    identity = maximum_error(direct, bias+variance)
    # s=0 -> s=1 -> terminal; the intermediate behavior chooses either reward.
    reward = np.array([[0., 0.], [1., 3.], [0., 0.]])
    next_state = np.array([[1, 1], [2, 2], [2, 2]])
    nonterminal = np.array([[1., 1.], [0., 0.], [0., 0.]])
    behavior = np.full((3, 2), .5)
    Q = np.array([[.2, -.1], [2., 4.], [0., 0.]])
    def Tb(q): return reward+.9*nonterminal*(behavior*q).sum(axis=1)[next_state]
    def Tstar(q): return reward+.9*nonterminal*q.max(axis=1)[next_state]
    mixed = Tb(Tstar(Q))[0, 0]
    optimal = Tstar(Tstar(Q))[0, 0]
    enumerated = .5*(.9*1)+.5*(.9*3)
    maximum_error(mixed, enumerated)
    maximum_error(mixed, 1.8); maximum_error(optimal, 2.7)
    return {"regression_variance_decomposition_error": identity,
            "two_step_behavior_expectation": float(mixed),
            "two_step_optimal_expectation": float(optimal)}


def performance_difference():
    """Matrix values against deterministic-prefix telescoping and occupancy."""
    gamma = .9
    # Two nonterminal states and a zero-reward absorbing terminal state.
    transitions = np.array([[[.2, .8, 0], [0, 0, 1]],
                            [[0, .4, .6], [0, 0, 1]],
                            [[0, 0, 1], [0, 0, 1]]])
    reward = np.array([[.1, 1.], [.3, 2.], [0., 0.]])
    old = np.array([[.6, .4], [.7, .3], [1., 0.]])
    new = np.array([[.8, .2], [.2, .8], [1., 0.]])
    Pold = (old[:, :, None]*transitions).sum(axis=1)
    Pnew = (new[:, :, None]*transitions).sum(axis=1)
    vold = np.linalg.solve(np.eye(3)-gamma*Pold, (old*reward).sum(axis=1))
    vnew = np.linalg.solve(np.eye(3)-gamma*Pnew, (new*reward).sum(axis=1))
    advantage = reward+gamma*(transitions@vold)-vold[:, None]
    mu = np.array([1., 0., 0.]); dist = mu.copy()
    Amean = (new*advantage).sum(axis=1)
    rmean = (new*reward).sum(axis=1)
    asum = 0.; rsum = 0.; H = 5
    for t in range(H):
        asum += gamma**t*(dist@Amean); rsum += gamma**t*(dist@rmean)
        dist = dist@Pnew
    telescope = maximum_error(asum, rsum-mu@vold+gamma**H*(dist@vold))
    occupancy = mu@np.linalg.inv(np.eye(3)-gamma*Pnew)
    mass = maximum_error((1-gamma)*occupancy.sum(), 1.)
    performance = maximum_error(mu@(vnew-vold), occupancy@Amean)
    return {"finite_H_telescoping_error": telescope,
            "normalized_absorbing_occupancy_error": mass,
            "performance_difference_error": performance}


def gae_critic_error():
    """Compare two independently formed TD sums with the shifted-error sum."""
    rng = np.random.default_rng(1135); largest = 0.; cases = 0
    for length in range(1, 15):
        reward = rng.normal(size=length)
        truth = np.r_[rng.normal(size=length), 0.]
        estimate = truth+np.r_[rng.normal(size=length), 0.]
        e = estimate-truth; gamma = .93
        dv = reward+gamma*estimate[1:]-estimate[:-1]
        dt = reward+gamma*truth[1:]-truth[:-1]
        for lam in (0., .4, .95, 1.):
            for t in range(length):
                direct = sum((gamma*lam)**j*(dv[t+j]-dt[t+j]) for j in range(length-t))
                shifted = -e[t]+gamma*(1-lam)*sum(
                    (gamma*lam)**(j-1)*e[t+j] for j in range(1, length-t))
                largest = max(largest, maximum_error(direct, shifted)); cases += 1
    actor_errors = []
    for lam in (0., .4, .95, 1.):
        # Enumerate the original three paths. V(s0)=.2 is a fixed baseline,
        # V(s1)=0 misses its true value 1.5. The sampled actor is at t=0.
        p, q, v0 = .5, .25, .2
        paths = [((1-p), 1-v0, -p),
                 (p*(1-q), -v0+.9*lam*1, 1-p),
                 (p*q, -v0+.9*lam*3, 1-p)]
        direct_actor = sum(prob*adv*score for prob, adv, score in paths)
        actor_errors.append(maximum_error(direct_actor, .25*(1.35*lam-1)))
    return {"prefix_lambda_cases": cases, "max_error": largest,
            "two_step_actor_enumeration_error": max(actor_errors),
            "direction_changes_at_lambda": 1/1.35}


def soft_values():
    """Enumerate entropy-regularized paths and compare the soft Bellman form."""
    p, q, gamma, alpha = .4, .3, .9, .2
    pi0 = np.array([1-p, p]); pi1 = np.array([1-q, q])
    v1 = float(np.dot(pi1, np.array([1., 3.])-alpha*np.log(pi1)))
    q0 = np.array([1., gamma*v1])
    v0 = float(np.dot(pi0, q0-alpha*np.log(pi0)))
    paths = [((1-p), 1.-alpha*np.log(1-p)),
             (p*(1-q), -alpha*np.log(p)+gamma*(1.-alpha*np.log(1-q))),
             (p*q, -alpha*np.log(p)+gamma*(3.-alpha*np.log(q)))]
    direct = sum(probability*total for probability, total in paths)
    return {"J_equals_start_soft_value_error": maximum_error(direct, v0),
            "J_alpha": direct, "Q_continue_excludes_first_entropy": float(q0[1])}


def existing_analytic_checks():
    import course15_traces
    import dqn_model_v11
    import sample14_pg
    results = {"traces": course15_traces.independent_checks(),
               "dqn": dqn_model_v11.tests(),
               "reinforce": sample14_pg.checks()}
    try:
        import torch  # noqa: F401
    except ImportError:
        results["torch_checks"] = {"status": "not_run", "reason": "torch unavailable in selected runtime"}
    else:
        import sample14_sac
        import ppo_sac_v11_lab
        results["sac"] = sample14_sac.checks()
        results["ppo_sac"] = ppo_sac_v11_lab.checks()
    return results


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, default=ROOT/'assets/v17-methods')
    parser.add_argument('--existing-checks', action='store_true')
    args = parser.parse_args()
    report = {"validation_layer": "finite analytic identities and implementation checks; no training",
              "lambda_weights": lambda_weights(), "model_decisions": model_decisions(),
              "planning_residuals": planning_residuals(),
              "weighting_and_projection": weighting_and_projection(),
              "fitted_q_and_multistep": fitted_q_and_multistep(),
              "performance_difference": performance_difference(),
              "gae_critic_error": gae_critic_error(), "soft_values": soft_values()}
    if args.existing_checks:
        report["preserved_implementation_checks"] = existing_analytic_checks()
    report["all_passed"] = True
    args.out.mkdir(parents=True, exist_ok=True)
    (args.out/'report.json').write_text(json.dumps(report, ensure_ascii=False, indent=2)+'\n')
    existing = report.get("preserved_implementation_checks", {})
    print(json.dumps({"all_passed": True, "new_check_groups": 8,
                      "executed_existing_check_groups": sum(k in existing for k in ('traces','dqn','reinforce','sac','ppo_sac')),
                      "torch_checks": existing.get('torch_checks', {"status": "executed"} if args.existing_checks else {"status": "not_requested"}),
                      "report": str(args.out/'report.json')}, ensure_ascii=False))


if __name__ == '__main__':
    main()
