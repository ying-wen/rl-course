"""Small, complete SAC experiment accompanying the Chapter 11 sample.

python sample14_sac.py --steps 8000 --seeds 0 1 2
Dependencies: numpy, torch, matplotlib. Runs on CPU; no Gym or model weights.
Outputs: ../assets/sample14-sac/{results.json,curves,checkpoints,figures}.

The task lasts exactly H=12 actions. State=(position,steps_remaining/H).
The learner knows the action limits, but accesses dynamics only through step.
Evaluation is independent frozen stochastic-policy execution, not critic output.
"""
from __future__ import annotations
import argparse, copy, json, math
from contextlib import contextmanager
from pathlib import Path
import numpy as np
import torch
from torch import nn
from torch.distributions import Normal

H,GAMMA=12,.97
torch.set_num_threads(1)


def tensor(x):return torch.as_tensor(x,dtype=torch.float32)


def observation(x,h):
    x=np.asarray(x)
    return np.column_stack([x,np.full_like(x,h/H)]).astype(np.float32)


def step(x,a):
    """Environment only. No transition derivative is passed to the learner."""
    next_x=np.clip(x+.25*a,-1.5,1.5)
    return next_x,-(next_x**2+.03*a**2)


def network(n_in,n_out):
    return nn.Sequential(nn.Linear(n_in,32),nn.Tanh(),nn.Linear(32,32),nn.Tanh(),nn.Linear(32,n_out))


class Agent(nn.Module):
    def __init__(self):
        super().__init__();self.actor=network(2,2);self.q1=network(3,1);self.q2=network(3,1)

    def sample(self,state,epsilon=None):
        mu,log_std=self.actor(state).chunk(2,-1)
        log_std=log_std.clamp(-5,1);distribution=Normal(mu,log_std.exp())
        # Base noise is independent of theta. Keep the path theta -> u -> action.
        u=distribution.rsample() if epsilon is None else mu+log_std.exp()*epsilon
        action=u.tanh()
        log_jacobian=2*(math.log(2)-u-nn.functional.softplus(-2*u))
        logp=(distribution.log_prob(u)-log_jacobian).sum(-1)
        return action,logp

    def min_q(self,state,action):
        pair=torch.cat([state,action],-1)
        return torch.minimum(self.q1(pair),self.q2(pair)).squeeze(-1)

    def q_parameters(self):return list(self.q1.parameters())+list(self.q2.parameters())


@contextmanager
def fixed_q_weights(agent):
    """Freeze Q weights, not the dependence of Q on its action argument."""
    params=agent.q_parameters()
    for p in params:p.requires_grad_(False)
    try:yield
    finally:
        for p in params:p.requires_grad_(True)


def critic_target(agent,target,next_state,reward,nonterminal,alpha):
    # No derivative through reward, next action, target Q, entropy or alpha.
    with torch.no_grad():
        next_action,next_logp=agent.sample(next_state)
        next_q=target.min_q(next_state,next_action)
        y=reward+GAMMA*nonterminal*(next_q-alpha*next_logp)
    return y,next_action,next_logp,next_q


def update_critic(agent,optimizer,state,recorded_action,y):
    pair=torch.cat([state,recorded_action],-1)
    q1,q2=agent.q1(pair).squeeze(-1),agent.q2(pair).squeeze(-1)
    loss=.5*((q1-y).square().mean()+(q2-y).square().mean())
    optimizer.zero_grad();loss.backward();optimizer.step()
    return {'loss':float(loss.detach()),'q1_before':q1.detach(),'q2_before':q2.detach()}


def update_actor(agent,optimizer,state,alpha):
    # Replay provides states; the CURRENT actor provides a fresh action.
    with fixed_q_weights(agent):
        action,logp=agent.sample(state)
        q=agent.min_q(state,action)
        loss=(alpha*logp-q).mean()
        optimizer.zero_grad();loss.backward();optimizer.step()
    return {'loss':float(loss.detach()),'action':action.detach(),'logp':logp.detach(),'q':q.detach()}


def update_temperature(log_alpha,optimizer,logp,target_entropy):
    # Exact log-alpha chain rule for alpha*(H-H_target); logp is fixed.
    loss=-(log_alpha.exp()*(logp.detach()+target_entropy)).mean()
    optimizer.zero_grad();loss.backward();optimizer.step()
    return float(loss.detach())


@torch.no_grad()
def update_target(agent,target,tau=.01):
    for p,bar_p in zip(agent.q_parameters(),target.q_parameters()):
        bar_p.mul_(1-tau).add_(p,alpha=tau)


@torch.no_grad()
def evaluate(agent,seed=9001,starts=None,repeats=256):
    """Independent RNG; stochastic policy, external reward only."""
    with torch.random.fork_rng():
        torch.manual_seed(seed);rng=np.random.default_rng(seed)
        x=rng.uniform(-1,1,repeats) if starts is None else np.repeat(starts,repeats)
        values=np.zeros(len(x));positions=[x.copy()];actions=[]
        for t in range(H):
            a=agent.sample(tensor(observation(x,H-t)))[0][:,0].numpy()
            x,reward=step(x,a);values+=GAMMA**t*reward
            actions.append(a.copy());positions.append(x.copy())
        return {'return':values,'x':np.array(positions),'a':np.array(actions)}


def baselines(seed=9001,repeats=256):
    results={}
    for mode in ['zero','uniform','feedback']:
        rng=np.random.default_rng(seed);x=rng.uniform(-1,1,repeats);values=np.zeros(repeats)
        for t in range(H):
            a=np.zeros(repeats) if mode=='zero' else rng.uniform(-1,1,repeats) if mode=='uniform' else np.clip(-x/.25,-1,1)
            x,reward=step(x,a);values+=GAMMA**t*reward
        results[mode]=float(values.mean())
    return results


def train(seed,steps,out):
    torch.manual_seed(seed);rng=np.random.default_rng(seed)
    agent=Agent();target=copy.deepcopy(agent)
    for p in target.parameters():p.requires_grad_(False)
    q_opt=torch.optim.Adam(agent.q_parameters(),lr=.001)
    actor_opt=torch.optim.Adam(agent.actor.parameters(),lr=.001)
    log_alpha=torch.tensor(math.log(.1),requires_grad=True)
    alpha_opt=torch.optim.Adam([log_alpha],lr=.001)
    replay=np.zeros((10000,7),np.float32)
    history=[[0,evaluate(agent)['return'].mean(),.1,0]]
    torch.save(agent.state_dict(),out/f'initial-{seed}.pt')
    x,t=float(rng.uniform(-1,1)),0
    for k in range(1,steps+1):
        s=observation([x],H-t)
        with torch.no_grad():a=float(rng.uniform(-1,1)) if k<=500 else agent.sample(tensor(s))[0].item()
        next_x,r=step(x,a);next_s=observation([next_x],H-t-1)
        m=float(t+1<H) # This horizon is part of the task, so its end is terminal.
        replay[(k-1)%len(replay)]=[*s[0],a,r,*next_s[0],m]
        x,t=(next_x,t+1) if m else (float(rng.uniform(-1,1)),0)
        if k>=500:
            rows=tensor(replay[rng.integers(0,min(k,len(replay)),size=128)])
            s,a,r,ns,m=rows[:,:2],rows[:,2:3],rows[:,3],rows[:,4:6],rows[:,6]
            alpha=log_alpha.exp().detach()
            y,*_=critic_target(agent,target,ns,r,m,alpha)
            update_critic(agent,q_opt,s,a,y)
            actor=update_actor(agent,actor_opt,s,alpha)
            update_temperature(log_alpha,alpha_opt,actor['logp'],-.7)
            update_target(agent,target)
        if k%500==0 or k==steps:
            history.append([k,evaluate(agent)['return'].mean(),log_alpha.exp().item(),max(0,k-499)])
    torch.save({'agent':agent.state_dict(),'alpha':log_alpha.exp().item()},out/f'learned-{seed}.pt')
    np.save(out/f'curve-{seed}.npy',np.array(history))
    return np.array(history),agent


def walkthrough():
    """Execute one complete update on one real transition; log every operand."""
    torch.manual_seed(7);agent=Agent();target=copy.deepcopy(agent)
    for p in target.parameters():p.requires_grad_(False)
    s=tensor(observation([.8],12));a=tensor([[-.4]])
    x1,reward=step(.8,-.4);ns=tensor(observation([x1],11));r=tensor([reward]);m=tensor([1.])
    alpha=torch.tensor(.1);log_alpha=torch.tensor(math.log(.1),requires_grad=True)
    oq=torch.optim.SGD(agent.q_parameters(),lr=.01)
    op=torch.optim.SGD(agent.actor.parameters(),lr=.01)
    oa=torch.optim.SGD([log_alpha],lr=.01)
    with torch.no_grad():median_before=agent.sample(s,torch.zeros((1,1)))[0].item()
    y,na,nlp,nq=critic_target(agent,target,ns,r,m,alpha)
    critic=update_critic(agent,oq,s,a,y)
    actor=update_actor(agent,op,s,alpha)
    update_temperature(log_alpha,oa,actor['logp'],-.7)
    update_target(agent,target)
    with torch.no_grad():median_after=agent.sample(s,torch.zeros((1,1)))[0].item()
    report={'s':[.8,1.],'recorded_action':-.4,'reward':float(reward),'next_s':[float(x1),11/12],
            'gamma':GAMMA,'alpha_before':.1,'next_action':na.item(),'next_logp':nlp.item(),'target_min_q':nq.item(),
            'target_y':y.item(),'q1_before':critic['q1_before'].item(),'q2_before':critic['q2_before'].item(),
            'critic_loss':critic['loss'],'fresh_action':actor['action'].item(),'fresh_logp':actor['logp'].item(),
            'fresh_min_q':actor['q'].item(),'actor_loss':actor['loss'],
            'median_before':median_before,'median_after':median_after,'alpha_after':log_alpha.exp().item()}
    assert abs(report['target_y']-(reward+GAMMA*(report['target_min_q']-.1*report['next_logp'])))<1e-6
    return report


def checks():
    result={}
    # Integrate the change-of-variables density, independently of torch sampling.
    a=np.linspace(-.9999999,.9999999,200001);u=np.arctanh(a)
    density=np.exp(-u*u/2)/np.sqrt(2*np.pi)/(1-a*a)
    integral=np.trapezoid(density,a);assert abs(integral-1)<2e-5
    result['density_integral']=float(integral)
    # One-dimensional fixed-noise path derivative versus numerical differentiation.
    eps=torch.tensor([-.8,.1,1.2],dtype=torch.float64)
    def f(mu):
        z=mu+.6*eps;action=z.tanh()
        lp=-.5*eps.square()-math.log(.6)-.5*math.log(2*math.pi)-torch.log1p(-action.square())
        return (.2*lp+(action-.4).square()).mean()
    mu=torch.tensor(.3,dtype=torch.float64,requires_grad=True);f(mu).backward()
    fd=(f(.3+1e-6)-f(.3-1e-6)).item()/2e-6
    assert abs(mu.grad.item()-fd)<1e-8
    result['path_gradient']={'autograd':mu.grad.item(),'finite_difference':fd}
    # Freezing Q weights must preserve its derivative with respect to action.
    torch.manual_seed(10);agent=Agent();s=tensor([[.8,1.]])
    for p in agent.parameters():p.grad=None
    with fixed_q_weights(agent):
        action,_=agent.sample(s,torch.zeros((1,1)));loss=-agent.min_q(s,action).mean();loss.backward()
    q_has_grad=any(p.grad is not None for p in agent.q_parameters())
    actor_norm=sum(p.grad.abs().sum().item() for p in agent.actor.parameters() if p.grad is not None)
    assert not q_has_grad and actor_norm>0
    result['frozen_Q_has_no_weight_gradient']=not q_has_grad;result['actor_Q_path_gradient_norm']=actor_norm
    for entropy in [-1.2,.2]:
        eta=torch.tensor(math.log(.1),requires_grad=True)
        op=torch.optim.SGD([eta],lr=.1)
        update_temperature(eta,op,torch.tensor([-entropy]),-.7)
        assert (eta.exp().item()>.1)==(entropy<-.7)
    # Terminal reward is retained; no next-state tail contributes.
    target=copy.deepcopy(agent)
    y,*_=critic_target(agent,target,s,torch.tensor([2.]),torch.tensor([0.]),torch.tensor(.1))
    assert y.item()==2.
    result['temperature_sign_and_terminal_target']=True;result['all_passed']=True
    return result


def plot(out,seeds):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    plt.rcParams.update({'font.size':13,'axes.spines.top':False,'axes.spines.right':False})
    teal,orange,gray='#087e8b','#c65335','#61757d'
    curves=np.stack([np.load(out/f'curve-{s}.npy') for s in seeds]);base=baselines()
    fig,ax=plt.subplots(figsize=(8.8,3.6),layout='constrained')
    for c in curves:ax.plot(c[:,0],c[:,1],color=teal,lw=1,alpha=.25)
    ax.plot(curves[0,:,0],curves[:,:,1].mean(0),color=teal,lw=2.6,label='SAC: seed mean')
    for key,style in [('uniform',':'),('zero','--'),('feedback','-.')]:ax.axhline(base[key],ls=style,label=key,color=gray if key!='feedback' else orange)
    ax.set(xlabel='real environment transitions',ylabel='discounted external return');ax.legend(frameon=False,fontsize=10)
    fig.savefig(out/'learning.pdf');fig.savefig(out/'learning.png',dpi=180);plt.close(fig)
    initial=Agent();initial.load_state_dict(torch.load(out/f'initial-{seeds[0]}.pt',weights_only=True))
    learned=Agent();ck=torch.load(out/f'learned-{seeds[0]}.pt',weights_only=True);learned.load_state_dict(ck['agent'])
    fig,axs=plt.subplots(1,2,figsize=(10.5,3.5),layout='constrained')
    for agent,color,label in [(initial,gray,'initial stochastic policy'),(learned,teal,'learned stochastic policy')]:
        run=evaluate(agent,seed=731,starts=[.8],repeats=20)
        for row in run['x'].T:axs[0].plot(range(H+1),row,color=color,alpha=.15,lw=.9)
        axs[0].plot(range(H+1),run['x'].mean(1),color=color,lw=2.7,label=label)
    axs[0].axhline(0,color=orange,ls='--');axs[0].set(xlabel='time in the episode',ylabel='position x');axs[0].legend(frameon=False,fontsize=9)
    x=np.linspace(-1,1,81);ss=tensor(observation(x,H))
    for agent,color,label in [(initial,gray,'initial'),(learned,teal,'learned')]:
        with torch.no_grad():
            mu,ls=agent.actor(ss).chunk(2,-1);median=mu.tanh().numpy()[:,0]
            low=(mu-ls.clamp(-5,1).exp()).tanh().numpy()[:,0];high=(mu+ls.clamp(-5,1).exp()).tanh().numpy()[:,0]
        axs[1].fill_between(x,low,high,color=color,alpha=.12);axs[1].plot(x,median,color=color,lw=2.3,label=label)
    axs[1].axhline(0,color='.8',lw=.7);axs[1].set(xlabel='position x (12 actions left)',ylabel='action: median and 68% interval',ylim=(-1.05,1.05));axs[1].legend(frameon=False,fontsize=10)
    fig.savefig(out/'behavior.pdf');fig.savefig(out/'behavior.png',dpi=180);plt.close(fig)
    plot_entropy_choice(out)
    return base


def plot_entropy_choice(out):
    """Fixed-Q density illustration: normalized preference, not a learned result.

    The temperature is written kappa, as in the chapter text (the SAC paper's alpha).
    """
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from matplotlib import font_manager
    teal,orange='#087e8b','#c65335'
    with plt.rc_context({'font.size':13,'axes.spines.top':False,'axes.spines.right':False,
                         'axes.unicode_minus':False,'pdf.fonttype':42}):
        for font in ['/System/Library/Fonts/PingFang.ttc','/System/Library/Fonts/STHeiti Light.ttc']:
            if Path(font).exists():
                font_manager.fontManager.addfont(font)
                plt.rcParams['font.family']=font_manager.FontProperties(fname=font).get_name()
                break
        a=np.linspace(-1,1,801);q=-(a+.6)**2
        fig,axs=plt.subplots(1,2,figsize=(10,3.2),layout='constrained')
        axs[0].plot(a,q,color='#182e38',lw=2.5);axs[0].set(xlabel=r'动作 $a$',ylabel=r'固定的 $Q(s,a)$')
        for kappa,color in [(.05,teal),(.3,orange)]:
            z=np.exp(q/kappa);density=z/np.trapezoid(z,a)
            axs[1].plot(a,density,color=color,lw=2.5,label=rf'$\kappa={kappa}$')
        axs[1].set(xlabel=r'动作 $a$',ylabel=r'归一化的 $\exp(Q/\kappa)$');axs[1].legend(frameon=False)
        fig.savefig(out/'entropy-choice.pdf');fig.savefig(out/'entropy-choice.png',dpi=180);plt.close(fig)


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--steps',type=int,default=8000);ap.add_argument('--seeds',type=int,nargs='+',default=[0,1,2]);ap.add_argument('--out',type=Path,default=Path(__file__).resolve().parents[1]/'assets/sample14-sac');ap.add_argument('--check-only',action='store_true');args=ap.parse_args()
    out=args.out;out.mkdir(parents=True,exist_ok=True)
    report={'checks':checks(),'walkthrough':walkthrough(),'torch_version':torch.__version__}
    if not args.check_only:
        runs=[]
        for seed in args.seeds:
            curve,_=train(seed,args.steps,out);runs.append(curve)
        report['training']={'seeds':args.seeds,'real_steps_per_seed':args.steps,'gradient_updates_per_seed':args.steps-499,'horizon':H,'gamma':GAMMA,
                            'evaluation':'256 frozen stochastic-policy episodes, fixed independent seed 9001',
                            'initial_returns':[float(c[0,1]) for c in runs],'final_returns':[float(c[-1,1]) for c in runs]}
        report['baselines']=plot(out,args.seeds)
    (out/'results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
    print(json.dumps(report,ensure_ascii=False,indent=2))


if __name__=='__main__':main()
