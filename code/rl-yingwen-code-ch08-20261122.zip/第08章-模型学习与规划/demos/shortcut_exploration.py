"""Dyna in the shortcut maze, Sutton & Barto, 2nd edition, Fig. 8.5.

    python demos/shortcut_exploration.py
    python demos/shortcut_exploration.py --check
    python demos/shortcut_exploration.py --replot   # redraw from curves.csv

Simulation uses Python's standard library. Drawing requires matplotlib.
Map, task and algorithms: Sutton & Barto §8.3. Hyperparameters follow
Shangtong Zhang and Kenta Shimada, chapter08/maze.py, figure_8_5.
Our random streams, switch timing, metrics and independently written
implementation are specified below. Rewards in outputs always come from step().
"""
import argparse
import csv
import json
import math
import random
import statistics
from collections import deque
from pathlib import Path

ROWS, COLS = 6, 9
ACTIONS = ((-1, 0), (0, 1), (1, 0), (0, -1))
START, GOAL, GAP = 5 * COLS + 3, 8, 3 * COLS + 8
CHANGE, HORIZON = 3000, 6000
ALPHA, GAMMA, EPSILON, KAPPA, N_PLAN = 1., .95, .1, .001, 50
DEFAULT_OUTPUT = Path(__file__).resolve().parents[1] / "assets" / "shortcut-exploration"
METHODS = ("Dyna-Q", "Dyna-Q+")


def step(state, action, open_gap):
    """One deterministic real transition; the terminal state has zero tail."""
    row, col = divmod(state, COLS)
    dr, dc = ACTIONS[action]
    r = max(0, min(ROWS - 1, row + dr))
    c = max(0, min(COLS - 1, col + dc))
    blocked = r == 3 and c >= 1 and not (open_gap and c == 8)
    successor = state if blocked else r * COLS + c
    return successor, int(successor == GOAL)


class Model:
    """Uniformly sample a known state, then a modeled action at that state."""
    def __init__(self, plus):
        self.plus = plus
        self.states = []
        self.actions = {}
        self.records = {}

    def observe(self, s, a, r, successor, real_step):
        if s not in self.actions:
            self.states.append(s)
            self.actions[s] = []
            if self.plus:
                for untried in range(4):
                    self.actions[s].append(untried)
                    self.records[s, untried] = (0, s, 0)
        if (s, a) not in self.records:
            self.actions[s].append(a)
        self.records[s, a] = (r, successor, real_step)

    def simulate(self, rng, clock):
        s = rng.choice(self.states)
        a = rng.choice(self.actions[s])
        r, successor, last_real_step = self.records[s, a]
        if self.plus:
            r += KAPPA * math.sqrt(clock - last_real_step)
        return s, a, r, successor


def choose(values, rng):
    if rng.random() < EPSILON:
        return rng.randrange(4)
    best = max(values)
    return rng.choice([a for a, v in enumerate(values) if v == best])


def update(q, s, a, r, successor):
    tail = 0. if successor == GOAL else GAMMA * max(q[successor])
    q[s][a] += ALPHA * (r + tail - q[s][a])


def train(method, seed):
    action_rng = random.Random(2 * seed)
    model_rng = random.Random(2 * seed + 1)
    q = [[0.] * 4 for _ in range(ROWS * COLS)]
    model = Model(method == "Dyna-Q+")
    s, gap_entry_side = START, None
    events = []
    cumulative = [0]
    first_entry = first_crossing = None
    for t in range(1, HORIZON + 1):
        action = choose(q[s], action_rng)
        successor, reward = step(s, action, open_gap=t > CHANGE)
        update(q, s, action, reward, successor)
        model.observe(s, action, reward, successor, t)
        for _ in range(N_PLAN):
            update(q, *model.simulate(model_rng, t))

        if reward:
            events.append((t, "goal"))
        cumulative.append(cumulative[-1] + reward)
        if s != GAP and successor == GAP:
            gap_entry_side = s // COLS
            if first_entry is None:
                first_entry = t
                events.append((t, "first_entry"))
        if s == GAP and successor != GAP:
            if first_crossing is None and gap_entry_side == 4 and successor // COLS == 2:
                first_crossing = t
                events.append((t, "first_upward_crossing"))
            gap_entry_side = None
        s = START if successor == GOAL else successor
    assert cumulative[-1] == sum(event == "goal" for _, event in events)
    assert first_entry is None or first_entry > CHANGE
    assert first_crossing is None or CHANGE < first_entry < first_crossing
    return cumulative, events, first_entry, first_crossing


def shortest_path(open_gap):
    queue = deque([(START, 0)])
    visited = {START}
    while queue:
        s, distance = queue.popleft()
        if s == GOAL:
            return distance
        for a in range(4):
            successor, _ = step(s, a, open_gap)
            if successor not in visited:
                visited.add(successor)
                queue.append((successor, distance + 1))
    raise AssertionError("The goal must be reachable")


def checks():
    assert shortest_path(False) == 16 and shortest_path(True) == 10
    below = GAP + COLS
    assert step(below, 0, False) == (below, 0)
    assert step(below, 0, True) == (GAP, 0)
    assert step(GAP, 0, True) == (GAP - COLS, 0)
    for plus in (False, True):
        model = Model(plus)
        model.observe(START, 0, 0, START - COLS, 1)
        assert len(model.actions[START]) == (4 if plus else 1)
        initial = dict(model.records)
        for _ in range(8):
            model.simulate(random.Random(_), 10)
        assert model.records == initial
        if plus:
            assert model.records[START, 1] == (0, START, 0)
    q = [[0.] * 4 for _ in range(ROWS * COLS)]
    q[GOAL] = [40.] * 4
    update(q, GOAL - 1, 1, 1, GOAL)
    assert q[GOAL - 1][1] == 1


# 11-21 审阅站请求 r1121-112759（第 8 章 p466）：图内字体改用课件字体（Latin Modern Sans + FandolHei），
# 图幅缩小到 6.4x1.85 英寸，课件中按 12.7cm 宽显示（缩放约 .78），刻度约 7.8pt、标签约 8.6pt。
# 原 save_figure（STHeiti/PingFang，9.1x2.45 英寸，显示时刻度约 4.5pt）保留在下面注释里。
# def save_figure(out, curves):
#     import matplotlib
#     matplotlib.use("Agg")
#     import matplotlib.pyplot as plt
#     from matplotlib.font_manager import fontManager
#     fonts = {entry.name for entry in fontManager.ttflist}
#     family = next((f for f in ("PingFang SC", "Heiti TC", "Noto Sans CJK SC", "WenQuanYi Zen Hei") if f in fonts), None)
#     if family:
#         plt.rcParams["font.family"] = family
#     plt.rcParams["axes.unicode_minus"] = False
#     fig, (left, right) = plt.subplots(1, 2, figsize=(9.1, 2.45), constrained_layout=True)
#     for method, color, style in zip(METHODS, ("#b7472d", "#006c74"), ("--", "-")):
#         data = [r for r in curves if r[0] == method]
#         left.plot([r[1] for r in data], [r[2] for r in data], style, color=color, lw=2.1, label=method)
#         post = [r for r in data if r[1] >= CHANGE]
#         right.step([r[1] for r in post], [100*r[3] for r in post], where="post",
#                    ls=style, color=color, lw=2.1)
#     left.axvline(CHANGE, lw=1, ls=":", color="#444")
#     left.set(xlim=(0,HORIZON), ylim=(0,None), xticks=[0,1500,3000,4500,6000])
#     right.set(xlim=(CHANGE,HORIZON), ylim=(-3,103), xticks=[3000,4000,5000,6000],
#               yticks=[0,50,100])
#     left.set_title("累计环境奖励（到达终点次数）" if family else "Cumulative environment reward", fontsize=12)
#     right.set_title("已向上穿过新缺口的运行（%）" if family else "Runs crossing upward through gap (%)", fontsize=12)
#     for ax in (left,right):
#         ax.set_xlabel("真实环境步" if family else "Real environment steps", fontsize=10)
#         ax.spines[["right","top"]].set_visible(False)
#         ax.grid(axis="y", color="#d3d9da", lw=.6)
#         ax.tick_params(labelsize=9)
#     left.legend(frameon=False, fontsize=10, loc="upper left")
#     for ext in ("png", "pdf"):
#         meta = {"CreationDate": None, "ModDate": None} if ext == "pdf" else {}
#         fig.savefig(out / ("shortcut." + ext), dpi=175, metadata=meta)
#     plt.close(fig)


def save_figure(out, curves):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import sys
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    from plot_fonts import use_course_fonts
    use_course_fonts()
    plt.rcParams["axes.unicode_minus"] = False
    fig, (left, right) = plt.subplots(1, 2, figsize=(6.4, 1.85), constrained_layout=True)
    for method, color, style in zip(METHODS, ("#b7472d", "#006c74"), ("--", "-")):
        data = [r for r in curves if r[0] == method]
        left.plot([r[1] for r in data], [r[2] for r in data], style, color=color, lw=1.7, label=method)
        post = [r for r in data if r[1] >= CHANGE]
        right.step([r[1] for r in post], [100*r[3] for r in post], where="post",
                   ls=style, color=color, lw=1.7)
    left.axvline(CHANGE, lw=.9, ls=":", color="#444")
    left.set(xlim=(0,HORIZON), ylim=(0,None), xticks=[0,1500,3000,4500,6000])
    right.set(xlim=(CHANGE,HORIZON), ylim=(-3,103), xticks=[3000,4000,5000,6000],
              yticks=[0,50,100])
    left.set_title("累计环境奖励（到达终点次数）", fontsize=11)
    right.set_title("已向上穿过新缺口的运行（%）", fontsize=11)
    for ax in (left,right):
        ax.set_xlabel("真实环境步", fontsize=11)
        ax.spines[["right","top"]].set_visible(False)
        ax.grid(axis="y", color="#d3d9da", lw=.6)
        ax.tick_params(labelsize=10)
    left.legend(frameon=False, fontsize=10.5, loc="upper left")
    for ext in ("png", "pdf"):
        meta = {"CreationDate": None, "ModDate": None} if ext == "pdf" else {}
        fig.savefig(out / ("shortcut." + ext), dpi=200, metadata=meta)
    plt.close(fig)


def replot(out):
    """Redraw shortcut.pdf/png from the saved curves.csv without rerunning."""
    with (out / "curves.csv").open() as f:
        rows = list(csv.reader(f))[1:]
    curves = [(m, int(t), float(r), float(c)) for m, t, r, c in rows]
    save_figure(out, curves)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--seeds", type=int, default=20)
    parser.add_argument("--check", action="store_true")
    parser.add_argument("--replot", action="store_true",
                        help="redraw the figure from OUT/curves.csv only")
    args = parser.parse_args()
    if args.replot:
        replot(args.out)
        return
    checks()
    if args.check:
        print("Maze geometry, terminal target, model coverage, planning clock: OK")
        return
    if args.seeds < 1:
        parser.error("--seeds must be positive")
    args.out.mkdir(parents=True, exist_ok=True)
    summary = {"geometry": "6x9, row 3 blocked at columns 1..8 until step 3000 inclusive, then 1..7; start (5,3), goal (0,8)",
               "parameters": dict(gamma=GAMMA, alpha=ALPHA, epsilon=EPSILON, kappa=KAPPA,
                                  real_steps=HORIZON, planning_per_real_step=N_PLAN,
                                  seeds=list(range(args.seeds))), "results": {}}
    all_events, runs, curves = [], [], []
    for method in METHODS:
        rewards, crossings = [], []
        for seed in range(args.seeds):
            cumulative, events, entry, crossing = train(method, seed)
            rewards.append(cumulative)
            crossings.append(crossing)
            all_events.extend((method,seed,*event) for event in events)
            runs.append((method,seed,cumulative[CHANGE],cumulative[-1]-cumulative[CHANGE],
                         cumulative[-1],entry,crossing))
        for t in range(HORIZON+1):
            mean = statistics.fmean(path[t] for path in rewards)
            fraction = sum(c is not None and c <= t for c in crossings) / args.seeds
            curves.append((method,t,mean,fraction))
        subset = [r for r in runs if r[0] == method]
        lags = [c-CHANGE for c in crossings if c is not None]
        summary["results"][method] = dict(
            mean_pre=statistics.fmean(r[2] for r in subset),
            mean_post=statistics.fmean(r[3] for r in subset),
            mean_total=statistics.fmean(r[4] for r in subset),
            entered=sum(r[5] is not None for r in subset), crossed=len(lags),
            median_crossing_delay_among_crossers=statistics.median(lags) if lags else None)
    for name, header, rows in [
        ("events.csv",("method","seed","real_step","event"),all_events),
        ("runs.csv",("method","seed","reward_steps_1_3000","reward_steps_3001_6000",
                     "reward_total","first_real_gap_entry","first_real_upward_crossing"),runs),
        ("curves.csv",("method","real_step","mean_cumulative_environment_reward",
                       "fraction_of_runs_crossed_upward"),curves)]:
        with (args.out / name).open("w", newline="") as f:
            writer = csv.writer(f)
            writer.writerow(header)
            writer.writerows(rows)
    (args.out / "results.json").write_text(json.dumps(summary, indent=2) + "\n")
    save_figure(args.out, curves)
    print(json.dumps(summary["results"], indent=2))


if __name__ == "__main__":
    main()
