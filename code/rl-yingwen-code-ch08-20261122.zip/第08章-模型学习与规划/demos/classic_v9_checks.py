"""Independent checks for v9 chapters 2–8; no training or old-output writes.
Run from any directory: python /path/to/demos/classic_v9_checks.py
"""
from pathlib import Path
import json, math, sys
sys.path.insert(0,str(Path(__file__).parent))
import mud_world as env
from classic_foundations import exact, backup

def run():
    report={}
    report['adaptive_mean'] = .5*1+.25*0+.25*.5
    assert report['adaptive_mean']==.625
    raw=merged=0
    for s in env.STATES:
        for a in env.ACTIONS:
            o=env.outcomes(s,a); raw+=len(o)
            atoms={}
            for p,sp,r,d in o: atoms[sp,r,d]=atoms.get((sp,r,d),0)+p
            assert abs(sum(atoms.values())-1)<1e-12
            merged+=sum(p>0 for p in atoms.values())
    assert (raw,merged)==(32,30)
    report['model_terms']={'raw_branches':raw,'distinct_joint_atoms':merged,'state_action_queries':28}
    vstar=exact(env.OLD); v={s:0. for s in env.STATES}; table=[]
    for k in range(1,21):
        v={s:backup(v,s,env.OLD[s]) for s in env.STATES}
        if k in (6,10,20):
            residual=max(abs(backup(v,s,env.OLD[s])-v[s]) for s in env.STATES)
            error=max(abs(v[s]-vstar[s]) for s in env.STATES)
            assert error<=residual/(1-env.GAMMA)+1e-12
            table.append({'k':k,'residual':residual,'error':error,'bound':residual/(1-env.GAMMA)})
    report['dp_stopping']=table
    report['td_drift']={'mean_delta':.9*(-.05)+.1*.5,'actual_error':10/19-.5,'drift_factor':1-.9*.9}
    assert abs(report['td_drift']['mean_delta']-.19*(10/19-.5))<1e-14
    report['constant_step']=[{'alpha':a,'last5_weight':1-(1-a)**5,'variance_factor':a/(2-a)} for a in (.1,.2,.5)]
    # Exact four-transition specified sample; advance clock after T without another env call.
    S=['S7','S4','S4','S4','G']; R=[0,0,0,1]; T=4
    report['nstep']={}
    for n in (1,3,6):
        V={s:0. for s in env.STATES};V['S7']=.4;V['S4']=.5
        env_calls=0;updates=[];t=0
        while True:
            if t<T: env_calls+=1
            tau=t-n+1
            if tau>=0:
                h=min(tau+n,T)
                target=sum(.9**(i-tau-1)*R[i-1] for i in range(tau+1,h+1))
                if tau+n<T: target+=.9**n*V[S[h]]
                V[S[tau]]+=.2*(target-V[S[tau]])
                updates.append({'clock':t,'tau':tau,'target':target})
            if tau==T-1:break
            t+=1
        assert env_calls==4 and [x['tau'] for x in updates]==list(range(T))
        report['nstep'][n]={'environment_calls':env_calls,'updates':updates,'values':V}
    assert abs(report['nstep'][3]['updates'][0]['target']-.3645)<1e-12
    # Absorbing terminal padding conserves probability; does not add real actions.
    d={s:0. for s in env.STATES};d['G']=0;d['S7']=1.;dist=[]
    for k in range(1,4):
        new={s:0. for s in d}
        for s,p in d.items():
            if s=='G':new['G']+=p;continue
            for prob,sp,r,done in env.outcomes(s,env.OLD[s]):new[sp]+=p*prob
        d=new;assert abs(sum(d.values())-1)<1e-12
        dist.append({'k':k,**{s:p for s,p in d.items() if p}})
    report['absorbing_distribution']=dist
    report['mean_model']={'E_X1':0.,'E_X2':1.,'m_E_X1':0.}
    report['extended_actions']={'up_until_G':{'mean_duration':11.,'expected_discounted_return':9/19},'detour_until_G':{'mean_duration':6.,'expected_discounted_return':.9**5}}
    report['mc_variance']=.1/(1-.9**3)-(10/19)**2
    # Full expected updates, alpha=1; pick largest current residual (priority recomputed).
    Q={(s,a):0. for s in env.STATES for a in env.ACTIONS}
    def target(s,a):return sum(p*(r+(0 if done else .9*max(Q[sp,b] for b in env.ACTIONS))) for p,sp,r,done in env.outcomes(s,a))
    count=0
    while True:
        pair=max(Q,key=lambda sa:abs(target(*sa)-Q[sa]));err=abs(target(*pair)-Q[pair])
        if err<1e-12:break
        Q[pair]=target(*pair);count+=1
        assert count<10000
    optimum=exact(env.NEW)
    assert max(abs(max(Q[s,a] for a in env.ACTIONS)-optimum[s]) for s in env.STATES)<1e-10
    report['priority_exact']={'updates':count,'max_value_error':max(abs(max(Q[s,a] for a in env.ACTIONS)-optimum[s]) for s in env.STATES)}
    out=Path(__file__).resolve().parents[1]/'assets/v9-classic';out.mkdir(parents=True,exist_ok=True)
    (out/'checks.json').write_text(json.dumps(report,indent=2))
    print(json.dumps(report,indent=2))
if __name__=='__main__':run()
