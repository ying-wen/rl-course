"""Reproducible chapter 2–8 derivations on the unchanged mud task.
Standard library. Run from any directory; writes assets/classic-v10/.
Exact trajectory enumeration, linear solves, and actual MC samples are labelled.
"""
from pathlib import Path
import json, math, random
import mud_world as env
from classic_foundations import solve, exact, backup
OUT=Path(__file__).resolve().parents[1]/'assets/classic-v10'

def evaluate(policy):
    """Linear solve for a stationary stochastic policy; nonterminal matrix."""
    states=env.STATES;pos={s:i for i,s in enumerate(states)}
    A=[[float(i==j) for j in range(len(states))] for i in range(len(states))];b=[0.]*len(states)
    for s in states:
        for a,pa in policy[s].items():
            for prob,sp,r,done in env.outcomes(s,a):
                b[pos[s]]+=pa*prob*r
                if not done:A[pos[s]][pos[sp]]-=env.GAMMA*pa*prob
    return dict(zip(states,solve(A,b)))

def enumerate_prefix(policy,start,horizon=300):
    mass={start:1.};value=0.
    for t in range(horizon):
        nxt={}
        for s,p in mass.items():
            for a,pa in policy[s].items():
                for prob,sp,r,done in env.outcomes(s,a):
                    w=p*pa*prob;value+=env.GAMMA**t*w*r
                    if not done:nxt[sp]=nxt.get(sp,0)+w
        mass=nxt
    # Nonnegative terminal reward <=1: omitted discounted tail bounded by gamma^H.
    return value,env.GAMMA**horizon

def episode(first,rng):
    s='S7';a=first;G=0.;steps=0
    while True:
        u=rng.random();total=0.;selected=env.outcomes(s,a)[-1]
        for row in env.outcomes(s,a):
            total+=row[0]
            if u<total:selected=row;break
        _,sp,r,done=selected;G+=env.GAMMA**steps*r;steps+=1
        if done:return G,steps
        s=sp;a=env.OLD[s]
        assert steps<100000

def run():
    OUT.mkdir(exist_ok=True,parents=True);report={}
    # Derivatives checked by central differences of explicit sums over outcomes.
    p=.4
    risk=lambda u:.5*((1-p)*u*u+p*(1-u)**2)
    for u in [.1,.4,.75]:
        numerical=(risk(u+1e-6)-risk(u-1e-6))/2e-6
        assert abs(numerical-(u-p))<1e-9
    data=[1.,1.,0.,1.];mean=sum(data)/len(data)
    assert mean==.75 and sum(mean-x for x in data)==0
    (OUT/'mean-risk.dat').write_text('u population empirical\n'+'\n'.join(f'{i/100} {risk(i/100)} {sum(.5*(i/100-x)**2 for x in data)/4}' for i in range(101)))
    report['bandit_risk']={'q':p,'sample_rewards':data,'sample_minimizer':mean}
    # Distinct state action and environment probabilities, then independent solve/enumeration.
    policy={s:{a:1.} for s,a in env.OLD.items()};policy['S4']={'up':.75,'down':.25}
    truth=evaluate(policy);enum,tail=enumerate_prefix(policy,'S4')
    assert abs(enum-truth['S4'])<=tail+1e-12
    atoms={}
    for a,pa in policy['S4'].items():
        for prob,sp,r,done in env.outcomes('S4',a):atoms[sp,r]=atoms.get((sp,r),0)+pa*prob
    assert all(abs(atoms[k]-v)<1e-12 for k,v in {( 'S4',0.):.9,('G',1.):.075,('S7',0.):.025}.items())
    report['joint_branches']={'policy_at_S4':policy['S4'],'atoms':[dict(state=s,reward=r,probability=p) for (s,r),p in atoms.items()],'linear_values':truth,'prefix_value':enum,'tail_bound':tail}
    # DP residual -> q intervals -> certified action comparison.
    old=exact(env.OLD);v=dict.fromkeys(env.STATES,0.);rows=[]
    for k in range(1,21):
        v={s:backup(v,s,env.OLD[s]) for s in env.STATES}
        if k in [6,10,20]:
            residual=max(abs(backup(v,s,env.OLD[s])-v[s]) for s in env.STATES)
            radius=.9*residual/(1-.9)
            q={a:backup(v,'S7',a) for a in ['up','left']}
            for a,x in q.items():assert abs(x-backup(old,'S7',a))<=radius+1e-12
            rows.append(dict(k=k,residual=residual,q_radius=radius,q=q,observed_gap=q['left']-q['up'],certified=q['left']-q['up']>2*radius))
    assert rows[-1]['certified'] and not rows[0]['certified']
    report['dp_action_intervals']=rows
    # Conditional update distribution at a frozen current V(S4)=.5.
    rows=[]
    for alpha in [1.,.2]:
        support=[(.9,.5+alpha*(.9*.5-.5)),(.1,.5+alpha*(1-.5))]
        m=sum(p*x for p,x in support);var=sum(p*(x-m)**2 for p,x in support)
        assert abs(m-(.5+alpha*(.1-.19*.5)))<1e-12
        rows.append(dict(alpha=alpha,support=support,mean=m,variance=var,mean_error_factor=1-.19*alpha))
    report['td_one_visit']=rows
    # Real independent exploring-start episodes, fixed continuation OLD.
    rng=random.Random(7);G={a:[] for a in ['up','left']};steps={a:0 for a in G};checkpoints=[]
    for n in range(1,2001):
        for a in G:
            g,st=episode(a,rng);G[a].append(g);steps[a]+=st
        if n in [20,200,2000]:
            q={a:sum(xs)/len(xs) for a,xs in G.items()};rad=math.sqrt(math.log(12/.05)/(2*n))
            chosen=max(q,key=q.get);gap=q['left']-q['up']
            checkpoints.append(dict(episodes_per_action=n,environment_steps=sum(steps.values()),Q=q,hoeffding_radius=rad,chosen=chosen,certified_left=gap>2*rad))
    assert checkpoints[-1]['chosen']=='left' and checkpoints[-1]['certified_left']
    report['mc_action_estimates']={'seed':7,'fixed_continuation':'OLD','simultaneous_failure_bound':.05,'checkpoints':checkpoints,'true_q':{a:backup(old,'S7',a) for a in G}}
    (OUT/'mc-action-estimates.dat').write_text('n up left radius\n'+'\n'.join(f"{x['episodes_per_action']} {x['Q']['up']} {x['Q']['left']} {x['hoeffding_radius']}" for x in checkpoints))
    # IS on actual mud trajectories: a geometric family + one deterministic detour.
    target={s:{a:1.} for s,a in env.OLD.items()};target['S7']={'up':.8,'left':.2}
    target_value=evaluate(target)['S7'];weighted=0.;mass=0.
    for k in range(500):
        pb=.5*.9**k*.1;rho=.8/.5;g=.9**(k+1)
        weighted+=pb*rho*g;mass+=pb*rho
    weighted+=.5*(.2/.5)*.9**5;mass+=.5*(.2/.5)
    assert abs(weighted-target_value)<1e-12 and abs(mass-1)<1e-12
    report['mud_IS']={'target_value_linear_solve':target_value,'trajectory_enumeration_weighted_return':weighted,'weighted_mass':mass,'behavior_value':.5*backup(old,'S7','up')+.5*backup(old,'S7','left')}
    # Exhaustive finite tree vs independent repeated Bellman expectations.
    cases={1:[(.1,1.),(.9,.45)],2:[(.1,1.),(.09,.9),(.81,.405)]};nrows=[]
    for n,items in cases.items():
        m=sum(p*y for p,y in items);second=sum(p*y*y for p,y in items);mse=sum(p*(y-old['S4'])**2 for p,y in items)
        v=dict(old);v['S4']=.5
        for _ in range(n):v={s:backup(v,s,env.OLD[s]) for s in env.STATES}
        assert abs(m-v['S4'])<1e-12
        nrows.append(dict(n=n,support=items,mean=m,variance=second-m*m,bias=m-old['S4'],mse=mse))
    assert abs(nrows[1]['bias'])<abs(nrows[0]['bias']) and nrows[1]['variance']>nrows[0]['variance']
    report['nstep_distributions']=nrows
    # Specified Dyna search-control schedule. Only the real transition changes C.
    Q={(s,a):0. for s in env.STATES for a in env.ACTIONS};C={('S1','right','S2',0.):1,('S3','up','S1',0.):1};alpha=.2
    def update(s,a,r,sp,done):
        before=Q[s,a];y=r+(0 if done else .9*max(Q[sp,c] for c in env.ACTIONS));Q[s,a]+=alpha*(y-before)
        return dict(s=s,a=a,before=before,target=y,after=Q[s,a])
    real=update('S2','right',1.,'G',True);C['S2','right','G',1.]=1
    qdirect={s:max(Q[s,a] for a in env.ACTIONS) for s in env.STATES}
    schedule=[('S1','right',0.,'S2',False),('S3','up',0.,'S1',False),('S2','right',1.,'G',True)]
    simulated=[update(*args) for args in schedule]
    assert sum(C.values())==3 and abs(Q['S1','right']-.036)<1e-12 and abs(Q['S3','up']-.00648)<1e-12 and abs(Q['S2','right']-.36)<1e-12
    report['dyna_schedule']={'alpha':alpha,'previous_real_records':2,'new_real_transitions':1,'model_calls':3,'count_after_planning':sum(C.values()),'real_update':real,'direct_maxQ':qdirect,'planning_updates':simulated,'final_maxQ':{s:max(Q[s,a] for a in env.ACTIONS) for s in env.STATES}}
    (OUT/'derivations.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
    print(json.dumps(report,ensure_ascii=False,indent=2))
if __name__=='__main__':run()
