#!/usr/bin/env python3
"""One-update scientific diagrams for chapters 7--11; no training runs.

Run from any directory. Only assets/v18-methods (or --out) is written.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, FancyArrowPatch

ROOT = Path(__file__).resolve().parents[1]
TEAL, RED, GOLD, INK, MUTED = '#087E8B', '#C65335', '#C4942A', '#182E38', '#61757D'
plt.rcParams.update({'font.size': 16, 'axes.labelsize': 17, 'xtick.labelsize': 15,
                     'ytick.labelsize': 15, 'axes.spines.top': False,
                     'axes.spines.right': False, 'text.color': INK,
                     'axes.labelcolor': INK, 'pdf.fonttype': 42})


def save(fig, out, name):
    fig.savefig(out/f'{name}.pdf', bbox_inches='tight')
    fig.savefig(out/f'{name}.png', bbox_inches='tight', dpi=180)
    plt.close(fig)


def trace_control(out):
    import course15_traces as traces
    features = np.array([[1., 0.], [0., 1.], [0., 1.], [0., 1.], [0., 0.]])
    rewards = np.array([0., 0., 0., 1.])
    # These two coordinates are Q(S7,up),Q(S4,up). All selected actions are up.
    z = np.zeros(2); q = np.zeros(2); rows = []
    for t, r in enumerate(rewards):
        delta = r+.9*(q@features[t+1])-q@features[t]
        z = .9*.8*z+features[t]; q += .2*delta*z
        rows.append({'t':t,'delta':float(delta),'z':z.tolist(),'q':q.tolist()})
    forward, _ = traces.frozen_forward(np.array([0,1,1,1]), rewards, np.zeros(2), .2, .9, .8)
    # On this zero selected-Q trajectory the only nonzero error is terminal.
    np.testing.assert_allclose(q, forward, atol=1e-14)
    np.testing.assert_allclose(q, [.0746496, .44768], atol=1e-14)
    old = np.array([0., 0., 0., .05]); td0 = old.copy(); new = old.copy(); new[0] = q[0]
    assert old.argmax()==3 and new.argmax()==0
    eps=.2
    probs=lambda a: np.eye(4)[a]*(1-eps)+eps/4
    np.testing.assert_allclose(probs(3), [.05,.05,.05,.85])
    np.testing.assert_allclose(probs(0), [.85,.05,.05,.05])
    fig, (ax, bx) = plt.subplots(1,2,figsize=(9,2.7),gridspec_kw={'width_ratios':[.9,1.6]})
    from mud_world import POSITIONS
    for state,(x,y) in POSITIONS.items():
        yy=2-y
        ax.add_patch(Rectangle((x,yy),1,1,facecolor='#F6E5CA' if state=='S4' else '#EAF4F3',edgecolor=MUTED))
        ax.text(x+.05,yy+.73,state,fontsize=14)
    ax.add_patch(Rectangle((1,1),1,1,color=INK))
    ax.annotate('',(2.75,1.25),(2.75,.45),arrowprops={'arrowstyle':'->','lw':2.5,'color':TEAL})
    ax.annotate('',(2.75,2.25),(2.75,1.6),arrowprops={'arrowstyle':'->','lw':2.5,'color':TEAL})
    ax.add_patch(FancyArrowPatch((2.72,1.37),(2.72,1.67),connectionstyle='arc3,rad=-1.6',arrowstyle='->',color=TEAL,lw=2))
    ax.text(3.05,1.5,'2 stays',fontsize=15,va='center')
    ax.set(xlim=(-.05,4.1),ylim=(-.05,3.05),aspect='equal');ax.axis('off')
    x=np.arange(4);width=.23
    bx.bar(x-width,old,width,label='initial',color=MUTED,alpha=.45)
    bx.bar(x,td0,width,label='Sarsa(0)',color=GOLD)
    bx.bar(x+width,new,width,label=r'$\lambda=.8$',color=TEAL)
    bx.set_xticks(x,['up','right','down','left']);bx.set_ylim(0,.13);bx.set_yticks([0,.05,.1])
    bx.set_ylabel(r'$Q(S_7,a)$');bx.legend(frameon=False,fontsize=14,ncol=3,loc='upper center')
    bx.text(.23,q[0]+.002,f'{q[0]:.5f}',ha='center',fontsize=16)
    bx.text(3,.053,'.05',ha='center',fontsize=16)
    fig.tight_layout();save(fig,out,'sarsa-control')
    return {'trajectory':['S7','S4','S4','S4','G'],'rows':rows,
            'q_S7_before':old.tolist(),'q_S7_after':new.tolist(),
            'epsilon':eps,'policy_before':probs(3).tolist(),'policy_after':probs(0).tolist()}


def planning_budget(out):
    # Retained historical table, not a new Dyna run. SD is not a confidence bound.
    budgets=np.array([0,5,20]);means=np.array([.379,.355,.308]);sd=np.array([.200,.249,.269])
    updates=1500*(1+budgets)
    np.testing.assert_array_equal(updates,[1500,9000,31500])
    fig,(ax,bx)=plt.subplots(1,2,figsize=(9,3.0))
    x=np.arange(3)
    ax.errorbar(x,means,yerr=sd,fmt='o-',color=TEAL,capsize=5,lw=2)
    ax.set(xticks=x,xticklabels=budgets,xlabel='planning / real step',ylabel=r'true $v_{\pi}(S_7)$',ylim=(0,.68))
    ax.set_title('1500 real steps; mean ± SD',fontsize=15)
    bx.bar(x,updates/1000,color=[MUTED,TEAL,GOLD],width=.55)
    for xx,n in zip(x,updates):bx.text(xx,n/1000+.4,f'{n:,}',ha='center',fontsize=15)
    bx.set(xticks=x,xticklabels=budgets,xlabel='planning / real step',ylabel='Q updates (thousands)',ylim=(0,37))
    fig.tight_layout();save(fig,out,'planning-budget')
    return {'data_origin':'retained slides/learning-37.tex table, historical10-seed Dyna run',
            'planning_per_real_step':budgets.tolist(),'mean':means.tolist(),'seed_sd':sd.tolist(),
            'real_transitions':1500,'q_updates':updates.tolist()}


def model_update():
    probability=np.array([.9,.1]);target=np.array([.45,1.]);current=.4;alpha=.2
    expected_target=probability@target;sample_updates=current+alpha*(target-current)
    expected_update=current+alpha*(expected_target-current)
    np.testing.assert_allclose(sample_updates,[.41,.52],atol=1e-14)
    np.testing.assert_allclose(probability@sample_updates,expected_update,atol=1e-14)
    return {'expected_target':float(expected_target),'sample_new_q':sample_updates.tolist(),
            'expected_new_q':float(expected_update)}


def one_step_distribution():
    P=np.array([[0.,1.,0.],[0.,.9,.1],[0.,0.,1.]])
    r=np.array([0.,.1,0.]);d0=np.array([1.,0.,0.]);d=d0.copy();value=0.;rows=[]
    for k in range(6):
        value += .9**k*(d@r);d=d@P
        direct=sum(.1*.9**j*.9**(j+1)for j in range(k))
        np.testing.assert_allclose(value,direct,atol=1e-14)
        np.testing.assert_allclose(d,d0@np.linalg.matrix_power(P,k+1),atol=1e-14)
        np.testing.assert_allclose(d.sum(),1.,atol=1e-14)
        rows.append({'steps':k+1,'distribution':d.tolist(),'prefix_return':float(value)})
    return {'state_order':['S7','S4','G'],'rows':rows,'recursive_code_matches_explicit_distribution':True}


def ppo_snapshot():
    old=.5;theta=.5;current=1/(1+np.exp(-theta));old_logp=np.log(old)
    ratio=np.exp(np.log(current)-old_logp)
    wrong=np.exp(np.log(current)-np.log(current))
    np.testing.assert_allclose([current,ratio,wrong],[.6224593312018546,1.2449186624037092,1.],atol=1e-14)
    assert ratio>1.2
    return {'old_probability':old,'current_probability':float(current),'frozen_denominator_ratio':float(ratio),
            'recomputed_denominator_ratio':float(wrong)}


def pg_occupancy():
    import sample14_pg
    p,q,gamma=.5,.25,.9
    local0=(1-p)*1*(-p)+p*(gamma*(1+2*q))*(1-p)
    local1=(1-q)*1*(-q)+q*3*(1-q)
    eta=np.array([1.,gamma*p]);gradient=eta*np.array([local0,local1])
    enumerated=sample14_pg.enumerate_gradient(sample14_pg.INITIAL)
    np.testing.assert_allclose(gradient,enumerated,atol=1e-14)
    np.testing.assert_allclose(gradient,[.0875,.16875],atol=1e-14)
    return {'discounted_visit_weights':eta.tolist(),'local_nonzero_components':[local0,local1],
            'gradient':gradient.tolist(),'independent_trajectory_enumeration':enumerated.tolist()}


def semigradient(out):
    states=np.arange(1,20);group=np.where(states<=6,0,np.where(states<=13,1,2));X=np.eye(3)[group]
    w=np.array([-.4,.2,.7]);x,xp=X[5],X[6];delta=(xp-x)@w;alpha=.1
    semi=w+alpha*delta*x;full=w+alpha*delta*(x-xp)
    np.testing.assert_allclose(semi,[-.34,.2,.7]);np.testing.assert_allclose(full,[-.34,.14,.7])
    def loss(q):return .5*((xp-x)@q)**2
    h=1e-6;fd=np.array([(loss(w+h*e)-loss(w-h*e))/(2*h)for e in np.eye(3)])
    np.testing.assert_allclose(w-alpha*fd,full,atol=1e-10)
    fig,ax=plt.subplots(figsize=(9,2.5))
    ax.axvspan(.5,6.5,color=TEAL,alpha=.045);ax.axvspan(6.5,13.5,color=GOLD,alpha=.045)
    ax.axhline(0,color=MUTED,lw=1,label=r'initial $\Delta=0$')
    ax.step(states,X@(semi-w),where='mid',color=TEAL,lw=3,label='semi-gradient')
    ax.step(states,X@(full-w),where='mid',color=RED,lw=2.5,ls='--',label='full gradient')
    ax.scatter([6,7],[.06,-.06],s=28,color=[TEAL,RED],zorder=5)
    ax.axvline(6.5,color=MUTED,lw=.7,ls=':')
    ax.text(3.5,.015,r'$+.06$',ha='center',color=TEAL,fontsize=16)
    ax.text(10,-.04,r'$-.06$ (full)',ha='center',color=RED,fontsize=16)
    ax.set(xlim=(.5,19.5),ylim=(-.09,.11),xlabel='state',ylabel=r'$\Delta\hat v(s)$',xticks=[1,6,7,13,14,19],yticks=[-.06,0,.06])
    ax.legend(frameon=False,ncol=3,fontsize=14,loc='upper left');fig.tight_layout();save(fig,out,'semigradient-values')
    return {'initial':w.tolist(),'delta':float(delta),'alpha':alpha,'semi':semi.tolist(),'full':full.tolist(),
            'gradient_fd_error':float(np.max(np.abs(fd-delta*(xp-x))))}


def dqn_one_update(out):
    import dqn_model_v11 as dqn
    net=dqn.MLP(np.random.default_rng(0));before=net.forward(dqn.FEATURES)
    state=dqn.INDEX[(3,4)];action=1;next_state,reward,terminal=dqn.transition(state,action)
    assert next_state==dqn.GOAL and reward==1 and terminal
    size=32;batch=np.repeat(dqn.FEATURES[state][None],size,axis=0)
    actions=np.full(size,action);targets=np.full(size,1.)
    old_parameters=[p.copy()for p in net.p];loss,grads=net.loss_grad(batch,actions,targets)
    # Independently verify a shared-output-weight derivative on this fixed target.
    ix=(0,action);old=net.p[2][ix];h=1e-6
    net.p[2][ix]=old+h;plus=net.loss_grad(batch,actions,targets)[0]
    net.p[2][ix]=old-h;minus=net.loss_grad(batch,actions,targets)[0];net.p[2][ix]=old
    error=abs((plus-minus)/(2*h)-grads[2][ix]);assert error<1e-8
    net.update(batch,actions,targets);after=net.forward(dqn.FEATURES);change=after-before
    assert change[state,action]>0 and np.max(np.abs(change[:,[0,2,3]]))>1e-6
    fig,(ax,bx)=plt.subplots(1,2,figsize=(9,2.9),gridspec_kw={'width_ratios':[1.1,1.]})
    x=np.arange(4)
    ax.bar(x-.18,before[state],.36,label='before',color=MUTED,alpha=.5)
    ax.bar(x+.18,after[state],.36,label='after 1 Adam step',color=TEAL)
    ax.axhline(0,color=MUTED,lw=.6);ax.set_xticks(x,['up','right','down','left']);ax.set_ylabel(r'$Q(s,a)$')
    ax.set_title('recorded action: right, reward 1',fontsize=14)
    ax.legend(frameon=False,fontsize=14)
    arr=np.full((5,5),np.nan)
    for i,(xx,yy) in enumerate(dqn.STATES):
        if i!=dqn.GOAL:arr[yy,xx]=change[i,action]
    limit=np.nanmax(abs(arr));cmap=plt.get_cmap('coolwarm').copy();cmap.set_bad('#182E38')
    im=bx.imshow(arr,origin='lower',extent=(-.5,4.5,-.5,4.5),vmin=-limit,vmax=limit,cmap=cmap)
    bx.add_patch(Rectangle((3.5,3.5),1,1,facecolor='#EAF4F3',edgecolor=MUTED));bx.text(4,4,'G',ha='center',va='center',fontsize=16)
    bx.scatter([3],[4],facecolors='none',edgecolors=INK,s=190,lw=1.5)
    bx.annotate('',(3.78,4),(3.18,4),arrowprops={'arrowstyle':'->','lw':1.7,'color':INK})
    bx.set_xticks([]);bx.set_yticks([]);bx.set_title(r'$\Delta Q(u,\mathrm{right})$',fontsize=16)
    fig.colorbar(im,ax=bx,shrink=.84,pad=.03).ax.tick_params(labelsize=12)
    fig.tight_layout();save(fig,out,'dqn-one-update')
    return {'seed':0,'state':[3,4],'action':'right','transition':[state,action,reward,next_state,terminal],
            'batch':'32 copies of one observed terminal transition, controlled one-update calculation',
            'optimizer':'existing MLP Adam, learning rate .001, first update',
            'q_before':before[state].tolist(),'q_after':after[state].tolist(),
            'delta_q_all_states':change.tolist(),'parameter_gradient_fd_error':error,
            'loss_before':loss,'loss_after':net.loss_grad(batch,actions,targets)[0]}


def sac_queries(out):
    # Numeric actions from the retained seed7 single-update walkthrough.
    x=.8;recorded=-.4;xp=x+.25*recorded;reward=-(xp*xp+.03*recorded**2)
    np.testing.assert_allclose([xp,reward],[.7,-.4948],atol=1e-14)
    retained=json.loads((ROOT/'assets/sample14-sac/results.json').read_text())['walkthrough']
    actor=retained['fresh_action'];successor=retained['next_action']
    np.testing.assert_allclose(reward,retained['reward'],atol=1e-14)
    target=reward+retained['gamma']*(retained['target_min_q']-retained['alpha_before']*retained['next_logp'])
    np.testing.assert_allclose(target,retained['target_y'],atol=1e-7)
    from matplotlib import font_manager
    old_family=plt.rcParams['font.family']
    for font in ['/System/Library/Fonts/PingFang.ttc','/System/Library/Fonts/STHeiti Light.ttc']:
        if Path(font).exists():
            font_manager.fontManager.addfont(font)
            plt.rcParams['font.family']=font_manager.FontProperties(fname=font).get_name()
            break
    fig=plt.figure(figsize=(9,3.0));gs=fig.add_gridspec(2,2,height_ratios=[1.,1.])
    ax=fig.add_subplot(gs[0,:]);ax.axhline(0,color=MUTED,lw=1.4)
    ax.axvline(0,color=TEAL,lw=2);ax.text(0,.2,r'目标 $x$ = 0',ha='center',color=TEAL,fontsize=16,bbox={'fc':'white','ec':'none','pad':1})
    ax.scatter([x,xp],[0,0],s=45,color=[MUTED,INK]);ax.annotate('',(xp,.1),(x,.1),arrowprops={'arrowstyle':'->','color':INK,'lw':2})
    ax.text(x+.015,-.2,r'$x$ = .8',ha='left',fontsize=16);ax.text(xp-.015,-.2,r'$x^{\prime}$ = .7',ha='right',fontsize=16)
    ax.text(.4,.32,r'已执行 $a$ = −.4，奖励 $r$ = −.4948',ha='center',fontsize=16)
    ax.set(xlim=(-.1,1.05),ylim=(-.4,.55));ax.axis('off')
    for col,title,action,color in [(0,r'在 $s$ = (.8, 1) 查询 $\widetilde a$',actor,TEAL),(1,r'在 $s^{\prime}$ = (.7, 11/12) 查询 $\widetilde a^{\prime}$',successor,RED)]:
        bx=fig.add_subplot(gs[1,col]);bx.axhline(0,color=MUTED,lw=1)
        bx.set(xlim=(-1.07,1.07),ylim=(-.3,.45),xticks=[-1,0,1],yticks=[])
        bx.spines['left'].set_visible(False);bx.set_title(title,fontsize=15)
        bx.scatter([action],[0],s=60,color=color,marker='D');bx.text(action,.15,f'{action:.4f}',ha='center',color=color,fontsize=16)
        if col==0:
            bx.scatter([recorded],[0],s=40,color=MUTED);bx.text(recorded,-.2,r'记录的 $a$ = −.4',ha='center',color=MUTED,fontsize=14)
        bx.set_xlabel('动作（仅查询评论者，未执行）',fontsize=14)
    fig.tight_layout();save(fig,out,'sac-three-actions')
    plt.rcParams['font.family']=old_family
    return {'retained_walkthrough':'demos/sample14_sac.py walkthrough seed7; not rerun torch',
            'x':x,'recorded_action':recorded,'observed_x_next':xp,'reward':reward,
            'fresh_actor_action':actor,'fresh_successor_action':successor,
            'independently_recomputed_target':float(target),'stored_float32_target':retained['target_y']}


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--out',type=Path,default=ROOT/'assets/v18-methods')
    args=parser.parse_args();args.out.mkdir(parents=True,exist_ok=True)
    result={'validation_layer':'finite one-update calculations and historical-data redraw; no training runs',
            'trace_control':trace_control(args.out),'model_update':model_update(),
            'one_step_distribution':one_step_distribution(),'planning_budget':planning_budget(args.out),
            'semigradient':semigradient(args.out),'dqn_one_update':dqn_one_update(args.out),
            'sac_queries':sac_queries(args.out),'ppo_snapshot':ppo_snapshot(),
            'pg_occupancy':pg_occupancy(),'all_executed_checks_passed':True}
    import v17_methods
    result['preserved_math_checks']={k:getattr(v17_methods,k)() for k in
        ['lambda_weights','model_decisions','planning_residuals','weighting_and_projection',
         'fitted_q_and_multistep','performance_difference','gae_critic_error','soft_values']}
    (args.out/'report.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'figures':5,'new_finite_calculation_groups':9,'preserved_math_groups':8,
                      'all_executed_checks_passed':True,'output':str(args.out)},ensure_ascii=False))


if __name__=='__main__':main()
