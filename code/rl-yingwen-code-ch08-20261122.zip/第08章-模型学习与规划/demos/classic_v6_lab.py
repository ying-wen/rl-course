"""Visible learning states for chapters 2--8. Local, small, reproducible runs.
Run: python3 demos/classic_v6_lab.py
Dependencies for figures: matplotlib. Numerical environment: unchanged mud_world.py.
No true transition probabilities or exact values enter model-free updates.
"""
from pathlib import Path
import json,random,math,argparse
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
import mud_world as env
from classic_foundations import exact
parser=argparse.ArgumentParser()
parser.add_argument('--initial-q',type=float,default=1.)
parser.add_argument('--control-alpha',type=float,default=.05)
parser.add_argument('--output',type=Path,default=Path(__file__).resolve().parents[1]/'assets/v6-classic')
ARGS=parser.parse_args()
if not 0 < ARGS.control_alpha <= 1:parser.error('--control-alpha must lie in (0,1]')
if not math.isfinite(ARGS.initial_q):parser.error('--initial-q must be finite')
OUT=ARGS.output
OUT.mkdir(parents=True,exist_ok=True)
A=list(env.ACTIONS);G=env.GAMMA
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':12,'savefig.dpi':180})
def step(s,a,rng):
    u=rng.random();mass=0
    for p,n,r,d in env.outcomes(s,a):
        mass+=p
        if u<mass:return n,r,d
    raise AssertionError('probability mass')
def greedy(q,s):return max(A,key=lambda a:q[s,a])
def choose(q,s,rng,eps=.2):
    if rng.random()<eps:return rng.choice(A)
    best=max(q[s,a] for a in A)
    return rng.choice([a for a in A if q[s,a]==best])
def grid(ax,v,policy=None,known=None,title=''):
    for x in range(3):
        for y in range(3):
            s=env.AT.get((x,y));color='#203842' if not s else '#f1f3f4'
            if s and s!='G' and (known is None or s in known):color=plt.cm.GnBu(.1+.6*max(0,min(v.get(s,0),1)))
            ax.add_patch(Rectangle((x,y),1,1,facecolor=color,edgecolor='#71818a',lw=.8))
            if s:
                ax.text(x+.07,y+.15,s,va='center',fontsize=10,color='#203842')
                label='terminal' if s=='G' else (f'{v.get(s,0):.3f}' if known is None or s in known else 'unvisited')
                ax.text(x+.5,y+.48,label,ha='center',fontsize=12 if label not in ['unvisited','terminal'] else 9)
                if policy and s!='G':
                    dx,dy=env.ACTIONS[policy[s]];ax.arrow(x+.5-dx*.1,y+.79-dy*.1,dx*.22,dy*.22,head_width=.085,head_length=.07,color='#087e8b',length_includes_head=True)
    ax.set(xlim=(0,3),ylim=(3,0));ax.set_aspect('equal');ax.axis('off');ax.set_title(title,pad=9,fontsize=12)
def save(fig,name):fig.savefig(OUT/name,bbox_inches='tight',facecolor='white');plt.close(fig)
# 1: selected-arm data, estimate and behavior probabilities.
rng=random.Random(7);q=[0.,0.];n=[0,0];snaps=[];wins=0
for t in range(2000):
    if rng.random()<.1:a=rng.randrange(2)
    else:a=rng.choice([j for j in range(2) if q[j]==max(q)])
    reward=float(rng.random()<[.4,.6][a]);wins+=reward;n[a]+=1;q[a]+=(reward-q[a])/n[a]
    if t+1 in [20,200,2000]:
        ties=[j for j in range(2) if q[j]==max(q)];pi=[.05,.05]
        for j in ties:pi[j]+=.9/len(ties)
        snaps.append({'steps':t+1,'Q':q.copy(),'N':n.copy(),'behavior':pi})
fig,axs=plt.subplots(1,3,figsize=(9.2,2.7))
for ax,z in zip(axs,snaps):
    ax.bar([0,1],z['Q'],color=['#809ba6','#087e8b'],width=.5)
    ax.scatter([0,1],[.4,.6],marker='_',s=500,color='#c65335',label='true mean')
    for i in range(2):ax.text(i,z['Q'][i]+.035,f"N={z['N'][i]}",ha='center',fontsize=10)
    ax.set(xticks=[0,1],xticklabels=['A','B'],ylim=(0,1),title=f"{z['steps']} pulls")
    ax.text(.5,.95,f"P(B)={z['behavior'][1]:.2f}",ha='center',transform=ax.transAxes,fontsize=10)
    ax.spines[['top','right']].set_visible(False)
axs[0].set_ylabel('estimated success probability');axs[-1].legend(fontsize=9,loc='lower right');save(fig,'bandit-estimates.png')
# 2: fixed OLD policy, exact same episodes for first-visit sample-average MC and TD(.05).
rng=random.Random(7);mc=dict.fromkeys(env.STATES,0.);td=mc.copy();counts=dict.fromkeys(env.STATES,0);pred=[];ret=[];env_steps=0
for ep in range(1,501):
    traj=env.rollout(env.OLD,rng);env_steps+=len(traj);returns=[];g=0
    for s,reward,nxt,done in reversed(traj):g=reward+G*g;returns.append(g)
    returns.reverse();ret.append(returns[0]);seen=set()
    for (s,reward,nxt,done),g in zip(traj,returns):
        target=reward+(0 if done else G*td[nxt]);td[s]+=.05*(target-td[s])
        if s not in seen:seen.add(s);counts[s]+=1;mc[s]+=(g-mc[s])/counts[s]
    if ep in [1,10,500]:pred.append({'episodes':ep,'environment_steps':env_steps,'MC':mc.copy(),'TD':td.copy(),'first_visit_counts':counts.copy()})
fig,axs=plt.subplots(1,3,figsize=(9,3.1))
for ax,z,key,title in [(axs[0],pred[0],'TD','TD: 1 episode'),(axs[1],pred[-1],'MC','MC: 500 episodes'),(axs[2],pred[-1],'TD','TD: 500 episodes')]:grid(ax,z[key],env.OLD,{'S7','S4'},title)
save(fig,'prediction-values.png')
fig,ax=plt.subplots(figsize=(7,2.6));ax.hist(ret,bins=[i/20 for i in range(21)],weights=[1/500]*500,color='#82bac2',edgecolor='white');ax.axvline(9/19,color='#c65335',lw=2,label='exact expected return 9/19');ax.axvline(sum(ret)/len(ret),color='#087e8b',lw=2,ls='--',label='sample mean');ax.set(xlabel='return from S7',ylabel='fraction of 500 episodes');ax.legend(fontsize=9);save(fig,'return-distribution.png')
# 3: value control. Each method has its own real interactive stream and empirical model.
def control(plan):
    rng=random.Random(7);q={(s,a):ARGS.initial_q for s in env.STATES for a in A};model={};s='S7';snapshots=[];reward_sum=0
    def update(s,a,nxt,r,done):q[s,a]+=ARGS.control_alpha*(r+(0 if done else G*max(q[nxt,c] for c in A))-q[s,a])
    for t in range(1,20001):
        a=choose(q,s,rng);nxt,r,done=step(s,a,rng);update(s,a,nxt,r,done);reward_sum+=r
        outcomes=model.setdefault((s,a),{});key=(nxt,r,done);outcomes[key]=outcomes.get(key,0)+1
        for _ in range(plan):
            u,c=rng.choice(list(model));items=list(model[u,c]);weights=[model[u,c][x] for x in items];v,re,d=rng.choices(items,weights=weights,k=1)[0];update(u,c,v,re,d)
        s='S7' if done else nxt
        if t in [100,1000,20000]:
            policy={u:greedy(q,u) for u in env.STATES};pv=exact(policy)
            snapshots.append({'environment_steps':t,'Q':{u:{a:q[u,a] for a in A} for u in env.STATES},'greedy_policy':policy,'greedy_policy_exact_values':pv,'Q_max':{u:max(q[u,a] for a in A) for u in env.STATES},'mud_up_counts':{str(k):v for k,v in model.get(('S4','up'),{}).items()},'cumulative_real_reward':reward_sum})
    return snapshots
ctrl=control(0);dyna=control(5)
fig,axs=plt.subplots(1,3,figsize=(9,3.1))
for ax,z in zip(axs,ctrl):grid(ax,z['Q_max'],z['greedy_policy'],title=f"{z['environment_steps']} real steps")
save(fig,'control-policies.png')
fig,axs=plt.subplots(1,2,figsize=(7,3.1));grid(axs[0],dyna[-1]['Q_max'],dyna[-1]['greedy_policy'],title='Dyna: learned max Q');grid(axs[1],dyna[-1]['greedy_policy_exact_values'],dyna[-1]['greedy_policy'],title='frozen policy: exact value');save(fig,'dyna-policy.png')
# 4: one actual prescribed episode isolates eligibility propagation.
ss=['S7','S4','S4','S4','G'];rr=[0,0,0,1];trace_results={}
for lam in [0.,.8]:
    v=dict.fromkeys(env.STATES,0.);z=v.copy()
    for s,re,nxt in zip(ss,rr,ss[1:]):
        delta=re+G*(0 if nxt=='G' else v[nxt])-v[s]
        z={u:G*lam*z[u] for u in z};z[s]+=1
        for u in v:v[u]+=.2*delta*z[u]
    trace_results[str(lam)]=v
assert abs(trace_results['0.8']['S7']-.0746496)<1e-12
assert abs(trace_results['0.8']['S4']-.44768)<1e-12
fig,axs=plt.subplots(1,2,figsize=(7,3.1));grid(axs[0],trace_results['0.0'],known={'S7','S4'},title='TD(0): one episode');grid(axs[1],trace_results['0.8'],known={'S7','S4'},title='TD(.8): same episode');save(fig,'trace-write.png')
report={'seed':7,'gamma':G,'environment_file':'mud_world.py (unchanged)','action_order':A,'bandit':{'steps':2000,'epsilon':.1,'means':[.4,.6],'snapshots':snaps,'total_reward':wins},'prediction':{'episodes':500,'TD_alpha':.05,'MC':'first visit sample mean 1/N','snapshots':pred,'sample_return_mean':sum(ret)/len(ret),'exact_return_mean':9/19},'control':{'steps':20000,'alpha':ARGS.control_alpha,'epsilon':.2,'initial_Q':ARGS.initial_q,'tie_break':'uniform during learning; first up,right,down,left during frozen evaluation','snapshots':ctrl},'dyna':{'steps':20000,'planning_updates_per_real_step':5,'alpha':ARGS.control_alpha,'epsilon':.2,'initial_Q':ARGS.initial_q,'model':'empirical joint counts over next_state,reward,termination','snapshots':dyna},'trace':{'trajectory':ss,'rewards':rr,'alpha':.2,'initial_values':0,'results':trace_results},'evaluation':'Exact model is used only to evaluate the frozen greedy policy; it is never given to model-free training.'}
(OUT/'results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print(json.dumps({'bandit_Q':snaps[-1]['Q'],'prediction_MC_S7':mc['S7'],'Q_greedy_value':ctrl[-1]['greedy_policy_exact_values']['S7'],'Dyna_greedy_value':dyna[-1]['greedy_policy_exact_values']['S7'],'output':str(OUT)},ensure_ascii=False))
