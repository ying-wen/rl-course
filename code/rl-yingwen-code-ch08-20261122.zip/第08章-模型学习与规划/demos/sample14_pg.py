"""REINFORCE on the two-decision task used in Chapter 11.

Run: python sample14_pg.py --out ../assets/sample14-pg
Only numpy and matplotlib are required. All paths default relative to this file.

The learner receives sampled (state, action, reward) records. exact_value and
enumerate_gradient are independent teaching checks, never training labels.
Gamma=.9; pi(continue|s0)=sigmoid(theta[0]); pi(high|s1)=sigmoid(theta[1]).
One update uses a batch collected with a fixed policy, and differentiates at
that same parameter version. This makes the displayed estimator exact.
"""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import numpy as np

GAMMA = .9
INITIAL = np.array([0., np.log(1/3)])


def sigmoid(theta):
    return 1/(1+np.exp(-np.asarray(theta)))


def exact_value(theta):
    """Analysis only: enumerate the three possible terminal outcomes."""
    p, q = sigmoid(theta)
    return (1-p) + GAMMA*p*(1+2*q)


def exact_gradient(theta):
    p, q = sigmoid(theta)
    return np.array([p*(1-p)*(GAMMA*(1+2*q)-1),
                     2*GAMMA*p*q*(1-q)])


def episode(theta, rng):
    """Execute actions; the learner never receives probabilities of outcomes."""
    p, q = sigmoid(theta)
    if rng.random() >= p:
        return [(0, 0, 1.)]               # stop: reward 1, then terminal
    high = int(rng.random() < q)
    return [(0, 1, 0.), (1, high, 1.+2*high)]


def discounted_returns(records):
    """G_t = R_(t+1) + gamma G_(t+1), evaluated only after termination."""
    result = np.zeros(len(records))
    tail = 0.
    for t in reversed(range(len(records))):
        tail = records[t][2] + GAMMA*tail
        result[t] = tail
    return result


def reinforce_gradient(theta, records, baseline=None):
    """One episode: sum gamma**t (G_t-b(S_t)) grad log pi(A_t|S_t).

    The Bernoulli score in the visited coordinate is action-probability.
    The baseline is fixed before these actions are drawn.
    """
    probabilities = sigmoid(theta)
    baseline = np.zeros(2) if baseline is None else np.asarray(baseline)
    returns = discounted_returns(records)
    gradient = np.zeros(2)
    for t, (state, action, _) in enumerate(records):
        score = action-probabilities[state]
        gradient[state] += GAMMA**t * (returns[t]-baseline[state]) * score
    return gradient


def enumerate_gradient(theta, baseline=None):
    """Check the estimator by summing all three trajectories independently."""
    p, q = sigmoid(theta)
    paths = [[(0,0,1.)], [(0,1,0.),(1,0,1.)], [(0,1,0.),(1,1,3.)]]
    weights = [1-p, p*(1-q), p*q]
    return sum(w*reinforce_gradient(theta,path,baseline) for w,path in zip(weights,paths))


def train(seed, batches=300, batch_size=32, step_size=.2):
    rng = np.random.default_rng(seed)
    theta = INITIAL.copy()
    history = [[0, exact_value(theta), *sigmoid(theta)]]
    for k in range(1,batches+1):
        # Collect with theta fixed. Each returned trajectory is actual experience.
        paths = [episode(theta,rng) for _ in range(batch_size)]
        gradient = np.mean([reinforce_gradient(theta,path) for path in paths],axis=0)
        theta += step_size*gradient       # gradient ascent, not loss descent
        history.append([k*batch_size,exact_value(theta),*sigmoid(theta)])
    return np.asarray(history), theta


def checks():
    rows=[]
    for theta in [INITIAL, np.array([.7,-.3]), np.array([-1.,1.2])]:
        fd=np.array([(exact_value(theta+np.eye(2)[j]*1e-6)-exact_value(theta-np.eye(2)[j]*1e-6))/2e-6 for j in range(2)])
        direct=exact_gradient(theta)
        enumerated=enumerate_gradient(theta)
        baseline=enumerate_gradient(theta,[1.1,2.3])
        assert np.max(abs(fd-direct))<1e-8
        assert np.max(abs(enumerated-direct))<1e-12
        assert np.max(abs(baseline-direct))<1e-12
        rows.append({'theta':theta.tolist(),'finite_difference':fd.tolist(),
                     'analytic':direct.tolist(),'enumerated':enumerated.tolist()})
    # Dropping the outer gamma is a detectable error for the second coordinate.
    assert abs(exact_gradient(INITIAL)[1]-.16875)<1e-12
    high=[(0,1,0.),(1,1,3.)]
    g=reinforce_gradient(INITIAL,high)
    assert np.allclose(g,[1.35,2.025])
    new=INITIAL+.1*g
    return {'all_passed':True,'checks':rows,'single_high_episode':{
        'gamma':GAMMA,'returns':discounted_returns(high).tolist(),
        'gradient':g.tolist(),'theta_before':INITIAL.tolist(),'theta_after':new.tolist(),
        'probabilities_before':sigmoid(INITIAL).tolist(),
        'probabilities_after':sigmoid(new).tolist(),
        'J_before':float(exact_value(INITIAL)),'J_after':float(exact_value(new))}}


def torch_loss_check():
    """Optional executable counterpart of the negative-loss slide.

    Returns are sampled constants. Only log_prob differentiates through theta.
    Its descent direction must equal the independently computed ascent direction.
    """
    import torch
    theta=torch.tensor(INITIAL,dtype=torch.float64,requires_grad=True)
    records=[(0,1,0.),(1,1,3.)]
    states=torch.tensor([r[0] for r in records]);actions=torch.tensor([r[1] for r in records],dtype=torch.float64)
    distribution=torch.distributions.Bernoulli(logits=theta[states])
    log_prob=distribution.log_prob(actions)
    returns=torch.tensor(discounted_returns(records),dtype=torch.float64)
    discount=torch.tensor([GAMMA**t for t in range(len(records))],dtype=torch.float64)
    weight=discount*returns.detach()
    loss=-(weight*log_prob).sum() # One complete episode; N=1.
    loss.backward()
    expected=reinforce_gradient(INITIAL,records)
    assert np.allclose(-theta.grad.numpy(),expected,atol=1e-12)
    return {'negative_loss':float(loss.detach()),'loss_gradient':theta.grad.tolist(),
            'ascent_gradient':expected.tolist(),'all_passed':True}


def figures(out, runs):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    plt.rcParams.update({'font.size':13,'axes.spines.top':False,'axes.spines.right':False})
    teal,orange,gray='#087e8b','#c65335','#61757d'
    stack=np.stack(runs); steps=stack[0,:,0]
    fig,ax=plt.subplots(figsize=(8.7,3.6),layout='constrained')
    for run in stack:ax.plot(steps,run[:,1],color=teal,lw=.8,alpha=.18)
    ax.plot(steps,stack[:,:,1].mean(0),color=teal,lw=2.8,label='REINFORCE: mean of 12 seeds')
    ax.axhline(1.175,color=gray,ls='--',label='initial policy: p=.5, q=.25')
    ax.axhline(2.7,color=orange,ls=':',label='optimal deterministic return')
    ax.set(xlabel='sampled episodes',ylabel='exact expected discounted return',ylim=(1.,2.85))
    ax.legend(frameon=False,fontsize=10,loc='lower right')
    fig.savefig(out/'learning.pdf');fig.savefig(out/'learning.png',dpi=180);plt.close(fig)
    fig,axs=plt.subplots(1,2,figsize=(10.2,3.2),layout='constrained')
    for j,name in [(2,'continue at s0'),(3,'high at s1')]:
        axs[0].plot(steps,stack[:,:,j].mean(0),label=name,lw=2.5,color=teal if j==2 else orange)
    axs[0].set(xlabel='sampled episodes',ylabel='action probability',ylim=(0,1.05));axs[0].legend(frameon=False,fontsize=10)
    names=['stop','continue / low','continue / high']
    positions=np.arange(3)
    for dx,k,c,label in [(-.21,0,gray,'initial'),(.21,-1,teal,'learned')]:
        p=stack[:,k,2];q=stack[:,k,3]
        prob=np.array([1-p,p*(1-q),p*q]).mean(1)
        axs[1].bar(positions+dx,prob,width=.38,color=c,label=label)
    axs[1].set(xticks=positions,xticklabels=names,ylim=(0,1.05),ylabel='trajectory probability')
    axs[1].tick_params(axis='x',labelsize=10);axs[1].legend(frameon=False,fontsize=10)
    fig.savefig(out/'behavior.pdf');fig.savefig(out/'behavior.png',dpi=180);plt.close(fig)
    # Exact finite enumeration: colored contribution from each outcome, including negative.
    p,q=sigmoid(INITIAL)
    paths=[[(0,0,1.)],[(0,1,0.),(1,0,1.)],[(0,1,0.),(1,1,3.)]]
    weights=np.array([1-p,p*(1-q),p*q])
    contributions=np.array([w*reinforce_gradient(INITIAL,path) for w,path in zip(weights,paths)])
    fig,axs=plt.subplots(1,2,figsize=(10,3.1),layout='constrained')
    for j,ax in enumerate(axs):
        values=[*contributions[:,j],contributions[:,j].sum()]
        ax.bar(range(4),values,color=[gray,teal,orange,'#182e38'],width=.57)
        for i,v in enumerate(values):ax.text(i,v+(.015 if v>=0 else -.015),f'{v:.5f}',ha='center',va='bottom' if v>=0 else 'top',fontsize=11)
        ax.axhline(0,color='.7',lw=.7);ax.set(xticks=range(4),xticklabels=['stop','low','high','sum'],ylabel=f'gradient component {j}',ylim=(-.31,.31))
    fig.savefig(out/'enumeration.pdf');fig.savefig(out/'enumeration.png',dpi=180);plt.close(fig)
    plot_critic_error(out)


def plot_critic_error(out):
    """Mean one-step actor-critic direction for theta_0 as the successor prediction varies."""
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from matplotlib import font_manager
    teal,orange,gray='#087e8b','#c65335','#61757d'
    with plt.rc_context({'font.size':13,'axes.spines.top':False,'axes.spines.right':False,
                         'axes.unicode_minus':False,'pdf.fonttype':42}):
        for font in ['/System/Library/Fonts/PingFang.ttc','/System/Library/Fonts/STHeiti Light.ttc']:
            if Path(font).exists():
                font_manager.fontManager.addfont(font)
                plt.rcParams['font.family']=font_manager.FontProperties(fname=font).get_name()
                break
        value=np.linspace(0,2.6,201)
        direction=.25*(GAMMA*value-1)
        fig,ax=plt.subplots(figsize=(8.6,3.0),layout='constrained')
        ax.plot(value,direction,color=teal,lw=2.6,label='一步行动者–评论者的平均方向')
        ax.axhline(exact_gradient(INITIAL)[0],color=orange,ls='--',label=r'真实策略梯度 $\partial J/\partial\theta_0$')
        ax.axhline(0,color=gray,lw=1);ax.axvline(1.5,color=gray,ls=':')
        ax.scatter([0,1.5],[-.25,.0875],color=[orange,teal],s=40,zorder=4)
        ax.set(xlabel=r'评论者对后继状态的预测 $V_{\mathbf{w}}(s_1)$',ylabel=r'$\theta_0$ 的平均更新方向')
        ax.legend(frameon=False,fontsize=10,loc='lower right')
        fig.savefig(out/'critic-error.pdf');fig.savefig(out/'critic-error.png',dpi=180);plt.close(fig)


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--out',type=Path,default=Path(__file__).resolve().parents[1]/'assets/sample14-pg');ap.add_argument('--torch-check',action='store_true');args=ap.parse_args()
    out=args.out;out.mkdir(parents=True,exist_ok=True)
    report=checks();runs=[]
    if args.torch_check:report['torch_negative_loss']=torch_loss_check()
    for seed in range(12):
        run,theta=train(seed);runs.append(run);np.save(out/f'seed-{seed}.npy',run)
    report['training']={'seeds':list(range(12)),'episodes_per_seed':9600,'batch_size':32,'step_size':.2,
                        'final_J':[float(r[-1,1]) for r in runs],
                        'final_probabilities':[r[-1,2:].tolist() for r in runs]}
    (out/'results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
    figures(out,runs)
    print(json.dumps({'checks':report['all_passed'],'mean_final_J':float(np.mean([r[-1,1] for r in runs])), 'out':str(out)},ensure_ascii=False))


if __name__=='__main__':main()
