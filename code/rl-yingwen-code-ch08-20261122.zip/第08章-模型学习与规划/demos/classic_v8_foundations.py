"""Reproducible calculations for chapters 2--8 (standard library only).
Run: python3 demos/classic_v8_foundations.py
Outputs: assets/v8-classic/*.dat and results.json. The mud-world is unchanged.
The ensemble compares specified estimators, not optimally tuned algorithms.
"""
from pathlib import Path
import json, math, random
import mud_world as env
from classic_foundations import exact, solve, backup
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'assets/v8-classic'

def soft_evaluate(greedy, epsilon):
    states=env.STATES; a=[[float(i==j) for j in range(7)] for i in range(7)]; r=[0.]*7
    for i,s in enumerate(states):
        for act in env.ACTIONS:
            prob=epsilon/4+(1-epsilon if act==greedy[s] else 0)
            for p,nxt,reward,done in env.outcomes(s,act):
                r[i]+=prob*p*reward
                if not done:a[i][states.index(nxt)]-=prob*p*env.GAMMA
    return dict(zip(states,solve(a,r)))

def write_dat(name, columns, rows):
    (OUT/name).write_text(' '.join(columns)+'\n'+'\n'.join(' '.join(f'{v:.12g}' for v in row) for row in rows)+'\n')

def main():
    OUT.mkdir(parents=True,exist_ok=True); tests=[]
    def check(name,x,y,tol=1e-10):
        assert abs(x-y)<tol,(name,x,y);tests.append(name)
    old,new=exact(env.OLD),exact(env.NEW)
    check('geometric vs linear system',old['S4'],10/19)
    # Finite horizon: all rewards zero except entrance to G, no artificial timeout reward.
    v=dict.fromkeys(env.STATES,0.); horizon=[]
    for h in range(1,8):
        qs={s:{a:backup(v,s,a) for a in env.ACTIONS} for s in env.STATES}
        v={s:max(qs[s].values()) for s in env.STATES}
        horizon.append({'h':h,'value_S7':v['S7'],'up':qs['S7']['up'],'left':qs['S7']['left']})
    check('horizon 2',horizon[1]['value_S7'],.09)
    check('horizon 6',horizon[5]['value_S7'],.59049)
    # Expected online TD(lambda) vs frozen forward view on the existing four-transition sample.
    states=['S7','S4','S4','S4','G']; rewards=[0,0,0,1]; initial={'S7':.4,'S4':.5,'G':0.}
    def online_trace(replace=False):
        vals=initial.copy();z=dict.fromkeys(initial,0.)
        for s,r,nxt in zip(states,rewards,states[1:]):
            delta=r+.9*vals[nxt]-vals[s]
            z={u:.72*x for u,x in z.items()}
            if replace:z[s]=1.
            else:z[s]+=1.
            for u in vals:vals[u]+=.2*delta*z[u]
        return vals
    frozen_forward={s:0. for s in ['S7','S4']}
    for t,s in enumerate(states[:-1]):
        targets=[];length=4-t
        for n in range(1,length+1):
            targets.append(sum(.9**k*rewards[t+k] for k in range(n))+.9**n*initial[states[t+n]])
        gl=sum(.2*.8**(n-1)*targets[n-1] for n in range(1,length))+.8**(length-1)*targets[-1]
        frozen_forward[s]+=.2*(gl-initial[s])
    frozen_values={s:initial[s]+frozen_forward[s] for s in frozen_forward}
    traces={'frozen_forward':frozen_values,'online_accumulating':online_trace(),'online_replacing':online_trace(True)}
    assert abs(traces['online_accumulating']['S4']-frozen_values['S4'])>1e-4;tests.append('online and frozen updates differ at finite alpha')
    # Exact n-step target distribution at S4: K is the number of failed attempts before success.
    truth=10/19;rows=[]
    for n in range(1,21):
        mean=truth*(1-.81**n)+.5*.81**n
        second=.1*(1-.729**n)/(1-.729)+.25*.729**n
        variance=second-mean*mean;bias=mean-truth;mse=variance+bias*bias
        enumerated=sum(.1*.9**k*(.9**k-truth)**2 for k in range(n))+.9**n*(.5*.9**n-truth)**2
        check('n-step MSE enumeration '+str(n),mse,enumerated)
        rows.append([n,mean,bias*bias,variance,mse])
    write_dat('nstep-mse.dat',['n','mean','bias2','variance','mse'],rows)
    # Every-visit average within ONE episode has a random denominator (not pooled visits).
    per_episode_mean=sum(.1*.9**(m-1)*(1-.9**m)/(.1*m) for m in range(1,1000))
    assert abs(per_episode_mean-truth)>.05;tests.append('finite every-visit random-denominator bias')
    check('every-visit limiting cumulative ratio',(1/(1-.81))/(1/(1-.9)),truth)
    # MC first-visit running mean and TD(.05) on identical complete episodes, 80 seeds.
    checkpoints=[1,5,20,100,500];sums={n:[0.,0.] for n in checkpoints};runs=80
    for seed in range(runs):
        rng=random.Random(1000+seed);mc=0.;td={'S7':0.,'S4':0.,'G':0.}
        for ep in range(1,501):
            traj=env.rollout(env.OLD,rng)
            g=0.
            for _,r,_,_ in reversed(traj):g=r+.9*g
            mc+=(g-mc)/ep
            for s,r,nxt,done in traj:td[s]+=.05*(r+(0 if done else .9*td[nxt])-td[s])
            if ep in sums:
                sums[ep][0]+=(mc-old['S7'])**2;sums[ep][1]+=(td['S7']-old['S7'])**2
    ensemble=[[n,math.sqrt(sums[n][0]/runs),math.sqrt(sums[n][1]/runs),math.sqrt((.9**2*(.1/(1-.9**3)-(10/19)**2))/n)] for n in checkpoints]
    write_dat('prediction-rmse.dat',['episodes','mc','td','mc_theory'],ensemble)
    # Model estimation diagnosis explicitly permits independent trials from each chosen state-action.
    model_rows=[]
    for N in [10,100,1000]:
        rng=random.Random(7);counts={}
        for s in env.STATES:
            for a in env.ACTIONS:
                outcomes=env.outcomes(s,a);cs={}
                for _ in range(N):
                    u=rng.random();cum=0
                    for prob,nxt,r,done in outcomes:
                        cum+=prob
                        if u<cum:break
                    key=(nxt,r,done);cs[key]=cs.get(key,0)+1
                counts[s,a]=[(n/N,*key) for key,n in cs.items()]
        vals=dict.fromkeys(env.STATES,0.)
        for _ in range(1000):
            w={s:sum(p*(r+(0 if done else .9*vals[nxt])) for p,nxt,r,done in counts[s,env.OLD[s]]) for s in env.STATES}
            if max(abs(vals[s]-w[s]) for s in vals)<1e-13:break
            vals=w
        success=sum(p for p,nxt,r,done in counts['S4','up'] if done)
        expected=success/(1-.9*(1-success))
        check('learned model analytical self-loop '+str(N),vals['S4'],expected,1e-10)
        model_rows.append([N,success,vals['S4'],vals['S7']])
    # Explicit small max-bias distribution, no normal approximations.
    pairs=[(x,y) for x in [-.1,.1] for y in [-.1,.1]]
    check('maximum of noisy equal estimates',sum(max(x,y) for x,y in pairs)/4,.05)
    # Softmax gradient checked both by action/reward enumeration and independent finite differences.
    theta=[.2,-.1];q=[.4,.6]
    def obj(t):
        z=sum(math.exp(x) for x in t);return sum(math.exp(x)/z*r for x,r in zip(t,q))
    pi=[math.exp(x)/sum(math.exp(y) for y in theta) for x in theta]
    grad=[]
    for a in range(2):
        g=sum(pi[b]*q[b]*(float(a==b)-pi[a]) for b in range(2));hi=theta.copy();lo=theta.copy();hi[a]+=1e-5;lo[a]-=1e-5
        check('softmax gradient finite difference '+str(a),g,(obj(hi)-obj(lo))/2e-5,1e-9);grad.append(g)
    # Full gradient-bandit and UCB interaction loops (reward means hidden from learners).
    rng=random.Random(7);preferences=[0.,0.];baseline=0.;grad_points=[]
    for t in range(2000):
        weights=[math.exp(x-max(preferences)) for x in preferences];probs=[x/sum(weights) for x in weights]
        action=int(rng.random()>=probs[0]);reward=float(rng.random()<[.4,.6][action])
        increment=[.1*(reward-baseline)*(float(a==action)-probs[a]) for a in range(2)]
        preferences=[x+d for x,d in zip(preferences,increment)];baseline+=(reward-baseline)/(t+1)
        if t+1 in [1,10,100,500,2000]:grad_points.append([t+1,*probs,baseline])
    write_dat('gradient-bandit.dat',['step','prob_A','prob_B','reward_mean'],grad_points)
    rng=random.Random(7);ucb_q=[0.,0.];ucb_n=[0,0]
    for t in range(2000):
        a=t if t<2 else max(range(2),key=lambda x:ucb_q[x]+math.sqrt(2*math.log(t)/ucb_n[x]))
        reward=float(rng.random()<[.4,.6][a]);ucb_n[a]+=1;ucb_q[a]+=(reward-ucb_q[a])/ucb_n[a]
    assert sum(ucb_n)==2000 and min(ucb_n)>0;tests.append('full UCB initialization and finite budget')
    # Full Double Q loop, all choices/ties use the current declared behavior distribution.
    rng=random.Random(7);qa={s:{a:1. for a in env.ACTIONS} for s in env.STATES};qb={s:dict(v) for s,v in qa.items()};state='S7'
    def tied_argmax(values):
        top=max(values.values());return rng.choice([a for a,x in values.items() if x>=top-1e-12])
    for t in range(20000):
        action=rng.choice(list(env.ACTIONS)) if rng.random()<.2 else tied_argmax({a:qa[state][a]+qb[state][a] for a in env.ACTIONS})
        u=rng.random();mass=0
        for prob,nxt,reward,done in env.outcomes(state,action):
            mass+=prob
            if u<mass:break
        first,second=(qa,qb) if rng.random()<.5 else (qb,qa)
        target=reward if done else reward+.9*second[nxt][tied_argmax(first[nxt])]
        first[state][action]+=.05*(target-first[state][action]);state='S7' if done else nxt
    double_policy={s:tied_argmax({a:qa[s][a]+qb[s][a] for a in env.ACTIONS}) for s in env.STATES}
    double_value=exact(double_policy)
    assert all(math.isfinite(x) for table in [qa,qb] for row in table.values() for x in row.values());tests.append('Double Q finite values after 20000 real steps')
    result={'task':'unchanged mud_world.py; gamma=.9; terminal entrance reward1','checks':tests,'horizon':horizon,'trace_comparison':traces,'single_episode_every_visit_expectation':per_episode_mean,'mc_true_S4':truth,'prediction_ensemble':{'seeds':list(range(1000,1080)),'episodes':500,'TD_alpha':.05,'MC':'first-visit sample mean','rows':ensemble},'learned_model_rows':model_rows,'soft_policy_values':{'greedy':new,'epsilon_point_2':soft_evaluate(env.NEW,.2)},'gradient':grad,'gradient_bandit_points':grad_points,'ucb_run':{'Q':ucb_q,'N':ucb_n,'seed':7,'steps':2000},'double_q':{'Q_A':qa,'Q_B':qb,'policy':double_policy,'exact_policy_value':double_value,'seed':7,'steps':20000,'alpha':.05,'epsilon':.2,'initial_Q':1},'batch_td':{'S4':5/6,'S7':.75},'nstep_mse':rows}
    (OUT/'results.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'checks':len(tests),'every_visit_one_episode_mean':per_episode_mean,'trace_comparison':traces,'model_rows':model_rows,'soft_S7':result['soft_policy_values']['epsilon_point_2']['S7'],'ensemble':ensemble},indent=2))
if __name__=='__main__':main()
