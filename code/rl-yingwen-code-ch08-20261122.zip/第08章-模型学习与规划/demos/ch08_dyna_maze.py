"""Dyna-Q on the Sutton-Barto Dyna maze (Example 8.1), rerun for the course.

11-21 审阅站请求 r1121-112759（第 8 章 p439）。
Run: python3 demos/ch08_dyna_maze.py --runs 100 --figure assets/course31-classic/dyna-maze-cn.pdf

Setting follows Sutton and Barto (2018), Example 8.1: a 6 x 9 grid, start S at
row 2 col 0, goal G at row 0 col 8, seven blocked cells; reward +1 on reaching G,
0 otherwise; gamma=.95, alpha=.1, epsilon=.1; Q starts at 0, greedy ties are broken
at random; the deterministic model stores the last observed (r, s') for each
(s, a); planning picks a previously observed state at random, then an action
already taken there. Planning steps n = 0, 5, 50 per real step; 50 episodes.
The shortest path from S to G takes 14 steps.

First episode (11-22): before G is first reached every Q value is exactly 0 (all
targets are 0 + gamma * 0), so with random tie-breaking the epsilon-greedy agent
picks each of the four actions with probability 1/4 whatever n is: the first
episode is a uniform random walk from S to G. `--first-episode` solves the
hitting-time equations of that walk exactly (mean, standard deviation, P(T > 1700))
to compare with the "about 1700 steps" in the text of Example 8.1, whose curves
average 30 repetitions.
"""
import argparse
import json
import random
from pathlib import Path

ROWS, COLS = 6, 9
START, GOAL = (2, 0), (0, 8)
WALLS = {(1, 2), (2, 2), (3, 2), (4, 5), (0, 7), (1, 7), (2, 7)}
MOVES = ((-1, 0), (1, 0), (0, -1), (0, 1))
GAMMA, ALPHA, EPS = .95, .1, .1


def step(s, a):
    r, c = s[0] + MOVES[a][0], s[1] + MOVES[a][1]
    if not (0 <= r < ROWS and 0 <= c < COLS) or (r, c) in WALLS:
        r, c = s
    return (r, c), float((r, c) == GOAL)


def shortest():
    from collections import deque
    dist, q = {START: 0}, deque([START])
    while q:
        s = q.popleft()
        for a in range(4):
            t, _ = step(s, a)
            if t not in dist:
                dist[t] = dist[s] + 1
                q.append(t)
    return dist[GOAL]


def first_episode_walk(threshold=1700, reps=30):
    """Exact hitting time of the uniform random walk from START to GOAL."""
    import numpy as np
    cells = [(r, c) for r in range(ROWS) for c in range(COLS) if (r, c) not in WALLS]
    inner = [s for s in cells if s != GOAL]
    idx = {s: i for i, s in enumerate(inner)}
    Q = np.zeros((len(inner), len(inner)))
    for s in inner:
        for a in range(4):
            t, _ = step(s, a)
            if t != GOAL:
                Q[idx[s], idx[t]] += .25
    eye = np.eye(len(inner))
    k = idx[START]
    with np.errstate(all='ignore'):           # some BLAS builds warn spuriously in matmul
        N = np.linalg.inv(eye - Q)            # fundamental matrix
        mean = N.sum(axis=1)
        second = (2 * N - eye) @ mean         # E[T^2]
        sd = float(np.sqrt(second[k] - mean[k] ** 2))
        tail = float(np.linalg.matrix_power(Q, threshold)[k].sum())   # P(T > threshold)
    se = sd / np.sqrt(reps)
    print(f'first episode = uniform random walk over {len(cells)} states: '
          f'E[T]={mean[k]:.1f}, sd={sd:.1f}, P(T>{threshold})={tail:.3f}; '
          f'mean of {reps} runs has SE {se:.1f}, so {threshold} is '
          f'{(threshold - mean[k]) / se:.1f} SE above E[T]')
    return {'states': len(cells), 'mean': float(mean[k]), 'sd': sd,
            f'p_gt_{threshold}': tail, f'se_mean_of_{reps}': float(se)}


def run(n, episodes, seed):
    rng = random.Random(seed)
    q = {}
    model = {}

    def qv(s, a):
        return q.get((s, a), 0.0)

    def greedy(s):
        vals = [qv(s, a) for a in range(4)]
        m = max(vals)
        return rng.choice([a for a in range(4) if vals[a] == m])

    lengths = []
    for _ in range(episodes):
        s, steps = START, 0
        while s != GOAL:
            a = rng.randrange(4) if rng.random() < EPS else greedy(s)
            t, r = step(s, a)
            target = r + (0.0 if t == GOAL else GAMMA * max(qv(t, b) for b in range(4)))
            q[s, a] = qv(s, a) + ALPHA * (target - qv(s, a))
            model.setdefault(s, {})[a] = (r, t)
            for _ in range(n):
                ps = rng.choice(list(model))
                pa = rng.choice(list(model[ps]))
                pr, pt = model[ps][pa]
                tg = pr + (0.0 if pt == GOAL else GAMMA * max(qv(pt, b) for b in range(4)))
                q[ps, pa] = qv(ps, pa) + ALPHA * (tg - qv(ps, pa))
            s, steps = t, steps + 1
        lengths.append(steps)
    return lengths


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--runs', type=int, default=100)
    ap.add_argument('--episodes', type=int, default=50)
    ap.add_argument('--figure', type=Path)
    ap.add_argument('--json', type=Path)
    ap.add_argument('--first-episode', action='store_true',
                    help='only solve the first-episode random walk exactly')
    args = ap.parse_args()
    if args.first_episode:
        first_episode_walk()
        return
    best = shortest()
    assert best == 14, best
    out = {'shortest_path': best, 'runs': args.runs, 'episodes': args.episodes,
           'alpha': ALPHA, 'epsilon': EPS, 'gamma': GAMMA, 'mean_steps': {},
           'first_episode_walk': first_episode_walk()}
    for n in (0, 5, 50):
        allruns = [run(n, args.episodes, 1000 * n + k) for k in range(args.runs)]
        mean = [sum(r[e] for r in allruns) / args.runs for e in range(args.episodes)]
        out['mean_steps'][str(n)] = mean
        first_near = next((e + 1 for e, m in enumerate(mean) if m <= 1.2 * best), None)
        print(f'n={n}: ep1 {mean[0]:.0f}, ep2 {mean[1]:.0f}, ep3 {mean[2]:.1f}, ep5 {mean[4]:.1f}, '
              f'ep10 {mean[9]:.1f}, last {mean[-1]:.1f}; first episode within 20% of 14: {first_near}')
    if args.json:
        args.json.write_text(json.dumps(out, indent=1))
    if args.figure:
        draw(out, args.figure)


def draw(out, path):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from plot_fonts import use_course_fonts, CJK_FAMILY
    use_course_fonts()
    # 图按 1:1 放进课件（宽 5.2 英寸），刻度 7pt、标签 8pt 即为页上字号。
    fig, (mz, ax) = plt.subplots(1, 2, figsize=(5.2, 1.6), gridspec_kw={'width_ratios': [1, 2.1]})
    # maze geometry
    for r in range(ROWS):
        for c in range(COLS):
            fc = '#3d4f57' if (r, c) in WALLS else 'white'
            mz.add_patch(plt.Rectangle((c, ROWS - 1 - r), 1, 1, facecolor=fc, edgecolor='#b9c4c8', lw=.5))
    mz.text(START[1] + .5, ROWS - 1 - START[0] + .5, 'S', ha='center', va='center', fontsize=8, weight='bold')
    mz.text(GOAL[1] + .5, ROWS - 1 - GOAL[0] + .5, 'G', ha='center', va='center', fontsize=8, weight='bold', color='#1f7a74')
    mz.set_xlim(0, COLS); mz.set_ylim(-1.6, ROWS + .1); mz.set_aspect('equal'); mz.axis('off')
    mz.text(COLS / 2, -.35, '迷宫：S 到 G 最短 14 步', ha='center', va='top', fontsize=8, fontfamily=CJK_FAMILY)
    colors = {'0': '#8a9aa0', '5': '#c8962e', '50': '#1f7a74'}
    eps = range(2, out['episodes'] + 1)
    for n, col in colors.items():
        m = out['mean_steps'][n][1:]
        ax.plot(list(eps), m, color=col, lw=1.4, label=f'$B={n}$')
    ax.axhline(14, color='#c0392b', lw=.8, ls='--')
    ax.text(out['episodes'], 13.4, '最短 14 步', color='#c0392b', ha='right', va='top', fontsize=7)
    m50 = out['mean_steps']['50'][2]
    ax.annotate(f'$B=50$ 第 3 回合 {m50:.0f} 步', xy=(3, m50), xytext=(7, 300), fontsize=7,
                fontfamily=CJK_FAMILY, arrowprops=dict(arrowstyle='->', lw=.7, color='#1f7a74'), color='#1f7a74')
    ax.set_yscale('log')
    ax.set_ylim(9, 900)
    ax.set_yticks([14, 50, 100, 200, 500])
    ax.set_yticklabels(['14', '50', '100', '200', '500'])
    ax.minorticks_off()
    ax.set_xlabel('回合', fontsize=8)
    ax.set_ylabel('每回合步数', fontsize=8)
    ax.tick_params(labelsize=7)
    ax.legend(fontsize=7, frameon=False, loc='upper right', handlelength=1.4, labelspacing=.25)
    for sp in ('top', 'right'):
        ax.spines[sp].set_visible(False)
    fig.tight_layout(pad=.3, w_pad=.6)
    fig.savefig(path)
    print('wrote', path)


if __name__ == '__main__':
    main()
