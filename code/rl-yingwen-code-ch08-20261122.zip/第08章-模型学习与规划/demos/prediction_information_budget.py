"""Matched real-interaction budgets for predicting a one-state episodic value.

Run: python3 demos/prediction_information_budget.py
For a successful action the one transition produces reward 1 and terminates.
After failure the reward is 0 and the next state is again S4. All estimators
see the same stream. An episode reset consumes no additional transition here.
"""
import argparse
import csv
import json
import math
import random
from pathlib import Path
from statistics import fmean

P, GAMMA = .1, .9
TRUTH = P / (1 - GAMMA * (1 - P))
BUDGETS = (8, 16, 32, 64, 128, 256, 512, 1024, 2048)
METHODS = ("TD(0)", "4-step TD", "MC", "Fitted model")
OUT = Path(__file__).resolve().parents[1] / "assets" / "prediction-information"


class ReturnMean:
    def __init__(self, depth):
        self.depth = depth  # None means use complete returns.
        self.value = 0.
        self.updates = 0
        self.pending = 0

    def learn(self, target):
        self.updates += 1
        self.value += (target - self.value) / self.updates

    def observe(self, terminal):
        self.pending += 1
        if terminal:
            # Flush oldest to newest. Only the final reward is nonzero.
            for delay in reversed(range(self.pending)):
                self.learn(GAMMA ** delay)
            self.pending = 0
        elif self.pending == self.depth:
            # All n rewards were zero. The n-th next state is again S4.
            self.learn(GAMMA ** self.depth * self.value)
            self.pending -= 1


def experiment(seeds=256):
    rows = []
    for seed in range(seeds):
        rng = random.Random(seed)
        predictors = [ReturnMean(n) for n in (1, 4, None)]
        successes = 0
        for step in range(1, BUDGETS[-1] + 1):
            terminal = rng.random() < P
            successes += terminal
            for learner in predictors:
                learner.observe(terminal)
            if step in BUDGETS:
                p_hat = successes / step
                fitted = p_hat / (1 - GAMMA * (1 - p_hat))
                rows.append([seed, step, successes, *(l.value for l in predictors), fitted])
    return rows


def summarize(rows):
    result = []
    for budget in BUDGETS:
        selected = [r for r in rows if r[1] == budget]
        for index, name in enumerate(METHODS, 3):
            values = [r[index] for r in selected]
            mean = fmean(values)
            sd = math.sqrt(fmean((v - mean) ** 2 for v in values))
            rmse = math.sqrt(fmean((v - TRUTH) ** 2 for v in values))
            assert math.isclose(rmse**2, (mean - TRUTH)**2 + sd**2)
            result.append(dict(budget=budget, method=name, bias=mean - TRUTH, sd=sd, rmse=rmse))
    return result


def plot(result):
    """Render the slide and web figure; the numerical experiment itself uses stdlib."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib import font_manager
    from matplotlib.ticker import ScalarFormatter
    installed = {font.name for font in font_manager.fontManager.ttflist}
    families = ("Hiragino Sans GB", "Noto Sans CJK SC", "Microsoft YaHei")
    cjk = next((family for family in families if family in installed), None)
    labels = ("TD(0)", "4 步 TD", "每次访问 MC", "拟合模型") if cjk else METHODS
    plt.rcParams.update({"font.family": [cjk or "DejaVu Sans", "DejaVu Sans"],
                         "svg.hashsalt": "prediction-information"})
    fig, ax = plt.subplots(figsize=(5.0, 2.85), layout="constrained")
    colors = ("#193d5d", "#007474", "#af512c", "#865b95")
    for method, label, color, marker in zip(METHODS, labels, colors, ("o", "s", "^", "D")):
        data = [row for row in result if row["method"] == method]
        ax.plot(BUDGETS, [row["rmse"] for row in data], color=color,
                marker=marker, label=label, markersize=4, linewidth=1.6)
    ax.set(xscale="log", yscale="log", xlabel="真实转移数 B" if cjk else "Real transitions B",
           ylabel="价值估计的 RMSE" if cjk else "Value estimate RMSE")
    ax.set_xticks(BUDGETS[::2])
    ax.set_yticks([.02, .05, .1, .2, .5])
    ax.xaxis.set_major_formatter(ScalarFormatter())
    ax.yaxis.set_major_formatter(ScalarFormatter())
    ax.minorticks_off()
    ax.grid(axis="y", color="#dce3e4", linewidth=.7)
    ax.spines[["top", "right"]].set_visible(False)
    ax.legend(frameon=False, fontsize=9, ncol=2)
    fig.savefig(OUT / "learning.pdf", metadata={"CreationDate": None, "ModDate": None})
    fig.savefig(OUT / "learning.svg", metadata={"Date": None})
    plt.close(fig)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--plot", action="store_true", help="also export PDF/SVG (matplotlib)")
    args = parser.parse_args()
    rows = experiment()
    result = summarize(rows)
    OUT.mkdir(parents=True, exist_ok=True)
    with (OUT / "predictions.csv").open("w", newline="") as out:
        writer = csv.writer(out)
        writer.writerow(["seed", "real_steps", "successes", *METHODS])
        writer.writerows(rows)
    (OUT / "runs.json").write_text(json.dumps(dict(p=P, gamma=GAMMA, truth=TRUTH,
        seeds=256, budgets=BUDGETS, estimates=result), indent=2) + "\n")
    if args.plot:
        plot(result)
    for item in result:
        if item['budget'] in (32, 128, 512):
            print("{budget:4} {method:13} bias {bias:+.4f}   SD {sd:.4f}   RMSE {rmse:.4f}".format(**item))


if __name__ == "__main__":
    main()
