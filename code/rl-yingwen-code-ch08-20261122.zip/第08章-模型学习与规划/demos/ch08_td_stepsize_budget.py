"""Step-size control for the p436 experiment (ch08, vision-model-planning).

11-21 审阅站请求 r1121-112759：prediction_information_budget.py 的一步 TD 用
1/n 步长（ReturnMean 按更新次数取平均）。这里在同一环境、同一随机流上补跑
常数步长与 1/n^c 步长的一步 TD，并与先估模型比较。

Run: python3 demos/ch08_td_stepsize_budget.py
Writes assets/prediction-information/td-stepsize.json.
"""
import json
import math
import random
from pathlib import Path

P, GAMMA = .1, .9
TRUTH = P / (1 - GAMMA * (1 - P))
BUDGETS = (8, 16, 32, 64, 128, 256, 512, 1024, 2048)
OUT = Path(__file__).resolve().parents[1] / "assets" / "prediction-information"
SCHEDULES = {"1/n": lambda n: 1 / n, "alpha=.05": lambda n: .05,
             "alpha=.1": lambda n: .1, "alpha=.2": lambda n: .2}
for c in (.5, .6, .7, .8):
    SCHEDULES[f"1/n^{c}"] = (lambda c: lambda n: n ** -c)(c)


def errors(seeds, schedule):
    """Squared errors per budget for TD(0) with the given step size, and for
    the fitted model p_hat/[1-gamma(1-p_hat)], on the same stream as the
    original script (random.Random(seed), success iff rng.random() < P)."""
    td = {b: [] for b in BUDGETS}
    model = {b: [] for b in BUDGETS}
    for seed in range(seeds):
        rng = random.Random(seed)
        v, n, succ = 0., 0, 0
        for t in range(1, BUDGETS[-1] + 1):
            terminal = rng.random() < P
            succ += terminal
            target = 1. if terminal else GAMMA * v
            n += 1
            v += schedule(n) * (target - v)
            if t in td:
                p_hat = succ / t
                td[t].append((v - TRUTH) ** 2)
                model[t].append((p_hat / (1 - GAMMA * (1 - p_hat)) - TRUTH) ** 2)
    return td, model


def rmse_se(sq):
    """RMSE and its delta-method standard error."""
    n = len(sq)
    mse = sum(sq) / n
    sd = math.sqrt(sum((x - mse) ** 2 for x in sq) / (n - 1))
    rmse = math.sqrt(mse)
    return rmse, sd / math.sqrt(n) / (2 * rmse)


def main():
    result = {}
    for seeds in (256, 1000):
        block = {}
        for name, schedule in SCHEDULES.items():
            td, model = errors(seeds, schedule)
            block[name] = [dict(budget=b, rmse=rmse_se(td[b])[0], se=rmse_se(td[b])[1]) for b in BUDGETS]
        block["fitted model"] = [dict(budget=b, rmse=rmse_se(model[b])[0], se=rmse_se(model[b])[1]) for b in BUDGETS]
        result[str(seeds)] = block
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "td-stepsize.json").write_text(json.dumps(dict(p=P, gamma=GAMMA, truth=TRUTH,
        budgets=BUDGETS, runs=result), indent=1) + "\n")
    for seeds, block in result.items():
        print(f"runs={seeds}")
        for name, rows in block.items():
            print(f"  {name:12}", " ".join(f"{r['rmse']:.4f}({r['se']:.4f})" for r in rows))


if __name__ == "__main__":
    main()
