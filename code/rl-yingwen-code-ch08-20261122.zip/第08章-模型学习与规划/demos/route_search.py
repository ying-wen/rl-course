"""Depth-limited lookahead at S7, using the two route policies of mud_world.

Run python3 demos/route_search.py --output assets/mud-planning/search.json
The only fitted quantity is the chance of success at S4. The environment is
used separately to evaluate a selected route after search. Standard library.
"""
from argparse import ArgumentParser
from fractions import Fraction
from functools import lru_cache
import json
from pathlib import Path
from random import Random

from mud_planning import fresh_trials
from mud_world import GAMMA, NEW, OLD, outcomes

DISCOUNT = Fraction(str(GAMMA))
ROUTES = {"dry": NEW, "mud": OLD}


def transitions(state, action, p):
    """Use known maze geometry and insert the model's p for the uncertain move."""
    if state == "S4" and action == "up":
        return [(p, "G", 1), (1 - p, "S4", 0)]
    return [(Fraction(str(prob)), nxt, int(reward))
            for prob, nxt, reward, _ in outcomes(state, action)]


def continuation(state, route, p):
    """Value of finishing this route in the same model, including repeated failures."""
    if state == "G":
        return Fraction(0)
    if state == "S4":
        return p / (1 - DISCOUNT * (1 - p))
    [(prob, nxt, reward)] = transitions(state, ROUTES[route][state], p)
    assert prob == 1
    return reward + DISCOUNT * continuation(nxt, route, p)


def search(route, p, depth, use_leaf_value):
    """Expand a branch in expectation. At the root the two branches are compared."""
    @lru_cache(None)
    def value(state, remaining):
        if state == "G":
            return Fraction(0)
        if remaining == 0:
            return continuation(state, route, p) if use_leaf_value else Fraction(0)
        return sum(prob * (reward + DISCOUNT * value(nxt, remaining - 1))
                   for prob, nxt, reward in transitions(state, ROUTES[route][state], p))
    return value("S7", depth)


def collect():
    trials = fresh_trials(16, Random(2))
    world_p = Fraction(str(next(prob for prob, _, _, done in outcomes("S4", "up") if done)))
    models = {"first10": Fraction(sum(trials[:10]), 10),
              "first16": Fraction(sum(trials), 16), "world": world_p}
    rows = []
    for model, p in models.items():
        for leaf in ("zero", "model"):
            for h in range(1, 13):
                scores = {route: search(route, p, h, leaf == "model") for route in ROUTES}
                route = "mud" if scores["mud"] > scores["dry"] else "dry"
                rows.append({"model": model, "p": float(p), "leaf": leaf, "depth": h,
                             "dry": float(scores["dry"]), "mud": float(scores["mud"]),
                             "choice": route, "in_world": float(continuation("S7", route, world_p))})
    return rows


if __name__ == "__main__":
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    results = collect()
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(results, ensure_ascii=False, indent=2) + "\n")
    for row in results:
        if row["model"] == "first10" and row["leaf"] == "zero" and row["depth"] in (5, 6, 9):
            print("depth={depth} dry={dry:.5f} mud={mud:.5f} choose={choice} "
                  "world return={in_world:.5f}".format(**row))
