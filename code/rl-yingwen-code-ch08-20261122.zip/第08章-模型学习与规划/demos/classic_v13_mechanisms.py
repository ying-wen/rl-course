"""Exact teaching calculations for MDPs, TD, traces, and model-based planning.

Run: python demos/classic_v13_mechanisms.py
Requires numpy and matplotlib. Saves figures and numerical values under
assets/classic-v13/. These are analytic task calculations, not training curves.

The online forward-view implementation deliberately recomputes every prefix.
It provides an independent check of the efficient true-online recurrence.
"""
from pathlib import Path
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties

OUT = Path(__file__).resolve().parents[1] / 'assets' / 'classic-v13'
INK, TEAL, RED, GOLD, MUTED = '#182E38', '#087E8B', '#C65335', '#C4942A', '#61757D'


def style():
    font = Path('/Library/Fonts/Arial Unicode.ttf')
    if font.exists():
        plt.rcParams['font.family'] = FontProperties(fname=str(font)).get_name()
    plt.rcParams.update({'font.size': 13, 'axes.labelcolor': INK,
                         'text.color': INK, 'axes.spines.top': False,
                         'axes.spines.right': False, 'axes.titleweight': 'bold',
                         'axes.unicode_minus': False, 'savefig.facecolor': 'white'})


def save(fig, name):
    fig.savefig(OUT / f'{name}.pdf', bbox_inches='tight')
    fig.savefig(OUT / f'{name}.png', dpi=180, bbox_inches='tight')
    plt.close(fig)


def online_forward(features, rewards, initial, alpha, gamma, lam):
    """Definition of online lambda-return; no trace recursion is used.

    features has T+1 vectors; its terminal vector is zero. At horizon h,
    restart from the episode's initial weights and redo updates k=0..h-1.
    All n-step bootstraps use the already saved diagonal weights w[k+n-1].
    See Sutton & Barto Sec. 12.4, Eqs. 12.8-12.9.
    """
    weights = [np.array(initial, dtype=float)]
    for horizon in range(1, len(rewards) + 1):
        current = np.array(initial, dtype=float)
        for k in range(horizon):
            target = 0.0
            for n in range(1, horizon - k + 1):
                # Definition of the n-step target, independent of the trace code.
                g = sum(gamma**j * rewards[k+j] for j in range(n))
                g += gamma**n * (weights[k+n-1] @ features[k+n])
                mixture = lam**(n-1)
                if n < horizon-k:
                    mixture *= 1-lam
                target += mixture * g
            current += alpha * (target - current @ features[k]) * features[k]
        weights.append(current.copy())
    return np.array(weights)


def true_online(features, rewards, initial, alpha, gamma, lam):
    """True-online TD(lambda), with all prediction reads before weight writes.

    A state table is the special case in which features are one-hot vectors.
    v_old is the preceding step's prediction of the *current* state; it must
    be stored before the preceding weight update, not recomputed afterward.
    """
    w = np.array(initial, dtype=float)
    z = np.zeros_like(w)
    v_old = 0.0
    history, diagnostics = [w.copy()], []
    for t, reward in enumerate(rewards):
        x, x_next = features[t], features[t+1]
        v, v_next = float(w @ x), float(w @ x_next)
        delta = reward + gamma*v_next - v
        # The dot product reads z_{t-1}; only then is z_t assigned.
        z = gamma*lam*z + (1-alpha*gamma*lam*(z @ x))*x
        correction = alpha*(v-v_old)*(z-x)
        w += alpha*delta*z + correction
        diagnostics.append(dict(t=t, delta=delta, z=z.tolist(),
                                old_prediction=v_old, correction=correction.tolist()))
        # Save the old prediction of the next state. Reversing this order is wrong.
        v_old = v_next
        history.append(w.copy())
    return np.array(history), diagnostics


def accumulating(features, rewards, initial, alpha, gamma, lam):
    w = np.array(initial, dtype=float)
    z = np.zeros_like(w)
    history = [w.copy()]
    for t, reward in enumerate(rewards):
        delta = reward + gamma*(w @ features[t+1]) - w @ features[t]
        z = gamma*lam*z + features[t]
        w += alpha*delta*z
        history.append(w.copy())
    return np.array(history)


class DynaQPlus:
    """Tabular Dyna-Q+ with the latest-outcome deterministic model.

    The interface deliberately separates real observation from model planning.
    A new observed state receives a zero-reward self-loop prior for every
    untried action. Never-tried pairs use last_visit=0; elapsed time counts only
    real transitions. This is not a Bayesian uncertainty estimate.
    """
    def __init__(self, actions, alpha=.1, gamma=.95, kappa=.001, seed=7):
        self.actions = tuple(actions)
        self.alpha, self.gamma, self.kappa = alpha, gamma, kappa
        self.rng = np.random.default_rng(seed)
        self.q, self.model, self.last_visit = {}, {}, {}
        self.real_steps = 0

    def add_state(self, state):
        for action in self.actions:
            pair = state, action
            if pair not in self.q:
                self.q[pair] = 0.
                self.model[pair] = (0., state, False)
                self.last_visit[pair] = 0

    def update_q(self, pair, reward, next_state, terminal):
        tail = 0. if terminal else max(self.q.get((next_state,a),0.) for a in self.actions)
        target = reward + self.gamma*tail
        self.q[pair] += self.alpha*(target-self.q[pair])
        return target

    def observe(self, state, action, reward, next_state, terminal=False):
        """One real transition: external reward remains unmodified."""
        self.add_state(state)
        self.real_steps += 1
        self.update_q((state,action),reward,next_state,terminal)
        self.model[state,action] = (reward,next_state,terminal)
        self.last_visit[state,action] = self.real_steps

    def plan(self, pair=None):
        """One internal value update. Does not advance the real clock."""
        if pair is None:
            pairs = list(self.model)
            pair = pairs[int(self.rng.integers(len(pairs)))]
        reward, next_state, terminal = self.model[pair]
        tau = self.real_steps-self.last_visit[pair]
        bonus = self.kappa*np.sqrt(tau)
        target = self.update_q(pair,reward+bonus,next_state,terminal)
        return dict(pair=pair,tau=tau,external_model_reward=reward,
                    planning_bonus=float(bonus),target=float(target))

    def act(self, state, epsilon=.1):
        """Epsilon-greedy action; break greedy ties uniformly."""
        self.add_state(state)
        if self.rng.random()<epsilon:
            return self.actions[int(self.rng.integers(len(self.actions)))]
        values=np.array([self.q[state,a] for a in self.actions])
        indices=np.flatnonzero(values==values.max())
        return self.actions[int(self.rng.choice(indices))]


def run():
    OUT.mkdir(parents=True, exist_ok=True)
    style()
    results = {}

    # 1. Two reachable nonterminal states under the mud task's fixed policy.
    # S7 -> S4; S4 remains with probability .9 or reaches terminal reward 1.
    gamma = .9
    transition = np.array([[0., 1.], [0., .9]])
    reward = np.array([0., .1])
    exact = np.linalg.solve(np.eye(2)-gamma*transition, reward)
    assert np.allclose(exact, [9/19, 10/19])
    low, high = [np.zeros(2)], [np.ones(2)]
    for _ in range(30):
        low.append(reward+gamma*transition@low[-1])
        high.append(reward+gamma*transition@high[-1])
    low, high = np.array(low), np.array(high)
    gap = np.max(np.abs(high-low), axis=1)
    assert np.all(gap <= gamma**np.arange(31)+1e-14)
    assert np.all(gap[1:] <= gamma*gap[:-1]+1e-14)
    fig, ax = plt.subplots(1, 2, figsize=(11, 3.0), layout='constrained')
    ax[0].plot(low[:, 1], color=TEAL, lw=2.3, label=r'$V_0=0$')
    ax[0].plot(high[:, 1], color=RED, lw=2.3, label=r'$U_0=1$')
    ax[0].axhline(exact[1], color=MUTED, ls='--', label=r'$v_\pi(S_4)=10/19$')
    ax[0].set(xlabel='期望更新轮数 k', ylabel='S4 的价值估计', ylim=(-.03, 1.03))
    ax[0].legend(fontsize=11)
    ax[1].semilogy(gap, color=TEAL, lw=2.3, label=r'$\|T_\pi^k U_0-T_\pi^k V_0\|_\infty$')
    ax[1].semilogy(gamma**np.arange(31), color=RED, ls='--', lw=2, label=r'$\gamma^k\|U_0-V_0\|_\infty$')
    ax[1].set(xlabel='期望更新轮数 k', ylabel='两张表的最大差距')
    ax[1].legend(fontsize=10)
    save(fig, 'contraction')
    results['contraction'] = {'exact': exact.tolist(), 'gap': gap.tolist(),
                              'gamma': gamma, 'initial_tables': [[0, 0], [1, 1]]}

    # 2. Exact target distributions. The final MC bucket carries all k>=30.
    value, p = .5, .1
    td_support, td_prob = np.array([gamma*value, 1]), np.array([1-p, p])
    td_mean = td_support @ td_prob
    td_var = (td_support-td_mean)**2 @ td_prob
    mc_mean = p/(1-(1-p)*gamma)
    mc_second = p/(1-(1-p)*gamma**2)
    fig, ax = plt.subplots(1, 2, figsize=(11, 3.0), layout='constrained')
    ax[0].vlines(td_support, 0, td_prob, color=TEAL, lw=5)
    ax[0].scatter(td_support, td_prob, color=TEAL, s=50)
    ax[0].axvline(td_mean, color=TEAL, ls='--', lw=1.7)
    ax[0].axvline(mc_mean, color=RED, ls=':', lw=1.7)
    ax[0].annotate('0.9', (.45, .9), xytext=(.52, .85))
    ax[0].annotate('0.1', (1, .1), xytext=(.85, .22))
    ax[0].set(title='TD：一步后接当前 V(S4)=0.5', xlabel='目标值', ylabel='概率质量', xlim=(-.04, 1.07), ylim=(0, 1.02))
    ks = np.arange(30)
    ax[1].vlines(gamma**ks, 0, p*(1-p)**ks, color=TEAL, lw=3)
    ax[1].scatter(gamma**ks, p*(1-p)**ks, color=TEAL, s=12)
    ax[1].axvline(mc_mean, color=RED, ls=':', lw=1.7)
    ax[1].bar(0, (1-p)**30, width=.028, color=GOLD)
    ax[1].annotate('K≥30 的总概率', (0, (1-p)**30), xytext=(.10, .07), arrowprops={'arrowstyle':'->','color':MUTED}, fontsize=10)
    ax[1].set(title=r'MC：等待成功，$G=0.9^K$', xlabel='完整回报', ylabel='概率质量', xlim=(-.04,1.07), ylim=(0,.115))
    save(fig, 'target-distributions')
    results['target_distributions'] = {'td_mean': float(td_mean), 'td_variance': float(td_var),
         'mc_mean': mc_mean, 'mc_variance': mc_second-mc_mean**2,
         'tail_bucket': {'K_at_least': 30, 'probability': (1-p)**30,
                         'support_upper_bound': gamma**30}}

    # 3. Sutton Example 6.4. Batch-TD and least-squares MC solve different systems.
    episodes = [[(0, 0., 1), (1, 0., 2)]] + [[(1, 1., 2)] for _ in range(6)] + [[(1, 0., 2)]]
    returns = [[], []]
    counts = np.zeros(2); transition_counts = np.zeros((2, 2)); reward_sums = np.zeros(2)
    for episode in episodes:
        g = 0.
        for s, r, sp in reversed(episode):
            g = r+g
            returns[s].append(g)
        for s, r, sp in episode:
            counts[s] += 1; reward_sums[s] += r
            if sp < 2: transition_counts[s, sp] += 1
    mc = np.array([np.mean(xs) for xs in returns])
    td = np.linalg.solve(np.eye(2)-transition_counts/counts[:,None], reward_sums/counts)
    iterative = np.zeros(3)
    for _ in range(4000):
        old = iterative.copy(); increment = np.zeros(3)
        for ep in episodes:
            for s, r, sp in ep:
                increment[s] += r+old[sp]-old[s]
        iterative += .05*increment
    assert np.allclose(mc, [0, .75]) and np.allclose(td, [.75, .75])
    assert np.allclose(iterative[:2], td, atol=1e-12)
    results['eight_episodes'] = {'episodes': episodes, 'mc':mc.tolist(), 'batch_td':td.tolist(),
                                'batch_td_iteration':iterative[:2].tolist()}

    # 4. Frozen lambda identity: rows are visits, columns are later TD errors.
    x = np.array([[1.,0.],[0.,1.],[0.,1.],[0.,1.],[0.,0.]])
    r = np.array([0.,0.,0.,1.]); initial=np.array([.4,.5]); alpha=.2; lam=.8
    delta = r + gamma*(x[1:]@initial) - x[:-1]@initial
    coeff = np.array([[(gamma*lam)**(t-k) if t>=k else 0 for t in range(4)] for k in range(4)])
    row_error = coeff@delta
    # Independently compute lambda-mixture targets from actual discounted rewards.
    targets=[]
    for k in range(4):
        gs=[sum(gamma**j*r[k+j] for j in range(n))+gamma**n*(x[k+n]@initial) for n in range(1,5-k)]
        weights=[(1-lam)*lam**(n-1) if n<4-k else lam**(n-1) for n in range(1,5-k)]
        targets.append(np.dot(gs,weights))
    assert np.allclose(np.array(targets)-x[:-1]@initial,row_error)
    frozen=initial+alpha*x[:-1].T@row_error
    fig, ax=plt.subplots(figsize=(8.6,3.4),layout='constrained')
    ax.imshow(coeff,cmap='GnBu',vmin=0,vmax=1,aspect='auto')
    for k in range(4):
        for t in range(4):
            ax.text(t,k,'—' if t<k else f'{coeff[k,t]:.3g}',ha='center',va='center',fontsize=17,color='white' if coeff[k,t]>.65 else INK)
    ax.set_xticks(range(4),[f'δ{t} = {delta[t]:+.2f}' for t in range(4)])
    ax.set_yticks(range(4),['访问 S7，k=0','访问 S4，k=1','访问 S4，k=2','访问 S4，k=3'])
    ax.tick_params(length=0);ax.xaxis.tick_top()
    ax.set_title(r'每一格：访问 k 对误差 $\delta_t$ 的权重 $(\gamma\lambda)^{t-k}$',pad=18)
    save(fig,'trace-matrix')

    # 5. Exact online equality checked by an independently constructed forward view.
    forward=online_forward(x,r,initial,alpha,gamma,lam)
    efficient,diag=true_online(x,r,initial,alpha,gamma,lam)
    ordinary=accumulating(x,r,initial,alpha,gamma,lam)
    max_error=float(np.max(np.abs(forward-efficient)))
    rng=np.random.default_rng(1307)
    for _ in range(120):
        T=int(rng.integers(2,12));d=int(rng.integers(1,7))
        features=rng.normal(size=(T+1,d))/np.sqrt(d);features[-1]=0
        rewards=rng.normal(size=T);w0=rng.normal(size=d)
        a=float(rng.uniform(.01,.25));g=float(rng.choice([0.,.7,.9,1.]));l=float(rng.choice([0.,.3,.8,1.]))
        f=online_forward(features,rewards,w0,a,g,l)
        e,_=true_online(features,rewards,w0,a,g,l)
        error=float(np.max(np.abs(f-e)));max_error=max(max_error,error)
        assert error<1e-11, (a,g,l,error)
    fig,ax=plt.subplots(1,2,figsize=(10.5,3),layout='constrained')
    for i in range(2):
        ax[i].plot(range(5),efficient[:,i],color=TEAL,lw=2,label='true-online TD(λ)')
        ax[i].scatter(range(5),forward[:,i],facecolors='white',edgecolors=TEAL,s=65,zorder=5,label='逐次重算前向目标')
        ax[i].plot(range(5),ordinary[:,i],color=RED,lw=2,ls='--',label='普通累积迹 TD(λ)')
        ax[i].set(title=['S7 的价值估计','S4 的价值估计'][i],xlabel='已收到的转移数 h',xticks=range(5))
    ax[0].legend(fontsize=9)
    save(fig,'true-online')
    results['traces']={'states':['S7','S4','S4','S4','terminal'],'rewards':r.tolist(),
        'initial':initial.tolist(),'alpha':alpha,'gamma':gamma,'lambda':lam,
        'frozen_deltas':delta.tolist(),'frozen_targets':targets,'frozen_final':frozen.tolist(),
        'online_forward':forward.tolist(),'true_online':efficient.tolist(),
        'accumulating':ordinary.tolist(),'true_online_diagnostics':diag,
        'independent_random_linear_tests':120,'max_forward_recursion_difference':max_error}

    # 6. Fixed one-step model: Monte Carlo variance shrinks, model bias remains.
    # Actual success p=.1, fitted model success p_hat=.2; V(S4)=.5 frozen.
    p_hat=.2;model_mean=p_hat+(1-p_hat)*.45
    model_variance=p_hat*(1-p_hat)*(1-.45)**2
    bias_sq=(model_mean-td_mean)**2
    K=np.arange(1,101)
    fig,ax=plt.subplots(figsize=(10,3.0),layout='constrained')
    ax.plot(K,bias_sq+model_variance/K,color=TEAL,lw=2.5,label='相对真实一步期望的均方误差')
    ax.plot(K,model_variance/K,color=GOLD,lw=2,ls='--',label='模型抽样方差 / K')
    ax.axhline(bias_sq,color=RED,lw=2,ls=':',label='模型偏差平方')
    ax.set(xlabel='独立模型调用次数 K（对数刻度）',ylabel='均方误差',xscale='log',xlim=(1,100),ylim=(0,.055))
    ax.legend(fontsize=10)
    save(fig,'model-error-budget')
    results['model_budget']={'actual_one_step_mean':float(td_mean),'model_one_step_mean':model_mean,
                             'model_variance':model_variance,'bias_squared':bias_sq}

    # 7. Tree-backup branch substitution. Expanding the expression cancels
    # the selected branch's old Q and inserts its deeper target exactly once.
    probs=np.array([.25,.75]);q=np.array([3.,2.]);deeper=4.
    direct=.9*(probs[1]*q[1]+probs[0]*deeper)
    correction=.9*(probs@q+probs[0]*(deeper-q[0]))
    assert abs(direct-correction)<1e-15
    results['tree_backup']={'probabilities':probs.tolist(),'Q':q.tolist(),'deeper_selected_target':deeper,
                            'direct':direct,'replace_branch':correction}

    # 8. Execute a Dyna-Q+ cycle and check which information can change.
    learner=DynaQPlus(actions=['left','right'],alpha=.2,gamma=.9,kappa=.1)
    for _ in range(9):
        learner.observe('S','left',0.,'S')
    before_model=dict(learner.model)
    before_time=learner.real_steps
    planning=learner.plan(('S','right'))
    assert planning['tau']==9 and abs(planning['planning_bonus']-.3)<1e-12
    assert learner.model==before_model and learner.real_steps==before_time
    assert abs(learner.q['S','right']-.06)<1e-12
    # Only executing right can replace its invented zero-reward self-loop.
    learner.observe('S','right',1.,'G',terminal=True)
    assert learner.model['S','right']==(1.,'G',True)
    assert learner.last_visit['S','right']==10
    assert learner.plan(('S','right'))['planning_bonus']==0.
    results['dyna_q_plus_cycle']={'planning_before_retry':planning,
        'real_steps_after_retry':learner.real_steps,
        'right_model_after_retry':learner.model['S','right'],
        'convention':'never-tried action last_visit=0; latest deterministic outcome model'}

    (OUT/'results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'output':str(OUT),'independent_true_online_tests':120,
                      'maximum_true_online_difference':max_error,
                      'forward_final':forward[-1].tolist(),'ordinary_final':ordinary[-1].tolist()},indent=2))


if __name__=='__main__':
    run()
