#!/usr/bin/env python3
"""Compare recursive and direct prediction with exactly the same observed paths.
Python standard library only. Run from any directory; outputs sit beside this file.
No environment control or RL training is performed by this prediction experiment.
"""
from pathlib import Path
import csv, json, math, random, statistics

OUT = Path(__file__).resolve().parent / 'multiscale-results'
HORIZON, REPEATS, BASE_SEED = 16, 300, 602810
CASES = {'linear': (0.9, 0.0, 0.2), 'omitted_intercept': (0.8, 0.2, 0.1)}

def fit_slope(xs, ys):
    return sum(x*y for x,y in zip(xs,ys))/sum(x*x for x in xs)

def mean_variance(a,b,sigma,k):
    return a**k, b*sum(a**j for j in range(k)), sigma*sigma*sum(a**(2*j) for j in range(k))

def simulate(case,n,rep):
    a,b,sigma=CASES[case]
    rng=random.Random(BASE_SEED + 100000*list(CASES).index(case)+1000*n+rep)
    paths=[]
    for _ in range(n):
        p=[rng.uniform(-1,1)]
        for _ in range(HORIZON): p.append(a*p[-1]+b+rng.gauss(0,sigma))
        paths.append(p)
    xs=[p[k] for p in paths for k in range(HORIZON)]
    ys=[p[k+1] for p in paths for k in range(HORIZON)]
    ahat=fit_slope(xs,ys)
    x0=[p[0] for p in paths]
    rows=[]
    for k in range(1,HORIZON+1):
        target_slope,target_offset,noise_var=mean_variance(a,b,sigma,k)
        for method,slope in [('recursive',ahat**k),('direct',fit_slope(x0,[p[k] for p in paths]))]:
            # Exact integration over an independent X0~Uniform[-1,1].
            mse=(slope-target_slope)**2/3+target_offset**2
            rows.append(dict(case=case,n=n,rep=rep,k=k,method=method,slope=slope,
                             mean_mse=mse,observation_mse=mse+noise_var,noise_var=noise_var))
    return rows

def main():
    OUT.mkdir(exist_ok=True)
    raw=[r for case in CASES for n in (32,256) for rep in range(REPEATS) for r in simulate(case,n,rep)]
    with (OUT/'raw.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(raw[0]));w.writeheader();w.writerows(raw)
    summary=[]
    for case in CASES:
        for n in (32,256):
            a,b,sigma=CASES[case]
            for k in range(1,HORIZON+1):
                r=dict(k=k)
                for method in ('recursive','direct'):
                    g=[x for x in raw if x['case']==case and x['n']==n and x['k']==k and x['method']==method]
                    losses=[x['mean_mse'] for x in g];slopes=[x['slope'] for x in g]
                    # Population denominator makes the empirical bias-variance identity exact.
                    variance=statistics.pvariance(slopes)/3
                    truth,offset,noise=mean_variance(a,b,sigma,k)
                    bias=(statistics.mean(slopes)-truth)**2/3+offset**2
                    mse=statistics.mean(losses)
                    assert math.isclose(mse,bias+variance,rel_tol=1e-10,abs_tol=1e-12)
                    r.update({method:mse,method+'_se':statistics.stdev(losses)/math.sqrt(REPEATS),
                              method+'_variance':variance,method+'_bias2':bias})
                r['noise']=mean_variance(a,b,sigma,k)[2]
                summary.append(dict(case=case,n=n,**r))
                if k in (1,8,16): print(case,n,k,'recursive %.6g direct %.6g'%(r['recursive'],r['direct']))
            rows=[{key:val for key,val in x.items() if key not in ('case','n')} for x in summary if x['case']==case and x['n']==n]
            with (OUT/f'{case}-{n}.csv').open('w',newline='') as f:
                w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    counter=[dict(k=k,contractive=abs(.5**k-.4**k),linear=.05*k,
                  bound_contract=.1*sum(.5**j for j in range(k))) for k in range(0,HORIZON+1)]
    assert all(counter[k+1]['contractive']<counter[k]['contractive'] for k in range(1,HORIZON))
    # Independent checks: finite enumeration/quadrature of conditional loss and exact noiseless fitting.
    assert abs(fit_slope([-1,0,1],[-.7,0,.7])-.7)<1e-12
    a,b,sigma=CASES['linear']; k=5; p=.4
    numeric=sum(((p-a**k)*(-1+(i+.5)*2/100000))**2 for i in range(100000))/100000
    assert abs(numeric-(p-a**k)**2/3)<1e-10
    with (OUT/'counterexample.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(counter[0]));w.writeheader();w.writerows(counter)
    manifest=dict(seed=BASE_SEED,repeats=REPEATS,horizon=HORIZON,cases=CASES,
        initial_distribution='independent Uniform[-1,1] per path',trajectory_counts=[32,256],
        observed_transition_counts=[32*HORIZON,256*HORIZON],
        recursive='one no-intercept OLS slope, all N*K observed one-step pairs',
        direct='K separate no-intercept OLS slopes, N observed initial/end pairs per horizon',
        evaluation='exact conditional-mean MSE integrated over new Uniform[-1,1]; observation MSE adds process variance',
        uncertainty='mean and standard error across 300 independently generated training datasets',
        checks=['analytic integrated MSE vs midpoint quadrature','bias-variance identity','noiseless slope recovery','decreasing actual error counterexample'],
        interpretation='same observed trajectories; supervision per fitted parameter and model parameter counts differ; no control evaluation')
    (OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    (OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')

if __name__=='__main__': main()
