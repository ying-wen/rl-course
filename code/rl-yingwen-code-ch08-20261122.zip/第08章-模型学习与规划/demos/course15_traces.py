"""Chapter 7: n-step TD, accumulating traces, and true-online TD(lambda).

Standalone: python course15_traces.py --out /absolute/output/directory
Dependencies: numpy, matplotlib. No other course file is imported.

Fixed policy: S7 -> S4; at S4, upward motion succeeds with probability .1.
Only entering terminal G pays 1; gamma=.9. All methods receive the same
completed episodes for each seed. No transition model is passed to learners.
The known model is used separately to generate data and to evaluate estimates.

Outputs: PDF/PNG teaching figures; raw seed/episode/value CSV; per-transition
trace CSV; independent numerical-check report and complete experiment settings.
"""
from __future__ import annotations
import argparse
import csv
import json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Circle, Rectangle, FancyArrowPatch

GAMMA=.9
TEAL, RED, GOLD, INK, MUTED = '#087e8b','#c65335','#c4942a','#182e38','#61757d'
COLORS=[TEAL,RED,GOLD]
FIXED_STATES=np.array([0,1,1,1,2])  # 0=S7, 1=S4, 2=terminal G
FIXED_REWARDS=np.array([0.,0.,0.,1.])
FEATURES=np.array([[1.,0.],[0.,1.],[0.,0.]])


def sample_episode(rng):
    """Only the environment knows the .1 success probability."""
    states, rewards=[0,1],[0.]
    while True:
        done=rng.random()<.1
        states.append(2 if done else 1);rewards.append(float(done))
        if done:return np.asarray(states),np.asarray(rewards)


def nstep_episode(states_all,rewards_all,values,n,alpha,gamma=GAMMA):
    """Online n-step TD, including terminal drain, from an observed stream.

    Inputs contain a pre-generated episode only to pair data across methods.
    The learner exposes exactly one transition at t<T. Tail reads cannot use
    future data; the final drain advances the algorithm clock but not the world.
    """
    states=[int(states_all[0])];rewards=[0.];T=np.inf;t=0;updates=[]
    while True:
        if t<T:                               # 1. reveal one new transition
            nxt=int(states_all[t+1]);states.append(nxt)
            rewards.append(float(rewards_all[t]))
            if nxt==2:T=t+1
        tau=t-n+1                             # 2. oldest ready visit
        if tau>=0:
            end=int(min(tau+n,T))
            target=sum(gamma**(i-tau-1)*rewards[i]
                       for i in range(tau+1,end+1))
            if tau+n<T:                       # 3. bootstrap only before G
                target+=gamma**n*values[states[tau+n]]
            s=states[tau];old=values[s]
            values[s]+=alpha*(target-old)      # 4. write this visit once
            updates.append((t,tau,target,values.copy()))
        if tau==T-1:return updates             # 5. all visits have been updated
        t+=1


def accumulating(features,rewards,initial,alpha,gamma,lam):
    """One trace per fixed feature. Use trace and weights_before/after for general
    features. Legacy S7/S4 fields name coordinates 0/1 of the one-hot mud task.
    """
    w=np.array(initial,dtype=float);z=np.zeros_like(w)
    history=[w.copy()];records=[]
    for t,reward in enumerate(rewards):
        x,x_next=features[t],features[t+1]
        before=w.copy()                        # all reads precede all writes
        value,next_value=w@x,w@x_next
        delta=reward+gamma*next_value-value
        z=gamma*lam*z+x                        # decay old visits, then add this one
        w+=alpha*delta*z                       # current error writes along the trace
        history.append(w.copy())
        record = dict(t=t, reward=float(reward), delta=float(delta),
                      trace=z.tolist(), weights_before=before.tolist(), weights_after=w.tolist())
        # The original two-column mud experiment and its CSV use these names.
        if w.size >= 2:
            record.update(z_S7=float(z[0]), z_S4=float(z[1]),
                          old_S7=float(before[0]), old_S4=float(before[1]),
                          new_S7=float(w[0]), new_S4=float(w[1]))
        records.append(record)
    return np.asarray(history),records


def online_forward(features,rewards,initial,alpha,gamma,lam):
    """Direct online lambda-return definition, deliberately no trace recursion.

    For every observed prefix h, restart at the episode's initial weights.
    For k=0..h-1, mix every available n-step target, then redo the sequential
    updates. Its bootstraps use previously saved diagonal weights w[k+n-1].
    This slow implementation independently tests the true-online recurrence.
    """
    history=[np.array(initial,dtype=float)]
    for h in range(1,len(rewards)+1):
        w=np.array(initial,dtype=float)
        for k in range(h):
            target=0.
            for n in range(1,h-k+1):
                g=sum(gamma**j*rewards[k+j] for j in range(n))
                g+=gamma**n*(history[k+n-1]@features[k+n])
                mass=lam**(n-1)*(1-lam if n<h-k else 1.)
                target+=mass*g
            w+=alpha*(target-w@features[k])*features[k]
        history.append(w.copy())
    return np.asarray(history)


def true_online(features,rewards,initial,alpha,gamma,lam):
    """True-online TD(lambda): fixed linear features, constant alpha."""
    w=np.array(initial,dtype=float);z=np.zeros_like(w);v_old=0.
    history=[w.copy()]
    for t,reward in enumerate(rewards):
        x,x_next=features[t],features[t+1]
        v,v_next=w@x,w@x_next                  # read both before writing w
        delta=reward+gamma*v_next-v
        z=gamma*lam*z+(1-alpha*gamma*lam*(z@x))*x  # inner product reads OLD z
        w+=alpha*(delta+v-v_old)*z-alpha*(v-v_old)*x
        v_old=v_next                          # save pre-update next prediction
        history.append(w.copy())
    return np.asarray(history)


def frozen_forward(states,rewards,initial,alpha,gamma,lam):
    """Direct finite mixture, all errors read the same frozen initial table."""
    w=np.asarray(initial);inc=np.zeros_like(w);targets=[];T=len(rewards)
    for k in range(T):
        target=0.
        for n in range(1,T-k+1):
            g=sum(gamma**j*rewards[k+j] for j in range(n))
            if k+n<T:g+=gamma**n*w[states[k+n]]
            target+=lam**(n-1)*(1-lam if n<T-k else 1.)*g
        targets.append(target);inc[states[k]]+=alpha*(target-w[states[k]])
    return w+inc,np.asarray(targets)


def offline_sequential(states,targets,initial,alpha):
    """Offline lambda-return: no writes during the episode; at the end, write each
    frozen-table target in time order, so a repeated state reads its own earlier write."""
    w=np.array(initial,dtype=float)
    for k,g in enumerate(targets):w[states[k]]+=alpha*(g-w[states[k]])
    return w


def frozen_backward(states,rewards,initial,alpha,gamma,lam):
    """Sum TD-error writes without changing the table used by later errors."""
    w=np.asarray(initial);inc=np.zeros_like(w);z=np.zeros_like(w)
    for t,r in enumerate(rewards):
        delta=r+(gamma*w[states[t+1]] if states[t+1]!=2 else 0)-w[states[t]]
        z*=gamma*lam;z[states[t]]+=1;inc+=alpha*delta*z
    return w+inc


def independent_checks():
    s,r=FIXED_STATES,FIXED_REWARDS;x=FEATURES[s];w=np.array([.4,.5])
    # 1. Analytical Bellman solution vs explicit waiting-time enumeration.
    truth=np.linalg.solve(np.eye(2)-GAMMA*np.array([[0.,1.],[0.,.9]]),[0.,.1])
    enum=sum(.1*.9**k*GAMMA**k for k in range(500))
    np.testing.assert_allclose(truth,[GAMMA*enum,enum],atol=2e-14)
    # 2. Direct finite lambda mixture vs independent TD-error recursion.
    a,target=frozen_forward(s,r,w,.2,.9,.8)
    b=frozen_backward(s,r,w,.2,.9,.8)
    np.testing.assert_allclose(a,b,atol=2e-14)
    np.testing.assert_allclose(target[0],.574704,atol=2e-14)
    # 3. Hand result for terminal draining; n>T performs no extra real steps.
    vals=w.copy();updates=nstep_episode(s,r,vals,6,.2)
    np.testing.assert_allclose([u[2] for u in updates],[.729,.81,.9,1.],atol=1e-14)
    assert [u[1] for u in updates]==[0,1,2,3] and updates[-1][0]==8
    vals=w.copy();n3=nstep_episode(s,r,vals,3,.2)
    np.testing.assert_allclose(vals,[.3929,.70368],atol=1e-14)
    # 4. Zero table: only terminal delta is nonzero; trace writes to BOTH states.
    zero,rows=accumulating(x,r,[0.,0.],.2,.9,.8)
    np.testing.assert_allclose(zero[-1],[.0746496,.44768],atol=2e-14)
    np.testing.assert_allclose([row['z_S4'] for row in rows],[0.,1.,1.72,2.2384])
    # 5. Online forward recomputation vs true-online at EVERY prefix.
    forward=online_forward(x,r,w,.2,.9,.8);true=true_online(x,r,w,.2,.9,.8)
    np.testing.assert_allclose(forward,true,atol=2e-14)
    ordinary,_=accumulating(x,r,w,.2,.9,.8)
    assert np.max(np.abs(ordinary-true))>.01
    # 6. Random fixed linear features, signed rewards, overlaps and endpoints.
    rng=np.random.default_rng(73015);maxerr=0.;cases=0
    for _ in range(40):
        features=rng.normal(size=(9,4))/2;features[-1]=0
        rewards=rng.normal(size=8);initial=rng.normal(size=4)
        for lam in (0.,.3,.8,1.):
            for alpha in (.01,.2):
                f=online_forward(features,rewards,initial,alpha,.93,lam)
                t=true_online(features,rewards,initial,alpha,.93,lam)
                error=float(np.max(np.abs(f-t)));maxerr=max(maxerr,error);cases+=1
                np.testing.assert_allclose(f,t,atol=2e-12,rtol=2e-12)
                if lam==0:
                    td,_=accumulating(features,rewards,initial,alpha,.93,0.)
                    np.testing.assert_allclose(t,td,atol=2e-12)
    # 7. n=1 agrees with ordinary TD(0), including repeated-state reads.
    vals=w.copy();nstep_episode(s,r,vals,1,.2)
    td,_=accumulating(x,r,w,.2,.9,0.)
    np.testing.assert_allclose(vals,td[-1],atol=2e-14)
    # 8. Exact target distributions: variance/MSE can INCREASE with n.
    distributions=[]
    for n in (1,2,4,16):
        probs=np.r_[.1*.9**np.arange(n),.9**n]
        targets=np.r_[.9**np.arange(n),.5*.9**n]
        mean=probs@targets;var=probs@(targets-mean)**2
        mse=probs@(targets-truth[1])**2
        formula=truth[1]+.81**n*(.5-truth[1])
        np.testing.assert_allclose(mean,formula,atol=2e-14)
        distributions.append(dict(n=n,mean=mean,variance=var,mse=mse))
    assert distributions[1]['mse']>distributions[0]['mse']
    # 9. Offline lambda-return (Section 17.4): S4 moves .5 -> .6732 -> .81 -> 1 in turn.
    offline=offline_sequential(s,target,w,.2)
    np.testing.assert_allclose(offline[1],.6717696,atol=2e-12)
    return dict(check_groups=9,linear_forward_cases=cases,max_linear_error=maxerr,
                truth=truth.tolist(),frozen_final=a.tolist(),offline_final=offline.tolist(),lambda_targets=target.tolist(),
                true_online_final=true[-1].tolist(),ordinary_final=ordinary[-1].tolist(),
                zero_final=zero[-1].tolist(),target_distributions=distributions)


def train(seeds,episodes):
    """Paired independent seeds; identical episodes, initialization and alpha."""
    configs=[('n',n) for n in (1,4,16)]+[('lambda',l) for l in (0.,.8,1.)]
    alphas=(.05,.2);hist={};lengths=[]
    for alpha in alphas:
        for kind,param in configs:hist[(alpha,kind,param)]=np.zeros((seeds,episodes,2))
    for seed in range(seeds):
        rng=np.random.default_rng(seed+150700)
        data=[sample_episode(rng) for _ in range(episodes)]
        lengths.append([len(r) for s,r in data])
        for alpha in alphas:
            for kind,param in configs:
                w=np.zeros(2)
                for ep,(states,rewards) in enumerate(data):
                    if kind=='n':nstep_episode(states,rewards,w,param,alpha)
                    else:w=accumulating(FEATURES[states],rewards,w,alpha,GAMMA,param)[0][-1]
                    hist[(alpha,kind,param)][seed,ep]=w
    return hist,np.asarray(lengths)


def save(fig,out,name):
    fig.savefig(out/(name+'.pdf'),bbox_inches='tight',facecolor='white')
    fig.savefig(out/(name+'.png'),bbox_inches='tight',facecolor='white',dpi=190)
    plt.close(fig)


def arrow(ax,a,b,color=TEAL,lw=2,**kw):
    ax.add_patch(FancyArrowPatch(a,b,arrowstyle='-|>',mutation_scale=14,color=color,lw=lw,**kw))


def chain(ax,y=0,alpha=1,stop=4):
    for i,label in enumerate(['S7','S4','S4','S4','G']):
        active=i<=stop
        ax.add_patch(Circle((i,y),.16,fc='#f7e4bb' if label=='S4' else '#dcefed',ec=INK,alpha=alpha if active else .2))
        ax.text(i,y,label,ha='center',va='center',fontsize=12,alpha=alpha if active else .2)
        if i<4:arrow(ax,(i+.18,y),(i+.81,y),color=RED if i==3 else TEAL,lw=1.8,alpha=alpha if i<stop else .15)


def maze(ax,values,title):
    cells={(0,2):'S1',(1,2):'S2',(2,2):'G',(0,1):'S3',(2,1):'S4',
           (0,0):'S5',(1,0):'S6',(2,0):'S7'}
    for xx in range(3):
        for yy in range(3):
            s=cells.get((xx,yy));v=values[0 if s=='S7' else 1] if s in ('S7','S4') else None
            color=INK if s is None else plt.cm.YlGnBu(min(v/.8,1)) if v is not None else '#edf0ef'
            ax.add_patch(Rectangle((xx,yy),1,1,facecolor=color,edgecolor='white',lw=1.5))
            if s:
                ax.text(xx+.07,yy+.83,s,fontsize=10,color='white' if v is not None and v>.5 else INK)
                if v is not None:ax.text(xx+.5,yy+.47,f'{v:.3f}',ha='center',fontsize=14,fontweight='bold',color='white' if v>.5 else INK)
                if s in ('S7','S4'):arrow(ax,(xx+.5,yy+.1),(xx+.5,yy+.27),color='white' if v>.5 else TEAL,lw=1.3)
    ax.set(xlim=(0,3),ylim=(0,3),aspect='equal');ax.axis('off');ax.set_title(title,fontsize=12,pad=6)


def figures(out,report,hist,lengths):
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':13,'axes.labelsize':13,
                         'axes.titlesize':15,'axes.spines.top':False,'axes.spines.right':False,
                         'text.color':INK,'axes.labelcolor':INK,'pdf.fonttype':42})
    # Same temporal occurrences in all four rows; shaded endpoint is a value read.
    fig,ax=plt.subplots(figsize=(10.2,4.3));ax.axis('off');ax.set(xlim=(-1.,6.9),ylim=(-.7,4.2))
    vals=[.45,.405,.3645,.729]
    for j,n in enumerate((1,2,3,4)):
        y=3.4-j;chain(ax,y,stop=n);ax.text(-.55,y,f'n={n}',ha='center',va='center',fontsize=15)
        ax.text(4.7,y,f'{vals[j]:.4g}',va='center',color=TEAL,fontsize=20,fontweight='bold')
        ax.text(6.1,y,f't={n}',va='center',fontsize=12)
        if n<4:
            ax.plot([n+.25,n+.25],[y-.26,y+.26],color=GOLD,lw=4);ax.text(n,y-.42,r'$V=.5$',ha='center',color=GOLD,fontsize=12)
    for i in range(5):ax.text(i,3.96,f't={i}',ha='center',fontsize=12,color=MUTED)
    ax.text(4.7,3.96,'target',fontsize=12,color=MUTED);ax.text(6.1,3.96,'available',fontsize=12,color=MUTED)
    save(fig,out,'targets')
    # A matrix explains sum interchange through geometry rather than prose boxes.
    mat=np.zeros((4,4))
    for k in range(4):
        for t in range(k,4):mat[k,t]=(.9*.8)**(t-k)
    fig,ax=plt.subplots(figsize=(7.4,4.4));ax.imshow(mat,cmap='YlGnBu',vmin=0,vmax=1)
    for k in range(4):
        for t in range(4):
            if t>=k:ax.text(t,k,f'{mat[k,t]:.3g}',ha='center',va='center',color='white' if mat[k,t]>.7 else INK,fontsize=17)
    ax.set(xticks=range(4),xticklabels=[r'$\delta_0=.05$',r'$\delta_1=-.05$',r'$\delta_2=-.05$',r'$\delta_3=.5$'],
           yticks=range(4),yticklabels=['k=0: S7','k=1: S4','k=2: S4','k=3: S4'],xlabel='later TD error t',ylabel='earlier visit k')
    ax.tick_params(length=0);save(fig,out,'credit-matrix')
    # Each disk is one surviving visit; repeated S4 visits share a table entry.
    fig,axs=plt.subplots(1,4,figsize=(11,3.5),sharey=True)
    for t,ax in enumerate(axs):
        ax.set(xlim=(-.5,1.5),ylim=(-.3,3.6));ax.axis('off');ax.set_title(f't={t}  (before write)',fontsize=14)
        for k in range(t+1):
            st=FIXED_STATES[k];v=(.72)**(t-k)
            ax.add_patch(Circle((st,2.9-.8*k),.22*np.sqrt(v),facecolor=TEAL if st==0 else GOLD,alpha=.3+.7*v))
            ax.text(st+.28,2.9-.8*k,f'{v:.3g}',va='center',fontsize=12)
        z=np.array([sum(.72**(t-k) for k in range(t+1) if FIXED_STATES[k]==s) for s in (0,1)])
        for st in (0,1):ax.text(st,-.1,f'{["S7","S4"][st]}\nz={z[st]:.4g}',ha='center',va='top',fontsize=13)
    fig.subplots_adjust(wspace=.16);save(fig,out,'fading-visits')
    # This zero-initialized mechanism isolates the arrival of terminal reward.
    fig,axs=plt.subplots(1,3,figsize=(10.4,3.4));maze(axs[0],[0,0],'Before R4=1')
    maze(axs[1],[0,.2],r'After: TD(0)');maze(axs[2],[.0746496,.44768],r'After: TD($\lambda=.8$)')
    save(fig,out,'reward-write')
    weights=np.array([.2,.16,.128,.512]);targets=np.array([.45,.405,.3645,.729])
    fig,axs=plt.subplots(1,2,figsize=(10,3.4),gridspec_kw={'width_ratios':[1,1.1]})
    axs[0].bar(range(1,5),weights,color=[TEAL,TEAL,TEAL,GOLD],width=.65)
    for i,v in enumerate(weights):axs[0].text(i+1,v+.015,f'{v:g}',ha='center',fontsize=14)
    axs[0].set(xlabel='n-step target',ylabel='mixture weight',xticks=range(1,5),ylim=(0,.62))
    axs[1].bar(range(1,5),weights*targets,color=[TEAL,TEAL,TEAL,GOLD],width=.65)
    axs[1].set(xlabel='n-step target',ylabel='weighted contribution',xticks=range(1,5),ylim=(0,.45))
    axs[1].text(2.5,.4,r'$G_0^\lambda=0.574704$',ha='center',color=TEAL,fontsize=19)
    fig.tight_layout();save(fig,out,'lambda-mixture')
    # Exact target distribution, not a simulated performance claim.
    fig,axs=plt.subplots(1,2,figsize=(10,3.5))
    for ax,n in zip(axs,(1,2)):
        p=np.r_[.1*.9**np.arange(n),.9**n];g=np.r_[.9**np.arange(n),.5*.9**n]
        ax.vlines(g,0,p,color=TEAL,lw=5);ax.scatter(g,p,color=TEAL,s=60)
        for value,prob in zip(g,p):ax.text(value,prob+.04,f'{prob:g}',ha='center',fontsize=13)
        ax.axvline(report['truth'][1],ls='--',color=RED);ax.set(xlim=(.28,1.1),ylim=(0,1.05),xlabel='target value',ylabel='probability',title=f'n={n}')
    fig.tight_layout();save(fig,out,'target-distribution')
    # Exact online sequences; circles are independent prefix recomputation.
    x=FEATURES[FIXED_STATES];f=online_forward(x,FIXED_REWARDS,[.4,.5],.2,.9,.8)
    t=true_online(x,FIXED_REWARDS,[.4,.5],.2,.9,.8);a,_=accumulating(x,FIXED_REWARDS,[.4,.5],.2,.9,.8)
    fig,axs=plt.subplots(1,2,figsize=(10.2,3.6))
    for j,ax in enumerate(axs):
        ax.plot(range(5),t[:,j],color=TEAL,lw=2,label='true-online recursion')
        ax.scatter(range(5),f[:,j],s=90,facecolors='none',edgecolors=TEAL,lw=1.6,label='direct forward recomputation',zorder=4)
        ax.plot(range(5),a[:,j],color=RED,ls='--',lw=2,label='ordinary accumulating trace')
        ax.set(title=['S7','S4'][j],xlabel='observed transitions h',ylabel='value',xticks=range(5))
    axs[1].legend(fontsize=9,loc='upper left');fig.tight_layout();save(fig,out,'online-equivalence')
    # Real multi-episode training; uncertainty is between independent seeds.
    truth=np.asarray(report['truth']);summary={}
    for kind in ('n','lambda'):
        fig,axs=plt.subplots(1,2,figsize=(10.6,3.8),sharey=True)
        params=(1,4,16) if kind=='n' else (0.,.8,1.)
        for ax,alpha in zip(axs,(.05,.2)):
            for c,param in zip(COLORS,params):
                arr=hist[(alpha,kind,param)];err=np.sqrt(np.mean((arr-truth)**2,axis=2));m=err.mean(axis=0);se=err.std(axis=0,ddof=1)/np.sqrt(len(err));ep=np.arange(1,len(m)+1)
                label=f'n={param}' if kind=='n' else rf'$\lambda={param:g}$'
                ax.plot(ep,m,label=label,color=c,lw=2);ax.fill_between(ep,m-se,m+se,color=c,alpha=.14)
                summary[f'{alpha}:{kind}:{param}']={f'RMSE_episode_{e}':float(m[e-1]) for e in (1,10,50,len(m))}
            ax.set(title=rf'$\alpha={alpha}$',xlabel='completed episodes',xlim=(1,len(m)),ylim=(0,.78 if kind=='lambda' else .53));ax.legend(fontsize=11)
        axs[0].set_ylabel('mean RMSE over S7, S4');fig.tight_layout();save(fig,out,'learning-'+kind)
    # A value map, aligned with the fixed arrows used in Chapter 5.
    fig,axs=plt.subplots(3,3,figsize=(8.2,7.4))
    for i,lam in enumerate((0.,.8,1.)):
        for j,ep in enumerate((1,10,200)):
            vals=hist[(.05,'lambda',lam)][:,ep-1].mean(axis=0)
            maze(axs[i,j],vals,rf'$\lambda={lam:g}$, episode {ep}')
    fig.subplots_adjust(wspace=.08,hspace=.32);save(fig,out,'value-maps')
    return summary


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--out',type=Path)
    parser.add_argument('--seeds',type=int,default=64);parser.add_argument('--episodes',type=int,default=200)
    args=parser.parse_args()
    if args.seeds<2:parser.error('At least two independent seeds are required for the standard-error band.')
    if args.episodes<200:parser.error('The comparison figures require at least 200 episodes.')
    root=Path(__file__).resolve().parents[1]
    out=args.out or (root/'assets/course15-traces' if (root/'chapters').exists() else Path(__file__).resolve().parent/'course15-traces-output')
    out.mkdir(parents=True,exist_ok=True);report=independent_checks()
    hist,lengths=train(args.seeds,args.episodes);summary=figures(out,report,hist,lengths)
    _,trace=accumulating(FEATURES[FIXED_STATES],FIXED_REWARDS,[.4,.5],.2,.9,.8)
    with (out/'four-step-trace.csv').open('w',newline='') as f:
        fields = ['t','reward','delta','z_S7','z_S4','old_S7','old_S4','new_S7','new_S4']
        writer = csv.DictWriter(f, fieldnames=fields, extrasaction='ignore')
        writer.writeheader()
        writer.writerows(trace)
    with (out/'training-values.csv').open('w',newline='') as f:
        writer=csv.writer(f);writer.writerow(['seed','episode','real_transitions','alpha','kind','parameter','S7','S4'])
        for (alpha,kind,param),arr in hist.items():
            for seed in range(args.seeds):
                cumulative=lengths[seed].cumsum()
                for ep in range(args.episodes):writer.writerow([seed,ep+1,int(cumulative[ep]),alpha,kind,param,*arr[seed,ep]])
    report['experiment']={'seeds':args.seeds,'seed_offset':150700,'episodes':args.episodes,'gamma':.9,'alphas':[.05,.2],
        'initial_values':[0.,0.],'policy':'fixed upward','success_probability':.1,
        'same_episodes_within_seed':True,'learning_curve_band':'mean +/- one standard error across independent seeds',
        'real_transitions_per_seed':lengths.sum(axis=1).tolist(),'source':'actual local execution, no tuned hyperparameters',
        'compute_budget':'same environmental data, different arithmetic cost and update count per transition'}
    report['learning_summary']=summary
    (out/'report.json').write_text(json.dumps(report,indent=2))
    print(json.dumps({'out':str(out),'checks':report['check_groups'],'linear_forward_cases':report['linear_forward_cases'],
                      'max_linear_error':report['max_linear_error'],'learning_summary':summary},indent=2))

if __name__=='__main__':main()
