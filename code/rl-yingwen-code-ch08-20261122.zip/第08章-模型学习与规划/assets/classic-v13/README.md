# 经典强化学习的机制图与计算

运行 `python demos/classic_v13_mechanisms.py` 重新生成五组解析图与 `results.json`。依赖 NumPy、Matplotlib；图中曲线为固定任务计算，未标作训练曲线。

- `contraction`：固定旧策略的期望更新，解析真值与两初值差。
- `target-distributions`：冻结尾值下的 TD 目标与 MC 几何回报分布。
- `trace-matrix`：同一冻结价值表下，访问与TD误差之间的资格权重。
- `true-online`：逐次重算 online λ-return 与 Dutch 递推的逐步比较。
- `model-error-budget`：固定模型偏差与模型内采样方差的分解。

`sutton-cliff-task` 和 `sutton-dyna-shortcut` 截取自 Sutton 与 Barto《Reinforcement Learning: An Introduction》第2版用户提供PDF；分别为 Example6.6、Figure8.5。作者与出处见课件页脚。它们保留原作者图示及原实验曲线，不属于本课新实验。原书入口：http://incompleteideas.net/book/the-book-2nd.html 。

`DynaQPlus` 提供直接学习、最近后果模型、模拟学习和 ε-greedy 行为。脚本末尾用确定的短序列检查真实时钟、未试动作模型与规划奖励。`online_forward` 与 `true_online` 分别按两种独立定义实现，其比较记录在 `results.json`。
