# 第 2 章　多臂赌博机：程序

本目录可以单独运行：在本目录下执行下面的命令即可，结果写回本目录的 `assets/`。目录由 `rl-course/tools/export_chapter_code.py` 从课程目录生成，改程序请改课程目录里的原件，再重新导出。

## 准备

```sh
python3 -m pip install -r requirements.txt
```

需要的第三方包：matplotlib、numpy。复现附录要求 Python 3.10 或更新版本；核验时用的版本见下表。

## 运行（与复现附录相同）

```sh
python3 demos/v17_bandit.py
python3 demos/classic_v6_lab.py
python3 demos/classic_v8_foundations.py
python3 demos/ch02_three_rules_regret.py
python3 demos/classic_foundations.py
python3 demos/classic_v9_checks.py
python3 demos/classic_v10_derivations.py
python3 demos/v18_classic.py
```

## 本目录的程序

| 程序 | 说明 | 核验 |
|---|---|---|
| `demos/v18_classic.py` | Exact teaching objects for v18 chapters 2--6. No training. | 通过（3 秒） |
| `demos/classic_foundations.py` | Small exact checks for chapters 2--8; standard library, no training. | 通过（0 秒） |
| `demos/classic_v10_derivations.py` | Reproducible chapter 2–8 derivations on the unchanged mud task. | 通过（0 秒） |
| `demos/classic_v9_checks.py` | Independent checks for v9 chapters 2–8; no training or old-output writes. | 通过（0 秒） |
| `demos/v17_bandit.py` | Two-armed bandit: action selection, incremental means, and actual behaviour. | 通过（2 秒） |
| `demos/classic_v6_lab.py` | Visible learning states for chapters 2--8. Local, small, reproducible runs. | 通过（1 秒） |
| `demos/classic_v8_foundations.py` | Reproducible calculations for chapters 2--8 (standard library only). | 通过（0 秒） |
| `demos/ch02_three_rules_regret.py` | 第 2 章抓取例：epsilon-贪心、UCB1、梯度赌博机在同一指标（期望伪遗憾）上的比较。 | 通过（79 秒） |
| `demos/ch02_greedy_lockin.py` | 第 2 章 ch02-greedy-asymmetry 表（纯贪心、样本均值）复算：最后千轮(9001–10000)多数选 A 的运行比例。平局随机；另给“平局取 A”作对照。 | 通过（61 秒） |
| `demos/ch02_optimistic_table.py` | 第 2 章 ch02-optimistic-exp 表前三行复算（11-21 全局方案 D01）。 | 超时：300 秒内未跑完（启动正常） |

被上面程序 import 的本课模块：`demos/mud_world.py`、`demos/plot_fonts.py`。

表中后 2 个程序复现附录本章一节没有列出，来自课件、阅读稿、CODE-MAP 或文件名前缀（第三部分另含学习器阶梯）。

## 复现附录本章一节

本章的结果来自两类程序。模拟程序给出两臂抓取例的选择记录、价值估计与行为比例，梯度赌博机的单次与多次运行，以及 2.4 节 ε-贪心、UCB1 与梯度赌博机的期望伪遗憾曲线；伪遗憾是 4000 次独立运行的平均，表中同时给出标准误。精确计算程序给出机会损失、平方损失、随机停止和常数步长的权重，这些数不含随机性。

梯度赌博机种子 7 的单次运行沿用 demos/classic_v8_foundations.py 的随机数流，两个程序可以逐步对照。十臂测试平台的曲线取自 Sutton 与 Barto 图 2.2，不在下表。

| 位置 | 结果 | 设置 | 程序 | 数据与输出 |
|---|---|---|---|---|
| “多臂赌博机与累计伪遗憾” | 指定五次选择的均值机会损失，选 A 两次累计 .4 | 精确计算：真值 .4 与 .6，指定行动序列，无训练 | `demos/v18_classic.py` | `assets/v18-classic/bandit-regret.png`、`assets/v18-classic/checks.json` |
| “动作样本均值的增量更新”；“动作选择、更新与实际行为”的更新表 | A 的第 5 份奖励为 0：$N$ 由 4 到 5，$Q$ 由 .75 到 .60 | 有限算术核对：增量样本均值与全历史均值一致，程序共 58 项核对，不含训练 | `demos/classic_foundations.py` | `demos/classic-foundations-results.json` |
| “平方损失与奖励均值”（课件 `classic-v10-mean-objective`） | 总体风险与样本 1、1、0、1 的经验风险曲线，经验最小点 .75 | 解析计算，无训练 | `demos/classic_v10_derivations.py` | `assets/classic-v10/mean-risk.dat`、`assets/classic-v10/derivations.json` |
| “样本均值的无偏性与一致性” | 首次得 1 即停止、否则再取一个样本时，样本均值的期望 .625 | 对全部结果枚举的精确计算 | `demos/classic_v9_checks.py` | `assets/v9-classic/checks.json` |
| “动作选择、更新与实际行为”（课件 `v17-bandit-values`、`v17-bandit-behaviour`） | 一次运行中的选择与两动作估计；最近 100 步选 B 的比例，末段均值约 .949 | 本课的模拟：Bernoulli 两臂，成功率 .4 与 .6，$\varepsilon=.1$，零初值，样本均值更新，每次运行 2000 步，独立重复 32 次（种子 0–31），单次运行图取种子 7；阴影为均值的一个标准误 | `demos/v17_bandit.py` | `assets/v17-bandit/action-value.png`、`assets/v17-bandit/behaviour.png`、`assets/v17-bandit/results.json`、`assets/v17-bandit/seed7-trace.csv` |
| “ε-greedy 的价值估计与行为概率” | 20、200、2000 次选择后的估计与访问数；2000 次后约 .388 与 .596，$N$ 为 116 与 1884；200 次后选 B 的概率 .95 | 本课的模拟：同一两臂任务，$\varepsilon=.1$，零初值，一次运行，种子 7，2000 步 | `demos/classic_v6_lab.py` | `assets/v6-classic/bandit-estimates.png`、`assets/v6-classic/results.json` |
| 2.5 节“梯度赌博机”（课件 `classic-v8-gradient-behavior`） | 第 2000 次选择前 $\pi(B)\approx.991$，累计奖励均值 .5825；1999 次更新中有 798 次使 $\pi(B)$ 下降；4000 次运行的均值 .986 与另外 8 次单次运行；同程序含 UCB 的完整交互循环 | 本课的模拟：同一两臂任务，梯度赌博机 $\alpha=.1$，基线为过去奖励均值，一次运行，种子 7，2000 步；梯度公式另以枚举期望与有限差分检验 | `demos/classic_v8_foundations.py`；`demos/ch02_three_rules_regret.py` | `assets/ch02-explore/gradient-runs.dat`、`assets/v8-classic/gradient-bandit.dat`、`assets/v8-classic/results.json` |
| “常数步长与指数加权平均” | 常数步长的权重与平稳噪声图；最近 5 个奖励的总权重 .40951、.67232、.96875（$\alpha=.1,.2,.5$）；平稳方差比 .05263、.11111、.33333 | 几何级数的精确计算，左图与 20 份样本均值比较 | `demos/v18_classic.py`；`demos/classic_v9_checks.py` | `assets/v18-classic/constant-weights.png`、`assets/v18-classic/checks.json`、`assets/v9-classic/checks.json` |
| 2.4 节（课件 `ch02-ucb-egreedy-regret`） | ε-贪心、UCB1 与梯度赌博机的期望伪遗憾曲线；约 4000 轮后 UCB1 低于 ε-贪心；$T=10\,000$ 时依次为 107.13、61.77、35.94，标准误不超过 .34；UCB1 的上界 $8\ln T/.2$ 在 $T=10^4$ 处约 368 | 本课的模拟：Bernoulli 两臂，成功率 .4 与 .6，零初值；ε-贪心 $\varepsilon=.1$；UCB1；梯度赌博机 $\alpha=.1$，基线为过去奖励的平均（$\bar R_0=0$）；每种规则独立重复 4000 次，种子 20261121、20261122、20261123；梯度赌博机的种子 7 单次运行沿用 demos/classic_v8_foundations.py 的随机数流 | `demos/ch02_three_rules_regret.py` | `assets/ch02-explore/regret-three-rules.dat`、`assets/ch02-explore/regret-three-rules.json`、`assets/ch02-explore/gradient-runs.dat` |

外部代码（出处）：无。十臂测试平台图取自 Sutton 与 Barto 第 2 版图 2.2；UCB 分数图与观测示意图是课件 TikZ 页面的截图或外部教程中的插图，均不依赖本课的程序。

运行：
```sh
python3 demos/v17_bandit.py
python3 demos/classic_v6_lab.py
python3 demos/classic_v8_foundations.py
python3 demos/ch02_three_rules_regret.py
python3 demos/classic_foundations.py
python3 demos/classic_v9_checks.py
python3 demos/classic_v10_derivations.py
python3 demos/v18_classic.py
```

## 参考数据

`assets/`（以及 `demos/NN-results/`）下复制了 12 个数据文件（json、csv 等），即课程目前使用的结果；图片没有复制，运行程序会重新画出。重跑会覆盖这些文件，可以先另存一份再对照。
