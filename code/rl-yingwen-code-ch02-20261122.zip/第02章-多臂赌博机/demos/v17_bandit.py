"""Two-armed bandit: action selection, incremental means, and actual behaviour.
Run from any directory: python demos/v17_bandit.py
Environment: independent Bernoulli rewards with means (0.4, 0.6).
The learner receives only the reward of the selected action.
"""
from pathlib import Path
import csv,json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

OUT=Path(__file__).resolve().parents[1]/'assets/v17-bandit'
TEAL='#087e8b';RED='#c65335';MUTED='#61757d'

def run(seed,steps=2000,epsilon=.1):
    rng=np.random.default_rng(seed)
    means=np.array([.4,.6])  # Used by environment/evaluation only.
    q=np.zeros(2);counts=np.zeros(2,dtype=int);rows=[]
    for t in range(steps):
        # 1. Choose using the PRE-UPDATE estimates. Break ties uniformly.
        greedy=np.flatnonzero(q==q.max())
        a=int(rng.integers(2) if rng.random()<epsilon else rng.choice(greedy))
        # 2. Environment supplies one reward; no unchosen reward is exposed.
        reward=int(rng.random()<means[a]);old=q.copy()
        # 3. Increment the selected action's count, then update its mean.
        counts[a]+=1;alpha=1./counts[a];q[a]+=alpha*(reward-q[a])
        rows.append([t+1,a,reward,alpha,*old,*q,*counts])
    return np.array(rows)

def check_incremental_mean(rows):
    # Independent recomputation from the full recorded reward history.
    for a in [0,1]:
        selected=rows[:,1]==a
        sums=np.cumsum(np.where(selected,rows[:,2],0))
        counts=np.cumsum(selected)
        direct=np.divide(sums,counts,out=np.zeros(len(rows)),where=counts>0)
        np.testing.assert_allclose(rows[:,6+a],direct,rtol=0,atol=3e-15)
        np.testing.assert_array_equal(rows[:,8+a],counts)
        np.testing.assert_allclose(rows[~selected,6+a],rows[~selected,4+a],atol=0,rtol=0)

if __name__=='__main__':
    OUT.mkdir(exist_ok=True)
    seeds=range(32);runs=np.stack([run(s) for s in seeds]);first=runs[7]
    for r in runs:check_incremental_mean(r)
    with (OUT/'seed7-trace.csv').open('w') as f:
        w=csv.writer(f);w.writerow(['step','action','reward','alpha','Q_A_before','Q_B_before','Q_A_after','Q_B_after','N_A','N_B']);w.writerows(first)
    plt.rcParams.update({'font.size':11,'axes.spines.top':False,'axes.spines.right':False,'figure.facecolor':'white'})
    fig,axs=plt.subplots(2,1,figsize=(10.8,4.9),gridspec_kw={'height_ratios':[.48,2.6]},sharex=True,layout='constrained')
    for a,c in [(0,RED),(1,TEAL)]:
        ix=first[:200,1]==a
        axs[0].scatter(first[:200,0][ix],np.full(ix.sum(),a),s=8,c=c,marker='|')
        axs[1].plot(first[:200,0],first[:200,6+a],c=c,lw=1.8,label=f'Q({chr(65+a)})')
        axs[1].axhline([.4,.6][a],c=c,ls='--',alpha=.6)
    axs[0].set_yticks([0,1],['A','B']);axs[0].set_ylabel('Action');axs[0].set_ylim(-.5,1.5)
    axs[1].set(xlabel='Interactions',ylabel='Estimated mean',ylim=(-.04,1.04),xlim=(0,200));axs[1].legend(ncols=2)
    for ext in ['pdf','png']:fig.savefig(OUT/f'action-value.{ext}',dpi=160)
    plt.close(fig)
    b=100;p=(runs[:,:,1]==1).reshape(32,-1,b).mean(2);x=np.arange(b,2001,b)
    fig,ax=plt.subplots(figsize=(10.8,3.1),layout='constrained');mean=p.mean(0);sem=p.std(0,ddof=1)/np.sqrt(32)
    ax.plot(x,mean,c=TEAL);ax.fill_between(x,mean-sem,mean+sem,color=TEAL,alpha=.2)
    ax.axhline(.95,c=MUTED,ls='--',label='0.95 if B is greedy');ax.set(xlabel='Interactions',ylabel='Fraction choosing B\n(last 100 steps)',ylim=(0,1.02));ax.legend(loc='lower right')
    for ext in ['pdf','png']:fig.savefig(OUT/f'behaviour.{ext}',dpi=160)
    plt.close(fig)
    report={'task':'two independent Bernoulli arms','means':[.4,.6],'epsilon':.1,'seeds':list(seeds),'steps_per_seed':2000,'trace_seed':7,'checks':'all 64000 steps: incremental mean equals full-history mean; counts agree; unselected estimate unchanged','last_100_B_fraction_mean':float(p[:,-1].mean()),'last_100_B_fraction_sem':float(sem[-1]),'seed7_final_q':first[-1,6:8].tolist(),'seed7_rewards_mean':float(first[:,2].mean()),'note':'Pointwise mean +/- one standard error across 32 independent runs; no universal performance comparison.'}
    (OUT/'results.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
