"""第 2 章抓取例：epsilon-贪心、UCB1、梯度赌博机在同一指标（期望伪遗憾）上的比较。

11-21 请求 r1121-105336 新增。设定与 ch02-ucb-egreedy-regret 页相同：
两臂 Bernoulli，q_* = (.4, .6)，A 为次优动作，差距 .2；零初值；固定随机种子。
伪遗憾 = .2 x（A 被选中的次数），对 RUNS 次独立运行取平均。

- epsilon-贪心：epsilon=.1，样本均值，并列均匀抽取（算法 2.1）。
- UCB1：每臂先试一次，此后分数 Q + sqrt(2 ln t / N)，t 为已完成的试次（算法 2.2）。
- 梯度赌博机：alpha=.1，基线为此前奖励的平均、R̄_0=0、偏好更新后才更新基线（算法 2.3）。

另输出梯度赌博机若干次单独运行的 pi(B) 轨迹（ch02 第 116 页用）：
seed-7 那一次沿用 demos/classic_v8_foundations.py 的 random.Random(7) 运行，逐步记录。

输出：
  assets/ch02-explore/regret-three-rules.dat   T  eps  ucb  grad  （以及各自标准误）
  assets/ch02-explore/regret-three-rules.json  设定与关键数
  assets/ch02-explore/gradient-runs.dat         step  run7  r1..r8  mean
"""
import json
import math
import random
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "assets" / "ch02-explore"
Q_STAR = np.array([.4, .6])
GAP = .2
RUNS = 4000
T_MAX = 100_000
GRID = sorted({int(round(10 ** (k / 10))) for k in range(10, 51)})


def record(counts_a, t, rows):
    """counts_a: A 的累计选择次数（各运行）。t: 已完成轮数。"""
    if t in rows:
        x = GAP * counts_a
        rows[t] = (x.mean(), x.std(ddof=1) / math.sqrt(len(x)))


def run_eps(seed, eps=.1):
    rng = np.random.default_rng(seed)
    n = np.zeros((RUNS, 2)); q = np.zeros((RUNS, 2)); cnt_a = np.zeros(RUNS)
    rows = {t: None for t in GRID}
    idx = np.arange(RUNS)
    for t in range(1, T_MAX + 1):
        tie = rng.random(RUNS) < .5
        greedy = np.where(q[:, 0] > q[:, 1], 0, np.where(q[:, 1] > q[:, 0], 1, tie.astype(int)))
        explore = rng.random(RUNS) < eps
        rand_a = (rng.random(RUNS) < .5).astype(int)
        a = np.where(explore, rand_a, greedy)
        r = (rng.random(RUNS) < Q_STAR[a]).astype(float)
        n[idx, a] += 1; q[idx, a] += (r - q[idx, a]) / n[idx, a]
        cnt_a += (a == 0)
        record(cnt_a, t, rows)
    return rows


def run_ucb(seed):
    rng = np.random.default_rng(seed)
    n = np.zeros((RUNS, 2)); q = np.zeros((RUNS, 2)); cnt_a = np.zeros(RUNS)
    rows = {t: None for t in GRID}
    idx = np.arange(RUNS)
    for t in range(1, T_MAX + 1):          # 第 t 轮之前已完成 t-1 次
        done = t - 1
        if done < 2:
            a = np.full(RUNS, done)
        else:
            s = q + np.sqrt(2 * math.log(done) / n)
            tie = (rng.random(RUNS) < .5).astype(int)
            a = np.where(s[:, 0] > s[:, 1], 0, np.where(s[:, 1] > s[:, 0], 1, tie))
        r = (rng.random(RUNS) < Q_STAR[a]).astype(float)
        n[idx, a] += 1; q[idx, a] += (r - q[idx, a]) / n[idx, a]
        cnt_a += (a == 0)
        record(cnt_a, t, rows)
    return rows


def run_grad(seed, alpha=.1, keep_traj=0):
    rng = np.random.default_rng(seed)
    th = np.zeros((RUNS, 2)); base = np.zeros(RUNS); cnt_a = np.zeros(RUNS)
    rows = {t: None for t in GRID}
    idx = np.arange(RUNS)
    traj = []          # 每轮选择前的 pi(B)：前 keep_traj 次运行 + 全体平均
    for t in range(1, T_MAX + 1):
        z = np.exp(th - th.max(axis=1, keepdims=True)); p = z / z.sum(axis=1, keepdims=True)
        if t <= 2000:
            traj.append(np.concatenate([p[:keep_traj, 1], [p[:, 1].mean()]]))
        a = (rng.random(RUNS) >= p[:, 0]).astype(int)
        r = (rng.random(RUNS) < Q_STAR[a]).astype(float)
        onehot = np.zeros((RUNS, 2)); onehot[idx, a] = 1
        th += alpha * (r - base)[:, None] * (onehot - p)
        base += (r - base) / t
        cnt_a += (a == 0)
        record(cnt_a, t, rows)
    return rows, np.array(traj)


def run7_trace():
    """与 demos/classic_v8_foundations.py 相同的 random.Random(7) 单次运行，逐步记录选择前的 pi(B)。"""
    rng = random.Random(7); pref = [0., 0.]; base = 0.; out = []
    for t in range(2000):
        w = [math.exp(x - max(pref)) for x in pref]; p = [x / sum(w) for x in w]
        out.append(p[1])
        a = int(rng.random() >= p[0]); r = float(rng.random() < [.4, .6][a])
        inc = [.1 * (r - base) * (float(c == a) - p[c]) for c in range(2)]
        pref = [x + d for x, d in zip(pref, inc)]; base += (r - base) / (t + 1)
    return out, base


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    eps = run_eps(20261121)
    ucb = run_ucb(20261122)
    grad, traj = run_grad(20261123, keep_traj=8)
    with open(OUT / "regret-three-rules.dat", "w") as f:
        f.write("T eps ucb grad eps_se ucb_se grad_se\n")
        for t in GRID:
            f.write(f"{t} {eps[t][0]:.3f} {ucb[t][0]:.3f} {grad[t][0]:.3f} "
                    f"{eps[t][1]:.3f} {ucb[t][1]:.3f} {grad[t][1]:.3f}\n")
    r7, base7 = run7_trace()
    with open(OUT / "gradient-runs.dat", "w") as f:
        f.write("step run7 " + " ".join(f"r{i+1}" for i in range(8)) + " mean\n")
        for k in range(2000):
            f.write(f"{k+1} {r7[k]:.5f} " + " ".join(f"{x:.5f}" for x in traj[k]) + "\n")
    key = {t: {"eps": round(eps[t][0], 2), "ucb": round(ucb[t][0], 2), "grad": round(grad[t][0], 2),
               "se": [round(eps[t][1], 2), round(ucb[t][1], 2), round(grad[t][1], 2)]}
           for t in (1000, 1995, 10000, 100000)}
    meta = {"setup": "q*=(.4,.6) Bernoulli, gap .2, zero init, pseudo-regret = .2*E[N_T(A)]",
            "runs": RUNS, "seeds": {"eps": 20261121, "ucb": 20261122, "grad": 20261123},
            "eps": .1, "grad_alpha": .1, "grad_baseline": "running mean of past rewards, R0=0",
            "ucb1_bound_T1e4": 8 * math.log(1e4) / GAP,
            "run7_pi_B_before_2000": r7[-1], "run7_final_baseline": base7,
            "mean_pi_B_before_2000": float(traj[-1, -1]), "key": key}
    (OUT / "regret-three-rules.json").write_text(json.dumps(meta, indent=1, ensure_ascii=False))
    print(json.dumps(meta, indent=1, ensure_ascii=False))


if __name__ == "__main__":
    main()
