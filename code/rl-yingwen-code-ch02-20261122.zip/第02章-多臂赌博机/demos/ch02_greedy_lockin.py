"""第 2 章 ch02-greedy-asymmetry 表（纯贪心、样本均值）复算：最后千轮(9001–10000)多数选 A 的运行比例。平局随机；另给“平局取 A”作对照。"""
import numpy as np, json
def run(QA, NA, QB, NB, runs=20000, T=10000, seed=0, tie='random'):
    rng = np.random.default_rng(seed); q = np.array([.4, .6]); idx = np.arange(runs)
    S = np.zeros((runs, 2)); N = np.zeros((runs, 2))
    S[:, 0], N[:, 0], S[:, 1], N[:, 1] = QA * NA, NA, QB * NB, NB
    last = np.zeros(runs)
    for t in range(T):
        Q = np.where(N > 0, S / np.maximum(N, 1), 0.0)
        tieq = Q[:, 0] == Q[:, 1]
        pick_tie = rng.integers(0, 2, runs) if tie == 'random' else np.zeros(runs, int)
        a = np.where(tieq, pick_tie, (Q[:, 1] > Q[:, 0]).astype(int))
        r = (rng.random(runs) < q[a]).astype(float)
        S[idx, a] += r; N[idx, a] += 1
        if t >= T - 1000: last += (a == 0)
    return float((last > 500).mean())
def try_each_once(runs=20000, T=10000, seed=0, tie='random'):
    # 各试一次（顺序随机）后贪心：等价于 A、B 各一次初始记录
    rng = np.random.default_rng(seed + 99)
    rA = (rng.random(runs) < .4).astype(float); rB = (rng.random(runs) < .6).astype(float)
    # 向量化：每个运行初值不同，复用 run 的逻辑
    q = np.array([.4, .6]); idx = np.arange(runs)
    S = np.stack([rA, rB], 1); N = np.ones((runs, 2)); last = np.zeros(runs)
    rng2 = np.random.default_rng(seed)
    for t in range(T - 2):
        Q = S / N; tieq = Q[:, 0] == Q[:, 1]
        pick_tie = rng2.integers(0, 2, runs) if tie == 'random' else np.zeros(runs, int)
        a = np.where(tieq, pick_tie, (Q[:, 1] > Q[:, 0]).astype(int))
        r = (rng2.random(runs) < q[a]).astype(float); S[idx, a] += r; N[idx, a] += 1
        if t >= T - 2 - 1000: last += (a == 0)
    return float((last > 500).mean())
res = {}
for tie in ('random', 'A'):
    res[tie] = {
      'chapter_record_A3/4_B1/2': run(.75, 4, .5, 2, seed=1, tie=tie),
      'A3/4_B1/3': run(.75, 4, 1/3, 3, seed=2, tie=tie),
      'both_zero': run(0, 0, 0, 0, seed=3, tie=tie),
      'try_each_once': try_each_once(seed=4, tie=tie)}
print(json.dumps(res, indent=1))
