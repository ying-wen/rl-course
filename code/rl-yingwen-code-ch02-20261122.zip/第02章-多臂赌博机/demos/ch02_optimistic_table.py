"""第 2 章 ch02-optimistic-exp 表前三行复算（11-21 全局方案 D01）。
设定：q*=(.4,.6) Bernoulli（A=臂0，B=臂1），差距 .2；贪心选择，平局随机。
遗憾 = .2 * E[N_T(A)]（伪遗憾）；“最后千轮多数选 A”= 第 9001–10000 轮中选 A 超过 500 次的运行比例。
"""
import numpy as np, json, sys
def run(rule, runs=20000, T=100000, seed=0):
    rng = np.random.default_rng(seed)
    q = np.array([.4, .6])
    if rule == 'opt_alpha': Q = np.full((runs, 2), 2.0); alpha = .1
    elif rule == 'opt_mean': Q = np.full((runs, 2), 2.0); alpha = None
    elif rule == 'zero_alpha': Q = np.zeros((runs, 2)); alpha = .1
    N = np.zeros((runs, 2)); nA = np.zeros(runs); lastA = np.zeros(runs)
    out = {}; idx = np.arange(runs)
    for t in range(T):
        tie = Q[:, 0] == Q[:, 1]
        a = np.where(tie, rng.integers(0, 2, runs), (Q[:, 1] > Q[:, 0]).astype(int))
        r = (rng.random(runs) < q[a]).astype(float)
        N[idx, a] += 1
        if alpha is None: Q[idx, a] += (r - Q[idx, a]) / N[idx, a]
        else: Q[idx, a] += alpha * (r - Q[idx, a])
        nA += (a == 0)
        if 9000 <= t < 10000: lastA += (a == 0)
        if t + 1 in (1000, 10000, 100000):
            out[t + 1] = (round(.2 * nA.mean(), 2), round(.2 * nA.std() / np.sqrt(runs), 2))
    out['lockA_last1000_of_1e4'] = float((lastA > 500).mean())
    return out
if __name__ == '__main__':
    T = int(sys.argv[1]) if len(sys.argv) > 1 else 100000
    res = {r: run(r, T=T, seed=20261121 + i) for i, r in enumerate(['opt_alpha', 'opt_mean', 'zero_alpha'])}
    print(json.dumps(res, indent=1, default=str))
