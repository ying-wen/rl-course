"""Exact teaching objects for v18 chapters 2--6. No training.
Run: python /absolute/path/to/demos/v18_classic.py (numpy, matplotlib).
Existing task model is independently checked against coordinate dynamics.
"""
from pathlib import Path
import json
from itertools import product
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle,FancyArrowPatch,Circle
from matplotlib import font_manager
from plot_fonts import chinese_font,use_course_fonts,CJK_FAMILY,no_leading_zero
import sys
from mud_world import STATES,OLD,NEW,outcomes,GAMMA
OUT=Path(__file__).resolve().parents[1]/'assets'/'v18-classic'
C='#087E8B';D='#C65335';K='#182E38';G='#C4942A';M='#61757D'
cjk = chinese_font()
font_manager.fontManager.addfont(cjk.get_file())
plt.rcParams.update({'font.family':[cjk.get_name(),'DejaVu Sans'],'font.size':15,'axes.spines.top':False,'axes.spines.right':False,'mathtext.fontset':'dejavusans'})
def save(fig,name):
 fig.savefig(OUT/(name+'.pdf'),bbox_inches='tight',facecolor='white')
 fig.savefig(OUT/(name+'.png'),bbox_inches='tight',facecolor='white',dpi=170);plt.close(fig)
def arrow(a,p,q,color=C,label=None,dy=0,ms=15,shrink=2):
 a.add_patch(FancyArrowPatch(p,q,arrowstyle='-|>',color=color,lw=2,mutation_scale=ms,shrinkA=shrink,shrinkB=shrink))
 if label:a.text((p[0]+q[0])/2,(p[1]+q[1])/2+dy,label,ha='center',color=color,bbox={'fc':'white','ec':'none','pad':1})
def node(a,p,t,color=K):
 a.add_patch(Circle(p,.22,fc='white',ec=color,lw=1.5,zorder=3));a.text(*p,t,ha='center',va='center',zorder=4)
def regret():
 f,a=plt.subplots(figsize=(9,2.5));act=['A','B','B','A','B'];gap=[.2,0,0,.2,0]
 a.bar(np.arange(5),gap,color=[D if v else C for v in gap],width=.55)
 a.set(xticks=np.arange(5),xticklabels=[f'{i+1}: {x}' for i,x in enumerate(act)],yticks=[0,.1,.2],ylim=(0,.3),xlabel='指定的五次动作选择',ylabel='均值机会损失')
 for i,x in enumerate(gap):a.text(i,x+.015,f'{x:g}',ha='center')
 a.text(2,.26,r'$\Delta(A)=.2,\ \Delta(B)=0;\quad 2(.2)+3(0)=.4$',ha='center')
 save(f,'bandit-regret')
def weights():
 f,(a,b)=plt.subplots(1,2,figsize=(10,2.9));age=np.arange(20)
 a.bar(age-.18,.2*.8**age,width=.36,color=C,label=r'常步长 $.2$')
 a.bar(age+.18,np.full(20,1/20),width=.36,color=G,label='20个样本均值')
 a.set(xlabel='样本年龄（0为最新）',ylabel='当前估计中的权重',xticks=[0,5,10,15],ylim=(0,.24));a.legend(frameon=False,fontsize=11)
 aa=np.linspace(0,.8,200);b.plot(aa,aa/(2-aa),color=D)
 for x in [.1,.2,.5]:b.scatter([x],[x/(2-x)],color=D);b.annotate(f'{x/(2-x):.5f}',(x,x/(2-x)),xytext=(5,8),textcoords='offset points',fontsize=11)
 b.set(xlabel=r'常步长 $\alpha$',ylabel=r'平稳极限方差 $/\sigma^2$',xlim=(0,.8),ylim=(0,.7));f.tight_layout();save(f,'constant-weights')
def vq():
 f,a=plt.subplots(figsize=(9,2.8));node(a,(0,0),r'$S_7$');node(a,(3,1),r'$S_4$');node(a,(3,-1),r'$S_6$')
 arrow(a,(.2,.1),(2.75,.95),label=r'$\pi(\uparrow|S_7)=.5$',dy=.3)
 arrow(a,(.2,-.1),(2.75,-.95),label=r'$\pi(\leftarrow|S_7)=.5$',dy=-.3)
 a.text(3.5,1,r'$q_\pi(S_7,\uparrow)=9/19$',va='center');a.text(3.5,-1,r'$q_\pi(S_7,\leftarrow)=.9^5$',va='center')
 a.text(5.1,0,'此后都执行旧箭头',ha='center',color=M)
 a.set(xlim=(-.4,7.5),ylim=(-1.6,1.6));a.axis('off');save(f,'policy-vq')
def coord_model():
 xy={'S1':(0,0),'S2':(1,0),'G':(2,0),'S3':(0,1),'S4':(2,1),'S5':(0,2),'S6':(1,2),'S7':(2,2)};inv={v:k for k,v in xy.items()};d={}
 for s in STATES:
  for act,(dx,dy) in {'up':(0,-1),'right':(1,0),'down':(0,1),'left':(-1,0)}.items():
   x,y=xy[s];t=inv.get((x+dx,y+dy),s);z={}
   for p,n in ([(.9,s),(.1,t)] if s=='S4' else [(1,t)]):z[n,float(n=='G')]=z.get((n,float(n=='G')),0)+p
   d[s,act]=z
 return d
def fmt3(v):
 """Slide style: .729, 1.00, 0."""
 if v==0:return '0'
 return f'{v:.2f}' if v>=1 else f'{v:.3f}'[1:]
# 11-21 r1121-110741：第 4 章两图（dp-order、action-intervals）改用课件字体，缩放后字号不小于 7pt；
# 只重出这两幅用 python3 v18_classic.py --ch04（不改 checks.json 与其他章的图）。
def grid(a,vals,title):
 pos={'S1':(0,2),'S2':(1,2),'G':(2,2),'S3':(0,1),'S4':(2,1),'S5':(0,0),'S6':(1,0),'S7':(2,0)}
 for x in range(3):
  for y in range(3):a.add_patch(Rectangle((x,y),1,1,fc=K if(x,y)==(1,1) else '#EAF4F3',ec=M))
 for s,(x,y) in pos.items():
  if s=='S4':a.add_patch(Rectangle((x,y),1,1,fc='#F2DEAF',ec=M))
  a.text(x+.05,y+.94,s,fontsize=12.5,va='top')
  a.text(x+.5,y+.40,'终点' if s=='G' else fmt3(vals[s]),ha='center',fontsize=14.5)
  if s!='G':
   dx,dy={'right':(.36,0),'left':(-.36,0),'up':(0,.3)}[NEW[s]];arrow(a,(x+.5-dx/2,y+.2-dy/2),(x+.5+dx/2,y+.2+dy/2),ms=10,shrink=0)
 a.set(xlim=(-.1,3.1),ylim=(-.1,3.45),aspect='equal');a.text(1.5,3.18,title,ha='center',fontsize=15);a.axis('off')
def dp_order(tab):
 def bk(v,s):return sum(p*(r+.9*(0 if t=='G' else v[t])) for(t,r),p in tab[s,NEW[s]].items())
 zero=dict.fromkeys(STATES,0.);sync={s:bk(zero,s) for s in STATES};order=['S2','S1','S3','S5','S6','S7','S4'];v=zero.copy()
 for s in order:v[s]=bk(v,s)
 assert all(abs(v[s]-w)<1e-12 for s,w in zip(order,[1,.9,.81,.729,.6561,.59049,.1]))
 f,(a,b)=plt.subplots(1,2,figsize=(5.8,2.75));grid(a,sync,'同步：全部读旧表 0');grid(b,v,'原地：读本轮已更新的值');f.tight_layout(w_pad=.6);save(f,'dp-order')
 return {'policy':NEW,'order':order,'synchronous_first_sweep':sync,'in_place_first_sweep':v}
def matrix_model(tab):
 idx={s:i for i,s in enumerate(STATES)};p=np.zeros((7,7));r=np.zeros(7)
 for st,i in idx.items():
  for (n,re),mass in tab[st,OLD[st]].items():
   r[i]+=mass*re
   if n!='G':p[i,idx[n]]+=mass
 f,(a,b)=plt.subplots(1,2,figsize=(8,3.4),gridspec_kw={'width_ratios':[4,1]})
 a.imshow(p,cmap='Blues',vmin=0,vmax=1)
 for i in range(7):
  for j in range(7):
   if p[i,j]>0:a.text(j,i,f'{p[i,j]:g}',ha='center',va='center',color='white' if p[i,j]>.5 else K,fontsize=12)
 a.set(xticks=range(7),yticks=range(7),xticklabels=STATES,yticklabels=STATES,xlabel='下一非终止状态',ylabel='当前状态',title=r'$P_{\pi_0}$')
 a.tick_params(labelsize=11)
 b.imshow(r[:,None],cmap='Oranges',vmin=0,vmax=1)
 for i in range(7):b.text(0,i,f'{r[i]:g}',ha='center',va='center',fontsize=12)
 b.set(xticks=[],yticks=range(7),yticklabels=STATES,title=r'$r_{\pi_0}$');b.tick_params(labelsize=11)
 f.tight_layout();save(f,'mdp-matrix')
 v=np.linalg.solve(np.eye(7)-.9*p,r)
 assert abs(v[idx['S4']]-10/19)<1e-13
 return {'P':p.tolist(),'r':r.tolist(),'v':v.tolist()}
def action_intervals():
 eps=.02;g=.9;truth=np.array([9/19,.9**5]);estimate=truth+np.array([g*eps,-g*eps])
 assert np.all(np.abs(estimate-truth)<=g*eps+1e-14)
 assert estimate[1]-estimate[0]>2*g*eps
 f,a=plt.subplots(figsize=(7.0,1.95))
 a.errorbar(estimate,[0,1],xerr=g*eps,fmt='o',color=C,capsize=6,label=r'由近似表 $V$ 算出，半径 $\gamma\varepsilon$')
 a.scatter(truth,[0,1],marker='x',s=60,color=D,label=r'真值 $q_{\pi_0}$（仅供比较）')
 lo,hi=estimate[0]+g*eps,estimate[1]-g*eps
 for xx in (lo,hi):a.axvline(xx,color=M,ls=':',lw=1)
 a.annotate('',xy=(hi,.42),xytext=(lo,.42),arrowprops={'arrowstyle':'<->','color':K,'lw':1.2})
 a.text((lo+hi)/2,.62,r'间隙 > 0 $\Leftrightarrow$ 差 > $2\gamma\varepsilon$',ha='center',fontsize=13,fontfamily=CJK_FAMILY,bbox={'fc':'white','ec':'none','pad':1})
 a.set(yticks=[0,1],yticklabels=['向上','向左'],xticks=[.45,.50,.55,.60],xlim=(.44,.62),ylim=(-.5,1.85))
 a.set_xlabel(r'S7 的动作价值 $q(\mathrm{S7},a)$',fontfamily=CJK_FAMILY)
 a.xaxis.set_major_formatter(lambda x,_:f'{x:.2f}'[1:])
 a.legend(frameon=False,loc='upper left',ncol=2,prop={'family':CJK_FAMILY,'size':12.5},handletextpad=.3,columnspacing=1.2);a.grid(axis='x',alpha=.2)
 save(f,'action-intervals');return {'V_error':eps,'action_error_radius':g*eps,'true':truth.tolist(),'estimate':estimate.tolist()}
def gpi():
 old=9/19;new=.9**5;f,a=plt.subplots(figsize=(8,2.4));a.scatter([old,new],[0,1],s=90,color=C);a.scatter([old],[1],s=90,facecolor='white',edgecolor=D,zorder=4)
 arrow(a,(old,.06),(old,.94),color=D);arrow(a,(old+.004,1),(new-.004,1))
 a.text(old+.008,.45,'改善：改S7箭头',color=D,fontsize=13);a.text((old+new)/2,1.17,'评价：求新策略价值',ha='center',color=C,fontsize=13)
 a.set(yticks=[0,1],yticklabels=['S7向上','S7向左'],xlabel=r'存储的 $V(S_7)$',xlim=(.44,.63),ylim=(-.4,1.65),xticks=[old,new],xticklabels=['.473684','.590490']);a.grid(axis='x',alpha=.2)
 a.text(old,1.5,'空心点：新策略配旧表',ha='center',fontsize=12,color=D);save(f,'gpi-s7')
 return {'old':old,'after_improvement_stored_V':old,'after_evaluation':new}
def telescope():
 delta=np.array([.05,-.05,-.05,.5]);weighted=.9**np.arange(4)*delta
 assert abs(weighted.sum()-(.9**3-.4))<1e-14
 states=['S7','S4','S4','S4','G'];rewards=[0,0,0,1];v={'S7':.4,'S4':.5,'G':0}
 direct=np.array([r+.9*v[n]-v[st] for st,n,r in zip(states,states[1:],rewards)])
 assert np.allclose(delta,direct)
 assert abs(weighted.sum()-(sum(.9**t*r for t,r in enumerate(rewards))-v['S7']))<1e-14
 f,a=plt.subplots(figsize=(9,2.5));a.axhline(0,color=M,lw=1);a.bar(range(4),weighted,color=[C if d>0 else D for d in weighted],width=.6)
 a.set(xticks=range(4),xticklabels=[r'$S_7\to S_4$',r'$S_4\to S_4$',r'$S_4\to S_4$',r'$S_4\to G$'],ylabel=r'$\gamma^t\delta_t$',ylim=(-.12,.47))
 for i,w in enumerate(weighted):a.text(i,w+(.02 if w>0 else -.04),f'{w:g}',ha='center')
 a.text(1.5,.43,r'冻结 $V(S_7)=.4,V(S_4)=.5$；总和 $.329=.729-.4$',ha='center');save(f,'frozen-td-sum')
 return {'delta':delta.tolist(),'weighted':weighted.tolist(),'sum':float(weighted.sum())}
def is_weights():
 f,a=plt.subplots(figsize=(9,2.5));a.set(xlim=(-.4,6),ylim=(-.8,2.8));a.axis('off')
 for y,pa,pb,label in [(2,.5,.5,r'$b$'),(.8,.2,.8,r'$b\rho=\pi$')]:
  a.add_patch(Rectangle((0,y),5*pa,.55,fc=C,alpha=.65));a.add_patch(Rectangle((5*pa,y),5*pb,.55,fc=G,alpha=.65));a.text(-.15,y+.27,label,ha='right',va='center');a.text(5*pa/2,y+.27,f'L: {pa:g}',ha='center',va='center');a.text(5*pa+5*pb/2,y+.27,f'R: {pb:g}',ha='center',va='center')
 a.text(1.25,1.55,r'$\rho(L)=.2/.5=.4$',ha='center',fontsize=13);a.text(4,1.55,r'$\rho(R)=.8/.5=1.6$',ha='center',fontsize=13)
 a.text(2.5,-.35,r'$G(L)=1,\ G(R)=3.6;\quad .2(1)+.8(3.6)=3.08$',ha='center');save(f,'is-mass')
def double_tables():
 f,a=plt.subplots(figsize=(8,2.4));qa=np.array([.7,.4]);qb=np.array([.3,.6]);a.set(xlim=(-.7,4.8),ylim=(-.4,2.6));a.axis('off')
 for j,t in enumerate(['上','左']):a.text(j*1.5+.7,2.3,t,ha='center')
 for i,(name,arr) in enumerate([(r'$Q^A$',qa),(r'$Q^B$',qb)]):
  y=1.35-i;a.text(-.2,y+.25,name,ha='right',va='center')
  for j,n in enumerate(arr):a.add_patch(Rectangle((j*1.5,y),1.4,.55,fc='#C5E4DF' if j==0 else '#F3F5F5',ec=M));a.text(j*1.5+.7,y+.275,f'{n:g}',ha='center',va='center')
 arrow(a,(.7,1.3),(.7,.98),color=D)
 a.text(3.2,1.62,'A表选最大：上',va='center',color=C);a.text(3.2,.62,'B表读同一动作：.3',va='center',color=D)
 a.text(1.4,-.25,r'$r=0,\ \gamma=.9\ \Rightarrow\ y=.9(.3)=.27$',ha='center');save(f,'double-tables')
 return {'QA':qa.tolist(),'QB':qb.tolist(),'chosen_action':int(qa.argmax()),'target':float(.9*qb[qa.argmax()])}
def main():
 OUT.mkdir(parents=True,exist_ok=True);tab=coord_model()
 for k,z in tab.items():
  actual={}
  for p,t,r,_ in outcomes(*k):actual[t,r]=actual.get((t,r),0)+p
  assert actual==z
 checks={'layer':'exact finite computations and specified snapshots; no training','independent_model_pairs':len(tab),'regret_trace':{'actions':['A','B','B','A','B'],'gaps':[.2,0,0,.2,0],'sum':.4},'vq_mixture':.5*(9/19)+.5*.9**5}
 assert abs(checks['vq_mixture']-.5320871052631579)<1e-14
 actions=['A','B','B','A','B'];probs={'A':.4,'B':.6};expected=0.
 for rewards in product([0,1],repeat=5):
  probability=np.prod([probs[a] if rr else 1-probs[a] for a,rr in zip(actions,rewards)])
  expected+=probability*sum(rewards)
 assert abs(5*.6-expected-.4)<1e-14
 checks['regret_trace']['independent_32_path_expected_reward']=float(expected)
 regret();weights();vq();checks['matrix']=matrix_model(tab);checks['dp_order']=dp_order(tab);checks['action_intervals']=action_intervals();checks['gpi']=gpi();checks['frozen_td']=telescope();is_weights();checks['double_tables']=double_tables()
 assert abs(checks['double_tables']['target']-.27)<1e-14
 checks['weights']={str(x):{'last_five':1-(1-x)**5,'variance_ratio':x/(2-x)} for x in [.1,.2,.5]}
 for x in [.1,.2,.5]:
  variance=0.
  for _ in range(1000):variance=(1-x)**2*variance+x*x
  assert abs(variance-x/(2-x))<1e-13
  assert abs(sum(x*(1-x)**age for age in range(5))-(1-(1-x)**5))<1e-14
 checks['is_mean']=sum(p*r*f for p,r,f in zip([.5,.5],[.4,1.6],[1,3.6]));assert abs(checks['is_mean']-3.08)<1e-14
 assert abs((0+.9*4)-3.6)<1e-14
 assert abs(np.dot([.5,.5],[1,3.6])-2.3)<1e-14
 assert abs(np.dot([.2,.8],[1,3.6])-checks['is_mean'])<1e-14
 checks['importance_intro']={'returns':[1,3.6],'behavior':[.5,.5],'target':[.2,.8],'ratios':[.4,1.6],'behavior_mean':2.3,'target_mean':checks['is_mean']}
 checks['weighted_IS']={'weights':[2,0,0],'returns':[1,3.6,3.6],'ordinary':2/3,'weighted':1,'one_R_ordinary':1.6*3.6,'one_R_weighted':3.6}
 rr=np.array([2.,0.,0.]);gg=np.array([1.,3.6,3.6]);assert abs((rr@gg)/3-2/3)<1e-14 and abs((rr@gg)/rr.sum()-1)<1e-14
 checks['q_conditional_mean']=.9*(.9*.7)+.1*1
 assert abs(checks['q_conditional_mean']-.667)<1e-14
 phi=[2.,1.,0.];reward=[0.,1.];shaped=[reward[i]+.9*phi[i+1]-phi[i] for i in range(2)]
 assert abs(shaped[0]+.9*shaped[1]-(reward[0]+.9*reward[1]-phi[0]))<1e-14
 checks['potential_cancellation']={'original_return':.9,'shaped_return':shaped[0]+.9*shaped[1],'initial_potential':2.}
 checks['passed']=True;(OUT/'checks.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2));print(json.dumps({'passed':True,'figures':10,'output':str(OUT)},ensure_ascii=False))
def ch04():
 OUT.mkdir(parents=True,exist_ok=True);use_course_fonts()
 plt.rcParams.update({'font.size':14,'xtick.labelsize':13.5,'ytick.labelsize':13.5,'axes.spines.top':False,'axes.spines.right':False})
 tab=coord_model();dp_order(tab);print(json.dumps(action_intervals()))
if __name__=='__main__':
 if '--ch04' in sys.argv:ch04()
 else:main()
