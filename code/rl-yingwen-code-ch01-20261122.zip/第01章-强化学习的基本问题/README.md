# 第 1 章　强化学习的基本问题：程序

本目录可以单独运行：在本目录下执行下面的命令即可，结果写回本目录的 `assets/`。目录由 `rl-course/tools/export_chapter_code.py` 从课程目录生成，改程序请改课程目录里的原件，再重新导出。

## 准备

```sh
python3 -m pip install -r requirements.txt
```

需要的第三方包：matplotlib、numpy。复现附录要求 Python 3.10 或更新版本；核验时用的版本见下表。

## 运行（与复现附录相同）

```sh
python3 demos/problem_foundations.py
python3 demos/average_reward_clock.py
python3 demos/v18_problem.py
```

## 本目录的程序

| 程序 | 说明 | 核验 |
|---|---|---|
| `demos/problem_foundations.py` | Chapter 1: information, objectives, and reward shaping. | 通过（1 秒） |
| `demos/average_reward_clock.py` | Ice fishing, in environment steps. Run with Python 3, no dependencies. | 通过（0 秒） |
| `demos/v18_problem.py` | Exact two-step teaching task: experience, value estimates, and learning rewards. | 通过（1 秒） |

## 复现附录本章一节

本章的数字有两种来源。提示任务的学习曲线、目标比较图和两步任务的两组图由本课的程序产生：提示任务是随机模拟，独立重复 20 次；两步任务按指定的行动序列运行，不含随机抽样。取鱼例的数值是确定性计算，由一个只在终端输出的小程序复算，用来核对正文的算术。

课件中的其余图取自所引文献或由 TikZ 直接绘制，不依赖本课的程序。

| 位置 | 结果 | 设置 | 程序 | 数据与输出 |
|---|---|---|---|---|
| 1.2 节“观测、历史与内部状态” | 提示消失后的记忆示意图；只看当前画面的成功率上限 1/2，保留提示时可达 1 的学习曲线 | 本课的模拟：两步提示任务，终止动作价值更新 $Q\leftarrow Q+\alpha(R-Q)$，$\alpha=.1$，$\varepsilon=.1$，每次运行 2000 回合，每 100 回合对两种提示做精确贪心评价，独立重复 20 次；一位记忆由实验给定，不是学得的 | `demos/problem_foundations.py` | `assets/v5/cue-memory.png`、`assets/v5/cue-learning.png`、`demos/05-results/cue-learning.csv`、`demos/05-results/problem-foundations.json` |
| 1.3 节“奖励、回报与目标函数” | 取 $\gamma=.30$：单趟走右 1.2；持续重复时走左约 1.429、走右 1.319；六个环境步内的总数 6 与 12 | 确定性计算，无训练：左路一步得 1，右路两步得 4，取鱼后立即回到起点；默认 $\gamma=3/10$，计数窗口 6 步；单趟值 $1,4\gamma$，重复值 $1/(1-\gamma)$ 与 $4\gamma/(1-\gamma^2)$ | `demos/average_reward_clock.py` | 只在终端输出，不写文件 |
| 1.5 节“探索与经验怎样改变选择” | 两次实际执行的路线；执行 L、R 两回合后 $Q(L)=1$、$Q(R)=3.6$ | 确定性两步任务，$\gamma=.9$，指定的行动序列，不含随机抽样 | `demos/v18_problem.py` | `assets/v18-problem/experience-policy.png`、`assets/v18-problem/results.json` |
| 专题扩展“回合、折扣与平均奖励目标” | 奖励序列 $1,1,1,\ldots$ 与 $0,3,0,3,\ldots$ 的比较：$\gamma>1/2$ 时后者折扣回报更高，长期奖励率 1 与 1.5 | 解析计算，无训练 | `demos/problem_foundations.py` | `assets/v5/reward-objectives.png`、`demos/05-results/problem-foundations.json` |
| 专题扩展“策略评价与学习算法评价” | 两条指定行动序列在六个环境步内的总奖励 12 与 8；冻结后的贪心动作 R，回报 3.6 | 确定性两步任务，终止后立即重启，重启不占环境步 | `demos/v18_problem.py` | `assets/v18-problem/learner-rewards.png`、`assets/v18-problem/results.json` |

运行：
```sh
python3 demos/problem_foundations.py
python3 demos/average_reward_clock.py
python3 demos/v18_problem.py
```

## 参考数据

`assets/`（以及 `demos/NN-results/`）下复制了 5 个数据文件（json、csv 等），即课程目前使用的结果；图片没有复制，运行程序会重新画出。重跑会覆盖这些文件，可以先另存一份再对照。
