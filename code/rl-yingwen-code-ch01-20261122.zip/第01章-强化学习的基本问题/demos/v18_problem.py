"""Exact two-step teaching task: experience, value estimates, and learning rewards.

Run from any directory: python /absolute/path/to/demos/v18_problem.py
The first choices in the two short illustrations are specified, not generated
by a proposed exploration algorithm. All rewards come from executing the task.
The figures explain definitions; they do not compare learning algorithms.
"""
from pathlib import Path
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Circle

OUT = Path(__file__).resolve().parents[1] / 'assets/v18-problem'
TEAL, RED, MUTED = '#087e8b', '#c65335', '#61757d'


class TwoStep:
    """L: reward 1 and terminate; R: reward 0, then reward 4 and terminate."""
    def reset(self):
        self.state = 's'
        return self.state

    def step(self, action):
        assert self.state != 'terminal'
        if self.state == 's':
            assert action in ('L', 'R')
            self.state, reward = ('terminal', 1.) if action == 'L' else ('u', 0.)
        else:
            assert action == 'go'
            self.state, reward = 'terminal', 4.
        return self.state, reward, self.state == 'terminal'


def episode(first):
    env = TwoStep(); state = env.reset(); rows = []
    while state != 'terminal':
        action = first if state == 's' else 'go'
        nxt, reward, _ = env.step(action)
        rows.append((state, action, reward, nxt)); state = nxt
    return rows


def discounted_return(rows, gamma=.9):
    # Reverse recursion, independent of the direct two-step formula in check().
    total = 0.
    for _, _, reward, _ in reversed(rows):
        total = reward + gamma * total
    return total


def check():
    np.testing.assert_allclose(discounted_return(episode('L')), 1.)
    np.testing.assert_allclose(discounted_return(episode('R')), .9 * 4.)
    q = np.zeros(2); count = np.zeros(2, dtype=int); snapshots = []
    for a in (0, 1):  # First L, then one exploratory R; not a performance test.
        rows = episode(('L', 'R')[a]); target = discounted_return(rows)
        before = q.copy(); count[a] += 1
        q[a] += (target - q[a]) / count[a]
        assert q[1-a] == before[1-a]
        snapshots.append(q.copy())
    np.testing.assert_allclose(snapshots, [[1., 0.], [1., 3.6]])
    # Reset happens immediately after terminal, without an extra action or reward.
    fast = [row[2] for choice in ('R', 'R', 'R') for row in episode(choice)]
    slow = [row[2] for choice in ('L', 'L', 'L', 'L', 'R') for row in episode(choice)]
    assert len(fast) == len(slow) == 6
    assert sum(fast) == 12. and sum(slow) == 8.
    final_q = []
    for choices in (('R', 'R', 'R'), ('L', 'L', 'L', 'L', 'R')):
        q = np.zeros(2); count = np.zeros(2, dtype=int)
        for first in choices:
            a = ('L', 'R').index(first)
            count[a] += 1
            q[a] += (discounted_return(episode(first)) - q[a]) / count[a]
        assert np.argmax(q) == 1  # Freeze the learned greedy policy, not the last action.
        final_q.append(q.tolist())
    np.testing.assert_allclose(final_q, [[0., 3.6], [1., 3.6]])
    return snapshots, fast, slow, final_q


def save(fig, name):
    for ext in ('pdf', 'png'):
        fig.savefig(OUT / f'{name}.{ext}', dpi=170, bbox_inches='tight')
    plt.close(fig)


def node(ax, xy, label):
    ax.add_patch(Circle(xy, .14, color='white', ec=MUTED, zorder=3))
    ax.text(*xy, label, ha='center', va='center', fontsize=14, zorder=4)


def path(ax, start, end, color, label, ypos, active=True):
    ax.annotate('', xy=end, xytext=start,
                arrowprops={'arrowstyle':'->', 'color':color, 'lw':2.4 if active else 1.2,
                            'linestyle':'-' if active else '--', 'shrinkA':11,'shrinkB':11})
    ax.text((start[0]+end[0])/2, ypos, label, ha='center', color=color, fontsize=15)


if __name__ == '__main__':
    OUT.mkdir(exist_ok=True)
    snapshots, fast, slow, final_q = check()
    plt.rcParams.update({'font.size':17, 'font.family':'Arial Unicode MS', 'axes.spines.top':False,
                         'axes.spines.right':False, 'figure.facecolor':'white'})
    fig, axs = plt.subplots(2, 2, figsize=(11.5,4.7),
                            gridspec_kw={'height_ratios':[1.4,1]}, layout='constrained')
    for i in range(2):
        ax=axs[0,i]; ax.set(xlim=(-.25,3.4),ylim=(-.9,1.1));ax.axis('off')
        points=[(0,0),(1.5,.6),(1.5,-.5),(3,-.5)]
        for xy, label in zip(points,['s','end','u','end']):node(ax,xy,label)
        path(ax,points[0],points[1],TEAL if i==0 else '#b9c4c7','L: +1',.65,i==0)
        path(ax,points[0],points[2],TEAL if i==1 else '#b9c4c7','R: 0' if i else 'R: ?',-.55,i==1)
        path(ax,points[2],points[3],TEAL if i==1 else '#b9c4c7','+4' if i else '?',-.32,i==1)
        ax.set_title(['第一次选择 L 后','探索一次 R 后'][i],loc='left',fontsize=21)
        ax=axs[1,i];ax.bar(['L','R'], snapshots[i], color=[RED,TEAL],width=.5)
        ax.set(ylim=(0,4.5),ylabel='回报估计 Q',yticks=[0,1,3.6])
        for j,q in enumerate(snapshots[i]):ax.text(j,q+.13,f'{q:g}',ha='center')
        if i==0:ax.text(1,.9,'初始估计',ha='center',fontsize=17,color=MUTED)
    save(fig,'experience-policy')

    fig, axs = plt.subplots(2, 2, figsize=(11.7,4.6),
                            gridspec_kw={'width_ratios':[1.7,1]},layout='constrained')
    for i,(seq,label) in enumerate([(fast,'R, R, R'),(slow,'L, L, L, L, R')]):
        ax=axs[i,0];x=np.arange(1,7)
        ax.bar(x,seq,color=TEAL if i==0 else RED,width=.56)
        for j,r in enumerate(seq):ax.text(j+1,r+.15,f'{r:g}',ha='center',fontsize=17)
        ax.set(ylim=(0,5.5),xticks=x,ylabel='奖励',title='各回合首动作：'+label)
        ax.set_xlabel('环境交互步')
        ax=axs[i,1];ax.plot(np.arange(7),np.r_[0,np.cumsum(seq)],marker='o',c=TEAL if i==0 else RED)
        ax.set(xlim=(0,6.5),ylim=(0,13),xticks=[0,2,4,6],yticks=[0,4,8,12],
               xlabel='环境交互步',ylabel='累积奖励')
    save(fig,'learner-rewards')
    result={'task':'deterministic two-step task; gamma=0.9',
            'chosen_episode_actions':['L','R'],
            'q_after_episodes':[s.tolist() for s in snapshots],
            'reward_sequences':[fast,slow], 'six_step_totals':[sum(fast),sum(slow)],
            'final_q_for_sequences':final_q, 'frozen_greedy_actions':['R','R'],
            'same_final_policy_return':3.6,
            'scope':'Specified action sequences executed in the environment; exact teaching illustration, not algorithm ranking.'}
    (OUT/'results.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
