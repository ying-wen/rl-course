"""Ice fishing, in environment steps. Run with Python 3, no dependencies.

At home, left yields one fish and stays home. Right yields four fish on
arrival and returns home at that instant. Count every movement as a step.
State 0 is home; a positive state counts the steps still to go.
"""
import argparse
from fractions import Fraction
from math import comb
from random import Random
from statistics import mean


def step(remaining, right, slow, rng):
    if remaining:
        return remaining - 1, 4 if remaining == 1 else 0
    if not right:
        return 0, 1
    duration = 8 if slow and rng.randrange(2) else 2
    return duration - 1, 0


def discounted(gamma):
    # One trip: stop valuing its continuation upon return. Repeated trips:
    # V_L = 1 + gamma * V_L and V_R = 4*gamma + gamma**2 * V_R.
    return (1, 4 * gamma), (1 / (1 - gamma), 4 * gamma / (1 - gamma**2))


def differential_td(steps, seed):
    """Fixed equiprobable choices at home, deterministic right duration two.

    Each physical transition updates one prediction and the rate estimate
    using the same pre-update TD error (Wan, Naik & Sutton, ICML 2021).
    Only the reported difference of the two state values is identifiable.
    """
    rng = Random(seed)
    state, rate, values = 0, 0.0, [0.0, 0.0]
    for t in range(steps):
        action_right = state == 0 and rng.randrange(2) == 1
        next_state, reward = step(state, action_right, False, rng)
        alpha = 0.5 / (1 + t / 500) ** 0.65
        delta = reward - rate + values[next_state] - values[state]
        values[state] += alpha * delta
        rate += 0.2 * alpha * delta
        state = next_state
    return rate, values[1] - values[0]


def completed_right_trips(n, rng):
    durations = []
    for _ in range(n):
        state, steps, total = 0, 0, 0
        while True:
            state, reward = step(state, True, True, rng)
            steps += 1
            total += reward
            if state == 0:
                break
        assert total == 4
        durations.append(steps)
    return durations


def fit_and_plan(durations):
    # Predict a trip's total reward and duration. Every option ends at home,
    # so constant-policy renewal rates suffice to compare the two controls.
    return Fraction(4 * len(durations), sum(durations)), mean(
        Fraction(4, k) for k in durations
    )


def probability_of_wrong_choice(trips, per_trip=False):
    # Right is worse (4 / E[K] = 4/5). Choose left on an empirical tie.
    # k of n trips lasted 8. Count samples that give right a score > 1.
    threshold = 2 * trips if per_trip else trips
    return Fraction(sum(comb(trips, k) for k in range(trips + 1)
                        if 3 * k < threshold), 2**trips)


def run(seed, samples, gamma, horizon):
    one, repeated = discounted(gamma)
    print("确定性路线：左路一步得 1，右路两步得 4。取鱼后立即回到起点。")
    print(f"gamma = {gamma}     left    right")
    print(f"first {horizon} steps (no discount):", horizon, 4 * (horizon // 2))
    print("one trip         ", *one)
    print("repeated trips   ", *repeated)
    print("fish per step       1        2")
    print("\n固定策略预测：在起点等概率选路。右路仍需两步。")
    rate, bias = differential_td(samples, seed)
    print(f"TD ({samples} steps, seed={seed}): rate={rate:.4f} (exact 5/3), "
          f"h(away)-h(home)={bias:.4f} (exact 7/3)")
    print("\n规划：右路现在等概率耗费 2 或 8 步，终点奖励仍为 4。")
    print("按环境步计，左路的率为 1，右路为 0.8。估计相等时选择左路。")
    observed = [2, 8, 2, 8]
    print("durations", observed, "pooled rate, mean of trip rates:", *fit_and_plan(observed))
    assert fit_and_plan(observed) == (Fraction(4, 5), Fraction(5, 4))
    rng = Random(seed)
    trials = 2000
    for n in [4, 16, 32]:
        wrong = [0, 0]
        for _ in range(trials):
            scores = fit_and_plan(completed_right_trips(n, rng))
            for j, score in enumerate(scores):
                wrong[j] += score > 1
        exact = [probability_of_wrong_choice(n, per_trip=j == 1) for j in range(2)]
        print(f"{n:2} trips, P(select right) pooled / per-trip, "
              f"sample: {wrong[0]/trials:.3f} / {wrong[1]/trials:.3f}, "
              f"exact: {float(exact[0]):.3f} / {float(exact[1]):.3f}")
    assert [probability_of_wrong_choice(4, per_trip=w) for w in [False, True]] == [
        Fraction(5, 16), Fraction(11, 16)]


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=7)
    parser.add_argument("--steps", type=int, default=100000)
    parser.add_argument("--gamma", type=Fraction, default=Fraction(3, 10),
                        help="Discount in [0, 1); decimals and fractions are accepted.")
    parser.add_argument("--horizon", type=int, default=6,
                        help="Number of physical steps counted in the finite window.")
    args = parser.parse_args()
    if args.steps < 1:
        parser.error("--steps must be positive")
    if not 0 <= args.gamma < 1 or args.horizon < 1:
        parser.error("use 0 <= gamma < 1 and a positive horizon")
    run(args.seed, args.steps, args.gamma, args.horizon)
