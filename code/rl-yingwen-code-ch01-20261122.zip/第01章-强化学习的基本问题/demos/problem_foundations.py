"""Chapter 1: information, objectives, and reward shaping.

Run from any directory. Training uses only the observed cue/state and reward.
The supplied one-bit memory is an experimental condition, not a learned memory
architecture. Exact policy evaluation enumerates BOTH possible cues after each
100 training episodes, and does not enter the training update.
"""
from pathlib import Path
import csv
import json
import random
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, Circle, FancyArrowPatch

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'demos' / '05-results'
ASSETS = ROOT / 'assets' / 'v5'
OUT.mkdir(exist_ok=True, parents=True)
ASSETS.mkdir(exist_ok=True, parents=True)
plt.rcParams.update({'font.size': 11, 'axes.spines.top': False,
                     'axes.spines.right': False, 'savefig.facecolor': 'white'})
TEAL, RED, INK = '#087e8b', '#c65335', '#182e38'


def cue_learning(memory, seed, episodes=2000, alpha=.1, epsilon=.1):
    """Terminal action-value update: Q <- Q + alpha*(R-Q).

    Identical cue/action random streams are supplied to both representations.
    A reactive learner indexes one row. The remembered-cue learner indexes two.
    Greedy evaluation uses uniform tie-breaking and has no exploration noise.
    """
    rng = random.Random(seed)
    q = np.zeros((2 if memory else 1, 2))
    results = []
    for ep in range(episodes + 1):
        if ep % 100 == 0:
            value = 0.0
            for cue in (0, 1):
                row = q[cue if memory else 0]
                best = np.flatnonzero(row == row.max())
                value += .5 * float(cue in best) / len(best)
            results.append((ep, value))
        if ep == episodes:
            break
        cue = rng.randrange(2)
        coin, tie = rng.random(), rng.random()
        state = cue if memory else 0
        best = np.flatnonzero(q[state] == q[state].max())
        action = int(tie * 2) if coin < epsilon else int(best[min(int(tie*len(best)), len(best)-1)])
        reward = float(action == cue)
        # The episode ends here: there is no bootstrapped future value.
        q[state, action] += alpha * (reward - q[state, action])
    return results


def main():
    records = []
    fig, ax = plt.subplots(figsize=(7.5, 3.8))
    for memory, color, name in [(False, RED, 'Current observation only'),
                                (True, TEAL, 'One-bit cue memory')]:
        runs = np.array([cue_learning(memory, seed) for seed in range(20)])
        for seed, run in enumerate(runs):
            for ep, value in run:
                records.append((name, seed, int(ep), value))
        x = runs[0, :, 0]; y = runs[:, :, 1]
        ax.plot(x, y.mean(0), label=name, color=color, lw=2)
        ax.fill_between(x, y.min(0), y.max(0), color=color, alpha=.12)
    ax.set(xlabel='Training episodes', ylabel='Exact greedy success probability',
           ylim=(.42, 1.07), title='The same update; different information')
    ax.legend(loc='lower right'); fig.tight_layout()
    fig.savefig(ASSETS/'cue-learning.png', dpi=180); plt.close(fig)
    with (OUT/'cue-learning.csv').open('w') as f:
        w=csv.writer(f); w.writerow(['representation','seed','episode','exact_success']);w.writerows(records)

    fig, ax = plt.subplots(figsize=(9, 3.4)); ax.set(xlim=(0, 10), ylim=(0, 3.6)); ax.axis('off')
    for y, color, name, action in [(2.6,RED,'Red cue','Left'),(.9,TEAL,'Blue cue','Right')]:
        ax.add_patch(Circle((.7,y),.3,color=color))
        ax.add_patch(Rectangle((2.6,y-.38),1.1,.76,facecolor='#e6e9eb',edgecolor=INK))
        ax.text(3.15,y,'?',ha='center',va='center',fontsize=22)
        ax.annotate('',(2.5,y),(1.1,y),arrowprops=dict(arrowstyle='->',color=INK))
        ax.text(.7,y-.55,name,ha='center')
        ax.text(4,y,'Same observation',va='center')
        ax.annotate('',(7,y),(6.1,y),arrowprops=dict(arrowstyle='->',color=color))
        ax.text(7.15,y,f'{action}  →  reward 1',va='center',color=color,fontsize=14)
    ax.text(3.15,3.35,'Cue disappears',ha='center')
    fig.tight_layout();fig.savefig(ASSETS/'cue-memory.png',dpi=180);plt.close(fig)

    gamma=np.linspace(0,.95,191)
    va=1/(1-gamma);vb=3*gamma/(1-gamma**2)
    fig,axes=plt.subplots(1,2,figsize=(9,3.5),gridspec_kw={'width_ratios':[2,1]})
    axes[0].plot(gamma,(1-gamma)*va,label='A: 1, 1, 1, 1, ...',color=RED)
    axes[0].plot(gamma,(1-gamma)*vb,label='B: 0, 3, 0, 3, ...',color=TEAL)
    axes[0].axvline(.5,color='gray',ls=':');axes[0].legend(loc='lower right')
    axes[0].set(xlabel='Discount gamma',ylabel='(1 − gamma) × discounted return',ylim=(0,1.65))
    axes[1].bar(['A','B'],[1,1.5],color=[RED,TEAL]);axes[1].set(ylabel='Long-run reward per step',ylim=(0,1.65))
    fig.tight_layout();fig.savefig(ASSETS/'reward-objectives.png',dpi=180);plt.close(fig)

    # Check telescoping for a finite path; terminal potential is zero.
    rewards=np.array([0.,0.,1.]); phi=np.array([.8,.5,.2,0.]);g=.9
    shape=g*phi[1:]-phi[:-1]
    base=sum(g**t*r for t,r in enumerate(rewards))
    changed=sum(g**t*r for t,r in enumerate(rewards+shape))
    assert abs(changed-(base-phi[0]))<1e-12
    assert all(v==.5 for ep,v in cue_learning(False,0))
    assert cue_learning(True,0)[-1][1]==1.
    assert abs(1/(1-.5)-3*.5/(1-.5**2))<1e-12

    fig,ax=plt.subplots(figsize=(9,4.2));ax.set(xlim=(0,10),ylim=(0,5));ax.axis('off')
    rng=np.random.default_rng(9)
    xy=rng.uniform([.3,.4],[3.7,4.5],(75,2));ax.scatter(xy[:,0],xy[:,1],s=rng.uniform(8,65,75),c=TEAL,alpha=.3)
    ax.text(2,4.8,'World',ha='center',fontsize=15)
    ax.add_patch(Rectangle((5.5,1.1),3.7,2.7,facecolor='#eaf4f3',edgecolor=INK,lw=2))
    ax.text(7.35,3.4,'Finite learner',ha='center',fontsize=15)
    for x,y,label in [(6.5,2.65,'State'),(8.1,2.65,'Values'),(6.5,1.65,'Policy'),(8.1,1.65,'Model')]:
        ax.text(x,y,label,ha='center',va='center',bbox=dict(boxstyle='round',fc='white',ec=TEAL))
    ax.annotate('',(5.5,3),(3.8,3),arrowprops=dict(arrowstyle='->',lw=2,color=TEAL));ax.text(4.55,3.3,'Experience',ha='center')
    ax.annotate('',(3.8,1.6),(5.5,1.6),arrowprops=dict(arrowstyle='->',lw=2,color=RED));ax.text(4.55,1.1,'Action',ha='center')
    ax.text(7.35,.55,'Limited memory • compute • response time',ha='center',fontsize=11)
    fig.tight_layout();fig.savefig(ASSETS/'finite-learner.png',dpi=180);plt.close(fig)
    summary={'seeds':20,'episodes':2000,'alpha':.1,'epsilon':.1,
             'reactive_exact_upper_bound':.5,'remembered_cue_optimum':1.,
             'discount_preference_threshold':.5,'shaping_original_return':base,
             'shaping_changed_return':changed,'shaping_constant':-phi[0]}
    (OUT/'problem-foundations.json').write_text(json.dumps(summary,indent=2))
    print(json.dumps(summary,indent=2))


if __name__=='__main__':main()
