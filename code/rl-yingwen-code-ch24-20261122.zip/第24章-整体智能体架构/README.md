# 第 24 章　整体智能体架构：程序

本目录可以单独运行：在本目录下执行下面的命令即可，结果写回本目录的 `assets/`。目录由 `rl-course/tools/export_chapter_code.py` 从课程目录生成，改程序请改课程目录里的原件，再重新导出。

## 准备

```sh
python3 -m pip install -r requirements.txt
```

需要的第三方包：matplotlib、mpmath、numpy。复现附录要求 Python 3.10 或更新版本；核验时用的版本见下表。

## 运行（与复现附录相同）

```sh
python3 demos/crl_joint_v12.py --output-dir runs/crl-joint   # 8 种子 × 3 条件 × 120000 步；不加 --output-dir 时写 assets/crl-joint-v12
python3 demos/v18_systems.py                                  # 读 assets/crl-joint-v12，写 assets/v18-systems
python3 demos/v19_continual.py                                # 读 assets/crl-joint-v12，写 assets/v19-continual
python3 demos/station_occupancy.py                            # 读不规划组种子 0 的轨迹，只打印
python3 demos/crl_ladder_learners.py --exp ch24 --seeds 20 --seed0 100 --steps 2000000 --tag formal   # 四区仓库阶梯，写 assets/crl-ladder-world/runs/formal-ch24.json
python3 demos/crl_ladder_figures.py ch24           # 写 assets/crl-ladder-world/fig/ladder-ch24.png
```

## 本目录的程序

| 程序 | 说明 | 核验 |
|---|---|---|
| `demos/crl_joint_v12.py` | One continuing navigation task, learned skills, GVFs and rate-aware planning. | 通过（62 秒） |
| `demos/v18_systems.py` | Small CPU checks and teaching figures for the v18 systems/continual review. | 通过（1 秒） |
| `demos/v19_continual.py` | Bounded calculations for the v19 continual-learning bridge. | 通过（2 秒） |
| `demos/station_occupancy.py` | Reproduce the fixed-policy comparison on the three-station course slide. | 通过（0 秒） |
| `demos/crl_question_selection.py` | Select an event GVF for a route model from a single continuing stream. | 通过（1 秒） |
| `demos/crl_skill_discovery_trial.py` | Discover and test one reusable delivery skill on a single continuing trajectory. | 通过（9 秒） |
| `demos/crl_meta_reader_trial.py` | Closed-loop duration meta-learning on the chapter 15 continuing three-station task. | 通过（7 秒） |
| `demos/crl_ladder_learners.py` | 四区仓库的学习器阶梯（例子方案第三步）。 | 超时：300 秒内未跑完（启动正常） |
| `demos/crl_ladder_diagnostics.py` | 四区仓库阶梯的诊断与改法（11-20）。 | 通过（4 秒） |
| `demos/crl_ladder_figures.py` | 阶梯世界（四区仓库）阅读稿用图：地图与各章“占天花板”条形。 | 通过（1 秒） |
| `demos/crl_ladder_world.py` | 四区仓库：第三部分的能力阶梯世界（环境与精确参照）。 | 通过（28 秒） |
| `demos/crl_ladder_world_checks.py` | 四区仓库的独立检查（照 v12 的做法：手算、枚举、独立实现互查）。 | 通过（17 秒） |
| `demos/crl_ladder_power.py` | 四区仓库学习器阶梯：试点估 σ_Δ 定种子数，正式跑后出第 24 章的账本。 | 通过（1 秒） |
| `demos/crl_ladder_ceiling.py` | 四区仓库学习器阶梯：每个试验条件的“天花板”，供账本算“离最优还差多少”。 | 超时：300 秒内未跑完（启动正常） |

表中后 4 个程序复现附录本章一节没有列出，来自课件、阅读稿、CODE-MAP 或文件名前缀（第三部分另含学习器阶梯）。

## 第三部分的学习器阶梯（例子方案第三步）

四区仓库世界与 L0–L10 阶梯学习器。每章一个实验，三档：没有、设计者给定、从经验学到。比较都是配对的：同一种子下两档用同一份世界随机数。

```sh
python3 demos/crl_ladder_world.py --fast                     # 各区参考线，写 reference.json（全量去掉 --fast）
python3 demos/crl_ladder_world_checks.py                     # 世界本身的核对
python3 demos/crl_ladder_ceiling.py                          # 各条件的天花板（ε-软最好率），写 ceiling.json
python3 demos/crl_ladder_learners.py --exp ch24 --seeds 2 --steps 200000 --procs 2 --tag smoke   # 冒烟：写 assets/crl-ladder-world/runs/smoke-ch24.json
python3 demos/crl_ladder_learners.py --exp ch24 --seeds 20 --seed0 100 --steps 2000000 --tag formal   # 正式设置（种子数与 runs/ 里的正式记录相同）
python3 demos/crl_ladder_power.py ledger --runs formal-ch24     # 配对差与 95% 区间，写 ledger-formal-ch24.json
python3 demos/crl_ladder_figures.py ch24                       # 阅读稿用的地图与条形图（读账本）
# 改进与诊断（README 第九节）：同一套世界随机数，跑完用 --compare 出配对差
python3 demos/crl_ladder_diagnostics.py --arms ch24/combo/all-win8 --seeds 2 --steps 200000 --procs 2 --tag smoke   # 冒烟：写 runs/diag-smoke-*.json
python3 demos/crl_ladder_diagnostics.py --arms ch24/combo/all-win8 ch24/combo/-idbd-win8 ch24/combo/only-context-win8 ch24/combo/sum-win8 ch24/combo/-idbd-opt ch24/combo/sum-opt ch24/combo/only-cue-opt --seeds 20 --procs 4
python3 demos/crl_ladder_diagnostics.py --arms ch24/combo/all-cap12 ch24/combo/-idbd-cap12 ch24/combo/only-context-opt ch24/combo/bat+cue-opt ch24/combo/ctx+bat-opt --seeds 20 --procs 4
python3 demos/crl_ladder_diagnostics.py --compare ch24/combo/all-win8 ch24/combo/all
python3 demos/crl_ladder_diagnostics.py --compare ch24/combo/all-cap12 ch24/combo/all
python3 demos/crl_ladder_diagnostics.py --compare ch24/combo/-idbd-opt ch24/combo/-idbd
python3 demos/crl_ladder_diagnostics.py --compare ch24/combo/only-context-opt ch24/combo/none
python3 demos/crl_ladder_diagnostics.py --compare ch24/combo/sum-opt ch24/combo/sum
python3 demos/crl_ladder_power.py ledger --runs formal-ch15 formal-ch16 formal-ch17 formal-ch18 formal-ch19 formal-ch20 formal-ch21 formal-ch22 formal-ch23 formal-ch24 formal-ch25 formal5m-ch20   # 读 assets/crl-ladder-world/runs/ 里的全部正式记录，出总账（含第 24 章的交互项）
```

参考记录在 `assets/crl-ladder-world/runs/`（随本目录复制）。正式设置一章要跑数十分钟到数小时；冒烟一行只确认程序能走通。正式结果与读法见 `assets/crl-ladder-world/README.md` 第八节，改进与诊断见第九节。

## 复现附录本章一节

本章来自本课程序的结果有：24.4 节三站任务第 40,003 步的逐行核算，技能与预测的快照图，冻结技能后的期望时长，A 站改选一行的稳态收益，24.5 节八对 lifetime 的配对比较，以及 24.5 节四区仓库上四种变化同时打开时的阶梯实验与改法。24.6 节“局部学习与全程收益的实验对照”一表引用第 23 章三组配对实验的结果。

24.2 节两步算例、24.3 节交互项的十步算例（$J_{11}=8$、$I_T=8$）、24.4 节步长取 $.20$ 时的 $1.3088$，以及 24.5 节所需对数（$\sigma_\Delta\approx2.12$，约 $12$、$35$、$141$ 对）由正文推导直接算出。

| 位置 | 结果 | 设置 | 程序 | 数据与输出 |
|---|---|---|---|---|
| 24.4 节“实际续行与未选行动”“每个原始步：行为、奖励预测与时间预测”“到站时：高层控制与模型规划”“一次技能完成事件的参数更新”（课件 ch24-bridge-three-station、ch15-arch-worked-trajectory、ch15-arch-sampled-branch、ch15-r9-arch-arrival-updates） | 规划组种子 0 第 39,996–40,003 步的一次 A 到 C 执行，$(G,\tau)=(3,7)$，首步原地；到站时低层值 $-1.1743\to-1.1464$，时长预测 $1.3860\to1.3551$，$\delta=.164707$，$\bar R$ $.286371\to.286700$，模型 $R$ $3.005568\to3.005123$、$T$ $7.562349\to7.517361$；第 40,010 步返回 A、得主奖励 $1$；第 100、12,000、120,000 步的去 C 技能图与两项 GVF 图 | 本课的模拟：Y 形网格上三个外部给定的站点，持续运行不重置；$10\%$ 的动作被随机动作替换；低层探索率 $.06$，高层 $.12$；技能步长 $.16$，GVF、模型与站点价值步长 $.08$，率估计步长 $.002$；规划组每个原始步做五次模型备份；表中各数取自规划组种子 0 这一段 lifetime | `demos/crl_joint_v12.py` | `assets/crl-joint-v12/one-real-transition.json`；`assets/crl-joint-v12/options-planning-seed0.csv`；`assets/crl-joint-v12/raw-planning-seed0.npz`；图 `assets/crl-joint-v12/skill-policy-maps.png`、`assets/crl-joint-v12/gvf-maps.png` |
| 24.4 节“每个原始步：行为、奖励预测与时间预测”的事件图 | 同一次执行的七个原始步与 $G$、$\tau$ 的逐步累积；另对上一行的技能、GVF、$\delta$ 与模型更新逐项复算 | 不重新训练：读取上一行保存的轨迹与到站记录，逐项复算并作图 | `demos/v18_systems.py` | 读 `assets/crl-joint-v12/raw-planning-seed0.npz`、`assets/crl-joint-v12/one-real-transition.json`；写 `assets/v18-systems/checks.json`；图 `assets/v18-systems/joint-event-timeline.png` |
| 24.4 节“表示、技能与更新规则的联合学习” | 冻结规划组第 100 步与第 12,000 步的去 C 技能，从 A 到 C 的期望时长约 $6{,}273$ 步与 $7.09$ 步；各位置选“东”的概率 | 不重新训练：读取规划组种子 0 的两个参数快照，保留探索与动作噪声，解七个位置的吸收链方程，另以生存概率求和验算 | `demos/v19_continual.py` | 读 `assets/crl-joint-v12/raw-planning-seed0.npz`；写 `assets/v19-continual/skill-changes-prediction-target.csv`、`assets/v19-continual/checks.json`（`skill_duration`）；图 `assets/v19-continual/skill-changes-target.png` |
| 24.4 节“A 站改选一行：频率要按新策略取”“全程平均主奖励”（课件 ch24-occupancy-advantage、ch24-tw） | A 站平均优势 $.045047$ 乘 A 站每步决策频率 $.060446$，得 $.002723$（每千步 $2.72$）；36 个可达状态上稳态每步收益 $.0764982\to.0792211$，差 $.0027229$；路口且上次服务 B 的占比 $.01631\to.07442$ | 无训练：取不规划组种子 0 第 60,000 步（C 降奖后）的参数快照为固定策略 $\mu$，只改 A 站一行得 $\mu'$，对两者解稳态分布 | `demos/station_occupancy.py` | 读 `assets/crl-joint-v12/raw-no_planning-seed0.npz`；结果只打印到终端，不写文件 |
| 24.5 节“三站实验：八对 lifetime 的配对差”（课件 ch24-three-station-lifetimes、ch24-open-difficulty） | 全程每步收益：不规划 $.208758$、规划 $.207046$、冻结 $.167127$；变化后最后 18,000 步 $.149318$、$.149327$、$.065790$；八对配对差（每千步）$.604,\ -.406,\ -5.093,\ -2.354,\ .259,\ -3.928,\ -2.695,\ -.088$，均值 $-1.713$，标准误 $.748$，$t_7$ 区间 $[-3.481,+.056]$；规划组共 $984{,}860$ 次模型备份（种子 0 为 $119{,}410$ 次，完成 $23{,}882$ 项技能）；学习曲线与到站序列两图 | 本课的模拟：设置同第一行，三种条件（不规划、规划、冻结）；第 60,000 步后 C 站奖励由 $3$ 降为 $.1$，两组都不重置；每段 lifetime 120,000 个原始步，种子 0–7，配对 lifetime 独立重复 8 次。配对差、均值、标准误与 $t$ 区间由 `manifest.json` 中各种子的 `lifetime_rate` 逐对相减算出，程序未单独写出 | `demos/crl_joint_v12.py` | `assets/crl-joint-v12/manifest.json`（`summary`）；`assets/crl-joint-v12/resources.csv`；`assets/crl-joint-v12/learning-curves.csv`；`assets/crl-joint-v12/README.md`；图 `assets/crl-joint-v12/learning-curves.png`、`assets/crl-joint-v12/behavior-routes.png` |
| 24.6 节“局部学习与全程收益的实验对照” | 三行分别引用：通道选择每步 $+.0746$（标准误 $.0027$）；排序练习比均匀多 $.08479$、比只用原始动作少 $.02133$；规划读逐步时长 GVF 且支路变慢时每千步 $-.662\,[-1.274,-.123]$ | 设置见第 23 章表中 23.7 节三行；96、64、64 对配对运行 | `demos/crl_question_selection.py`；`demos/crl_skill_discovery_trial.py`；`demos/crl_meta_reader_trial.py` | `assets/crl-question-selection/summary.json`；`assets/crl-skill-discovery-trial/summary.json`；`assets/crl-meta-reader-trial/results.json` |
| 24.5 节（课件 `ch24-ladder`） | 四个部件单加只有电量有益，lifetime 到天花板的 54%（最后一成 64%）；全加切换 8600 多次；改法把切换降到 2600 多次，lifetime 高 .0111（最后一成高 .0163） | 本课的模拟：四区仓库，四个刻度同时打开，200 万步，20 个种子，差分 Q；真实规律切换约 2000 次 | `demos/crl_ladder_learners.py` 实验 `ch24`；`demos/crl_ladder_diagnostics.py` | `assets/crl-ladder-world/runs/formal-ch24.json`、`assets/crl-ladder-world/fig/ladder-ch24.png`；runs/ 下的 diag-ch24_*.json |

运行：
```sh
python3 demos/crl_joint_v12.py --output-dir runs/crl-joint   # 8 种子 × 3 条件 × 120000 步；不加 --output-dir 时写 assets/crl-joint-v12
python3 demos/v18_systems.py                                  # 读 assets/crl-joint-v12，写 assets/v18-systems
python3 demos/v19_continual.py                                # 读 assets/crl-joint-v12，写 assets/v19-continual
python3 demos/station_occupancy.py                            # 读不规划组种子 0 的轨迹，只打印
python3 demos/crl_ladder_learners.py --exp ch24 --seeds 20 --seed0 100 --steps 2000000 --tag formal   # 四区仓库阶梯，写 assets/crl-ladder-world/runs/formal-ch24.json
python3 demos/crl_ladder_figures.py ch24           # 写 assets/crl-ladder-world/fig/ladder-ch24.png
```

## 参考数据

`assets/`（以及 `demos/NN-results/`）下复制了 164 个数据文件（json、csv 等），即课程目前使用的结果；图片没有复制，运行程序会重新画出。重跑会覆盖这些文件，可以先另存一份再对照。
