"""Reproduce the fixed-policy comparison on the three-station course slide.

Run from the rl-course directory: python3 demos/station_occupancy.py
Requires NumPy and the bundled no-planning seed-0 trajectory. No training.
"""
from collections import deque

import numpy as np

import crl_joint_v12 as world


A, B, C = range(3)
JUNCTION = world.INDEX[(0, 0)]
PHASE = 1  # After the C reward drops.


def transitions(state, skills, policy):
    """Yield (next state, probability, reward) for one real primitive step."""
    pos, last, goal = state
    intended = world.primitive_prob(skills[goal, pos])
    executed = (1 - world.SLIP) * intended + world.SLIP / len(world.MOVES)
    for action, prob in enumerate(executed):
        dest = int(world.NEXT[pos, action])
        next_last = world.AT_STATION.get(dest, last)
        reward = world.REWARDS[PHASE, next_last] if next_last != last else 0.
        if dest == world.STATIONS[goal]:
            for next_goal in np.flatnonzero(policy[goal]):
                yield (dest, next_last, next_goal), prob * policy[goal, next_goal], reward
        else:
            yield (dest, next_last, goal), prob, reward


def primitive_evaluation(skills, policy):
    """Solve the invariant distribution on reachable (position, last station, goal)."""
    start = (world.STATIONS[A], A, B)
    pending = deque([start])
    index = {start: 0}
    edges = []
    while pending:
        state = pending.popleft()
        row = list(transitions(state, skills, policy))
        edges.append(row)
        for successor, _, _ in row:
            if successor not in index:
                index[successor] = len(index)
                pending.append(successor)

    n = len(index)
    kernel = np.zeros((n, n))
    expected_reward = np.zeros(n)
    for i, row in enumerate(edges):
        for successor, prob, reward in row:
            kernel[i, index[successor]] += prob
            expected_reward[i] += prob * reward
    np.testing.assert_allclose(kernel.sum(axis=1), 1., atol=1e-12, rtol=0.)

    lhs = kernel.T - np.eye(n)
    lhs[-1] = 1.
    rhs = np.zeros(n)
    rhs[-1] = 1.
    mass = np.linalg.solve(lhs, rhs)
    np.testing.assert_allclose(mass @ kernel, mass, atol=1e-12, rtol=0.)
    assert np.min(mass) >= -1e-12
    history_mass = sum(mass[i] for (pos, last, _), i in index.items()
                       if pos == JUNCTION and last == B)
    return history_mass, mass @ expected_reward, n


def check_local_gain(old, changed, rewards, durations, old_rate, changed_station_mass):
    """Multiply the old-policy local advantage by the new frequency of A decisions."""
    # (I - policy) h = average skill reward minus the time charge. Set h(A)=0.
    excess = rewards - old_rate * durations
    lhs = np.eye(len(old)) - old
    rhs = (old * excess).sum(axis=1)
    lhs[A] = 0.
    lhs[A, A] = 1.
    rhs[A] = 0.
    h = np.linalg.solve(lhs, rhs)
    advantage = excess + h[None, :] - h[:, None]
    np.testing.assert_allclose((old * advantage).sum(axis=1), 0., atol=1e-12)
    gain_at_a = changed[A] @ advantage[A]
    mean_duration = changed_station_mass @ (changed * durations).sum(axis=1)
    decisions_per_step = changed_station_mass[A] / mean_duration
    return gain_at_a, decisions_per_step


def main():
    with np.load(world.OUT / 'raw-no_planning-seed0.npz') as snapshot:
        k = snapshot['snapshots_t'].tolist().index(60000)
        skills = snapshot['skill'][k]
        old = world.high_policy(snapshot['Q'][k])
    changed = old.copy()
    changed[A, [B, C]] = old[A, [C, B]]

    # An independent solution uses the embedded station chain and option models.
    model_reward, model_duration, _ = world.reference_models(skills, PHASE)
    results = []
    print('policy          P(B | A)    P(position=J, last=B)   reward/step (primitive / option)')
    for name, policy in [('original', old), ('A row swapped', changed)]:
        joint_mass, rate, n = primitive_evaluation(skills, policy)
        option_rate, station_mass = world.embedded_rate(model_reward, model_duration, policy)
        np.testing.assert_allclose(rate, option_rate, atol=1e-12, rtol=0.)
        results.append((rate, station_mass))
        print(f'{name:14} {policy[A, B]:9.2%} {joint_mass:23.5%}    {rate:.8f} / {option_rate:.8f}  ({n} states)')

    station_ids = range(len(world.STATIONS))
    rewards = np.array([[model_reward[j, world.STATIONS[i], i] for j in station_ids] for i in station_ids])
    durations = np.array([[model_duration[j, world.STATIONS[i], i] for j in station_ids] for i in station_ids])
    old_rate = results[0][0]
    new_rate, new_station_mass = results[1]
    local, frequency = check_local_gain(old, changed, rewards, durations, old_rate, new_station_mass)
    np.testing.assert_allclose(local * frequency, new_rate - old_rate, atol=1e-12, rtol=0.)
    print(f'gain at A × A decisions/step = {local:.8f} × {frequency:.8f} = {local * frequency:.8f}')


if __name__ == '__main__':
    main()
