"""一项能力的收支：最小世界的四种做法与上限（第 26 章 26.6 节）。

一条二值规律保持 n 次使用；选对比选错多得 D；结果在段末一并结算。
一次探测的准确率为 q、代价为 c；整理成知识一次付 C；只留记录则每次使用前付 rho。
运行：python3 capability-ledger.py
"""
import random
import statistics as st

SEED = 20261117
LIVES = 20000


def life(n, q, D, c, C, rho, rng, p0=0.5):
    """返回一条生涯中五种做法的净收益。p0 是固定方案事先猜对规律的概率。"""
    z = rng.random() < 0.5
    out = {}
    guess = z if rng.random() < p0 else (not z)
    out["固定"] = n * (D if guess == z else 0)
    total = 0.0
    for _ in range(n):
        read = z if rng.random() < q else (not z)
        total += (D if read == z else 0) - c
    out["反应"] = total
    hit = rng.random() < q
    out["重推"] = n * (D if hit else 0) - c - n * rho
    out["知识"] = n * (D if hit else 0) - c - C
    out["上限"] = n * D
    return out


def theory(n, q, D, c, C, rho, p0=0.5):
    return {
        "固定": n * p0 * D,
        "反应": n * (q * D - c),
        "重推": n * q * D - c - n * rho,
        "知识": n * q * D - c - C,
        "上限": n * D,
    }


def run(label, n=8, q=0.8, D=1.0, c=0.3, C=0.5, rho=0.1, p0=0.5):
    rng = random.Random(SEED)
    rows = [life(n, q, D, c, C, rho, rng, p0) for _ in range(LIVES)]
    th = theory(n, q, D, c, C, rho, p0)
    print(f"\n{label}: n={n} q={q} D={D} c={c} C={C} rho={rho} p0={p0}")
    for k in th:
        xs = [r[k] for r in rows]
        se = st.pstdev(xs) / LIVES ** 0.5
        print(f"  {k}: 公式 {th[k]:.3f}  模拟 {st.mean(xs):.3f} ± {se:.3f}")
    keep = th["重推"] - max(th["固定"], th["反应"])
    room = th["上限"] - max(th["固定"], th["反应"], th["重推"])
    print(f"  保留优势 {keep:+.2f}  净空 {room:.2f}")
    d = [r["知识"] - r["固定"] for r in rows]
    m, s = st.mean(d), st.pstdev(d)
    if m > 0:
        print(f"  知识-固定: 均值 {m:.2f} 标准差 {s:.2f} 需配对生涯约 {(2.8 * s / m) ** 2:.0f}")


def window(n=8, q=0.8, D=1.0):
    print("\n探测价格 c 与保留的优势 min{n(q-1/2)D-c, (n-1)c}")
    for c in (0, 0.05, 0.1, 0.2, 0.3, 0.4, 0.6, 1.0, 1.5, 2.0, 2.4, 2.6):
        print(f"  c={c:<4} 优势 {min(n * (q - 0.5) * D - c, (n - 1) * c):+.2f}")


if __name__ == "__main__":
    run("算例")
    run("对照一：只用一次", n=1)
    run("对照二：线索无信息", q=0.5)
    run("对照三：规律固定且固定方案已掌握", p0=1.0)
    run("细胞：配对保持两餐", n=2, c=0.4, C=0.0, rho=0.0)
    window()
