"""Finite, agent-writable Rule 110 assay; Python 3.9+, standard library.
python3 rule110-witness.py --figure local-computation.svg
Only write, move, wait and a one-cell sensor are exposed to the scripted builder.
"""
import argparse
import itertools
from pathlib import Path

T = 24
WIDTH = 2*T + 1
A, B = -13, 9
ETHER = "00010011011111"
PREP = WIDTH + WIDTH - 1 + T      # write every cell, walk across, return to x=0


def intended(x, a, b):
    """Off-world preparation recipe, never used during material evolution."""
    return a if x == A else b if x == B else int(ETHER[x % len(ETHER)])


def material(row, boundary=(0, 0), rule=110):
    """row[i] uses the old triple (i-1,i,i+1) exactly once per material tick."""
    padded = [boundary[0], *row, boundary[1]]
    return [(rule >> ((padded[i] << 2) | (row[i] << 1) | padded[i+2])) & 1
            for i in range(len(row))]


class Coupon:
    """Frozen for exactly PREP actions, then permanently active, no more writes."""
    def __init__(self):
        self._row = [0]*WIDTH
        self._head = 0            # left end; one-site manipulator, no role after preparation
        self._elapsed = 0
        self.moves = self.writes = 0

    def observe(self):
        return self._row[self._head]

    def act(self, action):
        if action in ("0", "1") and self._elapsed < PREP:
            self._row[self._head] = int(action)
            self.writes += 1
        elif action in ("left", "right"):
            new = self._head + (1 if action == "right" else -1)
            if not 0 <= new < WIDTH:
                raise ValueError("moved off coupon")
            self._head = new
            self.moves += 1
        elif action != "wait":
            raise ValueError("illegal action or attempt to write active material")
        if self._elapsed >= PREP:
            self._row = material(self._row)
        self._elapsed += 1

    def audit(self):
        """Observer only; its output never drives the script or the medium."""
        return self._row.copy()


def run(a, b):
    world = Coupon()
    for x in range(-T, T+1):
        if x != -T:
            world.act("right")
        world.act(str(intended(x, a, b)))
    for _ in range(T):
        world.act("left")
    assert (world._head, world._elapsed, world.moves, world.writes) == (T, PREP, 72, 49)
    history = [world.audit()]
    observations = [world.observe()]
    for _ in range(T):
        world.act("wait")
        history.append(world.audit())
        observations.append(world.observe())
    return history, observations


def shrinking_cone(row):
    """Independent Boolean specification: drop one cell at either end per tick."""
    cone = [row[:]]
    while len(row) > 2:
        row = [int((not c and r) or (c and not (l and r)))
               for l, c, r in zip(row, row[1:], row[2:])]
        cone.append(row)
    return cone


def check():
    # Hand-computable lookup in 111 ... 000 order. Check both implementations.
    assert [material([c], (l, r))[0] for l,c,r in itertools.product((1,0), repeat=3)] == list(map(int,"01101110"))
    for l,c,r in itertools.product((0,1), repeat=3):
        assert shrinking_cone([l,c,r])[-1][0] == material([c],(l,r))[0]
    # The unperturbed infinite periodic background returns after seven ticks.
    period = list(map(int, ETHER))
    row = period[:]
    for i in range(1,8):
        row = material(row, (row[-1], row[0]))
        assert (row == period) == (i == 7)
    outputs, mistimed, mutated, cones = [], [], [], []
    for a,b in itertools.product((0,1), repeat=2):
        history, sensor = run(a,b)
        assert history[0] == [intended(x,a,b) for x in range(-T,T+1)]
        cone = shrinking_cone(history[0])
        alternate = history[0][:]
        changed_rule = history[0][:]
        for t, actual in enumerate(history):
            stop = WIDTH-t
            assert actual[t:stop] == alternate[t:stop] == cone[t]
            if t < T:
                # Challenge the boundary using different ghost values at each tick.
                alternate = material(alternate, (1-t%2, int(t%3==0)))
                changed_rule = material(changed_rule, rule=108)
        outputs.append(sensor[T])
        mistimed.append(sensor[T-1])
        mutated.append(changed_rule[T])
        cones.append(cone)
    assert (outputs,mistimed,mutated) == ([0,1,1,0],[0]*4,[0]*4)
    print("AB=00,01,10,11; local sensor x=0:")
    print("  Rule 110 at t=24:", outputs, "  t=23:", mistimed)
    print("  Rule 108 at t=24:", mutated)
    print("Per case: 49 writes + 72 moves + 24 waits = 145 action ticks; 1176 site updates.")
    print("4 x 625 causal-cone sites match independent shrinking reference and changed boundaries.")
    return cones


def write_svg(cones, path):
    size = 7
    parts = ['<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 870 580" role="img" aria-labelledby="title desc">',
             '<title id="title">两个局部输入在第 24 拍产生异或</title>',
             '<desc id="desc">四个三角分别是同一有限 Rule 110 因果域在 00、01、10、11 输入下的时空图。上方两处金色框是输入，下方框内是中央单格。输出为 0、1、1、0。</desc>',
             '<rect width="870" height="580" fill="#fbf9f3"/>',
             '<g font-family="system-ui, sans-serif" fill="#172e36">',
             '<text x="34" y="40" font-size="26" font-weight="700">两处局部改写，一个延迟读数</text>',
             '<text x="34" y="68" font-size="16">横轴：格点 −24 至 +24　　时间：由上往下　　深色 = 1，浅色 = 0</text>']
    for i, cone in enumerate(cones):
        a,b = divmod(i,2)
        x0, y0 = 44+(i%2)*420, 136+(i//2)*223
        out = cone[-1][0]
        parts.append(f'<text x="{x0}" y="{y0-26}" font-size="18" font-weight="650">A = {a}　B = {b}　→　读数 {out}</text>')
        parts.append('<g shape-rendering="crispEdges">')
        for t,row in enumerate(cone):
            x,y=x0+t*size,y0+t*size
            parts.append(f'<rect x="{x}" y="{y}" width="{size*len(row)}" height="{size}" fill="#e2e9e5"/>')
            d=''.join(f'M{x+j*size} {y}h{size}v{size}h-{size}z' for j,v in enumerate(row) if v)
            if d: parts.append(f'<path fill="#264a53" d="{d}"/>')
        parts.append('</g>')
        for x in (A,B):
            left=x0+(x+T)*size
            parts.append(f'<path d="M{left+size/2} {y0-16}v13" stroke="#a55214" stroke-width="2"/>')
            parts.append(f'<rect x="{left-1}" y="{y0-1}" width="{size+2}" height="{size+2}" fill="none" stroke="#a55214" stroke-width="2"/>')
        parts.append(f'<rect x="{x0+T*size-2}" y="{y0+T*size-2}" width="{size+4}" height="{size+4}" fill="none" stroke="#a55214" stroke-width="2"/>')
    parts.append('<text x="34" y="562" font-size="15">每幅只画中央读数的依赖范围：最上行 49 格，第 24 拍只剩 x = 0。</text></g></svg>')
    Path(path).write_text('\n'.join(parts)+'\n', encoding='utf-8')


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--figure", type=Path, help="write the four checked spacetime cones as SVG")
    args = parser.parse_args()
    cones = check()
    if args.figure:
        write_svg(cones, args.figure)
