"""Synthesize a queryable, exact expression for a fixed-boundary equilibrium.
Run: python3 equilibrium-program.py [--figure equilibrium-program.svg]
Dependencies: sympy; numpy and matplotlib only for the optional plot.
"""
import argparse
from dataclasses import dataclass
from itertools import combinations
from pathlib import Path

import sympy as sp

s, z, r, t = sp.symbols("s z R t", real=True)
Q = sp.Rational
BASIS = (sp.Integer(1), s, z, s*z, s**2, z**2)


@dataclass(frozen=True)
class Problem:
    s0: object
    w: object
    z0: object
    h: object
    # RHS in the nondimensional GS equation = -(a*R**2 + b)*(1 + eta*psi).
    a: object
    b: object
    eta: object = 0

    def boundary(self, u):
        return (self.s0 + self.w*(1-u**2)/(1+u**2),
                self.z0 + self.h*2*u/(1+u**2))

    def source(self, radial_squared, psi):
        return -(self.a*radial_squared + self.b)*(1+self.eta*psi)


def hand_check(problem, program):
    """Independent check over the full continuous domain, including the boundary."""
    flux = program.subs(s, r**2)
    # Use cylindrical coordinates, independently of the coordinates used to fit.
    residual = sp.diff(flux, r, 2) - sp.diff(flux, r)/r + sp.diff(flux, z, 2)
    residual -= problem.source(r**2, flux)
    boundary_trace = program.subs(dict(zip((s, z), problem.boundary(t))), simultaneous=True)
    omitted_point = program.subs({s: problem.s0-problem.w, z: problem.z0})
    return (sp.cancel(residual) == 0 and sp.cancel(boundary_trace) == 0
            and omitted_point == 0)


def synthesize(problem):
    """Try sparse expressions. Obtain coefficients from test constraints, never flux labels."""
    weights = sp.symbols("c0:6")
    template = sum(c*m for c, m in zip(weights, BASIS))
    tests = [template.subs(dict(zip((s, z), problem.boundary(Q(v)))))
             for v in (-2, -1, 0, 1, 2)]
    residual = 4*s*sp.diff(template, s, 2) + sp.diff(template, z, 2)
    residual -= problem.source(s, template)
    # Three interior sites: subdomains have different dimensions across problems.
    for u, v in [(0,0), (Q(1,2),0), (0,Q(1,2))]:
        tests.append(residual.subs({s:problem.s0+u*problem.w,z:problem.z0+v*problem.h}))
    matrix, rhs = sp.linear_eq_to_matrix(tests, weights)
    tried = 0
    for order in range(1, len(BASIS)+1):
        for columns in combinations(range(len(BASIS)), order):
            tried += 1
            sol = sp.linsolve((matrix[:, list(columns)], rhs))
            if sol is sp.EmptySet or not sol:
                continue
            coeffs = next(iter(sol))
            if any(value.free_symbols for value in coeffs):
                continue
            program = sp.Add(*(BASIS[i]*v for i,v in zip(columns, coeffs)))
            if hand_check(problem, program):
                return program, tried
    return None, tried


def manufactured(k, s0, w, z0, h):
    return Problem(s0,w,z0,h,8*k/w**2,2*k/h**2)


def figure(p, program, dest):
    import numpy as np
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib import font_manager
    mac_font = Path("/System/Library/Fonts/Supplemental/Arial Unicode.ttf")
    if mac_font.is_file():
        font_manager.fontManager.addfont(mac_font)
    for name in ("Noto Sans CJK SC", "Arial Unicode MS", "PingFang SC", "Heiti SC"):
        if name in set(f.name for f in font_manager.fontManager.ttflist):
            plt.rcParams["font.family"] = name
            break
    plt.rcParams.update({"axes.unicode_minus":False,"svg.fonttype":"path","svg.hashsalt":"gs-fixture-v1"})
    lo, hi = map(float, (p.s0-p.w,p.s0+p.w))
    zz = np.linspace(float(p.z0-p.h)*1.05,float(p.z0+p.h)*1.05,201)
    rr = np.linspace(np.sqrt(lo)-.02,np.sqrt(hi)+.02,201)
    R,Z = np.meshgrid(rr,zz)
    values = sp.lambdify((s,z),program,'numpy')(R**2,Z)
    fig, (a,b) = plt.subplots(1,2,figsize=(7.8,3.8),layout="constrained")
    for axis in (a,b):
        axis.set_aspect("equal"); axis.set_xlabel("R"); axis.set_ylabel("Z")
        axis.spines[['top','right']].set_visible(False)
    phi=np.linspace(0,2*np.pi,361)
    border=(np.sqrt(float(p.s0)+float(p.w)*np.cos(phi)),float(p.z0)+float(p.h)*np.sin(phi))
    a.plot(*border,color='#266677',lw=2)
    for u in (-2,-1,0,1,2):
        points=p.boundary(Q(u))
        a.scatter(np.sqrt(float(points[0])), float(points[1]),s=20,color='#b3522c',zorder=3)
    for u,v in [(0,0),(.5,0),(0,.5)]:
        a.scatter(np.sqrt(float(p.s0)+u*float(p.w)),float(p.z0)+v*float(p.h),
                  s=25,marker='+',color='#253e46',zorder=4)
    a.set_title("给定零磁通边界",fontsize=13)
    b.plot(*border,color='#266677',lw=2)
    lines=b.contour(R,Z,values, levels=[.2,.4,.6,.8],colors='#27797a')
    b.clabel(lines,inline=True,fontsize=8,fmt='%.1f')
    b.set_title("用生成的表达式查询磁通",fontsize=13)
    for axis in (a,b):
        axis.set_xlim(rr[0],rr[-1]);axis.set_ylim(zz[0],zz[-1])
    fig.savefig(dest,format='svg',metadata={"Date":None});plt.close(fig)


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--figure", type=Path)
    args=ap.parse_args()
    problems = [manufactured(*map(Q,params)) for params in
                [(1,3,2,0,1),(2,4,1,Q(1,4),Q(3,4)),(Q(1,2),5,2,Q(-1,3),1)]]
    for i,p in enumerate(problems,1):
        out,tried=synthesize(p)
        assert out is not None and hand_check(p,out)
        assert not hand_check(p,out+1)  # constant shift leaves PDE, changes trace
        print("case",i,"tried",tried,"program",out,"whole boundary and PDE: exact")
        if i==1 and args.figure:
            figure(p,out,args.figure)
    p=Problem(3,2,0,1,2,2,Q(1,3))
    out,tried=synthesize(p)
    assert out is None
    print("flux-dependent source: no verified program in this grammar;",tried,"supports tried")


if __name__=="__main__":
    main()
