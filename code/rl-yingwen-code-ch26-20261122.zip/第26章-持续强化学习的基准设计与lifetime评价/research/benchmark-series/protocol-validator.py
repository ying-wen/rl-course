"""Two-process mutex protocols with independently checkable finite certificates.

Run the examples: python3 protocol-validator.py
Transfer a certificate: python3 protocol-validator.py --emit atomic | python3 protocol-validator.py --check atomic
--emit outputs JSON. --check reads one JSON certificate from stdin, rejecting invalid ones with exit status 1.
States are [phase0, phase1, lock]. A scheduler picks one enabled process per step.
The public transition table below is the specification shared by the finder and checker.
The checker does not need the finder, its queue, or its set of reachable states.
"""
import argparse
import itertools
import json
import sys
from collections import deque

PHASES = ("idle", "seen", "critical")
STATES = tuple(itertools.product(PHASES, PHASES, (0, 1)))
INITIAL = ("idle", "idle", 0)


def edges(state, protocol):
    """Yield the enabled, labeled successors of one state."""
    for actor in (0, 1):
        phase = state[actor]
        lock = state[2]
        if phase == "idle" and lock == 0:
            action, new_phase, new_lock = "observe", "seen", 0
        elif phase == "seen" and (protocol == "split" or lock == 0):
            # The repair checks the current lock as part of this indivisible step.
            action, new_phase, new_lock = "commit", "critical", 1
        elif phase == "critical":
            action, new_phase, new_lock = "release", "idle", 0
        else:
            continue
        target = list(state)
        target[actor] = new_phase
        target[2] = new_lock
        yield f"P{actor}.{action}", tuple(target)


def bad(state):
    return state[:2] == ("critical", "critical")


def shortest_counterexample(protocol):
    """Breadth-first search with unit-cost actions, reconstructing one shortest bad trace."""
    previous = {INITIAL: None}
    queue = deque([INITIAL])
    while queue:
        state = queue.popleft()
        if bad(state):
            states, actions = [state], []
            while previous[state] is not None:
                state, action = previous[state]
                states.append(state)
                actions.append(action)
            return {"kind": "trace", "states": states[::-1], "actions": actions[::-1]}
        for action, target in edges(state, protocol):
            if target not in previous:
                previous[target] = (state, action)
                queue.append(target)
    return None


def invariant_certificate():
    # The human-supplied symbolic invariant is num_critical == lock. Give its full
    # extension as a portable certificate. A prover may supply any subset of STATES.
    states = [s for s in STATES if s[:2].count("critical") == s[2]]
    return {"kind": "invariant", "states": states}


def decode_states(values):
    if not isinstance(values, list):
        raise ValueError("states must be a list")
    result = []
    for value in values:
        if (not isinstance(value, (list, tuple)) or len(value) != 3
                or value[0] not in PHASES or value[1] not in PHASES
                or type(value[2]) is not int or value[2] not in (0, 1)):
            raise ValueError(f"invalid state: {value!r}")
        result.append(tuple(value))
    return result


def verify(protocol, certificate):
    """Check a submitted witness against the public finite transition system."""
    if protocol not in ("split", "atomic"):
        raise ValueError("unknown protocol")
    if not isinstance(certificate, dict):
        raise ValueError("expected a certificate object")
    states = decode_states(certificate.get("states"))
    if certificate.get("kind") == "trace":
        actions = certificate.get("actions")
        if not states or states[0] != INITIAL:
            raise ValueError("trace does not start in the initial state")
        if not isinstance(actions, list) or len(actions) != len(states)-1:
            raise ValueError("trace length is inconsistent")
        for i, (source, action, target) in enumerate(zip(states, actions, states[1:]), 1):
            if (action, target) not in tuple(edges(source, protocol)):
                raise ValueError(f"invalid step {i}: {source} --{action}--> {target}")
        if not bad(states[-1]):
            raise ValueError("final state is not bad")
        return f"accepted bad trace of {len(actions)} steps"
    if certificate.get("kind") != "invariant":
        raise ValueError("unknown certificate kind")
    members = set(states)
    if INITIAL not in members:
        raise ValueError("initiation fails: H omits the initial state")
    edge_count = 0
    for state in STATES:
        if state not in members:
            continue
        for action, target in edges(state, protocol):
            if target not in members:
                raise ValueError(f"closure fails: {state} --{action}--> {target}")
            edge_count += 1
    for state in STATES:
        if state in members and bad(state):
            raise ValueError(f"safety fails: H contains {state}")
    return (f"accepted invariant: initiation, closure, safety; {len(members)}/{len(STATES)} "
            f"states satisfy H; {edge_count} enabled transitions from H")


def emit(protocol):
    return shortest_counterexample("split") if protocol == "split" else invariant_certificate()


def expect_rejection(protocol, certificate):
    try:
        verify(protocol, certificate)
    except ValueError as error:
        return str(error)
    raise RuntimeError("negative control unexpectedly accepted")


def demo():
    trace = emit("split")
    if trace is None:
        raise RuntimeError("split protocol produced no bad trace")
    print("split:", verify("split", trace))
    print("  start", trace["states"][0])
    for action, state in zip(trace["actions"], trace["states"][1:]):
        print(" ", action, "->", state)
    # Four is also a lower bound: each process must observe then commit at least once.
    if len(trace["actions"]) != 4:
        raise RuntimeError("shortest length did not match the four-action lower bound")
    inv = emit("atomic")
    print("atomic H = (# critical processes == lock):", verify("atomic", inv))
    if shortest_counterexample("atomic") is not None:
        raise RuntimeError("BFS disagrees with the checked invariant")
    print("split trace on atomic:", expect_rejection("atomic", trace))
    print("atomic H on split:", expect_rejection("split", inv))
    print("empty H on atomic:", expect_rejection("atomic", {"kind":"invariant", "states":[]}))
    print("H = not bad on atomic:", expect_rejection(
        "atomic", {"kind": "invariant", "states": [s for s in STATES if not bad(s)]}))
    print("universal H on atomic:", expect_rejection(
        "atomic", {"kind": "invariant", "states": list(STATES)}))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    group = parser.add_mutually_exclusive_group()
    group.add_argument("--emit", choices=("split", "atomic"))
    group.add_argument("--check", choices=("split", "atomic"))
    args = parser.parse_args()
    if args.emit:
        print(json.dumps(emit(args.emit), indent=2))
    elif args.check:
        try:
            print(verify(args.check, json.load(sys.stdin)))
        except ValueError as error:
            print(f"rejected: {error}", file=sys.stderr)
            sys.exit(1)
    else:
        demo()
