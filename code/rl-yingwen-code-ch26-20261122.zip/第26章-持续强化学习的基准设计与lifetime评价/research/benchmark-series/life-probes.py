#!/usr/bin/env python3
"""Two small identification experiments. Run with Python 3 and no packages.

Every tissue, organism and wet-lab result in the readings is a proposed
extension. This script runs a binary sensing task and a synthetic lab only.
"""

import argparse
from fractions import Fraction
from itertools import product
from math import comb


def sensing_value(accuracy, cost, prior=Fraction(1, 2)):
    """Expected net reward for an optimal enzyme choice after one noisy cue.

    The sensor has symmetric accuracy for the two possible nutrients.
    A correct enzyme earns one unit. Both joint masses for each observed
    cue are compared, allowing the agent to ignore an unhelpful cue.
    """
    high = max(prior * accuracy, (1 - prior) * (1 - accuracy))
    low = max(prior * (1 - accuracy), (1 - prior) * accuracy)
    direct = max(prior, 1 - prior)
    return direct, high + low - cost


def grows(mechanism, active_a, active_b, rich):
    """First model has a route B. In the second, rich medium supplies C."""
    if mechanism == "route":
        return active_a or active_b
    if mechanism == "medium":
        return active_a or rich
    raise ValueError("Unknown mechanism")


def growth_readout(mechanism, condition):
    """Probability of a positive readout with an independent 10% flip."""
    return Fraction(9 if grows(mechanism, *condition) else 1, 10)


def panel_brier(query, repetitions):
    """Exact expected squared error on a fresh, hidden synthetic culture.

    The two mechanisms are equiprobable. The test perturbation is distinct
    from both available queries. Scoring integrates over an independent
    test readout, conditional on the same hidden mechanism. No panel
    outcome is exposed to the experimenter.
    """
    panel = (False, False, True)
    mechanisms = ("route", "medium")
    query_probability = [growth_readout(m, query) for m in mechanisms]
    panel_probability = [growth_readout(m, panel) for m in mechanisms]
    expected_loss = Fraction(0)
    for positives in range(repetitions + 1):
        # Prior mass times binomial likelihood for all histories with k positives.
        mass = [
            Fraction(1, 2) * comb(repetitions, positives)
            * p ** positives * (1 - p) ** (repetitions - positives)
            for p in query_probability
        ]
        prediction = sum(w * p for w, p in zip(mass, panel_probability)) / sum(mass)
        for w, p in zip(mass, panel_probability):
            expected_loss += w * (p * (1 - prediction) ** 2 + (1 - p) * prediction ** 2)
    return expected_loss


def save_lab_figure(path, familiar, informative):
    """Optional offline figure. All plotted points come from panel_brier."""
    import matplotlib.pyplot as plt

    counts = range(7)
    with plt.rc_context({"font.family": "DejaVu Sans", "svg.fonttype": "path"}):
        fig, ax = plt.subplots(figsize=(7.2, 3.55), constrained_layout=True)
        for condition, label, color, marker in (
            (familiar, "Repeat familiar medium", "#aa5834", "s"),
            (informative, "Change the medium", "#116c74", "o"),
        ):
            scores = [float(panel_brier(condition, n)) for n in counts]
            ax.plot(counts, scores, color=color, marker=marker, label=label, linewidth=2)
        ax.axhline(0.09, linestyle=":", color="#697e80", linewidth=1.3)
        ax.text(0.08, 0.093, "Irreducible readout noise", fontsize=9, color="#566a6c")
        ax.set(xlabel="Virtual cultures queried", ylabel="Expected Brier score on fresh culture",
               xticks=counts, yticks=(0.10, 0.15, 0.20, 0.25), ylim=(0.075, 0.27))
        ax.spines[["top", "right"]].set_visible(False)
        ax.legend(loc="center right", bbox_to_anchor=(0.99, 0.65), frameon=False)
        fig.savefig(path)
        plt.close(fig)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--figure", help="Save the lab plot; requires Matplotlib")
    args = parser.parse_args()
    direct, cheap = sensing_value(Fraction(4, 5), Fraction(1, 10))
    _, costly = sensing_value(Fraction(4, 5), Fraction(2, 5))
    assert (direct, cheap, costly) == (Fraction(1, 2), Fraction(7, 10), Fraction(2, 5))
    # If the prior dominates the sensor, a new reading can be ignored.
    assert sensing_value(Fraction(4, 5), 0, Fraction(9, 10)) == (Fraction(9, 10),) * 2
    print("Binary sensing, expected net assimilation (one unit for a match)")
    print(f"  direct {float(direct):.2f}, cheap test {float(cheap):.2f}, costly test {float(costly):.2f}")
    print("Synthetic lab, exact expected Brier score on held-out rich double knockout")
    familiar = (False, True, True)
    informative = (False, True, False)
    assert growth_readout("route", familiar) == growth_readout("medium", familiar)
    # Directly enumerate the 8 (A, B, medium) environments in the two models.
    differing = [s for s in product((False, True), repeat=3) if grows("route", *s) != grows("medium", *s)]
    assert len(differing) == 2 and informative in differing and (False, False, True) in differing
    assert panel_brier(familiar, 6) == Fraction(1, 4)
    assert panel_brier(informative, 1) == Fraction(369, 2500)
    print("  repeats    familiar    informative")
    for n in (0, 1, 2, 4, 6):
        print(f"  {n:7d}    {float(panel_brier(familiar, n)):.4f}    {float(panel_brier(informative, n)):.4f}")

    if args.figure:
        save_lab_figure(args.figure, familiar, informative)


if __name__ == "__main__":
    main()
