"""Two-load compliance probe for the Chapter 15 orbital assembly reading.

Run with Python 3. Only one transverse spring-damper mode is integrated.
Parameters are illustrative and forces are imposed by an ideal actuator.
"""
from math import sqrt


def loaded_positions(offset_mm, compliance_mm_per_n, step_s):
    mass_kg = 0.4
    stiffness_n_per_m = 1000 / compliance_mm_per_n
    damping_ns_per_m = 2 * sqrt(stiffness_n_per_m * mass_kg)
    position_m = 0.0
    velocity_m_per_s = 0.0
    readings_mm = []
    for force_n in (2.0, 4.0):
        for _ in range(round(0.25 / step_s)):
            spring_n = stiffness_n_per_m * position_m
            damping_n = damping_ns_per_m * velocity_m_per_s
            velocity_m_per_s += step_s * (force_n - spring_n - damping_n) / mass_kg
            position_m += step_s * velocity_m_per_s
        readings_mm.append(offset_mm + 1000 * position_m)
    return readings_mm


if __name__ == '__main__':
    for offset_mm, compliance_mm_per_n in ((0.6, 0.2), (0.2, 0.4)):
        equilibrium_mm = [offset_mm + force * compliance_mm_per_n for force in (2, 4)]
        print('Offset %.1f mm, compliance %.1f mm/N' % (offset_mm, compliance_mm_per_n))
        for step_s in (0.001, 0.0005):
            readings_mm = loaded_positions(offset_mm, compliance_mm_per_n, step_s)
            print('  dt %.1f ms: %.6f mm, %.6f mm' % (1000 * step_s, *readings_mm))
            assert max(abs(x - y) for x, y in zip(readings_mm, equilibrium_mm)) < 0.001
