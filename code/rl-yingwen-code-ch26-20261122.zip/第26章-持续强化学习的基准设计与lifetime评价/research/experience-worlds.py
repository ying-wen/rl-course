#!/usr/bin/env python3
"""Two small mechanisms for the chapter on learning from experience.

Run: python3 experience-worlds.py --seed 20261116 --steps 4000
Each policy sees exactly the same events as its comparisons within its world.
Both generators start from the reported seed. Times exclude the self-checks.
All devices and update rules in this file are supplied by the experimenter.
"""

import argparse
import random
from time import perf_counter


def routing_trial(steps, stations, reachable, seed):
    """One binary packet per station and round. Gain is one per correct route.

    Default route is zero. The operator can read and switch up to k sites
    selected before the destinations are revealed. Unvisited sites receive no
    remote command. A local contact reads and routes its own site's packet.
    """
    rng = random.Random(seed)
    # Independent, exchangeable sites: visiting the first k is representative.
    manual = local = 0
    visited_mask = (1 << reachable) - 1
    for _ in range(steps):
        destinations = rng.getrandbits(stations)
        manual_routes = destinations & visited_mask
        local_routes = destinations  # Independent wires, one sensor per site.
        manual += stations - bin(manual_routes ^ destinations).count('1')
        local += stations - bin(local_routes ^ destinations).count('1')
    return manual, local


def feed_cell(state, cue, nutrient, rate):
    """Choose enzyme first; after nutrient arrives, update a bounded trace."""
    enzyme = cue if state >= 0 else -cue
    gain = int(enzyme == nutrient)
    next_state = (1 - rate) * state + rate * cue * nutrient
    return gain, next_state


def nutrient_trial(steps, seed, reliability=0.85, rate=0.125):
    """One nondividing cell, no change-of-regime signal. Gain is 1 or 0.

    State is a scalar in [-1, 1]. A zero trace breaks ties toward copying the
    cue. The erase comparison performs the identical writes then loses its
    writable trace before each next cue. It retains the current cue.
    """
    rng = random.Random(seed)
    switch = steps // 2
    window = min(16, steps - switch)
    totals = {key: [0, 0, 0] for key in
              ('fixed +cue', 'fixed -cue', 'retained trace', 'erased trace')}
    state = 0.0
    for t in range(steps):
        cue = rng.choice((-1, 1))
        sign = 1 if t < switch else -1
        # This is the world's private outcome. Only the arriving cue is used
        # to choose an enzyme. All methods see the same nutrient afterwards.
        nutrient = sign * cue if rng.random() < reliability else -sign * cue
        retained_gain, state = feed_cell(state, cue, nutrient, rate)
        erased_gain, _ = feed_cell(0.0, cue, nutrient, rate)
        gains = (int(cue == nutrient), int(-cue == nutrient),
                 retained_gain, erased_gain)
        period = 0 if t < switch else (1 if t < switch + window else 2)
        for counts, gain in zip(totals.values(), gains):
            counts[period] += gain
    return totals, (switch, window, steps - switch - window)


def self_check():
    # Under no visitation, enumerating all N-bit destinations yields N/2.
    for k in range(4):
        correct = sum(3 - bin(word >> k).count('1') for word in range(8))
        assert correct == 8 * (k + (3 - k) / 2)
    assert routing_trial(8, 3, 3, 9) == (24, 24)
    # A current observation can update only future choices.
    assert feed_cell(0.0, 1, -1, 1.0) == (0, -1.0)
    assert feed_cell(-1.0, 1, -1, 1.0) == (1, -1.0)
    for cue in (-1, 1):
        for nutrient in (-1, 1):
            for state in (-1.0, 0.0, 1.0):
                assert abs(feed_cell(state, cue, nutrient, 0.125)[1]) <= 1
    scores, lengths = nutrient_trial(100, 11)
    assert sum(lengths) == 100 and scores['fixed +cue'] == scores['erased trace']


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--seed', type=int, default=20261116)
    parser.add_argument('--steps', type=int, default=4000)
    parser.add_argument('--stations', type=int, default=8)
    parser.add_argument('--reachable', type=int, default=2)
    args = parser.parse_args()
    if args.steps < 2 or args.stations < 1 or not 0 <= args.reachable <= args.stations:
        parser.error('require steps >= 2 and 0 <= reachable <= stations, stations >= 1')
    self_check()
    print(f'seed={args.seed}, rounds per world={args.steps}, self-checks passed')
    start = perf_counter()
    manual, local = routing_trial(args.steps, args.stations, args.reachable, args.seed)
    elapsed = perf_counter() - start
    expected = args.reachable + (args.stations - args.reachable) / 2
    print(f'routing: N={args.stations}, k={args.reachable}, correct deliveries/round')
    print(f'  manual {manual / args.steps:.3f} (expectation {expected:.3f})')
    print(f'  local contacts {local / args.steps:.3f} (exact); {elapsed:.6f} s')
    start = perf_counter()
    totals, lengths = nutrient_trial(args.steps, args.seed)
    elapsed = perf_counter() - start
    print(f'cell: P(Y=sign*C)=0.85, trace rate=0.125, energy gain/round')
    print(f'  periods: before reversal ({lengths[0]}), first after ({lengths[1]}), '
          f'later ({lengths[2]}), full life ({args.steps})')
    for key, scores in totals.items():
        means = [f'{x / n:.3f}' if n else 'n/a' for x, n in zip(scores, lengths)]
        print(f'  {key:15s} {"  ".join(means)}  {sum(scores) / args.steps:.3f}')
    print(f'  {elapsed:.6f} s')


if __name__ == '__main__':
    main()
