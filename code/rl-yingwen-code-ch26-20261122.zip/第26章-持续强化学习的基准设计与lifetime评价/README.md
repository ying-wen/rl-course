# 第 26 章　持续强化学习的基准设计与 lifetime 评价：程序

本目录可以单独运行：在本目录下执行下面的命令即可，结果写回本目录的 `assets/`。目录由 `rl-course/tools/export_chapter_code.py` 从课程目录生成，改程序请改课程目录里的原件，再重新导出。

## 准备

```sh
python3 -m pip install -r requirements.txt
```

需要的第三方包：matplotlib、numpy、sympy。复现附录要求 Python 3.10 或更新版本；核验时用的版本见下表。

## 运行（与复现附录相同）

```sh
python3 demos/crl_joint_v12.py
python3 research/benchmark-series/protocol-validator.py
python3 research/benchmark-series/rule110-witness.py --figure research/benchmark-series/local-computation.svg
python3 research/benchmark-series/orbit-probe.py
python3 research/capability-ledger.py
python3 research/benchmark-series/equilibrium-program.py --figure research/benchmark-series/equilibrium-program.svg
python3 research/benchmark-series/life-probes.py --figure research/benchmark-series/lab-intervention-brier.svg
python3 research/experience-worlds.py --seed 20261116 --steps 4000
```

## 本目录的程序

| 程序 | 说明 | 核验 |
|---|---|---|
| `demos/crl_joint_v12.py` | One continuing navigation task, learned skills, GVFs and rate-aware planning. | 通过（47 秒） |
| `research/benchmark-series/protocol-validator.py` | Two-process mutex protocols with independently checkable finite certificates. | 通过（0 秒） |
| `research/benchmark-series/rule110-witness.py` | Finite, agent-writable Rule 110 assay; Python 3.9+, standard library. | 通过（0 秒） |
| `research/benchmark-series/orbit-probe.py` | Two-load compliance probe for the Chapter 15 orbital assembly reading. | 通过（0 秒） |
| `research/capability-ledger.py` | 一项能力的收支：最小世界的四种做法与上限（第 26 章 26.6 节）。 | 通过（1 秒） |
| `research/benchmark-series/equilibrium-program.py` | Synthesize a queryable, exact expression for a fixed-boundary equilibrium. | 通过（2 秒） |
| `research/benchmark-series/life-probes.py` | Two small identification experiments. Run with Python 3 and no packages. | 通过（0 秒） |
| `research/experience-worlds.py` | Two small mechanisms for the chapter on learning from experience. | 通过（0 秒） |
| `demos/v19_continual.py` | Bounded calculations for the v19 continual-learning bridge. | 通过（1 秒） |
| `demos/sample14_average_option.py` | Three-station worked example: rate -> differential TD -> learned option model -> action. | 通过（6 秒） |
| `demos/multiscale_models.py` | Compare recursive and direct prediction with exactly the same observed paths. | 通过（2 秒） |
| `demos/crl_ladder_world.py` | 四区仓库：第三部分的能力阶梯世界（环境与精确参照）。 | 通过（52 秒） |
| `demos/crl_ladder_world_checks.py` | 四区仓库的独立检查（照 v12 的做法：手算、枚举、独立实现互查）。 | 通过（18 秒） |
| `demos/crl_ladder_learners.py` | 四区仓库的学习器阶梯（例子方案第三步）。 | 通过（86 秒） |
| `demos/crl_ladder_power.py` | 四区仓库学习器阶梯：试点估 σ_Δ 定种子数，正式跑后出第 24 章的账本。 | 通过（1 秒） |
| `demos/crl_ladder_ceiling.py` | 四区仓库学习器阶梯：每个试验条件的“天花板”，供账本算“离最优还差多少”。 | 超时：300 秒内未跑完（启动正常） |
| `demos/crl_ladder_figures.py` | 阶梯世界（四区仓库）阅读稿用图：地图与各章“占天花板”条形。 | 通过（1 秒） |
| `demos/crl_ladder_diagnostics.py` | 四区仓库阶梯的诊断与改法（11-20）。 | 通过（0 秒） |

表中后 10 个程序复现附录本章一节没有列出，来自课件、阅读稿、CODE-MAP 或文件名前缀（第三部分另含学习器阶梯）。

## 第三部分的学习器阶梯（例子方案第三步）

四区仓库世界与 L0–L10 阶梯学习器。每章一个实验，三档：没有、设计者给定、从经验学到。比较都是配对的：同一种子下两档用同一份世界随机数。

```sh
python3 demos/crl_ladder_power.py ledger --runs formal-ch15 formal-ch16 formal-ch17 formal-ch18 formal-ch19 formal-ch20 formal-ch21 formal-ch22 formal-ch23 formal-ch24 formal-ch25 formal5m-ch20   # 读 assets/crl-ladder-world/runs/ 里的全部正式记录，出总账（含第 24 章的交互项）
```

参考记录在 `assets/crl-ladder-world/runs/`（随本目录复制）。正式设置一章要跑数十分钟到数小时；冒烟一行只确认程序能走通。正式结果与读法见 `assets/crl-ladder-world/README.md` 第八节，改进与诊断见第九节。

## 复现附录本章一节

本章来自本课程序的结果有：26.5 节引用的第 24 章三站实验配对差，26.5 节锁协议、Rule 110 见证与在轨装配两次加力的数值，选读部分“一项能力的收支”的模拟与否定对照，以及各研究世界表中已运行的数字。选读部分指 26.md 的“研究环境：能力怎样从经验中形成（选读）”；这几个程序放在 research/ 目录下，表中的链接给出位置。平流层气球与聚变一段引用的代码和测量来自原作者，出处见表后。

26.4 节仓库读数的 $27/8$、$17/8$、$5/8$ 与 $4/3$，以及 $N\approx(2.8\sigma_\Delta/\delta)^2$ 代入后的配对数，由正文推导直接算出。

| 位置 | 结果 | 设置 | 程序 | 数据与输出 |
|---|---|---|---|---|
| 26.5 节“要多少对”表中“第 24 章三站实验”一行（课件 `ch26-spec-pairs`） | 八对每千步差均值 $-1.71$，标准误 $.748$，单对标准差约 $2.12$ | 本课的模拟：三站任务，不规划、五次规划、中点后冻结三种条件各运行 8 段 lifetime，每段 $120000$ 步，第 $60000$ 步 C 站奖励由 $3$ 降为 $.1$；此处按种子把不规划组与五次规划组配成 8 对，取全程每步奖励之差 | `demos/crl_joint_v12.py` | `assets/crl-joint-v12/manifest.json`（`summary` 中逐种子的 `lifetime_rate`）；逐段原始记录在同一目录的 `raw-*-seed*.npz` |
| 26.5 节“第一个标志性基准”，两类任务（课件 ch26-computer-tasks） | 锁协议共 $18$ 个赋值；查锁与上锁分两步时最短 $4$ 步违反互斥；合成一步时不变式 $H$ 含 $8$ 个状态，通过三条蕴含核验；把错误的证书交给核验器时被拒绝 | 本课的计算：两进程、每进程闲/看/临界三相加一位锁；由广度优先搜索求最短反例，由独立的核验函数检查证书 | `research/benchmark-series/protocol-validator.py` | 结果打印到终端，无输出文件；`--emit` 输出 JSON 证书，`--check` 读入并核验 |
| 26.5 节“第一个标志性基准”，校准见证（课件 ch26-computer-witness） | 输入写在第 $-13$ 与 $+9$ 格，跑 $24$ 拍，中心读数 $0,1,1,0$；第 $23$ 拍早读与改用 Rule 108 时四组都为 $0$；每组 $49\times24=1176$ 次格点更新 | 本课的计算：Rule 110，以太图样 `00010011011111`，$T=24$，四组输入各运行一次 | `research/benchmark-series/rule110-witness.py` | `research/benchmark-series/local-computation.svg`（加 `--figure` 时生成） |
| 26.5 节“第二个标志性基准：在轨装配”（课件 `ch26-orbit-identify`）；选读部分世界表“在轨装配”一行 | $(b,c)=(.6,.2)$ 与 $(.2,.4)$ 在 $2$ N 时位移都是 $1.0$ mm，在 $4$ N 时为 $1.4$ 与 $1.8$ mm，相差 $.4$ mm | 本课的模拟：单一侧向弹簧—阻尼模态，质量 $.4$ kg，临界阻尼，每个力水平积分 $.25$ s，步长 $1$ ms 与 $.5$ ms 各算一次；与静态解之差小于 $.001$ mm | `research/benchmark-series/orbit-probe.py` | 结果打印到终端，无输出文件 |
| 选读部分“一项能力的收支与可判别的窗口”；“首批实验的实施方案”第二、三步 | 四种做法的模拟值 $3.951$、$3.998$、$5.314$、$5.614$（标准误不超过 $.028$）；$c^*=.3$ 时最大优势 $2.1$；细胞代入得 $1.2$ 对 $1.0$；三个否定对照下保留优势 $-.1$、$-1.1$、$-2.7$；“整理成知识”比固定方案多 $1.6$，差的标准差约 $5.1$，$N\approx80$ | 本课的模拟：最小世界 $n=8$、$q=.8$、$D=1$、$c=.3$、$C=.5$、$\rho=.1$，独立模拟 $20000$ 条 lifetime，种子 $20261117$；否定对照依次取 $n=1$、$q=.5$、$p_0=1$；细胞代入取 $n=2$、$c=.4$、$C=0$、$\rho=0$；探测价格 $c$ 从 $0$ 取到 $2.6$ | `research/capability-ledger.py` | 结果打印到终端，无输出文件 |
| 选读部分世界表“磁平衡程序”一行；“各世界的可学规律与检验”磁平衡一段 | 三组常数源项的问题通过全域验证，首例 $\psi=-s^2/4+3s/2-Z^2-5/4$；换源项后 $63$ 个非空组合全部失败 | 本课的计算：变换 $s=R^2$，六个候选单项式 $1,s,Z,sZ,s^2,Z^2$，枚举非空组合，在五个边界点和三个内部点上求精确有理系数，再独立检验全域方程与整条边界；需 sympy | `research/benchmark-series/equilibrium-program.py` | `research/benchmark-series/equilibrium-program.svg`（加 `--figure` 时生成） |
| 选读部分世界表“单细胞”“虚拟细胞实验室”两行；“各世界的可学规律与检验”中生物个体与虚拟细胞实验室两段 | 受体准确率 $.80$：不测 $.50$，成本 $.10$ 时 $.70$，成本 $.40$ 时 $.40$；先验 $.90$ 时读数价值为零；无区分力的一行重复 $6$ 次 Brier 分数仍为 $.2500$，有区分力的一行 $6$ 次降到 $.0931$ | 本课的计算：二元感知按精确分数求期望；虚拟实验室枚举 $(A,B,\text{培养基})$ 八种环境，读数独立以 $10\%$ 概率翻转，按精确分数计算留出条件上的期望 Brier 分数 | `research/benchmark-series/life-probes.py` | `research/benchmark-series/lab-intervention-brier.svg`（加 `--figure` 时生成） |
| 选读部分世界表“单细胞”一行；“一种能力何时值得获得”中配送网与细胞两段 | 配送网每拍送对 $5.028$ 件对 $8$ 件；单细胞清除慢状态后匹配率由 $.850$ 降到 $.497$ | 本课的模拟：单次运行，种子 $20261116$，$4000$ 拍；配送网 $N=8$、$k=2$；细胞线索可靠度 $.85$、痕迹更新率 $.125$，从第 $2001$ 拍起配对反转 | `research/experience-worlds.py` | 结果打印到终端，无输出文件 |

运行：
```sh
python3 demos/crl_joint_v12.py
python3 research/benchmark-series/protocol-validator.py
python3 research/benchmark-series/rule110-witness.py --figure research/benchmark-series/local-computation.svg
python3 research/benchmark-series/orbit-probe.py
python3 research/capability-ledger.py
python3 research/benchmark-series/equilibrium-program.py --figure research/benchmark-series/equilibrium-program.svg
python3 research/benchmark-series/life-probes.py --figure research/benchmark-series/lab-intervention-brier.svg
python3 research/experience-worlds.py --seed 20261116 --steps 4000
```

外部代码（出处）：平流层气球一段引用 Balloon Learning Environment（google/balloon-learning-environment）的 `eval_lib.py`、`balloon_env.py`、`generative_wind_field.py`、`balloon_arena.py`、`features.py`、`perciatelli44.py`、`station_seeker_agent.py`、`marco_polo_exploration.py`、`wind_gp.py`，为原作者代码；聚变“每炮约 2 分 37 秒”为 FPDT 作者的测量，MHD 求解器的迭代数与求解时间取自 Adams 等的文献。

## 参考数据

`assets/`（以及 `demos/NN-results/`）下复制了 165 个数据文件（json、csv 等），即课程目前使用的结果；图片没有复制，运行程序会重新画出。重跑会覆盖这些文件，可以先另存一份再对照。
