# 第 20 章　状态构造与表示学习：程序

本目录可以单独运行：在本目录下执行下面的命令即可，结果写回本目录的 `assets/`。目录由 `rl-course/tools/export_chapter_code.py` 从课程目录生成，改程序请改课程目录里的原件，再重新导出。

## 准备

```sh
python3 -m pip install -r requirements.txt
```

需要的第三方包：matplotlib、numpy。复现附录要求 Python 3.10 或更新版本；核验时用的版本见下表。

## 运行（与复现附录相同）

```sh
python3 demos/v19_continual.py        # 读 assets/crl-joint-v12，写 assets/v19-continual
python3 demos/crl_v10_derivations.py  # 写 assets/crl-v10
python3 demos/ch20_noisy_cue.py 6000 3000 0.2   # 写 assets/ch20-noisy-cue
python3 demos/ch20_noisy_cue.py 6000 6000 0.8
python3 demos/ch20_noisy_cue_sensitivity.py
python3 demos/ch20_open_world_c.py check        # 复现 20.4 节的数
python3 demos/ch20_open_world_c.py full 100     # 写 assets/ch20-open-world-c
python3 demos/ch20_lit_cycle_world.py      # 文献原型：循环世界，写 assets/ch20-lit-cycle-world
python3 demos/ch20_lit_generate_test.py    # 文献原型：生成与检验，写 assets/ch20-lit-generate-test
python3 demos/crl_ladder_learners.py --exp ch20 --seeds 20 --seed0 100 --steps 2000000 --tag formal   # 四区仓库阶梯，写 assets/crl-ladder-world/runs/formal-ch20.json
python3 demos/crl_ladder_learners.py --exp ch20 --seeds 20 --seed0 100 --steps 5000000 --tag formal5m   # 500 万步的一组，写 assets/crl-ladder-world/runs/formal5m-ch20.json（约 15 分钟）
python3 demos/crl_ladder_figures.py ch20           # 写 assets/crl-ladder-world/fig/ladder-ch20.png
python3 demos/ch20_r21_figs.py             # 写 assets/ch20-r21
```

## 本目录的程序

| 程序 | 说明 | 核验 |
|---|---|---|
| `demos/v19_continual.py` | Bounded calculations for the v19 continual-learning bridge. | 通过（3 秒） |
| `demos/crl_joint_v12.py` | One continuing navigation task, learned skills, GVFs and rate-aware planning. | 通过（61 秒） |
| `demos/crl_v10_derivations.py` | Small exact calculations accompanying chapter 14's v10 derivations. | 通过（8 秒） |
| `demos/ch20_noisy_cue.py` | — | 通过（63 秒） |
| `demos/ch20_noisy_cue_sensitivity.py` | — | 通过（119 秒） |
| `demos/ch20_open_world_c.py` | Chapter 20 open problem, world C: corridor length L, write noise, indicator reversals every M steps. | 通过（88 秒） |
| `demos/ch20_lit_cycle_world.py` | 第 20 章文献原型：Tanner 与 Sutton (2005) TD(lambda) 网络在 6 状态循环世界上的实验 | 通过（142 秒） |
| `demos/ch20_lit_generate_test.py` | 第 20 章文献原型：Mahmood 与 Sutton (2013) 的生成与检验表示搜索（AAAI 2013 Workshop， | 通过（250 秒） |
| `demos/crl_ladder_learners.py` | 四区仓库的学习器阶梯（例子方案第三步）。 | 超时：300 秒内未跑完（启动正常） |
| `demos/crl_ladder_diagnostics.py` | 四区仓库阶梯的诊断与改法（11-20）。 | 通过（4 秒） |
| `demos/ch20_r21_figs.py` | 第 20 章章首风险曲线与「线性—非线性」对照的数与图。 | 通过（3 秒） |
| `demos/crl_ladder_figures.py` | 阶梯世界（四区仓库）阅读稿用图：地图与各章“占天花板”条形。 | 通过（2 秒） |
| `demos/crl_ladder_world.py` | 四区仓库：第三部分的能力阶梯世界（环境与精确参照）。 | 通过（20 秒） |
| `demos/crl_ladder_world_checks.py` | 四区仓库的独立检查（照 v12 的做法：手算、枚举、独立实现互查）。 | 通过（16 秒） |
| `demos/crl_ladder_power.py` | 四区仓库学习器阶梯：试点估 σ_Δ 定种子数，正式跑后出第 24 章的账本。 | 通过（0 秒） |
| `demos/crl_ladder_ceiling.py` | 四区仓库学习器阶梯：每个试验条件的“天花板”，供账本算“离最优还差多少”。 | 超时：300 秒内未跑完（启动正常） |

被上面程序 import 的本课模块：`demos/plot_fonts.py`。

表中后 4 个程序复现附录本章一节没有列出，来自课件、阅读稿、CODE-MAP 或文件名前缀（第三部分另含学习器阶梯）。

## 第三部分的学习器阶梯（例子方案第三步）

四区仓库世界与 L0–L10 阶梯学习器。每章一个实验，三档：没有、设计者给定、从经验学到。比较都是配对的：同一种子下两档用同一份世界随机数。

```sh
python3 demos/crl_ladder_world.py --fast                     # 各区参考线，写 reference.json（全量去掉 --fast）
python3 demos/crl_ladder_world_checks.py                     # 世界本身的核对
python3 demos/crl_ladder_ceiling.py                          # 各条件的天花板（ε-软最好率），写 ceiling.json
python3 demos/crl_ladder_learners.py --exp ch20 --seeds 2 --steps 200000 --procs 2 --tag smoke   # 冒烟：写 assets/crl-ladder-world/runs/smoke-ch20.json
python3 demos/crl_ladder_learners.py --exp ch20 --seeds 20 --seed0 100 --steps 2000000 --tag formal   # 正式设置（种子数与 runs/ 里的正式记录相同）
python3 demos/crl_ladder_power.py ledger --runs formal-ch20     # 配对差与 95% 区间，写 ledger-formal-ch20.json
python3 demos/crl_ladder_figures.py ch20                       # 阅读稿用的地图与条形图（读账本）
python3 demos/crl_ladder_learners.py --exp ch20 --seeds 20 --seed0 100 --steps 5000000 --tag formal5m   # lifetime 500 万步的对照
python3 demos/crl_ladder_power.py ledger --runs formal5m-ch20
# 改进与诊断（README 第九节）：同一套世界随机数，跑完用 --compare 出配对差
python3 demos/crl_ladder_diagnostics.py --arms ch20/flip/opt3e-4 --seeds 2 --steps 200000 --procs 2 --tag smoke   # 冒烟：写 runs/diag-smoke-*.json
python3 demos/crl_ladder_diagnostics.py --arms ch20/flip/opt3e-4 ch20/fixed/opt3e-4 --seeds 20 --procs 3
python3 demos/crl_ladder_diagnostics.py --compare ch20/flip/opt3e-4 ch20/flip/given
python3 demos/crl_ladder_diagnostics.py --arms ch20/flip/opt3e-4 ch20/flip/given --seeds 20 --seed0 200 --tag confirm --procs 3   # 换一批种子确证
python3 demos/crl_ladder_diagnostics.py --compare ch20/flip/opt3e-4 ch20/flip/given --seed-range 200 219
```

参考记录在 `assets/crl-ladder-world/runs/`（随本目录复制）。正式设置一章要跑数十分钟到数小时；冒烟一行只确认程序能走通。正式结果与读法见 `assets/crl-ladder-world/README.md` 第八节，改进与诊断见第九节。

## 复现附录本章一节

本章来自本课程序的结果有：20.3 节截断敏感度的数例，20.4、20.5 节的两张机制图及其数值，20.4 节的仓库实验与敏感性分析，开放问题“世界丙”，循环世界与生成与检验两个文献原型，20.5 节四区仓库上指示灯含义翻转的阶梯实验，以及线性与非线性读出的对照。最后一项中章首的风险曲线按公式精确计算，关系翻转后的恢复是 50 个种子的模拟。

20.3 节的风险表与平衡点 $\psi^\star=.6$、20.4 节三种做法的停点与每趟 $J$（$2.983$、$3.098$、$3.185$）、开放问题中的 $.6^8\approx.017$ 由正文推导直接算出。

| 位置 | 结果 | 设置 | 程序 | 数据与输出 |
|---|---|---|---|---|
| 20.3 节“敏感度的代价”（课件 `ch17-sensitivity-example`） | $\psi=.5$、$c=+1$、$Y=1$ 时 $z_E=.5$、$z_J=.25$、$p=.625$，$\partial\ell/\partial z_J=-.1875$；完整敏感度 1、梯度 $-.1875$；只回传最后一步时敏感度 .5、梯度 $-.09375$ | 本课的计算：D 与 J 之间加一格走廊 E，$z_E=\psi c$、$z_J=\psi^2c$，$c=\pm1$ 两种来路各算一次，读出 $p=(1+z_J)/2$，平方损失；完整导数、截断导数与中心有限差分对照；程序另按步长 .2 更新一次 $\psi$（.5→.5375），现行正文未用；确定性计算 | `demos/v19_continual.py` | `assets/v19-continual/memory-gradient.csv`；`assets/v19-continual/checks.json`；`assets/v19-continual/memory-through-time.png`（现行课件与讲义未用） |
| 20.4 节“共享特征对不同读出的影响” | 只按时长损失走一步，$\psi$ 由 1 到 $1.06$；时长预测 $6.36$，奖励预测 $3.18$，去 $C$ 概率 $.529964$ | 本课的计算：取三站实验记录（种子 0、规划组）中第 40,003 步结束的一次 $A\to C$ 执行，$G=3$、$\tau=7$；单参数局部模型 $6\psi$、$3\psi$、$\operatorname{sig}(2\psi-2)$，步长 $.01$ | `demos/v19_continual.py`；记录由 `demos/crl_joint_v12.py` 产生 | 输入 `assets/crl-joint-v12/one-real-transition.json`；输出 `assets/v19-continual/shared-update-readers.png`、`assets/v19-continual/checks.json` |
| 20.5 节“表示变换与预测头适配” | 两状态预测 $(1,-1)$；只旋转表示、保留旧读出得 $(-1,-1)$；读出同步变换后回到 $(1,-1)$ | 本课的计算：单位特征 $\mathbf x(A),\mathbf x(B)$，读出 $\mathbf w=(1,-1)^\top$，旋转 $90^\circ$；精确计算，无采样 | `demos/crl_v10_derivations.py` | `assets/crl-v10/representation-readout.png`；`assets/crl-v10/results.json`（`checks` 中 `invertible_representation_can_preserve_predictions`） |
| 20.4 节仓库实验（课件 ch20-fixed-vs-learned、ch20-remedies-compared） | 反转前后各 3000 步：固定 $\psi=.6$ 为 2626/1207，固定 $\psi=1$ 为 2818/1132，分开管 2609/2822，小权重 2690/2870，端到端 2787/2758，不写入 1876/1881；6000 步世界不变的对照 5546、5796、5513、5625、5757、3757 | 本课的模拟：有噪指示的仓库，$\kappa$ 在第 3000 步由 .8 变为 .2；REINFORCE 学 $\theta$，各学习器只在 $\psi$ 的学法上不同；每种 300 次独立运行 | `demos/ch20_noisy_cue.py` | `assets/ch20-noisy-cue/ch20_noisy_cue_6000_3000_0.2.json`、`assets/ch20-noisy-cue/ch20_noisy_cue_6000_6000_0.8.json` |
| 20.4 节“两种办法的得失与固定记忆的对照”中的“敏感度”一段 | $a_c$、$a_p$、$\theta_0$ 与小权重 $\lambda$ 改变时的同一组对照 | 同上一行，每种 200 次 | `demos/ch20_noisy_cue_sensitivity.py` | `assets/ch20-noisy-cue/ch20_noisy_cue_sensitivity.json` |
| 开放问题“世界丙” | 小权重减固定 $\psi=1$ 的 $L\times M$ 表（如 $L=1,M=3000$ 为 8838，$L=8$ 不翻为 $-2679$）；缩小步长的补救；两个槽下不替换、按使用度、按回本账的全程回报 | 本课的模拟：走廊长 $L\in\{1,2,4,8\}$，写入噪声 .1，指示可靠度每 $M$ 步在 .8、.2 间翻；30000 步，10 次预试定数，每格 100 次独立运行；回本账的租金 .02、上限 20、反事实功劳乘 3 是本课的设计选择；`check` 在 $L=1$ 时与 20.4 节的数相差不到 40 | `demos/ch20_open_world_c.py` | `assets/ch20-open-world-c/ch20-open-world-c-pilot.json`、`assets/ch20-open-world-c/ch20-open-world-c-results.json` |
| 20.2 节文献原型“循环世界”（课件 ch20-lit-cycle-world） | 达到 RMSE $<.05$ 的步数：$\lambda=1$ 为 6,000，$.75$ 为 14,500，$.5$ 为 75,500；$\lambda=.25$ 在 150 万步内未达（停在约 .25），$\lambda=0$ 在 100 万步内未达（约 .31）；原文图 5 为不到 5,000、约 7,000、约 32,000、约 189,000、失败 | 本课按 Tanner 与 Sutton（ICML 2005）图 3 伪代码重跑：6 状态确定循环、1 个观测位，5 个预测的链式问题网络，输入为观测指示与上一步预测共 7 维，初始权重 $1/7$，上一步预测初值 0；$\alpha\in\{.5,.25,.125,.0625\}$ 取最好；每 500 步平均一点；导数因子按式 (7)，另记伪代码字面读法；世界确定，各 1 次运行 | `demos/ch20_lit_cycle_world.py` | `assets/ch20-lit-cycle-world/results.json` |
| 20.5 节文献原型“生成与检验”（课件 ch20-lit-generate-test） | 最后 1 万个样本的平均 MSE：F:100 为 2.59，F:1K 为 1.86，F:10K 为 1.66，S:100 为 1.76，S:1K 为 1.33（最小可能为 1）；开头 1 万个样本 S:1K 为 2.23、F:1K 为 2.07 | 本课按 Mahmood 与 Sutton（AAAI 2013 Workshop）缩小重跑：20 个二值输入，目标由 20 个随机阈值单元（参数 .6）加 $N(0,1)$ 噪声；学习器阈值单元 $\beta=.6$、$\eta=.1$，每样本替换比例 1/200，按 $|w|$ 检验，成熟门槛 $\mu=100$ 由 S:1K 上 5 万样本 × 5 次的预试从 {20, 100, 500} 选出；每配置 10 次独立运行、各 100 万个样本；原文的 F:100K、F:1M 与 50 次运行未跑 | `demos/ch20_lit_generate_test.py` | `assets/ch20-lit-generate-test/results.json` |
| 20.5 节（课件 `ch20-ladder`） | 灯的含义翻转后，把预测放进状态的学习器能跟上，只放灯本身的跟不上；生成与检验每个种子都挑中灯，比不看灯低 .0024 | 本课的模拟：四区仓库，200 万步，20 个种子；另有 500 万步的一组运行 | `demos/crl_ladder_learners.py` 实验 `ch20`；`demos/crl_ladder_diagnostics.py` | `assets/crl-ladder-world/runs/formal-ch20.json`、`assets/crl-ladder-world/fig/ladder-ch20.png`、`assets/crl-ladder-world/runs/formal5m-ch20.json`；runs/ 下的 diag-ch20_*.json |
| 20.5 节（课件 `ch20-r21-linear-nonlinear-example`） | 一步走廊（读出对参数线性）与两步走廊（非线性）的平方风险对照；关系翻转后约 2400 趟恢复 | 本课的计算与模拟：$\alpha=.2$，每段 2000 趟，50 个种子；章首风险曲线按公式精确计算 | `demos/ch20_r21_figs.py` | `assets/ch20-r21/risk-curves.pdf`、`assets/ch20-r21/linear-nonlinear.pdf` |

运行：
```sh
python3 demos/v19_continual.py        # 读 assets/crl-joint-v12，写 assets/v19-continual
python3 demos/crl_v10_derivations.py  # 写 assets/crl-v10
python3 demos/ch20_noisy_cue.py 6000 3000 0.2   # 写 assets/ch20-noisy-cue
python3 demos/ch20_noisy_cue.py 6000 6000 0.8
python3 demos/ch20_noisy_cue_sensitivity.py
python3 demos/ch20_open_world_c.py check        # 复现 20.4 节的数
python3 demos/ch20_open_world_c.py full 100     # 写 assets/ch20-open-world-c
python3 demos/ch20_lit_cycle_world.py      # 文献原型：循环世界，写 assets/ch20-lit-cycle-world
python3 demos/ch20_lit_generate_test.py    # 文献原型：生成与检验，写 assets/ch20-lit-generate-test
python3 demos/crl_ladder_learners.py --exp ch20 --seeds 20 --seed0 100 --steps 2000000 --tag formal   # 四区仓库阶梯，写 assets/crl-ladder-world/runs/formal-ch20.json
python3 demos/crl_ladder_learners.py --exp ch20 --seeds 20 --seed0 100 --steps 5000000 --tag formal5m   # 500 万步的一组，写 assets/crl-ladder-world/runs/formal5m-ch20.json（约 15 分钟）
python3 demos/crl_ladder_figures.py ch20           # 写 assets/crl-ladder-world/fig/ladder-ch20.png
python3 demos/ch20_r21_figs.py             # 写 assets/ch20-r21
```

## 参考数据

`assets/`（以及 `demos/NN-results/`）下复制了 157 个数据文件（json、csv 等），即课程目前使用的结果；图片没有复制，运行程序会重新画出。重跑会覆盖这些文件，可以先另存一份再对照。
