# -*- coding: utf-8 -*-
"""第 20 章文献原型：Mahmood 与 Sutton (2013) 的生成与检验表示搜索（AAAI 2013 Workshop，
"Representation Search through Generate and Test"，图 2、图 3 的缩小重跑）。

数据流（原文 "Experiments and Results"）：每个样本 20 个二值输入，各以 1/2 取 1；
目标 y = sum_i w*_i f*_i + eps，f* 是 20 个固定随机线性阈值单元（LTU，阈值参数 .6），
w*_i ~ N(0,1) 每次运行抽一次，eps ~ N(0,1)。学到真特征与真权重时 MSE 最小为 1。

学习器（原文 "Effectiveness of Search"）：n 个 LTU 特征，输入权重取 +-1，
阈值 theta_i = beta*m - S_i（S_i 是负权重个数），只在至少 beta 比例的输入位与原型一致时取 1；
另加一个恒为 1 的偏置。输出权重用 LMS 学，步长 alpha_k = eta / lambda_k，
lambda_k 是 ||f||^2 的递增估计，eta = .1（原文）。
搜索（原文第一种检验器）：按输出权重绝对值估用处；每个样本在“年龄”不小于 mu 的特征里
换掉比例 rho = 1/200 的最小者；新特征输入权重随机取 +-1，输出权重为 0，年龄归零。

本课的选择（原文写“粗调”或没写的）：学习器的 beta 取 .6；lambda_k 用步长 .01 的指数平均；
成熟门槛 mu 先在 S:1K 上做小规模预试，从 {20, 100, 500} 里取最好的。

缩小：原文图 3 跑 100 万个样本、50 次运行，固定表示最大到 100 万个特征；
本课只比较 F:100、F:1K、F:10K 与 S:100、S:1K，样本数与运行次数见 results.json。
评价：最后 1 万个样本上的 delta^2 平均（原文图 3 的做法），另记每 1 万个样本的分段平均。

只用 numpy。用法：
    python3 demos/ch20_lit_generate_test.py [样本数，默认 1000000] [运行次数，默认 10]
输出写 assets/ch20-lit-generate-test/results.json。
"""
import json, os, sys, time
from multiprocessing import Pool
import numpy as np
np.seterr(all='ignore')   # macOS 的 BLAS 在 float32 matmul 上会误报浮点异常；输入是 0/1 与 +-1，结果是小整数

M, N_TARGET, BETA_T, BETA, ETA, RHO = 20, 20, .6, .6, .1, 1. / 200
WINDOW = 10_000


def ltu(rng, shape_runs, n):
    V = np.where(rng.random((shape_runs, n, M)) < .5, -1., 1.).astype(np.float32)
    return V


def thresh(V, beta):
    S = (V < 0).sum(axis=2)
    return (beta * M - S).astype(np.float32)


def run(args):
    n, search, mu, T, R, seed = args
    rng = np.random.default_rng(seed)
    Vt = ltu(rng, R, N_TARGET); tht = thresh(Vt, BETA_T)
    wt = rng.standard_normal((R, N_TARGET)).astype(np.float32)
    V = ltu(rng, R, n); th = thresh(V, BETA)
    w = np.zeros((R, n + 1), np.float32)
    age = np.zeros((R, n), np.int64)
    lam = None
    acc = 0.
    sq = np.zeros(R)
    curve = []
    rows = np.arange(R)[:, None]
    CH = 1000
    for c0 in range(0, T, CH):
        X = (rng.random((CH, R, M)) < .5).astype(np.float32)
        E = rng.standard_normal((CH, R)).astype(np.float32)
        for c in range(CH):
            x = X[c]
            fs = (np.einsum('rnm,rm->rn', Vt, x) > tht).astype(np.float32)
            y = (wt * fs).sum(1) + E[c]
            f = np.empty((R, n + 1), np.float32)
            f[:, 0] = 1.
            f[:, 1:] = (np.matmul(V, x[:, :, None])[:, :, 0] > th)
            yh = (w * f).sum(1)
            d = y - yh
            nf = f.sum(1)                      # 二值特征，||f||^2 = 激活个数
            lam = nf.copy() if lam is None else lam + .01 * (nf - lam)
            w += (ETA / lam * d)[:, None] * f
            sq += d.astype(np.float64) ** 2
            t = c0 + c + 1
            if t % WINDOW == 0:
                curve.append((sq / WINDOW).tolist()); sq[:] = 0.
            if search:
                age += 1
                acc += RHO * n
                k = int(acc)
                if k > 0:
                    acc -= k
                    score = np.abs(w[:, 1:]).astype(np.float64)
                    score[age < mu] = np.inf
                    idx = np.argpartition(score, k - 1, axis=1)[:, :k]
                    ok = np.isfinite(score[rows, idx])
                    rr, ii = np.broadcast_to(rows, idx.shape)[ok], idx[ok]
                    if rr.size:
                        newv = np.where(rng.random((rr.size, M)) < .5, -1., 1.).astype(np.float32)
                        V[rr, ii] = newv
                        th[rr, ii] = BETA * M - (newv < 0).sum(1)
                        w[rr, ii + 1] = 0.
                        age[rr, ii] = 0
    curve = np.array(curve)                    # (窗口数, R)
    return {"n": n, "search": search, "mu": mu, "T": T, "runs": R,
            "final_mse_mean": float(curve[-1].mean()),
            "final_per_run": [float(v) for v in curve[-1]],
            "curve_mean": [round(float(v), 4) for v in curve.mean(1)]}


def main():
    T = int(sys.argv[1]) if len(sys.argv) > 1 else 1_000_000
    R = int(sys.argv[2]) if len(sys.argv) > 2 else 10
    t0 = time.time()
    # 预试：在 S:1K 上选成熟门槛 mu（较短的流、较少的运行，种子与正式运行分开）
    pilot_T, pilot_R = 50_000, 5
    with Pool(3) as pool:
        pil = pool.map(run, [(1000, True, mu, pilot_T, pilot_R, 900 + i) for i, mu in enumerate([20, 100, 500])])
    mu_best = min(pil, key=lambda r: r["final_mse_mean"])["mu"]
    t1 = time.time()
    cfgs = [(100, False), (1000, False), (10000, False), (100, True), (1000, True)]
    jobs = []
    for j, (n, s) in enumerate(cfgs):
        # 每个配置把 R 次运行拆成若干块并行；同一块内批量计算
        blk = 2 if n == 10000 else 5
        for b in range(0, R, blk):
            jobs.append((n, s, mu_best, T, min(blk, R - b), 1000 * j + b))
    with Pool(min(len(jobs), os.cpu_count() or 4)) as pool:
        parts = pool.map(run, jobs)
    res = []
    for n, s in cfgs:
        ps = [p for p in parts if p["n"] == n and p["search"] == s]
        # 合并各块：按运行次数加权
        Rtot = sum(p["runs"] for p in ps)
        curve = np.sum([np.array(p["curve_mean"]) * p["runs"] for p in ps], axis=0) / Rtot
        finals = np.array(sum((p["final_per_run"] for p in ps), []))
        mean = float(finals.mean())
        se = float(finals.std(ddof=1) / np.sqrt(len(finals))) if len(finals) > 1 else None
        res.append({"name": ("S:" if s else "F:") + (f"{n // 1000}K" if n >= 1000 else str(n)),
                    "n": n, "search": s, "runs": Rtot, "final_mse_mean": round(mean, 4),
                    "final_mse_se": None if se is None else round(se, 4),
                    "curve_window": WINDOW, "curve_mean": [round(float(v), 4) for v in curve]})
    out = {"source": "Mahmood & Sutton, AAAI 2013 Workshop, Fig. 2-3",
           "setting": {"inputs": M, "target_ltus": N_TARGET, "target_beta": BETA_T, "learner_beta": BETA,
                       "eta": ETA, "rho": RHO, "mu": mu_best, "examples": T, "runs": R,
                       "final_metric": "mean of delta^2 over last 10000 examples, averaged over runs",
                       "min_possible_mse": 1.0},
           "pilot": [{"mu": p["mu"], "T": pilot_T, "runs": pilot_R, "final_mse_mean": round(p["final_mse_mean"], 4)} for p in pil],
           "results": res,
           "paper": {"fig2": "F:1M only slightly better than F:100K (100k examples, 50 runs)",
                     "fig3": "S:1K beats F:1M over 1M examples (50 runs); S:100 beats F:100 early and keeps improving"},
           "seconds": {"pilot": round(t1 - t0, 1), "main": round(time.time() - t1, 1)}}
    here = os.path.dirname(os.path.abspath(__file__))
    od = os.path.join(here, "..", "assets", "ch20-lit-generate-test")
    os.makedirs(od, exist_ok=True)
    with open(os.path.join(od, "results.json"), "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=1)
    print("mu", mu_best, out["pilot"])
    for r in res:
        print(r["name"], r["final_mse_mean"], r["curve_mean"][::max(1, len(r["curve_mean"]) // 6)])
    print(out["seconds"])


if __name__ == "__main__":
    main()
