#!/usr/bin/env python3
"""Bounded calculations for the v19 continual-learning bridge.

No new joint-agent training. Reanalyse preserved v12 transitions/snapshots,
then check two small differentiable examples independently by finite
differences. Exact environment equations are evaluator-only references.
"""
from pathlib import Path
import argparse
import csv
import hashlib
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties, fontManager

ROOT = Path(__file__).resolve().parents[1]
for path in ['/System/Library/Fonts/PingFang.ttc', '/System/Library/Fonts/STHeiti Medium.ttc']:
    if Path(path).exists():
        fontManager.addfont(path)
        plt.rcParams['font.family'] = FontProperties(fname=path).get_name()
        break
plt.rcParams.update({'font.size': 18, 'axes.spines.top': False,
                     'axes.spines.right': False, 'axes.unicode_minus': False})
TEAL, RED, GOLD, GREY = '#087E8B', '#C65335', '#C4942A', '#61757D'


def run(out):
    out.mkdir(parents=True, exist_ok=True)
    old = ROOT / 'assets/crl-joint-v12'
    checks, source_hashes = [], {}

    def check(name, ok, **details):
        assert bool(ok), (name, details)
        checks.append(dict(name=name, passed=True, **details))

    def preserve(path):
        source_hashes[str(path.relative_to(ROOT))] = hashlib.sha256(path.read_bytes()).hexdigest()

    def save(fig, name):
        fig.savefig(out / f'{name}.pdf', bbox_inches='tight')
        fig.savefig(out / f'{name}.png', bbox_inches='tight', dpi=180)
        plt.close(fig)

    def save_csv(name, rows):
        with (out / name).open('w', newline='') as stream:
            writer = csv.DictWriter(stream, fieldnames=rows[0])
            writer.writeheader()
            writer.writerows(rows)

    # All rewards count, including initial learning and post-change adaptation.
    curve_path = old / 'learning-curves.csv'
    preserve(curve_path)
    curve = list(csv.DictReader(curve_path.open()))
    times = np.arange(3000, 120001, 3000)
    cumulative, rates, lifetime_rows = {}, {}, []
    for condition in ['no_planning', 'frozen']:
        totals, current = [], []
        for seed in range(8):
            path = old / f'raw-{condition}-seed{seed}.npz'
            preserve(path)
            with np.load(path) as raw:
                reward = raw['transitions'][:, 6]
                total = np.cumsum(reward)[times - 1]
            selected = sorted([r for r in curve if r['condition'] == condition and int(r['seed']) == seed], key=lambda r: int(r['t']))
            reported = np.array([float(r['lifetime_rate']) * int(r['t']) for r in selected])
            check(f'raw_reward_matches_reported_lifetime_{condition}_{seed}', np.allclose(total, reported, atol=1e-7, rtol=0), max_error=float(abs(total-reported).max()))
            totals.append(total)
            current.append([float(r['exact_current_policy_rate']) for r in selected])
        cumulative[condition] = np.asarray(totals)
        rates[condition] = np.asarray(current)
        for k, t in enumerate(times):
            lifetime_rows.append(dict(condition=condition, t=int(t), total_reward=float(cumulative[condition][:, k].mean()), lifetime_rate=float(cumulative[condition][:, k].mean()/t), frozen_policy_rate=float(rates[condition][:, k].mean())))
    save_csv('lifetime-evaluation.csv', lifetime_rows)
    fig, axes = plt.subplots(1, 2, figsize=(12.2, 3.2), layout='constrained')
    for cond, label, color in [('no_planning', '持续更新', TEAL), ('frozen', '6万步后冻结', RED)]:
        ys = cumulative[cond] / 1000
        mean, se = ys.mean(0), ys.std(0, ddof=1)/np.sqrt(8)
        axes[0].plot(times/1000, mean, c=color, label=label, lw=2)
        axes[0].fill_between(times/1000, mean-se, mean+se, color=color, alpha=.15)
    axes[0].axvline(60, color=GREY, ls=':', lw=1.5)
    axes[0].set(xlabel='真实原子步（千）', ylabel='累计奖励（千）', xticks=[0, 60, 120])
    axes[0].legend(loc='upper left', fontsize=15)
    labels = ['持续更新', '6万步后冻结']
    for i, cond in enumerate(['no_planning', 'frozen']):
        values = [cumulative[cond][:, -1].mean()/120000, rates[cond][:, -1].mean()]
        axes[1].bar(np.array([0, 1])+i*3, values, color=[TEAL, GOLD], width=.7)
        for x, v in zip(np.array([0, 1])+i*3, values):
            axes[1].text(x, v+.008, f'{v:.3f}', ha='center', fontsize=16)
    axes[1].set(xticks=[.5, 3.5], xticklabels=labels, ylabel='奖励 / 原子步', ylim=(0, .31))
    axes[1].plot([], [], c=TEAL, lw=8, label='全程平均')
    axes[1].plot([], [], c=GOLD, lw=8, label='末次策略的稳态率')
    axes[1].legend(loc='upper center', ncol=2, fontsize=14)
    for ax in axes: ax.grid(axis='y', alpha=.15)
    save(fig, 'lifetime-versus-policy')

    # A cue held across two no-arrival transitions: scalar recurrent memory.
    # x=+1 means last station B; x=-1 means last station A. A later forced
    # arrival at A gives target 1 or 0. This is a fixed-data local calculation.
    psi, step = .5, .2
    cue_rows = []
    for cue in [-1., 1.]:
        z = [cue, psi*cue, psi**2*cue]
        y = (1+cue)/2
        prediction = (1+z[-1])/2
        D = [0., cue, 2*psi*cue]
        grad = (prediction-y)*.5*D[-1]
        loss = lambda p: .5*((1+p*p*cue)/2-y)**2
        eps = 1e-6
        fd = (loss(psi+eps)-loss(psi-eps))/(2*eps)
        check(f'cue_recurrent_derivative_{int(cue)}', np.isclose(grad, fd, atol=1e-10), analytic=grad, finite_difference=fd)
        new = psi-step*grad
        check(f'cue_update_improves_prediction_{int(cue)}', loss(new)<loss(psi) and 0<new<1, psi_new=new, loss_before=loss(psi), loss_after=loss(new))
        truncated = (prediction-y)*.5*z[1]
        check(f'truncation_drops_first_memory_path_{int(cue)}', np.isclose(truncated, grad/2), full=grad, last_step_only=truncated)
        cue_rows.append(dict(last_station='A' if cue<0 else 'B', cue=cue, z1=z[1], z2=z[2], target=y, prediction=prediction, full_gradient=grad, truncated_gradient=truncated, psi_new=new))
    save_csv('memory-gradient.csv', cue_rows)
    fig, ax = plt.subplots(figsize=(11.8, 2.6), layout='constrained')
    for cue, color, label in [(1, TEAL, '上次到站 B；下次到 A 得 1'), (-1, RED, '上次到站 A；下次到 A 得 0')]:
        z = cue*psi**np.arange(3)
        ax.plot(range(3), z, '-o', c=color, lw=2.5, ms=8, label=label)
        for t, value in enumerate(z): ax.annotate(f'{value:g}', (t, value), xytext=(10, 5 if cue>0 else -18), textcoords='offset points', color=color, fontsize=18)
    ax.axhline(0, color=GREY, lw=1)
    ax.set(xticks=[0, 1, 2], xticklabels=['保存到站线索', '无到站事件：乘 ψ', '再乘 ψ；用于预测'], yticks=[-1, 0, 1], ylabel='记忆坐标 z', xlim=(-.15, 2.35), ylim=(-1.35, 1.7))
    ax.legend(loc='upper center', ncol=2, fontsize=15)
    save(fig, 'memory-through-time')

    # Real sample from the retained seven-step A->C option. Heads/logit below
    # are a constructed one-parameter example, not the original tabular agent.
    event_path = old / 'one-real-transition.json'
    preserve(event_path)
    event = json.loads(event_path.read_text())[0]
    check('shared_example_targets_are_recorded_option_outcome', event['G']==3 and event['tau']==7)
    T_target, R_target = event['tau'], event['G']
    loss_T = lambda p: .5*(6*p-T_target)**2
    grad = (6-T_target)*6
    fd = (loss_T(1+1e-6)-loss_T(1-1e-6))/(2e-6)
    check('shared_encoder_gradient_finite_difference', np.isclose(grad, fd, atol=1e-8), analytic=grad, finite_difference=fd)
    new_psi = 1-.01*grad
    sigmoid = lambda x: 1/(1+np.exp(-x))
    check('time_update_changes_untrained_readers', loss_T(new_psi)<loss_T(1) and (3*new_psi-R_target)**2>0 and sigmoid(2*new_psi-2)>.5, psi_old=1, psi_new=new_psi, time_new=6*new_psi, reward_new=3*new_psi, probability_new=float(sigmoid(2*new_psi-2)))
    score_B = .2-.2*3
    scores_C = [3-.2*t for t in [20,7]]
    check('duration_reader_changes_greedy_goal', scores_C[0]<score_B<scores_C[1] and np.isclose(scores_C[1]-scores_C[0],.2*(20-7)), B=score_B, C=scores_C)
    pgrid = np.linspace(.9, 1.18, 100)
    fig, axes = plt.subplots(1, 3, figsize=(12, 2.9), layout='constrained')
    for ax, values, target, title, old_value, new_value in [
        (axes[0], 6*pgrid, 7, '时长头：6ψ', 6, 6*new_psi),
        (axes[1], 3*pgrid, 3, '奖励头：3ψ', 3, 3*new_psi),
        (axes[2], sigmoid(2*pgrid-2), None, '去 C 概率：σ(2ψ−2)', .5, float(sigmoid(2*new_psi-2)))]:
        ax.plot(pgrid, values, c=GREY, lw=1.8)
        if target is not None: ax.axhline(target, c=GOLD, ls='--', lw=1.5)
        ax.plot([1, new_psi], [old_value, new_value], 'o', c=TEAL, ms=7)
        ax.annotate('', (new_psi, new_value), (1, old_value), arrowprops=dict(arrowstyle='->', color=TEAL, lw=2.2))
        ax.set(xlabel='共享表示参数 ψ', title=title, xticks=[1, new_psi], xticklabels=['1', '1.06'])
        ax.grid(alpha=.16)
    save(fig, 'shared-update-readers')

    # Evaluate fixed low-level policy snapshots in the same stationary world.
    # Duration needs only position, so solve a 7-state absorbing chain, then
    # independently sum survival probabilities by repeated first-step updates.
    path = old / 'raw-planning-seed0.npz'
    preserve(path)
    raw = np.load(path)
    coords = [(-2,0),(-1,0),(0,0),(0,1),(1,0),(2,0),(3,0),(4,0)]
    index = {xy:i for i,xy in enumerate(coords)}
    moves = [(1,0),(0,1),(-1,0),(0,-1)]
    physical_next = np.array([[index.get((x+dx,y+dy),i) for dx,dy in moves] for i,(x,y) in enumerate(coords)])
    # Independently verify that the two fixed cue histories are possible in
    # the actual corridor graph and yield the stated later A-arrival rewards.
    last_stations=[]
    for initial, actions in [(0,[0,0,2,2]),(3,[0,3,2,2])]:
        pos=last=initial
        positions=[pos]
        payouts=[]
        for action in actions:
            pos=int(physical_next[pos,action])
            next_last=pos if pos in [0,3,7] else last
            payout={0:1.,3:.2,7:3.}[next_last] if next_last!=last else 0.
            last=next_last;positions.append(pos);payouts.append(payout)
        last_stations.append(dict(positions=positions,payouts=payouts))
    check('memory_histories_reach_same_junction_different_A_reward', [r['positions'][2] for r in last_stations]==[2,2] and [r['payouts'][-1] for r in last_stations]==[0,1], histories=last_stations)
    route = np.array([0,1,2,4,5,6])
    labels = ['A','a','路口','c1','c2','c3']
    true_times, policies, skill_rows = [], [], []
    for snapshot in [0,1]:
        q = raw['skill'][snapshot,2]
        best = (q == q.max(1, keepdims=True))
        commanded = .06/4+.94*best/best.sum(1, keepdims=True)
        executed = .9*commanded+.1/4
        P = np.zeros((7,7))
        for s in range(7):
            for action, probability in enumerate(executed[s]):
                nxt = physical_next[s,action]
                if nxt != 7: P[s,nxt] += probability
        T = np.linalg.solve(np.eye(7)-P, np.ones(7))
        # Geometric summation by doubling avoids millions of individual terms
        # when the early policy rarely passes a bottleneck. After each step,
        # iterative=sum(P**k @ 1, k=0..n-1), power=P**n.
        iterative, power, n_terms = np.ones(7), P.copy(), 1
        for iteration in range(40):
            iterative = iterative+power@iterative
            power = power@power
            n_terms *= 2
            if np.max(abs(power@T))<1e-9: break
        check(f'absorbing_time_independent_survival_sum_{snapshot}', np.allclose(T,iterative,atol=1e-8,rtol=1e-10), error=float(np.max(abs(T-iterative))), terms=n_terms)
        check(f'policy_and_bellman_residual_{snapshot}', np.allclose(executed.sum(1),1) and np.max(abs(T-(1+P@T)))<1e-8)
        true_times.append(T)
        policies.append(commanded)
        for state in route:
            skill_rows.append(dict(snapshot_t=int(raw['snapshots_t'][snapshot]), position=int(state), expected_steps=float(T[state]), predicted_steps=float(raw['gvf_T'][snapshot,2,state,0]), east_probability=float(commanded[state,0])))
    check('stationary_world_skill_improves_C_duration', true_times[1][0]<true_times[0][0], early=float(true_times[0][0]), later=float(true_times[1][0]))
    save_csv('skill-changes-prediction-target.csv', skill_rows)
    fig, axes = plt.subplots(1,2,figsize=(12.2,3.1),layout='constrained')
    for k,color,label in [(0,GREY,'第100步'),(1,TEAL,'第12,000步')]:
        axes[0].plot(range(6),true_times[k][route],'-o',c=color,lw=2,label=label)
        axes[1].plot(range(6),policies[k][route,0],'-o',c=color,lw=2,label=label)
    axes[0].set(ylabel='冻结此刻技能：到 C 期望步数', yscale='log', yticks=[1,10,100,1000,10000], yticklabels=['1','10','100','1千','1万'])
    axes[1].set(ylabel='去 C 技能选择“东”的概率', ylim=(0,1.08), yticks=[0,.5,1])
    for ax in axes:
        ax.set(xticks=range(6), xticklabels=labels, xlabel='沿 A 到 C 路线的当前位置')
        ax.grid(alpha=.16)
    axes[0].legend(fontsize=15)
    save(fig, 'skill-changes-target')

    for relative, expected in source_hashes.items():
        assert hashlib.sha256((ROOT/relative).read_bytes()).hexdigest()==expected
    check('preserved_sources_unchanged', True, source_files=len(source_hashes))
    result = dict(validation_layer='finite calculations and preserved-data reanalysis; no new joint training', checks=checks, source_sha256=source_hashes, memory_example=cue_rows, shared_example=dict(psi_new=new_psi,time_new=6*new_psi,reward_new=3*new_psi,policy_new=float(sigmoid(2*new_psi-2))), final_evaluation=[r for r in lifetime_rows if r['t']==120000], skill_duration=dict(early=float(true_times[0][0]),later=float(true_times[1][0])))
    (out/'checks.json').write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n')
    print(json.dumps(dict(passed=len(checks), skill_duration=result['skill_duration'], final_evaluation=result['final_evaluation']),ensure_ascii=False,indent=2))


if __name__ == '__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--out',type=Path,default=ROOT/'assets/v19-continual')
    args=parser.parse_args()
    run(args.out)
