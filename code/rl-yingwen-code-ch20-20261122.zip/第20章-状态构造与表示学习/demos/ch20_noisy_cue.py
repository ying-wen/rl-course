# -*- coding: utf-8 -*-
# Noisy-indicator warehouse (ch18/ch20 world). Trip: D -> J -> B (+4)  or  D -> J -> W -> C(+1) -> B, then B -> D.
# Correct trip 3 steps, detour 5 steps.  Indicator c=+-1 points to the B side with prob kappa.
# Agent state: z_D = c (write), z_J = psi*c.  Policy pi(L|z)=sig(theta z).  Prediction readout p=(1+z)/2 for Y=1{left side is B}.
# Learners differ in how psi is trained; theta always by REINFORCE with a running-mean baseline.
import numpy as np, sys, json
def sig(x): return 1/(1+np.exp(-x))
def run(mode, T, change, kap0, kap1, rng, psi0=.5, th0=0., a_p=.1, a_c=.05, a_b=.05, lam=.1, write=True):
    psi=psi0; th=th0; b=2.5
    rew=np.zeros(T); psis=np.zeros(T); ths=np.zeros(T); t=0
    while t<T:
        kap = kap0 if t<change else kap1
        s = 1 if rng.random()<.5 else -1          # +1: left side leads to B
        c = s if rng.random()<kap else -s
        zD = c if write else 0.
        z = psi*zD
        pL = sig(th*z)
        a = 1 if rng.random()<pL else -1
        Y = 1. if s==1 else 0.
        if a==s: seq=[0.,4.,0.]
        else:    seq=[0.,0.,1.,0.,0.]
        G=sum(seq)
        for r in seq:
            if t<T: rew[t]=r; psis[t]=psi; ths[t]=th
            t+=1
        # gradients
        p=(1+z)/2
        dz = zD                                 # dz_J/dpsi
        gp = (p-Y)*.5*dz                        # d/dpsi of 1/2 (p-Y)^2
        ind = 1. if a==1 else 0.
        score_psi = (ind-pL)*th*dz
        score_th  = (ind-pL)*z
        adv = G-b
        th += a_c*adv*score_th
        if mode=='fixed': pass
        elif mode=='pred': psi -= a_p*gp
        elif mode=='ctrl': psi += a_c*adv*score_psi
        elif mode=='mix':  psi -= a_p*(gp - lam*adv*score_psi)
        psi=min(1.,max(-1.,psi))
        b += a_b*(G-b)
    return rew, psis, ths
def risk(psi,kap,write=True):
    # E(p-Y)^2 with p=(1+psi c)/2 ; without the write step p=1/2 always
    if not write: return .25
    return kap*(1-kap)+((1+psi)/2-kap)**2
CFGS=[('fixed .6',dict(mode='fixed',psi0=.6)),('fixed 1',dict(mode='fixed',psi0=1.)),
      ('pred',dict(mode='pred')),('ctrl',dict(mode='ctrl')),('mix .1',dict(mode='mix',lam=.1)),
      ('nowrite',dict(mode='fixed',write=False))]
def experiment(T=6000,change=3000,kap1=.2,R=300,seed=12345,extra=None,cfgs=CFGS,verbose=True):
    out={}; W=100
    for name,kw in cfgs:
        kw=dict(kw); kw.update(extra or {})
        rng=np.random.default_rng(seed)
        res=[run(T=T,change=change,kap0=.8,kap1=kap1,rng=rng,**kw) for j in range(R)]
        M=np.array([r[0] for r in res]); P=np.array([r[1] for r in res]); TH=np.array([r[2] for r in res])
        wr=kw.get('write',True)
        pre=M[:,:change].sum(1); post=M[:,change:].sum(1); tot=M.sum(1)
        ma=np.convolve(M.mean(0),np.ones(W)/W,mode='valid')   # ma[k] = mean of steps k..k+W-1
        curve=[round(float(ma[i-W]),3) for i in range(W,T+1,100)]
        psi_mean=[round(float(P[:,i-1].mean()),3) for i in range(100,T+1,100)]
        th_mean=[round(float(TH[:,i-1].mean()),2) for i in range(100,T+1,100)]
        rec=[i+W for i in range(change,len(ma)) if ma[i]>=.9]
        r_pre=float(np.mean([risk(x,.8,wr) for x in P[:,change-1]]))
        r_post=float(np.mean([risk(x,kap1,wr) for x in P[:,T-1]]))
        d=dict(pre=float(pre.mean()),pre_se=float(pre.std()/np.sqrt(R)),post=float(post.mean()),post_se=float(post.std()/np.sqrt(R)),
               tot=float(tot.mean()),tot_se=float(tot.std()/np.sqrt(R)),curve=curve,psi=psi_mean,theta=th_mean,
               risk_pre=r_pre,risk_post=r_post,psi_pre=float(P[:,change-1].mean()),psi_end=float(P[:,T-1].mean()),
               recover90=(rec[0]-change) if rec else None,
               plateau_pre=float(M[:,change-500:change].mean()),plateau_end=float(M[:,T-500:].mean()))
        out[name]=d
        if verbose:
            print('%-9s pre %.0f(%.1f) post %.0f(%.1f) tot %.0f(%.1f) psi@chg %.3f psi@end %.3f risk pre %.4f post %.4f rec90 %s plat %.3f/%.3f th@chg %.2f'%(
                name,d['pre'],d['pre_se'],d['post'],d['post_se'],d['tot'],d['tot_se'],d['psi_pre'],d['psi_end'],r_pre,r_post,d['recover90'],d['plateau_pre'],d['plateau_end'],TH[:,change-1].mean()))
    return out
if __name__=='__main__':
    T=int(sys.argv[1]) if len(sys.argv)>1 else 6000
    change=int(sys.argv[2]) if len(sys.argv)>2 else 3000
    kap1=float(sys.argv[3]) if len(sys.argv)>3 else .2
    out=experiment(T,change,kap1)
    json.dump(out,open(str(__import__('pathlib').Path(__file__).resolve().parent.parent/'assets'/'ch20-noisy-cue'/('ch20_noisy_cue_%d_%d_%s.json'%(T,change,kap1))),'w'),indent=1)
