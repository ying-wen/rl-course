# -*- coding: utf-8 -*-
"""第 20 章文献原型：Tanner 与 Sutton (2005) TD(lambda) 网络在 6 状态循环世界上的实验
（ICML 2005，pp. 888-895，图 3 的伪代码、图 4 的环境、图 5 的学习曲线）。

环境：6 个状态按确定的次序循环，没有动作；只有一个观测比特，只在一个状态为 1。
问题网络：5 个预测排成一条链。y1 预报下一步的观测，y_k (k=2..5) 预报 y_{k-1}
下一步的值；展开后 y_k 预报 k 步之后的观测。
回答网络：y_t = sig(W x_t)，x_t 由当前观测的指示（2 维，本世界没有动作）与
上一步的 5 个预测拼成，共 7 维。初始权重全为 1/|x| = 1/7（原文 §4）。
从观测为 1 的状态开始。上一步预测的初值取 0（原文未写，本课的选择）。

学习：照原文图 3 的伪代码。每个预测 (i, k) 留一条迹，直到它展开到观测为止；
第 t-k 个目标到达时，按 alpha (z - p) D x_k lambda^(t-k-1) 更新 W 的第 i 行，
其中 z 是新目标、p 是上一个目标（第一次时就是 y_k^i 本身）。
这些增量逐项相加，等于把 y_k^i 推向式 (6) 的加权目标。
导数因子 D 有两种写法，本程序都跑：
  "eq7"：D = y_k^i (1 - y_k^i)，与原文式 (7) 一致（主结果）；
  "fig3"：D = p (1 - p)，照抄伪代码的字面写法（p 是上一个目标）。

评价：每个节点的真值是展开后的观测 o_{t+i}（世界确定，可直接算）；
每步取 5 个节点平方误差均值的平方根（RMSE），每 500 步平均成一个点（原文图 5 的做法）。
记录首次低于 .05 的步数。步长在原文的 {.5, .25, .125, .0625} 中取最好的。
世界是确定的，原文图 5 是单次运行，本程序也各跑一次。

只用 Python 标准库与 numpy。用法：
    python3 demos/ch20_lit_cycle_world.py
输出写 assets/ch20-lit-cycle-world/results.json。
"""
import json, math, os, time
from multiprocessing import Pool

N_STATES, N_NODES = 6, 5
ALPHAS = [.5, .25, .125, .0625]
LAMBDAS = [0., .25, .5, .75, 1.]
BLOCK = 500
THRESH = .05
MAX_STEPS = {0.: 1_000_000, .25: 1_500_000, .5: 300_000, .75: 300_000, 1.: 300_000}
DERIVS = ["eq7", "fig3"]


def sig(s):
    if s >= 0:
        return 1. / (1. + math.exp(-s))
    e = math.exp(s)
    return e / (1. + e)


def obs(state):
    return 1. if state == 0 else 0.


def run(args):
    lam, alpha, deriv = args
    T = MAX_STEPS[lam]
    m = 2 + N_NODES
    W = [[1. / m] * m for _ in range(N_NODES)]      # 第 i 行 (0 起) 是节点 i+1
    y_prev = [0.] * N_NODES
    xs, ys = {}, {}                                   # 时刻 -> 输入向量、预测
    traces = []                                       # (节点 i, 1 起; 生成时刻 k)
    state = 0
    curve, block_sum, first_hit = [], 0., None
    lam_pow = [lam ** j for j in range(N_NODES + 1)]
    for t in range(T):
        o = obs(state)
        x = [1. - o, o] + y_prev
        y = [sig(sum(W[i][j] * x[j] for j in range(m))) for i in range(N_NODES)]
        xs[t], ys[t] = x, y
        new_traces = []
        for (i, k) in traces:
            d = t - k                                 # 这是第 d 个目标
            c = i - d                                 # 目标指向的节点；0 表示观测
            z = o if c == 0 else y[c - 1]
            p = y_prev[c]                             # 上一个目标（节点 c+1 在 t-1 的预测）
            D = ys[k][i - 1] * (1. - ys[k][i - 1]) if deriv == "eq7" else p * (1. - p)
            g = alpha * (z - p) * D * lam_pow[d - 1]
            if g != 0.:
                xk, Wi = xs[k], W[i - 1]
                for j in range(m):
                    Wi[j] += g * xk[j]
            if c != 0:
                new_traces.append((i, k))
        for i in range(1, N_NODES + 1):
            new_traces.append((i, t))
        traces = new_traces
        xs.pop(t - N_NODES - 1, None)
        ys.pop(t - N_NODES - 1, None)
        # 评价：节点 i 的真值是 i 步后的观测
        se = 0.
        for i in range(1, N_NODES + 1):
            se += (y[i - 1] - obs((state + i) % N_STATES)) ** 2
        block_sum += math.sqrt(se / N_NODES)
        if (t + 1) % BLOCK == 0:
            r = block_sum / BLOCK
            curve.append(r)
            block_sum = 0.
            if first_hit is None and r < THRESH:
                first_hit = t + 1
        y_prev = y
        state = (state + 1) % N_STATES
    return {"deriv": deriv, "lambda": lam, "alpha": alpha, "steps": T, "first_below_05": first_hit,
            "final_rmse": curve[-1], "min_rmse": min(curve), "curve_block": BLOCK,
            "curve": [round(v, 5) for v in curve]}


def main():
    t0 = time.time()
    jobs = [(lam, a, d) for d in DERIVS for lam in LAMBDAS for a in ALPHAS]
    jobs.sort(key=lambda j: -MAX_STEPS[j[0]])         # 长的先跑
    with Pool(min(len(jobs), os.cpu_count() or 4)) as pool:
        res = pool.map(run, jobs)
    best = {}
    for d in DERIVS:
        best[d] = {}
        for lam in LAMBDAS:
            rs = [r for r in res if r["lambda"] == lam and r["deriv"] == d]
            hit = [r for r in rs if r["first_below_05"] is not None]
            b = min(hit, key=lambda r: r["first_below_05"]) if hit else min(rs, key=lambda r: r["final_rmse"])
            best[d][str(lam)] = {"alpha": b["alpha"], "first_below_05": b["first_below_05"],
                                 "final_rmse": round(b["final_rmse"], 4), "min_rmse": round(b["min_rmse"], 4),
                                 "steps": b["steps"], "curve": b["curve"]}
    paper = {"1.0": "under 5000", "0.75": "about 7000", "0.5": "about 32000",
             "0.25": "about 189000", "0.0": "fails (TD(0) network, no history)"}
    out = {"source": "Tanner & Sutton, ICML 2005, Fig. 3-5, Eq. (6)-(7)",
           "setting": {"states": N_STATES, "nodes": N_NODES, "inputs": 2 + N_NODES,
                       "init_weight": "1/7", "y_init": 0, "block": BLOCK, "threshold": THRESH,
                       "alphas": ALPHAS, "runs": 1, "derivs": DERIVS,
                       "max_steps": {str(k): v for k, v in MAX_STEPS.items()}},
           "paper_steps_to_rmse_below_05": paper,
           "best_per_lambda": best,
           "all_runs": [{k: v for k, v in r.items() if k != "curve"} for r in res],
           "seconds": round(time.time() - t0, 1)}
    here = os.path.dirname(os.path.abspath(__file__))
    od = os.path.join(here, "..", "assets", "ch20-lit-cycle-world")
    os.makedirs(od, exist_ok=True)
    with open(os.path.join(od, "results.json"), "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=1)
    for d in DERIVS:
        for lam in LAMBDAS:
            b = best[d][str(lam)]
            print(d, lam, "alpha", b["alpha"], "hit", b["first_below_05"], "final", b["final_rmse"],
                  "paper:", paper[str(lam)])
    print("seconds", out["seconds"])


if __name__ == "__main__":
    main()
