"""Small exact calculations accompanying chapter 14's v10 derivations.

Run with Python 3, NumPy and matplotlib from any working directory.
Writes only assets/crl-v10. No training service, private research folder,
or previously recorded experiment is required.
"""
from pathlib import Path
import json
from functools import lru_cache
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager
ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "assets/crl-v10"
OUT.mkdir(parents=True, exist_ok=True)
for filename in ["/System/Library/Fonts/PingFang.ttc", "/System/Library/Fonts/STHeiti Medium.ttc"]:
    if Path(filename).exists():
        font_manager.fontManager.addfont(filename)
        plt.rcParams["font.family"] = font_manager.FontProperties(fname=filename).get_name()
        break
plt.rcParams.update({"font.size": 15, "axes.spines.top": False,
                     "axes.spines.right": False, "axes.unicode_minus": False,
                     "pdf.fonttype": 42})
TEAL, RED, INK = "#087E8B", "#C65335", "#182E38"
checks = []
def check(name, condition, **details):
    assert bool(condition), (name, details)
    checks.append({"name": name, "passed": True, **details})
def save(fig, name):
    fig.tight_layout()
    fig.savefig(OUT / (name + ".pdf"))
    fig.savefig(OUT / (name + ".png"), dpi=180)
    fig.savefig(OUT / (name + ".svg"))
    plt.close(fig)

# Unknown arm: a fixed hidden reward theta in {0,1}; one observation reveals it.
# Independent dynamic programming checks the closed-form probe-then-exploit rule.
@lru_cache(None)
def bayes_value(n, belief):
    if n == 0:
        return 0.
    safe = .6 + bayes_value(n-1, belief)
    probe = belief * (1. + bayes_value(n-1, 1.)) + (1-belief)*bayes_value(n-1, 0.)
    return max(safe, probe)
T = np.arange(1, 21)
safe = .6*T
probe = .5 + .8*(T-1)
optimal = np.array([bayes_value(int(t), .5) for t in T])
check("lifetime_closed_form_vs_belief_dynamic_programming",
      np.allclose(optimal, np.maximum(safe, probe)))
check("two_step_information_value", np.isclose(bayes_value(2,.5),1.3))
fig, ax = plt.subplots(figsize=(11.,2.9))
ax.plot(T,safe,"o-",color=INK,label="始终选 a（已知动作）")
ax.plot(T,probe,"s-",color=TEAL,label="先试 b，再按结果选择")
ax.scatter([1,2],[.6,1.3],color=RED,zorder=4)
ax.annotate("T=1：不试探", (1,.6), xytext=(1.25,12.2), ha="left", va="center",
            arrowprops={"arrowstyle":"->","color":RED,"shrinkB":5}, color=RED)
ax.annotate("T=2：试探的期望总奖励更高", (2,1.3), xytext=(2.6,8.2), ha="left", va="center",
            arrowprops={"arrowstyle":"->","color":RED,"shrinkB":5}, color=RED)
ax.set(xlabel="总交互步数 T",ylabel="期望累计奖励",xticks=[1,2,5,10,15,20])
ax.legend(loc="lower right")
save(fig,"lifetime-information")

# Fixed two-state environment. At A: F returns to A with reward .4;
# D moves to B with reward 0. At B: only action returns to A with reward 2.
def quantities(theta):
    p=1/(1+np.exp(-theta))
    P=np.array([[1-p,p],[1.,0.]])
    r=np.array([.4*(1-p),2.])
    d=np.array([1/(1+p),p/(1+p)])
    rho=(.4+1.6*p)/(1+p)
    h=np.array([0.,2-rho])
    return p,P,r,d,rho,h
theta=0.;p,P,r,d,rho,h=quantities(theta)
q=np.array([.4-rho, -rho+h[1]])
score=np.array([-p,1-p])
gradient=d[0]*np.dot(np.array([1-p,p])*q,score)
fd=(quantities(theta+1e-6)[4]-quantities(theta-1e-6)[4])/2e-6
check("stationary_distribution",np.allclose(d@P,d))
check("average_poisson_equation",np.allclose(rho+h,r+P@h))
check("average_policy_gradient_vs_finite_difference",np.isclose(gradient,fd,atol=1e-9),
      exact=float(gradient),finite_difference=float(fd))
# One observed D transition. All targets use the old critic/rate/actor.
delta=0.-rho+h[1]-h[0]
theta_new=theta+.5*delta*score[1]
rho_est_new=rho+.01*delta
h_est_new=h.copy();h_est_new[0]+=.1*delta
p_new,P_new,r_new,d_new,rho_new,h_true_new=quantities(theta_new)
check("one_actor_critic_step",np.allclose([delta,theta_new,rho_est_new,h_est_new[0]],[.4,.1,.804,.04]))
check("rate_improves_for_this_exact_example",rho_new>rho)
check("critic_must_track_new_policy",not np.allclose(h_est_new-h_est_new[0],h_true_new))
thetas=np.linspace(-3,3,121)
vals=np.array([[quantities(t)[0],quantities(t)[3][1],quantities(t)[4]] for t in thetas])
fig,axes=plt.subplots(1,2,figsize=(11.,2.8))
for ax,col,title in [(axes[0],2,"策略的奖励率"),(axes[1],1,"训练数据中 B 的长期比例")]:
    ax.plot(thetas,vals[:,col],color=TEAL)
    old=rho if col==2 else d[1];new=rho_new if col==2 else d_new[1]
    ax.scatter([0,.1],[old,new],color=[INK,RED],s=40,zorder=4)
    ax.annotate(f"{old:.4f} → {new:.4f}",(.1,new),xytext=(.45,new-.13),
                arrowprops={"arrowstyle":"->","color":RED},color=RED,fontsize=13)
    ax.set(xlabel="策略参数 θ",title=title)
axes[0].set_ylabel("每个原子步的期望奖励")
axes[1].set_ylabel("平稳访问概率 dπ(B)")
save(fig,"policy-and-data")
np.savetxt(OUT/"policy-and-data.csv",np.column_stack([thetas,vals]),delimiter=",",
           header="theta,p_D,d_B,rho",comments="")

# A representation change need not lose information or change the function class.
phi=np.eye(2);w=np.array([1.,-1.]);rotation=np.array([[0.,-1.],[1.,0.]])
# Rows are state features, so column-vector phi_new=rotation phi_old becomes:
phi_new=phi@rotation.T
old=phi@w;stale=phi_new@w;transported=phi_new@(rotation@w)
check("invertible_representation_can_preserve_predictions",np.allclose(old,transported))
check("fixed_readout_changes_after_representation_update",not np.allclose(old,stale))
fig,axes=plt.subplots(1,2,figsize=(11.,2.6))
ax=axes[0]
for vector,label,color in [(phi[0],"A 原表示",INK),(phi[1],"B 原表示",INK),
                           (phi_new[0],"A 新表示",TEAL),(phi_new[1],"B 新表示",TEAL)]:
    ax.arrow(0,0,vector[0],vector[1],width=.012,head_width=.08,length_includes_head=True,color=color,alpha=.75)
    # A 新表示 与 B 原表示 是同一向量 (0,1)：标签分放箭头尖端左右两侧
    pos={"A 原表示":(1.06,-.1,"left"),"B 新表示":(-1.0,.2,"left"),
         "A 新表示":(-.08,1.0,"right"),"B 原表示":(.08,1.0,"left")}[label]
    ax.text(pos[0],pos[1],label,fontsize=13,color=color,ha=pos[2],va="center")
ax.set(xlim=(-1.45,1.5),ylim=(-.45,1.4),xlabel="特征 1",ylabel="特征 2",title="可逆旋转：信息仍然保留")
ax.axhline(0,color="#ddd",lw=.8);ax.axvline(0,color="#ddd",lw=.8)
ax=axes[1];locations=np.arange(2)
for j,(v,label,color) in enumerate([(old,"原预测",INK),(stale,"只改表示",RED),(transported,"同步变换读出",TEAL)]):
    ax.bar(locations+(j-1)*.23,v,width=.22,color=color,label=label)
ax.set(xticks=locations,xticklabels=["状态 A","状态 B"],ylim=(-1.5,1.6),ylabel="预测值")
ax.axhline(0,color="#ddd",lw=.8);ax.legend(fontsize=12,loc="center left",bbox_to_anchor=(1.01,.5),frameon=False)
save(fig,"representation-readout")

# Event GVF: a two-step route, stopping on its first failure or route completion.
# Exact probabilities are an oracle for checking the definition, not TD labels.
risk=.4
G_safe=0+1*0;G_bad=0+1*1
check("event_gvf_equals_probability",np.isclose((1-risk)*G_safe+risk*G_bad,risk))
vA=.08;vB=.08;alpha=.5
sequence=[]
for state,C,k,next_state in [("A",0.,1.,"B"),("B",1.,0.,"terminal"),("A",0.,1.,"B")]:
    before={"A":vA,"B":vB}
    target=C+k*({"A":vA,"B":vB}.get(next_state,0.))
    if state=="A":vA+=alpha*(target-vA)
    else:vB+=alpha*(target-vB)
    sequence.append({"state":state,"cumulant":C,"continuation":k,"target":target,
                     "before":before,"after":{"A":vA,"B":vB}})
check("event_TD_propagation",np.allclose([sequence[0]["after"]["A"],sequence[1]["after"]["B"],sequence[2]["after"]["A"]],[.08,.54,.31]))
check("predicted_risk_rule_changes_action",.08<.1<.31)

# Sum frozen atomic differential residuals over an option.
rewards=np.array([0.,2.]);state_values=np.array([0.,1.2,0.])
deltas=rewards-rho+np.diff(state_values)
option_target=rewards.sum()-rho*2+state_values[-1]
check("option_atomic_residuals_telescope",np.isclose(deltas.sum(),option_target-state_values[0]))
gamma=.9;V_end=3.
discounted_target=sum(gamma**k*r for k,r in enumerate(rewards))+gamma**2*V_end
check("option_discounted_target",np.isclose(discounted_target,4.23))
check("option_reward_rate_ranking",2/2>.4/1)

# Two one-step episodes with targets 1 then 0. Terminal traces reset;
# sensitivity persists because learned w persists across the episodes.
def two_updates(beta):
    alpha=np.exp(beta);ww=0.
    for y in [1.,0.]:ww+=alpha*(y-ww)
    return ww
alpha=.8;beta=np.log(alpha);ww=0.;H=0.;sensitivity=[]
for y in [1.,0.]:
    err=y-ww
    H=(1-alpha)*H+alpha*err
    ww+=alpha*err
    sensitivity.append({"target":y,"w":ww,"eligibility":1.,"H":H})
fd_H=(two_updates(beta+1e-6)-two_updates(beta-1e-6))/2e-6
check("meta_sensitivity_vs_finite_difference",np.isclose(H,fd_H,atol=1e-9),
      exact=float(H),finite_difference=float(fd_H))
check("trace_is_not_parameter_sensitivity",H<0 and sensitivity[-1]["eligibility"]==1)
a=np.linspace(.001,.999,240);fig,axes=plt.subplots(1,2,figsize=(11.,2.6))
axes[0].plot(a,a*(1-a),color=TEAL);axes[0].scatter([.8],[.16],color=RED)
axes[0].set(xlabel="步长 α",ylabel="两次更新后的 w",title=r"$w_2=\alpha(1-\alpha)$")
axes[1].plot(a,a*(1-2*a),color=TEAL,label=r"元敏感度 $H_2$")
axes[1].axhline(1,color=INK,ls="--",label="当前资格迹 e=1")
axes[1].axhline(0,color="#ccc",lw=.8);axes[1].scatter([.8],[-.48],color=RED)
axes[1].set(xlabel="步长 α",ylabel="不同的导数对象",title=r"$H_2=\alpha(1-2\alpha)$")
axes[1].legend(fontsize=13)
save(fig,"trace-and-sensitivity")

result={"checks":checks,"check_count":len(checks),
        "delivery":{"p_before":float(p),"rate_before":float(rho),"h_before":h.tolist(),
                    "gradient":float(gradient),"delta":float(delta),"theta_after":float(theta_new),
                    "p_after":float(p_new),"rate_estimate_after":float(rho_est_new),
                    "rate_true_after":float(rho_new),"d_B_before":float(d[1]),"d_B_after":float(d_new[1]),
                    "h_estimate_after":h_est_new.tolist(),"h_true_after":h_true_new.tolist()},
        "risk_TD_sequence":sequence,"meta_sequence":sensitivity,
        "lifetime":{"T":T.tolist(),"safe":safe.tolist(),"probe":probe.tolist(),"optimal":optimal.tolist()},
        "semantics":"Exact finite examples and prescribed observed samples; not an end-to-end continual-RL benchmark."}
(OUT/"results.json").write_text(json.dumps(result,ensure_ascii=False,indent=2)+"\n")
print(json.dumps({"checks_passed":len(checks),"delivery":result["delivery"]},ensure_ascii=False,indent=2))
