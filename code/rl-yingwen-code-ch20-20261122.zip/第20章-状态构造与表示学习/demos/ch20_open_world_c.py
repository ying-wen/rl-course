# -*- coding: utf-8 -*-
"""Chapter 20 open problem, world C: corridor length L, write noise, indicator reversals every M steps.

Run:  python3 demos/ch20_open_world_c.py pilot      # 10 runs per cell (same seeds across learners)
      python3 demos/ch20_open_world_c.py full N     # N runs per cell -> demos/ch20-open-world-c-results.json
      python3 demos/ch20_open_world_c.py check      # L=1, no noise, one reversal at 3000: chapter 20 table

Trip (chapter 20 warehouse with a corridor): D -> L corridor steps -> J; correct side: J (+4) -> B,
detour: J -> W (+1) -> C -> B.  Steps per trip: L+2 correct, L+4 detour.  Indicator c = +-1 points to
the B side with probability kappa; kappa alternates .8 / .2 every M steps (M = inf: never).
Memory: z = c written at D; each corridor step z <- psi*z + sigma_w*eps.  Policy pi(left) = sig(theta*z).
Prediction readout p = (1+z)/2 for Y = 1{left is B}.  theta by REINFORCE with a running baseline;
psi by: fixed, prediction error (pred), small control weight (mix), control only (ctrl).
Part 2 (slots): L=1, two memory slots, candidate sources {indicator, clock, TV}; each slot has its own
psi (trained by prediction error) and theta; replacement by usage (Rafiee et al. 2023 style) or by a
payback ledger (hindsight counterfactual credit minus rent; a slot yields only when its balance < 0).
All runs are vectorized over independent runs; learners share the world's random numbers run by run.
"""
import json
import sys
from pathlib import Path

import numpy as np


def sig(x):
    return 1.0 / (1.0 + np.exp(-x))


def world_stream(R, K, L, seed):
    rng = np.random.default_rng(seed)
    return dict(s=np.where(rng.random((K, R)) < .5, 1.0, -1.0), u=rng.random((K, R)),
                ua=rng.random((K, R)), eps=rng.normal(size=(K, L, R)),
                tv=np.where(rng.random((K, R)) < .5, 1.0, -1.0))


def run(mode, R, T, L, M, sigma_w, seed, psi0=.5, th0=0., a_p=.1, a_c=.05, a_b=.05, lam=.1, block=3000,
        kap_hi=.8, kap_lo=.2):
    K = T // 3 + 2
    W = world_stream(R, K, L, seed)
    psi = np.full(R, psi0); th = np.full(R, th0); b = np.full(R, 2.5)
    t = np.zeros(R, dtype=np.int64)
    nb = (T + block - 1) // block
    J = np.zeros((R, nb))
    ar = np.arange(R)
    for k in range(K):
        live = t < T
        if not live.any():
            break
        if np.isinf(M):
            kap = np.full(R, kap_hi)
        else:
            kap = np.where((t // int(M)) % 2 == 0, kap_hi, kap_lo)
        s = W['s'][k]
        c = np.where(W['u'][k] < kap, s, -s)
        z = c.copy(); g = np.zeros(R)
        for j in range(L):
            g = z + psi * g
            z = psi * z + sigma_w * W['eps'][k, j]
        pL = sig(th * z)
        a = np.where(W['ua'][k] < pL, 1.0, -1.0)
        ok = a == s
        G = np.where(ok, 4.0, 1.0)
        ridx = t + L + np.where(ok, 0, 1)            # step index of the reward
        steps = L + np.where(ok, 2, 4)
        m = live & (ridx < T)
        np.add.at(J, (ar[m], ridx[m] // block), G[m])
        p = (1 + z) / 2; Y = (s == 1).astype(float)
        gp = (p - Y) * .5 * g
        ind = (a == 1).astype(float)
        score_psi = (ind - pL) * th * g
        score_th = (ind - pL) * z
        adv = G - b
        th = np.where(live, th + a_c * adv * score_th, th)
        if mode == 'pred':
            npsi = psi - a_p * gp
        elif mode == 'ctrl':
            npsi = psi + a_c * adv * score_psi
        elif mode == 'mix':
            npsi = psi - a_p * (gp - lam * adv * score_psi)
        else:
            npsi = psi
        psi = np.where(live, np.clip(npsi, -1, 1), psi)
        b = np.where(live, b + a_b * (G - b), b)
        t = t + steps
    return J, psi


LEARNERS = [('fixed .6', dict(mode='fixed', psi0=.6)), ('fixed 1', dict(mode='fixed', psi0=1.)),
            ('pred', dict(mode='pred')), ('mix .1', dict(mode='mix')), ('ctrl', dict(mode='ctrl')),
            ('mix .1 psi0=1', dict(mode='mix', psi0=1.))]


def run_slots(rule, R, T, M, seed, a_p=.1, a_c=.05, a_b=.05, Tr=100, Amin=300, rent=.02, cap=20., block=3000):
    """rule: 'none' (keep indicator+clock), 'usage', 'payback'.  Sources 0 indicator, 1 clock, 2 TV."""
    K = T // 3 + 2
    W = world_stream(R, K, 1, seed)
    src = np.tile(np.array([0, 1]), (R, 1))
    psi = np.full((R, 2), .5); th = np.zeros((R, 2)); b = np.full(R, 2.5)
    use = np.zeros((R, 2)); zbar = np.zeros((R, 2)); bal = np.zeros((R, 2)); age = np.zeros((R, 2))
    t = np.zeros(R, dtype=np.int64); nextr = np.full(R, Tr)
    nb = (T + block - 1) // block
    J = np.zeros((R, nb)); held = np.zeros((R, nb)); drops = np.zeros(R)
    ar = np.arange(R)
    for k in range(K):
        live = t < T
        if not live.any():
            break
        kap = np.full(R, .8) if np.isinf(M) else np.where((t // int(M)) % 2 == 0, .8, .2)
        s = W['s'][k]
        c = np.where(W['u'][k] < kap, s, -s)
        clock = np.full(R, 1.0 if k % 2 == 0 else -1.0)
        xs = np.stack([c, clock, W['tv'][k]], 1)                    # R x 3
        x = np.take_along_axis(xs, src, 1)                           # R x 2
        z = psi * x
        h = (th * z).sum(1)
        pL = sig(h)
        a = np.where(W['ua'][k] < pL, 1.0, -1.0)
        ok = a == s
        G = np.where(ok, 4.0, 1.0)
        ridx = t + 1 + np.where(ok, 0, 1); steps = np.where(ok, 3, 5)
        m = live & (ridx < T)
        np.add.at(J, (ar[m], ridx[m] // block), G[m])
        hb = np.minimum(t, T - 1) // block
        np.add.at(held, (ar[live], hb[live]), ((src[live] == 0).any(1)) * steps[live])
        Y = (s == 1).astype(float)
        ind = (a == 1).astype(float)
        adv = G - b
        L_ = live[:, None]
        th = np.where(L_, th + a_c * (adv * (ind - pL))[:, None] * z, th)
        p = (1 + z) / 2
        psi = np.where(L_, np.clip(psi - a_p * (p - Y[:, None]) * .5 * x, -1, 1), psi)
        b = np.where(live, b + a_b * (G - b), b)
        zbar = np.where(L_, zbar + .01 * (z - zbar), zbar)
        use = np.where(L_, use + .01 * (np.abs(th * (z - zbar)) - use), use)
        # hindsight counterfactual credit: P(correct | z) - P(correct | z without slot i), times 3
        pc = np.where(s == 1, pL, 1 - pL)
        cred = np.zeros((R, 2))
        for i in range(2):
            pli = sig(h - th[:, i] * z[:, i])
            cred[:, i] = 3 * (pc - np.where(s == 1, pli, 1 - pli))
        bal = np.where(L_, np.minimum(cap, bal + cred - rent), bal)
        age = np.where(L_, age + steps[:, None], age)
        t = t + steps
        if rule == 'none':
            continue
        due = live & (t >= nextr)
        nextr = np.where(due, nextr + Tr * ((t - nextr) // Tr + 1), nextr)
        if not due.any():
            continue
        score = use if rule == 'usage' else bal
        i = np.argmin(score, 1)                                       # lowest slot of all;
        sc = score[ar, i]
        go = due & (age[ar, i] >= Amin)                               # if it is still young, wait
        if rule == 'payback':
            go &= sc < 0
        if go.any():
            r = ar[go]; ii = i[go]
            outside = 3 - src[r].sum(1)                               # sources are {0,1,2}
            drops += go & (src[ar, i] == 0)
            src[r, ii] = outside
            psi[r, ii] = .5; th[r, ii] = 0.; use[r, ii] = 0.; zbar[r, ii] = 0.; bal[r, ii] = 0.; age[r, ii] = 0
    tb = np.minimum(np.arange(1, nb + 1) * block, T) - np.arange(nb) * block
    return J, held / tb, drops


def summ(J):
    tot = J.sum(1)
    return dict(J_block=[float(x) for x in J.mean(0)], per_step=float(tot.mean() / J.size * J.shape[0] / 1.0),
                total=float(tot.mean()), se=float(tot.std(ddof=1) / np.sqrt(len(tot))))


def paired(a, b):
    d = np.asarray(a) - np.asarray(b); n = len(d); sd = float(d.std(ddof=1))
    tc = 1.984 if n >= 100 else (2.262 if n == 10 else 2.0)
    se = sd / np.sqrt(n)
    return dict(mean=float(d.mean()), sd=sd, se=float(se), ci95=[float(d.mean() - tc * se), float(d.mean() + tc * se)],
                wins=int((d > 0).sum()), n=n)


def main():
    what = sys.argv[1] if len(sys.argv) > 1 else 'pilot'
    R = int(sys.argv[2]) if len(sys.argv) > 2 else 10
    if what == 'check':
        for name, kw in LEARNERS[:5]:
            J, _ = run(R=300, T=6000, L=1, M=3000, sigma_w=0., seed=12345, **kw)
            print('%-9s pre %.0f post %.0f' % (name, J[:, 0].mean(), J[:, 1].mean()))
        return
    T = 30000; sw = .1
    out = dict(T=T, sigma_w=sw, R=R, grid={}, slots={})
    for L in (1, 2, 4, 8):
        for M in (500, 1000, 3000, 10000, np.inf):
            cell = {}; Js = {}
            for name, kw in LEARNERS:
                J, psi = run(R=R, T=T, L=L, M=M, sigma_w=sw, seed=1000 + 7 * L, **kw)
                Js[name] = J.sum(1)
                cell[name] = dict(total=float(J.sum(1).mean()), se=float(J.sum(1).std(ddof=1) / np.sqrt(R)),
                                  psi_end=float(np.abs(psi).mean()))
            best_fixed = max(('fixed .6', 'fixed 1'), key=lambda n: cell[n]['total'])
            for n in ('pred', 'mix .1', 'ctrl'):
                cell['%s-%s' % (n, best_fixed)] = paired(Js[n], Js[best_fixed])
            cell['mix .1-fixed .6'] = paired(Js['mix .1'], Js['fixed .6'])
            cell['mix .1 psi0=1-%s' % best_fixed] = paired(Js['mix .1 psi0=1'], Js[best_fixed])
            cell['mix .1-ctrl'] = paired(Js['mix .1'], Js['ctrl'])
            key = 'L=%d M=%s' % (L, 'inf' if np.isinf(M) else int(M))
            out['grid'][key] = cell
            print(key, ' '.join('%s %.0f' % (n, cell[n]['total']) for n, _ in LEARNERS),
                  '| best fixed', best_fixed, '| mix-bf %.0f sd %.0f' % (cell['mix .1-%s' % best_fixed]['mean'], cell['mix .1-%s' % best_fixed]['sd']),
                  'pred-bf %.0f sd %.0f' % (cell['pred-%s' % best_fixed]['mean'], cell['pred-%s' % best_fixed]['sd']), flush=True)
    out['scaled_step'] = {}
    for L in (4, 8):                     # prediction step .1/L^2, psi from 1: does a smaller step rescue learning psi?
        for M in (3000, np.inf):
            Jp, psi = run('pred', R=R, T=T, L=L, M=M, sigma_w=sw, seed=1000 + 7 * L, psi0=1., a_p=.1 / L ** 2)
            Jf, _ = run('fixed', R=R, T=T, L=L, M=M, sigma_w=sw, seed=1000 + 7 * L, psi0=1.)
            key = 'L=%d M=%s' % (L, 'inf' if np.isinf(M) else int(M))
            out['scaled_step'][key] = dict(pred=float(Jp.sum(1).mean()), fixed1=float(Jf.sum(1).mean()),
                                           psi_end=float(np.abs(psi).mean()), diff=paired(Jp.sum(1), Jf.sum(1)))
            print('scaled', key, out['scaled_step'][key]['pred'], out['scaled_step'][key]['fixed1'],
                  round(out['scaled_step'][key]['psi_end'], 2), round(out['scaled_step'][key]['diff']['sd']), flush=True)
    for M in (1000, 3000, 10000, np.inf):
        cell = {}; Js = {}
        for rule in ('none', 'usage', 'payback'):
            J, held, drops = run_slots(rule, R, T, M, seed=777)
            Js[rule] = J.sum(1)
            cell[rule] = dict(total=float(J.sum(1).mean()), se=float(J.sum(1).std(ddof=1) / np.sqrt(R)),
                              held=float(held.mean()), drops=float(drops.mean()))
        cell['usage-none'] = paired(Js['usage'], Js['none'])
        cell['payback-none'] = paired(Js['payback'], Js['none'])
        cell['payback-usage'] = paired(Js['payback'], Js['usage'])
        key = 'M=%s' % ('inf' if np.isinf(M) else int(M))
        out['slots'][key] = cell
        print('slots', key, ' '.join('%s %.0f held %.2f drops %.1f' % (r, cell[r]['total'], cell[r]['held'], cell[r]['drops'])
                                     for r in ('none', 'usage', 'payback')),
              '| pay-use %.0f sd %.0f' % (cell['payback-usage']['mean'], cell['payback-usage']['sd']), flush=True)
    path = Path(__file__).resolve().parent.parent / 'assets' / 'ch20-open-world-c' / ('ch20-open-world-c-%s.json' % ('pilot' if what == 'pilot' else 'results'))
    path.parent.mkdir(parents=True, exist_ok=True)
    json.dump(out, open(path, 'w'), indent=1)


if __name__ == '__main__':
    main()
