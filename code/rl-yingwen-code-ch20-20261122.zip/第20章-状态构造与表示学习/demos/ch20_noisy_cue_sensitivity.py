# -*- coding: utf-8 -*-
import json, ch20_noisy_cue as sim20
from pathlib import Path
_OUT = Path(__file__).resolve().parent.parent / 'assets' / 'ch20-noisy-cue' / 'ch20_noisy_cue_sensitivity.json'
_OUT.parent.mkdir(parents=True, exist_ok=True)
res={}
for lab,extra in [('a_c=.02',dict(a_c=.02)),('a_c=.1',dict(a_c=.1)),('a_c=.2',dict(a_c=.2)),('a_p=.05',dict(a_p=.05)),('a_p=.2',dict(a_p=.2)),('theta0=2',dict(th0=2.))]:
    print('==',lab)
    o=sim20.experiment(6000,3000,.2,R=200,extra=extra,cfgs=[c for c in sim20.CFGS if c[0]!='nowrite'])
    res[lab]={k:{kk:v[kk] for kk in ('pre','post','tot','risk_pre','risk_post','psi_pre','recover90')} for k,v in o.items()}
print('== lambda')
lam={}
for l in (.03,.1,.3,1.):
    o=sim20.experiment(6000,3000,.2,R=200,cfgs=[('mix %g'%l,dict(mode='mix',lam=l))])
    lam[l]=list(o.values())[0]
    lam[l]={kk:lam[l][kk] for kk in ('pre','post','tot','risk_pre','risk_post','psi_pre','recover90')}
res['lambda']=lam
json.dump(res,open(_OUT, 'w'),indent=1)
