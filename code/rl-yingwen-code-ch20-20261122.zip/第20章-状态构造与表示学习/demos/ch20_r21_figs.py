"""第 20 章章首风险曲线与「线性—非线性」对照的数与图。

Run from rl-course:
    python demos/ch20_r21_figs.py

Writes
    assets/ch20-r21/risk-curves.pdf       (page ch20-open-encoder)
    assets/ch20-r21/linear-nonlinear.pdf  (page ch20-r21-linear-nonlinear-example)

11-21 审阅站请求 r1121-132759（第 20 章，1713 页风险曲线；总评「线性与非线性特征的优缺点与学习挑战」）。

设定（仓库主例）：在 D 写入 z=c（亮左 c=+1，亮右 c=-1），其后每步乘 psi；到 J 读出
p=(1+z_J)/2，Y=1 表示向左后到 B。指示正确率 kappa：Pr(Y=1 | c=+1)=kappa。
记 u = z_J * c，则平方风险
    E[(p-Y)^2] = kappa(1-kappa) + (u-(2kappa-1))^2/4 .
一步走廊 u=psi（读出对参数线性）；两步走廊 u=psi^2（同一个 psi 用两次，读出对参数非线性）。
"""
from pathlib import Path
import sys

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter

sys.path.insert(0, str(Path(__file__).resolve().parent))
from plot_fonts import use_course_fonts, CJK_FAMILY, no_leading_zero  # noqa: E402

TEAL, RED, GOLD, MUTED, INK = "#096B76", "#AA412D", "#A27618", "#52666E", "#182E38"
OUT = Path(__file__).resolve().parent.parent / "assets" / "ch20-r21"
NLZ = FuncFormatter(no_leading_zero)


def risk(u, kappa):
    return kappa * (1 - kappa) + (u - (2 * kappa - 1)) ** 2 / 4


def grad_expected(psi, kappa, steps):
    """d/dpsi of E[ 1/2 (p-Y)^2 ] for c=+1 (c=-1 gives the same by symmetry)."""
    u = psi ** steps
    du = steps * psi ** (steps - 1)
    p = (1 + u) / 2
    return (p - kappa) * du / 2


def sgd_run(steps, psi0=.5, alpha=.2, n_pass=6000, flips=(2000, 4000), seeds=50):
    """Stochastic updates on single passes; kappa .8, then .2 after flips[0], then .8 again after flips[1]."""
    traj = np.zeros((seeds, n_pass + 1))
    for s in range(seeds):
        rng = np.random.default_rng(s)
        psi = psi0
        traj[s, 0] = psi
        for t in range(n_pass):
            kappa = .2 if flips[0] <= t < flips[1] else .8
            c = 1 if rng.random() < .5 else -1
            correct = rng.random() < kappa
            y = 1.0 if (c == 1) == correct else 0.0      # B on the left?
            z = c * psi ** steps
            dz = c * steps * psi ** (steps - 1)            # sensitivity z-dot
            p = (1 + z) / 2
            psi -= alpha * (p - y) * dz / 2
            traj[s, t + 1] = psi
    return traj


def numbers():
    print("== one-step corridor (u = psi) ==")
    for psi in (0, .6, 1):
        print(f"  psi={psi:g}: risk kappa=.8 -> {risk(psi, .8):.4f}; kappa=.2 -> {risk(psi, .2):.4f}")
    print("  z=.6 -> p=", (1 + .6) / 2)
    print("  expected grad at psi=.5:", grad_expected(.5, .8, 1), "(=(psi-.6)/4 =", (.5 - .6) / 4, ")")
    print("== two-step corridor (u = psi^2) ==")
    print("  minimisers +-sqrt(.6) =", np.sqrt(.6))
    for psi in (0, .5, np.sqrt(.6), 1):
        print(f"  psi={psi:.4f}: risk kappa=.8 -> {risk(psi**2, .8):.4f}; kappa=.2 -> {risk(psi**2, .2):.4f};"
              f" grad kappa=.8 -> {grad_expected(psi, .8, 2):.4f}")
    grid = np.linspace(-1, 1, 20001)
    r2 = risk(grid ** 2, .2)
    print("  kappa=.2 two-step min risk", r2.min(), "at psi", grid[r2.argmin()])
    print("  kappa=.8 two-step risk at psi=0 (stationary):", risk(0, .8))
    print("== linear features x=(1,c) ==")
    # v = w0 + w1 c fitted to E[Y|c]: c=+1 -> .8, c=-1 -> .2
    A = np.array([[1, 1], [1, -1]]); b = np.array([.8, .2])
    w = np.linalg.solve(A, b)
    print("  w0, w1 =", w, " risk =", .16)
    print("  x=(1) only: best w0 =", .5, " risk =", .25)
    out = {}
    for steps in (1, 2):
        tr = sgd_run(steps)
        out[steps] = tr
        m = tr.mean(axis=0)
        print(f"  SGD steps={steps}: psi at 2000 = {m[2000]:.3f} (sd {tr[:,2000].std():.3f}),"
              f" at 4000 = {m[4000]:.3f} (sd {tr[:,4000].std():.3f}), at 6000 = {m[-1]:.3f}")
        print(f"     max |psi| at 4000 = {np.abs(tr[:,4000]).max():.3g};"
              f" risk(kappa=.2) at psi(4000) mean = {risk(m[4000]**steps, .2):.4f}")
        for lo, hi, thr, sgn in ((2000, 4000, -.5, -1), (4000, 6000, .5, 1)):
            hit = [np.argmax(sgn * tr[s_, lo:hi + 1] >= sgn * thr) if (sgn * tr[s_, lo:hi + 1] >= sgn * thr).any() else None
                   for s_ in range(tr.shape[0])]
            ok = [h for h in hit if h is not None]
            print(f"     passes after flip at {lo} to reach psi {'<=' if sgn < 0 else '>='} {thr}: "
                  f"{len(ok)}/{len(hit)} seeds, median {np.median(ok) if ok else 'never'}")
    long = sgd_run(2, n_pass=9000, flips=(2000, 4000))
    hit = [int(np.argmax(long[s_, 4000:] >= .5)) for s_ in range(long.shape[0]) if (long[s_, 4000:] >= .5).any()]
    print(f"  two-step, longer run: {len(hit)}/{long.shape[0]} seeds reach psi>=.5 after the flip back;"
          f" median {np.median(hit):.0f} passes (range {min(hit)}-{max(hit)})")
    tr0 = sgd_run(2, psi0=0.0, n_pass=500, flips=(10**9, 10**9), seeds=3)
    print("  two-step from psi=0: max |psi| over 500 passes =", np.abs(tr0).max())
    return out


def fig_risk_curves():
    fig, ax = plt.subplots(figsize=(2.4, 1.3))
    g = np.linspace(-1, 1, 401)
    ax.plot(g, risk(g, .8), color=TEAL, lw=1.5)
    ax.plot(g, risk(g, .2), color=RED, lw=1.3, ls='--')
    for psi in (0, .6, 1):
        ax.plot([psi], [risk(psi, .8)], 'o', color=TEAL, ms=3.2)
    ax.plot([-.6], [.16], 'o', color=RED, ms=3.2, mfc='white')
    ax.annotate('.25', (0, .25), xytext=(.1, .262), fontsize=9.5, color=TEAL, ha='left')
    ax.annotate('.20', (1, .20), xytext=(.98, .228), fontsize=9.5, color=TEAL, ha='center')
    ax.text(.30, .55, '$\\kappa=.8$', color=TEAL, fontsize=10, transform=ax.transAxes)
    ax.text(.0, .86, '$\\kappa=.2$', color=RED, fontsize=10, transform=ax.transAxes)
    ax.set_xlim(-1.05, 1.05); ax.set_ylim(.13, .45)
    ax.set_xticks([-1, -.6, 0, .6, 1]); ax.set_yticks([.16, .25, .4])
    ax.xaxis.set_major_formatter(NLZ); ax.yaxis.set_major_formatter(NLZ)
    ax.set_xlabel('$\\psi$', fontsize=10.5, labelpad=1)
    ax.set_ylabel('平方风险', fontsize=10, labelpad=1)
    ax.tick_params(labelsize=9.5, pad=1.5)
    for sp in ('top', 'right'):
        ax.spines[sp].set_visible(False)
    fig.tight_layout(pad=.2)
    fig.savefig(OUT / 'risk-curves.pdf')
    plt.close(fig)


def fig_linear_nonlinear(traj):
    fig, (a1, a2) = plt.subplots(1, 2, figsize=(5.0, 1.38), gridspec_kw={'width_ratios': [1, 1.15]})
    g = np.linspace(-1, 1, 401)
    a1.plot(g, risk(g, .8), color=GOLD, lw=1.1)
    a1.plot(g, risk(g ** 2, .8), color=TEAL, lw=1.7)
    a1.plot(g, risk(g ** 2, .2), color=RED, lw=1.5, ls='--')
    a1.plot([0], [.25], 'o', color=INK, ms=3.6)
    a1.annotate('驻点 $\\psi=0$', (0, .25), xytext=(-.33, .335), fontsize=8, fontfamily=CJK_FAMILY,
                color=INK, arrowprops=dict(arrowstyle='->', color=INK, lw=.6))
    for s in (-1, 1):
        a1.plot([s * np.sqrt(.6)], [.16], 'o', color=TEAL, ms=3.4)
    a1.text(-1.02, .088, '一步：$u=\\psi$', color=GOLD, fontsize=8, fontfamily=CJK_FAMILY)
    a1.text(.08, .088, '两步：$u=\\psi^2$', color=TEAL, fontsize=8, fontfamily=CJK_FAMILY)
    a1.text(0, .44, '两步，反转后', color=RED, fontsize=8, fontfamily=CJK_FAMILY, ha='center')
    a1.set_xlim(-1.05, 1.05); a1.set_ylim(.07, .48)
    a1.set_xticks([-.775, 0, .775]); a1.set_xticklabels(['-.775', '0', '.775'])
    a1.set_yticks([.16, .25, .4])
    a1.yaxis.set_major_formatter(NLZ)
    a1.set_xlabel('$\\psi$', fontsize=8, labelpad=1); a1.set_ylabel('平方风险', fontsize=8)
    for xf in (2000, 4000):
        a2.axvline(xf, color=MUTED, lw=.7, ls=':')
    a2.axhline(0, color=MUTED, lw=.5)
    for steps, col, lab in ((1, GOLD, '一步走廊'), (2, TEAL, '两步走廊')):
        m = traj[steps].mean(axis=0)
        a2.plot(np.arange(len(m)), m, color=col, lw=1.6)
    a2.text(2050, .9, '反转', fontsize=8, color=MUTED, fontfamily=CJK_FAMILY)
    a2.text(4050, .9, '再反转', fontsize=8, color=MUTED, fontfamily=CJK_FAMILY)
    a2.set_xlim(0, 6000); a2.set_ylim(-.85, 1.0)
    a2.set_yticks([-.6, 0, .6, .775]); a2.set_yticklabels(['-.6', '0', '.6', ''])
    a2.set_xticks([0, 2000, 4000, 6000])
    a2.set_xlabel('趟数', fontsize=8, labelpad=1); a2.set_ylabel('$\\psi$（50 次平均）', fontsize=8, fontfamily=CJK_FAMILY)
    a2.text(5000, .3, '一步走廊', fontsize=8, color=GOLD, fontfamily=CJK_FAMILY, ha='center')
    a2.text(3000, .08, '两步走廊', fontsize=8, color=TEAL, fontfamily=CJK_FAMILY, ha='center')
    for ax in (a1, a2):
        ax.tick_params(labelsize=8)
        for sp in ('top', 'right'):
            ax.spines[sp].set_visible(False)
    fig.tight_layout(pad=.3, w_pad=1.2)
    fig.savefig(OUT / 'linear-nonlinear.pdf')
    plt.close(fig)


if __name__ == '__main__':
    use_course_fonts()
    OUT.mkdir(parents=True, exist_ok=True)
    tr = numbers()
    fig_risk_curves()
    fig_linear_nonlinear(tr)
