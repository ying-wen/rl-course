# 第 25 章　知识的维护、检验与更新：程序

本目录可以单独运行：在本目录下执行下面的命令即可，结果写回本目录的 `assets/`。目录由 `rl-course/tools/export_chapter_code.py` 从课程目录生成，改程序请改课程目录里的原件，再重新导出。

## 准备

```sh
python3 -m pip install -r requirements.txt
```

需要的第三方包：matplotlib、numpy。复现附录要求 Python 3.10 或更新版本；核验时用的版本见下表。

## 运行（与复现附录相同）

```sh
python3 demos/ch25_lit_shortcut.py         # 文献原型：捷径迷宫，写 assets/ch25-lit-shortcut
python3 demos/crl_ladder_learners.py --exp ch25 --seeds 60 --seed0 100 --steps 2000000 --tag formal   # 四区仓库阶梯，写 assets/crl-ladder-world/runs/formal-ch25.json
python3 demos/crl_ladder_figures.py ch25           # 写 assets/crl-ladder-world/fig/ladder-ch25.png
```

## 本目录的程序

| 程序 | 说明 | 核验 |
|---|---|---|
| `demos/ch25_lit_shortcut.py` | 第 25 章文献原型：捷径迷宫（Sutton & Barto 第 2 版 §8.3，例 8.3，图 8.5）。 | 通过（34 秒） |
| `demos/crl_ladder_learners.py` | 四区仓库的学习器阶梯（例子方案第三步）。 | 超时：300 秒内未跑完（启动正常） |
| `demos/crl_ladder_figures.py` | 阶梯世界（四区仓库）阅读稿用图：地图与各章“占天花板”条形。 | 通过（1 秒） |
| `demos/crl_ladder_world.py` | 四区仓库：第三部分的能力阶梯世界（环境与精确参照）。 | 通过（16 秒） |
| `demos/crl_ladder_world_checks.py` | 四区仓库的独立检查（照 v12 的做法：手算、枚举、独立实现互查）。 | 通过（16 秒） |
| `demos/crl_ladder_power.py` | 四区仓库学习器阶梯：试点估 σ_Δ 定种子数，正式跑后出第 24 章的账本。 | 通过（0 秒） |
| `demos/crl_ladder_ceiling.py` | 四区仓库学习器阶梯：每个试验条件的“天花板”，供账本算“离最优还差多少”。 | 超时：300 秒内未跑完（启动正常） |
| `demos/crl_ladder_diagnostics.py` | 四区仓库阶梯的诊断与改法（11-20）。 | 通过（0 秒） |

表中后 5 个程序复现附录本章一节没有列出，来自课件、阅读稿、CODE-MAP 或文件名前缀（第三部分另含学习器阶梯）。

## 第三部分的学习器阶梯（例子方案第三步）

四区仓库世界与 L0–L10 阶梯学习器。每章一个实验，三档：没有、设计者给定、从经验学到。比较都是配对的：同一种子下两档用同一份世界随机数。

```sh
python3 demos/crl_ladder_world.py --fast                     # 各区参考线，写 reference.json（全量去掉 --fast）
python3 demos/crl_ladder_world_checks.py                     # 世界本身的核对
python3 demos/crl_ladder_ceiling.py                          # 各条件的天花板（ε-软最好率），写 ceiling.json
python3 demos/crl_ladder_learners.py --exp ch25 --seeds 2 --steps 200000 --procs 2 --tag smoke   # 冒烟：写 assets/crl-ladder-world/runs/smoke-ch25.json
python3 demos/crl_ladder_learners.py --exp ch25 --seeds 60 --seed0 100 --steps 2000000 --tag formal   # 正式设置（种子数与 runs/ 里的正式记录相同）
python3 demos/crl_ladder_power.py ledger --runs formal-ch25     # 配对差与 95% 区间，写 ledger-formal-ch25.json
python3 demos/crl_ladder_figures.py ch25                       # 阅读稿用的地图与条形图（读账本）
```

参考记录在 `assets/crl-ladder-world/runs/`（随本目录复制）。正式设置一章要跑数十分钟到数小时；冒烟一行只确认程序能走通。正式结果与读法见 `assets/crl-ladder-world/README.md` 第八节，改进与诊断见第九节。

## 复现附录本章一节

本章 25.2 节三站仓库的数字（100 次试走 90 次成功、半宽 $h_{100}=.254$、区间 $[.646,1]$ 与“去 C”的 $[.523,.7]$、至少 $68$ 次）由正文推导直接算出。来自本课程序的结果有捷径迷宫的文献原型，以及 25.2 节四区仓库上北门关闭再重开时探测方式的阶梯比较。

25.2 节“每试一次就看一次”（课件 `ch25-anytime`）与 25.6 节“挑出来的，再量会偏高”（课件 `ch25-check-exp`）两张模拟数表，程序暂未收入本附录。

| 位置 | 结果 | 设置 | 程序 | 数据与输出 |
|---|---|---|---|---|
| 25.2 节“捷径迷宫”（课件 `ch25-lit-shortcut`） | 后 3000 步 Dyna-Q 165.33、Dyna-Q+ 228.77 次到达终点；Dyna-Q+ 30 次全部走通捷径，首次走通延迟中位数 354 步；Dyna-Q 1 次偶然走通 | 本课的模拟：6×9 捷径迷宫，第 3000 步后打开缺口，共 6000 个真实步，每个真实步 50 次规划，$\alpha=1$，$\gamma=.95$，$\epsilon=.1$，$\kappa=.001$，独立重复 30 次 | `demos/ch25_lit_shortcut.py` | `assets/ch25-lit-shortcut/results.json` |
| 25.2 节（课件 `ch25-ladder`） | 北门关 50 万步后重开：不探测的 Dyna 重开后每步少拿约 .008，学变化率的探测降到 .002；学变化率减不探测 $+.0031\pm.0005$，减 Dyna-Q+ $+.0020\pm.0007$ | 本课的模拟：四区仓库，200 万步，差分 Q，60 个种子；对照组同种子、门一直开 | `demos/crl_ladder_learners.py` 实验 `ch25` | `assets/crl-ladder-world/runs/formal-ch25.json`、`assets/crl-ladder-world/fig/ladder-ch25.png` |

运行：
```sh
python3 demos/ch25_lit_shortcut.py         # 文献原型：捷径迷宫，写 assets/ch25-lit-shortcut
python3 demos/crl_ladder_learners.py --exp ch25 --seeds 60 --seed0 100 --steps 2000000 --tag formal   # 四区仓库阶梯，写 assets/crl-ladder-world/runs/formal-ch25.json
python3 demos/crl_ladder_figures.py ch25           # 写 assets/crl-ladder-world/fig/ladder-ch25.png
```

## 参考数据

`assets/`（以及 `demos/NN-results/`）下复制了 90 个数据文件（json、csv 等），即课程目前使用的结果；图片没有复制，运行程序会重新画出。重跑会覆盖这些文件，可以先另存一份再对照。
