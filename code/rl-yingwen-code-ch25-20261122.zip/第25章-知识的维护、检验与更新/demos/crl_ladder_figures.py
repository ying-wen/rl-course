"""阶梯世界（四区仓库）阅读稿用图：地图与各章“占天花板”条形。

幻灯片用 math-helpers.tex 里的 \\LadderMap、\\LadderBars（TikZ）；阅读稿要 PNG，
这里用同样的几何与配色重画一遍。条形的数字从账本读：
先读 assets/crl-ladder-world/ledger.json，再用比它新的 ledger-<tag>.json 覆盖同一章；
改进与诊断实验的档（README 第九节）从 diagnostics.json 读，不进账本。

用法：
    python3 demos/crl_ladder_figures.py            # 画地图与 CHAPTERS 里列出的各章
    python3 demos/crl_ladder_figures.py ch16 ch17  # 只画这几章
输出：assets/crl-ladder-world/fig/ladder-map.png、ladder-<ch>.png
"""
import glob
import json
import os
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.patches import Rectangle, FancyArrowPatch

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
LADDER = os.path.join(ROOT, "assets", "crl-ladder-world")
OUT = os.path.join(LADDER, "fig")

INK, TEAL, RED, GOLD, MUTED, PALE = "#182E38", "#096B76", "#AA412D", "#A27618", "#52666E", "#EAF4F3"

for f in ("/System/Library/Fonts/PingFang.ttc", "/System/Library/Fonts/STHeiti Medium.ttc",
          "/Library/Fonts/Arial Unicode.ttf"):
    if os.path.exists(f):
        font_manager.fontManager.addfont(f)
        matplotlib.rcParams["font.family"] = font_manager.FontProperties(fname=f).get_name()
        break
matplotlib.rcParams["axes.unicode_minus"] = False

# 与 \LadderMap 相同：第 r 行第 c 列画在 (c, 12-r)，矩形为 (x0, y0, x1, y1)。
WALLS = [(0, 12, 13, 13), (0, 0, 13, 1), (0, 0, 1, 13), (12, 0, 13, 13),
         (6, 10, 7, 12), (6, 7, 7, 9), (6, 3, 7, 6), (6, 1, 7, 2),
         (1, 6, 2, 7), (3, 6, 7, 7), (6, 5, 9, 6), (10, 5, 12, 6)]
DOORS = [(6, 9), (2, 6), (9, 5), (6, 2)]
STATIONS = {"A": (1, 7), "B": (11, 11), "C": (1, 5), "D": (11, 1)}

# 每章画哪些档：(实验条件, 档名, 图上的名字)。数字全从账本读，这里只定顺序与名字。
CHAPTERS = {
    "ch16": ("base", [("none", "γ=.9 折扣 Q"), ("given", "设计者挑 γ=.99"), ("learned", "学 r̄（差分 Q）")]),
    "ch17": ("d20", [("none", "不处理延迟"), ("trace0.9", "迹 λ=.9"), ("trace0.98", "迹 λ=.98"),
                     ("learned", "学到延迟"), ("given", "给定延迟")]),
    "ch18": ("local", [("none", "无记忆，只看 3×3"), ("hist2", "记前两步观测"),
                       ("given", "记上次交货的站"), ("learned", "记上次得奖时的观测"),
                       ("given-sarsa0.9", "记上次的站，差分 Sarsa(λ=.9)")]),
    "ch19": ("battery", [("raw", "原始电量进表"), ("none", "不看电量"), ("learned", "给问题，逐格 TD 学答案"),
                         ("model", "给问题，模型学答案"), ("discover", "自己选问题"), ("given", "给定到桩步数")]),
    "ch20": ("flip", [("none", "不看灯"), ("given", "灯直接进状态"), ("learned", "生成与检验，选出灯"),
                      ("opt3e-4", "放预测，久未检验转乐观")]),
    "ch23": ("drift", [("alpha0.01", "写定 α=.01"), ("alpha0.03", "写定 α=.03"), ("alpha0.1", "写定 α=.1"),
                       ("alpha0.3", "写定 α=.3"), ("idbd0.1-a0.01", "IDBD，从 .01 起"),
                       ("idbd0.1", "IDBD，从 .1 起"), ("idbd0.1-a0.3", "IDBD，从 .3 起")]),
    "ch24": ("combo", [("none", "都不加"), ("only-battery", "只加电量"), ("only-context", "只加情境"),
                       ("only-cue", "只加灯"), ("only-idbd", "只加 IDBD"), ("all", "全加"),
                       ("-idbd", "全加，去掉 IDBD"), ("sum", "三件，因子化"), ("shared", "三件，共享")]),
    # 一章跨几个条件时，cond 写 None，每行写 (条件, 档名, 图上的名字)；条件之间画一条细线。
    "ch15": (None, [("h0.001-full", "none", "全看：到一半冻结"), ("h0.001-full", "given", "全看：常数步长"),
                    ("h0.001-full", "learned", "全看：识别情境"),
                    ("h0.001-coarse", "none", "粗看：到一半冻结"), ("h0.001-coarse", "given", "粗看：常数步长"),
                    ("h0.001-coarse", "learned", "粗看：识别情境")]),
    "ch21": ("h0.001", [("none", "只有原始动作"), ("given", "给定 8 个走廊选项"), ("learned-sub", "学到的子目标"),
                        ("learned-eig2", "本征选项 2 个"), ("learned-eig4", "本征选项 4 个"),
                        ("learned-eig8", "本征选项 8 个")]),
    "ch22": (None, [("h0", "prim", "不换：原始动作"), ("h0", "prim-plan", "不换：原始动作＋规划"),
                    ("h0", "none", "不换：选项"), ("h0", "given", "不换：选项＋设计者模型规划"),
                    ("h0", "learned", "不换：选项＋自己的模型规划"),
                    ("h0.001", "prim", "常换：原始动作"), ("h0.001", "prim-plan", "常换：原始动作＋规划"),
                    ("h0.001", "none", "常换：选项"), ("h0.001", "given", "常换：选项＋设计者模型规划"),
                    ("h0.001", "learned", "常换：选项＋自己的模型规划")]),
    "ch25": ("reopen", [("eps", "只靠 ε 探测，不规划"), ("none", "Dyna，不加探测奖励"),
                        ("given", "Dyna-Q+，κ√τ"), ("learned", "学到的变化率")]),
}

# 图题后补一句学习器说明（同一章里学习器不全相同时）。
NOTES = {"ch18": "前四档为差分 Q 学习"}


def load_tiers():
    """ledger.json 为底，比它新的单次账本覆盖同一章。"""
    base = os.path.join(LADDER, "ledger.json")
    tiers = {}
    t0 = os.path.getmtime(base) if os.path.exists(base) else 0
    files = [base] if os.path.exists(base) else []
    files += sorted((p for p in glob.glob(os.path.join(LADDER, "ledger-*.json"))
                     if os.path.getmtime(p) > t0), key=os.path.getmtime)
    for p in files:
        d = json.load(open(p))
        chs = {t["ch"] for t in d.get("tiers", [])}
        for k in [k for k in tiers if k[0] in chs]:
            del tiers[k]
        for t in d.get("tiers", []):
            tiers[(t["ch"], t["cond"], t["tier"])] = t
    diag = os.path.join(LADDER, "diagnostics.json")
    if os.path.exists(diag):
        for t in json.load(open(diag)).get("tiers", []):
            tiers[(t["ch"], t["cond"], t["tier"])] = t
    return tiers


def draw_map(ax, cell=1.0):
    ax.add_patch(Rectangle((0, 0), 13, 13, color=PALE, lw=0))
    for x in range(1, 13):
        ax.plot([x, x], [1, 12], color=MUTED, alpha=.25, lw=.4)
        ax.plot([1, 12], [x, x], color=MUTED, alpha=.25, lw=.4)
    for x0, y0, x1, y1 in WALLS:
        ax.add_patch(Rectangle((x0, y0), x1 - x0, y1 - y0, color=INK, alpha=.85, lw=0))
    for x, y in DOORS:
        ax.add_patch(Rectangle((x, y), 1, 1, color=TEAL, alpha=.35, lw=0))
    for s, (x, y) in STATIONS.items():
        ax.text(x + .5, y + .5, s, ha="center", va="center", fontsize=11, fontweight="bold", color=INK)
    ax.set_xlim(0, 13)
    ax.set_ylim(0, 13)
    ax.set_aspect("equal")
    ax.axis("off")


def route(ax, pts, color, both=False):
    xs, ys = zip(*pts)
    ax.plot(xs[:-1], ys[:-1], color=color, lw=2, solid_capstyle="round")
    ax.add_patch(FancyArrowPatch(pts[-2], pts[-1], arrowstyle="<|-|>" if both else "-|>",
                                 mutation_scale=12, color=color, lw=2))


def fig_map():
    fig, ax = plt.subplots(figsize=(4.2, 4.2), dpi=200)
    draw_map(ax)
    route(ax, [(1.6, 7.8), (5, 10.4), (6.5, 9.5), (9, 10.4), (10.6, 11.2)], GOLD)
    ax.text(9.3, 8.3, "R0：A→B 经北门", color=GOLD, fontsize=8, ha="center")
    route(ax, [(1.6, 5.2), (5, 2.6), (6.5, 2.5), (9, 2.6), (10.6, 1.8)], TEAL)
    ax.text(9.3, 3.9, "R1：C→D 经南门", color=TEAL, fontsize=8, ha="center")
    ax.annotate("东门兼充电桩", (9.5, 5.5), (10.2, 7.0), fontsize=7, color=TEAL,
                ha="center", arrowprops=dict(arrowstyle="-", color=TEAL, lw=.6))
    ax.annotate("西门：A–C 四步", (2.5, 6.5), (4.3, 5.2), fontsize=7, color=MUTED,
                ha="center", arrowprops=dict(arrowstyle="-", color=MUTED, lw=.6))
    os.makedirs(OUT, exist_ok=True)
    p = os.path.join(OUT, "ladder-map.png")
    fig.savefig(p, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    return p


def fig_bars(ch, tiers):
    if ch not in CHAPTERS:
        print("跳过", ch, "：CHAPTERS 里没有这一章（例如第 24 章还没有天花板）")
        return None
    cond, rows = CHAPTERS[ch]
    rows = [r if len(r) == 3 else (cond, *r) for r in rows]
    got = [(lab, tiers[(ch, cd, tr)], cd) for cd, tr, lab in rows if (ch, cd, tr) in tiers]
    if not got:
        print("跳过", ch, "：账本里没有", cond)
        return None
    n = len(got)
    seeds = {t.get("n") for _, t, _ in got}   # 各档种子数不同时（如第 18 章诊断档 12 个），逐行标出
    fig, ax = plt.subplots(figsize=(6.2, .45 * n + .9), dpi=200)
    for i, (lab, t, cd) in enumerate(got):
        y = n - 1 - i
        if i and cd != got[i - 1][2]:
            ax.axhline(y + .5, color=MUTED, lw=.5, alpha=.6)
        a, b = 100 * t["life_ratio"], 100 * t["last10_ratio"]
        ax.barh(y, a, height=.5, color=TEAL, alpha=.7)
        ax.plot([b, b], [y - .34, y + .34], color=GOLD, lw=2.5)
        reach = t.get("reach_med")
        frac = t.get("reach_frac") or 0
        extra = f"   到达 {reach / 1e4:.0f} 万步" if reach else ""
        if reach and frac < .995:
            extra += f"（{100 * frac:.0f}% 种子）"
        if len(seeds) > 1 and t.get("n"):
            extra += f"   {t['n']} 种子"
        ax.text(102, y, f"{a:.1f} / {b:.1f}{extra}", va="center", fontsize=8, color=INK)
    ax.set_yticks(range(n))
    ax.set_yticklabels([g[0] for g in got][::-1], fontsize=9)
    ax.set_xlim(0, 135)
    ax.set_xticks([0, 50, 100])
    ax.set_xticklabels(["0", "50%", "天花板"], fontsize=8, color=MUTED)
    ax.axvline(100, color=MUTED, lw=.6, ls="--")
    for s in ("top", "right", "left"):
        ax.spines[s].set_visible(False)
    ax.tick_params(axis="y", length=0)
    ceils = []
    for lab, t, cd in got:
        name = lab.split("：")[0] if "：" in lab else cd
        if (name, round(t["ceil"], 4)) not in ceils:   # 账本存 .129845，诊断档存 .1298：按四位小数算同一个
            ceils.append((name, round(t["ceil"], 4)))
    if len({c for _, c in ceils}) == 1:
        head = f"占天花板 {ceils[0][1]:.4f} 的百分比"
    else:
        head = "占各自天花板的百分比（" + "；".join(f"{cd} {c:.4f}" for cd, c in ceils) + "）"
    note = f"；{NOTES[ch]}" if ch in NOTES else ""
    ax.set_title(head + "：青条为 lifetime 率，金线为最后 10%" + note, fontsize=8, color=MUTED, loc="left")
    p = os.path.join(OUT, f"ladder-{ch}.png")
    fig.savefig(p, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    return p


def main(argv):
    tiers = load_tiers()
    chs = argv or list(CHAPTERS)
    print(fig_map())
    for ch in chs:
        p = fig_bars(ch, tiers)
        if p:
            print(p)


if __name__ == "__main__":
    main(sys.argv[1:])
