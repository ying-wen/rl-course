# -*- coding: utf-8 -*-
"""四区仓库学习器阶梯：每个试验条件的“天花板”，供账本算“离最优还差多少”。

天花板 = 被迫以 ε = 0.05 随机探测时能做到的最好 lifetime 奖励率（对 ε-软策略做相对值迭代：
备份取 (1−ε)·max Q + ε·mean Q）。学习器自己就是 ε-贪婪，所以拿不探测的 r* 比会把 ε 的固定代价
（约 r* 的 5%）也算成“没学会”。天花板假定知道一切（地图、当前规律、电量、灯的含义），
不扣学习期的损失，是上界，不一定达得到。

  python3 demos/crl_ladder_ceiling.py          # 写 assets/crl-ladder-world/ceiling.json
  python3 demos/crl_ladder_ceiling.py --only ch24 [--procs 5]   # 只算第 24 章并并入已有文件（约 17 分钟/点）

各条件的处理：
- 支付延迟（第 17 章）不改变任何策略的奖励率，天花板同底座。
- 局部观测（第 18 章）没有精确天花板（要解 POMDP）；这里用全观测的值，是更松的上界。
- 规律切换（第 15、21、22 章 h > 0）：规律进状态的联合模型（知道当前规律的最优者）。
- 灯的含义翻转（第 20 章 flip）：按含义固定算；翻转平均 1 万步一次，翻转后的重学不计。
- 打滑漂移（第 23 章）：打滑率每 5 万步在 [0.5, 0.9] 里均匀重抽；天花板取各打滑率下天花板的平均（知道当前打滑率）。
- 四件组合（第 24 章 combo）：规律、电量、灯、打滑漂移同时开；联合模型知道当前规律、电量、灯的含义与打滑率，
  打滑率取 [0.5, 0.9] 上 5 个中点的平均（每点约 17 分钟，所以比第 23 章的 17 点少）。
- 门关再开（第 25 章 reopen）：关门期用关门的值、其余用开门的值，按时间加权；另给逐时段的值。
"""
import json
import os
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import crl_ladder_world as LW

OUT = os.path.join(os.path.dirname(HERE), "assets", "crl-ladder-world", "ceiling.json")
EPS = 0.05


def best_eps_soft(model, eps=EPS, tau=0.5, tol=1e-10, it=400000):
    """ε-软策略里最好的奖励率（相对值迭代，跨度收敛到 tol）。"""
    NS, P, R = model["NS"], model["P"], model["R"]
    v = np.zeros(len(R))
    lo = hi = 0.0
    for _ in range(it):
        Q = R + (P * v[NS]).sum(-1)
        d = (1 - eps) * Q.max(1) + eps * Q.mean(1) - v
        lo, hi = d.min(), d.max()
        if hi - lo < tol:
            break
        v = v + tau * d
        v -= v[0]
    return 0.5 * (lo + hi)


def both(model):
    return dict(eps_soft=round(float(best_eps_soft(model)), 6), r_star=round(float(LW.rvi(model)[0]), 6))


def ceilings(steps=2_000_000):
    out = {}
    base = both(LW.build_model(LW.make_cfg()))
    joint = {h: both(LW.build_model(LW.make_cfg(h=h), joint_regime=True)) for h in (1e-4, 1e-3, 1e-2)}
    note_j = "规律进状态的联合模型（知道当前规律）"
    for cap in ("full", "coarse"):
        out[f"ch15/h0-{cap}"] = dict(base, note="底座世界")
        out[f"ch15/h0.001-{cap}"] = dict(joint[1e-3], note=note_j)
    out["ch16/base"] = dict(base, note="底座世界")
    out["ch17/d20"] = dict(base, note="支付延迟不改变奖励率，同底座")
    out["ch18/local"] = dict(base, note="全观测的值，是局部观测的松上界（POMDP 的精确值没有算）")
    out["ch19/battery"] = dict(both(LW.build_model(LW.dial_cfg(19))), note="电量进状态")
    fixed = LW.dial_cfg(20)
    fixed["cue"] = dict(fixed["cue"], h_sign=0.0)
    c20 = both(LW.build_model(fixed))
    out["ch20/fixed"] = dict(c20, note="灯进状态，含义不变")
    out["ch20/flip"] = dict(c20, note="按含义固定算（翻转约 1 万步一次，翻转后重学的损失不计）")
    for h in (1e-3, 1e-2):
        out[f"ch21/h{h:g}"] = dict(joint[h], note=note_j)
    out["ch22/h0"] = dict(base, note="底座世界")
    for h in (1e-4, 1e-3, 1e-2):
        out[f"ch22/h{h:g}"] = dict(joint[h], note=note_j)
    # 第 23 章：打滑率在 [0.5, 0.9] 均匀，取 17 个中点的平均
    c23 = LW.dial_cfg(23)
    ps = 0.5 + 0.4 * (np.arange(17) + 0.5) / 17
    vals = [both(LW.build_model(c23, slip_p=float(p))) for p in ps]
    out["ch23/drift"] = dict(eps_soft=round(float(np.mean([v["eps_soft"] for v in vals])), 6),
                             r_star=round(float(np.mean([v["r_star"] for v in vals])), 6),
                             note="打滑率 [0.5, 0.9] 上 17 个点的平均（知道当前打滑率）")
    # 第 25 章：门 N 在 [20 万, 70 万) 关
    cfg = LW.dial_cfg(25)
    cfg["door"] = None
    op = both(LW.build_model(cfg))
    cfg["door"] = dict(door="N", schedule=[(200_000, 700_000)])
    cl = both(LW.build_model(cfg, door_closed=True))
    w = 500_000 / steps
    out["ch25/control"] = dict(op, note="门一直开")
    out["ch25/reopen"] = dict(eps_soft=round((1 - w) * op["eps_soft"] + w * cl["eps_soft"], 6),
                              r_star=round((1 - w) * op["r_star"] + w * cl["r_star"], 6),
                              note=f"按时间加权：开门 {op['eps_soft']:.4f}、关门 {cl['eps_soft']:.4f}（{steps} 步的 lifetime）",
                              profile=[[0, 200_000, op["eps_soft"]], [200_000, 700_000, cl["eps_soft"]],
                                       [700_000, steps, op["eps_soft"]]])
    out.update(ceiling_ch24())
    return out


def _ch24_point(p):
    return both(LW.build_model(LW.dial_cfg(15, 19, 23), joint_regime=True, slip_p=float(p)))


def ceiling_ch24(procs=1, n=5):
    ps = 0.5 + 0.4 * (np.arange(n) + 0.5) / n
    if procs > 1:
        from multiprocessing import Pool
        with Pool(min(procs, n)) as pool:
            vals = pool.map(_ch24_point, ps)
    else:
        vals = [_ch24_point(p) for p in ps]
    return {"ch24/combo": dict(eps_soft=round(float(np.mean([v["eps_soft"] for v in vals])), 6),
                               r_star=round(float(np.mean([v["r_star"] for v in vals])), 6),
                               note=f"规律、电量、灯、打滑漂移同开；打滑率 [0.5, 0.9] 上 {n} 个点的平均"
                                    "（知道当前规律、灯的含义与打滑率；灯含义翻转后的重学不计）",
                               points=[[round(float(p), 4), v["eps_soft"]] for p, v in zip(ps, vals)])}


def main():
    if "--only" in sys.argv and sys.argv[sys.argv.index("--only") + 1] == "ch24":
        procs = int(sys.argv[sys.argv.index("--procs") + 1]) if "--procs" in sys.argv else 1
        with open(OUT, encoding="utf-8") as f:
            d = json.load(f)
        d["ceilings"].update(ceiling_ch24(procs))
        with open(OUT, "w", encoding="utf-8") as f:
            json.dump(d, f, ensure_ascii=False, indent=1)
        print("ch24/combo", d["ceilings"]["ch24/combo"]); print("written", OUT)
        return
    out = ceilings()
    with open(OUT, "w", encoding="utf-8") as f:
        json.dump(dict(eps=EPS, ceilings=out), f, ensure_ascii=False, indent=1)
    for k, v in out.items():
        print(f"{k:22s} ε-软最好 {v['eps_soft']:.4f}   r* {v['r_star']:.4f}   {v['note']}")
    print("written", OUT)


if __name__ == "__main__":
    main()
