"""四区仓库学习器阶梯：试点估 σ_Δ 定种子数，正式跑后出第 24 章的账本。

所有比较都是配对的：同一个种子 s 下，两档用同一个世界随机数（common random numbers），
差 Δ_s = 率(A, s) − 率(B, s)。配对把世界本身的运气抵掉，σ_Δ 远小于各自的标准差。

  python3 crl_ladder_power.py pilot  --runs pilot-all pilot5m-ch20       # 试点：σ_Δ 与所需对数
  python3 crl_ladder_power.py ledger --runs formal-all formal5m-ch20     # 正式：账本与置信区间

种子数的规矩：n = max(20, ⌈(z_.975 + z_.8)² σ_Δ² / δ²⌉)，δ = 0.002（约为 r* 的 1.5%），
上限 N_CAP。每章一个种子数：该章各比较所需 n 的最大值，封顶 N_CAP。所需 n 超过上限、且按上限算的
95% 区间半宽仍大于 |Δ|（定不了正负）的比较，标“检验力不足”；效应远大于 δ 时 n 超上限也不标。20 的下限来自 Patterson 等（2024）
对强化学习实验的建议（待核：见统一核验与遗留清单）。

判读（账本 ledger 模式）：
- 显著：配对 t 检验的 p 值经 Holm 校正（全账本同一指标的所有比较算一族，族错误率 0.05）后 < 0.05。
  比“95% 区间不含 0”严：一族几十个比较，不校正时纯靠运气也会有一两个“显著”。
- 有意义：显著，且 |Δ| ≥ δ。
- 变化跟踪（结果里有 track 时）：按“距上次变化多少步”分档的奖励率（第 25 章以外取 lifetime 后半，排除学习初期）。
  稳定水平 = 距变化够久（后一半的档，不含最后的“更久”档）的率；
  刚变化后 = 第一档的率；恢复步数 = 3 档滑动平均第一次补回 90%（从刚变化后到稳定水平）的距变化步数；
  每次变化的损失 = Σ_档 (稳定水平 − 该档率) × 该档步数 / 变化次数（只算稳定水平之前的档），单位是“奖励”，
  即每发生一次变化少拿多少奖励。各档之间配对比较这项损失（Holm 校正另算一族）。
- 离最优多远：各档的 lifetime 率与最后 10% 的率都除以天花板（crl_ladder_ceiling.py 算的 ε-软最好率）；
  “补上的差距” = (A − B) / (天花板 − B)，用最后 10% 的率算；
  “到 90% 天花板的步数”：5 万步滑动平均第一次达到 0.9 × 天花板的步数（各种子的中位数，及达到的种子比例）。
"""
import argparse
import json
import math
import os

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
RUNS = os.path.join(os.path.dirname(HERE), "assets", "crl-ladder-world", "runs")
OUTD = os.path.join(os.path.dirname(HERE), "assets", "crl-ladder-world")
DELTA, N_MIN, N_CAP = 0.002, 20, 60
Z975, Z80 = 1.959964, 0.841621


# t 分布 0.975 分位的精确值（df = 1–30）；更大的 df 用 Cornish–Fisher 展开，误差 < 1e-4。
T975 = [12.706, 4.303, 3.182, 2.776, 2.571, 2.447, 2.365, 2.306, 2.262, 2.228, 2.201, 2.179, 2.160, 2.145, 2.131,
        2.120, 2.110, 2.101, 2.093, 2.086, 2.080, 2.074, 2.069, 2.064, 2.060, 2.056, 2.052, 2.048, 2.045, 2.042]


def t975(df):
    if df <= 30:
        return T975[df - 1]
    z = Z975
    return z + (z ** 3 + z) / (4 * df) + (5 * z ** 5 + 16 * z ** 3 + 3 * z) / (96 * df ** 2)


# 第 24 章组合的部件（试验名里的英文，账本里的中文）
COMBO_PARTS = [("context", "情境"), ("battery", "电量"), ("cue", "灯"), ("idbd", "IDBD")]

# 每章的比较：(标签, A, B) 表示 A − B；名字里的 {x} 依次换成条件
COMPARE = [
    ("ch15", ["h0-full", "h0-coarse", "h0.001-full", "h0.001-coarse"],
     [("给定−没有", "given", "none"), ("学到−给定", "learned", "given")]),
    ("ch16", ["base"], [("给定−没有", "given", "none"), ("学到−没有", "learned", "none"), ("学到−给定", "learned", "given")]),
    ("ch17", ["d20"], [("给定−没有", "given", "none"), ("学到−没有", "learned", "none"), ("学到−给定", "learned", "given"),
                       ("迹0.98−没有", "trace0.98", "none")]),
    ("ch18", ["local"], [("给定−没有", "given", "none"), ("学到−给定", "learned", "given"), ("两步历史−没有", "hist2", "none")]),
    ("ch19", ["battery"], [("给定−没有", "given", "none"), ("学到−没有", "learned", "none"), ("学到−给定", "learned", "given"),
                           ("原始电量−没有", "raw", "none"), ("模型 GVF−没有", "model", "none"),
                           ("模型 GVF−学到", "model", "learned"), ("发现问题−没有", "discover", "none"),
                           ("发现问题−模型 GVF", "discover", "model")]),
    ("ch20", ["fixed", "flip"], [("给定−没有", "given", "none"), ("学到−没有", "learned", "none")]),
    ("ch21", ["h0.001", "h0.01"], [("给定−没有", "given", "none"), ("子目标−没有", "learned-sub", "none"),
                                   ("子目标−给定", "learned-sub", "given"), ("eig2−给定", "learned-eig2", "given"),
                                   ("eig4−给定", "learned-eig4", "given"), ("eig8−给定", "learned-eig8", "given")]),
    ("ch22", ["h0", "h0.0001", "h0.001", "h0.01"], [("给定−没有", "given", "none"), ("学到−没有", "learned", "none"),
                                              ("原始+规划−原始", "prim-plan", "prim"), ("选项−原始", "none", "prim")]),
    ("ch23", ["drift"], [("α0.3−α0.1", "alpha0.3", "alpha0.1"), ("α0.03−α0.1", "alpha0.03", "alpha0.1"),
                         ("α0.01−α0.1", "alpha0.01", "alpha0.1"), ("IDBD0.01−α0.1", "idbd0.01", "alpha0.1"),
                         ("IDBD0.001−α0.1", "idbd0.001", "alpha0.1"), ("IDBD0.1−α0.1", "idbd0.1", "alpha0.1"),
                         ("IDBD从.01起−α0.01", "idbd0.01-a0.01", "alpha0.01"), ("IDBD从.3起−α0.3", "idbd0.01-a0.3", "alpha0.3"),
                         ("IDBD0.1从.01起−α0.01", "idbd0.1-a0.01", "alpha0.01"), ("IDBD0.1从.3起−α0.3", "idbd0.1-a0.3", "alpha0.3")]),
    ("ch24", ["combo"], [("全加−都不加", "all", "none")]
     + [(f"只加{z}−都不加", f"only-{x}", "none") for x, z in COMBO_PARTS]
     + [(f"全加−去掉{z}", "all", f"-{x}") for x, z in COMBO_PARTS]
     + [("全加−只加电量", "all", "only-battery"), ("因子化−全加", "sum", "all"), ("共享表−全加", "shared", "all"),
        ("共享表−因子化", "shared", "sum")]),
    ("ch25", ["reopen", "control"], [("给定−没有", "given", "none"), ("学到−没有", "learned", "none"),
                                     ("学到−给定", "learned", "given"), ("Dyna−ε", "none", "eps")]),
]


def load(tags):
    """{(名字, 种子): (lifetime 率, 最后 10% 的率, lifetime 步数)}；同名不同 lifetime 的分开（名字后加 @步数）。"""
    out = {}
    for tag in tags:
        with open(os.path.join(RUNS, tag + ".json"), encoding="utf-8") as f:
            d = json.load(f)
        for r in d["results"]:
            k = max(1, len(r["curve"]) // 10)
            fin = sum(r["curve"][-k:]) / (k * r["steps"] / len(r["curve"]))
            out[(f'{r["name"]}@{r["steps"]}', r["seed"])] = (r["rate"], fin, r["curve"], r["steps"] / len(r["curve"]))
    return out


# ---------------------------------------------------------------- 配对 t 检验的 p 值（不依赖 scipy）
def _betacf(a, b, x, it=300, eps=3e-16):
    qab, qap, qam = a + b, a + 1, a - 1
    c, d = 1.0, 1 - qab * x / qap
    d = 1 / (d if abs(d) > 1e-300 else 1e-300)
    h = d
    for m in range(1, it):
        m2 = 2 * m
        for aa in (m * (b - m) * x / ((qam + m2) * (a + m2)), -(a + m) * (qab + m) * x / ((a + m2) * (qap + m2))):
            d = 1 + aa * d
            d = 1 / (d if abs(d) > 1e-300 else 1e-300)
            c = 1 + aa / c
            c = c if abs(c) > 1e-300 else 1e-300
            h *= d * c
        if abs(d * c - 1) < eps:
            break
    return h


def betainc(a, b, x):
    """正则化不完全贝塔函数 I_x(a, b)（Numerical Recipes 的连分式）。"""
    if x <= 0:
        return 0.0
    if x >= 1:
        return 1.0
    lb = math.lgamma(a + b) - math.lgamma(a) - math.lgamma(b) + a * math.log(x) + b * math.log(1 - x)
    if x < (a + 1) / (a + b + 2):
        return math.exp(lb) * _betacf(a, b, x) / a
    return 1 - math.exp(lb) * _betacf(b, a, 1 - x) / b


def p_two_sided(mean, sd, n):
    if sd == 0:
        return 0.0 if mean != 0 else 1.0
    t = mean / (sd / math.sqrt(n))
    df = n - 1
    return betainc(df / 2, 0.5, df / (df + t * t))


def holm(ps):
    """Holm（1979）逐步校正：返回校正后的 p 值（与输入同序）。"""
    m = len(ps)
    order = sorted(range(m), key=lambda i: ps[i])
    adj, run = [0.0] * m, 0.0
    for k, i in enumerate(order):
        run = max(run, min(1.0, (m - k) * ps[i]))
        adj[i] = run
    return adj


# ---------------------------------------------------------------- 天花板与到达速度
CEIL = os.path.join(OUTD, "ceiling.json")
REACH, SMOOTH = 0.9, 5          # 0.9 × 天花板；5 个记录点（5 万步）的滑动平均


def ceilings():
    if not os.path.exists(CEIL):
        return {}
    with open(CEIL, encoding="utf-8") as f:
        return json.load(f)["ceilings"]


def ceil_curve(c, n, ev):
    """每个记录点的天花板（第 25 章关门期不同）。"""
    if "profile" not in c:
        return np.full(n, c["eps_soft"])
    t = (np.arange(n) + 0.5) * ev
    out = np.full(n, c["eps_soft"])
    for t0, t1, v in c["profile"]:
        out[(t >= t0) & (t < t1)] = v
    return out


def reach_step(curve, ev, cc):
    """5 万步滑动平均第一次达到 REACH × 天花板的步数；没达到返回 None。"""
    x = np.asarray(curve) / ev
    if len(x) < SMOOTH:
        return None
    m = np.convolve(x, np.ones(SMOOTH) / SMOOTH, mode="valid")
    ok = np.flatnonzero(m >= REACH * cc[SMOOTH - 1:])
    return int((ok[0] + SMOOTH) * ev) if len(ok) else None


def tiers(data):
    """各档相对天花板的位置：dict(ch, cond, tier, life, n, ceil, life_ratio, last10, last10_ratio, gap10, reach_med, reach_frac)。"""
    C = ceilings()
    names = sorted({k[0] for k in data})
    rows = []
    for nm in names:
        base, life = nm.split("@")
        ch, cond, tier = base.split("/")
        c = C.get(f"{ch}/{cond}")
        if c is None:
            continue
        seeds = sorted(s for (n, s) in data if n == nm)
        L = np.array([data[(nm, s)][0] for s in seeds])
        F = np.array([data[(nm, s)][1] for s in seeds])
        ev = data[(nm, seeds[0])][3]
        nrec = len(data[(nm, seeds[0])][2])
        cc = ceil_curve(c, nrec, ev)
        # 天花板的 lifetime 值与最后 10% 的值（第 25 章两者不同）
        k = max(1, nrec // 10)
        c_life, c_last = float(cc.mean()), float(cc[-k:].mean())
        rs = [reach_step(data[(nm, s)][2], ev, cc) for s in seeds]
        got = [x for x in rs if x is not None]
        rows.append(dict(ch=ch, cond=cond, tier=tier, life=int(life), n=len(seeds), ceil=c_life, ceil_last=c_last,
                         rate=float(L.mean()), life_ratio=float(L.mean() / c_life),
                         last10=float(F.mean()), last10_ratio=float(F.mean() / c_last), gap10=float(c_last - F.mean()),
                         reach_med=float(np.median(got)) if len(got) * 2 >= len(seeds) else None,
                         reach_frac=len(got) / len(seeds)))
    return rows


# ---------------------------------------------------------------- 变化跟踪
def load_track(tags):
    out = {}
    for tag in tags:
        with open(os.path.join(RUNS, tag + ".json"), encoding="utf-8") as f:
            d = json.load(f)
        for r in d["results"]:
            if r.get("track"):
                out[(f'{r["name"]}@{r["steps"]}', r["seed"])] = r["track"]
    return out


def track_metric(tr, kind):
    """一个种子、一种变化的跟踪量。返回 dict(r0, settled, recover, loss, events) 或 None。"""
    x = tr[kind]
    row = 1                                         # lifetime 后半；门取“门开着”（重开以后）
    S, N, w = np.array(x["sum"][row], float), np.array(x["n"][row], float), x["width"]
    nb = len(S)
    lo, hi = nb // 2, nb - 1
    if N[lo:hi].sum() == 0 or N[0] == 0:
        return None
    rate = np.divide(S, N, out=np.full(nb, np.nan), where=N > 0)
    settled = S[lo:hi].sum() / N[lo:hi].sum()
    r0 = rate[0]
    sm = np.convolve(np.nan_to_num(rate[:lo], nan=settled), np.ones(3) / 3, mode="same")
    ok = np.flatnonzero(sm >= r0 + 0.9 * (settled - r0)) if settled > r0 else np.array([0])
    # 每次变化：lifetime 后半的变化次数按步数比例估（门：重开只有一次）
    ev = 1 if kind == "door" else max(1, x["events"] * N.sum() / max(1, np.sum(x["n"])))
    loss = float(((settled - rate[:lo]) * N[:lo]).sum() / ev)
    return dict(r0=float(r0), settled=float(settled), recover=float((ok[0] + 1) * w) if len(ok) else None,
                loss=loss, events=float(ev))


def track_rows(tags):
    T = load_track(tags)
    if not T:
        return [], []
    tiers_ = []
    names = sorted({k[0] for k in T})
    per = {}
    for nm in names:
        seeds = sorted(s for (n, s) in T if n == nm)
        for kind in T[(nm, seeds[0])]:
            ms = {s: track_metric(T[(nm, s)], kind) for s in seeds}
            ms = {s: m for s, m in ms.items() if m is not None}
            if len(ms) < 2:
                continue
            per[(nm, kind)] = ms
            v = lambda key: [m[key] for m in ms.values() if m[key] is not None]
            rec = v("recover")
            ch, cond, tier = nm.split("@")[0].split("/")
            tiers_.append(dict(ch=ch, cond=cond, tier=tier, life=int(nm.split("@")[1]), kind=kind, n=len(ms),
                               r0=float(np.mean(v("r0"))), settled=float(np.mean(v("settled"))),
                               recover=float(np.median(rec)) if len(rec) * 2 >= len(ms) else None,
                               loss=float(np.mean(v("loss"))),
                               loss_half=float(t975(len(ms) - 1) * np.std(v("loss"), ddof=1) / math.sqrt(len(ms))),
                               events=float(np.mean(v("events")))))
    comps = []
    for ch, conds, cl in COMPARE:
        for (nm, kind), ma in per.items():
            base, life = nm.split("@")
            c0, cond, tier = base.split("/")
            if c0 != ch:
                continue
            for lab, a, b in cl:
                if tier != a:
                    continue
                mb = per.get((f"{ch}/{cond}/{b}@{life}", kind))
                if mb is None:
                    continue
                seeds = sorted(set(ma) & set(mb))
                if len(seeds) < 2:
                    continue
                d = np.array([ma[s]["loss"] - mb[s]["loss"] for s in seeds])
                n, sd = len(d), float(d.std(ddof=1))
                comps.append(dict(ch=ch, cond=cond, comp=lab, kind=kind, life=int(life), n=n, mean=float(d.mean()),
                                  half=float(t975(n - 1) * sd / math.sqrt(n)), p=p_two_sided(float(d.mean()), sd, n)))
    for r, q in zip(comps, holm([r["p"] for r in comps])):
        r["p_holm"], r["sig"] = q, q < 0.05
    print("\n变化跟踪（lifetime 后半；门取重开以后）：刚变化后 → 稳定水平，恢复 90% 的步数，每次变化少拿的奖励")
    for r in tiers_:
        rc = f"{r['recover']:.0f}" if r["recover"] is not None else "—"
        print(f"  {r['ch']:5s} {r['cond']:14s} {r['tier']:14s} {r['kind']:6s} 步数 {r['life']:8d} n={r['n']:2d} "
              f"{r['r0']:.4f} → {r['settled']:.4f}  恢复 {rc:>6s} 步  每次损失 {r['loss']:7.2f} ± {r['loss_half']:.2f}  变化 {r['events']:.0f} 次")
    if comps:
        print("  配对比较（每次变化的损失，A − B；负数 = A 恢复得更好）")
        for r in comps:
            print(f"  {r['ch']:5s} {r['cond']:14s} {r['comp']:16s} {r['kind']:6s} n={r['n']:2d} {r['mean']:+8.2f} ± {r['half']:.2f}  "
                  f"p(Holm) {r['p_holm']:.1e} {'显著' if r['sig'] else '不显著'}")
    return tiers_, comps


def show_tiers(rows):
    print(f"\n各档离天花板多远（天花板 = ε-软最好率；到达 = 5 万步滑动平均 ≥ {REACH:g} × 天花板）")
    print(f"{'章':5s} {'条件':14s} {'档':14s} {'步数':>8s} {'n':>3s} {'天花板':>7s} {'lifetime':>8s} {'占比':>6s} {'最后10%':>8s} {'占比':>6s} {'差距':>7s} {'到达步数':>10s} {'达到比例':>6s}")
    for r in rows:
        rm = f"{r['reach_med']:.0f}" if r["reach_med"] is not None else "—"
        print(f"{r['ch']:5s} {r['cond']:14s} {r['tier']:14s} {r['life']:8d} {r['n']:3d} {r['ceil']:.4f} {r['rate']:8.4f} {r['life_ratio']:6.1%} "
              f"{r['last10']:8.4f} {r['last10_ratio']:6.1%} {r['gap10']:7.4f} {rm:>10s} {r['reach_frac']:6.0%}")


def pairs(data):
    """逐条比较算配对差。返回列表：dict(章, 条件, 比较, lifetime 步数, n, mean, sd, ci, need)。"""
    lives = sorted({k[0].split("@")[1] for k in data})
    C = ceilings()
    rows = []
    for ch, conds, comps in COMPARE:
        for life in lives:
            for c in conds:
                for lab, a, b in comps:
                    na, nb = f"{ch}/{c}/{a}@{life}", f"{ch}/{c}/{b}@{life}"
                    seeds = sorted({s for (n, s) in data if n == na} & {s for (n, s) in data if n == nb})
                    if len(seeds) < 2:
                        continue
                    for which, idx in (("life", 0), ("last10", 1)):
                        d = np.array([data[(na, s)][idx] - data[(nb, s)][idx] for s in seeds])
                        n = len(d)
                        sd = float(d.std(ddof=1))
                        need = max(N_MIN, math.ceil((Z975 + Z80) ** 2 * sd ** 2 / DELTA ** 2))
                        rows.append(dict(ch=ch, cond=c, comp=lab, a=a, b=b, life=int(life), metric=which, n=n,
                                         mean=float(d.mean()), sd=sd, half=float(t975(n - 1) * sd / math.sqrt(n)),
                                         need=need,
                                         # 检验力不足：区间含 0，且按 σΔ 算要的种子比实际用的多
                                         capped=need > n and abs(float(d.mean())) < t975(n - 1) * sd / math.sqrt(n),
                                         # 恒等：两档逐种子完全相同（构造上是同一个学习器），这一行不是测量
                                         ident=bool(np.all(d == 0)),
                                         ra=float(np.mean([data[(na, s)][idx] for s in seeds])),
                                         rb=float(np.mean([data[(nb, s)][idx] for s in seeds])),
                                         p=p_two_sided(float(d.mean()), sd, n)))
                        r = rows[-1]
                        cc = C.get(f"{ch}/{c}")
                        if cc is not None and which == "last10" and b in ("none", "eps", "prim", "alpha0.1"):
                            nrec = len(data[(na, seeds[0])][2])
                            top = float(ceil_curve(cc, nrec, data[(na, seeds[0])][3])[-max(1, nrec // 10):].mean())
                            r["gap_closed"] = r["mean"] / (top - r["rb"]) if top - r["rb"] > 1e-9 else None
    # Holm 校正：每个指标（lifetime、最后 10%）各算一族；恒等行不算测量，不进族
    for which in ("life", "last10"):
        fam = [r for r in rows if r["metric"] == which and not r["ident"]]
        for r, q in zip(fam, holm([r["p"] for r in fam])):
            r["p_holm"] = q
            r["sig"] = q < 0.05
            r["meaningful"] = r["sig"] and abs(r["mean"]) >= DELTA
    return rows


def show(rows, metric="life"):
    print(f"{'章':5s} {'条件':14s} {'比较':16s} {'步数':>8s} {'n':>3s} {'A':>7s} {'B':>7s} {'Δ':>8s} {'±95%':>7s} {'σΔ':>7s} {'需要n':>5s} {'p(Holm)':>8s} {'补上':>6s} 判读")
    for r in rows:
        if r["metric"] != metric:
            continue
        flag = " 恒等（构造上相同，不是测量）" if r.get("ident") else " 检验力不足" if r["capped"] else ""
        verdict = "" if r.get("ident") else "有意义" if r.get("meaningful") else "显著但小于δ" if r.get("sig") else "不显著"
        ph = f"{r['p_holm']:.1e}" if "p_holm" in r else "—"
        gc = f"{r['gap_closed']:+.0%}" if r.get("gap_closed") is not None else "—"
        print(f"{r['ch']:5s} {r['cond']:14s} {r['comp']:16s} {r['life']:8d} {r['n']:3d} {r['ra']:.4f} {r['rb']:.4f} "
              f"{r['mean']:+.4f} {r['half']:.4f} {r['sd']:.4f} {r['need']:5d} {ph:>8s} {gc:>6s} {verdict}{flag}")


def combo_interaction(data):
    """第 24 章的交互项：逐种子算 (全加 − 都不加) − Σ_部件 (只加该部件 − 都不加)。
    各部件的增益若可以相加，交互项为 0；负值表示放在一起比各自单加的和差。"""
    out = []
    for life in sorted({k[0].split("@")[1] for k in data}):
        nm = lambda t: f"ch24/combo/{t}@{life}"
        need = ["all", "none"] + [f"only-{x}" for x, _ in COMBO_PARTS]
        seeds = sorted(set.intersection(*[{s for (n, s) in data if n == nm(t)} for t in need]))
        if len(seeds) < 2:
            continue
        for which, idx in (("life", 0), ("last10", 1)):
            v = lambda t, s: data[(nm(t), s)][idx]
            tot = np.array([v("all", s) - v("none", s) for s in seeds])
            parts = np.array([sum(v(f"only-{x}", s) - v("none", s) for x, _ in COMBO_PARTS) for s in seeds])
            d = tot - parts
            n = len(d)
            sd = float(d.std(ddof=1))
            out.append(dict(life=int(life), metric=which, n=n, total=float(tot.mean()), sum_parts=float(parts.mean()),
                            interaction=float(d.mean()), half=float(t975(n - 1) * sd / math.sqrt(n)),
                            p=p_two_sided(float(d.mean()), sd, n)))
            r = out[-1]
            print(f"第 24 章交互项（{which}，{life} 步，n={n}）：全加 − 都不加 {r['total']:+.4f}；各部件单加增益之和 "
                  f"{r['sum_parts']:+.4f}；交互 {r['interaction']:+.4f} ± {r['half']:.4f}（p={r['p']:.1e}，未校正）")
    return out


REOPEN_WIN = [("关门期", 200_000, 700_000), ("重开后头 30 万步", 700_000, 1_000_000),
              ("重开后 100–130 万步", 1_700_000, 2_000_000)]


def reopen_rows(tags):
    """第 25 章预言 3 要看的量：门关、重开以后，每档相对对照（门一直开）的每步损失，按时间窗分开。
    lifetime 率把关门期的损失（各档相同）和重开以后的损失混在一起，读不出“没有探测的损失随剩余 lifetime 线性增长”。"""
    cur = {}
    for tag in tags:
        path = os.path.join(RUNS, tag + ".json")
        with open(path, encoding="utf-8") as f:
            d = json.load(f)
        for r in d["results"]:
            if r["name"].startswith("ch25/"):
                cur[(r["name"], r["seed"])] = (np.array(r["curve"]), r["steps"] / len(r["curve"]))
    rows = []
    for tier in ("eps", "none", "given", "learned"):
        a, b = f"ch25/reopen/{tier}", f"ch25/control/{tier}"
        seeds = sorted({s for (n, s) in cur if n == a} & {s for (n, s) in cur if n == b})
        if len(seeds) < 2:
            continue
        for lab, t0, t1 in REOPEN_WIN:
            loss = []
            for s in seeds:
                (ca, ev), (cb, _) = cur[(a, s)], cur[(b, s)]
                i0, i1 = int(t0 / ev), int(t1 / ev)
                if i1 > len(ca):
                    break
                loss.append((cb[i0:i1].sum() - ca[i0:i1].sum()) / (t1 - t0))
            if len(loss) < 2:
                continue
            x = np.array(loss)
            n = len(x)
            rows.append(dict(tier=tier, win=lab, t0=t0, t1=t1, n=n, mean=float(x.mean()), sd=float(x.std(ddof=1)),
                             half=float(t975(n - 1) * x.std(ddof=1) / math.sqrt(n))))
    if rows:
        print("\n第 25 章：每步损失 = 对照 − 关门再重开（同一种子、同一档；正数是损失）")
        for r in rows:
            print(f"  {r['tier']:8s} {r['win']:18s} n={r['n']:3d}  {r['mean']:+.4f} ± {r['half']:.4f}")
    return rows


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("mode", choices=["pilot", "ledger"])
    ap.add_argument("--runs", nargs="+", required=True)
    a = ap.parse_args()
    if a.mode == "pilot" and any(t.startswith("formal") for t in a.runs):
        ap.error("pilot 模式只读试点数据；power-pilot.json 是定种子数的依据，不能被正式数据覆盖。正式数据用 ledger。")
    miss = [t for t in a.runs if not os.path.exists(os.path.join(RUNS, t + ".json"))]
    for t in miss:
        print(f"没有 {os.path.relpath(os.path.join(RUNS, t + '.json'))}：先跑相应的实验（正式设置是 --tag formal 那一行）")
    a.runs = [t for t in a.runs if t not in miss]
    if not a.runs:
        return
    data = load(a.runs)
    rows = pairs(data)
    show(rows, "life")
    print("\n最后 10% 的率：")
    show(rows, "last10")
    # 只看一章时另存，免得覆盖全课的 ledger.json
    out = os.path.join(OUTD, "power-pilot.json" if a.mode == "pilot" else
                       "ledger.json" if len(a.runs) > 1 else f"ledger-{a.runs[0]}.json")
    life_rows = [r for r in rows if r["metric"] == "life"]
    summary = dict(delta=DELTA, n_min=N_MIN, n_cap=N_CAP, runs=a.runs, rows=rows)
    if a.mode == "ledger":
        summary["ch25_reopen"] = reopen_rows(a.runs)
        summary["ch24_interaction"] = combo_interaction(data)
        summary["tiers"] = tiers(data)
        summary["reach"], summary["smooth_records"] = REACH, SMOOTH
        show_tiers(summary["tiers"])
        summary["track_tiers"], summary["track_comps"] = track_rows(a.runs)
    if a.mode == "pilot":
        summary["n_formal"] = min(N_CAP, max(r["need"] for r in life_rows)) if life_rows else N_MIN
        summary["sd_median"] = float(np.median([r["sd"] for r in life_rows])) if life_rows else None
        summary["n_by_ch"] = {ch: min(N_CAP, max(r["need"] for r in life_rows if r["ch"] == ch))
                              for ch in sorted({r["ch"] for r in life_rows})}
        print("各章正式种子数：", summary["n_by_ch"])
        print(f"\n正式种子数（所有 lifetime 比较所需的最大值，封顶 {N_CAP}）：{summary['n_formal']}；σ_Δ 中位数 {summary['sd_median']:.4f}")
    with open(out, "w", encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=1)
    print("written", out)


if __name__ == "__main__":
    main()
