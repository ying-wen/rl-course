# -*- coding: utf-8 -*-
"""四区仓库的学习器阶梯（例子方案第三步）。

每一级在它对应的档位下比三档：“没有”、“设计者给定”、“从经验学到”。
阶梯不是逐级累加的：第 15–16 章的底座是折扣 Q 学习，第 17 章起的底座是差分 Q 学习（L2），
每章只在底座上加这一章的一种能力，所以每一行是“单加一种能力”的消融比较；
“没有”指底座本身，不含前几章的能力（第 21–22、25 章另用 OptionAgent / ProbeAgent，见各试验的注释）。
学习器只读观测与奖励；env.info() 只供评价，学习器不读。
成绩 = lifetime 奖励率（lifetime 的总奖励 / 步数，学习期间的损失也算在内）。
同一种子下各档用同一个世界随机数（配对比较），学习器另用自己的随机数。

本文件：共用的表格学习器、各章的状态函数与三档、试验定义、并行运行器。
用法：
  python3 demos/crl_ladder_learners.py --exp ch15 --seeds 5 --steps 300000
  python3 demos/crl_ladder_learners.py --exp all --seeds 20
输出：assets/crl-ladder-world/runs/<试验>.json
"""
import argparse, json, os, sys, time
from collections import deque
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import crl_ladder_world as LW

OUT = os.path.join(os.path.dirname(HERE), "assets", "crl-ladder-world", "runs")
NA = 4
EPS = 0.05
ALPHA = 0.1
ETA = 0.1          # 平均奖励的步长 = ETA * ALPHA
LAM = 0.9


# ======================================================================== 共用的表格学习器
OPT = dict(disc09=3.0, disc099=15.0, rbar0=1.0, eta=0.001)   # 乐观初值（第一部分的工具；高一档的试过，更慢）


class Tab:
    """表格值学习器。method:
      'q'      一步 Q 学习（折扣 gamma，或 gamma=None 时为差分 Q 学习，Wan、Naik 与 Sutton 2021）
      'sarsa'  Sarsa(λ)，替换迹（差分或折扣）
    步长：alpha 为常数；alpha='count' 时按 1/n(s,a) 退火到 0。
    """

    def __init__(self, rng, method="q", gamma=None, alpha=ALPHA, lam=0.0, eps=EPS, n_init=1024, freeze_at=None, q0=0.0, rbar0=0.0, eta=ETA, theta=0.01, alpha0=ALPHA):
        self.rng, self.method, self.gamma, self.alpha, self.lam, self.eps = rng, method, gamma, alpha, lam, eps
        self.freeze_at, self.n = freeze_at, 0
        self.q0, self.eta = float(q0), eta
        self.Q = np.full((n_init, NA), self.q0)
        self.N = np.zeros((n_init, NA)) if alpha == "count" else None
        self.theta, self.logA0 = theta, float(np.log(alpha0))
        self.B = np.full((n_init, NA), self.logA0) if alpha == "idbd" else None   # log 步长，从 alpha0 起
        self.H = np.zeros((n_init, NA)) if alpha == "idbd" else None
        self.rbar = float(rbar0)
        self.trace = {}
        self.ps = None
        self.pa = None

    def _grow(self, s):
        if s >= len(self.Q):
            k = max(s + 1, 2 * len(self.Q))
            Q = np.full((k, NA), self.q0); Q[:len(self.Q)] = self.Q; self.Q = Q
            if self.N is not None:
                Nn = np.zeros((k, NA)); Nn[:len(self.N)] = self.N; self.N = Nn
            if self.B is not None:
                B = np.full((k, NA), self.logA0); B[:len(self.B)] = self.B; self.B = B
                H = np.zeros((k, NA)); H[:len(self.H)] = self.H; self.H = H

    def greedy(self, s):
        q = self.Q[s]
        m = q.max()
        b = np.flatnonzero(q == m)
        return int(b[0]) if len(b) == 1 else int(b[self.rng.integers(len(b))])

    def choose(self, s):
        if self.rng.random() < self.eps:
            return int(self.rng.integers(NA))
        return self.greedy(s)

    def _a(self, s, a):
        if self.N is None:
            return self.alpha
        self.N[s, a] += 1
        return 1.0 / self.N[s, a]

    def step(self, s, r):
        """s：当前状态编号；r：上一个动作得到的奖励。返回这一步的动作。"""
        self._grow(s)
        self.n += 1
        if self.freeze_at is not None and self.n > self.freeze_at:
            self.ps = None
            return self.choose(s)
        if self.method == "q":
            if self.ps is not None:
                self.update_q(self.ps, self.pa, r, s)
            a = self.choose(s)
        else:
            a = self.choose(s)
            if self.ps is not None:
                self.update_sarsa(self.ps, self.pa, r, s, a)
        self.ps, self.pa = s, a
        return a

    def update_q(self, s, a, r, s2, alpha=None):
        if self.B is not None:
            return self._update_idbd(s, a, r, s2)
        al = self._a(s, a) if alpha is None else alpha
        if self.gamma is None:
            d = r - self.rbar + self.Q[s2].max() - self.Q[s, a]
            self.rbar += self.eta * al * d
        else:
            d = r + self.gamma * self.Q[s2].max() - self.Q[s, a]
        self.Q[s, a] += al * d
        return d

    def _update_idbd(self, s, a, r, s2):
        """表格 IDBD（Sutton 1992；TD 形式见 Kearney 等 2019 的 TIDBD，这里 λ=0）：每个 (s, a) 一个对数步长。"""
        d = r - self.rbar + self.Q[s2].max() - self.Q[s, a]
        self.B[s, a] = min(0.0, max(-9.0, self.B[s, a] + self.theta * d * self.H[s, a]))
        al = float(np.exp(self.B[s, a]))
        self.Q[s, a] += al * d
        self.H[s, a] = self.H[s, a] * max(0.0, 1.0 - al) + al * d
        self.rbar += self.eta * al * d
        return d

    def update_sarsa(self, s, a, r, s2, a2):
        al = self._a(s, a)
        if self.gamma is None:
            d = r - self.rbar + self.Q[s2, a2] - self.Q[s, a]
            self.rbar += self.eta * al * d
            g = self.lam
        else:
            d = r + self.gamma * self.Q[s2, a2] - self.Q[s, a]
            g = self.gamma * self.lam
        tr = self.trace
        for b in range(NA):                      # 替换迹：同一状态的其他动作清零
            tr.pop(s * NA + b, None)
        tr[s * NA + a] = 1.0
        Qf = self.Q.reshape(-1)
        dead = []
        for k, e in tr.items():
            Qf[k] += al * d * e
            e *= g
            if e < 1e-3:
                dead.append(k)
            else:
                tr[k] = e
        for k in dead:
            del tr[k]


class Indexer:
    """把任意可哈希的特征元组编成连续整数。"""

    def __init__(self):
        self.d = {}

    def __call__(self, key):
        i = self.d.get(key)
        if i is None:
            i = self.d[key] = len(self.d)
        return i


# ======================================================================== 智能体：观测 → 状态 → 表格学习器
class Agent:
    """默认智能体：状态 = 观测里的若干分量。子类改 state() 或 step()。"""

    def __init__(self, rng, learner, keep=(0, 1), cell_map=None):
        self.rng, self.L, self.keep, self.cell_map, self.ix = rng, learner, keep, cell_map, Indexer()

    def state(self, obs, r):
        key = tuple(obs[i] for i in self.keep)
        if self.cell_map is not None:
            key = (self.cell_map[key[0]],) + key[1:]
        return self.ix(key)

    def step(self, obs, r):
        return self.L.step(self.state(obs, r), r)


def coarse_map(block=2):
    """容量不足：把格子按 block×block 的方块合并（第 15 章容量档）。"""
    ids = Indexer()
    return [ids((r // block, c // block)) for (r, c) in LW.CELLS]


# ---------------------------------------------------------------- 第 15 章：情境（规律）由支付的意外发现
def match_context(ctx, c, j, r, tol, recent=()):
    """意外之后换到哪个情境：返回已有情境的序号，没有相符的返回 None（新建）。
    候选 = 在站 j 记过、且与这次支付 r 相符的其他情境。recent 为空时取第一个候选（11-20 以前的做法）；
    否则按最近几次交货 (站, 支付) 打分：相符 +1、不符 −1、没记过 0，取分最高者（11-20 加的“窗口匹配”）。
    只看一站时，几个规律在这一站付得一样（例如灯控制的 B 站在每个规律里都一样），会先跳到错的情境，
    下一次交货再意外，来回换；最近几站一起看，就少跳错。"""
    cand = [i for i, x in enumerate(ctx) if i != c and j in x["pay"] and abs(x["pay"][j] - r) <= tol]
    if not cand:
        return None
    if not recent:
        return cand[0]
    def score(i):
        pay = ctx[i]["pay"]
        return sum(0 if k not in pay else (1 if abs(pay[k] - v) <= tol else -1) for k, v in recent)
    return max(cand, key=lambda i: (score(i), -i))


class ContextAgent(Agent):
    """从经验学到的跟踪：按交货支付的意外识别当前规律，每个情境一张 Q 表（RL-CD 的简化版）。
    支付与上次在同一情境同一站看到的不同 → 换到与之相符的已有情境，否则新建（复制当前表）。
    window > 0 时按最近 window 次交货挑情境（见 match_context）；默认 0 与正式运行相同。"""

    def __init__(self, rng, make_learner, keep=(0, 1), cell_map=None, tol=0.1, max_ctx=6, window=0):
        super().__init__(rng, make_learner(), keep, cell_map)
        self.make = make_learner
        self.ctx = [dict(pay={}, L=self.L)]
        self.c = 0
        self.tol, self.max_ctx = tol, max_ctx
        self.n_switch = 0
        self.recent = deque(maxlen=window) if window else None

    def step(self, obs, r):
        if r > 0:                                  # 交货：obs[1] 是刚交货的站
            j = obs[1]
            cur = self.ctx[self.c]
            if j in cur["pay"] and abs(cur["pay"][j] - r) > self.tol:
                m = match_context(self.ctx, self.c, j, r, self.tol, self.recent or ())
                if m is not None:
                    new = m
                elif len(self.ctx) < self.max_ctx:
                    L = self.make()
                    L.Q = self.L.Q.copy(); L.rbar = self.L.rbar
                    self.ctx.append(dict(pay={}, L=L))
                    new = len(self.ctx) - 1
                else:
                    new = self.c
                if new != self.c:                  # 上一步的更新交给新情境的表
                    L = self.ctx[new]["L"]
                    L.ps, L.pa = self.L.ps, self.L.pa
                    if L.ps is not None:           # 新表可能比带过来的状态号小（第 24 章组合里遇到过）
                        L._grow(L.ps)
                    self.L.ps = None
                    self.c, self.L = new, L
                    self.n_switch += 1
            self.ctx[self.c]["pay"][j] = r
            if self.recent is not None:
                self.recent.append((j, r))
        return self.L.step(self.state(obs, r), r)


# ---------------------------------------------------------------- 第 17 章：时滞（设计者给定 / 从经验学到）
class LagAgent(Agent):
    """把这一步到账的奖励记给 D 步之前的 (s, a)。
    D 给定（设计者知道支付晚 D 步）；或 D=None：从经验学时滞——对每个 d ∈ 0..Dmax 同时学
    r̂_d(s, a)（用 d+1 步前的 (s, a) 预测这一步到账的奖励），预测误差的滑动平均最小者为 D̂，
    每 every 步重选一次。不用地图，也不用“交货”这个概念。"""

    def __init__(self, rng, learner, D=None, Dmax=40, keep=(0, 1), every=5000):
        super().__init__(rng, learner, keep)
        self.D, self.Dmax, self.every = D, Dmax, every
        self.Dhat = 0 if D is None else D
        self.buf = deque(maxlen=max(self.Dhat, Dmax if D is None else 0) + 2)
        if D is None:
            self.Rh = np.zeros((Dmax + 1, 1024, NA))
            self.err = np.zeros(Dmax + 1)
            self.t = 0
            self.ar = np.arange(Dmax + 1)

    def _learn_lag(self, r):
        if len(self.buf) < self.Dmax + 1:
            return
        b = list(self.buf)[-(self.Dmax + 1):][::-1]          # b[d] = (s_{t-1-d}, a_{t-1-d})
        sb = np.fromiter((x[0] for x in b), int, len(b))
        ab = np.fromiter((x[1] for x in b), int, len(b))
        if sb.max() >= self.Rh.shape[1]:
            Rh = np.zeros((self.Dmax + 1, 2 * sb.max() + 2, NA)); Rh[:, :self.Rh.shape[1]] = self.Rh; self.Rh = Rh
        e = r - self.Rh[self.ar, sb, ab]
        self.Rh[self.ar, sb, ab] += 0.05 * e
        self.err += 0.001 * (e * e - self.err)
        self.t += 1
        if self.t % self.every == 0:
            self.Dhat = int(self.err.argmin())

    def step(self, obs, r):
        s = self.state(obs, r)
        L = self.L
        L._grow(s)
        L.n += 1
        if self.D is None:
            self._learn_lag(r)
        D = self.Dhat
        if len(self.buf) >= D + 1:
            s0, a0 = self.buf[-1 - D]
            s1 = self.buf[-D][0] if D > 0 else s
            L.update_q(s0, a0, r, s1)
        a = L.choose(s)
        self.buf.append((s, a))
        return a


# ---------------------------------------------------------------- 第 18 章：局部观测下的状态
class LocalAgent(Agent):
    """obs = (8 位墙码, 脚下站标 0–4)。mode:
      'none'     只看观测（无记忆）；
      'given'    观测 + 设计者给的记忆“上次交货的站”（脚下站标非 0 时更新）；
      'learned'  观测 + 通用记忆“最近一次得到奖励时的观测”（不知道有站这回事）；
      'hist2'    观测 + 前两步的观测（通用短历史，对照用）。"""

    def __init__(self, rng, learner, mode):
        super().__init__(rng, learner)
        self.mode = mode
        self.mem = None
        self.h1 = self.h2 = None

    def step(self, obs, r):
        o = (obs[0], obs[1])
        if self.mode == "given" and obs[1] > 0:
            self.mem = obs[1]
        if self.mode == "learned" and r != 0:
            self.mem = o
        if self.mode == "none":
            key = o
        elif self.mode == "hist2":
            key = (o, self.h1, self.h2)
            self.h2, self.h1 = self.h1, o
        else:
            key = (o, self.mem)
        return self.L.step(self.ix(key), r)


# ---------------------------------------------------------------- 第 19 章：电量
class BatteryAgent(Agent):
    """obs = (格, last, b, 拖车中)。mode: 'none' 不看电量；'raw' 看原始电量（对照：表大 41 倍）；
    'given' 看“电量 − 期望到桩步数”分档（设计者知道地图和打滑，按值迭代算）；
    'learned' 看“电量 − 学到的到桩步数”分档（GVF：累积量 1、到桩终止，离策略按最短学）。"""
    BINS = (2, 6, 15)

    def __init__(self, rng, learner, mode, charger):
        super().__init__(rng, learner)
        self.mode, self.charger = mode, charger
        self.G = np.full((LW.N, NA), 0.0)
        self.prev = None
        self.D = self.expected_steps(charger, LW.dial_cfg(19)["slip_p"])

    @staticmethod
    def expected_steps(charger, p):
        """设计者知道地图和打滑：按最优走法到桩的期望步数（值迭代）。"""
        nxt = LW.next_table()
        P = np.full((NA, NA), (1 - p) / 3); np.fill_diagonal(P, p)   # P[a, d]
        E = np.zeros(LW.N)
        for _ in range(5000):
            E2 = 1.0 + (E[nxt] @ P.T).min(1)                          # E[nxt][i, d] · P[a, d]
            E2[charger] = 0.0
            if np.abs(E2 - E).max() < 1e-9:
                break
            E = E2
        return E

    def step(self, obs, r):
        cell, last, b, tow = obs
        if self.mode == "learned" and self.prev is not None and not tow:
            c0, a0 = self.prev
            tgt = 1.0 + (0.0 if cell == self.charger else self.G[cell].min())
            self.G[c0, a0] += 0.1 * (tgt - self.G[c0, a0])
        if tow:
            key = ("tow", last)
        elif self.mode == "none":
            key = (cell, last)
        elif self.mode == "raw":
            key = (cell, last, b)
        elif self.mode == "given":
            key = (cell, last, int(np.searchsorted(self.BINS, b - self.D[cell])))
        else:
            m = b - self.G[cell].min()
            key = (cell, last, int(np.searchsorted(self.BINS, m)))
        a = self.L.step(self.ix(key), r)
        self.prev = None if tow else (cell, a)
        return a


class GVFModel:
    """模型式 GVF：从经验数转移 (格, 动作) → 下一格，在学到的模型上做值迭代，算“到 X 的期望步数”
    （累积量 1、到 X 终止、按最短走法的 GVF）。每 every 步重算一次（Dyna 的想法用在预测上：
    一次真实转移通过模型影响所有格的预测，不必每格每动作都亲自走很多遍）。没见过的 (格, 动作) 不参与取最小。"""

    def __init__(self, targets, every=10000, tol=1e-3, max_it=400):
        self.C = np.zeros((LW.N, NA, LW.N))
        self.targets = list(targets)
        self.E = np.zeros((len(self.targets), LW.N))
        self.every, self.tol, self.max_it, self.t = every, tol, max_it, 0
        self.reached = set()

    def observe(self, c0, a0, c1):
        self.C[c0, a0, c1] += 1
        self.reached.add(c1)
        self.t += 1
        if self.t % self.every == 0:
            self.solve()

    def solve(self):
        n = self.C.sum(2)
        P = self.C / np.maximum(n, 1)[..., None]
        unseen = n == 0
        for i, x in enumerate(self.targets):
            if x not in self.reached:
                continue
            E = self.E[i].copy()
            for _ in range(self.max_it):
                Q = 1.0 + P @ E
                Q[unseen] = np.inf
                E2 = Q.min(1)
                bad = ~np.isfinite(E2)
                E2[bad] = E[bad]
                E2[x] = 0.0
                if np.abs(E2 - E).max() < self.tol:
                    E = E2
                    break
                E = E2
            self.E[i] = E


class BatteryModelAgent(BatteryAgent):
    """第 19 章的两个新档（与 BatteryAgent 同样的分档特征“电量 − 到某处的期望步数”）：
    'model'     问题给定（到充电桩），答案用模型式 GVF 学（GVFModel），代替逐格 TD；
    'discover'  问题也不给：候选问题 = “到 X 的步数”，X 取 4 个门、4 个站，外加“不减步数”（只看电量）共 9 个，
                全部用同一个学到的模型回答。生成与检验：每个候选在电量之外对“接下来 H 步内被拖车”多解释的 R²
                （见 _test），每 WIN 步一个窗口、窗口间指数平均；最高分超过门槛且是第二名的 RATIO 倍才换用它。
                被拖车是观测里看得到的坏事（obs 的拖车位）；学习器不知道哪一格是桩。"""
    WIN, THR, RATIO, EMA, H = 5000, 0.001, 1.5, 0.2, 15

    def __init__(self, rng, learner, mode, charger, learner_maker=None):
        super().__init__(rng, learner, "given" if mode == "model" else "none", charger)
        self.mode2 = mode
        if mode == "model":
            self.M = GVFModel([charger])
        else:
            self.make = learner_maker
            self.cands = [LW.IDX[LW.DOORS[d]] for d in "NWES"] + list(LW.ST_CELL)
            self.M = GVFModel(self.cands)
            self.nc = len(self.cands) + 1                     # 最后一个候选：只看电量
            self.buf = deque()
            self.win = np.zeros((self.nc, (len(self.BINS) + 1) ** 2, 2))
            self.score = np.zeros(self.nc)
            self.sel = None
            self.Ls = {None: self.L}
            self.t = 0
            self.ptow = 0

    def _bins(self, cell, b):
        m = list(b - self.M.E[:, cell]) + [float(b)]
        return np.searchsorted(self.BINS, m)

    def _jbins(self, cell, b):
        nb = len(self.BINS) + 1
        bb = self._bins(cell, b)
        return bb[-1] * nb + bb

    def _test(self):
        """R²（组间方差/总方差）按“电量档 × 候选档”的联合分组算，再减去只按电量档分组的 R²：
        量的是“知道到 X 的步数，在电量之外多解释了多少”。只看电量的候选增益为 0。"""
        W = self.win
        n = W.sum(2)
        tot_n = n.sum(1)
        y1 = W[:, :, 1].sum(1)
        p = y1 / np.maximum(tot_n, 1)
        tot = tot_n * p * (1 - p)
        pb = W[:, :, 1] / np.maximum(n, 1)
        bet = (n * (pb - p[:, None]) ** 2).sum(1)
        ws = np.where(tot > 1e-9, bet / np.maximum(tot, 1e-12), 0.0)
        ws = ws - ws[-1]
        if y1.max() > 0:                                       # 窗口里没有拖车就不更新分数
            self.score += self.EMA * (ws - self.score)
        self.win[:] = 0
        order = np.argsort(self.score)[::-1]
        best, second = int(order[0]), self.score[order[1]]
        # 增益都很小（拖车少），所以用相对门槛：最好的要明显高过第二名
        new = best if self.score[best] > max(self.THR, self.RATIO * second) else self.sel
        if new != self.sel:
            if new not in self.Ls:
                self.Ls[new] = self.make()
            self.L.ps = None
            self.sel, self.L = new, self.Ls[new]

    def step(self, obs, r):
        cell, last, b, tow = obs
        if self.prev is not None and not tow:
            self.M.observe(self.prev[0], self.prev[1], cell)
        if self.mode2 == "model":
            self.D = self.M.E[0]
            a = super().step(obs, r)
            return a
        # discover：记录每步各候选的档，H 步后结算“这期间有没有开始拖车”
        self.t += 1
        if tow and not self.ptow:
            for e in self.buf:
                e[1] = 1
        self.ptow = tow
        if not tow:
            self.buf.append([self._jbins(cell, b), 0])
        while self.buf and (len(self.buf) > self.H):
            bins, y = self.buf.popleft()
            self.win[np.arange(self.nc), bins, y] += 1
        if self.t % self.WIN == 0:
            self._test()
        if tow:
            key = ("tow", last)
        elif self.sel is None:
            key = (cell, last)
        else:
            key = (cell, last, int(self._bins(cell, b)[self.sel]))
        a = self.L.step(self.ix(key), r)
        self.prev = None if tow else (cell, a)
        return a


# ---------------------------------------------------------------- 第 20 章：指示灯
class CueAgent(Agent):
    """obs = (格, last, 灯)。学习器另有 3 个无关的“灯”（自己的随机数，同样每步以 0.01 翻转），
    容量只许加 1 个特征。mode: 'none' 不加；'given' 设计者加真灯；
    'learned' 生成与检验：每 5000 步一个窗口，在窗口内算每个候选对各站支付的解释度 R²
    （组间方差 / 总方差；灯的含义会翻转，所以只在窗口内比、不跨窗口平均条件均值），
    窗口间做指数平均，选分最高者（低于门槛 0.5 则不加）。"""
    WIN, THR, EMA = 5000, 0.5, 0.2

    def __init__(self, rng, learner_maker, mode, n_distract=3, p_flip=0.01):
        self.make = learner_maker
        super().__init__(rng, learner_maker())
        self.mode = mode
        self.nd, self.pf = n_distract, p_flip
        self.bits = [0] * n_distract
        self.sel = None if mode == "none" else 0          # 候选 0 是真灯
        self.pcand = [0] * (1 + n_distract)
        if mode == "learned":
            self.sel = None
            self.win = []                                  # 窗口内 (站, 支付, 候选取值…)
            self.score = np.zeros(1 + n_distract)
            self.t = 0
            self.Ls = {None: self.L}

    def _window_score(self):
        if not self.win:
            return None
        W = np.array(self.win, dtype=float)
        sc, wt = np.zeros(1 + self.nd), 0.0
        for j in np.unique(W[:, 0]):
            X = W[W[:, 0] == j]
            tot = ((X[:, 1] - X[:, 1].mean()) ** 2).sum()
            if len(X) < 4 or tot < 1e-9:
                continue
            for i in range(1 + self.nd):
                g = X[:, 2 + i]
                bet = sum(((X[g == v, 1].mean() - X[:, 1].mean()) ** 2) * (g == v).sum() for v in (0, 1) if (g == v).any())
                sc[i] += len(X) * bet / tot
            wt += len(X)
        return sc / wt if wt else None

    def step(self, obs, r):
        cell, last, light = obs
        for i in range(self.nd):
            if self.rng.random() < self.pf:
                self.bits[i] = 1 - self.bits[i]
        cand = [light] + self.bits
        if self.mode == "learned":
            if r > 0:
                self.win.append([last, r] + self.pcand)
            self.t += 1
            if self.t % self.WIN == 0:
                ws = self._window_score()
                self.win = []
                if ws is not None:
                    self.score += self.EMA * (ws - self.score)
                best = int(self.score.argmax())
                new = best if self.score[best] > self.THR else None
                if new != self.sel:
                    if new not in self.Ls:                     # 新表沿用学习器自己的乐观初值
                        self.Ls[new] = self.make()
                    self.L.ps = None
                    self.sel, self.L = new, self.Ls[new]
            self.pcand = cand
        key = (cell, last) if self.sel is None else (cell, last, cand[self.sel])
        return self.L.step(self.ix(key), r)


# ---------------------------------------------------------------- 第 24 章：组合
class FactoredQ:
    """差分 Q 学习，Q(s, a) = Σ_k W_k[i_k(s), a]：每个部件一张小表，按 1/K 分摊 TD 误差（线性函数逼近，
    特征是各组的独热码）。表格组合把特征相乘（格×last×灯×电量档×…），每个格子都要单独学；
    这里相加，“灯”的表在所有电量档之间共享，“电量”的表在灯的两种取值之间共享。
    代价：相加表达不了特征之间的交互（例如“灯亮且电量低”有特别的值），这一部分只能近似。"""

    def __init__(self, rng, K, alpha=ALPHA, eps=EPS, rbar0=OPT["rbar0"], eta=OPT["eta"]):
        self.rng, self.K, self.alpha, self.eps, self.eta = rng, K, alpha, eps, eta
        self.W = [np.zeros((4096, NA)) for _ in range(K)]      # 预分配（组合世界里每组最多约 2100 个取值）
        self.rbar = float(rbar0)
        self.ps = self.pa = None
        self.B = None

    def q(self, s):
        return sum(self.W[k][i] for k, i in enumerate(s))

    def step(self, s, r):
        q = self.q(s)
        if self.ps is not None:
            d = r - self.rbar + q.max() - self.q(self.ps)[self.pa]
            al = self.alpha / self.K
            for k, i in enumerate(self.ps):
                self.W[k][i, self.pa] += al * d
            self.rbar += self.eta * self.alpha * d
            q = self.q(s)
        if self.rng.random() < self.eps:
            a = int(self.rng.integers(NA))
        else:
            b = np.flatnonzero(q == q.max())
            a = int(b[0]) if len(b) == 1 else int(b[self.rng.integers(len(b))])
        self.ps, self.pa = s, a
        return a

    def clone(self, shared=()):
        """新情境的学习器：shared 里的组与本学习器共用同一张表（按引用），其余复制一份。"""
        L = FactoredQ(self.rng, self.K, self.alpha, self.eps, self.rbar, self.eta)
        L.W = [w if k in shared else w.copy() for k, w in enumerate(self.W)]
        return L


class ComboAgent(Agent):
    """把第 15、19、20、23 章学到的部件装进一个智能体，世界同时开着这四个刻度（规律切换、电量、灯、打滑漂移）。
    use 里的部件：
      'context'  第 15 章：按支付的意外识别规律，每个情境一张表（同 ContextAgent）；
      'battery'  第 19 章：状态加“电量 − 到桩期望步数”分档，步数由模型式 GVF 学（问题给定，答案学到）；
      'cue'      第 20 章：状态加灯（设计者给的特征）；
      'idbd'     第 23 章：每个 (s, a) 学自己的步长。
    部件之间有接口：灯也改 B 站的支付，所以情境识别记“站的支付”时，用了灯就按 (站, 灯) 记；
    不用灯时 B 站的支付随灯变，会被当成规律切换（这是组合要付的代价之一，ch24/combo/-cue 里看得到）。"""
    PARTS = ("context", "battery", "cue", "idbd")

    def __init__(self, rng, use, charger, tol=0.1, max_ctx=6, factored=False, window=0, cue="light",
                 b_station=None, rho=3e-4, alpha_q=0.3):
        # 11-20 加的两种接口改法（默认值与正式运行相同）：
        #   window > 0：情境按最近 window 次交货挑（match_context）；
        #   cue='opt'：状态里放“当前灯下 B 拿高价的预测是否过半”，久未检验转乐观（第 20 章的改法，
        #     diagnostics 的 PredCue）；B 站的支付归这个预测解释，情境识别不再看 B，灯含义翻转不再被当成规律切换。
        self.window, self.cue_mode, self.bst = window, cue, b_station
        self.recent = deque(maxlen=window) if window else None
        self.q, self.pl, self.rho, self.aq, self.thr = [0.5, 0.5], None, rho, alpha_q, 0.5 * (6.0 + 0.5)
        if cue == "opt":
            assert b_station is not None
        self.use, self.factored = set(use), factored
        # factored='sum'：每个部件一张小表，Q 取和（FactoredQ）；情境换表时整套复制。
        # factored='shared'：另加一张按情境分开的 (格, last) 表，其余各表（导航、灯、电量）所有情境共用，
        #   情境只管“与规律有关”的那一部分。都不带 IDBD。
        if factored:
            assert "idbd" not in self.use
            self.share = "context" in self.use and factored == "shared"
            self.K = 1 + self.share + ("cue" in self.use) + ("battery" in self.use)
            self.ixs = [Indexer() for _ in range(self.K)]
            self.make = lambda: FactoredQ(rng, self.K)
        else:
            kw = dict(alpha="idbd", theta=0.01) if "idbd" in self.use else {}
            self.make = mk("L2", rng, **kw)
        super().__init__(rng, self.make())
        self.ctx = [dict(pay={}, L=self.L)]
        self.c, self.tol, self.max_ctx, self.n_switch = 0, tol, max_ctx, 0
        self.M = GVFModel([charger]) if "battery" in self.use else None
        self.prev = None

    def _context(self, obs, r):
        cell, last, light = obs[0], obs[1], obs[2]
        if self.cue_mode == "opt" and last == self.bst:
            return
        j = (last, light) if ("cue" in self.use and self.cue_mode == "light") else last
        cur = self.ctx[self.c]
        if j in cur["pay"] and abs(cur["pay"][j] - r) > self.tol:
            m = match_context(self.ctx, self.c, j, r, self.tol, self.recent or ())
            if m is not None:
                new = m
            elif len(self.ctx) < self.max_ctx:
                if self.factored:
                    L = self.L.clone(shared=[k for k in range(self.K) if k != 1] if self.share else ())
                else:
                    L = self.make()
                    L.Q = self.L.Q.copy(); L.rbar = self.L.rbar
                    if L.B is not None:
                        L.B = self.L.B.copy(); L.H = self.L.H.copy()
                self.ctx.append(dict(pay={}, L=L))
                new = len(self.ctx) - 1
            else:
                new = self.c
            if new != self.c:
                L = self.ctx[new]["L"]
                L.ps, L.pa = self.L.ps, self.L.pa
                if L.ps is not None and not self.factored:   # 别的情境的表可能还没长到这个状态编号
                    L._grow(L.ps)
                self.L.ps = None
                self.c, self.L = new, L
                self.n_switch += 1
        self.ctx[self.c]["pay"][j] = r
        if self.recent is not None:
            self.recent.append((j, r))

    def step(self, obs, r):
        cell, last, light, b, tow = obs
        if self.cue_mode == "opt":
            self.q[0] += self.rho * (1 - self.q[0]); self.q[1] += self.rho * (1 - self.q[1])
            if self.pl is not None and r > 0 and last == self.bst:
                self.q[self.pl] += self.aq * (float(r > self.thr) - self.q[self.pl])
            self.pl = light
            light = int(self.q[light] > 0.5)
            obs = (cell, last, light, b, tow)
        if self.M is not None and self.prev is not None and not tow:
            self.M.observe(self.prev[0], self.prev[1], cell)
        if "context" in self.use and r > 0:
            self._context(obs, r)
        base = ("tow", last) if tow else (cell, last)
        bb = None if (self.M is None or tow) else int(np.searchsorted(BatteryAgent.BINS, b - self.M.E[0][cell]))
        if self.factored:
            keys = [base] + ([base] if self.share else [])
            if "cue" in self.use:
                keys.append(base + (light,))
            if self.M is not None:
                keys.append(base + (bb,))
            a = self.L.step(tuple(ix(k) for ix, k in zip(self.ixs, keys)), r)
            self.prev = None if tow else (cell, a)
            return a
        key = base
        if "cue" in self.use:
            key += (light,)
        if bb is not None:
            key += (bb,)
        a = self.L.step(self.ix(key), r)
        self.prev = None if tow else (cell, a)
        return a


# ---------------------------------------------------------------- 第 21–22 章：options 与规划
ST_OF = np.full(LW.N, -1)
for _j, _c in enumerate(LW.ST_CELL):
    ST_OF[_c] = _j


def path_policy(target, nxt):
    """去目标格的确定性策略：每格选使到目标的 BFS 距离最小的方向；到了记 -1。"""
    d = LW.bfs_dist(target, nxt)
    far = 10 ** 6
    D = np.array([d.get(i, far) for i in range(LW.N)])
    pol = np.full(LW.N, -1)
    for i in range(LW.N):
        if i != target and D[i] < far:
            pol[i] = int(np.argmin(D[nxt[i]]))
    return pol


def ascent_policy(e, nxt):
    """eigenoption（Machado 等 2017）：沿特征向量 e 上升，到局部最大处终止（记 -1）。"""
    pol = np.full(LW.N, -1)
    for i in range(LW.N):
        v = e[nxt[i]]
        if v.max() > e[i] + 1e-9:
            pol[i] = int(np.argmax(v))
    return pol


def sim_option(cell, last, opt, slip_p, rng, nxt, maxdur):
    """设计者的模拟器：知道地图和打滑，不知道当下的支付。返回 (终点格, 步数, 依次交货的站)。"""
    kind, x = opt
    tau, dl = 0, []
    while True:
        a = x if kind == "prim" else int(x[cell])
        u = rng.random()
        d = a if u < slip_p else [e for e in range(NA) if e != a][int(rng.integers(3))]
        cell = int(nxt[cell, d]); tau += 1
        j = ST_OF[cell]
        if j >= 0 and j != last:
            dl.append(int(j)); last = int(j)
        if kind == "prim" or tau >= maxdur or x[cell] < 0:
            return cell, tau, tuple(dl)


class OptionAgent:
    """差分的选项内 Q 学习（intra-option，Sutton、Precup 与 Singh 1999；差分形式见 Wan、Naik 与 Sutton 2021）：
    每走一步，凡是在上一格会选同一动作的选项都更新一次；规划时按选项的整段结局做 SMDP 备份。
    选项 = 4 个原始动作 + 若干“策略 + 终止”。obs 用 (格, last)。
    opts:  'none' 只有原始动作；'given' 设计者给 4 个门 + 4 个站的走廊式选项（真地图上的最短路）；
           'sub' 学到的子目标：前 learn_steps 步只用原始动作、记下转移图与得过奖励的格，
                 然后以这些格为目标、在学到的图上规划最短路（尊重奖励的子任务的简化）；
           'eig' 学到的 eigenoption：在学到的图上算拉普拉斯特征向量，取前 k/2 个、正负各一。
    plan:  None 不规划；'given' 规划用设计者模拟器预先采的结局；'learned' 用自己最近 K 次真实结局。
           规划时奖励按当前跟踪的各站支付 p̂（步长 beta）重算——支付会切换，模型只记“去了哪里”。"""
    MAXDUR = 40

    def __init__(self, rng, opts="none", k=8, plan=None, n_plan=5, K=10, beta=0.5,
                 learn_steps=50_000, alpha=ALPHA, eps=EPS, rbar0=OPT["rbar0"], eta=OPT["eta"], slip_p=2 / 3, M=8,
                 plan_rbar=False):
        self.rng, self.mode, self.k, self.plan = rng, opts, k, plan
        self.plan_rbar = plan_rbar
        self.n_plan, self.K, self.beta, self.learn_steps = n_plan, K, beta, learn_steps
        self.alpha, self.eps, self.eta, self.rbar = alpha, eps, eta, float(rbar0)
        self.nxt = LW.next_table()
        self.opts = [("prim", a) for a in range(NA)]
        if opts == "given":
            for t in [LW.IDX[LW.DOORS[d]] for d in "NWES"] + list(LW.ST_CELL):
                self.opts.append(("pol", path_policy(t, self.nxt)))
        self._avail()
        self.Q = {}
        self.cur = None
        self.t = 0
        self.prev = self.pkey = None
        self.cnt = np.zeros((LW.N, NA, LW.N), dtype=np.int32) if opts in ("sub", "eig") else None
        self.rcells = set()
        self.phat = np.ones(4)
        self.model, self.mkeys = {}, []
        self.slip_p, self.M = slip_p, M
        if plan == "given":
            self._designer_model()

    def _avail(self):
        n = len(self.opts)
        A = np.ones((LW.N, n), dtype=bool)
        self.POL = np.zeros((n, LW.N), dtype=np.int64)     # 每个选项在每格的动作（-1 = 终止）
        self.TERM = np.ones((n, LW.N), dtype=bool)         # 到这一格是否终止
        for o, (kind, x) in enumerate(self.opts):
            if kind == "pol":
                A[:, o] = x >= 0
                self.POL[o] = x
                self.TERM[o] = x < 0
            else:
                self.POL[o] = x
        self.avail = A

    def _designer_model(self):
        r2 = np.random.default_rng(int(self.rng.integers(1 << 30)))
        self.dm = {}
        for c in range(LW.N):
            for last in range(5):
                for o, op in enumerate(self.opts):
                    if self.avail[c, o]:
                        self.dm[(c, last, o)] = [sim_option(c, last, op, self.slip_p, r2, self.nxt, self.MAXDUR) for _ in range(self.M)]

    def _build_learned(self):
        nxt = np.where(self.cnt.sum(2) > 0, self.cnt.argmax(2), np.arange(LW.N)[:, None])
        A = (self.cnt.sum(1) + self.cnt.sum(1).T) > 0
        np.fill_diagonal(A, False)
        if self.mode == "sub":
            for t in sorted(self.rcells):
                self.opts.append(("pol", path_policy(t, nxt)))
        else:
            seen = np.flatnonzero(A.any(1))
            As = A[np.ix_(seen, seen)].astype(float)
            Lap = np.diag(As.sum(1)) - As
            w, V = np.linalg.eigh(Lap)
            for i in range(1, 1 + self.k // 2):
                for sgn in (1, -1):
                    e = np.full(LW.N, -1e9); e[seen] = sgn * V[:, i]
                    self.opts.append(("pol", ascent_policy(e, nxt)))
        self._avail()

    def q(self, key):
        v = self.Q.get(key)
        if v is None or len(v) < len(self.opts):
            nv = np.zeros(len(self.opts))
            if v is not None:
                nv[:len(v)] = v
            self.Q[key] = v = nv
        return v

    def vmax(self, key):
        return self.q(key)[self.avail[key[0]]].max()

    def choose(self, key):
        """ε 的随机选择只在原始动作里抽（与“没有”档的探索相同；随机抽一个 40 步的选项代价太大）。"""
        if self.rng.random() < self.eps:
            return int(self.rng.integers(NA))
        ok = np.flatnonzero(self.avail[key[0]])
        v = self.q(key)[ok]
        b = ok[v == v.max()]
        return int(b[self.rng.integers(len(b))])

    def _backup(self, k0, o, R, tau, k2, real):
        qv = self.q(k0)
        d = R - self.rbar * tau + self.vmax(k2) - qv[o]
        qv[o] += self.alpha * d
        # r̄ 只由真实步更新（本课取定）。Wan、Naik 与 Sutton（2021）的差分 Q 规划让规划的 TD 误差也更新 r̄，
        # 那要求模型是对的；这里规划用的支付 p̂ 会过时，混进去 r̄ 就不再是真实的奖励率。plan_rbar=True 是那个做法，
        # 试点（pilot2-ch22）作敏感性对照。
        if real or self.plan_rbar:
            self.rbar += self.eta * self.alpha * d

    def _plan_once(self):
        k0, o = self.mkeys[self.rng.integers(len(self.mkeys))]
        if self.plan == "given":
            outs = self.dm[(k0[0], k0[1], o)]
        else:
            outs = self.model[(k0, o)]
        c2, tau, dl = outs[self.rng.integers(len(outs))]
        R = float(sum(self.phat[j] for j in dl))
        self._backup(k0, o, R, tau, (c2, dl[-1] if dl else k0[1]), real=False)

    def step(self, obs, r):
        cell, last = obs[0], obs[1]
        self.t += 1
        if self.cnt is not None and self.prev is not None:
            self.cnt[self.prev[0], self.prev[1], cell] += 1
        if r > 0:
            self.rcells.add(cell)
            self.phat[last] += self.beta * (r - self.phat[last])
        if self.cnt is not None and self.t == self.learn_steps:
            self._build_learned()
        key = (cell, last)
        if self.pkey is not None:                                   # 选项内更新
            pk, pa = self.pkey, self.prev[1]
            qp, qn = self.q(pk), self.q(key)
            cons = np.flatnonzero(self.avail[pk[0]] & (self.POL[:, pk[0]] == pa))
            vm = qn[self.avail[cell]].max()
            U = np.where(self.TERM[cons, cell], vm, qn[cons])
            dp = r - self.rbar + vm - qp[pa]
            qp[cons] += self.alpha * (r - self.rbar + U - qp[cons])
            self.rbar += self.eta * self.alpha * dp
        if self.cur is not None:
            o, k0, tau, G, dl = self.cur
            tau += 1; G += r
            if r > 0:
                dl.append(last)
            kind, x = self.opts[o]
            if kind == "prim" or tau >= self.MAXDUR or x[cell] < 0:
                if self.plan == "learned":
                    m = self.model.get((k0, o))
                    if m is None:
                        m = self.model[(k0, o)] = deque(maxlen=self.K)
                        self.mkeys.append((k0, o))
                    m.append((cell, tau, tuple(dl)))
                elif self.plan == "given" and (k0, o) not in self.model:
                    self.model[(k0, o)] = True
                    self.mkeys.append((k0, o))
                self.cur = None
            else:
                self.cur = [o, k0, tau, G, dl]
        if self.cur is None:
            o = self.choose(key)
            self.cur = [o, key, 0, 0.0, []]
            if self.plan and self.mkeys:
                for _ in range(self.n_plan):
                    self._plan_once()
        kind, x = self.opts[self.cur[0]]
        a = x if kind == "prim" else int(x[cell])
        self.prev = (cell, a)
        self.pkey = key
        return a


# ---------------------------------------------------------------- 第 25 章：探测
class ProbeAgent:
    """原始动作级的差分 Dyna（obs 用 (格, last)）。模型：每个 (s, a) 最近 K 次的 (s', r)。
    mode 'none'   只学不规划，ε-贪心（L9 的做法）；
         'given'  Dyna-Q+（Sutton 与 Barto 2018 §8.3）：规划时加奖励 κ√τ，τ 是 (s, a) 多久没试过，κ 由设计者定；
         'learned' 加 κ_L·(1 − exp(−λ̂τ))：λ̂ 是从经验估的“世界变化率”，
                   变化 = 某个已试过 > 100 次的 (s, a) 出现了从没见过的下一格（打滑下漏看某个结局的概率约 1e-5）。"""

    def __init__(self, rng, mode="none", kappa=1e-4, kappa_l=0.1, n_plan=5, K=10, prior_t=1e5,
                 alpha=ALPHA, eps=EPS, rbar0=OPT["rbar0"], eta=OPT["eta"]):
        self.rng, self.mode, self.kappa, self.kappa_l = rng, mode, kappa, kappa_l
        self.n_plan, self.K, self.prior_t = n_plan, K, prior_t
        self.L = Tab(rng, "q", gamma=None, rbar0=rbar0, eta=eta, alpha=alpha, eps=eps)
        self.ix = Indexer()
        self.model, self.keys, self.last_try, self.seen, self.n_sa = {}, [], {}, {}, {}
        self.t, self.n_change = 0, 0
        self.ps = None

    def lam_hat(self):
        return (self.n_change + 1) / (self.t + self.prior_t)

    def bonus(self, sa):
        tau = self.t - self.last_try[sa]
        if self.mode == "given":
            return self.kappa * np.sqrt(tau)
        if self.mode == "learned":
            return self.kappa_l * (1.0 - np.exp(-self.lam_hat() * tau))
        return 0.0

    def step(self, obs, r):
        self.t += 1
        cell = obs[0]
        s = self.ix((cell, obs[1]))
        L = self.L
        L._grow(s)
        if self.ps is not None:
            sa = self.ps
            L.update_q(sa[0], sa[1], r, s)
            if self.mode != "none":
                m = self.model.get(sa)
                if m is None:
                    m = self.model[sa] = deque(maxlen=self.K)
                    self.keys.append(sa)
                m.append((s, r))
                self.last_try[sa] = self.t
                seen = self.seen.setdefault(sa, set())
                self.n_sa[sa] = self.n_sa.get(sa, 0) + 1
                if cell not in seen:
                    if self.n_sa[sa] > 100:
                        self.n_change += 1
                    seen.add(cell)
                for _ in range(self.n_plan):
                    k = self.keys[self.rng.integers(len(self.keys))]
                    s2, rr = self.model[k][self.rng.integers(len(self.model[k]))]
                    L._grow(s2)
                    d = rr + self.bonus(k) - L.rbar + L.Q[s2].max() - L.Q[k[0], k[1]]
                    L.Q[k[0], k[1]] += L.alpha * d
        a = L.choose(s)
        self.ps = (s, a)
        return a


# ======================================================================== 运行
# 变化跟踪：按“距上次变化多少步”分档累计奖励（只读 env.info()，学习器看不到，也不动世界随机数）。
# 种类 → (info 的字段, 档宽, 档数)；最后一档收“更久以前”。
TRACK = dict(regime=("regime", 50, 60), sign=("sign", 500, 60), slip=("slip_p", 2500, 20), door=("door_open", 10000, 130))


def track_kinds(cfg):
    out = []
    if cfg["h"] > 0 and len(cfg["regimes"]) > 1:
        out.append("regime")
    if cfg["cue"] and cfg["cue"]["h_sign"] > 0:
        out.append("sign")
    if cfg["slip_drift"]:
        out.append("slip")
    if cfg["door"]:
        out.append("door")
    return out


def run(cfg, agent, steps, seed, every=10000, track=None):
    """返回 (lifetime 率, 每 every 步的奖励)。track 给一个 dict 时，另记变化跟踪：
    track[种类] = dict(width, sum=[lifetime 前半, lifetime 后半][档], n=同形状的步数, events=变化次数)。
    “距上次变化”从这一种类的第一次变化算起；第一次变化之前的步不计。
    门（第 25 章）例外：两行是 [门关着, 门开着]，不按前后半分（关门后、重开后分开记）。"""
    env = LW.LadderWorld(cfg, seed=seed)
    obs = env.observe()
    r = 0.0
    total = 0.0
    curve = []
    kinds = track_kinds(cfg) if track is not None else []
    if kinds:
        info = env.info()
        prev = {k: info[TRACK[k][0]] for k in kinds}
        since = {k: None for k in kinds}
        acc = {k: (np.zeros((2, TRACK[k][2])), np.zeros((2, TRACK[k][2]), dtype=np.int64)) for k in kinds}
        nev = {k: 0 for k in kinds}
        half = steps // 2
    for t in range(steps):
        a = agent.step(obs, r)
        obs, r, info = env.step(a)
        total += r
        if kinds:
            hh = int(t >= half)
            for k in kinds:
                f, w, nb = TRACK[k]
                if k == "door":
                    hh = int(prev[k])
                if since[k] is not None:
                    i = min((t - since[k]) // w, nb - 1)
                    acc[k][0][hh, i] += r
                    acc[k][1][hh, i] += 1
                v = info[f]
                if v != prev[k]:
                    prev[k], since[k] = v, t + 1
                    nev[k] += 1
        if (t + 1) % every == 0:
            curve.append(total)
    for k in kinds:
        track[k] = dict(width=TRACK[k][1], sum=acc[k][0].tolist(), n=acc[k][1].tolist(), events=nev[k])
    return total / steps, np.diff([0.0] + curve).tolist()




def mk(kind, rng, **kw):
    """学习器工厂。所有学习器都用乐观初值，保证第一次就能把四个区走遍。"""
    if kind == "L0":   # 折扣 Q，学到中途冻结（之后步长为 0）
        return lambda: Tab(rng, "q", gamma=0.9, q0=OPT["disc09"], freeze_at=kw["freeze_at"])
    if kind == "L1":   # 折扣 Q，常数步长
        g = kw.get("gamma", 0.9)
        return lambda: Tab(rng, "q", gamma=g, q0=OPT["disc09"] if g == 0.9 else OPT["disc099"])
    if kind == "L2":   # 差分 Q（从经验学 r̄）；alpha='idbd' 时每个 (s, a) 学自己的步长（L9）
        return lambda: Tab(rng, "q", gamma=None, rbar0=OPT["rbar0"], eta=OPT["eta"], alpha=kw.get("alpha", ALPHA),
                           theta=kw.get("theta", 0.01), alpha0=kw.get("alpha0", ALPHA))
    if kind == "L2sarsa":   # 差分 Sarsa(λ)
        return lambda: Tab(rng, "sarsa", gamma=None, lam=kw.get("lam", LAM), rbar0=OPT["rbar0"], eta=OPT["eta"])
    raise KeyError(kind)


# ---------------------------------------------------------------- 试验定义：名字 → (世界配置, 造智能体的函数)
def experiments(steps=1_000_000):
    """名字 → (世界配置, 造智能体的函数)。名字格式：章/条件/档（none | given | learned | 其他对照）。"""
    E = {}
    L2 = lambda rng: mk("L2", rng)()
    # 第 15 章：h ∈ {0, 1e-3} × 容量 {足, 不足}；没有 = 学到一半冻结，给定 = 常数步长一直跟踪，
    # 学到 = 按支付的意外识别情境、每个情境一张表
    cm = coarse_map(2)
    for h in (0.0, 1e-3):
        for cap, cmap in (("full", None), ("coarse", cm)):
            cfg = LW.make_cfg(h=h)
            E[f"ch15/h{h:g}-{cap}/none"] = (cfg, lambda rng, c=cmap: Agent(rng, mk("L0", rng, freeze_at=steps // 2)(), cell_map=c))
            E[f"ch15/h{h:g}-{cap}/given"] = (cfg, lambda rng, c=cmap: Agent(rng, mk("L1", rng)(), cell_map=c))
            E[f"ch15/h{h:g}-{cap}/learned"] = (cfg, lambda rng, c=cmap: ContextAgent(rng, mk("L1", rng), cell_map=c))
    # 第 16 章：lifetime 不复位；没有 = γ=0.9，给定 = 设计者选 γ=0.99，学到 = 差分（从经验学 r̄）
    cfg = LW.make_cfg()
    E["ch16/base/none"] = (cfg, lambda rng: Agent(rng, mk("L1", rng)()))
    E["ch16/base/given"] = (cfg, lambda rng: Agent(rng, mk("L1", rng, gamma=0.99)()))
    E["ch16/base/learned"] = (cfg, lambda rng: Agent(rng, L2(rng)))
    # 第 17 章：支付晚 20 步；没有 = 一步更新，给定 = 设计者告知 D=20，学到 = 从经验学时滞；资格迹作对照
    cfg = LW.dial_cfg(17)
    E["ch17/d20/none"] = (cfg, lambda rng: Agent(rng, L2(rng)))
    E["ch17/d20/given"] = (cfg, lambda rng: LagAgent(rng, L2(rng), D=20))
    E["ch17/d20/learned"] = (cfg, lambda rng: LagAgent(rng, L2(rng), D=None))
    E["ch17/d20/trace0.9"] = (cfg, lambda rng: Agent(rng, mk("L2sarsa", rng, lam=0.9)()))
    E["ch17/d20/trace0.98"] = (cfg, lambda rng: Agent(rng, mk("L2sarsa", rng, lam=0.98)()))
    # 第 18 章：局部观测
    cfg = LW.dial_cfg(18)
    for m in ("none", "given", "learned", "hist2"):
        E[f"ch18/local/{m}"] = (cfg, lambda rng, m=m: LocalAgent(rng, L2(rng), m))
    # 第 19 章：电量
    ch19 = LW.dial_cfg(19)
    charger = LW.IDX[LW.DOORS[ch19["battery"]["charger"]]]
    for m in ("none", "raw", "given", "learned"):
        E[f"ch19/battery/{m}"] = (ch19, lambda rng, m=m: BatteryAgent(rng, L2(rng), m, charger))
    # 改进与发现（见 README 八）：模型式 GVF；连“问什么”也从经验发现
    E["ch19/battery/model"] = (ch19, lambda rng: BatteryModelAgent(rng, L2(rng), "model", charger))
    E["ch19/battery/discover"] = (ch19, lambda rng: BatteryModelAgent(rng, L2(rng), "discover", charger,
                                                                      learner_maker=lambda: mk("L2", rng)()))
    # 第 20 章：指示灯
    # 两种条件：灯的含义约每 1 万步翻一次（档位默认），和含义不变（h_sign=0）
    for tag, hs in (("flip", None), ("fixed", 0.0)):
        cfg = LW.dial_cfg(20)
        if hs is not None:
            cfg["cue"] = dict(cfg["cue"], h_sign=hs)
        for m in ("none", "given", "learned"):
            E[f"ch20/{tag}/{m}"] = (cfg, lambda rng, m=m: CueAgent(rng, lambda: mk("L2", rng)(), m))
    # 第 21 章：options。h=1e-3（档位）与 1e-2（切换更频繁）
    for h in (1e-3, 1e-2):
        cfg = LW.make_cfg(h=h)
        tag = f"h{h:g}"
        E[f"ch21/{tag}/none"] = (cfg, lambda rng: OptionAgent(rng, "none"))
        E[f"ch21/{tag}/given"] = (cfg, lambda rng: OptionAgent(rng, "given"))
        E[f"ch21/{tag}/learned-sub"] = (cfg, lambda rng: OptionAgent(rng, "sub"))
        for k in (2, 4, 8):
            E[f"ch21/{tag}/learned-eig{k}"] = (cfg, lambda rng, k=k: OptionAgent(rng, "eig", k=k))
    # 第 22 章：在给定 options 上规划；没有 = 不规划，给定 = 设计者模拟器，学到 = 自己的样本模型
    for h in (0.0, 1e-4, 1e-3, 1e-2):                       # h=0：支付不变，模型不会过时（预言 2 的 h→0 端）
        cfg = LW.make_cfg(h=h)
        tag = f"h{h:g}"
        E[f"ch22/{tag}/none"] = (cfg, lambda rng: OptionAgent(rng, "given"))
        E[f"ch22/{tag}/given"] = (cfg, lambda rng: OptionAgent(rng, "given", plan="given"))
        E[f"ch22/{tag}/learned"] = (cfg, lambda rng: OptionAgent(rng, "given", plan="learned"))
        # 交互分解（第 24 章账本）：原始动作 × {不规划, 设计者模型规划}
        E[f"ch22/{tag}/prim"] = (cfg, lambda rng: OptionAgent(rng, "none"))
        E[f"ch22/{tag}/prim-plan"] = (cfg, lambda rng: OptionAgent(rng, "none", plan="given"))
    # 第 23 章：打滑漂移 + 指示灯（灯由设计者给，L6 已学到）；步长扫描与 IDBD
    cfg = LW.dial_cfg(23)
    for al in (0.01, 0.03, 0.1, 0.3):
        E[f"ch23/drift/alpha{al:g}"] = (cfg, lambda rng, al=al: CueAgent(rng, lambda: mk("L2", rng, alpha=al)(), "given"))
    for th in (0.001, 0.01, 0.1):
        E[f"ch23/drift/idbd{th:g}"] = (cfg, lambda rng, th=th: CueAgent(rng, lambda: mk("L2", rng, alpha="idbd", theta=th)(), "given"))
        # IDBD 从一个坏的步长起（0.1 恰是扫描里最好的常数，从它起步看不出 IDBD 会不会自己找）
        for a0 in (0.01, 0.3):
            E[f"ch23/drift/idbd{th:g}-a{a0:g}"] = (cfg, lambda rng, th=th, a0=a0: CueAgent(
                rng, lambda: mk("L2", rng, alpha="idbd", theta=th, alpha0=a0)(), "given"))
    # 第 24 章：组合。世界同时开第 15（规律切换）、19（电量）、20 与 23（灯、打滑漂移）章的刻度；
    # 全开、各去一个部件、全关
    cfg = LW.dial_cfg(15, 19, 23)
    charger = LW.IDX[LW.DOORS[cfg["battery"]["charger"]]]
    P = ComboAgent.PARTS
    E["ch24/combo/all"] = (cfg, lambda rng: ComboAgent(rng, P, charger))
    for p in P:
        E[f"ch24/combo/-{p}"] = (cfg, lambda rng, p=p: ComboAgent(rng, [q for q in P if q != p], charger))
        E[f"ch24/combo/only-{p}"] = (cfg, lambda rng, p=p: ComboAgent(rng, [p], charger))
    E["ch24/combo/none"] = (cfg, lambda rng: ComboAgent(rng, [], charger))
    # 两种接口改法（不带 IDBD）：各部件小表相加；再加上导航、灯、电量的表在情境间共享
    for fx in ("sum", "shared"):
        E[f"ch24/combo/{fx}"] = (cfg, lambda rng, fx=fx: ComboAgent(rng, ("context", "battery", "cue"), charger, factored=fx))
    # 第 25 章：门 N 在 [20 万, 70 万) 关、之后重开；对照 = 门一直开
    for tag, door in (("reopen", dict(door="N", schedule=[(200_000, 700_000)])), ("control", None)):
        cfg = LW.dial_cfg(25)
        cfg["door"] = door
        E[f"ch25/{tag}/eps"] = (cfg, lambda rng: ProbeAgent(rng, "none"))                 # 对照：不规划
        E[f"ch25/{tag}/none"] = (cfg, lambda rng: ProbeAgent(rng, "given", kappa=0.0))    # Dyna，不探测
        E[f"ch25/{tag}/given"] = (cfg, lambda rng: ProbeAgent(rng, "given", kappa=1e-4))
        E[f"ch25/{tag}/learned"] = (cfg, lambda rng: ProbeAgent(rng, "learned", kappa_l=0.1))
    return E


def one(args):
    name, seed, steps = args
    cfg, make = experiments(steps)[name]
    rng = np.random.default_rng(10_000 + seed)
    agent = make(rng)
    t0 = time.time()
    tr = {}
    rate, curve = run(cfg, agent, steps, seed, track=tr)
    extra = dict(track=tr) if tr else {}
    if isinstance(agent, LagAgent) and agent.D is None:
        extra["Dhat"] = agent.Dhat
    if isinstance(agent, (ContextAgent, ComboAgent)):
        extra["n_ctx"], extra["n_switch"] = len(agent.ctx), agent.n_switch
    if isinstance(agent, CueAgent):
        extra["selected"] = agent.sel
    if isinstance(agent, BatteryModelAgent) and agent.mode2 == "discover":
        extra["selected"], extra["score"] = agent.sel, [round(float(x), 4) for x in agent.score]
    if isinstance(agent, OptionAgent):
        extra["n_opts"] = len(agent.opts)
    if isinstance(agent, ProbeAgent):
        extra["n_change"], extra["lam_hat"] = agent.n_change, agent.lam_hat()
    return dict(name=name, seed=seed, steps=steps, rate=rate, curve=curve, sec=round(time.time() - t0, 1), **extra)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--exp", default="ch15")
    ap.add_argument("--seeds", type=int, default=5)
    ap.add_argument("--seed0", type=int, default=0)
    ap.add_argument("--steps", type=int, default=1000000)
    ap.add_argument("--procs", type=int, default=12)
    ap.add_argument("--tag", default="pilot")
    a = ap.parse_args()
    if a.exp == "ch22" and a.tag == "formal" and os.path.exists(os.path.join(os.path.dirname(__file__), ".hold-ch22")):
        sys.exit("ch22 正式运行暂停：规划器在审查中（删掉 demos/.hold-ch22 即可运行）")
    names =[n for n in experiments(a.steps) if a.exp == "all" or n.startswith(a.exp)]
    jobs = [(n, s, a.steps) for n in names for s in range(a.seed0, a.seed0 + a.seeds)]
    from multiprocessing import Pool
    t0 = time.time()
    with Pool(a.procs) as p:
        res = p.map(one, jobs, chunksize=1)
    os.makedirs(OUT, exist_ok=True)
    path = os.path.join(OUT, f"{a.tag}-{a.exp.replace('/', '_')}.json")
    with open(path, "w", encoding="utf-8") as f:
        json.dump(dict(steps=a.steps, seeds=a.seeds, results=res, seconds=round(time.time() - t0, 1)), f)
    summarize(res)
    print("written", path, "seconds", round(time.time() - t0, 1))


def summarize(res):
    """lifetime 奖励率（主量）与最后 10% 的奖励率（看收敛到哪里）。"""
    by = {}
    for r in res:
        k = max(1, len(r["curve"]) // 10)
        fin = sum(r["curve"][-k:]) / (k * r["steps"] / len(r["curve"]))
        by.setdefault(r["name"], {})[r["seed"]] = (r["rate"], fin)
    se = lambda v: v.std(ddof=1) / np.sqrt(len(v)) if len(v) > 1 else 0.0
    for n in sorted(by):
        v = np.array(list(by[n].values()))
        print(f"{n:30s} n={len(v):2d} life={v[:,0].mean():.4f}±{se(v[:,0]):.4f}  last10%={v[:,1].mean():.4f}±{se(v[:,1]):.4f}")


if __name__ == "__main__":
    main()
