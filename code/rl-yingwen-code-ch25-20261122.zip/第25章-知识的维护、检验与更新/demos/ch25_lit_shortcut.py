# -*- coding: utf-8 -*-
"""第 25 章文献原型：捷径迷宫（Sutton & Barto 第 2 版 §8.3，例 8.3，图 8.5）。

    python3 demos/ch25_lit_shortcut.py            # 30 次独立运行
    python3 demos/ch25_lit_shortcut.py --runs 4   # 快速试跑

只用 numpy。迷宫 6×9：起点 (5,3)，终点 (0,8)；第 3 行第 1--8 列是墙，
第 3000 步之后打开 (3,8)，左侧缺口 (3,0) 一直开着。共 6000 个真实步，
每个真实步 50 次规划；alpha=1，gamma=0.95，epsilon=0.1，kappa=0.001。
这些参数为本课取定（迷宫尺寸由书图重画，书中参数未逐一核对），
与本课第 8 章的标准库实现 demos/shortcut_exploration.py 相同，
但随机数流与代码独立。Dyna-Q+ 规划奖励为 r + kappa*sqrt(tau)；
首次到达一个状态时，未试过的动作记为“回到原地、奖励 0”（书中脚注）。
输出：assets/ch25-lit-shortcut/results.json
"""
import argparse
import json
import math
from collections import deque
from pathlib import Path

import numpy as np

ROWS, COLS = 6, 9
ACTIONS = ((-1, 0), (0, 1), (1, 0), (0, -1))
START, GOAL, GAP = 5 * COLS + 3, 0 * COLS + 8, 3 * COLS + 8
CHANGE, HORIZON = 3000, 6000
ALPHA, GAMMA, EPSILON, KAPPA, N_PLAN = 1.0, 0.95, 0.1, 0.001, 50
GRID = 100
OUT = Path(__file__).resolve().parents[1] / "assets" / "ch25-lit-shortcut"


def step(s, a, open_gap):
    row, col = divmod(s, COLS)
    dr, dc = ACTIONS[a]
    r = min(ROWS - 1, max(0, row + dr))
    c = min(COLS - 1, max(0, col + dc))
    blocked = r == 3 and c >= 1 and not (open_gap and c == 8)
    nxt = s if blocked else r * COLS + c
    return nxt, int(nxt == GOAL)


def shortest(open_gap):
    q, seen = deque([(START, 0)]), {START}
    while q:
        s, d = q.popleft()
        if s == GOAL:
            return d
        for a in range(4):
            n, _ = step(s, a, open_gap)
            if n not in seen:
                seen.add(n)
                q.append((n, d + 1))
    return None


def run(plus, rng):
    q = [[0.0] * 4 for _ in range(ROWS * COLS)]
    states, acts, rec = [], {}, {}
    s = START
    cum = np.zeros(HORIZON + 1)
    total = 0
    first_cross = None
    crossings_late = 0  # 最后 1000 步里从下往上穿过右侧缺口的次数
    goals_late = 0
    entered_from = None
    for t in range(1, HORIZON + 1):
        u = rng.random(2 + 2 * N_PLAN)
        row = q[s]
        if u[0] < EPSILON:
            a = int(u[1] * 4)
        else:
            best = max(row)
            cand = [i for i in range(4) if row[i] == best]
            a = cand[int(u[1] * len(cand))]
        nxt, r = step(s, a, t > CHANGE)
        tail = 0.0 if nxt == GOAL else GAMMA * max(q[nxt])
        row[a] += ALPHA * (r + tail - row[a])
        if s not in acts:
            states.append(s)
            acts[s] = []
            if plus:
                for b in range(4):
                    acts[s].append(b)
                    rec[s, b] = (0, s, 0)
        if (s, a) not in rec:
            acts[s].append(a)
        rec[s, a] = (r, nxt, t)
        ns = len(states)
        for k in range(N_PLAN):
            ps = states[int(u[2 + 2 * k] * ns)]
            al = acts[ps]
            pa = al[int(u[3 + 2 * k] * len(al))]
            pr, pn, last = rec[ps, pa]
            if plus:
                pr = pr + KAPPA * math.sqrt(t - last)
            pt = 0.0 if pn == GOAL else GAMMA * max(q[pn])
            q[ps][pa] += ALPHA * (pr + pt - q[ps][pa])
        total += r
        cum[t] = total
        if t > HORIZON - 1000:
            goals_late += r
        if s != GAP and nxt == GAP:
            entered_from = s // COLS
        if s == GAP and nxt != GAP:
            if entered_from == 4 and nxt // COLS == 2:
                if first_cross is None:
                    first_cross = t
                if t > HORIZON - 1000:
                    crossings_late += 1
            entered_from = None
        s = START if nxt == GOAL else nxt
    return cum, first_cross, goals_late, crossings_late


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--runs", type=int, default=30)
    ap.add_argument("--seed", type=int, default=20261119)
    args = ap.parse_args()
    ss = np.random.SeedSequence(args.seed)
    children = ss.spawn(2 * args.runs)
    grid = list(range(0, HORIZON + 1, GRID))
    out = {
        "geometry": "6x9; wall row 3 cols 1..8; (3,8) opens after step 3000; start (5,3), goal (0,8)",
        "shortest_path_steps": {"before": shortest(False), "after": shortest(True)},
        "parameters": {"alpha": ALPHA, "gamma": GAMMA, "epsilon": EPSILON, "kappa": KAPPA,
                       "planning_per_step": N_PLAN, "real_steps": HORIZON, "change_after": CHANGE,
                       "runs": args.runs, "seed": args.seed},
        "grid": grid,
        "methods": {},
    }
    for mi, (name, plus) in enumerate((("Dyna-Q", False), ("Dyna-Q+", True))):
        curves, crosses, late_goals, late_cross = [], [], [], []
        for i in range(args.runs):
            rng = np.random.default_rng(children[2 * i + mi])
            cum, fc, lg, lc = run(plus, rng)
            curves.append(cum[grid])
            crosses.append(fc)
            late_goals.append(lg)
            late_cross.append(lc)
        C = np.array(curves)
        pre = C[:, grid.index(CHANGE)]
        post = C[:, -1] - pre
        n = args.runs
        delays = [c - CHANGE for c in crosses if c is not None]
        out["methods"][name] = {
            "mean_curve": np.round(C.mean(0), 2).tolist(),
            "ci95_halfwidth": np.round(1.96 * C.std(0, ddof=1) / math.sqrt(n), 2).tolist(),
            "mean_reward_steps_1_3000": round(float(pre.mean()), 2),
            "mean_reward_steps_3001_6000": round(float(post.mean()), 2),
            "ci95_post": round(float(1.96 * post.std(ddof=1) / math.sqrt(n)), 2),
            "runs_crossing_shortcut": sum(c is not None for c in crosses),
            "median_first_crossing_delay": float(np.median(delays)) if delays else None,
            "mean_goals_last_1000": round(float(np.mean(late_goals)), 2),
            "mean_shortcut_crossings_last_1000": round(float(np.mean(late_cross)), 2),
        }
    diff = (np.array(out["methods"]["Dyna-Q+"]["mean_curve"]) - np.array(out["methods"]["Dyna-Q"]["mean_curve"]))
    out["mean_difference_at_6000"] = round(float(diff[-1]), 2)
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "results.json").write_text(json.dumps(out, ensure_ascii=False, indent=1), encoding="utf-8")
    for name, m in out["methods"].items():
        print(name, {k: v for k, v in m.items() if k not in ("mean_curve", "ci95_halfwidth")})
    print("shortest", out["shortest_path_steps"])


if __name__ == "__main__":
    main()
