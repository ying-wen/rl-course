# -*- coding: utf-8 -*-
"""四区仓库的独立检查（照 v12 的做法：手算、枚举、独立实现互查）。

检查 1  手算：无滑动、四站支付全为 1 时，最优是近站对 A–C 来回，r̄* = 2/8 = 0.25。
检查 2  枚举：无滑动时 r̄* 等于站点序列构成的简单环上“支付和 / 步数和”的最大值；
        步数用本文件自己写的 BFS（绕开其他站），与 crl_ladder_world 的 RVI 比。
检查 3  独立建模：本文件从地图字符串另写一遍 (格, last) 的转移与期望奖励，
        与 build_model 的输出逐项比。
检查 4  独立求解：策略迭代 + 稠密线性方程精确求增益，与 RVI 的 r̄* 比（基本世界与规律可见的切换世界）。
检查 5  恒等式：冻结在 R0 的策略在切换世界的奖励率 = 它在三套规律下奖励率的平均（规律过程与智能体无关、平稳分布均匀）。
检查 6  模拟器与模型一致：用最优策略跑 LadderWorld，经验奖励率与精确奖励率之差在 4 个批均值标准误内
        （基本、电量、指示灯、规律切换四种设定）。
检查 7  延迟：同一随机种子、同一策略，有 20 步延迟时的累计奖励 = 无延迟时去掉最后 20 步支付。
检查 8  回合档、门的时间表、局部观测、切换频率的行为检查。

用法：python3 demos/crl_ladder_world_checks.py [模拟步数，默认 1000000]
输出：assets/crl-ladder-world/checks.json
"""
import json, os, sys, time, itertools
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import crl_ladder_world as LW

CHECKS = []


def check(name, ok, **data):
    CHECKS.append(dict(name=name, passed=bool(ok), **data))
    print(("ok   " if ok else "FAIL ") + name, json.dumps(data, ensure_ascii=False))


# ---------------------------------------------------------------- 本文件自己的地图读法（不用 LW 的 next_table / IDX）
GRID = LW.LAYOUT
OPEN = [(r, c) for r in range(len(GRID)) for c in range(len(GRID[0])) if GRID[r][c] == "."]
POS = {rc: i for i, rc in enumerate(OPEN)}
DIRS = {0: (-1, 0), 1: (1, 0), 2: (0, -1), 3: (0, 1)}
ST = {"A": (5, 1), "B": (1, 11), "C": (7, 1), "D": (11, 11)}


def step_cell(rc, d):
    r, c = rc[0] + DIRS[d][0], rc[1] + DIRS[d][1]
    return (r, c) if GRID[r][c] == "." else rc


def bfs_avoid(src, dst, avoid):
    seen = {src: 0}
    fr = [src]
    while fr:
        nf = []
        for x in fr:
            for d in range(4):
                y = step_cell(x, d)
                if y not in seen and (y == dst or y not in avoid):
                    seen[y] = seen[x] + 1
                    nf.append(y)
        fr = nf
    return seen[dst]


def best_cycle(pay):
    names = "ABCD"
    D = {}
    for a in names:
        for b in names:
            if a != b:
                avoid = {ST[x] for x in names if x not in (a, b)}
                D[a, b] = bfs_avoid(ST[a], ST[b], avoid)
    best, arg = -1, None
    for L in range(2, 5):
        for seq in itertools.permutations(names, L):
            if seq[0] != min(seq):
                continue
            num = sum(pay[names.index(x)] for x in seq)
            den = sum(D[seq[i], seq[(i + 1) % L]] for i in range(L))
            if num / den > best:
                best, arg = num / den, "".join(seq)
    return best, arg, D


def own_base_model(pay, p):
    """独立写的 (格, last) 转移：返回 dict[(格, last, a)] -> (期望奖励, {(格', last'): 概率})。"""
    q = (1 - p) / 3
    st_at = {ST[x]: i for i, x in enumerate("ABCD")}
    out = {}
    for rc in OPEN:
        for last in range(4):
            for a in range(4):
                rexp, nxt = 0.0, {}
                for d in range(4):
                    pr = p if d == a else q
                    y = step_cell(rc, d)
                    j = st_at.get(y)
                    nl, r = last, 0.0
                    if j is not None and j != last:
                        nl, r = j, pay[j]
                    rexp += pr * r
                    nxt[(y, nl)] = nxt.get((y, nl), 0.0) + pr
                out[(rc, last, a)] = (rexp, nxt)
    return out


def gain_exact(model, pi):
    """稠密求解：h + g = r_π + P_π h，h[0]=0。"""
    NS, P, R = model["NS"], model["P"], model["R"]
    S = len(R)
    Pm = np.zeros((S, S))
    ar = np.arange(S)
    for m in range(NS.shape[2]):
        np.add.at(Pm, (ar, NS[ar, pi, m]), P[ar, pi, m])
    r = R[ar, pi]
    A = np.eye(S) - Pm
    A[:, 0] = 1.0                       # 未知数 (g, h[1:])，把 h[0] 列换成 g 的系数
    x = np.linalg.solve(A, r)
    h = x.copy(); g = x[0]; h[0] = 0.0
    return g, h


def policy_iteration(model, max_iter=200):
    NS, P, R = model["NS"], model["P"], model["R"]
    pi = np.zeros(len(R), dtype=np.int64)
    for it in range(max_iter):
        g, h = gain_exact(model, pi)
        Q = R + (P * h[NS]).sum(-1)
        best = Q.max(1)
        cur = Q[np.arange(len(R)), pi]
        new = np.where(best > cur + 1e-11, Q.argmax(1), pi)
        if np.array_equal(new, pi):
            return g, pi, it
        pi = new
    return g, pi, max_iter


def batch_rate(rewards, nb=50):
    x = np.asarray(rewards).reshape(nb, -1).mean(1)
    return float(x.mean()), float(x.std(ddof=1) / np.sqrt(nb))


def simulate(cfg, act, steps, seed):
    env = LW.LadderWorld(cfg, seed=seed)
    rs = np.zeros(steps)
    info = env.info()
    for t in range(steps):
        _, r, info = env.step(act(info))
        rs[t] = r
    return rs, env


def main():
    steps = int(sys.argv[1]) if len(sys.argv) > 1 else 1_000_000
    t0 = time.time()
    base = LW.make_cfg()

    # 1 手算
    m = LW.build_model(LW.make_cfg(slip_p=1.0, regimes=[[1, 1, 1, 1]]))
    g = LW.rvi(m)[0]
    check("hand: 无滑动、支付全 1，A–C 来回 4+4 步，r̄*=2/8", abs(g - 0.25) < 1e-9, rvi=g, hand=0.25)

    # 2 枚举
    for k, pay in enumerate(base["regimes"] + [[1, 1, 1, 1], [1, 4, 1, 4]]):
        best, arg, D = best_cycle(pay)
        g = LW.rvi(LW.build_model(LW.make_cfg(slip_p=1.0, regimes=[pay])))[0]
        check(f"enumeration: 无滑动 pay={pay}", abs(g - best) < 1e-9, rvi=g, best_cycle=best, cycle=arg)
    check("enumeration: 站间步数（绕开其他站）", True, dist={f"{a}{b}": v for (a, b), v in D.items()})

    # 3 独立建模
    worst = 0.0
    for k in range(len(base["regimes"])):
        mod = LW.build_model(base, regime=k)
        own = own_base_model(base["regimes"][k], base["slip_p"])
        for (cell, last, kk, L, b, tw), i in mod["index"].items():
            rc = LW.CELLS[cell]
            for a in range(4):
                rexp, nxt = own[(rc, last, a)]
                worst = max(worst, abs(rexp - mod["R"][i, a]))
                got = {}
                for mm in range(mod["NS"].shape[2]):
                    pr = mod["P"][i, a, mm]
                    if pr > 0:
                        s2 = mod["states"][mod["NS"][i, a, mm]]
                        key = (LW.CELLS[s2[0]], s2[1])
                        got[key] = got.get(key, 0.0) + pr
                for key in set(got) | set(nxt):
                    worst = max(worst, abs(got.get(key, 0.0) - nxt.get(key, 0.0)))
    check("independent model: 三套规律的转移与期望奖励逐项一致", worst < 1e-12, max_abs_diff=worst)

    # 4 独立求解
    for k in range(len(base["regimes"])):
        mod = LW.build_model(base, regime=k)
        g_rvi = LW.rvi(mod)[0]
        g_pi, _, it = policy_iteration(mod)
        check(f"policy iteration vs RVI: R{k}", abs(g_rvi - g_pi) < 1e-8, rvi=g_rvi, pi=float(g_pi), pi_iters=it)
    cfg = LW.make_cfg(h=1e-2)
    mj = LW.build_model(cfg, joint_regime=True)
    g_rvi = LW.rvi(mj, tol=1e-10)[0]
    g_pi, pij, it = policy_iteration(mj)
    check("policy iteration vs RVI: 规律可见的切换世界 h=0.01", abs(g_rvi - g_pi) < 1e-8, rvi=g_rvi, pi=float(g_pi), pi_iters=it)

    # 5 恒等式
    models = [LW.build_model(base, regime=k) for k in range(3)]
    pis = [LW.rvi(mm)[1] for mm in models]
    cross = [LW.policy_rate(models[j], pis[0])[0] for j in range(3)]
    for h in [1e-3, 1e-2]:
        mjh = LW.build_model(LW.make_cfg(h=h), joint_regime=True)
        frozen = LW.policy_rate(mjh, LW.lift(pis[0], models[0], mjh, {2}), tol=1e-11)[0]
        check(f"identity: 冻结 R0 的奖励率 = 三套规律下的平均（h={h}）", abs(frozen - np.mean(cross)) < 1e-8,
              frozen=frozen, mean_cross=float(np.mean(cross)))

    # 6 模拟器与模型一致
    def table_policy(mod, pi, cfg):
        """把精确模型上的表格策略接到模拟器：按 info 里的真实状态查表。"""
        idx = mod["index"]
        joint = len({st[2] for st in mod["states"]}) > 1
        k_fixed = mod["states"][0][2]
        def act(info):
            last = info["last"] if info["last"] != LW.NONE else 0      # lifetime 开头的暂态，随便按 A 处理
            key = (info["cell"], last, info["regime"] if joint else k_fixed,
                   info["light"] if cfg["cue"] else 0, info["battery"] if cfg["battery"] else 0, info["tow"])
            return int(pi[idx[key]])
        return act

    sims = []
    g0, pi0 = LW.rvi(models[0])[:2]
    sims.append(("基本世界 R0", base, models[0], pi0, g0))
    cb = LW.dial_cfg(19)
    mb = LW.build_model(cb)
    gb, pib = LW.rvi(mb, tol=1e-9)[:2]
    sims.append(("电量档", cb, mb, pib, gb))
    cc = LW.dial_cfg(20)
    cc["cue"]["h_sign"] = 0.0
    mc = LW.build_model(cc)
    gc, pic = LW.rvi(mc, tol=1e-9)[:2]
    sims.append(("指示灯档（符号不翻）", cc, mc, pic, gc))
    cs = LW.make_cfg(h=1e-2)
    sims.append(("切换 h=0.01（策略读真实规律）", cs, mj, pij, g_pi))
    for i, (name, cfg, mod, pi, g) in enumerate(sims):
        act = table_policy(mod, pi, cfg)
        rs, env = simulate(cfg, act, steps, seed=100 + i)
        warm = steps // 10
        mean, se = batch_rate(rs[warm:])
        check(f"simulator vs model: {name}", abs(mean - g) < 4 * se, empirical=mean, se=se, exact=float(g),
              z=(mean - g) / se, steps=steps)

    # 7 延迟
    n = 200_000
    act = table_policy(models[0], pi0, base)
    r0, _ = simulate(base, act, n, seed=7)
    r1, _ = simulate(LW.make_cfg(pay_delay=20), act, n, seed=7)
    check("delay: 有 20 步延迟的累计奖励 = 无延迟去掉最后 20 步", abs(r1.sum() - r0[:-20].sum()) < 1e-9
          and np.allclose(r1[20:], r0[:-20]), with_delay=float(r1.sum()), without_last20=float(r0[:-20].sum()))

    # 8 行为检查
    env = LW.LadderWorld(LW.make_cfg(episodic=True, episode_len=100), seed=3)
    resets_ok = True
    for t in range(1, 1001):
        _, _, info = env.step(int(env.rng.integers(4)))
        if t % 100 == 0 and info["last"] != LW.NONE:
            resets_ok = False
    check("episodic: 每 100 步复位，last 清空", resets_ok)

    cd = LW.make_cfg(door=dict(door="N", schedule=[(1000, 6000)]))
    env = LW.LadderWorld(cd, seed=4)
    door_cell = LW.IDX[LW.DOORS["N"]]
    entered_closed, entered_open = 0, 0
    prev, prev_open = env.cell, env.door_open
    for t in range(1, 20001):
        _, _, info = env.step(int(env.rng.integers(4)))
        if info["cell"] == door_cell and prev != door_cell:
            if prev_open:
                entered_open += 1
            else:
                entered_closed += 1
        prev, prev_open = info["cell"], info["door_open"]
    check("door schedule: 关门期间从未走进北门格（开门期间走进过）", entered_closed == 0 and entered_open > 0,
          entered_while_closed=entered_closed, entered_while_open=entered_open)

    env = LW.LadderWorld(LW.dial_cfg(18), seed=5)
    o = env.observe()
    codes = {LW.local_view(i) for i in range(LW.N)}
    changed = [i for i in range(LW.N) if LW.local_view(i, ("N",)) != LW.local_view(i)]
    check("local obs: 观测不含格号；关门时门旁格子的墙码改变", len(o) == 2 and len(changed) > 0,
          obs_example=list(o), distinct_wall_codes=len(codes), cells_changed_by_closing_N=len(changed))

    env = LW.LadderWorld(LW.make_cfg(h=1e-2), seed=6)
    sw, kprev = 0, env.k
    for t in range(200_000):
        _, _, info = env.step(int(env.rng.integers(4)))
        sw += info["regime"] != kprev
        kprev = info["regime"]
    rate = sw / 200_000
    check("switching: 经验切换率与 h=0.01 一致（4 个标准误内）", abs(rate - 1e-2) < 4 * np.sqrt(1e-2 * 0.99 / 200_000),
          empirical=rate)

    out = dict(checks=CHECKS, all_passed=all(c["passed"] for c in CHECKS), seconds=round(time.time() - t0, 1),
               sim_steps=steps)
    root = os.path.dirname(HERE)
    with open(os.path.join(root, "assets", "crl-ladder-world", "checks.json"), "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=1)
    print("all_passed", out["all_passed"], "seconds", out["seconds"])


if __name__ == "__main__":
    main()
