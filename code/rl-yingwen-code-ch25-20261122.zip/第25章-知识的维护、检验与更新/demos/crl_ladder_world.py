# -*- coding: utf-8 -*-
"""四区仓库：第三部分的能力阶梯世界（环境与精确参照）。

方案：04-交接与计划/逐页审阅-新生视角/1119/第三部分例子方案.md §四、§六第二步。
说明与档位表：assets/crl-ladder-world/README.md。

本文件有两部分，彼此只共享地图常数：
1. LadderWorld：给学习器用的模拟器，lifetime 只在开始时 reset 一次；
   step(action) 返回 (观测, 奖励, info)，info 里的真实状态只供评价，学习器不得读取。
2. build_model / rvi / policy_rate / discounted_policy：固定一段规律时的精确模型，
   用相对值迭代算最优奖励率 r̄*，并算若干“过时策略”的精确奖励率作参照。

同一步里事件的先后（模拟器与精确模型一致）：
  (1) 拖车中（tow>0）则动作无效、原地不动；否则按滑动规则移动；
  (2) 进入与上次不同的站，得该站当前支付（用本步开始时的支付规律与指示灯）；
  (3) 电量减 1，到充电桩充满；电量耗尽且不在桩上，则拖到桩上、充满、冻结 T 步；
  (4) 支付若有延迟 D，记入队列，D 步后到账；
  (5) 外生变化：支付规律切换、指示灯翻转、指示符号翻转、门开关、滑动概率重采样、回合复位。

只用 numpy。用法：
    python3 demos/crl_ladder_world.py            # 算全部参照，写 assets/crl-ladder-world/reference.json
"""
import json, os, sys, time
from collections import deque
import numpy as np

# ---------------------------------------------------------------- 地图（与第 21、22 章文献原型同一张图）
LAYOUT = [
    "#############",
    "#.....#.....#",
    "#.....#.....#",
    "#...........#",
    "#.....#.....#",
    "#.....#.....#",
    "##.####.....#",
    "#.....###.###",
    "#.....#.....#",
    "#.....#.....#",
    "#...........#",
    "#.....#.....#",
    "#############",
]
H, W = len(LAYOUT), len(LAYOUT[0])
CELLS = [(r, c) for r in range(H) for c in range(W) if LAYOUT[r][c] == "."]
IDX = {rc: i for i, rc in enumerate(CELLS)}
N = len(CELLS)                                  # 104 格
MOVES = [(-1, 0), (1, 0), (0, -1), (0, 1)]      # 上 下 左 右
DOORS = {"N": (3, 6), "W": (6, 2), "E": (7, 9), "S": (10, 6)}
# 每区一个站。A、C 紧挨西门两侧（近站对，相距 4 步），B、D 在东侧两房的外角（远站）。
STATIONS = {"A": (5, 1), "B": (1, 11), "C": (7, 1), "D": (11, 11)}
NAMES = "ABCD"
ST_CELL = [IDX[STATIONS[k]] for k in NAMES]
NONE = 4                                        # “还没交过货”


def next_table(closed=()):
    """NXT[i, d]：在格 i 往方向 d 走一步到的格；墙和关着的门挡住则原地不动。
    门关时，站在门格里的智能体仍可走出来，只是不能再走进去。"""
    blocked = {IDX[DOORS[d]] for d in closed}
    nxt = np.zeros((N, 4), dtype=np.int64)
    for i, (r, c) in enumerate(CELLS):
        for d, (dr, dc) in enumerate(MOVES):
            j = IDX.get((r + dr, c + dc))
            nxt[i, d] = i if (j is None or j in blocked) else j
    return nxt


def slip_dist(p):
    """按意图走的概率 p，其余三个方向各 (1-p)/3。默认 p=2/3，即其余各 1/9（SPS 1999）。"""
    q = (1.0 - p) / 3.0
    return np.array([[p if e == d else q for e in range(4)] for d in range(4)])


DEFAULT = dict(
    slip_p=2.0 / 3.0,
    stations="ABCD",            # 起作用的站；去掉的站当普通格
    regimes=[[1.0, 6.0, 0.5, 0.5],     # R0：A 为中转、远站 B 大额（经北门）
             [0.5, 0.5, 1.0, 6.0],     # R1：C 为中转、远站 D 大额（经南门）
             [1.5, 0.25, 1.0, 0.25]],  # R2：近站对 A–C 来回（经西门）
    h=0.0,                      # 第 15、22 章：每步以 h 的概率切到另一套规律（均匀选），不预告
    regime0=0,
    episodic=False,             # 第 16 章关掉时：有回合、有复位
    episode_len=200,
    pay_delay=0,                # 第 17 章：支付晚 D 步到账
    obs="full",                 # 第 18 章："full" 或 "local"
    battery=None,               # 第 19 章：dict(cap=, charger="N", tow=)
    cue=None,                   # 第 20 章：dict(station="C", hi=, lo=, p_light=, h_sign=, sign0=1)
    slip_drift=None,            # 第 23 章：dict(period=, low=, high=)
    door=None,                  # 第 25 章：dict(door="E", p_close=, p_open=) 或 dict(door="E", schedule=[(t0,t1),...])
)


def make_cfg(**kw):
    cfg = json.loads(json.dumps(DEFAULT))
    for k, v in kw.items():
        if k not in cfg:
            raise KeyError(k)
        cfg[k] = json.loads(json.dumps(v))     # 深拷贝，改 cfg 不会改到 DIALS
    return cfg


# ---------------------------------------------------------------- 模拟器
class LadderWorld:
    def __init__(self, cfg=None, seed=0):
        self.cfg = cfg or make_cfg()
        self.rng = np.random.default_rng(seed)
        c = self.cfg
        self.station_at = {ST_CELL[NAMES.index(k)]: NAMES.index(k) for k in c["stations"]}
        self.nxt_open = next_table()
        self.nxt_closed = next_table((c["door"]["door"],)) if c["door"] else None
        self.charger = IDX[DOORS[c["battery"]["charger"]]] if c["battery"] else None
        self.reset()

    # lifetime 只调用一次（回合档除外，由 step 内部复位位置，学习器不复位）
    def reset(self):
        c, rng = self.cfg, self.rng
        non_station = [i for i in range(N) if i not in self.station_at and i != self.charger]
        self.cell = int(rng.choice(non_station))
        self.last = NONE
        self.k = c["regime0"]
        self.t = 0
        self.slip_p = c["slip_p"]
        self.queue = deque()
        self.L = int(rng.integers(2)) if c["cue"] else 0
        self.sign = c["cue"].get("sign0", 1) if c["cue"] else 1
        self.b = c["battery"]["cap"] if c["battery"] else 0
        self.tow = 0
        self.door_open = True
        if c["door"] and "schedule" in c["door"]:
            self.door_open = not self._scheduled_closed(0)
        return self.observe()

    def _scheduled_closed(self, t):
        return any(t0 <= t < t1 for t0, t1 in self.cfg["door"]["schedule"])

    def pay(self, j):
        c = self.cfg
        if c["cue"] and NAMES[j] == c["cue"]["station"]:
            match = (self.L == 1) == (self.sign > 0)
            return c["cue"]["hi"] if match else c["cue"]["lo"]
        return float(c["regimes"][self.k][j])

    def step(self, a):
        c, rng = self.cfg, self.rng
        r_now = 0.0
        if self.tow > 0:                                   # (1) 拖车冻结
            self.tow -= 1
            # 照常抽打滑用的随机数再丢掉：每步抽的个数只取决于 u，与动作和是否被拖无关，
            # 配对比较的两个学习器才一直共用同一串世界随机数（共同随机数）。
            if rng.random() >= self.slip_p:
                rng.integers(3)
        else:
            u = rng.random()
            d = a if u < self.slip_p else [e for e in range(4) if e != a][int(rng.integers(3))]
            nxt = self.nxt_open if self.door_open or self.nxt_closed is None else self.nxt_closed
            self.cell = int(nxt[self.cell, d])
            j = self.station_at.get(self.cell)               # (2) 交货
            if j is not None and j != self.last:
                r_now = self.pay(j)
                self.last = j
            if c["battery"]:                                 # (3) 电量
                self.b -= 1
                if self.cell == self.charger:
                    self.b = c["battery"]["cap"]
                elif self.b == 0:
                    self.cell = self.charger
                    self.b = c["battery"]["cap"]
                    self.tow = c["battery"]["tow"]
        if c["pay_delay"] > 0:                               # (4) 延迟到账
            self.queue.append(r_now)
            r = self.queue.popleft() if len(self.queue) > c["pay_delay"] else 0.0
        else:
            r = r_now
        # (5) 外生变化
        K = len(c["regimes"])
        if c["h"] > 0 and K > 1 and rng.random() < c["h"]:
            others = [x for x in range(K) if x != self.k]
            self.k = others[int(rng.integers(len(others)))]
        if c["cue"]:
            if rng.random() < c["cue"]["p_light"]:
                self.L = 1 - self.L
            if rng.random() < c["cue"]["h_sign"]:
                self.sign = -self.sign
        self.t += 1
        if c["door"]:
            if "schedule" in c["door"]:
                self.door_open = not self._scheduled_closed(self.t)
            elif self.door_open and rng.random() < c["door"]["p_close"]:
                self.door_open = False
            elif (not self.door_open) and rng.random() < c["door"]["p_open"]:
                self.door_open = True
        if c["slip_drift"] and self.t % c["slip_drift"]["period"] == 0:
            self.slip_p = float(rng.uniform(c["slip_drift"]["low"], c["slip_drift"]["high"]))
        if c["episodic"] and self.t % c["episode_len"] == 0:
            non_station = [i for i in range(N) if i not in self.station_at and i != self.charger]
            self.cell = int(rng.choice(non_station))
            self.last = NONE
        return self.observe(), r, self.info()

    def info(self):
        """真实状态，只供评价。"""
        return dict(t=self.t, cell=self.cell, last=self.last, regime=self.k, light=self.L,
                    sign=self.sign, battery=self.b, tow=self.tow, door_open=self.door_open,
                    slip_p=self.slip_p)

    def observe(self):
        c = self.cfg
        extra = []
        if c["cue"]:
            extra.append(self.L)
        if c["battery"]:
            extra += [self.b, int(self.tow > 0)]
        if c["obs"] == "full":
            return (self.cell, self.last, *extra)
        # 局部观测：身边 8 格是否走得进（墙或关着的门记 1），脚下站标（0 无，1–4 为 A–D）
        closed = () if self.door_open or not c["door"] else (c["door"]["door"],)
        return (local_view(self.cell, closed), self.station_at.get(self.cell, -1) + 1, *extra)


NEIGH8 = [(-1, -1), (-1, 0), (-1, 1), (0, -1), (0, 1), (1, -1), (1, 0), (1, 1)]


def local_view(cell, closed=()):
    """身边 3×3（不含自己）的 8 位墙码；closed 是关着的门的名字，关着的门格也记作墙。"""
    r, c = CELLS[cell]
    shut = {IDX[DOORS[d]] for d in closed}
    code = 0
    for bit, (dr, dc) in enumerate(NEIGH8):
        j = IDX.get((r + dr, c + dc))
        if j is None or j in shut:
            code |= 1 << bit
    return code


# ---------------------------------------------------------------- 精确模型
def build_model(cfg, regime=None, sign=1, door_closed=False, slip_p=None, joint_regime=False):
    """固定一段规律，枚举状态与转移。返回 dict(NS, P, R, states, index)。

    状态 = (格, 上次交货站 0–3, 规律 k, 指示灯 L, 电量 b, 拖车剩余步数)。
    - joint_regime=True：规律 k 进状态并按 h 切换（“知道当前规律的最优者”的精确参照）；
      否则 k 固定为 regime。
    - 有 cue 时 L 进状态并按 p_light 翻转；符号 sign 固定。
    - 有 battery 时 b ∈ 1..cap 进状态，另有拖车状态 (桩, last, k, L, cap, 1..tow)。
    - 支付延迟不改变任何策略的奖励率（同一奖励序列整体后移 D 步），模型里不建队列。
    - “还没交过货”只在 lifetime 开头出现一次，是暂态，模型不含。
    """
    c = cfg
    p = c["slip_p"] if slip_p is None else slip_p
    S_D = slip_dist(p)
    nxt = next_table((c["door"]["door"],)) if door_closed else next_table()
    active = {ST_CELL[NAMES.index(k)]: NAMES.index(k) for k in c["stations"]}
    K = len(c["regimes"])
    ks = list(range(K)) if joint_regime else [c["regime0"] if regime is None else regime]
    Ls = [0, 1] if c["cue"] else [0]
    bat = c["battery"]
    caps = list(range(1, bat["cap"] + 1)) if bat else [0]
    charger = IDX[DOORS[bat["charger"]]] if bat else None

    states = []
    for cell in range(N):
        for last in range(4):
            for k in ks:
                for L in Ls:
                    for b in caps:
                        states.append((cell, last, k, L, b, 0))
    if bat:
        for last in range(4):
            for k in ks:
                for L in Ls:
                    for tw in range(1, bat["tow"] + 1):
                        states.append((charger, last, k, L, bat["cap"], tw))
    index = {s: i for i, s in enumerate(states)}

    def pay(j, k, L):
        if c["cue"] and NAMES[j] == c["cue"]["station"]:
            return c["cue"]["hi"] if ((L == 1) == (sign > 0)) else c["cue"]["lo"]
        return float(c["regimes"][k][j])

    def exo(k, L):
        out = []
        if joint_regime and c["h"] > 0 and K > 1:
            kb = [(1 - c["h"], k)] + [(c["h"] / (K - 1), x) for x in range(K) if x != k]
        else:
            kb = [(1.0, k)]
        if c["cue"]:
            pl = c["cue"]["p_light"]
            Lb = [(1 - pl, L), (pl, 1 - L)]
        else:
            Lb = [(1.0, L)]
        for pk, nk in kb:
            for pL, nL in Lb:
                if pk * pL > 0:
                    out.append((pk * pL, nk, nL))
        return out

    S = len(states)
    rows = []
    M = 0
    for s in states:
        cell, last, k, L, b, tw = s
        per_a = []
        for a in range(4):
            outs = {}
            rexp = 0.0
            if tw > 0:
                moves = [(1.0, cell, None)]
            else:
                moves = [(S_D[a, d], int(nxt[cell, d]), d) for d in range(4) if S_D[a, d] > 0]
            for pm, nc, _ in moves:
                r = 0.0
                nl, nb, ntw = last, b, tw
                if tw > 0:
                    ntw = tw - 1
                else:
                    j = active.get(nc)
                    if j is not None and j != last:
                        r = pay(j, k, L)
                        nl = j
                    if bat:
                        nb = b - 1
                        if nc == charger:
                            nb = bat["cap"]
                        elif nb == 0:
                            nc, nb, ntw = charger, bat["cap"], bat["tow"]
                rexp += pm * r
                for pe, nk, nL in exo(k, L):
                    key = index[(nc, nl, nk, nL, nb, ntw)]
                    outs[key] = outs.get(key, 0.0) + pm * pe
            per_a.append((rexp, outs))
            M = max(M, len(outs))
        rows.append(per_a)
    NS = np.zeros((S, 4, M), dtype=np.int64)
    P = np.zeros((S, 4, M))
    R = np.zeros((S, 4))
    for i, per_a in enumerate(rows):
        for a, (rexp, outs) in enumerate(per_a):
            R[i, a] = rexp
            for m, (key, pr) in enumerate(outs.items()):
                NS[i, a, m] = key
                P[i, a, m] = pr
    assert np.allclose(P.sum(-1), 1.0)
    return dict(NS=NS, P=P, R=R, states=states, index=index)


def rvi(model, tol=1e-10, tau=0.5, max_iter=400000):
    """相对值迭代（带 τ 阻尼，避免周期性）。返回 (r̄*, 贪婪策略, 相对值, (下界, 上界), 迭代次数)。
    对弱连通的 MDP，min(Tv−v) ≤ r̄* ≤ max(Tv−v) 对任意 v 成立，所以上下界就是证书。"""
    NS, P, R = model["NS"], model["P"], model["R"]
    v = np.zeros(len(R))
    for it in range(1, max_iter + 1):
        Q = R + (P * v[NS]).sum(-1)
        Tv = Q.max(1)
        diff = Tv - v
        lo, hi = float(diff.min()), float(diff.max())
        if hi - lo < tol:
            break
        v = v + tau * diff
        v -= v[0]
    return 0.5 * (lo + hi), Q.argmax(1), v, (lo, hi), it


def policy_rate(model, pi, tol=1e-10, tau=0.5, max_iter=400000):
    """固定确定性策略 pi 的奖励率（有滑动时每个策略都只有一个常返类）。返回 (率, (下界, 上界))。"""
    NS, P, R = model["NS"], model["P"], model["R"]
    S = len(R)
    ar = np.arange(S)
    nsp, pp, rp = NS[ar, pi], P[ar, pi], R[ar, pi]
    v = np.zeros(S)
    for it in range(1, max_iter + 1):
        Tv = rp + (pp * v[nsp]).sum(-1)
        diff = Tv - v
        lo, hi = float(diff.min()), float(diff.max())
        if hi - lo < tol:
            break
        v = v + tau * diff
        v -= v[0]
    return 0.5 * (lo + hi), (lo, hi)


def discounted_policy(model, gamma, tol=1e-10, max_iter=1000000):
    """折扣 γ 下的最优策略（值迭代）。"""
    NS, P, R = model["NS"], model["P"], model["R"]
    v = np.zeros(len(R))
    for it in range(max_iter):
        Q = R + gamma * (P * v[NS]).sum(-1)
        nv = Q.max(1)
        if np.max(np.abs(nv - v)) < tol * (1 - gamma):
            v = nv
            break
        v = nv
    return Q.argmax(1)


def lift(pi_small, small, big, drop):
    """把小状态空间上的策略搬到大状态空间：大状态去掉 drop 指定的分量后查小策略。
    drop 为分量下标集合，被去掉的分量在小模型里取小模型自己的值（如 k 固定、b=0）。"""
    out = np.zeros(len(big["states"]), dtype=np.int64)
    sidx = small["index"]
    proto = small["states"][0]
    for i, s in enumerate(big["states"]):
        key = tuple(proto[j] if j in drop else s[j] for j in range(6))
        out[i] = pi_small[sidx[key]] if key in sidx else 0
    return out


def bfs_dist(src, nxt=None):
    nxt = next_table() if nxt is None else nxt
    dist = {src: 0}
    fr = [src]
    while fr:
        nf = []
        for x in fr:
            for y in nxt[x]:
                y = int(y)
                if y not in dist:
                    dist[y] = dist[x] + 1
                    nf.append(y)
        fr = nf
    return dist


# ---------------------------------------------------------------- 档位：每章“打开”时的设定（在默认世界上叠加）
DIALS = {
    15: dict(h=1e-3),                                            # 规律切换，平均 1000 步一次
    16: dict(),                                                  # 默认就是 lifetime 不复位；关掉时 episodic=True
    17: dict(pay_delay=20),
    18: dict(obs="local"),
    19: dict(battery=dict(cap=40, charger="E", tow=50)),
    20: dict(cue=dict(station="B", hi=6.0, lo=0.5, p_light=0.01, h_sign=1e-4, sign0=1)),
    21: dict(h=1e-3),                                            # 关掉时 stations="AB"、只用 R0
    22: dict(h=1e-2),                                            # 切换频繁，门与地形不变
    23: dict(slip_drift=dict(period=50000, low=0.5, high=0.9),
             cue=dict(station="B", hi=6.0, lo=0.5, p_light=0.01, h_sign=1e-4, sign0=1)),
    25: dict(door=dict(door="N", p_close=5e-6, p_open=5e-6)),
}
OFF = {16: dict(episodic=True), 21: dict(stations="AB", regimes=[[1.0, 6.0, 0.5, 0.5]])}


def dial_cfg(*chapters, **extra):
    kw = {}
    for ch in chapters:
        for k, v in DIALS[ch].items():
            kw[k] = v
    kw.update(extra)
    return make_cfg(**kw)


# ---------------------------------------------------------------- 参照计算
def _r(x, n=6):
    return float(round(x, n))


def references(fast=False):
    out = {}
    base = make_cfg()
    t0 = time.time()

    # 0. 基本几何
    nd = next_table()
    out["geometry"] = dict(
        cells=N, stations={k: list(STATIONS[k]) for k in NAMES}, doors={k: list(v) for k, v in DOORS.items()},
        station_dist={a: {b: bfs_dist(ST_CELL[i], nd)[ST_CELL[j]] for j, b in enumerate(NAMES)} for i, a in enumerate(NAMES)},
        slip_p=base["slip_p"])

    # 1. 每套规律各自的最优奖励率，以及各最优策略在别的规律下的奖励率
    models, pis, gs = [], [], []
    for k in range(len(base["regimes"])):
        m = build_model(base, regime=k)
        g, pi, v, bd, it = rvi(m)
        models.append(m); pis.append(pi); gs.append(g)
    cross = [[_r(policy_rate(models[j], pis[i])[0]) for j in range(len(gs))] for i in range(len(gs))]
    out["regimes"] = dict(pay=base["regimes"], r_star=[_r(g) for g in gs], policy_i_under_regime_j=cross)

    # 2. 第 15、22 章：切换（规律可见的最优者 / 冻结在 R0 的策略 / 按平均支付的盲策略）
    sw = []
    mean = list(np.mean(base["regimes"], 0))
    mm = build_model(make_cfg(regimes=[mean]))
    pim = rvi(mm)[1]
    for h in ([1e-3, 1e-2] if fast else [1e-4, 1e-3, 1e-2]):
        cfg = make_cfg(h=h)
        mj = build_model(cfg, joint_regime=True)
        gj = rvi(mj, tol=1e-9)[0]
        stale = policy_rate(mj, lift(pis[0], models[0], mj, {2}), tol=1e-9)[0]
        blind = policy_rate(mj, lift(pim, mm, mj, {2}), tol=1e-9)[0]
        sw.append(dict(h=h, oracle=_r(gj), frozen_R0=_r(stale), mean_pay_blind=_r(blind)))
    out["switching"] = dict(rows=sw, mean_pay=[_r(x) for x in mean],
                            note="oracle 知道当前规律；frozen_R0 一直用 R0 的最优策略；mean_pay_blind 用平均支付下的最优策略")

    # 3. 第 16 章：折扣 γ 的最优策略在本世界的奖励率（R0）
    m0, g0 = models[0], gs[0]
    out["discount"] = dict(r_star=_r(g0), rows=[
        dict(gamma=gam, rate=_r(policy_rate(m0, discounted_policy(m0, gam, tol=1e-8))[0]))
        for gam in [0.5, 0.8, 0.9, 0.95, 0.98, 0.99, 0.999]])

    # 4. 第 18 章：局部观测的混叠
    groups = {}
    for i in range(N):
        key = (local_view(i), {ST_CELL[j]: j for j in range(4)}.get(i, -1) + 1)
        groups.setdefault(key, []).append(i)
    sizes = sorted((len(v) for v in groups.values()), reverse=True)
    out["aliasing"] = dict(distinct_observations=len(groups), cells=N, largest_groups=sizes[:8],
                           singleton_cells=sum(1 for x in sizes if x == 1),
                           note="观测不含 last，所以同一格的 4 个 last 值也混在一起")

    # 5. 第 19 章：电量
    cfg = dial_cfg(19)
    mb = build_model(cfg)
    gb = rvi(mb, tol=1e-9)[0]
    blind = policy_rate(mb, lift(pis[0], m0, mb, {4, 5}), tol=1e-9)[0]
    out["battery"] = dict(cfg=cfg["battery"], states=len(mb["states"]), r_star=_r(gb),
                          battery_blind=_r(blind), r_star_no_battery=_r(g0))

    # 6. 第 20 章：指示灯
    cfg = dial_cfg(20)
    mc = build_model(cfg, sign=1)
    gc, pic = rvi(mc, tol=1e-9)[:2]
    R2 = [list(r) for r in base["regimes"]]
    R2[0][1] = 0.5 * (cfg["cue"]["hi"] + cfg["cue"]["lo"])
    mmc = build_model(make_cfg(regimes=R2))
    blind = policy_rate(mc, lift(rvi(mmc)[1], mmc, mc, {3}), tol=1e-9)[0]
    mneg = build_model(cfg, sign=-1)
    gneg = rvi(mneg, tol=1e-9)[0]
    stale = policy_rate(mneg, pic, tol=1e-9)[0]
    out["cue"] = dict(cfg=cfg["cue"], r_star=_r(gc), light_blind=_r(blind), r_star_after_flip=_r(gneg),
                      stale_sign_after_flip=_r(stale),
                      note="指示灯外生、与位置无关，所以不看灯的策略的奖励率等于把 B 的支付换成均值后的奖励率")

    # 7. 第 21 章关掉时：只有 A、B 两站、只用 R0
    moff = build_model(make_cfg(**OFF[21]))
    out["two_stations"] = dict(r_star=_r(rvi(moff)[0]))

    # 8. 第 23 章：滑动概率
    rows = []
    for p in [0.5, 0.6, 2.0 / 3.0, 0.75, 0.9]:
        mp = build_model(base, slip_p=p)
        gp = rvi(mp)[0]
        rows.append(dict(slip_p=_r(p, 4), r_star=_r(gp), policy_for_2_3=_r(policy_rate(mp, pis[0])[0])))
    out["slip"] = rows

    # 9. 第 25 章：北门关闭
    cfg = dial_cfg(25)
    mcl = build_model(cfg, door_closed=True)
    gcl, picl = rvi(mcl)[:2]
    out["door"] = dict(door=cfg["door"]["door"], r_star_open=_r(g0), r_star_closed=_r(gcl),
                       closed_believer_in_open=_r(policy_rate(m0, picl)[0]),
                       open_believer_in_closed=_r(policy_rate(mcl, pis[0])[0]))
    out["seconds"] = round(time.time() - t0, 1)
    return out


def main():
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    outdir = os.path.join(root, "assets", "crl-ladder-world")
    os.makedirs(outdir, exist_ok=True)
    ref = references(fast="--fast" in sys.argv)
    with open(os.path.join(outdir, "reference.json"), "w", encoding="utf-8") as f:
        json.dump(ref, f, ensure_ascii=False, indent=1)
    print(json.dumps(ref, ensure_ascii=False, indent=1))


if __name__ == "__main__":
    main()
