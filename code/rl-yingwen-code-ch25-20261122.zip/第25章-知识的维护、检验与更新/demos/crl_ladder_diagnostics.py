# -*- coding: utf-8 -*-
"""四区仓库阶梯的诊断与改法（11-20）。

正式阶梯（crl_ladder_learners.py）里有几档没到预期，这里放查原因、试改法用的档。
每一档与正式运行用同一套种子规则（世界随机数 = seed，学习器随机数 = 10000 + seed），
所以同一种子可以直接与 runs/formal-<章>.json 里的档配对比较。

第 17 章（支付晚 20 步，学时滞 D̂）
  given19     写定 D=19：看“交货后一步”的状态当原因，会怎样
  hyst0.1     D̂ 加滞后：新时滞的误差须比当前低 10% 才换
  early0.15   误差在最小值 1.15 倍以内的时滞里取最大的（最早的原因）
  early0.3    同上，1.3 倍
  gain        选“动作起作用”的时滞：argmax_d [err_s(d) − err_sa(d)]
第 18 章（局部观测，记上次交货的站）
  given-sarsa0.9 / given-sarsa0.97   学习器换成差分 Sarsa(λ)
第 20 章（灯与 B 的支付相关，含义会翻）
  pred0.1 / pred0.3   状态里放“对 B 支付的预测”1{q[灯] > .5}，不放灯本身
  opt1e-4 / opt3e-4 / opt1e-3   同上，再加“久未检验就乐观”：每步 q += ρ(1 − q)
                       （思路同 Dyna-Q+ 给久未试的转移加奖励，Sutton & Barto 2018 第 8.3 节）

用法：
  python3 demos/crl_ladder_diagnostics.py --arms ch17/d20/early0.3 --seeds 20 --seed0 100
  python3 demos/crl_ladder_diagnostics.py --arms ch20/flip/opt3e-4 ch20/fixed/opt3e-4 --seeds 20 --seed0 100
  python3 demos/crl_ladder_diagnostics.py --compare ch20/flip/opt3e-4 ch20/flip/given
  确证（换一批没用过的种子，诊断档与正式档一起跑，--tag 分开存）：
  python3 demos/crl_ladder_diagnostics.py --arms ch20/flip/opt3e-4 ch20/flip/given --seeds 20 --seed0 200 --tag confirm
  python3 demos/crl_ladder_diagnostics.py --compare ch20/flip/opt3e-4 ch20/flip/given --seed-range 200 219
输出：assets/crl-ladder-world/runs/diag-<档>.json，加 --tag 时为 diag-<tag>-<档>.json（结果格式与正式运行相同）。
--arms 也收正式运行的档名（如 ch20/flip/given），用来在新种子上跑对照。
仓库里现有的 diag-*.json 由 11-20 的诊断运行整理而来，只存 lifetime 率与最后 10%（curve 为 null）；
要学习曲线就用 --arms 重跑那一档，会覆盖原文件。
--compare A B：从 runs/ 里所有 formal-*.json 与 diag-*.json 找两档的同种子结果，
打印配对差（lifetime 率与最后 10%）的均值与 95% 区间。
"""
import argparse, glob, json, math, os, sys, time
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import crl_ladder_learners as M
import crl_ladder_world as LW

OUT = M.OUT
B = LW.NAMES.index("B")


# ---------------------------------------------------------------- 第 17 章
class Hyst(M.LagAgent):
    """D̂ 加滞后。"""
    def __init__(s, *a, margin=0.1, **k):
        super().__init__(*a, **k)
        s.margin, s.nch = margin, 0

    def _learn_lag(s, r):
        old, tt = s.Dhat, s.t
        super()._learn_lag(r)
        if s.t != tt and s.t % s.every == 0 and s.Dhat != old and old != 0:
            if not (s.err[s.Dhat] < (1 - s.margin) * s.err[old]):
                s.Dhat = old
        s.nch += int(s.Dhat != old)


class Earliest(M.LagAgent):
    """误差在最小值 (1+tol) 倍以内的时滞里取最大的。"""
    def __init__(s, *a, tol=0.15, **k):
        super().__init__(*a, **k)
        s.tol, s.nch, s.hist = tol, 0, []

    def _learn_lag(s, r):
        old = s.Dhat
        super()._learn_lag(r)
        if s.t % s.every == 0:        # 时滞缓冲未满时 t 停在 0，这里每步都重选（与 11-20 的诊断运行一致）
            m = s.err[1:].min()
            s.Dhat = max(d for d in range(1, s.Dmax + 1) if s.err[d] <= (1 + s.tol) * m)
            s.hist.append(s.Dhat)
        s.nch += int(s.Dhat != old)


class Gain(M.LagAgent):
    """对每个时滞同时学 r̂(s, a) 与 r̂(s)；选加上动作后预测改进最大的时滞。
    交货后一步的状态已能预测奖励，但那一步的动作不起作用，增益约为 0。"""
    def __init__(s, *a, **k):
        super().__init__(*a, **k)
        s.Rs = np.zeros((s.Dmax + 1, 1024))
        s.errs = np.zeros(s.Dmax + 1)
        s.nch, s.hist = 0, []

    def _learn_lag(s, r):
        if len(s.buf) < s.Dmax + 1:
            return
        b = list(s.buf)[-(s.Dmax + 1):][::-1]
        sb = np.fromiter((x[0] for x in b), int, len(b))
        ab = np.fromiter((x[1] for x in b), int, len(b))
        if sb.max() >= s.Rh.shape[1]:
            n = 2 * sb.max() + 2
            Rh = np.zeros((s.Dmax + 1, n, M.NA)); Rh[:, :s.Rh.shape[1]] = s.Rh; s.Rh = Rh
            Rs = np.zeros((s.Dmax + 1, n)); Rs[:, :s.Rs.shape[1]] = s.Rs; s.Rs = Rs
        e = r - s.Rh[s.ar, sb, ab]; s.Rh[s.ar, sb, ab] += 0.05 * e; s.err += 0.001 * (e * e - s.err)
        es = r - s.Rs[s.ar, sb]; s.Rs[s.ar, sb] += 0.05 * es; s.errs += 0.001 * (es * es - s.errs)
        s.t += 1
        if s.t % s.every == 0:
            old = s.Dhat
            s.Dhat = int((s.errs - s.err).argmax())
            s.hist.append(s.Dhat)
            s.nch += int(s.Dhat != old)


# ---------------------------------------------------------------- 第 20 章
class PredCue(M.CueAgent):
    """状态里放 1{q[当前灯] > .5}，q[灯] ≈ P(到 B 拿高价 | 灯)，到 B 拿到支付时更新。"""
    def __init__(s, rng, maker, alpha, rho=0.0):
        super().__init__(rng, maker, "given")
        s.a, s.rho, s.q, s.pl = alpha, rho, [0.5, 0.5], None
        s.thr = 0.5 * (6.0 + 0.5)          # 高价 6 与低价 .5 的中点

    def step(s, obs, r):
        if s.rho:
            s.q[0] += s.rho * (1 - s.q[0]); s.q[1] += s.rho * (1 - s.q[1])
        cell, last, light = obs
        if s.pl is not None and r > 0 and last == B:
            s.q[s.pl] += s.a * (float(r > s.thr) - s.q[s.pl])
        s.pl = light
        return s.L.step(s.ix((cell, last, int(s.q[light] > 0.5))), r)


def cfg20(cond):
    cfg = LW.dial_cfg(20)
    if cond == "fixed":
        cfg["cue"] = dict(cfg["cue"], h_sign=0.0)
    return cfg


def arms(steps):
    """名字 → (世界配置, 造智能体的函数)。名字格式与正式运行相同：章/条件/档。"""
    c17 = M.experiments(steps)["ch17/d20/learned"][0]
    L2 = lambda r: M.mk("L2", r)()
    A = {"ch17/d20/given19": (c17, lambda r: M.LagAgent(r, L2(r), D=19)),
         "ch17/d20/hyst0.1": (c17, lambda r: Hyst(r, L2(r), D=None, margin=0.1)),
         "ch17/d20/early0.15": (c17, lambda r: Earliest(r, L2(r), D=None, tol=0.15)),
         "ch17/d20/early0.3": (c17, lambda r: Earliest(r, L2(r), D=None, tol=0.3)),
         "ch17/d20/gain": (c17, lambda r: Gain(r, L2(r), D=None))}
    for lam in (0.9, 0.97):
        A[f"ch18/local/given-sarsa{lam}"] = (LW.dial_cfg(18), lambda r, lam=lam: M.LocalAgent(r, M.mk("L2sarsa", r, lam=lam)(), "given"))
    for cond in ("flip", "fixed"):
        for a in (0.1, 0.3):
            A[f"ch20/{cond}/pred{a}"] = (cfg20(cond), lambda r, a=a: PredCue(r, lambda: M.mk("L2", r)(), a))
        for rho in ("1e-4", "3e-4", "1e-3"):
            A[f"ch20/{cond}/opt{rho}"] = (cfg20(cond), lambda r, rho=float(rho): PredCue(r, lambda: M.mk("L2", r)(), 0.3, rho))
    # 第 15 章：情境按最近 8 次交货挑（窗口匹配），看它在原来的世界里是否也少跳错
    cm = M.coarse_map(2)
    for cap, cmap in (("full", None), ("coarse", cm)):
        A[f"ch15/h0.001-{cap}/learned-win8"] = (LW.make_cfg(h=1e-3), lambda r, c=cmap: M.ContextAgent(r, M.mk("L1", r), cell_map=c, window=8))
    # 第 24 章：两种接口改法——窗口匹配（win8）；灯换成乐观预测、B 站归预测解释（opt）
    c24 = LW.dial_cfg(15, 19, 23)
    ch = LW.IDX[LW.DOORS[c24["battery"]["charger"]]]
    P, P3 = M.ComboAgent.PARTS, ("context", "battery", "cue")
    for tag, use, fx in (("all", P, False), ("-idbd", P3, False), ("only-context", ("context",), False), ("sum", P3, "sum")):
        A[f"ch24/combo/{tag}-win8"] = (c24, lambda r, u=use, f=fx: M.ComboAgent(r, u, ch, factored=f, window=8))
    # opt 下 B 站的支付不进情境识别；不含 cue 的档（only-context、ctx+bat）只用这一点，状态里不放灯
    for tag, use, fx in (("-idbd", P3, False), ("sum", P3, "sum"), ("only-cue", ("cue",), False),
                         ("only-context", ("context",), False), ("bat+cue", ("battery", "cue"), False),
                         ("ctx+bat", ("context", "battery"), False)):
        A[f"ch24/combo/{tag}-opt"] = (c24, lambda r, u=use, f=fx: M.ComboAgent(r, u, ch, factored=f, cue="opt", b_station=B))
    for tag, use in (("all", P), ("-idbd", P3)):     # 情境上限 6 正好等于 3 套规律 × 2 种灯符号；上限放到 12
        A[f"ch24/combo/{tag}-cap12"] = (c24, lambda r, u=use: M.ComboAgent(r, u, ch, max_ctx=12))
    for tag, use, fx in (("-idbd", P3, False), ("sum", P3, "sum")):
        A[f"ch24/combo/{tag}-win8-opt"] = (c24, lambda r, u=use, f=fx: M.ComboAgent(r, u, ch, factored=f, window=8, cue="opt", b_station=B))
    return A


def all_arms(steps):
    """诊断档加上正式运行的全部档（正式档用于在新种子上跑对照）。"""
    return {**M.experiments(steps), **arms(steps)}


def one(args):
    name, seed, steps = args
    cfg, make = all_arms(steps)[name]
    rng = np.random.default_rng(10_000 + seed)
    ag = make(rng)
    t0 = time.time()
    tr = {}
    rate, curve = M.run(cfg, ag, steps, seed, track=tr)
    extra = dict(track=tr) if tr else {}
    if isinstance(ag, M.LagAgent):
        extra["Dhat"] = ag.Dhat
        if getattr(ag, "hist", None):
            extra["counts"] = {int(k): int(v) for k, v in zip(*np.unique(ag.hist, return_counts=True))}
        if hasattr(ag, "nch"):
            extra["n_change"] = ag.nch
    if isinstance(ag, PredCue):
        extra["q"] = [round(float(x), 3) for x in ag.q]
    if hasattr(ag, "n_switch"):
        extra["n_switch"], extra["n_ctx"] = ag.n_switch, len(ag.ctx)
    return dict(name=name, seed=seed, steps=steps, rate=rate, curve=curve, sec=round(time.time() - t0, 1), **extra)


# ---------------------------------------------------------------- 配对比较
T95 = {1: 12.71, 2: 4.303, 3: 3.182, 4: 2.776, 5: 2.571, 6: 2.447, 7: 2.365, 8: 2.306, 9: 2.262, 10: 2.228,
       11: 2.201, 12: 2.179, 13: 2.160, 14: 2.145, 15: 2.131, 16: 2.120, 17: 2.110, 18: 2.101, 19: 2.093}


def load_all():
    got = {}
    for p in sorted(glob.glob(os.path.join(OUT, "formal-*.json"))) + sorted(glob.glob(os.path.join(OUT, "diag-*.json"))):
        if "formal5m" in p or os.path.basename(p).startswith("diag-smoke-"):
            continue                                   # 500 万步与冒烟记录不与 200 万步的同种子结果混用
        for r in json.load(open(p))["results"]:
            got[(r["name"], r["seed"])] = r
    return got


def last10(r):
    """最后 10% 的率：有曲线就由曲线算（曲线每 1 万步一点，共 200 点），没有就用结果里存的值。"""
    if r.get("curve"):
        return float(np.mean(r["curve"][-20:])) / 1e4
    return r["last10"]


def compare(a, b, lo=None, hi=None):
    got = load_all()
    seeds = sorted(s for (n, s) in got if n == a and (b, s) in got
                   and (lo is None or s >= lo) and (hi is None or s <= hi))
    if len(seeds) < 2:
        sys.exit(f"同种子结果不足：{a} 与 {b} 共有 {len(seeds)} 个")
    for key in ("rate", "last10"):
        val = (lambda r: r["rate"]) if key == "rate" else last10
        d = [val(got[(a, s)]) - val(got[(b, s)]) for s in seeds]
        n, m = len(d), float(np.mean(d))
        sd = float(np.std(d, ddof=1))
        half = T95.get(n - 1, 1.96) * sd / math.sqrt(n)
        print(f"{key:7s} n={n:2d}  {a} − {b} = {m:+.4f} ± {half:.4f}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--arms", nargs="*", default=[])
    ap.add_argument("--seeds", type=int, default=20)
    ap.add_argument("--seed0", type=int, default=100)
    ap.add_argument("--steps", type=int, default=2_000_000)
    ap.add_argument("--procs", type=int, default=3)
    ap.add_argument("--compare", nargs=2, metavar=("A", "B"))
    ap.add_argument("--list", action="store_true")
    ap.add_argument("--tag", default="")
    ap.add_argument("--seed-range", nargs=2, type=int, metavar=("LO", "HI"))
    a = ap.parse_args()
    if a.list:
        print("\n".join(arms(a.steps))); return
    if a.compare:
        compare(*a.compare, *(a.seed_range or (None, None))); return
    known = all_arms(a.steps)
    for n in a.arms:
        if n not in known:
            sys.exit(f"没有这一档：{n}（--list 看全部）")
    from multiprocessing import Pool
    os.makedirs(OUT, exist_ok=True)
    for n in a.arms:
        jobs = [(n, s, a.steps) for s in range(a.seed0, a.seed0 + a.seeds)]
        t0 = time.time()
        with Pool(a.procs) as p:
            res = p.map(one, jobs, chunksize=1)
        path = os.path.join(OUT, f"diag-{a.tag + '-' if a.tag else ''}{n.replace('/', '_')}.json")
        with open(path, "w", encoding="utf-8") as f:
            json.dump(dict(steps=a.steps, seeds=a.seeds, results=res, seconds=round(time.time() - t0, 1)), f)
        print("written", path, "seconds", round(time.time() - t0, 1), flush=True)


if __name__ == "__main__":
    main()
