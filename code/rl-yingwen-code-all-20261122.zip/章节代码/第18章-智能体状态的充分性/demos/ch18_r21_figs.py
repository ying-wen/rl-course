"""11-21 审阅站请求 r1121-132524（第 18 章，分叉 W1）：章首与 18.1–18.2 的配图，
以及四类场景调研页的配图。所有数值由本脚本算出，运行时打印核对。

输出（assets/ch18-r21/）：
  learn-curves.pdf   1635 页：分组表与单表的预报值随趟数变化
  timeline16.pdf     1637 页：lifetime 16 步的奖励时间线与期望累计回报
  grid-alias.pdf     超大网格调研页：网格变大时，单个局部观测能认出位置的格所占比例
  kuhn-call.pdf      不完全信息博弈调研页：乙持 Q、甲下注时跟注与弃牌的期望收益随甲的虚张概率变化

用法：python3 demos/ch18_r21_figs.py
"""
from fractions import Fraction
from pathlib import Path
import random

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter
import numpy as np

from plot_fonts import use_course_fonts, CJK_FAMILY, no_leading_zero

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'assets' / 'ch18-r21'
OUT.mkdir(parents=True, exist_ok=True)

TEAL = '#1b7f79'
RED = '#b8432f'
GOLD = '#b8860b'
INK = '#222222'
MUTED = '#7a7a7a'

use_course_fonts()
plt.rcParams.update({'axes.spines.top': False, 'axes.spines.right': False,
                     'axes.linewidth': .6, 'xtick.major.width': .6,
                     'ytick.major.width': .6})
NLZ = FuncFormatter(no_leading_zero)


# ---------------------------------------------------------------- 1635
def learn_curves():
    """前两趟按八步记录（左、右），之后指示独立等可能（固定种子）。"""
    rng = random.Random(18)
    cues = ['L', 'R'] + [rng.choice('LR') for _ in range(18)]
    pL = pR = pJ = .5
    pJ_avg, n = .5, 0
    rows = [(0, pL, pR, pJ, pJ_avg)]
    for k, c in enumerate(cues, 1):
        y = 1.0 if c == 'L' else 0.0  # 向左：左指示到 B（Y=1），右指示到 W（Y=0）
        if c == 'L':
            pL += .5 * (y - pL)
        else:
            pR += .5 * (y - pR)
        pJ += .5 * (y - pJ)
        n += 1
        pJ_avg += (y - pJ_avg) / (n + 1)  # 步长 1/(n+1)：初值 1/2 当作一条先验样本
        rows.append((k, pL, pR, pJ, pJ_avg))
    print('learn-curves：前三行（趟, pL, pR, pJ常步长, pJ递减步长）')
    for r in rows[:3]:
        print('   ', r)
    print('    最后：', rows[-1])
    ks = [r[0] for r in rows]
    fig, ax = plt.subplots(figsize=(3.1, 2.75))
    ax.axhline(.5, color=MUTED, lw=.7, ls=(0, (3, 2)))
    ax.plot(ks, [r[1] for r in rows], color=TEAL, lw=1.3, marker='o', ms=2.4, label='分组表 $p_{\\mathrm{L}}$')
    ax.plot(ks, [r[2] for r in rows], color=TEAL, lw=1.3, ls='--', marker='o', ms=2.4, label='分组表 $p_{\\mathrm{R}}$')
    ax.plot(ks, [r[3] for r in rows], color=RED, lw=1.3, marker='o', ms=2.4, label='单表 $p_J$，步长 $\\frac{1}{2}$')
    ax.plot(ks, [r[4] for r in rows], color=GOLD, lw=1.3, label='单表 $p_J$，步长递减')
    ax.set_xlim(0, len(cues))
    ax.set_ylim(-.03, 1.03)
    ax.set_yticks([0, .25, .5, .75, 1])
    ax.yaxis.set_major_formatter(NLZ)
    ax.set_xticks([0, 5, 10, 15, 20])
    ax.tick_params(labelsize=9.5, length=2.5)
    ax.set_xlabel('第几趟到 $J$（前两趟即 $t=1,4$）', fontsize=10, fontfamily=CJK_FAMILY)
    ax.set_ylabel('预报值', fontsize=10)
    leg = ax.legend(frameon=False, loc='upper center', bbox_to_anchor=(.45, -.42), ncol=2,
                    handlelength=1.6, columnspacing=.9, prop={'family': CJK_FAMILY, 'size': 9.2})
    fig.tight_layout(pad=.3)
    fig.savefig(OUT / 'learn-curves.pdf', bbox_inches='tight', pad_inches=.03)
    plt.close(fig)


# ---------------------------------------------------------------- 1637
def expected_cumulative(T=16):
    """无记忆（在 J 总向左）与记一位的期望累计回报，精确分数。
    一趟：左指示 3 步，第 2 步得 4；右指示 5 步，第 3 步得 1。记一位每趟 3 步，第 2 步得 4。"""
    half = Fraction(1, 2)
    # dist[t] = 在时刻 t 恰好位于仓库、开始新一趟的概率
    start = [Fraction(0)] * (T + 1)
    start[0] = Fraction(1)
    exp_r = [Fraction(0)] * (T + 1)  # 第 s 步（s=1..T）的期望奖励
    for t in range(T + 1):
        if start[t] == 0:
            continue
        # 左指示
        if t + 2 <= T:
            exp_r[t + 2] += start[t] * half * 4
        if t + 3 <= T:
            start[t + 3] += start[t] * half
        # 右指示
        if t + 3 <= T:
            exp_r[t + 3] += start[t] * half * 1
        if t + 5 <= T:
            start[t + 5] += start[t] * half
    cum_m = [Fraction(0)]
    for s in range(1, T + 1):
        cum_m.append(cum_m[-1] + exp_r[s])
    cum_1 = [Fraction(0)]
    for s in range(1, T + 1):
        cum_1.append(cum_1[-1] + (4 if s % 3 == 2 else 0))
    return cum_m, cum_1


def timeline16():
    T = 16
    cum_m, cum_1 = expected_cumulative(T)
    print(f'timeline16：记一位 J_16 = {cum_1[-1]}，无记忆 J_16 = {cum_m[-1]} ≈ {float(cum_m[-1]):.4f}')
    assert cum_1[-1] == 20 and cum_m[-1] == Fraction(331, 32)
    # 一种指示序列：左右交替（八步记录的延续）
    one_bit = {2: 4, 5: 4, 8: 4, 11: 4, 14: 4}
    memless = {2: 4, 6: 1, 10: 4, 14: 1}
    trips_1 = [(0, 3), (3, 6), (6, 9), (9, 12), (12, 15), (15, 18)]
    trips_m = [(0, 3, 'L'), (3, 8, 'R'), (8, 11, 'L'), (11, 16, 'R')]
    fig = plt.figure(figsize=(5.8, 1.45))
    gs = fig.add_gridspec(1, 2, width_ratios=[1.6, 1], wspace=.2)
    ax = fig.add_subplot(gs[0])
    ax.set_xlim(-.3, T + .6)
    ax.set_ylim(-.1, 1.55)
    for y, trips, rew, col, name in [(1.15, [(a, b, 'L') for a, b in trips_1], one_bit, TEAL, '记一位'),
                                     (.35, trips_m, memless, RED, '无记忆')]:
        ax.text(-.6, y, name, fontsize=8.5, color=col, ha='right', va='center', fontfamily=CJK_FAMILY)
        for a, b, cue in trips:
            bb = min(b, T)
            ax.add_patch(plt.Rectangle((a, y - .2), bb - a, .4, fc=('#e6f2f1' if col == TEAL else ('#e6f2f1' if cue == 'L' else '#f6e3df')),
                                       ec=col, lw=.6))
        for s, r in rew.items():
            ax.text(s - .5, y, f'+{r}', fontsize=8, ha='center', va='center', color=INK)
    ax.set_yticks([])
    ax.spines['left'].set_visible(False)
    ax.set_xticks([0, 4, 8, 12, 16])
    ax.tick_params(labelsize=8, length=2.5)
    ax.set_xlabel('原始步 $t$（方块为一趟，指示左右交替）', fontsize=8.5, fontfamily=CJK_FAMILY, labelpad=1)
    ax2 = fig.add_subplot(gs[1])
    xs = list(range(T + 1))
    ax2.step(xs, [float(v) for v in cum_1], where='post', color=TEAL, lw=1.3)
    ax2.step(xs, [float(v) for v in cum_m], where='post', color=RED, lw=1.3)
    ax2.text(T + .3, 20, '20', color=TEAL, fontsize=8.5, va='center')
    ax2.text(T + .3, float(cum_m[-1]), '10.3', color=RED, fontsize=8.5, va='center')
    ax2.set_xlim(0, T)
    ax2.set_ylim(0, 22)
    ax2.set_xticks([0, 4, 8, 12, 16])
    ax2.set_yticks([0, 5, 10, 15, 20])
    ax2.tick_params(labelsize=8, length=2.5)
    ax2.set_xlabel('原始步 $t$', fontsize=8.5, fontfamily=CJK_FAMILY, labelpad=1)
    ax2.set_ylabel('期望累计回报', fontsize=8.5, labelpad=2)
    fig.subplots_adjust(left=.08, right=.95, bottom=.25, top=.97)
    fig.savefig(OUT / 'timeline16.pdf')
    plt.close(fig)


# ---------------------------------------------------------------- 网格
def rooms_world(n, rng, side=8):
    """n×n 的房间世界：外墙一圈，每隔 side 格一道墙，相邻房间之间的墙上随机开一个门。
    n=17 时是 2×2 的四房间；n 越大房间越多，房间里的布局完全相同。"""
    wall = np.zeros((n, n), dtype=bool)
    wall[0, :] = wall[-1, :] = wall[:, 0] = wall[:, -1] = True
    for k in range(side, n - 1, side):
        wall[k, :] = True
        wall[:, k] = True
    for k in range(side, n - 1, side):
        for a in range(0, n - 1, side):
            d = a + 1 + int(rng.integers(side - 1))
            if d < n - 1:
                wall[k, d] = False
                wall[d, k] = False
    return wall


def unique_fraction(wall, r):
    """空格中，以自己为中心的 (2r+1)×(2r+1) 窗口（出界当墙）在全图独一无二的比例。"""
    n = wall.shape[0]
    pad = np.ones((n + 2 * r, n + 2 * r), dtype=bool)
    pad[r:r + n, r:r + n] = wall
    free = np.argwhere(~wall)
    ks = [pad[i:i + 2 * r + 1, j:j + 2 * r + 1].tobytes() for i, j in free]
    cnt = {}
    for k in ks:
        cnt[k] = cnt.get(k, 0) + 1
    return sum(cnt[k] == 1 for k in ks) / len(ks), len(ks), len(cnt)


def grid_alias():
    sizes = [17, 33, 65, 129, 257]
    seeds = range(3)
    res = {}
    for r in (1, 2, 3, 4):
        for n in sizes:
            v = [unique_fraction(rooms_world(n, np.random.default_rng(sd)), r) for sd in seeds]
            res[(r, n)] = (float(np.mean([x[0] for x in v])), float(np.mean([x[1] for x in v])),
                           float(np.mean([x[2] for x in v])))
        print(f'grid-alias 看 {2*r+1}×{2*r+1}：', ', '.join(
            f'n={n}（空格 {res[(r, n)][1]:.0f}）唯一 {res[(r, n)][0]:.3f}，不同观测 {res[(r, n)][2]:.0f}' for n in sizes))
    fig, ax = plt.subplots(figsize=(2.6, 1.5))
    cells = [res[(1, n)][1] for n in sizes]
    for r, col, mk in [(1, RED, 'o'), (2, GOLD, 's'), (3, TEAL, '^'), (4, INK, 'D')]:
        ax.plot(cells, [res[(r, n)][0] for n in sizes], color=col, marker=mk, ms=3, lw=1.2,
                label=f'看 ${2*r+1}\\times{2*r+1}$')
    ax.set_xscale('log')
    ax.set_ylim(-.03, 1.03)
    ax.set_yticks([0, .25, .5, .75, 1])
    ax.yaxis.set_major_formatter(NLZ)
    ax.set_xticks([1e2, 1e3, 1e4, 1e5])
    ax.set_xticklabels(['$10^2$', '$10^3$', '$10^4$', '$10^5$'])
    ax.minorticks_off()
    ax.tick_params(labelsize=8.7, length=2.5)
    ax.set_xlabel('可走的格数（房间边长 7）', fontsize=9, fontfamily=CJK_FAMILY, labelpad=1)
    ax.set_ylabel('认出位置的比例', fontsize=9, labelpad=2)
    # 直接在各线起点左侧标视野大小，免得图例压住曲线
    for r, col in [(1, RED), (2, GOLD), (3, TEAL), (4, INK)]:
        ax.text(cells[0] / 1.25, res[(r, sizes[0])][0], f'${2*r+1}\\times{2*r+1}$', color=col,
                fontsize=8.5, ha='right', va='center')
    ax.set_xlim(18, 1.3e5)
    fig.tight_layout(pad=.3)
    fig.savefig(OUT / 'grid-alias.pdf')
    plt.close(fig)
    return res


# ---------------------------------------------------------------- 博弈
def kuhn_call():
    """三张牌 J<Q<K，各下底注 1，下注 1。乙持 Q，甲持 J、K 各半。
    设甲持 K 必下注、持 J 以概率 α 虚张下注。乙看到“甲下注”后：
      跟注：甲持 J 赢 2，甲持 K 输 2；弃牌：输掉底注 1。"""
    def call_ev(a):
        a = Fraction(a)
        pk = 1 / (1 + a)
        return pk * (-2) + (1 - pk) * 2
    for a in (Fraction(0), Fraction(1, 3), Fraction(1)):
        print(f'kuhn α={a}: P(K|下注)={1/(1+a)}, 跟注期望 {call_ev(a)}, 弃牌 -1')
    assert call_ev(Fraction(1, 3)) == -1
    al = np.linspace(0, 1, 201)
    ev = 2 * (al - 1) / (1 + al)
    fig, ax = plt.subplots(figsize=(3.3, 2.05))
    ax.plot(al, ev, color=TEAL, lw=1.4, label='跟注')
    ax.axhline(-1, color=RED, lw=1.4, label='弃牌')
    ax.axvline(1 / 3, color=MUTED, lw=.7, ls=(0, (3, 2)))
    ax.plot([1 / 3], [-1], 'o', color=INK, ms=3)
    ax.text(1 / 3 + .03, -1.75, '$\\alpha=\\frac{1}{3}$', fontsize=9.5)
    ax.set_xlim(0, 1)
    ax.set_ylim(-2.1, .25)
    ax.set_xticks([0, 1 / 3, .5, 1])
    ax.set_xticklabels(['0', '$\\frac{1}{3}$', '.5', '1'])
    ax.set_yticks([-2, -1, 0])
    ax.tick_params(labelsize=9, length=2.5)
    ax.set_xlabel('甲持 $J$ 时虚张下注的概率 $\\alpha$', fontsize=9.5, fontfamily=CJK_FAMILY)
    ax.set_ylabel('乙的期望收益', fontsize=9.5)
    ax.legend(fontsize=8.6, frameon=False, loc='upper left', prop={'family': CJK_FAMILY, 'size': 8.6})
    fig.tight_layout(pad=.3)
    fig.savefig(OUT / 'kuhn-call.pdf')
    plt.close(fig)


if __name__ == '__main__':
    learn_curves()
    timeline16()
    grid_alias()
    # kuhn_call()  # 11-21 W1：未用（与 18.5 节博弈算例重复），保留函数备查
    print('输出目录：', OUT)
