# -*- coding: utf-8 -*-
"""四区仓库，第 18 章档位：只凭观测（无记忆）的策略能达到的最好奖励率。

方法：在精确模型（416 个状态）上做精确策略梯度（平稳分布 d 与差分值 h 都直接解线性方程），
softmax 参数，Adam，8 个随机起点各 1500 次迭代。所得是“最好无记忆策略”奖励率的下界
（多起点找到的最好值，不是证书）。对照：同法在完整观测上应收敛到 r*（验算方法）。
用法：python3 demos/crl_ladder_memoryless.py → assets/crl-ladder-world/memoryless.json
"""
import json, os
import sys, numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import crl_ladder_world as LW
from multiprocessing import Pool

m = LW.build_model(LW.make_cfg())
NS, P, R, ST = m["NS"], m["P"], m["R"], m["states"]
n = len(R)
lab = {LW.ST_CELL[i]: i + 1 for i in range(4)}
VIEWS = {
    "local": lambda s: (LW.local_view(s[0]), lab.get(s[0], 0)),
    "local+last": lambda s: (LW.local_view(s[0]), lab.get(s[0], 0), s[1]),
    "full": lambda s: (s[0], s[1]),
}

def setup(view):
    keys = {}
    o = np.array([keys.setdefault(VIEWS[view](s), len(keys)) for s in ST])
    return o, len(keys)

def evaluate(pi_s):           # pi_s: n×4
    Pm = np.zeros((n, n))
    for a in range(4):
        for j in range(NS.shape[2]):
            np.add.at(Pm, (np.arange(n), NS[:, a, j]), pi_s[:, a] * P[:, a, j])
    r = (pi_s * R).sum(1)
    A = np.vstack([Pm.T - np.eye(n), np.ones(n)])
    d = np.linalg.lstsq(A, np.r_[np.zeros(n), 1.0], rcond=None)[0]
    rho = d @ r
    # 差分值 h：(I - Pm) h = r - rho，加 h[0]=0
    B = np.vstack([np.eye(n) - Pm, np.eye(n)[0]])
    h = np.linalg.lstsq(B, np.r_[r - rho, 0.0], rcond=None)[0]
    Q = R - rho + (P * h[NS]).sum(-1)
    return rho, d, Q

def opt(args):
    view, seed, iters = args
    o, K = setup(view)
    rng = np.random.default_rng(seed)
    th = rng.normal(0, 1.0, (K, 4))
    mo, vo = np.zeros_like(th), np.zeros_like(th)
    best = 0
    for t in range(1, iters + 1):
        z = np.exp(th - th.max(1, keepdims=True)); pk = z / z.sum(1, keepdims=True)
        pi_s = pk[o]
        rho, d, Q = evaluate(pi_s)
        best = max(best, rho)
        adv = Q - (pi_s * Q).sum(1, keepdims=True)
        g = np.zeros_like(th)
        np.add.at(g, o, d[:, None] * pi_s * adv)
        mo = .9 * mo + .1 * g; vo = .999 * vo + .001 * g * g
        th += 0.3 * (mo / (1 - .9 ** t)) / (np.sqrt(vo / (1 - .999 ** t)) + 1e-12)
    # 确定化：取每个观测的最大概率动作
    det = np.eye(4)[pk.argmax(1)][o]
    return view, seed, best, evaluate(det)[0], K, float((pk.max(1) < .95).sum())

if __name__ == "__main__":
    jobs = [(v, s, 1500) for v in ("local", "local+last", "full") for s in range(8)]
    with Pool(12) as p:
        res = p.map(opt, jobs)
    out = {}
    for v in VIEWS:
        rs = [r for r in res if r[0] == v]
        out[v] = dict(n_obs=rs[0][4], best_stochastic=round(max(r[2] for r in rs), 6),
                      per_start=[round(float(r[2]), 6) for r in rs],
                      best_deterministic=round(max(float(r[3]) for r in rs), 6))
        print(v, "观测数", rs[0][4], "随机策略最好", round(max(r[2] for r in rs), 6),
              "各起点", [round(r[2], 4) for r in rs], "取确定化后最好", round(max(r[3] for r in rs), 6),
              "最好者非确定的观测数", [r[5] for r in rs if r[2] == max(x[2] for x in rs)][0])
    out["note"] = "下界：多起点策略梯度找到的最好值；full 一行应等于 reference.json 的 R0 r* 0.13719，用来验算方法"
    path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "assets", "crl-ladder-world", "memoryless.json")
    json.dump(out, open(path, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print("written", path)
