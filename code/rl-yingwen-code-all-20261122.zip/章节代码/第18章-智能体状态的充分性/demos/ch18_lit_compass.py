# -*- coding: utf-8 -*-
"""第 18 章文献原型：compass world（Sutton、Rafols 与 Koop，NIPS 18，2005）的部分可观测实验，本课重跑。

环境（按原文图 1 与第 4、5 节文字重建）：
  6x6 房间，智能体以自我为中心，有位置与朝向。北墙橙 O、东墙黄 Y、南墙红 R、
  西墙蓝 B，西墙最上一格为绿 G。观测是 6 个颜色比特（O,Y,R,B,G,白），
  只在正对一面墙且贴着它时看到墙色，否则为白。
  动作 F/L/R，行为策略与状态无关，概率 .5/.25/.25；L、R 原地转 90 度；
  F 以 1-p 前进一格、以 p 原地不动（滑动），撞墙不动。部分可观测实验 p=.1。
  起点按图 1：第 2 行第 2 列，朝东。

问题网络（图 1 右）：每种非白颜色 8 个节点（部分可观测实验共 40 个节点，
  与原文“40 个节点值”一致；Wander 节点不进入本实验）：
    L1/F1/R1：执行该原始动作后下一步是否见到该色（一步预测）；
    Fwd：一直前进直到见到墙色，终止时是否为该色；
    LFwd/RFwd：先 L（或 R）再 Fwd；
    FwdLFwd/FwdRFwd：先 Fwd 到墙，再 L（或 R），再 Fwd。
回答网络：y_t = sigmoid(W x_t)，x_t 按上一步动作分成三组，每组 46 维 =（上一步 40 个预测值，6 个观测比特），
  其余两组置 0，共 138 维（原文第 5 节）。
学习：原文式 (3)-(5) 的选项内 TD(lambda)，lambda=.9，W0=0。原文未给部分可观测实验的步长，本课取 ALPHA。
误差：节点 5-9（Fwd、LFwd、RFwd、FwdLFwd、FwdRFwd）共 25 个节点相对真值的均方根，
  按 1000 步分箱、对运行平均（原文图 2 右的口径：不含原始动作节点与 Wander）。
另算一个对照：只看当前观测的最好预测（按观测分组取真值均值）的同一误差，即混叠造成的误差下限。
后半程（第 steps/2 步起）另记一步节点（L1、F1、R1，15 个）的误差及其只看观测的对照：原文说这些节点
“永远不能完全准确”，因为在空地里分不清具体位置（原文第 5 节），不计入图 2。
最后照原文图 3 的做法：把智能体放到第 2 行第 3 列朝北（面前不是墙），原地顺时针转 25 次，记录 Fwd 节点的读数。

只用 numpy。用法：
    python3 demos/ch18_lit_compass.py [运行次数，默认 10] [步数，默认 300000]
输出写 assets/ch18-lit-compass/results.json。
"""
import json, os, sys, time
import numpy as np

N = 6
O_, Y_, R_, B_, G_, W_ = range(6)          # 观测比特
COLORS = ['O', 'Y', 'R', 'B', 'G']          # 5 种非白颜色
DR = np.array([-1, 0, 1, 0]); DC = np.array([0, 1, 0, -1])   # 朝向 0北 1东 2南 3西
A_F, A_L, A_R = 0, 1, 2
P_SLIP = .1
LAM = .9
ALPHA = float(os.environ.get('CW_ALPHA', '1.0'))   # 原文完全可观测实验用 1.0；本课在 .1/.5/1.0 中试过，1.0 最快
NK = 8                                      # 每种颜色的节点数
L1, F1, R1, FWD, LFWD, RFWD, FLF, FRF = range(NK)
NN = NK * 5                                 # 40 个节点
GROUP = NN + 6                              # 46
M = 3 * GROUP                               # 138


def wall_color(r, c, h):
    """在 (r,c) 朝 h 时，若面前是墙返回颜色比特，否则返回白。可向量化。"""
    nr, nc = r + DR[h], c + DC[h]
    obs = np.full(np.shape(r), W_)
    obs = np.where(nr < 0, O_, obs)
    obs = np.where(nc >= N, Y_, obs)
    obs = np.where(nr >= N, R_, obs)
    obs = np.where(nc < 0, np.where(r == 0, G_, B_), obs)
    return obs


def forward_end(r, c, h):
    """一直前进到墙前（滑动不改终点）。"""
    if h == 0: return 0, c
    if h == 1: return r, N - 1
    if h == 2: return N - 1, c
    return r, 0


def truth_table():
    """T[r,c,h,k,node] 对节点 5-9 的真值（确定，与滑动无关）；节点 1-3 不需要。"""
    T = np.zeros((N, N, 4, 5, NK))
    for r in range(N):
        for c in range(N):
            for h in range(4):
                def fwd_color(rr, cc, hh):
                    er, ec = forward_end(rr, cc, hh)
                    return int(wall_color(np.array(er), np.array(ec), hh))
                hl, hr = (h - 1) % 4, (h + 1) % 4
                cf = fwd_color(r, c, h)
                cl = fwd_color(r, c, hl)
                cr = fwd_color(r, c, hr)
                er, ec = forward_end(r, c, h)
                cfl = fwd_color(er, ec, hl)
                cfr = fwd_color(er, ec, hr)
                for k in range(5):
                    T[r, c, h, k, FWD] = cf == k
                    T[r, c, h, k, LFWD] = cl == k
                    T[r, c, h, k, RFWD] = cr == k
                    T[r, c, h, k, FLF] = cfl == k
                    T[r, c, h, k, FRF] = cfr == k
    return T


EVAL_NODES = [FWD, LFWD, RFWD, FLF, FRF]
ONE_NODES = [L1, F1, R1]


def truth_one():
    """一步节点（L1、F1、R1）的真概率：只取决于位置与朝向，F 要计入滑动。"""
    T1 = np.zeros((N, N, 4, 5, 3))
    for r in range(N):
        for c in range(N):
            for h in range(4):
                cur = int(wall_color(np.array(r), np.array(c), h))
                nr, nc = r + DR[h], c + DC[h]
                if not (0 <= nr < N and 0 <= nc < N): nr, nc = r, c
                mv = int(wall_color(np.array(nr), np.array(nc), h))
                cl = int(wall_color(np.array(r), np.array(c), (h - 1) % 4))
                cr = int(wall_color(np.array(r), np.array(c), (h + 1) % 4))
                for k in range(5):
                    T1[r, c, h, k, 0] = cl == k
                    T1[r, c, h, k, 1] = (1 - P_SLIP) * (mv == k) + P_SLIP * (cur == k)
                    T1[r, c, h, k, 2] = cr == k
    return T1


def idx(k, node):
    return k * NK + node


def features(y_prev, a_prev, obs):
    """x 按上一步动作放进三组之一（原文：R 第一组、L 第二组、F 第三组）。"""
    R = y_prev.shape[0]
    x = np.zeros((R, M))
    grp = np.where(a_prev == A_R, 0, np.where(a_prev == A_L, 1, 2))
    blk = np.concatenate([y_prev, np.eye(6)[obs]], axis=1)       # (R,46)
    for g in range(3):
        m = grp == g
        x[m, g * GROUP:(g + 1) * GROUP] = blk[m]
    return x


def sig(u):
    return 1. / (1. + np.exp(-u))


def run(runs, steps, seed=0):
    rng = np.random.default_rng(seed)
    T = truth_table(); T1 = truth_one()
    one_idx = np.array([idx(k, n) for k in range(5) for n in ONE_NODES])
    sq1 = 0.; cnt1 = 0
    o1_sum = np.zeros((6, 15)); o1_sq = np.zeros((6, 15))
    r = np.full(runs, 1); c = np.full(runs, 1); h = np.full(runs, 1)   # 图 1 起点：第 2 行第 2 列，朝东
    W = np.zeros((runs, NN, M)); E = np.zeros_like(W)
    y = np.zeros((runs, NN))
    a_prev = np.full(runs, A_F)
    obs = wall_color(r, c, h)
    x = features(y, a_prev, obs)
    y = sig(np.einsum('rnm,rm->rn', W, x))
    beta_prev = np.ones((runs, NN))
    # 节点索引
    col = np.repeat(np.arange(5), NK)                 # 每个节点对应的颜色
    kind = np.tile(np.arange(NK), 5)
    ev_idx = np.array([idx(k, n) for k in range(5) for n in EVAL_NODES])
    bins = steps // 1000
    sq = np.zeros(bins)                                # 学习器的平方误差
    sq_cnt = np.zeros(bins)
    # 只看观测的对照：按观测累计真值和与平方和
    obs_sum = np.zeros((6, 25)); obs_sq = np.zeros((6, 25)); obs_n = np.zeros(6)
    t0 = time.time()
    for t in range(steps):
        # 误差（当前预测 y_t 对当前真状态）
        tr = T[r, c, h][:, :, EVAL_NODES].reshape(runs, 25)       # (R,25)，颜色主序
        yt = y[:, ev_idx]
        b = t // 1000
        sq[b] += ((yt - tr) ** 2).sum(); sq_cnt[b] += yt.size
        if t >= steps // 2:
            np.add.at(obs_sum, obs, tr); np.add.at(obs_sq, obs, tr ** 2); np.add.at(obs_n, obs, 1)
            tr1 = T1[r, c, h].reshape(runs, 15)
            sq1 += ((y[:, one_idx] - tr1) ** 2).sum(); cnt1 += tr1.size
            np.add.at(o1_sum, obs, tr1); np.add.at(o1_sq, obs, tr1 ** 2)
        # 行为
        u = rng.random(runs)
        a = np.where(u < .5, A_F, np.where(u < .75, A_L, A_R))
        move = (a == A_F) & (rng.random(runs) >= P_SLIP)
        nr, nc = r + DR[h], c + DC[h]
        ok = move & (nr >= 0) & (nr < N) & (nc >= 0) & (nc < N)
        r = np.where(ok, nr, r); c = np.where(ok, nc, c)
        h = np.where(a == A_L, (h - 1) % 4, np.where(a == A_R, (h + 1) % 4, h))
        obs1 = wall_color(r, c, h)
        x1 = features(y, a, obs1)
        y1_old = sig(np.einsum('rnm,rm->rn', W, x1))          # 旧权重算出的 y~_{t+1}
        ob = np.eye(6)[obs1][:, col]                            # (R,NN) 每个节点颜色的比特
        wall = (obs1 != W_)[:, None]
        isF = (a == A_F)[:, None]; isL = (a == A_L)[:, None]; isR = (a == A_R)[:, None]
        cnd = np.zeros((runs, NN)); beta = np.ones((runs, NN)); z = np.zeros((runs, NN))
        for node in range(NK):
            j = np.arange(5) * NK + node
            if node == L1:   cnd[:, j] = isL; z[:, j] = ob[:, j]
            elif node == F1: cnd[:, j] = isF; z[:, j] = ob[:, j]
            elif node == R1: cnd[:, j] = isR; z[:, j] = ob[:, j]
            elif node == FWD:
                cnd[:, j] = isF; beta[:, j] = wall; z[:, j] = ob[:, j]
            elif node == LFWD:
                cnd[:, j] = isL; z[:, j] = y1_old[:, np.arange(5) * NK + FWD]
            elif node == RFWD:
                cnd[:, j] = isR; z[:, j] = y1_old[:, np.arange(5) * NK + FWD]
            elif node == FLF:
                cnd[:, j] = isF; beta[:, j] = wall; z[:, j] = y1_old[:, np.arange(5) * NK + LFWD]
            elif node == FRF:
                cnd[:, j] = isF; beta[:, j] = wall; z[:, j] = y1_old[:, np.arange(5) * NK + RFWD]
        delta = beta * z + (1 - beta) * y1_old - y
        grad = (y * (1 - y))[:, :, None] * x[:, None, :]
        E = cnd[:, :, None] * (LAM * (1 - beta_prev)[:, :, None] * E + grad)
        W += ALPHA * delta[:, :, None] * E
        beta_prev = beta
        y = sig(np.einsum('rnm,rm->rn', W, x1)); x = x1; obs = obs1
    secs = time.time() - t0
    rms = np.sqrt(sq / sq_cnt)
    # 只看观测的最好预测：组内方差
    m = obs_n > 0
    mean = obs_sum[m] / obs_n[m][:, None]
    var = obs_sq[m] / obs_n[m][:, None] - mean ** 2
    memless_rms = float(np.sqrt((var * obs_n[m][:, None]).sum() / (obs_n[m].sum() * 25)))
    white_frac = float(obs_n[W_] / obs_n.sum())
    mean1 = o1_sum[m] / obs_n[m][:, None]
    var1 = o1_sq[m] / obs_n[m][:, None] - mean1 ** 2
    memless1 = float(np.sqrt((var1 * obs_n[m][:, None]).sum() / (obs_n[m].sum() * 15)))
    learned_fwd_half = float(np.sqrt(sq[bins // 2:].sum() / sq_cnt[bins // 2:].sum()))
    learned_one_half = float(np.sqrt(sq1 / cnt1))
    # 原文图 3 式的转圈演示（第 0 个运行，接着它自己的历史手动驾驶，不滑动、不再学习）：
    # 先一直前进到见到墙，再掉头（R,R）走两步到房间里，然后原地顺时针转 25 次。
    W0 = W[:1]; ys = y[:1].copy()
    rr, cc, hh = r[:1].copy(), c[:1].copy(), h[:1].copy()

    def act(a, rr, cc, hh, ys):
        if a == A_F:
            nr, nc = rr + DR[hh], cc + DC[hh]
            ok = (nr >= 0) & (nr < N) & (nc >= 0) & (nc < N)
            rr = np.where(ok, nr, rr); cc = np.where(ok, nc, cc)
        elif a == A_L: hh = (hh - 1) % 4
        else: hh = (hh + 1) % 4
        ys = sig(np.einsum('rnm,rm->rn', W0, features(ys, np.array([a]), wall_color(rr, cc, hh))))
        return rr, cc, hh, ys
    for _ in range(N + 1):
        if wall_color(rr, cc, hh)[0] != W_: break
        rr, cc, hh, ys = act(A_F, rr, cc, hh, ys)
    for a in (A_R, A_R, A_F, A_F):
        rr, cc, hh, ys = act(a, rr, cc, hh, ys)
    spin = []
    for s in range(26):
        tr = T[rr[0], cc[0], hh[0]][:, FWD]
        spin.append({'step': s + 1, 'pos': [int(rr[0]), int(cc[0])], 'heading': 'NESW'[hh[0]],
                     'obs': 'OYRBGW'[int(wall_color(rr, cc, hh)[0])],
                     'fwd_pred': [round(float(ys[0, k * NK + FWD]), 3) for k in range(5)],
                     'fwd_true': [int(v) for v in tr]})
        rr, cc, hh, ys = act(A_R, rr, cc, hh, ys)
    spin_ok = sum(int(np.argmax(s_['fwd_pred']) == np.argmax(s_['fwd_true'])) for s_ in spin)
    return dict(rms_by_1000=[round(float(v), 4) for v in rms], memoryless_rms=round(memless_rms, 4),
                white_fraction=round(white_frac, 4), second_half=dict(forward_family_learned=round(learned_fwd_half, 4), forward_family_memoryless=round(memless_rms, 4), one_step_learned=round(learned_one_half, 4), one_step_memoryless=round(memless1, 4)), spin=spin, spin_correct=spin_ok, seconds=round(secs, 1))


if __name__ == '__main__':
    runs = int(sys.argv[1]) if len(sys.argv) > 1 else 10
    steps = int(sys.argv[2]) if len(sys.argv) > 2 else 300000
    res = run(runs, steps)
    rms = res['rms_by_1000']
    out = dict(source='Sutton, Rafols & Koop, NIPS 18 (2005), Sec. 5, Fig. 2 right / Fig. 3 (rerun by this course)',
               runs=runs, steps=steps, alpha=ALPHA, lam=LAM, slip=P_SLIP, nodes=NN, inputs=M,
               eval_nodes='Forward, L-Forward, R-Forward, Forward-L-Forward, Forward-R-Forward x 5 colours = 25',
               rms_at={str(k): rms[k // 1000 - 1] for k in (1000, 10000, 50000, 100000, 200000, 300000) if k <= steps},
               **res)
    d = os.environ.get('CW_OUT') or os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'assets', 'ch18-lit-compass')
    os.makedirs(d, exist_ok=True)
    with open(os.path.join(d, 'results.json'), 'w') as f:
        json.dump(out, f, ensure_ascii=False, indent=1)
    print(json.dumps({k: out[k] for k in ('runs', 'steps', 'alpha', 'rms_at', 'memoryless_rms', 'white_fraction', 'second_half', 'spin_correct', 'seconds')}, ensure_ascii=False))
    for s in out['spin'][:6] + out['spin'][-2:]:
        print(s)
