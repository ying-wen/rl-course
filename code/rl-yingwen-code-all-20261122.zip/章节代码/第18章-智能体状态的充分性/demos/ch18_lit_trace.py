# -*- coding: utf-8 -*-
"""第 18 章文献原型：trace conditioning（Rafiee、Abbas、Ghiassian、Kumaraswamy、Sutton、Ludvig 与 White，
Adaptive Behavior 31(1):3-19, 2023；arXiv 2011.04590）中固定表示的部分，本课重跑。

环境（原文“Trace Conditioning”一节）：
  每个试次：条件刺激 CS 持续 4 步；从 CS 开始到非条件刺激 US 开始的间隔 ISI ~ 均匀分布；
  US 持续 2 步；从 US 开始到下一试次的间隔 ITI ~ U(80,120)。
  三档 ISI：短 U(7,13)、中 U(14,26)、长 U(20,40)，E[ISI] = 10/20/30。
  10 个干扰信号，平均间隔 10,20,...,100 步，每次持续 4 步（本课按每步以 1/均值 的概率开始近似泊松过程）。
  预测目标：US 的折扣回报 G_t = sum_k gamma^k US_{t+k+1}，gamma = 1 - 1/E[ISI]。
  度量：MSRE = 平方回报误差 (V_t - G_t)^2 对时间步的平均。
表示（每种都另加一个恒为 1 的偏置）：
  presence：每个刺激一位，刺激在时为 1（共 12 位）。间隔期间全为 0。
  microstimulus（MS）：每个刺激一条“刺激痕迹” y（开始时置 1，此后每步乘 tau），
    再用 m 个高斯基 exp(-(y-mu_i)^2/(2 sigma^2)) 乘以 y；mu_i = i/m。
  tile-coded traces（TCT）：对同一条痕迹 y 做 2 层、每层 n 格的瓦片编码。
  tau = 1 - 1/E[ISI]（原文：痕迹衰减按 E[ISI] 设定）。
学习：线性半梯度 TD(lambda)，lambda = .9（原文对固定表示用 .9）。
  原文用 Adam 优化器并扫步长、m、n；本课用普通步长 alpha/（活跃特征数的典型值），在少量运行上扫 alpha 后取最好值。
规模：原文 2,000,000 步 x 30 次运行；本课缩到 STEPS 步 x RUNS 次运行（见输出）。

只用 numpy。用法：
    python3 demos/ch18_lit_trace.py [运行次数，默认 10] [步数，默认 200000]
输出写 assets/ch18-lit-trace/results.json。
"""
import json, os, sys, time
import numpy as np

np.seterr(all='ignore')   # 扫步长时过大的步长会发散，按 inf 处理后不被选中

N_DIS = 10
N_STIM = 2 + N_DIS
LAM = .9
SETTINGS = {'short': (7, 13), 'medium': (14, 26), 'long': (20, 40)}
M_MS, SIGMA = 16, float(os.environ.get('TC_SIGMA', '.08'))         # microstimulus 个数与宽度（宽度取 Ludvig 等常用值，见 README 说明）
N_TILE, N_TILING = 16, 2


def make_stream(rng, runs, steps, lo, hi):
    """返回 obs (steps, runs, 12) 的 0/1 数组；第 0 列 CS，第 1 列 US。"""
    obs = np.zeros((steps, runs, N_STIM), dtype=np.int8)
    for r in range(runs):
        t = int(rng.integers(0, 50))
        while t < steps:
            obs[t:t + 4, r, 0] = 1
            isi = int(rng.integers(lo, hi + 1))
            u = t + isi
            obs[u:u + 2, r, 1] = 1
            t = u + int(rng.integers(80, 121))
    means = np.arange(1, N_DIS + 1) * 10
    left = np.zeros((runs, N_DIS), dtype=int)
    for t in range(steps):
        start = (left == 0) & (rng.random((runs, N_DIS)) < 1. / means)
        left = np.where(start, 4, left)
        obs[t, :, 2:] = left > 0
        left = np.maximum(left - 1, 0)
    return obs


def returns(us, gamma):
    G = np.zeros_like(us, dtype=float)
    acc = np.zeros(us.shape[1])
    for t in range(us.shape[0] - 2, -1, -1):
        acc = us[t + 1] + gamma * acc
        G[t] = acc
    return G


def feat_fn(kind, tau):
    mu = np.arange(1, M_MS + 1) / M_MS
    offs = np.arange(N_TILING) / (N_TILING * N_TILE)

    def f(o, o_prev, y):
        """o, o_prev: (R,12)；y: (R,12) 痕迹（就地更新后返回）。返回特征 (R,d) 与新 y。"""
        onset = (o == 1) & (o_prev == 0)
        y = np.where(onset, 1., y * tau)
        R = o.shape[0]
        if kind == 'presence':
            x = o.astype(float)
        elif kind == 'MS':
            x = (y[:, :, None] * np.exp(-(y[:, :, None] - mu) ** 2 / (2 * SIGMA ** 2))).reshape(R, -1)
        else:   # TCT
            idx = np.floor((y[:, :, None] + offs) * N_TILE).clip(0, N_TILE).astype(int)   # (R,12,tilings)
            x = np.zeros((R, N_STIM, N_TILING, N_TILE + 1))
            np.put_along_axis(x, idx[..., None], 1., axis=3)
            x = x.reshape(R, -1)
        return np.concatenate([x, np.ones((R, 1))], 1), y
    return f


def run(kind, obs, gamma, tau, alpha, keep_trace=False):
    steps, R, _ = obs.shape
    f = feat_fn(kind, tau)
    y = np.zeros((R, N_STIM))
    x, y = f(obs[0], np.zeros_like(obs[0]), y)
    w = np.zeros((R, x.shape[1])); z = np.zeros_like(w)
    V = np.zeros((steps, R))
    for t in range(steps - 1):
        v = (w * x).sum(1)
        V[t] = v
        x1, y = f(obs[t + 1], obs[t], y)
        v1 = (w * x1).sum(1)
        delta = obs[t + 1, :, 1] + gamma * v1 - v
        z = gamma * LAM * z + x
        w += alpha * delta[:, None] * z
        x = x1
    return V


def msre(V, G, burn):
    e = (V[burn:-1000] - G[burn:-1000]) ** 2
    per_run = e.mean(0)
    return float(per_run.mean()), float(per_run.std(ddof=1) / np.sqrt(len(per_run))) if len(per_run) > 1 else 0.


ALPHAS = {k: [.001, .003, .01, .03, .1] for k in ('presence', 'MS', 'TCT')}


def main(runs, steps):
    rng = np.random.default_rng(2023)
    res = {}
    t0 = time.time()
    for name, (lo, hi) in SETTINGS.items():
        eisi = (lo + hi) / 2
        gamma = 1 - 1 / eisi
        tau = 1 - 1 / eisi
        # 扫步长：3 次运行、steps//4 步
        sobs = make_stream(rng, 3, steps // 4, lo, hi)
        sG = returns(sobs[:, :, 1].astype(float), gamma)
        obs = make_stream(rng, runs, steps, lo, hi)
        G = returns(obs[:, :, 1].astype(float), gamma)
        res[name] = {'isi': [lo, hi], 'gamma': round(gamma, 4)}
        for kind in ('presence', 'MS', 'TCT'):
            best = min(ALPHAS[kind], key=lambda a: np.nan_to_num(msre(run(kind, sobs, gamma, tau, a), sG, 0)[0], nan=np.inf))
            V = run(kind, obs, gamma, tau, best)
            m_all, se_all = msre(V, G, 0)
            m_last, se_last = msre(V, G, steps // 2)
            res[name][kind] = {'alpha': best, 'msre_all': round(m_all, 5), 'se_all': round(se_all, 5),
                               'msre_second_half': round(m_last, 5), 'se_second_half': round(se_last, 5)}
            # 示例试次（第 0 个运行最后一个完整试次，不含干扰的影响说明见 README）
            cs_on = np.where((obs[1:, 0, 0] == 1) & (obs[:-1, 0, 0] == 0))[0] + 1
            s0 = int(cs_on[-2]) - 10
            res[name][kind]['example'] = [round(float(v), 4) for v in V[s0:s0 + 60, 0]]
            if kind == 'presence':
                res[name]['example_return'] = [round(float(v), 4) for v in G[s0:s0 + 60, 0]]
                res[name]['example_cs'] = obs[s0:s0 + 60, 0, 0].astype(int).tolist()
                res[name]['example_us'] = obs[s0:s0 + 60, 0, 1].astype(int).tolist()
            print(name, kind, res[name][kind]['alpha'], res[name][kind]['msre_all'], res[name][kind]['msre_second_half'],
                  round(time.time() - t0, 1), flush=True)
        res[name]['return_variance'] = round(float(G[:-1000].var()), 5)
    return res, time.time() - t0


if __name__ == '__main__':
    runs = int(sys.argv[1]) if len(sys.argv) > 1 else 10
    steps = int(sys.argv[2]) if len(sys.argv) > 2 else 200000
    res, secs = main(runs, steps)
    out = dict(source='Rafiee et al., Adaptive Behavior 31(1):3-19, 2023, trace conditioning, fixed representations (rerun by this course)',
               runs=runs, steps=steps, lam=LAM, ms=dict(m=M_MS, sigma=SIGMA), tct=dict(tiles=N_TILE, tilings=N_TILING),
               paper_scale='2,000,000 steps x 30 runs, Adam', seconds=round(secs, 1), results=res)
    d = os.environ.get('TC_OUT') or os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'assets', 'ch18-lit-trace')
    os.makedirs(d, exist_ok=True)
    with open(os.path.join(d, 'results.json'), 'w') as f:
        json.dump(out, f, ensure_ascii=False, indent=1)
    print('seconds', round(secs, 1))
