"""第 18 章 18.6 仓库规则翻转实验的复现脚本（11-21 请求 r1121-132524 新写）。

原始脚本未找到；本脚本按 textbook/18.md §18.6 的设定重写：
仓库 D→J→B→D（与指示相符，得 4）或 D→J→W→C→B→D（不符，W→C 得 1）；
第 1000 步起规则反过来；表格 Sarsa，α=.1，零初值，只在 J 探索；
意外读数 u_t=(1-β)u_{t-1}+β|δ_t|（只在 J 处的更新计入），κ_t=1{u_t>θ}，
κ_t=0 时 ε=.1，κ_t=1 时 ε=.5；价值表不按 κ_t 分开。
教材未写 γ；这里取 γ=.72，使固定 ε 的四个结果与课件表格相差在 2% 以内。
用法：python3 demos/ch18_surprise_bit.py [γ]
"""
import sys
import numpy as np

D, J, B, W, C = range(5)


def run(eps_off=.1, eps_on=.5, surprise=False, gamma=.72, T=3000, N=300,
        seed=1, beta=.05, theta=.5, alpha=.1, flip=1000):
    rng = np.random.default_rng(seed)
    Q = np.zeros((N, 5, 2, 2))            # 位置 × 指示 × 动作
    idx = np.arange(N)
    pos = np.full(N, D)
    cue = rng.integers(0, 2, N)
    u = np.zeros(N)
    kappa = np.zeros(N, bool)

    def act(pos, cue, kappa):
        q = Q[idx, J, cue]
        tie = rng.integers(0, 2, N)
        greedy = np.where(q[:, 0] > q[:, 1], 0, np.where(q[:, 1] > q[:, 0], 1, tie))
        eps = np.where(kappa, eps_on, eps_off) if surprise else np.full(N, eps_off)
        a = np.where(rng.random(N) < eps, rng.integers(0, 2, N), greedy)
        return np.where(pos == J, a, 0)

    a = act(pos, cue, kappa)
    R = np.zeros((N, T))
    K = np.zeros((N, T))
    for t in range(T):
        good = (a == cue) if t < flip else (a != cue)
        npos = np.select([pos == D, (pos == J) & good, pos == J, pos == W, pos == C, pos == B],
                         [J, B, W, C, B, D])
        r = np.where((pos == J) & good, 4., np.where(pos == W, 1., 0.))
        ncue = np.where(npos == D, rng.integers(0, 2, N), cue)
        na = act(npos, ncue, kappa)
        delta = r + gamma * Q[idx, npos, ncue, na] - Q[idx, pos, cue, a]
        Q[idx, pos, cue, a] += alpha * delta
        u = np.where(pos == J, (1 - beta) * u + beta * np.abs(delta), u)
        kappa = u > theta
        R[:, t] = r
        K[:, t] = kappa
        pos, cue, a = npos, ncue, na
    total = R.sum(1)
    return {'J_T': total.mean(), 'se': total.std(ddof=1) / np.sqrt(N),
            'after': R[:, flip:].sum(1).mean(), 'on': K.mean(),
            'on_before': K[:, :flip].mean(), 'on_after': K[:, flip:].mean()}


if __name__ == '__main__':
    g = float(sys.argv[1]) if len(sys.argv) > 1 else .72
    for e in (.05, .1, .19, .2, .3):
        o = run(eps_off=e, gamma=g)
        print(f'固定 ε={e}: J_T={o["J_T"]:.0f}±{o["se"]:.0f}，翻转后 {o["after"]:.0f}')
    o = run(surprise=True, gamma=g)
    print(f'意外位: J_T={o["J_T"]:.0f}±{o["se"]:.0f}，翻转后 {o["after"]:.0f}，'
          f'κ=1 占比 {o["on"]:.3f}（前 1000 步 {o["on_before"]:.3f}，后 2000 步 {o["on_after"]:.3f}）')
