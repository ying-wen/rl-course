#!/usr/bin/env python3
"""Chapter 14 worked calculations and small subtask training.
Data generation is standard-library only; optional --figures needs matplotlib.
All outputs are local to this course. No external environment or experiments.
"""
from pathlib import Path
import csv,json,math,random,sys
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'assets/continual/v6';OUT.mkdir(parents=True,exist_ok=True)

def csvwrite(name,rows):
 with (OUT/name).open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def differential():
 h=[0.,0.,0.];rho=0.;rows=[dict(t=0,rho=rho,hA=0,hB=0,hC=0,delta=0)]
 first=[]
 for t in range(1500):
  s=t%3;sp=(s+1)%3;r=float(s==2);delta=r-rho+h[sp]-h[s]
  old=h.copy();oldrho=rho;h[s]+=.1*delta;rho+=.01*delta
  if t<6:first.append(dict(t=t,s=s,sp=sp,reward=r,old_h=old,old_rho=oldrho,delta=delta,new_h=h.copy(),new_rho=rho))
  if (t+1)%3==0:rows.append(dict(t=t+1,rho=rho,hA=0,hB=h[1]-h[0],hC=h[2]-h[0],delta=delta))
 assert abs(rho-1/3)<1e-6 and abs(h[1]-h[0]-1/3)<1e-6
 csvwrite('differential-td.csv',rows);(OUT/'differential-first-steps.json').write_text(json.dumps(first,indent=2))
 return rows

A=[(1,0),(0,1),(-1,0),(0,-1)];walls={(1,1),(1,2)};goal=(3,3)
states=[(x,y) for x in range(4) for y in range(4) if (x,y) not in walls and (x,y)!=goal]
def step(s,a):
 x=s[0]+A[a][0];y=s[1]+A[a][1];sp=(x,y)
 if not(0<=x<4 and 0<=y<4) or sp in walls:sp=s
 return sp,-1.,sp==goal

def skills():
 rng=random.Random(141206);q={s:[0.]*4 for s in states};snapshots={};transitions=0;progress=[]
 for ep in range(1,6001):
  s=rng.choice(states)
  for t in range(100):
   best=max(q[s]);ties=[a for a in range(4) if q[s][a]==best]
   a=rng.randrange(4) if rng.random()<.2 else rng.choice(ties)
   sp,r,done=step(s,a);target=r+(0 if done else max(q[sp]));q[s][a]+=.2*(target-q[s][a]);transitions+=1
   if done:break
   s=sp
  if ep in (20,200,6000):snapshots[ep]={s:list(v) for s,v in q.items()}
  if ep%100==0:progress.append(dict(episode=ep,transitions=transitions,value_start=max(q[(0,0)])))
 # Independent BFS exact shortest distances, separate from Q updates.
 dist={goal:0};front=[goal]
 while front:
  sp=front.pop(0)
  for s in states:
   if s not in dist and any(step(s,a)[0]==sp for a in range(4)):
    dist[s]=dist[sp]+1;front.append(s)
 err=max(abs(max(q[s])+dist[s]) for s in states)
 assert err<1e-8,err
 rows=[]
 for ep,snap in snapshots.items():
  for s,qs in snap.items():
   a=max(range(4),key=lambda a:qs[a]);rows.append(dict(episode=ep,x=s[0],y=s[1],value=max(qs),action=a,dx=A[a][0],dy=A[a][1],exact_time=dist[s]))
 csvwrite('skill-grid.csv',rows);csvwrite('skill-learning.csv',progress)
 return rows,dict(seed=141206,episodes=6000,transitions=transitions,alpha=.2,epsilon=.2,max_steps=100,initial_states='uniform reset over nonterminal free cells',reward=-1,discount=1,terminal='charger (3,3)',cutoff='reset after100 steps; last target still bootstraps',max_value_error=err)

def model():
 g=.9;tail=10.
 def rew(n):return -sum(g**j for j in range(n))
 r=rew(2);p=g**2;detour=rew(4)+g**4*tail;rows=[]
 for n in range(7):
  rows.append(dict(observations=n,r_direct=r,p_direct=p,q_direct=r+p*tail,q_detour=detour,choice=0 if r+p*tail>=detour else 1))
  r+=.5*(rew(6)-r);p+=.5*(g**6-p)
 assert rows[1]['choice']==0 and rows[2]['choice']==1
 assert math.isclose(rows[0]['q_direct'],6.2) and math.isclose(detour,3.122)
 csvwrite('model-replanning.csv',rows);return rows

rates=differential();grid,skillmeta=skills();models=model()
meta=dict(differential=dict(alpha=.1,rate_step=.01,steps=1500,trajectory='deterministic A-B-C-A; reward1 on C-A',no_resets=True),skill=skillmeta,model=dict(discount=.9,tail_value=10,old_direct_duration=2,new_direct_duration=6,detour_duration=4,step_reward=-1,model_step=.5),meaning='Differential and model panels are deterministic worked computations; skill panel is actual tabular Q-learning with stated resets; neither is a complete continual-agent evaluation.')
(OUT/'manifest.json').write_text(json.dumps(meta,indent=2)+'\n')
print(json.dumps(meta,indent=2))
if '--figures' not in sys.argv:raise SystemExit
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from plot_fonts import chinese_font
from matplotlib.patches import Rectangle
font=chinese_font()
plt.rcParams.update({'font.family':font.get_name(),'axes.unicode_minus':False,'font.size':11,'svg.fonttype':'path','axes.spines.top':False,'axes.spines.right':False})
T,R,G='#087E8B','#C65335','#C4942A'
def save(fig,n):
 fig.savefig(OUT/(n+'.svg'),bbox_inches='tight');fig.savefig(OUT/(n+'.png'),dpi=170,bbox_inches='tight');plt.close(fig)
fig,axs=plt.subplots(1,2,figsize=(10,3.6),layout='constrained')
axs[0].plot([r['t'] for r in rates],[r['rho'] for r in rates],color=T,label='率估计');axs[0].axhline(1/3,ls='--',color=G,label='真实率1/3');axs[0].set(xlabel='真实原子转移次数',ylabel='每步奖励率');axs[0].legend(frameon=False)
for key,c,label in [('hB',T,'B相对A'),('hC',R,'C相对A')]:axs[1].plot([r['t'] for r in rates],[r[key] for r in rates],color=c,label=label)
axs[1].axhline(1/3,ls='--',color=T,alpha=.5);axs[1].axhline(2/3,ls='--',color=R,alpha=.5);axs[1].set(xlabel='真实原子转移次数',ylabel='相对价值估计');axs[1].legend(frameon=False)
for ax in axs:ax.grid(alpha=.2)
fig.suptitle('同一条循环经验：率与相对价值联合更新',fontsize=14);save(fig,'differential-learning')
fig,axs=plt.subplots(1,3,figsize=(11.2,4),layout='constrained')
for ax,ep in zip(axs,[20,200,6000]):
 ax.set(xlim=(0,4),ylim=(0,4),aspect='equal',title=f'{ep}次子任务训练');ax.set_xticks([]);ax.set_yticks([])
 for x in range(4):
  for y in range(4):ax.add_patch(Rectangle((x,y),1,1,edgecolor='#bfcaca',facecolor='#f4f7f6'))
 for x,y in walls:ax.add_patch(Rectangle((x,y),1,1,facecolor='#182E38'))
 ax.add_patch(Rectangle(goal,1,1,facecolor='#d0eae6'));ax.text(3.5,3.55,'充电座',ha='center',va='center');ax.text(3.5,3.2,'0',ha='center')
 for row in [r for r in grid if r['episode']==ep]:
  x,y=row['x']+.5,row['y']+.5;ax.text(x,y+.16,f"{row['value']:.1f}",ha='center',va='center',fontsize=10)
  ax.arrow(x-.16*row['dx'],y-.19-.16*row['dy'],.32*row['dx'],.32*row['dy'],head_width=.1,head_length=.08,color=T,length_includes_head=True)
 ax.text(.5,.91,'起点',ha='center',fontsize=8,color=R)
fig.suptitle('学习回充子任务：数值为最大动作价值，箭头为贪心动作',fontsize=14);save(fig,'skill-policy-values')
fig,ax=plt.subplots(figsize=(7.8,3.5),layout='constrained')
ax.plot([r['observations'] for r in models],[r['q_direct'] for r in models],'-o',color=T,label='直达技能的模型价值')
ax.axhline(models[0]['q_detour'],color=R,label='绕行技能的模型价值')
ax.annotate('第二次新执行后，规划改选绕行',xy=(2,models[2]['q_direct']),xytext=(2.3,4.5),arrowprops={'arrowstyle':'->','color':'#182E38'})
ax.set(xlabel='直达变慢后观察到的完整技能执行次数',ylabel='期间奖励＋折扣后的终点价值',title='真实经验修订模型，规划随之改变选择');ax.legend(frameon=False);ax.grid(alpha=.2);save(fig,'model-replanning')
fig,axs=plt.subplots(1,3,figsize=(10.4,3.1),layout='constrained')
for ax,values,title in zip(axs,[[.8,.2],[.76,.24],[19/73,54/73]],['当前信念','按动作预测','收到反馈后校正']):
 ax.bar([0,1],values,color=[T,R],width=.55);ax.set_xticks([0,1],['隐状态1','隐状态2']);ax.set(ylim=(0,1),title=title)
 for x,v in enumerate(values):ax.text(x,v+.04,f'{v:.4f}',ha='center')
axs[0].set_ylabel('概率');save(fig,'belief-update')
fig,axs=plt.subplots(1,2,figsize=(9.5,3.5),layout='constrained');xs=[i/100 for i in range(101)]
for ax,y,c in zip(axs,[1,-1],[T,R]):
 ax.plot(xs,[.5*(a-y)**2 for a in xs],color=c,lw=2);ax.scatter([.2],[.5*(.2-y)**2],color=c,zorder=4)
 direction=.36 if y==1 else .04
 ax.annotate('',xy=(direction,.5*(direction-y)**2),xytext=(.2,.5*(.2-y)**2),arrowprops={'arrowstyle':'->','color':c,'lw':2})
 ax.set(xlabel='本次步长 alpha',ylabel='下一次平方损失',title=f'当前目标1，下一目标{y}');ax.grid(alpha=.2)
fig.suptitle('后续目标评价当前参数更新',fontsize=14);save(fig,'meta-step-loss')
