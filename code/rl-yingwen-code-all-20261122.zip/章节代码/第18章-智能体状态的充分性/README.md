# 第 18 章　智能体状态的充分性：程序

本目录可以单独运行：在本目录下执行下面的命令即可，结果写回本目录的 `assets/`。目录由 `rl-course/tools/export_chapter_code.py` 从课程目录生成，改程序请改课程目录里的原件，再重新导出。

## 准备

```sh
python3 -m pip install -r requirements.txt
```

需要的第三方包：matplotlib、numpy。复现附录要求 Python 3.10 或更新版本；核验时用的版本见下表。

## 运行（与复现附录相同）

```sh
python3 demos/sample14_average_option.py
python3 demos/door_signal.py --reliability 3/5
python3 demos/door_signal.py --option-time
python3 demos/door_signal.py --export assets/door-signal/reader.json
python3 demos/ch18_lit_trace.py            # 文献原型：痕迹条件反射，写 assets/ch18-lit-trace
python3 demos/ch18_lit_compass.py          # 文献原型：罗盘世界，写 assets/ch18-lit-compass
python3 demos/ch18_r21_figs.py             # 写 assets/ch18-r21
python3 demos/crl_ladder_learners.py --exp ch18 --seeds 20 --seed0 100 --steps 2000000 --tag formal   # 四区仓库阶梯，写 assets/crl-ladder-world/runs/formal-ch18.json
python3 demos/crl_ladder_figures.py ch18           # 写 assets/crl-ladder-world/fig/ladder-ch18.png
python3 demos/crl_ladder_memoryless.py     # 写 assets/crl-ladder-world/memoryless.json
python3 demos/ch18_surprise_bit.py         # 可加折扣因子，默认 .72；只打印
```

## 本目录的程序

| 程序 | 说明 | 核验 |
|---|---|---|
| `demos/sample14_average_option.py` | Three-station worked example: rate -> differential TD -> learned option model -> action. | 通过（10 秒） |
| `demos/continual_figures.py` | Render original figures from formulas and multiscale CSV; requires matplotlib. | 通过（2 秒） |
| `demos/continual_v6_calculations.py` | Chapter 14 worked calculations and small subtask training. | 通过（0 秒） |
| `demos/door_signal.py` | A cue, a decision, and a delayed alarm in the course's delivery task. | 通过（1 秒） |
| `demos/ch18_lit_trace.py` | 第 18 章文献原型：trace conditioning（Rafiee、Abbas、Ghiassian、Kumaraswamy、Sutton、Ludvig 与 White， | 超时：300 秒内未跑完（启动正常） |
| `demos/ch18_lit_compass.py` | 第 18 章文献原型：compass world（Sutton、Rafols 与 Koop，NIPS 18，2005）的部分可观测实验，本课重跑。 | 通过（278 秒） |
| `demos/ch18_r21_figs.py` | 11-21 审阅站请求 r1121-132524（第 18 章，分叉 W1）：章首与 18.1–18.2 的配图， | 通过（3 秒） |
| `demos/crl_ladder_learners.py` | 四区仓库的学习器阶梯（例子方案第三步）。 | 超时：300 秒内未跑完（启动正常） |
| `demos/crl_ladder_memoryless.py` | 四区仓库，第 18 章档位：只凭观测（无记忆）的策略能达到的最好奖励率。 | 通过（189 秒） |
| `demos/crl_ladder_diagnostics.py` | 四区仓库阶梯的诊断与改法（11-20）。 | 通过（5 秒） |
| `demos/ch18_surprise_bit.py` | 第 18 章 18.6 仓库规则翻转实验的复现脚本（11-21 请求 r1121-132524 新写）。 | 通过（2 秒） |
| `demos/crl_ladder_figures.py` | 阶梯世界（四区仓库）阅读稿用图：地图与各章“占天花板”条形。 | 通过（2 秒） |
| `demos/crl_ladder_world.py` | 四区仓库：第三部分的能力阶梯世界（环境与精确参照）。 | 通过（32 秒） |
| `demos/crl_ladder_world_checks.py` | 四区仓库的独立检查（照 v12 的做法：手算、枚举、独立实现互查）。 | 通过（35 秒） |
| `demos/crl_ladder_power.py` | 四区仓库学习器阶梯：试点估 σ_Δ 定种子数，正式跑后出第 24 章的账本。 | 通过（0 秒） |
| `demos/crl_ladder_ceiling.py` | 四区仓库学习器阶梯：每个试验条件的“天花板”，供账本算“离最优还差多少”。 | 超时：300 秒内未跑完（启动正常） |

被上面程序 import 的本课模块：`demos/plot_fonts.py`。

表中后 4 个程序复现附录本章一节没有列出，来自课件、阅读稿、CODE-MAP 或文件名前缀（第三部分另含学习器阶梯）。

## 第三部分的学习器阶梯（例子方案第三步）

四区仓库世界与 L0–L10 阶梯学习器。每章一个实验，三档：没有、设计者给定、从经验学到。比较都是配对的：同一种子下两档用同一份世界随机数。

```sh
python3 demos/crl_ladder_world.py --fast                     # 各区参考线，写 reference.json（全量去掉 --fast）
python3 demos/crl_ladder_world_checks.py                     # 世界本身的核对
python3 demos/crl_ladder_ceiling.py                          # 各条件的天花板（ε-软最好率），写 ceiling.json
python3 demos/crl_ladder_learners.py --exp ch18 --seeds 2 --steps 200000 --procs 2 --tag smoke   # 冒烟：写 assets/crl-ladder-world/runs/smoke-ch18.json
python3 demos/crl_ladder_learners.py --exp ch18 --seeds 20 --seed0 100 --steps 2000000 --tag formal   # 正式设置（种子数与 runs/ 里的正式记录相同）
python3 demos/crl_ladder_power.py ledger --runs formal-ch18     # 配对差与 95% 区间，写 ledger-formal-ch18.json
python3 demos/crl_ladder_figures.py ch18                       # 阅读稿用的地图与条形图（读账本）
# 改进与诊断（README 第九节）：同一套世界随机数，跑完用 --compare 出配对差
python3 demos/crl_ladder_diagnostics.py --arms ch18/local/given-sarsa0.9 --seeds 2 --steps 200000 --procs 2 --tag smoke   # 冒烟：写 runs/diag-smoke-*.json
python3 demos/crl_ladder_diagnostics.py --arms ch18/local/given-sarsa0.9 --seeds 12 --procs 3
python3 demos/crl_ladder_diagnostics.py --compare ch18/local/given-sarsa0.9 ch18/local/given
```

参考记录在 `assets/crl-ladder-world/runs/`（随本目录复制）。正式设置一章要跑数十分钟到数小时；冒烟一行只确认程序能走通。正式结果与读法见 `assets/crl-ladder-world/README.md` 第八节，改进与诊断见第九节。

## 复现附录本章一节

本章来自本课程序的结果有：18.1 节的三站路口图，18.4 节的两段历史图，18.5 节“看不清时：信念状态”中的信念柱状图与门口线索的期望收益，18.1–18.2 节的学习曲线与时间线配图，18.3 节一般的单智能体深度强化学习一类中大规模复杂环境里局部视野认得出位置的比例图，18.2 节四区仓库上局部观测的阶梯实验（含在精确模型上搜索无记忆策略与差分 Sarsa($\lambda$) 的诊断运行），18.4 节痕迹条件反射与 18.5 节罗盘世界两个文献原型的重跑，以及 18.6 节意外记忆实验的复现。意外记忆实验原来的脚本没有留下，复现由本课重写，300 次运行平均。

其余数字由正文推导直接算出，包括 18.1–18.3 节的 1/4、1/16、17/64 与 $5/8$ 对 $4/3$，18.3 节的指示对照表，18.5 节混叠损失在仓库两例上的下限 2 与 3/2，岭回归的 2/3、51/101、1/3、1/6，信念 4/5 与 3.4、1.6，选读一的回报分布，选读二的可行动作集，以及门口冻结预测器的期望平方误差 .09、.41、.25。18.1 节的配送经历图、18.3 节的判据图、18.5 节的混叠图与状态用途图是手绘 SVG，没有绘图程序。18.6 节引用的 SRM 99.7%、RTU 63%（Elsayed、Pham、Mahmood 2026）和 Jenkinson–Alvarez 的维数结果来自所引文献。

| 位置 | 结果 | 设置 | 程序 | 数据与输出 |
|---|---|---|---|---|
| 18.1 节“补充例：三站地图上的最近服务站” | 三站共用路口 J 的地图：J 到 A、B、C 的支路分别为 2、1、4 个原始步，到站奖励 1、.2、3 → .1 | 本课的绘图：节点 A、a、J、B、c1、c2、c3、C 按程序中的坐标绘出，到站奖励按程序中的标签标注；确定性绘图 | `demos/sample14_average_option.py` | `assets/sample14-avg-option/sample14-avg-map.png`、`assets/sample14-avg-option/sample14-avg-map.pdf` |
| 18.4 节“补充例：一步预测够用，递推却不够” | 末尾为 1 与 2 的两段历史一步预测分布相同，见到 3 以后需要不同的下一步预测 | 本课的绘图：按正文给定的两段历史与转移直接绘图；确定性绘图，程序为顶层脚本 | `demos/continual_figures.py` | `assets/continual/state-recursion.png`、`assets/continual/state-recursion.svg` |
| 18.5 节“看不清时：信念状态”中的“补充：两步预测与校正的数值” | 信念 $(.8,.2)\to(.76,.24)\to(19/73,54/73)\approx(.2603,.7397)$ 的三组柱 | 本课的绘图：转移矩阵两行 $(.9,.1)$、$(.2,.8)$，反馈似然 $(.1,.9)$；三组概率由正文推导直接算出后写入绘图程序，加 `--figures` 时才绘图 | `demos/continual_v6_calculations.py` | `assets/continual/v6/belief-update.png`、`assets/continual/v6/belief-update.svg`、`assets/continual/v6/manifest.json` |
| 18.5 延伸「门口线索的价值与长期路线选择」与「决策记忆与长期路线选择」 | 读到“宽”时直行期望 $1.60q-1$；$q=.60$ 时两种读数直行分别为 $-.04$、$-.36$，都应绕行；$q>5/8$ 时直行才严格胜出；标记准确时每处门口最多 .30，忘记标记时最好为 0；始终直行每处 $-.20$，长期每步奖励从 $-.10$ 提高到 .15 | 本课的计算：宽、窄门各半且独立，直行得 1、告警扣 4、绕行得 0，宽门、窄门告警概率 .10、.50；标记正确率 $q$ 取 .5 到 1 之间间隔 1/40 的 21 档，精确计算各读数下的直行收益与最优收益；另比较每处门口两个原始步时的长期奖励率。结果文件中的在线学习部分为 64 个独立种子，正文这里只用精确值 | `demos/door_signal.py` | `assets/door-signal/reader.json`（observed 下标 24、25、40 对应 $q=.60$、.625、1，blind 为不读标记） |
| 18.4 节“要记多久：痕迹条件反射”中的“本课重跑” | 后半段 MSRE：presence .137 / .226 / .269，微刺激 .033 / .041 / .047，痕迹瓦片 .036 / .034 / .034（ISI 均值 10 / 20 / 30）；presence 的误差与回报方差 .149 / .224 / .261 相当；附中档 ISI 一个试次的预测曲线 | 照 Rafiee 等（Adaptive Behavior，2023）trace conditioning：CS 4 步、US 2 步、ISI 三档均匀分布、ITI U(80,120)、10 个干扰；γ=1−1/E[ISI]；线性 TD(λ)，λ=.9，普通步长在五个候选中按 3 次 × 5 万步试跑选出；微刺激 16 个基、宽度 .08；痕迹瓦片 2 层 × 16 格；10 次独立运行，各 20 万步（原文 200 万步 × 30 次、Adam）；只重跑固定表示 | `demos/ch18_lit_trace.py` | `assets/ch18-lit-trace/results.json` |
| 18.5 节“以预测为状态：罗盘世界”中的“本课重跑” | 25 个朝向类节点的均方根误差 1k / 10k / 50k / 100k / 200k / 300k 步为 .409 / .318 / .061 / .053 / .019 / .017；后 15 万步朝向类 .021（只看观测 .312），一步节点 .108（只看观测 .184）；原地顺时针转 26 次，Forward 节点 26 次都报对墙色 | 照 Sutton、Rafols 与 Koop（NIPS 18，2005）部分可观测实验：6×6，6 个颜色比特，F / L / R 概率 .5 / .25 / .25，滑动 .1；每色 8 个问题节点共 40 个，答案网络按上一步动作分三组共 138 维输入，logistic 输出；选项内 TD(λ)，λ=.9，步长 1；10 次独立运行，各 30 万步 | `demos/ch18_lit_compass.py` | `assets/ch18-lit-compass/results.json` |
| 18.1 节“两种状态上的一次预测更新”（课件 `ch15-f03-learning`）；18.2 节（课件 `ch15-shared-state-interference`）；18.3 节“单智能体深度强化学习：状态也要学”（课件 `ch18-r21-survey-grid`） | 分组表与单表预报值随趟数变化的曲线；lifetime 16 步的奖励时间线，20 与 $331/32$；大规模复杂环境里局部视野在全图独一无二的格所占比例（一般的单智能体深度强化学习调研页） | 本课的计算：学习曲线中头两趟取 L、R，其后 18 次线索由 `random.Random(18)` 生成，单表与分组表步长 .5，另画步长 $1/(n+1)$ 递减的单表；时间线对 16 步精确求期望，程序断言 $J=20$ 与 $331/32$；比例图用边长 $n\in\{17,33,65,129,257\}$ 的房间世界，每隔 8 格一道墙（房间内部 7×7），门位随机，3 个种子，窗口 3×3 到 9×9；无训练，运行时打印核对 | `demos/ch18_r21_figs.py` | `assets/ch18-r21/learn-curves.pdf`、`assets/ch18-r21/timeline16.pdf`、`assets/ch18-r21/grid-alias.pdf` |
| 18.2 节（课件 `ch18-ladder`、`ch18-r21-ladder-learner`） | 局部 $3\times3$ 观测下，记住上次交货的站使每步奖励由天花板（.1298）的 2.6% 升到 28.6%；不随机探测时在“局部观测加上次的站”上搜到每步 .1326 的无记忆策略；差分 Sarsa($\lambda=.9$) 12 个种子到天花板的 54%，差分 Q 为 29%，配对差 $+.0326\pm.0024$ | 本课的模拟：四区仓库，200 万步，规律 R0，局部 $3\times3$ 观测，20 个种子；无记忆策略在精确模型上做策略梯度 | `demos/crl_ladder_learners.py` 实验 `ch18`；`demos/crl_ladder_memoryless.py`；`demos/crl_ladder_diagnostics.py` | `assets/crl-ladder-world/runs/formal-ch18.json`、`assets/crl-ladder-world/fig/ladder-ch18.png`、`assets/crl-ladder-world/memoryless.json`；runs/diag-ch18_local_given-sarsa0.9.json |
| 18.6 节（课件 `ch18-surprise-experiment`） | 本课重写的复现：$\gamma=.72$ 时固定探索率 .05、.1、.2、.3 得 2682、3073、3165、3034（表中 2604、3083、3197、3062），一位意外记忆得 3365（表中 3373） | 本课的模拟：表格 Sarsa，$\alpha=.1$，零初值，第 1000 步起规则反过来，300 次运行平均，标准误在 24 以内；原实验的脚本没有留下 | `demos/ch18_surprise_bit.py` | 只在终端输出，不写文件 |

运行：
```sh
python3 demos/sample14_average_option.py
python3 demos/door_signal.py --reliability 3/5
python3 demos/door_signal.py --option-time
python3 demos/door_signal.py --export assets/door-signal/reader.json
python3 demos/ch18_lit_trace.py            # 文献原型：痕迹条件反射，写 assets/ch18-lit-trace
python3 demos/ch18_lit_compass.py          # 文献原型：罗盘世界，写 assets/ch18-lit-compass
python3 demos/ch18_r21_figs.py             # 写 assets/ch18-r21
python3 demos/crl_ladder_learners.py --exp ch18 --seeds 20 --seed0 100 --steps 2000000 --tag formal   # 四区仓库阶梯，写 assets/crl-ladder-world/runs/formal-ch18.json
python3 demos/crl_ladder_figures.py ch18           # 写 assets/crl-ladder-world/fig/ladder-ch18.png
python3 demos/crl_ladder_memoryless.py     # 写 assets/crl-ladder-world/memoryless.json
python3 demos/ch18_surprise_bit.py         # 可加折扣因子，默认 .72；只打印
```

## 参考数据

`assets/`（以及 `demos/NN-results/`）下复制了 115 个数据文件（json、csv 等），即课程目前使用的结果；图片没有复制，运行程序会重新画出。重跑会覆盖这些文件，可以先另存一份再对照。
