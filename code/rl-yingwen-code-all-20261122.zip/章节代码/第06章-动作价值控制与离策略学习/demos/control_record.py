"""泥地第 6、7 章：运行 python demos/control_record.py（只用标准库）。

给定 S7 向上，第一步必到 S4。比较同一张冻结 Q 表下的两条后续记录：
向上成功到达终点，或向上打滑留在 S4。最后枚举所有可能后果。
折扣、策略和 Q 表是题设；移动概率和奖励来自 mud_world.outcomes。
"""
from fractions import Fraction

from mud_world import ACTIONS, GAMMA, outcomes

DISCOUNT = Fraction(str(GAMMA))
# 动作顺序与网格环境相同，依次为上、右、下、左。
Q = dict(zip(ACTIONS, map(Fraction, ('.5', '.1', '.2', '.7'))))
BEHAVIOR = dict(zip(ACTIONS, map(Fraction, ('.05', '.05', '.05', '.85'))))
TARGET = dict(zip(ACTIONS, map(Fraction, ('.1', '0', '0', '.9'))))


def movement_probability(state, action, reward, next_state, terminal):
    """同一动作可能有多个分支通向相同后果（如撞墙）。"""
    return sum(
        Fraction(str(prob))
        for prob, nxt, r, done in outcomes(state, action)
        if (r, nxt, done) == (reward, next_state, terminal)
    )


def expected_value(policy, values):
    return sum(prob * values[action] for action, prob in policy.items())


def evaluate_record():
    """首动作已给定。在 S4 选上，走到 G；回合到此终止。"""
    [(first_prob, middle, first_reward, done)] = outcomes('S7', 'up')
    assert first_prob == 1 and not done
    observed_action = 'up'
    [(last_reward, terminal)] = [
        (Fraction(str(r)), nxt) for _, nxt, r, done in outcomes(middle, observed_action) if done
    ]
    success = movement_probability(middle, observed_action, last_reward, terminal, True)
    r1 = Fraction(str(first_reward))
    episode_return = r1 + DISCOUNT * last_reward
    prob_behavior = BEHAVIOR[observed_action] * success
    prob_target = TARGET[observed_action] * success
    importance_ratio = prob_target / prob_behavior
    greedy_action = max(Q, key=Q.get)  # S4 的动作价值有唯一最大值
    greedy_path_ratio = int(observed_action == greedy_action) * success / prob_behavior
    return {
        'Sarsa, observed next action': r1 + DISCOUNT * Q[observed_action],
        'Expected Sarsa, behavior policy': r1 + DISCOUNT * expected_value(BEHAVIOR, Q),
        'Expected Sarsa, target policy': r1 + DISCOUNT * expected_value(TARGET, Q),
        'Q-learning, greedy continuation': r1 + DISCOUNT * max(Q.values()),
        'Observed discounted return': episode_return,
        'IS weight for the frozen greedy policy': greedy_path_ratio,
        'Conditional path likelihood ratio': importance_ratio,
        'Ordinary IS, single weighted sample': importance_ratio * episode_return,
    }


def slip_record(old=Fraction('.4'), alpha=Fraction('.2')):
    """S4 向上打滑；在 S4 又抽到向上。末端对目标策略求和时，无需读取最后一个动作。"""
    [(_, s1, r1, _)] = outcomes('S7', 'up')
    a1, a2 = 'up', 'up'
    [(r2, s2)] = [(r, nxt) for _, nxt, r, done in outcomes(s1, a1) if nxt == s1 and not done]
    assert s1 == s2 == 'S4'
    prefix = Fraction(str(r1)) + DISCOUNT * Fraction(str(r2))
    rho1 = TARGET[a1] / BEHAVIOR[a1]
    rho2 = TARGET[a2] / BEHAVIOR[a2]
    sampled = prefix + DISCOUNT**2 * Q[a2]
    averaged = prefix + DISCOUNT**2 * expected_value(TARGET, Q)
    # 普通重要性采样的权重乘整个更新误差。
    return {
        'Sarsa G': sampled,
        'Sarsa weight (A1 and A2)': rho1 * rho2,
        'Sarsa Q after this record': old + alpha * rho1 * rho2 * (sampled - old),
        'Expected Sarsa G': averaged,
        'Expected Sarsa weight (A1)': rho1,
        'Expected Sarsa Q after this record': old + alpha * rho1 * (averaged - old),
    }


def endpoint_branches(state, terminal, values):
    """每个可能的末端动作给出 (行为概率, 目标概率, 自举值)。"""
    if terminal:
        yield Fraction(1), Fraction(1), Fraction(0)  # 到 G 无动作、无尾值、无新比率
        return
    if state == 'S4':
        for action in ACTIONS:
            yield BEHAVIOR[action], TARGET[action], values[action]
    else:
        # 行为可向下返回 S7。题设目标不会选下；补全该状态以便枚举行为的记录。
        for _ in ACTIONS:
            yield Fraction(1, len(ACTIONS)), Fraction(1, len(ACTIONS)), Fraction('.4')


def enumerate_two_steps(values=Q):
    """在同一首动作条件下，分别按目标策略和行为策略枚举，精确计算两步均值。"""
    [(_, s1, r1, _)] = outcomes('S7', 'up')
    direct = sampled_is = expected_is = Fraction(0)
    tree_backup = per_decision = Fraction(0)
    start_tail = expected_value(TARGET, values)
    for a1 in ACTIONS:
        b1, pi1 = BEHAVIOR[a1], TARGET[a1]
        if b1 == 0:
            if pi1 > 0:
                raise ValueError(f'行为策略未覆盖目标动作 {a1!r}')
            continue
        rho1 = pi1 / b1
        for p, s2, r2, done in outcomes(s1, a1):
            env_prob = Fraction(str(p))
            prefix = Fraction(str(r1)) + DISCOUNT * Fraction(str(r2))
            branches = list(endpoint_branches(s2, done, values))
            mean_tail = sum(pi2 * q2 for _, pi2, q2 in branches)
            g_expected = prefix + DISCOUNT**2 * mean_tail

            # 直接按目标策略平均。行为策略取得同一前缀的概率是 b1 * env_prob。
            direct += pi1 * env_prob * g_expected
            behavior_prefix = b1 * env_prob
            expected_is += behavior_prefix * rho1 * g_expected
            # 新转移只为实际动作提供一次修正；两种算法给这项修正不同的权重。
            # 树回退保留目标策略的分支权重，逐决策重要性采样还校正抽样频率。
            observed_tail = Fraction(str(r2)) + DISCOUNT * mean_tail
            residual = observed_tail - values[a1]
            first = Fraction(str(r1)) + DISCOUNT * start_tail
            tree_backup += behavior_prefix * (first + DISCOUNT * pi1 * residual)
            per_decision += behavior_prefix * (first + DISCOUNT * rho1 * residual)
            for b2, pi2, q2 in branches:
                if b2 == 0:  # S4 的覆盖条件在外层逐动作检查，其他状态两策略相同。
                    continue
                rho2 = pi2 / b2
                g_sampled = prefix + DISCOUNT**2 * q2
                sampled_is += behavior_prefix * b2 * rho1 * rho2 * g_sampled
    assert direct == sampled_is == expected_is == per_decision
    return {
        'Direct target-policy mean': direct,
        'Behavior mean, IS Sarsa': sampled_is,
        'Behavior mean, IS Expected Sarsa': expected_is,
        'Behavior mean, per-decision IS': per_decision,
        'Behavior mean, Tree Backup': tree_backup,
    }


def exact_fixed_point():
    """目标策略在 S4 选上或左。一次尝试或者进终点得 1，或者留在原地。"""
    p_goal = TARGET['up'] * movement_probability('S4', 'up', 1, 'G', True)
    # v = p_goal + (1 - p_goal) * gamma * v
    v = p_goal / (1 - (1 - p_goal) * DISCOUNT)
    values = Q.copy()
    for action, probability in TARGET.items():
        if probability:
            branches = outcomes('S4', action)
            assert all(done or nxt == 'S4' for _, nxt, _, done in branches)
            values[action] = sum(
                Fraction(str(p)) * (Fraction(str(r)) + (0 if done else DISCOUNT * v))
                for p, _, r, done in branches
            )
    # 目标策略未选择的动作权重为零，无需指定其真值。首动作 S7 向上必到 S4。
    assert expected_value(TARGET, values) == v
    means = enumerate_two_steps(values)
    assert all(value == DISCOUNT * v for value in means.values())
    return {'v_pi(S4)': v, 'q_pi(S7, up)': DISCOUNT * v, **means}


if __name__ == '__main__':
    sections = (
        ('一、从 S7 向上，随后走出泥地', evaluate_record()),
        ('二、从 S7 向上，随后在 S4 打滑（初值 .4，步长 .2）', slip_record()),
        ('三、所有可能记录的两步目标均值（末端使用冻结 Q）', enumerate_two_steps()),
        ('四、目标策略的真值：两种两步更新都保持不动点', exact_fixed_point()),
    )
    for heading, values in sections:
        print(heading)
        for label, value in values.items():
            print(f'  {label:38s} {float(value):.8g}')
