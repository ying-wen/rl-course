"""Chapter 6, Double Q-learning experiments (11-21 review request r1121-111555, p349).

Part 1: Sutton & Barto (2nd ed.) Example 6.7, the maximization-bias MDP.
  A: right -> terminal, reward 0; left -> B, reward 0.
  B: N_B actions, each -> terminal with reward ~ N(-0.1, 1).
  epsilon = .1, alpha = .1, gamma = 1, Q initialised to 0, 300 episodes.
  Records the fraction of runs that choose left in A in each episode.
Part 2: the course mud world (demos/mud_world.py), Q initialised to 1,
  alpha = .05, epsilon = .2, gamma = .9, 20000 real steps from S7,
  100 runs with seeds 1000..1099. Records max_a Q(S4, a) and the greedy
  action at S7 for Q-learning and Double Q-learning.

Run:  python3 demos/ch06_double_q_runs.py
Outputs: assets/ch06-double/example67.pdf and assets/ch06-double/results.json
"""
import json
import random
import statistics
from pathlib import Path

import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

import mud_world as env
from plot_fonts import use_course_fonts, CJK_FAMILY, no_leading_zero

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'assets' / 'ch06-double'

RUNS_67 = 2000
EPISODES = 300
N_B = 10
EPS, ALPHA = .1, .1


def argmax_random(q, rng):
    """Row-wise argmax with uniform tie-breaking; q has shape (runs, n)."""
    noise = rng.random(q.shape) * 1e-9
    top = q.max(axis=1, keepdims=True)
    return np.argmax((q >= top - 1e-12) * (1 + noise), axis=1)


def example67(double, seed):
    rng = np.random.default_rng(seed)
    runs = RUNS_67
    tables = 2 if double else 1
    qa = np.zeros((tables, runs, 2))        # A: 0 = left, 1 = right
    qb = np.zeros((tables, runs, N_B))
    left = np.zeros(EPISODES)
    idx = np.arange(runs)
    for ep in range(EPISODES):
        greedy = argmax_random(qa.sum(axis=0), rng)
        explore = rng.random(runs) < EPS
        a = np.where(explore, rng.integers(0, 2, runs), greedy)
        left[ep] = np.mean(a == 0)
        # Update at A. Right ends with reward 0.
        upd = rng.integers(0, tables, runs) if double else np.zeros(runs, int)
        other = 1 - upd if double else upd
        go_left = a == 0
        sel = argmax_random(qb[upd, idx], rng)
        boot = qb[other, idx, sel]
        target = np.where(go_left, boot, 0.0)
        qa[upd, idx, a] += ALPHA * (target - qa[upd, idx, a])
        # Step in B for the runs that went left.
        greedy_b = argmax_random(qb.sum(axis=0), rng)
        explore_b = rng.random(runs) < EPS
        b = np.where(explore_b, rng.integers(0, N_B, runs), greedy_b)
        r = rng.normal(-.1, 1., runs)
        upd_b = rng.integers(0, tables, runs) if double else np.zeros(runs, int)
        cur = qb[upd_b, idx, b]
        qb[upd_b, idx, b] = np.where(go_left, cur + ALPHA * (r - cur), cur)
    return left


def mud_run(double, seed):
    rng = random.Random(seed)
    acts = list(env.ACTIONS)

    def tied_argmax(values):
        top = max(values.values())
        return rng.choice([a for a, x in values.items() if x >= top - 1e-12])

    qa = {s: {a: 1. for a in acts} for s in env.STATES}
    qb = {s: dict(v) for s, v in qa.items()}
    state = 'S7'
    for _ in range(20000):
        if double:
            score = {a: qa[state][a] + qb[state][a] for a in acts}
        else:
            score = qa[state]
        action = rng.choice(acts) if rng.random() < .2 else tied_argmax(score)
        u, mass = rng.random(), 0.
        for prob, nxt, reward, done in env.outcomes(state, action):
            mass += prob
            if u < mass:
                break
        if double:
            first, second = (qa, qb) if rng.random() < .5 else (qb, qa)
            boot = 0. if done else second[nxt][tied_argmax(first[nxt])]
        else:
            first = qa
            boot = 0. if done else max(qa[nxt].values())
        target = reward + .9 * boot
        first[state][action] += .05 * (target - first[state][action])
        state = 'S7' if done else nxt
    if double:
        s4 = max((qa['S4'][a] + qb['S4'][a]) / 2 for a in acts)
        s7 = max(acts, key=lambda a: qa['S7'][a] + qb['S7'][a])
    else:
        s4 = max(qa['S4'].values())
        s7 = max(acts, key=lambda a: qa['S7'][a])
    return s4, s7


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    ql = example67(False, 61)
    dq = example67(True, 62)
    se = lambda p: float(np.sqrt(p * (1 - p) / RUNS_67))
    res = {'example_6_7': {
        'runs': RUNS_67, 'episodes': EPISODES, 'actions_in_B': N_B,
        'epsilon': EPS, 'alpha': ALPHA, 'gamma': 1, 'Q0': 0, 'seeds': [61, 62],
        'left_ep1_10_mean': {'Q': float(ql[:10].mean()), 'DoubleQ': float(dq[:10].mean())},
        'left_peak': {'Q': float(ql.max()), 'Q_episode': int(ql.argmax()) + 1,
                      'DoubleQ': float(dq.max()), 'DoubleQ_episode': int(dq.argmax()) + 1},
        'left_last50_mean': {'Q': float(ql[-50:].mean()), 'DoubleQ': float(dq[-50:].mean())},
        'se_per_point_at_.5': se(.5), 'optimal_left_fraction': EPS / 2}}

    truth = .1 / (1 - .81)   # S4 under the greedy policy: v = .1 + .81 v
    mud = {}
    for name, double in (('Q', False), ('DoubleQ', True)):
        vals, left = [], 0
        for seed in range(1000, 1100):
            s4, s7 = mud_run(double, seed)
            vals.append(s4)
            left += s7 == 'left'
        mud[name] = {'S4_mean': statistics.mean(vals), 'S4_sd': statistics.stdev(vals),
                     'S4_se': statistics.stdev(vals) / 10, 'S7_left_runs': left}
    res['mud_world'] = {'runs': 100, 'seeds': [1000, 1099], 'steps': 20000, 'alpha': .05,
                        'epsilon': .2, 'gamma': .9, 'Q0': 1, 'S4_true': truth, **mud}
    (OUT / 'results.json').write_text(json.dumps(res, indent=2, ensure_ascii=False))
    print(json.dumps(res, indent=2, ensure_ascii=False))

    # Figure: 7.4 cm wide on the slide; W = 3.6 in -> scale .81; 9pt -> 7.3pt.
    use_course_fonts()
    fig, ax = plt.subplots(figsize=(3.6, 2.3))
    x = np.arange(1, EPISODES + 1)
    ax.plot(x, ql, color='#B5473A', lw=1.3)
    ax.plot(x, dq, color='#2F7F7A', lw=1.3)
    ax.axhline(EPS / 2, color='#777777', lw=.8, ls='--')
    ax.text(30, .955, 'Q-learning', color='#B5473A', ha='left', va='bottom', fontsize=10)
    ax.text(42, .27, 'Double Q-learning', color='#2F7F7A', ha='left', fontsize=10)
    ax.text(304, EPS / 2, '最优\n5%', color='#555555', ha='left', va='center',
            fontsize=9, clip_on=False)
    ax.set_xlim(0, 300)
    ax.set_ylim(0, 1)
    ax.yaxis.set_major_formatter(no_leading_zero)
    ax.set_xlabel('回合', fontsize=10)
    ax.set_ylabel('在 A 选左的比例', fontsize=10, fontfamily=CJK_FAMILY)
    ax.tick_params(labelsize=9)
    for side in ('top', 'right'):
        ax.spines[side].set_visible(False)
    fig.savefig(OUT / 'example67.pdf', bbox_inches='tight')


if __name__ == '__main__':
    main()
