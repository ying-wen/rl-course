"""Chapter 6.4 figures redrawn in the course fonts (11-21 review request r1121-111555).

Run:  python3 demos/ch06_control_figs.py
Outputs (new files; the older figures and their scripts are left untouched):
  assets/ch06-control/cliff-paths.pdf      p323  greedy routes after 500 episodes, seed 0
  assets/ch06-control/cliff-results.pdf    p324  training curves and per-run frozen returns
  assets/ch06-control/control-feedback.pdf p325  one Q-learning update changes the greedy action
  assets/ch06-control/mud-q-runs.pdf       p326  mud-world Q-learning, 100 independent runs
  assets/ch06-control/results.json         numbers quoted on the slides

Data sources.
  Cliff (p323, p324): reads assets/course25-control/{results.json,episodes.csv,evaluation.csv},
  written by demos/course25_sarsa_q.py (12 seeds, 500 episodes, alpha=.5, epsilon=.1).
  Nothing is retrained here.
  Mud (p326): re-runs the control loop of demos/classic_v6_lab.py (Q0=1, alpha=.05,
  epsilon=.2, gamma=.9, 20000 real steps from S7, uniform ties while learning, first of
  up/right/down/left for the frozen greedy action) for seeds 0..99 with random.Random(seed).
  Seed 7 must reproduce the single run in assets/v6-classic/results.json; this is asserted.
"""
import csv
import json
import random
import statistics
from pathlib import Path

import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, Circle, FancyArrowPatch
from matplotlib.ticker import FuncFormatter

import mud_world as env
from plot_fonts import use_course_fonts, CJK_FAMILY, no_leading_zero

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'assets' / 'ch06-control'
CLIFF = ROOT / 'assets' / 'course25-control'
INK, TEAL, RED, GOLD, MUTED = '#182E38', '#096B76', '#AA412D', '#A27618', '#52666E'
PALE, LIGHT = '#EAF4F3', '#F3F5F5'
CLIFF_FILL, EDGE_FILL, GOLD_FILL = '#F2DCD5', '#F6EBCF', '#F2E3BD'


def save(fig, name):
    fig.savefig(OUT / f'{name}.pdf', bbox_inches='tight', facecolor='white')
    plt.close(fig)


def arrow(ax, start, end, color, lw=1.6, ls='-', scale=11):
    ax.add_patch(FancyArrowPatch(start, end, arrowstyle='-|>', mutation_scale=scale,
                                 color=color, lw=lw, linestyle=ls, shrinkA=0, shrinkB=0))


# ---------------------------------------------------------------- p323
def cliff_paths(paths):
    """Flat 4 x 12 grid. Row 0 is the top row; the cliff is row 3, columns 1..10."""
    fig, ax = plt.subplots(figsize=(6.6, 2.35))
    y = lambda row: 3 - row
    for row in range(4):
        for col in range(12):
            cliff = row == 3 and 1 <= col <= 10
            lip = row == 2 and 1 <= col <= 10
            fc = CLIFF_FILL if cliff else EDGE_FILL if lip else LIGHT
            ax.add_patch(Rectangle((col, y(row)), 1, 1, fc=fc, ec='#B7C2C6', lw=.6))
    ax.add_patch(Rectangle((1, 0), 10, 1, fill=False, ec=RED, lw=1))
    ax.text(3.6, .5, '悬崖：奖励 −100，回到起点', ha='center', va='center', color=RED, fontsize=10.5)
    ax.text(.5, -.3, '起点', ha='center', va='center', fontsize=10.5)
    ax.text(11.5, -.3, '终点', ha='center', va='center', fontsize=10.5)
    ax.text(12.12, 1.5, '临崖格', ha='left', va='center', color=GOLD, fontsize=10.5)
    ax.text(12.12, .5, '悬崖', ha='left', va='center', color=RED, fontsize=10.5)
    route = {}
    for kind, color, shift in [('sarsa', TEAL, (-.09, .09)), ('qlearning', RED, (.09, -.09))]:
        cells = [divmod(s, 12) for s in paths[kind]]
        xs = [c + .5 + shift[0] for r, c in cells]
        ys = [y(r) + .5 + shift[1] for r, c in cells]
        ax.plot(xs, ys, color=color, lw=2.4, solid_joinstyle='round', solid_capstyle='round', zorder=3)
        for j in range(len(cells) - 1):
            if j % 2 == 0:
                mx, my = (xs[j] + xs[j + 1]) / 2, (ys[j] + ys[j + 1]) / 2
                dx, dy = xs[j + 1] - xs[j], ys[j + 1] - ys[j]
                arrow(ax, (mx - .12 * dx, my - .12 * dy), (mx + .12 * dx, my + .12 * dy), color, lw=1.2, scale=10)
        lips = sum(1 for r, c in cells if r == 2 and 1 <= c <= 10)
        route[kind] = dict(steps=len(cells) - 1, cliff_edge_cells=lips)
    # One hypothetical exploratory step, drawn apart from the measured greedy routes.
    arrow(ax, (7.5, 1.38), (7.5, .62), MUTED, lw=1.2, ls=(0, (2.5, 2)), scale=9)
    ax.text(7.62, .5, '试探向下：概率 .025', ha='left', va='center', color=INK, fontsize=10)
    s, q = route['sarsa'], route['qlearning']
    ax.text(0, 4.28, f"Sarsa：{s['steps']} 步，{s['cliff_edge_cells']} 个临崖格",
            color=TEAL, fontsize=11, ha='left', va='center')
    ax.text(12, 4.28, f"Q-learning：{q['steps']} 步，{q['cliff_edge_cells']} 个临崖格",
            color=RED, fontsize=11, ha='right', va='center')
    ax.set(xlim=(-.05, 13.2), ylim=(-.55, 4.55), aspect='equal')
    ax.axis('off')
    save(fig, 'cliff-paths')
    return route


# ---------------------------------------------------------------- p324
def cliff_results():
    rows = list(csv.DictReader((CLIFF / 'episodes.csv').open()))
    evals = list(csv.DictReader((CLIFF / 'evaluation.csv').open()))
    seeds = sorted({int(r['seed']) for r in rows})
    fig, axes = plt.subplots(1, 2, figsize=(8.6, 2.45), gridspec_kw={'width_ratios': [1.25, 1]},
                             constrained_layout=True)
    a, b = axes
    summary = {}
    for kind, color, label in [('sarsa', TEAL, 'Sarsa'), ('qlearning', RED, 'Q-learning')]:
        ret = np.array([[float(r['reward']) for r in rows if r['method'] == kind and int(r['seed']) == s]
                        for s in seeds])
        smooth = np.array([np.convolve(r, np.ones(20) / 20, mode='valid') for r in ret])
        m = smooth.mean(axis=0)
        se = smooth.std(axis=0, ddof=1) / np.sqrt(len(seeds))
        x = np.arange(20, ret.shape[1] + 1)
        a.plot(x, m, color=color, lw=1.6, label=label)
        a.fill_between(x, m - se, m + se, color=color, alpha=.15, lw=0)
        summary[kind] = dict(final100_mean=float(ret[:, 400:].mean()))
    a.set_xlabel('训练回合', fontsize=11)
    a.set_ylabel('每回合奖励之和', fontsize=11)
    a.set_title(r'训练中（$\varepsilon=.1$）：12 次运行的均值', fontsize=11, fontfamily=CJK_FAMILY)
    a.set(ylim=(-150, 0), xlim=(0, 500))
    a.legend(frameon=False, fontsize=10.5, loc='lower right')
    floor = -82
    for j, eps in enumerate(['0', '0.1']):
        for kind, color, off in [('sarsa', TEAL, -.17), ('qlearning', RED, .17)]:
            vals = np.array([float(v['return_first200']) for v in evals
                             if v['method'] == kind and v['epsilon'] == eps])
            loop = np.array([v['proper'] == 'False' for v in evals
                             if v['method'] == kind and v['epsilon'] == eps])
            rng = np.random.default_rng(3 + j)
            jitter = rng.uniform(-.07, .07, len(vals))
            ok = ~loop
            b.scatter(j + off + jitter[ok], vals[ok], s=16, color=color, alpha=.75, lw=0, zorder=3)
            if loop.any():
                b.scatter(j + off + jitter[loop], np.full(loop.sum(), floor + 2.5), s=26, marker='v',
                          color=color, zorder=3)
            med = float(np.median(vals))
            b.plot([j + off - .13, j + off + .13], [med, med], color=INK, lw=1.6, zorder=4)
            summary[kind][f'eps{eps}'] = dict(mean=float(vals.mean()), median=med,
                                              looping_runs=int(loop.sum()),
                                              looping_seeds=[int(v['seed']) for v in evals
                                                             if v['method'] == kind and v['epsilon'] == eps
                                                             and v['proper'] == 'False'],
                                              min=float(vals.min()), max=float(vals.max()))
    b.axhline(floor + 6, color='#C9D1D4', lw=.8, ls=(0, (3, 2)))
    b.text(-.03, floor + 2.5, '2 次撞墙停住，各计 −200', fontsize=10, color=TEAL, va='center', ha='left')
    b.set_xticks([0, 1])
    b.set_xticklabels(['只走贪心', r'保留 $\varepsilon=.1$'], fontsize=11, fontfamily=CJK_FAMILY)
    b.set_ylabel('前 200 步累积奖励', fontsize=11)
    b.set_title('冻结 Q 表后：每点一次运行，横线为中位数', fontsize=11)
    b.set(ylim=(floor, 0), xlim=(-.5, 1.5))
    for ax in axes:
        ax.tick_params(labelsize=10.5)
        ax.spines[['top', 'right']].set_visible(False)
        ax.yaxis.set_major_formatter(FuncFormatter(no_leading_zero))
    save(fig, 'cliff-results')
    return dict(seeds=seeds, **summary)


# ---------------------------------------------------------------- p325
def node(ax, xy, label, color=INK, r=.26):
    ax.add_patch(Circle(xy, r, fc='white', ec=color, lw=1.4, zorder=4))
    ax.text(*xy, label, ha='center', va='center', color=color, zorder=5, fontsize=11)


def control_feedback():
    qbefore, qafter, gamma, alpha, s4max = [.50, .49], [None, .49], .9, .5, .4
    y = 0 + gamma * s4max
    qafter[0] = qbefore[0] + alpha * (y - qbefore[0])
    assert abs(y - .36) < 1e-12 and abs(qafter[0] - .43) < 1e-12 and qafter[0] < qbefore[1]
    fig, (ax, bx) = plt.subplots(1, 2, figsize=(7.4, 2.15), gridspec_kw={'width_ratios': [1, 1.25]})
    ax.scatter(qbefore, [1, 0], s=46, color=MUTED, zorder=3, label='更新前')
    ax.scatter(qafter, [1, 0], s=80, marker='|', linewidths=2.4, color=TEAL, zorder=3, label='更新后')
    arrow(ax, (.4965, 1), (.4335, 1), TEAL, lw=1.6, scale=10)
    ax.text(.503, 1, '.50', va='center', fontsize=10.5)
    ax.text(.43, .72, '.43', ha='center', fontsize=10.5, color=TEAL)
    ax.text(.49, -.33, '.49（未更新）', ha='center', fontsize=10.5)
    ax.set_yticks([0, 1])
    ax.set_yticklabels(['左', '上'], fontsize=11)
    ax.set_xlim(.40, .53)
    ax.set_ylim(-.6, 1.6)
    ax.set_xlabel(r'$Q(\mathrm{S7},a)$', fontsize=11)
    ax.xaxis.set_major_formatter(FuncFormatter(no_leading_zero))
    ax.tick_params(labelsize=10.5)
    ax.spines[['top', 'right']].set_visible(False)
    ax.legend(loc='upper center', ncol=2, fontsize=10, frameon=False, bbox_to_anchor=(.5, 1.18))
    node(bx, (.3, .75), 'S7')
    node(bx, (3.1, 1.6), 'S4')
    node(bx, (3.1, -.1), 'S6')
    arrow(bx, (.55, .87), (2.84, 1.5), MUTED, lw=1.5)
    arrow(bx, (.55, .64), (2.84, -.02), TEAL, lw=1.5)
    bx.text(1.35, 1.62, '本次：上，奖励 0', ha='center', fontsize=10.5, color=MUTED)
    bx.text(1.45, -.5, '下回合：贪心选左', ha='center', fontsize=10.5, color=TEAL)
    bx.text(3.45, 1.85, '快照中的值', va='center', fontsize=10.5)
    bx.text(3.45, 1.35, r'$\max_c Q(\mathrm{S4},c)$ = .4', va='center', fontsize=10.5)
    bx.text(0, -1.05, r'$Y$ = 0 + .9 × .4 = .36,   $\alpha$ = .5', fontsize=11)
    bx.text(0, -1.55, r'$Q^{+}(\mathrm{S7},\uparrow)$ = .5 + .5(.36 − .5) = .43', fontsize=11)
    bx.set(xlim=(-.1, 5.6), ylim=(-1.75, 2.05))
    bx.axis('off')
    fig.subplots_adjust(wspace=.12)
    save(fig, 'control-feedback')
    return dict(Y=y, Q_after=qafter[0])


# ---------------------------------------------------------------- p326
A = list(env.ACTIONS)


def mud_step(s, a, rng):
    u = rng.random()
    mass = 0
    for p, n, r, d in env.outcomes(s, a):
        mass += p
        if u < mass:
            return n, r, d
    raise AssertionError('probability mass')


def mud_control(seed, q0=1., alpha=.05, eps=.2, steps=20000, marks=(100, 1000, 20000)):
    """Same loop as control(0) in demos/classic_v6_lab.py."""
    rng = random.Random(seed)
    q = {(s, a): q0 for s in env.STATES for a in A}
    s = 'S7'
    snaps = {}
    for t in range(1, steps + 1):
        if rng.random() < eps:
            a = rng.choice(A)
        else:
            best = max(q[s, c] for c in A)
            a = rng.choice([c for c in A if q[s, c] == best])
        nxt, r, done = mud_step(s, a, rng)
        q[s, a] += alpha * (r + (0 if done else env.GAMMA * max(q[nxt, c] for c in A)) - q[s, a])
        s = 'S7' if done else nxt
        if t in marks:
            snaps[t] = dict(Q_max={u: max(q[u, c] for c in A) for u in env.STATES},
                            greedy={u: max(A, key=lambda c: q[u, c]) for u in env.STATES})
    return snaps


ARROW = {'up': (0, 1), 'right': (1, 0), 'down': (0, -1), 'left': (-1, 0)}


def mud_runs(seeds=range(100)):
    ref = json.loads((ROOT / 'assets/v6-classic/results.json').read_text())['control']['snapshots']
    runs = {seed: mud_control(seed) for seed in seeds}
    for z in ref:
        mine = runs[7][z['environment_steps']]
        assert all(abs(mine['Q_max'][u] - z['Q_max'][u]) < 1e-12 for u in env.STATES), 'seed 7 mismatch'
        assert mine['greedy'] == z['greedy_policy'], 'seed 7 greedy mismatch'
    truth = env.evaluate(env.NEW)
    n = len(runs)
    stats = {}
    fig, axes = plt.subplots(1, 3, figsize=(7.4, 2.75))
    # Figure grid: x to the right, y upward; mud_world rows run downward.
    for ax, t, title in zip(axes, (100, 1000, 20000), ('100 步', '1000 步', '2 万步')):
        mean = {u: statistics.mean(runs[k][t]['Q_max'][u] for k in runs) for u in env.STATES}
        sd = {u: statistics.stdev(runs[k][t]['Q_max'][u] for k in runs) for u in env.STATES}
        votes = {u: {c: sum(runs[k][t]['greedy'][u] == c for k in runs) for c in A} for u in env.STATES}
        top = {u: max(A, key=lambda c: votes[u][c]) for u in env.STATES}
        stats[t] = dict(mean=mean, sd=sd, se={u: sd[u] / n ** .5 for u in env.STATES},
                        greedy_votes=votes)
        for cx in range(3):
            for cy in range(3):
                u = env.AT.get((cx, cy))
                X, Y = cx, 2 - cy
                fc = INK if u is None else GOLD_FILL if u == 'S4' else PALE
                ax.add_patch(Rectangle((X, Y), 1, 1, fc=fc, ec=MUTED, lw=.7))
                if u is None:
                    continue
                if u == 'G':   # 11-21: grid cells keep their names; the goal cell is G (course rule)
                    ax.text(X + .06, Y + .88, 'G', fontsize=9.5, va='center', color=MUTED)
                    ax.text(X + .5, Y + .45, '终点', ha='center', va='center', fontsize=10.5)
                    continue
                ax.text(X + .06, Y + .88, u, fontsize=9.5, va='center', color=MUTED)
                ax.text(X + .5, Y + .52, f'{mean[u]:.3f}'.lstrip('0'), ha='center', va='center',
                        fontsize=11)
                share = votes[u][top[u]] / n
                dx, dy = ARROW[top[u]]
                arrow(ax, (X + .5 - .14 * dx, Y + .22 - .14 * dy), (X + .5 + .14 * dx, Y + .22 + .14 * dy),
                      TEAL if share >= .9 else MUTED, lw=1.3, scale=9)
        ax.set_title(title, fontsize=11, pad=4)
        ax.set(xlim=(0, 3), ylim=(0, 3), aspect='equal')
        ax.axis('off')
    fig.subplots_adjust(wspace=.08)
    save(fig, 'mud-q-runs')
    final = [runs[k][20000]['Q_max']['S4'] for k in runs]
    s7_left = sum(runs[k][20000]['greedy']['S7'] == 'left' for k in runs)
    return dict(seeds=[min(runs), max(runs)], runs=n, q0=1., alpha=.05, epsilon=.2, gamma=env.GAMMA,
                steps=20000, S4_true=truth['S4'], S7_true=truth['S7'],
                S4_final_mean=statistics.mean(final), S4_final_sd=statistics.stdev(final),
                S4_final_se=statistics.stdev(final) / n ** .5, S4_final_min=min(final), S4_final_max=max(final),
                S7_final_mean=stats[20000]['mean']['S7'], S7_final_se=stats[20000]['se']['S7'],
                S7_greedy_left_runs=s7_left,
                seed7_S4=runs[7][20000]['Q_max']['S4'],
                snapshots={str(t): v for t, v in stats.items()})


def main():
    ok = use_course_fonts()
    OUT.mkdir(parents=True, exist_ok=True)
    paths = json.loads((CLIFF / 'results.json').read_text())['paths']
    res = dict(fonts_found=ok, cliff_paths=cliff_paths(paths), cliff_results=cliff_results(),
               control_feedback=control_feedback(), mud=mud_runs(),
               provenance='Cliff numbers read from course25_sarsa_q.py outputs; mud runs re-run here.')
    (OUT / 'results.json').write_text(json.dumps(res, ensure_ascii=False, indent=1) + '\n')
    m = res['mud']
    print(json.dumps(dict(fonts=ok, route=res['cliff_paths'], cliff={k: res['cliff_results'][k] for k in ['sarsa', 'qlearning']},
                          S4=(m['S4_final_mean'], m['S4_final_se'], m['S4_final_sd'], m['S4_true']),
                          S7=(m['S7_final_mean'], m['S7_final_se'], m['S7_true'], m['S7_greedy_left_runs'])),
                     ensure_ascii=False, indent=1))


if __name__ == '__main__':
    main()
