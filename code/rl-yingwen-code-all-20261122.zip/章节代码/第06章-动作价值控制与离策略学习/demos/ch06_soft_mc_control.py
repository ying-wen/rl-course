"""第 6 章 6.5 节算例（classic-v10-control-estimates）：泥地上首次访问 ε-软 MC 控制（算法 6.4）。
ε=.2，m=4，每回合从 S7 出发，Q 初值 0，并列时取 π_0 的动作，样本均值更新，种子 7。
输出 assets/classic-v10/mc-soft-control-estimates.dat（列 n up left nup nleft），并打印 ε-软最优值与 100 个种子的稳健性。
11-21 r1121-111555 新增。"""
import sys, random, math, os
HERE=os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0,HERE)
from mud_world import STATES, ACTIONS, OLD, outcomes, GAMMA
A=list(ACTIONS); EPS=.2; m=len(A)
def greedy(Q,s):
    best=max(Q[s,a] for a in A)
    tied=[a for a in A if abs(Q[s,a]-best)<1e-15]
    return OLD[s] if OLD[s] in tied else tied[0]
def probs(g,s):
    return {a:EPS/m+(1-EPS)*(a==g[s]) for a in A}
def evalq(g):
    v=dict.fromkeys(STATES,0.0)
    for _ in range(20000):
        nv={}
        for s in STATES:
            pr=probs(g,s)
            nv[s]=sum(pr[a]*sum(p*(r+GAMMA*(0 if d else v[n])) for p,n,r,d in outcomes(s,a)) for a in A)
        e=max(abs(nv[s]-v[s]) for s in STATES); v=nv
        if e<1e-14: break
    q={(s,a):sum(p*(r+GAMMA*(0 if d else v[n])) for p,n,r,d in outcomes(s,a)) for s in STATES for a in A}
    return v,q
# initial eps-soft version of OLD and eps-soft optimum
g0=dict(OLD); v0,q0=evalq(g0)
g=dict(OLD)
for it in range(50):
    v,q=evalq(g)
    ng={s:max(A,key=lambda a:(q[s,a], a==g[s])) for s in STATES}
    if ng==g: break
    g=ng
print('init eps-soft pi0: v(S7)=%.6f q(S7,up)=%.6f q(S7,left)=%.6f'%(v0['S7'],q0['S7','up'],q0['S7','left']))
print('eps-soft optimum:',g); print(' v(S7)=%.6f q(S7,up)=%.6f q(S7,left)=%.6f v(S4)=%.6f'%(v['S7'],q['S7','up'],q['S7','left'],v['S4']))
def step(s,a,rng):
    ch=outcomes(s,a); u=rng.random(); mass=0
    for it in ch:
        mass+=it[0]
        if u<mass: return it
    return ch[-1]
def run(seed,B=2000,checks=None):
    rng=random.Random(seed)
    Q={(s,a):0.0 for s in STATES for a in A}; N={k:0 for k in Q}
    pol={s:greedy(Q,s) for s in STATES}
    out=[]; steps=0
    for j in range(1,B+1):
        s='S7'; traj=[]
        while True:
            pr=probs(pol,s); u=rng.random(); acc=0
            for a in A:
                acc+=pr[a]
                if u<acc: break
            p,n,r,d=step(s,a,rng); traj.append((s,a,r)); steps+=1
            if d: break
            s=n
        G=0; rets=[0]*len(traj)
        for t in range(len(traj)-1,-1,-1):
            G=traj[t][2]+GAMMA*G; rets[t]=G
        seen=set()
        for t,(s,a,r) in enumerate(traj):
            if (s,a) in seen: continue
            seen.add((s,a)); N[s,a]+=1; Q[s,a]+=(rets[t]-Q[s,a])/N[s,a]
        pol={s:greedy(Q,s) for s in STATES}
        if checks and j in checks:
            out.append((j,Q['S7','up'],Q['S7','left'],N['S7','up'],N['S7','left'],pol['S7'],steps,dict(pol)))
    return out
checks={1,2,3,5,10,20,30,50,100,200,300,500,1000,2000}
res=run(7,2000,checks)
for row in res: print(row[0],'up=%.4f left=%.4f Nup=%d Nleft=%d greedyS7=%s steps=%d'%row[1:7])
print(res[-1][7])
# robustness: how many of 100 seeds have greedy S7 = left at 20,200,2000
cnt={20:0,200:0,2000:0}
for sd in range(100):
    for row in run(sd,2000,{20,200,2000}):
        cnt[row[0]]+= row[5]=='left'
print('fraction left over 100 seeds',cnt)
with open(os.path.join(HERE,'..','assets','classic-v10','mc-soft-control-estimates.dat'),'w') as f:
    f.write('n up left nup nleft\n')
    for row in res: f.write('%d %.6f %.6f %d %d\n'%row[:5])
