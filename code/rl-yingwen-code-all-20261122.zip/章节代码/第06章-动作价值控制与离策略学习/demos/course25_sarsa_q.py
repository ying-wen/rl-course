"""Sarsa versus Q-learning: the same environment, different target actions.

Run: python demos/course25_sarsa_q.py
The learner receives only step(s,a) samples. Exact policy evaluation below is
an independent diagnostic AFTER training; it is never used in an update.
Cliff task: Sutton & Barto, Example 6.6. These are new teaching runs, not the
book's reported data. Compare 500 episodes per seed; steps need not match.
"""
from pathlib import Path
import csv,json,sys
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
from plot_fonts import chinese_font
OUT=Path(__file__).resolve().parents[1]/'assets/course25-control';OUT.mkdir(parents=True,exist_ok=True)
START,GOAL=36,47
MOVES=((-1,0),(0,1),(1,0),(0,-1))  # up,right,down,left
FONT=chinese_font();TEAL='#087e8b';RED='#c65335';GOLD='#c4942a'

def step(s,a):
    row,col=divmod(s,12);dr,dc=MOVES[a]
    row=min(3,max(0,row+dr));col=min(11,max(0,col+dc));n=12*row+col
    if 37<=n<=46:return START,-100.,False
    return n,-1.,n==GOAL

def choose(q,s,rng,epsilon):
    if rng.random()<epsilon:return int(rng.integers(4))
    v=q[s];ties=np.flatnonzero(v==v.max())
    return int(ties[rng.integers(len(ties))])

def train(kind,seed,episodes=500,alpha=.5,epsilon=.1):
    rng=np.random.default_rng(seed);q=np.zeros((48,4));records=[];steps=0
    for ep in range(episodes):
        s=START;a=choose(q,s,rng,epsilon);ret=0.;falls=0
        for t in range(20000):
            n,r,done=step(s,a);steps+=1;ret+=r;falls+=int(r==-100)
            if done:target=r;next_a=None
            elif kind=='sarsa':
                # The sampled NEXT action is used in the target AND executed.
                next_a=choose(q,n,rng,epsilon);target=r+q[n,next_a]
            else:
                # Only the environment consequence is sampled; max is exact
                # over the current four entries, not over sampled behavior.
                next_a=None;target=r+q[n].max()
            q[s,a]+=alpha*(target-q[s,a])
            if done:break
            s=n
            a=next_a if kind=='sarsa' else choose(q,s,rng,epsilon)
        else:raise RuntimeError('Episode budget reached: no terminal tail fabricated')
        records.append(dict(method=kind,seed=seed,episode=ep+1,reward=ret,length=t+1,falls=falls,environment_steps=steps))
    return q,records

def model_from_coordinates():
    # Independently written reference, not a call to step().
    states=list(range(37));idx={s:i for i,s in enumerate(states)}
    P=np.zeros((37,4,37));R=np.zeros((37,4))
    for s in states:
        y,x=divmod(s,12)
        destinations=[(max(y-1,0),x),(y,min(x+1,11)),(min(y+1,3),x),(y,max(x-1,0))]
        for a,(ny,nx) in enumerate(destinations):
            fall=ny==3 and 1<=nx<=10;terminal=(ny,nx)==(3,11)
            R[s,a]=-100 if fall else -1
            if not terminal:P[s,a,START if fall else ny*12+nx]=1
    return states,P,R

def exact_return(q,epsilon,P,R):
    # Evaluation tie convention: uniform over all maximizing actions, exactly
    # as in training. Reachable support excludes irrelevant unvisited cycles.
    best=q[:37]==q[:37].max(axis=1,keepdims=True)
    pi=(1-epsilon)*best/best.sum(axis=1,keepdims=True)+epsilon/4
    p=np.einsum('sa,san->sn',pi,P);r=(pi*R).sum(axis=1)
    reach={START};front=[START]
    while front:
        s=front.pop()
        for n in np.flatnonzero(p[s]>0):
            if int(n) not in reach:reach.add(int(n));front.append(int(n))
    ix=sorted(reach);M=np.eye(len(ix))-p[np.ix_(ix,ix)]
    if max(abs(np.linalg.eigvals(p[np.ix_(ix,ix)])))>=1-1e-12:
        return float('-inf')
    v=np.linalg.solve(M,r[ix]);assert np.max(abs(M@v-r[ix]))<1e-8
    return float(v[ix.index(START)])

def finite_return(q,epsilon,P,R,horizon=200):
    """Expected reward up to min(T,H), plus P(T<=H); H is evaluation only."""
    best=q[:37]==q[:37].max(axis=1,keepdims=True)
    pi=(1-epsilon)*best/best.sum(axis=1,keepdims=True)+epsilon/4
    p=np.einsum('sa,san->sn',pi,P);r=(pi*R).sum(axis=1)
    v=np.zeros(37);survival=np.ones(37)
    for _ in range(horizon):v=r+p@v;survival=p@survival
    return float(v[START]),float(1-survival[START])

def save(fig,name):
    for ax in fig.axes:
        for label in [ax.title,ax.xaxis.label,ax.yaxis.label,*ax.get_xticklabels(),*ax.get_yticklabels(),*ax.texts]:label.set_fontproperties(FONT)
        if ax.get_legend():
            for t in ax.get_legend().get_texts():t.set_fontproperties(FONT)
    fig.savefig(OUT/(name+'.png'),dpi=190,bbox_inches='tight');fig.savefig(OUT/(name+'.pdf'),bbox_inches='tight');plt.close(fig)

def main():
    states,P,R=model_from_coordinates()
    for s in states:
        for a in range(4):
            n,r,done=step(s,a);assert R[s,a]==r
            assert P[s,a].sum()==(0 if done else 1)
            if not done:assert P[s,a,n]==1
    qs={};rows=[];evaluations=[];seeds=list(range(12))
    reuse='--reuse' in sys.argv
    saved=np.load(OUT/'learned-q.npz') if reuse else None
    if reuse:
        with (OUT/'episodes.csv').open() as f:
            rows=[{k:(v if k=='method' else float(v) if k=='reward' else int(v)) for k,v in row.items()} for row in csv.DictReader(f)]
    for kind in ['sarsa','qlearning']:
        qs[kind]=[]
        for seed in seeds:
            if reuse:q=saved[kind][seed]
            else:
                q,run=train(kind,seed);rows.extend(run)
            qs[kind].append(q)
            for eps in [0,.1]:
                infinite=exact_return(q,eps,P,R);value,arrival=finite_return(q,eps,P,R)
                evaluations.append(dict(method=kind,seed=seed,epsilon=eps,return_first200=value,goal_probability_200=arrival,episodic_return=infinite if np.isfinite(infinite) else None,proper=bool(np.isfinite(infinite))))
    with (OUT/'episodes.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    np.savez(OUT/'learned-q.npz',**{k:np.asarray(v) for k,v in qs.items()})
    with (OUT/'evaluation.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(evaluations[0]));w.writeheader();w.writerows(evaluations)
    fig,axes=plt.subplots(1,2,figsize=(10.4,3.2),gridspec_kw={'width_ratios':[1.35,1]},constrained_layout=True)
    for kind,color,label in [('sarsa',TEAL,'Sarsa'),('qlearning',RED,'Q-learning')]:
        returns=np.array([[r['reward'] for r in rows if r['method']==kind and r['seed']==seed] for seed in seeds])
        smooth=np.array([np.convolve(r,np.ones(20)/20,mode='valid') for r in returns]);m=smooth.mean(axis=0);se=smooth.std(axis=0,ddof=1)/np.sqrt(len(seeds));x=np.arange(20,501)
        axes[0].plot(x,m,color=color,label=label);axes[0].fill_between(x,m-se,m+se,color=color,alpha=.14)
        for j,eps in enumerate([0,.1]):
            vals=[v['return_first200'] for v in evaluations if v['method']==kind and v['epsilon']==eps]
            assert all(np.isfinite(vals)),(kind,eps,'Finite budget value must exist')
            offset=-.16 if kind=='sarsa' else .16
            axes[1].bar(j+offset,np.mean(vals),width=.29,color=color,label=label if j==0 else None)
            axes[1].errorbar(j+offset,np.mean(vals),yerr=np.std(vals,ddof=1)/np.sqrt(len(vals)),color='#182e38',capsize=3)
            axes[1].text(j+offset,np.mean(vals)-3,f'{np.mean(vals):.1f}',ha='center',va='top',fontsize=10)
    axes[0].set(xlabel='训练回合（每种方法独立运行 12 次）',ylabel='每回合奖励之和',ylim=(-150,0),title='学习中：始终保留 10% 探索');axes[0].legend(frameon=False);axes[1].legend(frameon=False,loc='lower left')
    axes[1].set(xticks=[0,1],xticklabels=['只走贪心','保留 10% 探索'],ylabel='前 200 步内的期望累积奖励',title='两种方法各自学到的路线（各用自己的 Q 表）',ylim=(-95,0))
    save(fig,'performance')
    fig,axes=plt.subplots(2,1,figsize=(10.2,4.0),constrained_layout=True)
    paths={}
    for ax,kind,color in zip(axes,['sarsa','qlearning'],[TEAL,RED]):
        q=qs[kind][0];s=START;path=[s]
        for t in range(200):
            a=int(np.argmax(q[s]));s,r,done=step(s,a);path.append(s)
            if done:break
        else:raise RuntimeError('Seed 0 greedy path did not terminate')
        paths[kind]=path
        for y in range(4):
            for x in range(12):
                cliff=y==3 and 1<=x<=10
                ax.add_patch(Rectangle((x,3-y),1,1,facecolor='#f7ddd4' if cliff else '#f3f5f5',edgecolor='#a9b6bb',lw=.6))
        xx=[s%12+.5 for s in path];yy=[3-s//12+.5 for s in path]
        ax.plot(xx,yy,color=color,lw=2.5)
        for j in range(len(path)-1):ax.annotate('',xy=(xx[j+1],yy[j+1]),xytext=(xx[j],yy[j]),arrowprops=dict(arrowstyle='->',color=color,lw=1.2))
        ax.text(.5,.5,'S',ha='center',va='center');ax.text(11.5,.5,'G',ha='center',va='center');ax.text(6,.5,'悬崖：−100，返回 S',ha='center',va='center',color=RED)
        ax.set(xlim=(0,12),ylim=(0,4),aspect='equal',title=f'{"Sarsa" if kind=="sarsa" else "Q-learning"}：一次运行学得Q表的贪心路线（{len(path)-1}步）');ax.axis('off')
    save(fig,'learned-paths')
    # Conditional expectation identity, including current-action selection.
    qnext=np.array([.5,.1,.2,.7]);b=np.array([.05,.05,.05,.85]);gamma=.9
    sarsa_mean=gamma*float(b@qnext);q_target=gamma*qnext.max()
    assert abs(sarsa_mean-.5715)<1e-12 and abs(q_target-.63)<1e-12
    report=dict(task='4x12 cliff; -1 each transition, -100 and reset-to-start on cliff, only goal terminates',gamma=1,alpha=.5,epsilon=.1,seeds=seeds,episodes=500,training='real transition samples only; no model used in target',evaluation='frozen Q; first min(T,200) rewards and P(T<=200) by exact finite recurrence; full episodic return from reachable-policy linear system also saved; uniform greedy ties',curves='20-episode moving average, mean +/- one standard error across seeds',path_convention='seed0 fixed before training; fixed first-action greedy tie-break',budgets={k:sum(r['length'] for r in rows if r['method']==k) for k in qs},mean_final100_returns={k:float(np.mean([r['reward'] for r in rows if r['method']==k and r['episode']>400])) for k in qs},evaluation_means={k:{str(e):float(np.mean([v['return_first200'] for v in evaluations if v['method']==k and v['epsilon']==e])) for e in [0,.1]} for k in qs},nonterminating_greedy_seeds={k:[v['seed'] for v in evaluations if v['method']==k and v['epsilon']==0 and not v['proper']] for k in qs},goal_probability200={k:{str(e):float(np.mean([v['goal_probability_200'] for v in evaluations if v['method']==k and v['epsilon']==e])) for e in [0,.1]} for k in qs},paths=paths,checks={'independent_model_matches_all_transitions':True,'sarsa_expected_target':sarsa_mean,'q_target':q_target},provenance='New teaching experiment based on Sutton and Barto Example 6.6; not original figure data')
    (OUT/'results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:report[k] for k in ['mean_final100_returns','evaluation_means','budgets']},ensure_ascii=False))
if __name__=='__main__':main()
