# 第 6 章　动作价值控制与离策略学习：程序

本目录可以单独运行：在本目录下执行下面的命令即可，结果写回本目录的 `assets/`。目录由 `rl-course/tools/export_chapter_code.py` 从课程目录生成，改程序请改课程目录里的原件，再重新导出。

## 准备

```sh
python3 -m pip install -r requirements.txt
```

需要的第三方包：matplotlib、numpy。复现附录要求 Python 3.10 或更新版本；核验时用的版本见下表。

## 运行（与复现附录相同）

```sh
python3 demos/course25_sarsa_q.py
python3 demos/classic_v6_lab.py
python3 demos/classic_v6_lab.py --initial-q 0 --control-alpha .1 --output /tmp/v6-classic-zero
python3 demos/classic_v8_foundations.py
python3 demos/classic_v10_derivations.py
python3 demos/ch06_soft_mc_control.py
python3 demos/ch06_double_q_runs.py   # 写 assets/ch06-double
python3 demos/control_record.py
python3 demos/classic_foundations.py
python3 demos/v17_classic.py
python3 demos/v18_classic.py
python3 demos/ch06_control_figs.py
```

## 本目录的程序

| 程序 | 说明 | 核验 |
|---|---|---|
| `demos/classic_v8_foundations.py` | Reproducible calculations for chapters 2--8 (standard library only). | 通过（0 秒） |
| `demos/classic_foundations.py` | Small exact checks for chapters 2--8; standard library, no training. | 通过（0 秒） |
| `demos/control_record.py` | 泥地第 6、7 章：运行 python demos/control_record.py（只用标准库）。 | 通过（0 秒） |
| `demos/course25_sarsa_q.py` | Sarsa versus Q-learning: the same environment, different target actions. | 通过（3 秒） |
| `demos/v17_classic.py` | Small exact checks and instructional figures for chapters 3--6. | 通过（2 秒） |
| `demos/ch06_control_figs.py` | Chapter 6.4 figures redrawn in the course fonts (11-21 review request r1121-111555). | 通过（8 秒） |
| `demos/classic_v6_lab.py` | Visible learning states for chapters 2--8. Local, small, reproducible runs. | 通过（2 秒） |
| `demos/classic_v10_derivations.py` | Reproducible chapter 2–8 derivations on the unchanged mud task. | 通过（0 秒） |
| `demos/v18_classic.py` | Exact teaching objects for v18 chapters 2--6. No training. | 通过（2 秒） |
| `demos/ch06_soft_mc_control.py` | 第 6 章 6.5 节算例（classic-v10-control-estimates）：泥地上首次访问 ε-软 MC 控制（算法 6.4）。 | 通过（6 秒） |
| `demos/ch06_double_q_runs.py` | Chapter 6, Double Q-learning experiments (11-21 review request r1121-111555, p349). | 通过（12 秒） |
| `demos/classic_v13_mechanisms.py` | Exact teaching calculations for MDPs, TD, traces, and model-based planning. | 通过（2 秒） |
| `demos/mud_world.py` | The lecture's 3 x 3 mud maze, with an exact model and sampled predictions. | 通过（0 秒） |
| `demos/td_control.py` | Auditable numbers and small runs for chapter 03 (Python standard library). | 通过（2 秒） |
| `demos/classic_v9_checks.py` | Independent checks for v9 chapters 2–8; no training or old-output writes. | 通过（0 秒） |

被上面程序 import 的本课模块：`demos/plot_fonts.py`。

表中后 4 个程序复现附录本章一节没有列出，来自课件、阅读稿、CODE-MAP 或文件名前缀（第三部分另含学习器阶梯）。

## 复现附录本章一节

本章的模拟结果有五组：泥地上的 Q-learning 与 Double Q-learning，悬崖任务上 Sarsa 与 Q-learning 的比较，6.5 节有限样本下首动作的 MC 估计，6.5 节首次访问的 ε-软 MC 控制，以及 6.7 节按 Sutton 与 Barto 例 6.7 的设定重做的最大化偏差实验。软策略价值、一步目标和轨迹重要性采样的数值来自精确计算程序，不含随机性；6.7 节同一后继状态上的两表快照是手设数值的示意图。

悬崖任务与例 6.7 的设定依据 Sutton 与 Barto 例 6.6、例 6.7，结果由本课重新运行得到，原书图的数据不在表中。

| 位置 | 结果 | 设置 | 程序 | 数据与输出 |
|---|---|---|---|---|
| 6.2 节“软策略的上限”（课件 `ch06-bridge-soft-cost`）；6.4 节“Q-learning 的价值估计与贪心策略” | $\varepsilon=.2$ 时最好的软策略价值 .858、.977、.754、.482、.663、.583、.514；同一组箭头保留探索时 S7 由 .590 降到 .51366 | 精确模型下的策略价值方程，每格以 .85 走箭头、其余三个方向各 .05，$\gamma=.9$ | `demos/classic_v8_foundations.py` | `assets/v8-classic/results.json`（`soft_policy_values`） |
| 6.3 节“Sarsa、Expected Sarsa 与 Q-learning 的目标” | 相同转移与当前 Q 下三种目标 .45、.5715、.63；练习中 $\varepsilon=.4$ 的 Expected Sarsa 目标 | 给定四个动作价值与行为概率的有限算术；目标图是课件 TikZ 页面的截图 | `demos/classic_foundations.py` | `demos/classic-foundations-results.json`、`assets/v5/classic/one-step-control-targets.png` |
| 6.3 节“同一段经验中的一步目标与完整回报”（课件 `course25-control-no-is`、`course26-control-exploration`） | Sarsa .45、Expected Sarsa（评价 $\pi$）.612、Q-learning .63、普通轨迹重要性采样 1.8，轨迹权重 2 | 冻结 Q 表 (.5,.1,.2,.7)，行为 $b=(.05,.05,.05,.85)$，目标 $\pi=(.1,0,0,.9)$；转移概率与奖励取自 `mud_world.outcomes`，分数精确运算 | `demos/control_record.py` | 只在终端输出，不写文件 |
| 6.4 节（课件 `course25-control-cliff-results`、`course25-sarsa-algorithm`、`learning-21`） | 最后 100 回合平均奖励 Sarsa −25.78、Q-learning −47.75；冻结 Q-learning 表纯贪心 −13.0、保留探索 −50.55；两次 Sarsa 运行纯贪心时循环；种子 0 的贪心路线经过临崖格 Q-learning 10 个、Sarsa 1 个 | 本课的模拟：4×12 悬崖，每步 −1，跌崖 −100 并回起点，$\gamma=1$，$\alpha=.5$，$\varepsilon=.1$，每次运行 500 回合，独立重复 12 次（种子 0–11）；冻结表的评价用精确有限递推计前 200 步，曲线为 20 回合滑动平均与一个标准误 | `demos/course25_sarsa_q.py` | `assets/course25-control/results.json`、`assets/course25-control/performance.png`、`assets/course25-control/learned-paths.png`、`assets/course25-control/episodes.csv`、`assets/course25-control/evaluation.csv`、`assets/course25-control/learned-q.npz` |
| 6.4 节“Q-learning 的价值估计与贪心策略”（课件 `v17-classic-control-feedback`） | 给定 Q 快照的一次可能更新及下回合的动作变化 | 单步教学算例，精确模型，无训练 | `demos/v17_classic.py` | `assets/v17-classic/control-feedback.png`、`assets/v17-classic/checks.json` |
| 6.4 节“泥地 Q-learning”（课件 `classic-v6-q-policies`，现用图） | 100 次独立运行在 100、1000、20000 个真实步后的 $\max_aQ$ 均值与多数贪心箭头；两万步时 S4 为 .539±.007（标准误，标准差 .067），真值 .526；S7 在 100 次中都向左、取 .590；种子 7 复现下一行的单次运行（S4 .549） | 本课的模拟：沿用 demos/classic_v6_lab.py 的控制循环（初值 1，$\alpha=.05$，$\varepsilon=.2$，从 S7 重置，20000 个真实转移），种子 0–99 | `demos/ch06_control_figs.py` | `assets/ch06-control/mud-q-runs.pdf`、`assets/ch06-control/results.json` |
| 6.4 节（课件 `classic-v13-cliff` 之后的 `course25-control-cliff-paths`、`course25-control-cliff-results`、`v17-classic-control-feedback`，现用图） | 悬崖贪心路线、训练曲线与冻结回报、单步反馈算例按本课字体重画 | 悬崖两图读自 demos/course25_sarsa_q.py 的输出（assets/course25-control/），不重训；单步反馈算例在程序内重算（目标 .36，更新后 .43） | `demos/ch06_control_figs.py` | `assets/ch06-control/` 下的 cliff-paths.pdf、cliff-results.pdf、control-feedback.pdf |
| 6.4 节“Q-learning 的价值估计与贪心策略”（课件 `classic-v6-q-policies` 的旧图，单次运行） | 100、1000、20000 个真实步后的最大 Q 与贪心箭头，最后 S7 向左绕行；冻结贪心策略的精确评价 .59049；零初值、步长 .1 时两万步后仍经泥地 | 本课的模拟：从 S7 重置，Q-learning，初值 1，$\alpha=.05$，$\varepsilon=.2$，20000 个真实转移，单次运行，随机数种子 7；另一组初值 0、$\alpha=.1$ | `demos/classic_v6_lab.py` | `assets/v6-classic/control-policies.png`、`assets/v6-classic/results.json`、`assets/v6-classic/zero-init-results.json`、`assets/v6-classic/control-policies-zero.png` |
| 6.5 节“有限样本的动作价值与改进保证”；补充阅读“有限样本下的改进保证”（课件 `classic-v10-control-margin`） | 每个首动作 20、200、2000 回合后的估计，2000 回合时向上 .471000、向左 .590490；观察差距 .157677、.135820、.119490；两个误差半径之和 .740313、.234108、.074031 | 本课的模拟：可重置到 S7，分别指定首动作向上、向左，之后固定旧策略，各收集独立完整回合，随机数种子 7；Hoeffding 界的同时失败概率 .05 | `demos/classic_v10_derivations.py` | `assets/classic-v10/mc-action-estimates.dat`、`assets/classic-v10/derivations.json` |
| 6.6 节“轨迹重要性采样：泥地算例” | 按比率加权后期望由 .532087 变为 .497045；目标策略的线性方程解得同一数值 | 行为在 S7 上、左各 .5，目标 .8、.2，之后旧策略；轨迹枚举与线性方程两种精确计算 | `demos/classic_v10_derivations.py` | `assets/classic-v10/derivations.json`（`mud_IS`） |
| 6.7 节 | 同一后继状态上的两表快照：A 选上，B 评价上的 .3 | 手设数值的示意图 | `demos/v18_classic.py` | `assets/v18-classic/double-tables.png`、`assets/v18-classic/checks.json` |
| 6.5 节（课件 `classic-v10-control-estimates`） | S7 的贪心动作在第 10 回合由上改为左，之后不再改回；2000 回合中选上 133 次；ε-软策略下的精确动作价值：上 .434、左 .524；100 个种子中 S7 选左的比例，第 20 回合 79%、第 200 回合 94%、第 2000 回合 100% | 本课的模拟：泥地上首次访问的 ε-软 MC 控制（算法 6.4），$\varepsilon=.2$，$m=4$，每回合从 S7 出发，$Q_0=0$，并列时取 $\pi_0$ 的动作，样本均值更新，单次运行种子 7 | `demos/ch06_soft_mc_control.py` | `assets/classic-v10/mc-soft-control-estimates.dat`（列 n up left nup nleft） |
| 6.7 节（课件 `classic-v8-double-policy`） | 例 6.7：第 1–10 回合选左的比例 Q-learning .70、Double Q-learning .49；峰值 Q-learning .95（第 21 回合）、Double Q-learning .52（第 5 回合）；最后 50 回合 .117 与 .064（最优 .05）。泥地：Q-learning 的 S4 均值 .528（真值 .526），标准误约 .006；Double Q-learning 的 S4 均值 .521；两者在 100 次运行中 S7 都选左 | 本课的模拟。例 6.7：B 处 10 个动作，奖励 $N(-.1,1)$，$\varepsilon=.1$，$\alpha=.1$，$\gamma=1$，$Q_0=0$，每次运行 300 回合，独立重复 2000 次，种子 61、62。泥地：独立重复 100 次（种子 1000–1099），每次 20000 步，$\alpha=.05$，$\varepsilon=.2$，$\gamma=.9$，$Q_0=1$ | `demos/ch06_double_q_runs.py` | `assets/ch06-double/example67.pdf`、`assets/ch06-double/results.json` |

外部代码（出处）：无。悬崖任务图按 Sutton 与 Barto 例 6.6 用 TikZ 重画，路线为示意；Sarsa 回溯图仿 Silver 第 5 讲重画；Expected Sarsa 的算法框参照 Sutton 与 Barto §6.6。

运行：
```sh
python3 demos/course25_sarsa_q.py
python3 demos/classic_v6_lab.py
python3 demos/classic_v6_lab.py --initial-q 0 --control-alpha .1 --output /tmp/v6-classic-zero
python3 demos/classic_v8_foundations.py
python3 demos/classic_v10_derivations.py
python3 demos/ch06_soft_mc_control.py
python3 demos/ch06_double_q_runs.py   # 写 assets/ch06-double
python3 demos/control_record.py
python3 demos/classic_foundations.py
python3 demos/v17_classic.py
python3 demos/v18_classic.py
python3 demos/ch06_control_figs.py
```

## 参考数据

`assets/`（以及 `demos/NN-results/`）下复制了 27 个数据文件（json、csv 等），即课程目前使用的结果；图片没有复制，运行程序会重新画出。重跑会覆盖这些文件，可以先另存一份再对照。
