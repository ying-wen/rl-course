"""One prediction, three sources of information (Chapters 3–5).
Run: python3 demos/mud_prediction_lens.py [--old 0.5] [--alpha 0.2]
The environment and policy are imported from the course mud task. The MC and TD
functions below consume observations, never the transition kernel.
"""
import argparse
from math import isclose
from mud_world import OLD, GAMMA, outcomes

# One possible recorded episode: the first visit to S4 is at t=1.
# Format: source, next reward, successor. Two failed attempts, then success.
EPISODE = (("S7", 0, "S4"), ("S4", 0, "S4"), ("S4", 0, "S4"), ("S4", 1, "G"))

def target_td(transition, table):
    _, r, successor = transition
    return r + GAMMA * (0 if successor == "G" else table[successor])

def target_mc(episode, visit):
    g = 0
    for _, reward, _ in reversed(episode[visit:]):
        g = reward + GAMMA * g
    return g

def target_dp(state, table):
    # π0 is deterministic here; for a stochastic policy also average over actions.
    return sum(prob * target_td((state, r, successor), table)
               for prob, successor, r, _ in outcomes(state, OLD[state]))

def report(old=0.5, alpha=0.2):
    table = {"S4": old}
    observed = EPISODE[1]
    dp = target_dp("S4", table)
    # Solve the true value independently of the displayed old estimate.
    transitions = outcomes("S4", OLD["S4"])
    stay = sum(prob for prob, nxt, _, _ in transitions if nxt == "S4")
    reward = sum(prob*r for prob, _, r, _ in transitions)
    true = reward/(1-GAMMA*stay)
    td = target_td(observed, table)
    mc = target_mc(EPISODE, 1)
    return dict(v_pi=true, dp_target=dp, dp_synchronous_write=dp,
                td_target=td, td_write=old+alpha*(td-old),
                mc_first_visit_target=mc, mc_constant_step_write=old+alpha*(mc-old))

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--old", type=float, default=.5)
    parser.add_argument("--alpha", type=float, default=.2)
    args = parser.parse_args()
    if not 0 < args.alpha <= 1: parser.error("alpha must be in (0, 1]")
    # Check terminal handling, the entire old table at DP fixed point and
    # the exact conditional expectation of TD over *both* possible outcomes.
    baseline = report()
    assert isclose(baseline["v_pi"],10/19)
    assert isclose(target_td(EPISODE[-1], {"G":999}),1)
    assert isclose(target_dp("S4", {"S4":10/19}),10/19)
    assert isclose(baseline["dp_target"], .9*.45 + .1*1)
    assert isclose(baseline["mc_first_visit_target"], .81)
    for name, value in report(args.old, args.alpha).items(): print(f"{name:24} {value:.6f}")
