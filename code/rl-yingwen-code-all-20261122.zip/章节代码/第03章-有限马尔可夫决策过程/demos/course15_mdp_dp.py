"""Finite MDP and exact-model DP on the course's shared mud maze.

Run from any directory:
  python demos/course15_mdp_dp.py
Requires numpy and matplotlib. Outputs PDF/PNG, CSV and JSON beside the course.
The algorithm may query every exact outcome. Sampled episodes illustrate the
resulting behaviour; they are not used to calculate DP targets.
"""
from __future__ import annotations
import argparse, csv, itertools, json, random
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
from mud_world import STATES, ACTIONS, POSITIONS, OLD, NEW, GAMMA, outcomes, rollout

ROOT = Path(__file__).resolve().parents[1]
INDEX = {s: i for i,s in enumerate(STATES)}
ACTS = tuple(ACTIONS)
ARROWS = {'up':(0,.31), 'down':(0,-.31), 'left':(-.31,0), 'right':(.31,0)}
INK, TEAL, RED, GOLD = '#182E38', '#087E8B', '#C65335', '#C4942A'
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':15,'axes.spines.top':False,'axes.spines.right':False,'text.color':INK,'axes.labelcolor':INK,'xtick.color':INK,'ytick.color':INK,'pdf.fonttype':42})


def backup(v, s, a):
    return sum(p*(r+GAMMA*(0 if done else v[INDEX[n]])) for p,n,r,done in outcomes(s,a))


def action_values(v):
    return np.array([[backup(v,s,a) for a in ACTS] for s in STATES])


def evaluate(policy, tol=1e-12, initial=None):
    v=np.zeros(len(STATES)) if initial is None else np.array(initial,copy=True)
    history=[v.copy()]
    for k in range(10000):
        new=np.array([backup(v,s,policy[s]) for s in STATES])
        history.append(new.copy())
        # All targets were calculated from v, before this assignment.
        delta=np.max(np.abs(new-v)); v=new
        if delta < tol: return v,np.array(history)
    raise RuntimeError('evaluation did not converge')


def greedy(v, old=None):
    q=action_values(v); result={}
    for i,s in enumerate(STATES):
        best=np.max(q[i]); tied=[a for j,a in enumerate(ACTS) if best-q[i,j] <= 1e-12]
        result[s]=old[s] if old and old[s] in tied else tied[0]
    return result


def policy_iteration(initial):
    policy=initial.copy(); v=np.zeros(len(STATES)); stages=[]
    for _ in range(100):
        v,h=evaluate(policy,initial=v)
        improved=greedy(v,policy)
        stages.append({'policy':policy.copy(),'value':v.tolist(),'evaluation_sweeps':len(h)-1,
                       'changed_states':[s for s in STATES if policy[s]!=improved[s]]})
        if improved==policy: return policy,v,stages
        policy=improved
    raise RuntimeError('policy iteration did not terminate')


def value_iteration(tol=1e-12):
    v=np.zeros(len(STATES)); history=[v.copy()]
    for _ in range(10000):
        new=action_values(v).max(axis=1); history.append(new.copy())
        delta=np.max(np.abs(new-v)); v=new
        if delta < tol:return v,greedy(v),np.array(history)
    raise RuntimeError('value iteration did not converge')


def independent_arrays():
    """Second model construction from coordinates, without calling outcomes/backup."""
    at={xy:s for s,xy in POSITIONS.items()}; p=np.zeros((7,4,7)); r=np.zeros((7,4))
    for i,s in enumerate(STATES):
        x,y=POSITIONS[s]
        for j,(a,(dx,dy)) in enumerate(ACTIONS.items()):
            n=at.get((x+dx,y+dy),s); success=.1 if s=='S4' else 1.
            p[i,j,i]+=1-success
            if n=='G': r[i,j]=success
            else:p[i,j,INDEX[n]]+=success
    return p,r


def matrix_value(policy,p,r):
    choices=np.array([ACTS.index(policy[s]) for s in STATES]); ix=np.arange(7)
    return np.linalg.solve(np.eye(7)-GAMMA*p[ix,choices],r[ix,choices])


def map_ax(ax, value=None, policy=None, title='', marks=None):
    for y in range(3):
        for x in range(3):
            s=next((s for s,xy in POSITIONS.items() if xy==(x,y)),None)
            yy=2-y
            fill=INK if not s else '#F6E5CA' if s=='S4' else '#EAF4F3'
            ax.add_patch(Rectangle((x,yy),1,1,facecolor=fill,edgecolor='#92A3A9',lw=1))
            if not s:continue
            ax.text(x+.08,yy+.83,s,fontsize=12,color=INK)
            if s=='G':ax.text(x+.5,yy+.45,'terminal\nv(G)=0',ha='center',va='center',fontsize=11);continue
            if value is not None:ax.text(x+.5,yy+.52,f'{value[INDEX[s]]:.3f}',ha='center',fontsize=15,fontweight='bold')
            if policy:
                dx,dy=ARROWS[policy[s]]; cy=yy+.2 if value is not None else yy+.45
                ax.arrow(x+.5-dx/2,cy-dy/2,dx,dy,head_width=.10,head_length=.08,length_includes_head=True,color=RED if marks and s in marks else TEAL,width=.018)
    ax.set(xlim=(-.03,3.03),ylim=(-.03,3.03),aspect='equal');ax.axis('off');ax.set_title(title,fontsize=16,pad=9)


def save(fig,out,name):
    fig.savefig(out/(name+'.pdf'),bbox_inches='tight',facecolor='white')
    fig.savefig(out/(name+'.png'),dpi=180,bbox_inches='tight',facecolor='white');plt.close(fig)


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=ROOT/'assets/course15-mdp-dp');args=ap.parse_args();out=args.output;out.mkdir(parents=True,exist_ok=True)
    old,hist=evaluate(OLD); new,_=evaluate(NEW)
    opt,pol,vi=value_iteration(); pi_pol,pi_v,stages=policy_iteration(OLD)
    _,_,allup=policy_iteration({s:'up' for s in STATES})
    p,r=independent_arrays()
    assert np.max(np.abs(old-matrix_value(OLD,p,r)))<1e-10
    assert np.max(np.abs(new-matrix_value(NEW,p,r)))<1e-10
    assert abs(old[INDEX['S4']]-10/19)<1e-10 and abs(old[INDEX['S7']]-9/19)<1e-10
    assert abs(new[INDEX['S7']]-GAMMA**5)<1e-10
    # Exhaustive comparison of all 4^7 deterministic stationary policies.
    enum_best=np.full(7,-np.inf)
    for choices in itertools.product(ACTS,repeat=7):
        val=matrix_value(dict(zip(STATES,choices)),p,r);enum_best=np.maximum(enum_best,val)
    assert np.max(np.abs(opt-enum_best))<1e-10
    assert np.max(np.abs(pi_v-opt))<1e-10
    probe=np.random.default_rng(17).normal(size=7)
    model_check=max(abs(backup(probe,ss,aa)-(r[i,j]+GAMMA*p[i,j]@probe)) for i,ss in enumerate(STATES) for j,aa in enumerate(ACTS))
    assert model_check<1e-12
    optimal_residual=float(np.max(np.abs(action_values(opt).max(axis=1)-opt)))
    assert optimal_residual<1e-11
    # Finite trajectory tree: expand each branch explicitly (no Bellman memoization).
    def enumerate_return(s,h):
        if h==0 or s=='G':return 0.
        x,y=POSITIONS[s];dx,dy=ACTIONS[OLD[s]];n={xy:s for s,xy in POSITIONS.items()}.get((x+dx,y+dy),s)
        prob=.1 if s=='S4' else 1.
        return prob*(float(n=='G')+GAMMA*enumerate_return(n,h-1))+(1-prob)*GAMMA*enumerate_return(s,h-1) if prob<1 else float(n=='G')+GAMMA*enumerate_return(n,h-1)
    enum_h={h:enumerate_return('S7',h) for h in range(1,13)}
    assert max(abs(hist[h,INDEX['S7']]-v) for h,v in enum_h.items())<1e-12
    exact_old=matrix_value(OLD,p,r)
    err=np.max(np.abs(hist-exact_old),axis=1);delta=np.max(np.abs(np.diff(hist,axis=0)),axis=1)
    assert np.all(err[1:]<=GAMMA*err[:-1]+1e-11)
    horizon=[]
    for h in [2,4,6,10]:
        q=action_values(vi[h-1]); horizon.append({'h':h,'up':q[INDEX['S7'],0],'left':q[INDEX['S7'],3],'best':ACTS[np.argmax(q[INDEX['S7']])]})
    # Actual environment draws, separate from every algorithm above.
    episodes=[]
    rng=random.Random(7)
    for e in range(1,7):
        tr=rollout(OLD,rng); episodes.append({'episode':e,'steps':len(tr),'return':GAMMA**(len(tr)-1),'trajectory':tr})
    report={'gamma':GAMMA,'state_order':STATES,'action_order':ACTS,'old_policy':OLD,'new_policy':NEW,'old_values':dict(zip(STATES,old)),
            'new_values':dict(zip(STATES,new)),'optimal_values':dict(zip(STATES,opt)),'optimal_policy':pol,'old_evaluation_sweeps':len(hist)-1,
            'value_iteration_sweeps':len(vi)-1,'policy_iteration':stages,'policy_iteration_all_up':allup,'finite_horizons':horizon,
            'sample_episodes':episodes,'checks':{'matrix_old_max_error':float(np.max(np.abs(old-matrix_value(OLD,p,r)))),
            'all_action_model_max_error':model_check,'optimal_bellman_residual':optimal_residual,'exhaustive_policy_count':4**7,'enumeration_optimal_max_error':float(np.max(np.abs(opt-enum_best))),
            'trajectory_tree_max_error':max(abs(hist[h,6]-v) for h,v in enum_h.items()),'contraction_pass':True},
            'executed_optimal_trajectory':rollout(pol,random.Random(19)),
            'permissions':'Exact model available to DP; sampled episodes are demonstrations only.'}
    assert len(report['executed_optimal_trajectory'])==6
    assert [row[0] for row in report['executed_optimal_trajectory']]==['S7','S6','S5','S3','S1','S2']
    (out/'results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    for filename,rows in [('evaluation.csv',[{'sweep':k,**dict(zip(STATES,v)),'error_inf':err[k]} for k,v in enumerate(hist)]),('value-iteration.csv',[{'sweep':k,**dict(zip(STATES,v))} for k,v in enumerate(vi)]),('finite-horizon.csv',horizon)]:
        with (out/filename).open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
    with (out/'sample-trajectories.csv').open('w',newline='') as f:
        w=csv.writer(f);w.writerow(['episode','t','state','action','reward','next_state','terminated'])
        for ep in episodes:
            for t,(s,re,n,d) in enumerate(ep['trajectory']):w.writerow([ep['episode'],t,s,OLD[s],re,n,d])
    fig,axs=plt.subplots(1,2,figsize=(8.3,3.5));map_ax(axs[0],policy=OLD,title='Try the mud');map_ax(axs[1],policy=NEW,title='Take the detour',marks=['S7']);save(fig,out,'routes')
    fig,ax=plt.subplots(figsize=(3.8,3.6));map_ax(ax,policy=OLD,title='');save(fig,out,'task')
    fig,axs=plt.subplots(1,2,figsize=(8.3,3.5));map_ax(axs[0],old,OLD,'Old policy');map_ax(axs[1],new,NEW,'Improved policy',marks=['S7']);save(fig,out,'policy-values')
    fig,axs=plt.subplots(1,3,figsize=(10.2,3.4))
    for ax,k in zip(axs,[1,2,5]):map_ax(ax,hist[k],OLD,f'k = {k}')
    save(fig,out,'evaluation-maps')
    fig,axs=plt.subplots(1,3,figsize=(10.2,3.4))
    for ax,k in zip(axs,[2,4,6]):map_ax(ax,vi[k],greedy(vi[k-1]),f'h = {k}')
    save(fig,out,'horizon-maps')
    fig,axs=plt.subplots(1,3,figsize=(10.2,3.4))
    for ax,k in zip(axs,[1,5,25]):map_ax(ax,vi[k],greedy(vi[k]),f'k = {k}')
    save(fig,out,'vi-maps')
    fig,axs=plt.subplots(1,len(allup),figsize=(3.25*len(allup),3.4))
    for i,(ax,stage) in enumerate(zip(np.atleast_1d(axs),allup)):map_ax(ax,np.array(stage['value']),stage['policy'],f'PI policy {i}',marks=stage['changed_states'])
    save(fig,out,'pi-allup')
    for part,subset in [('early',allup[:3]),('late',allup[3:])]:
        fig,axs=plt.subplots(1,3,figsize=(10.2,3.4))
        for j,(ax,stage) in enumerate(zip(axs,subset)):
            idx=j if part=='early' else j+3
            map_ax(ax,np.array(stage['value']),stage['policy'],f'PI policy {idx}',marks=stage['changed_states'])
        save(fig,out,'pi-'+part)
    fig,ax=plt.subplots(figsize=(7.9,3.9));ks=np.arange(min(80,len(hist)));ax.semilogy(ks,err[ks],label='Actual max error',lw=2.4,color=TEAL);ax.semilogy(ks,GAMMA**ks*err[0],label=r'$0.9^k\|V_0-v_\pi\|_\infty$',ls='--',color=GOLD,lw=2);ax.set(xlabel='Synchronous sweeps (no environment steps)',ylabel='Max absolute error');ax.grid(alpha=.2);ax.legend(fontsize=12);save(fig,out,'contraction')
    fig,axs=plt.subplots(1,2,figsize=(8.6,3.6));k=np.arange(18);axs[0].bar(k,.1*.9**k,color=TEAL);axs[0].set(xlabel='Failed mud attempts K before success',ylabel='Probability',title=r'$P(K=k)=0.1\,0.9^k$');axs[1].plot(k,GAMMA**(k+1),'o-',color=RED,label='S7 return via mud');axs[1].axhline(GAMMA**5,color=TEAL,label='Detour: 6 transitions');axs[1].set(xlabel='Failed mud attempts K',ylabel='Discounted return');axs[1].legend(fontsize=10);save(fig,out,'return-distribution')
    fig,ax=plt.subplots(figsize=(8.7,2.8));selected=[episodes[1],episodes[4],episodes[0]]
    for y,ep in enumerate(selected):
        seq=['S7']+[z[2] for z in ep['trajectory']]
        ax.plot(range(len(seq)),[y]*len(seq),color='#AFC3C8',lw=2)
        for t,s in enumerate(seq):
            ax.scatter(t,y,s=190,color=GOLD if s=='S4' else TEAL,zorder=3);ax.text(t,y,s,color='white',ha='center',va='center',fontsize=8,zorder=4)
        ax.text(len(seq)+.1,y,f"G0 = {ep['return']:.4f}",va='center',fontsize=12)
    ax.set(ylim=(-.6,2.6),xlim=(-1,max(e['steps'] for e in selected)+3.7),xlabel='Transition index t');ax.set_yticks(range(3),[f'Episode {e["episode"]}' for e in selected]);ax.spines[['left','top','right']].set_visible(False);save(fig,out,'sample-paths')
    print(json.dumps({'checks':report['checks'],'old_S7':old[6],'optimal_S7':opt[6],'evaluation_sweeps':len(hist)-1,'vi_sweeps':len(vi)-1,'pi_stages':len(stages),'allup_stages':len(allup),'horizons':horizon},indent=2))

if __name__=='__main__':main()
