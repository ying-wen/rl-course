"""第 3 章小结页（ch03-conclusion，审阅站第 181 页）复算：
q*(S7,左/上)、剩余步数 h 下 S7 的最优首动作、γ 阈值。模型取自 demos/mud_world.py。"""
import sys, json, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import mud_world as M

def brentq(f, a, b):
    for _ in range(200):
        m = (a + b) / 2
        if f(a) * f(m) <= 0: b = m
        else: a = m
    return (a + b) / 2

def q_inf(gamma):
    M.GAMMA = gamma
    v = dict.fromkeys(M.STATES, 0.0)
    for _ in range(20000):
        v = {s: max(M.backup(v, s, a) for a in M.ACTIONS) for s in M.STATES}
    return {a: M.backup(v, "S7", a) for a in M.ACTIONS}, v

out = {}
q, v = q_inf(.9)
out["q_star_S7"] = q
out["v_star"] = v
# 有限期：v_h(s) = max_a sum p [r + γ v_{h-1}(s')]，v_0 = 0
M.GAMMA = .9
v = dict.fromkeys(M.STATES, 0.0)
rows = []
for h in range(1, 11):
    qh = {a: M.backup(v, "S7", a) for a in M.ACTIONS}
    best = max(qh.values())
    rows.append({"h": h, "q_up": qh["up"], "q_left": qh["left"],
                 "argmax": [a for a in qh if abs(qh[a]-best) < 1e-12]})
    v = {s: max(M.backup(v, s, a) for a in M.ACTIONS) for s in M.STATES}
out["finite_horizon_S7"] = rows
f = lambda g: g**5 - g * (.1 / (1 - .9*g))   # 向左 γ^5 与向上 γ·v*(S4)
out["gamma_threshold"] = brentq(f, .5, .99)
q_thr, _ = q_inf(out["gamma_threshold"])
out["check_at_threshold"] = q_thr
print(json.dumps(out, indent=1, ensure_ascii=False))
