"""Small exact checks and instructional figures for chapters 3--6.

Run from any directory: python /absolute/path/to/demos/v17_classic.py
Dependencies: numpy, matplotlib. No training or source-asset replacement.
The inherited mud_world model is checked against an independent coordinate model.
"""
from pathlib import Path
import json
import math
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, Circle, FancyArrowPatch

from mud_world import STATES, ACTIONS, OLD, NEW, outcomes

OUT = Path(__file__).resolve().parents[1] / "assets" / "v17-classic"
INK, TEAL, RED, GOLD = "#182E38", "#087E8B", "#C65335", "#C4942A"
PALE, MUTED = "#EAF4F3", "#61757D"
plt.rcParams.update({"font.family": ["PingFang SC", "DejaVu Sans"],
                     "font.size": 16, "mathtext.fontset": "dejavusans",
                     "axes.spines.top": False, "axes.spines.right": False})
# PingFang SC is not always registered with Matplotlib; fall back to a system CJK file.
from matplotlib import font_manager as _fm
if not any(f.name == "PingFang SC" for f in _fm.fontManager.ttflist):
    for _font in ["/System/Library/Fonts/PingFang.ttc", "/System/Library/Fonts/STHeiti Light.ttc"]:
        if Path(_font).exists():
            _fm.fontManager.addfont(_font)
            plt.rcParams["font.family"] = [_fm.FontProperties(fname=_font).get_name(), "DejaVu Sans"]
            break


def save(fig, name):
    fig.savefig(OUT / f"{name}.pdf", bbox_inches="tight", facecolor="white")
    fig.savefig(OUT / f"{name}.png", dpi=170, bbox_inches="tight", facecolor="white")
    plt.close(fig)


def arrow(ax, start, end, label="", color=TEAL, dy=0, lw=2):
    ax.add_patch(FancyArrowPatch(start, end, arrowstyle="-|>",
                                mutation_scale=14, color=color, lw=lw))
    if label:
        ax.text((start[0]+end[0])/2, (start[1]+end[1])/2+dy, label,
                ha="center", va="center", color=color,
                bbox={"facecolor": "white", "edgecolor": "none", "pad": 1})


def node(ax, xy, label, color=INK, radius=.22):
    ax.add_patch(Circle(xy, radius, fc="white", ec=color, lw=1.6, zorder=4))
    ax.text(*xy, label, ha="center", va="center", color=color, zorder=5)


def grid(ax):
    pos = {"S1": (0, 2), "S2": (1, 2), "G": (2, 2), "S3": (0, 1),
           "S4": (2, 1), "S5": (0, 0), "S6": (1, 0), "S7": (2, 0)}
    for x in range(3):
        for y in range(3):
            ax.add_patch(Rectangle((x, y), 1, 1, ec=MUTED,
                                   fc=INK if (x,y)==(1,1) else PALE))
    for s,(x,y) in pos.items():
        if s == "S4": ax.add_patch(Rectangle((x,y),1,1,fc="#F2DEAF",ec=MUTED))
        if s == "G": ax.add_patch(Rectangle((x,y),1,1,fc="#B8E2D9",ec=MUTED))
        ax.text(x+.5,y+.67,s,ha="center",va="center")
    for dx,dy in [(0,.35),(.35,0),(0,-.35),(-.35,0)]:
        arrow(ax,(2.5,.32),(2.5+dx,.32+dy),lw=1.5)
    ax.text(1.5,3.25,r"$\mathcal{S}=\{\mathrm{S1},\ldots,\mathrm{S7},\mathrm{G}\}$",ha="center")
    ax.text(1.5,-.35,"动作：上、右、下、左",ha="center",color=TEAL)
    ax.set(xlim=(-.15,3.15),ylim=(-.6,3.55),aspect="equal")
    ax.axis("off")


def objects():
    fig,(ax,b)=plt.subplots(1,2,figsize=(12,3.6),gridspec_kw={"width_ratios":[1,1.6]})
    grid(ax)
    node(b,(.2,1.5),r"$\mathrm{S4}$")
    node(b,(2.4,2.35),r"$\mathrm{G}$")
    node(b,(2.4,.65),r"$\mathrm{S4}$")
    arrow(b,(.4,1.58),(2.15,2.25),r"$P(\mathrm{G}\mid \mathrm{S4},\uparrow)=.1$",dy=.32)
    arrow(b,(.4,1.4),(2.15,.75),r"$P(\mathrm{S4}\mid \mathrm{S4},\uparrow)=.9$",dy=-.32)
    b.text(2.85,2.35,"奖励 1",va="center",color=RED)
    b.text(2.85,.65,"奖励 0",va="center",color=RED)
    b.text(.1,-.05,r"$r(\mathrm{S4},\uparrow)=.1(1)+.9(0)=.1$",color=RED)
    b.text(.1,-.58,r"$\gamma=.9$；从 $R_{t+1}$ 起，权重为 $1,.9,.9^2,\ldots$",color=INK)
    b.set(xlim=(-.1,4.2),ylim=(-.8,2.9));b.axis("off")
    fig.subplots_adjust(wspace=.3)
    save(fig,"mdp-objects")


def probability_tree():
    fig,ax=plt.subplots(figsize=(12,3.5))
    root=(0,0); up=(2.8,1); down=(2.8,-1)
    node(ax,root,r"$S_4$")
    node(ax,up,r"$\uparrow$",TEAL);node(ax,down,r"$\downarrow$",TEAL)
    arrow(ax,(.2,.1),(2.6,.95),r"$\pi=.7$",dy=.23)
    arrow(ax,(.2,-.1),(2.6,-.95),r"$\pi=.3$",dy=-.23)
    leaves=[(up,1.65,"G",1,.1,.07,1), (up,.55,"S_4",0,.9,.63,.45),
            (down,-.55,"S_7",0,.1,.03,.36), (down,-1.65,"S_4",0,.9,.27,.45)]
    for start,y,state,r,p,mass,target in leaves:
        arrow(ax,(3,start[1]),(5.15,y),f"p={p:.1f}",dy=.17 if y>start[1] else -.17)
        node(ax,(5.4,y),f"${state}$")
        ax.text(6,y,f"奖励 {r}",va="center",color=RED)
        ax.text(7.65,y,f"{mass:.2f}",ha="center",va="center")
        ax.text(9.7,y,f"{target:g}",ha="center",va="center",color=TEAL)
    ax.text(7.65,2.2,r"分支权重 $\pi p$",ha="center")
    ax.text(9.7,2.2,r"$r+.9V(s')$",ha="center",color=TEAL)
    ax.text(2.8,2.2,"先选动作",ha="center",color=TEAL)
    ax.text(5.4,2.2,"再出后果",ha="center")
    ax.set(xlim=(-.5,10.6),ylim=(-2,2.5));ax.axis("off")
    save(fig,"probability-tree")


def control_feedback():
    fig,(ax,b)=plt.subplots(1,2,figsize=(12,3.5),gridspec_kw={"width_ratios":[1,1.15]})
    qbefore=[.5,.49];qafter=[.43,.49]
    ax.scatter(qbefore,[1,0],s=100,marker="o",color=MUTED,label="更新前")
    ax.scatter(qafter,[1,0],s=110,marker="|",linewidths=3,color=TEAL,label="更新后")
    arrow(ax,(.497,1),(.433,1),color=TEAL,lw=2)
    ax.set(yticks=[0,1],yticklabels=["左", "上"],xlim=(.4,.53),ylim=(-.5,1.5),xlabel=r"$Q(S_7,a)$")
    ax.text(.507,1,".50",va="center",fontsize=11);ax.text(.432,.78,".43",ha="center",fontsize=11)
    ax.text(.487,-.27,".49（未更新）",ha="center",fontsize=11)
    ax.legend(loc="upper center",ncol=2,fontsize=11,frameon=False)
    ax.grid(axis="x",alpha=.2)
    node(b,(.2,.8),r"$S_7$")
    node(b,(3,1.65),r"$S_4$")
    node(b,(3,-.05),r"$S_6$")
    arrow(b,(.4,.9),(2.8,1.6),"本次：上，奖励 0",dy=.25,color=MUTED)
    arrow(b,(.4,.7),(2.8,0),"下回合：贪心选左",dy=-.25,color=TEAL)
    b.text(3.45,1.65,r"$\max_cQ(S_4,c)=.4$",va="center",fontsize=12)
    b.text(.1,-.8,r"$Y=0+.9(.4)=.36$"+"，"+r"$\alpha=.5$",fontsize=13)
    b.text(.1,-1.35,r"$Q^+(S_7,\uparrow)=.5+.5(.36-.5)=.43$",fontsize=13)
    b.set(xlim=(-.15,5),ylim=(-1.6,2.1));b.axis("off")
    fig.subplots_adjust(wspace=.2)
    save(fig,"control-feedback")


def independent_model():
    # Geometry, noise and terminal reward constructed without outcomes/backup.
    xy={"S1":(0,0),"S2":(1,0),"G":(2,0),"S3":(0,1),"S4":(2,1),
        "S5":(0,2),"S6":(1,2),"S7":(2,2)}
    inv={v:k for k,v in xy.items()}
    delta={"up":(0,-1),"right":(1,0),"down":(0,1),"left":(-1,0)}
    table={}
    for s in STATES:
        for a,(dx,dy) in delta.items():
            x,y=xy[s]; t=inv.get((x+dx,y+dy),s)
            masses={}
            for p,t2 in ([(.9,s),(.1,t)] if s=="S4" else [(1,t)]):
                key=(t2,float(t2=="G"));masses[key]=masses.get(key,0)+p
            table[s,a]=masses
    return table


def check():
    tab=independent_model()
    for (s,a),d in tab.items():
        actual={}
        for p,t,r,done in outcomes(s,a):
            assert done==(t=="G")
            actual[t,r]=actual.get((t,r),0)+p
        assert actual==d and math.isclose(sum(d.values()),1)
    idx={s:i for i,s in enumerate(STATES)}
    def solve(policy):
        p=np.zeros((7,7));r=np.zeros(7)
        for s,i in idx.items():
            for (t,reward),mass in tab[s,policy[s]].items():
                r[i]+=mass*reward
                if t!="G":p[i,idx[t]]+=mass
        v=np.linalg.solve(np.eye(7)-.9*p,r)
        return dict(zip(STATES,v))
    old,new=solve(OLD),solve(NEW)
    trajectory_sum=sum(.1*.9**k*.9**(k+1) for k in range(1000))
    assert abs(old["S7"]-trajectory_sum)<1e-13
    assert abs(new["S7"]-.9**5)<1e-13
    masses=np.array([.07,.63,.03,.27]);targets=np.array([1,.45,.36,.45])
    tree=float(masses@targets)
    assert abs(tree-.4858)<1e-14
    # Same P and mean R, different joint law: full reward-state sampling needs p.
    joint={('G',1):.1,('S4',0):.9}
    product={('G',1):.01,('G',0):.09,('S4',1):.09,('S4',0):.81}
    def mean(d):return sum(m*(r+.9*(.5 if s=='S4' else 0)) for (s,r),m in d.items())
    assert abs(mean(joint)-mean(product))<1e-14
    # TD conditional bias equals discounted successor-value error.
    td_mean=.1*1+.9*.45
    bias=td_mean-old['S4']
    assert abs(bias-.9*.9*(.5-old['S4']))<1e-14
    qa=np.array([.5,.1,.2,.7]); pi=np.array([.05,.05,.05,.85]);y=.9*qa
    expected=float(pi@y)
    variance=float(pi@(y-expected)**2)
    assert abs(expected-.5715)<1e-14
    # Independent enumeration versus the max formula for the same Q snapshot.
    assert abs(max(y)-.63)<1e-14
    q_after=.5+.5*(0+.9*.4-.5)
    assert abs(q_after-.43)<1e-14 and q_after<.49<.5
    return {"layer":"exact finite-model identities and instructional snapshots; no training",
            "source_model_check":"28 state-action distributions match independent coordinates",
            "old_values":old,"new_values":new,"trajectory_sum_S7":trajectory_sum,
            "probability_tree":{"masses":masses.tolist(),"targets":targets.tolist(),"mean":tree},
            "five_tuple_reward_law":{"same_expected_backup":mean(joint),
                "independent_sampler_impossible_mass":.18},
            "objectives":{"J_delta_S7_old":old['S7'],"J_delta_S7_new":new['S7'],
                "J_equal_S7_S4_old":.5*(old['S7']+old['S4'])},
            "td":{"fixed_V":.5,"target_mean":td_mean,"target_bias":bias},
            "control_snapshot":{"sarsa_if_up":.45,"expected_sarsa":expected,
                "q_learning":.63,"sarsa_action_variance":variance,
                "expected_sarsa_action_variance_given_transition":0,
                "Q_S7_up_before":.5,"Q_S7_up_after":q_after,"Q_S7_left":.49},
            "checks_passed":True}


if __name__=="__main__":
    OUT.mkdir(parents=True,exist_ok=True)
    result=check()
    objects();probability_tree();control_feedback()
    (OUT/"checks.json").write_text(json.dumps(result,ensure_ascii=False,indent=2))
    print(json.dumps({"checks_passed":True,"output":str(OUT),
                      "new_figures":3,"old_S7":result['old_values']['S7']},ensure_ascii=False))
