# 第 3 章　有限马尔可夫决策过程：程序

本目录可以单独运行：在本目录下执行下面的命令即可，结果写回本目录的 `assets/`。目录由 `rl-course/tools/export_chapter_code.py` 从课程目录生成，改程序请改课程目录里的原件，再重新导出。

## 准备

```sh
python3 -m pip install -r requirements.txt
```

需要的第三方包：matplotlib、numpy。复现附录要求 Python 3.10 或更新版本；核验时用的版本见下表。

## 运行（与复现附录相同）

```sh
python3 demos/course15_mdp_dp.py
python3 demos/v17_classic.py
python3 demos/v18_classic.py
python3 demos/mud_prediction_lens.py
python3 demos/average_reward_clock.py
```

## 本目录的程序

| 程序 | 说明 | 核验 |
|---|---|---|
| `demos/v17_classic.py` | Small exact checks and instructional figures for chapters 3--6. | 通过（1 秒） |
| `demos/course15_mdp_dp.py` | Finite MDP and exact-model DP on the course's shared mud maze. | 通过（4 秒） |
| `demos/v18_classic.py` | Exact teaching objects for v18 chapters 2--6. No training. | 通过（2 秒） |
| `demos/mud_prediction_lens.py` | One prediction, three sources of information (Chapters 3–5). | 通过（0 秒） |
| `demos/average_reward_clock.py` | Ice fishing, in environment steps. Run with Python 3, no dependencies. | 通过（0 秒） |
| `demos/mud_world.py` | The lecture's 3 x 3 mud maze, with an exact model and sampled predictions. | 通过（0 秒） |
| `demos/ch03_mud_conclusion.py` | 第 3 章小结页（ch03-conclusion，审阅站第 181 页）复算： | 通过（1 秒） |

被上面程序 import 的本课模块：`demos/plot_fonts.py`。

表中后 2 个程序复现附录本章一节没有列出，来自课件、阅读稿、CODE-MAP 或文件名前缀（第三部分另含学习器阶梯）。

## 复现附录本章一节

本章的泥地导航图、价值表、有限期限表和转移矩阵由本课的程序按已知模型精确计算，结果与随机数无关。只有抽样轨迹图用到随机抽样；这些轨迹用来展示模型生成的经验，不进入任何价值计算。

| 位置 | 结果 | 设置 | 程序 | 数据与输出 |
|---|---|---|---|---|
| “泥地导航与折扣回报”（课件 `v17-classic-mdp-objects`） | 泥地地图与五元组的对应，同一动作两条后果的概率、奖励与折扣 | 共用泥地任务：S4 打滑概率 .9，$\gamma=.9$，进入 G 得 1；精确模型，无训练 | `demos/v17_classic.py` | `assets/v17-classic/mdp-objects.png`、`assets/v17-classic/checks.json` |
| “泥地导航与折扣回报”（课件 `course15-mdp-episodes`） | 两条策略的路线图；旧策略下的实际抽样轨迹 | 同一任务；旧策略 $\pi_0$（S7 向上）抽样 6 个回合，随机数种子 7，仅作演示 | `demos/course15_mdp_dp.py` | `assets/course15-mdp-dp/routes.png`、`assets/course15-mdp-dp/sample-paths.png`、`assets/course15-mdp-dp/sample-trajectories.csv` |
| “策略与轨迹分布” | 随机策略下先选动作、再按环境分支加权的概率树 | 精确模型，无训练 | `demos/v17_classic.py` | `assets/v17-classic/probability-tree.png`、`assets/v17-classic/checks.json` |
| “价值与 Bellman 期望方程” | 回报的概率与等待长度 | 精确模型：S4 每步成功概率 .1 的几何分布，无训练 | `demos/course15_mdp_dp.py` | `assets/course15-mdp-dp/return-distribution.png` |
| “动作价值与控制目标” | $\pi_0$ 与 $\pi_1$ 的价值表 .900、1.000、.810、.526、.729、.656、.474；$\pi_1$ 下 S7 为 .590，变化 +.117；$q_{\pi_0}(\mathrm{S7},\leftarrow)=.59049$ | 精确模型下的线性方程求解与迭代评价；另对全部 $4^7=16384$ 条确定性策略枚举核对最优性 | `demos/course15_mdp_dp.py` | `assets/course15-mdp-dp/results.json` |
| “动作价值与控制目标” | 同一 S7 的两种首动作对应的两个动作价值，以及状态价值按策略概率的平均 | 精确模型，无训练 | `demos/v18_classic.py` | `assets/v18-classic/policy-vq.png`、`assets/v18-classic/checks.json` |
| “有限期限与时间状态”（课件 `course15-mdp-finite-horizon`） | S7 首动作的有限期限价值：$h=2$ 为 .090000 与 0，$h=4$ 为 .221949 与 .072900，$h=6$ 为 .308521 与 .590490；最佳首动作由上变为左 | 精确模型下按剩余步数 $h$ 逐层递推 | `demos/course15_mdp_dp.py` | `assets/course15-mdp-dp/horizon-maps.png`、`assets/course15-mdp-dp/finite-horizon.csv`、`assets/course15-mdp-dp/results.json` |
| “专题扩展：模型、回报与奖励变换”（课件 `course15-mdp-matrix`） | 旧策略的非终止转移矩阵与奖励向量：S4 以 .9 留在自身，期望即时奖励 .1 | 精确模型，无训练 | `demos/v18_classic.py` | `assets/v18-classic/mdp-matrix.png`、`assets/v18-classic/checks.json` |
| “同一预测目标的三种计算”（课件 `ch03-conclusion`） | S4 的 DP 目标 .505、TD 目标 .45、首次访问 MC 目标 .81；$v_{\pi_0}(\mathrm{S4})=10/19$ | 旧估计 .5，两次打滑后成功的一条轨迹；程序默认 `--old 0.5`、`--alpha 0.2` | `demos/mud_prediction_lens.py` | 只在终端输出，不写文件 |
| 3.6 节；课件 `vision-objective-choice` | 取鱼例：$\gamma=.30$ 时单趟走右 1.20；六个环境步内总数 6 与 12 | 确定性计算，无训练；默认 $\gamma=3/10$，计数窗口 6 步 | `demos/average_reward_clock.py` | 只在终端输出，不写文件 |

外部代码（出处）：无。转移图 law.svg 由 TikZ 绘制；Hopper 姿态图取自 Pardo 等（2018）图 5；备份图取自 Sutton 与 Barto 和 Silver 的课程讲义。

运行：
```sh
python3 demos/course15_mdp_dp.py
python3 demos/v17_classic.py
python3 demos/v18_classic.py
python3 demos/mud_prediction_lens.py
python3 demos/average_reward_clock.py
```

## 参考数据

`assets/`（以及 `demos/NN-results/`）下复制了 9 个数据文件（json、csv 等），即课程目前使用的结果；图片没有复制，运行程序会重新画出。重跑会覆盖这些文件，可以先另存一份再对照。
