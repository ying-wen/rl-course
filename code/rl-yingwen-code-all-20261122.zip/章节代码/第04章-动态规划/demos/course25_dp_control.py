#!/usr/bin/env python3
"""Exact-model DP control on the existing seven-state mud task.

Run: python demos/course25_dp_control.py
No sampled learning or training. Fractions implement evaluation / improvement;
independently constructed coordinate matrices check values and optimality.
"""
from fractions import Fraction as F
from functools import lru_cache
from pathlib import Path
import itertools,json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
from plot_fonts import use_course_fonts,CJK_FAMILY
from mud_world import STATES,ACTIONS,POSITIONS,OLD,NEW,outcomes
from course22_mdp_checks import evaluate,q_values,branches
from course15_mdp_dp import independent_arrays,matrix_value

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'assets/course25-dp-control'
G=F(9,10)
ACTS=tuple(ACTIONS)
# 11-21 r1121-110741：图内字体改用课件字体（Latin Modern Sans + FandolHei），缩放后字号不小于 7pt。
use_course_fonts()
TEAL,RED,GOLD,INK,MUTED='#087E8B','#C65335','#C4942A','#182E38','#61757D'
plt.rcParams.update({'font.size':14,'pdf.fonttype':42})
MAP_FS={'state':11.5,'value':14,'terminal':12.5,'title':15.5}
# vi-front 在 217 页只有 3.05cm 高，单独放大。
VI_FS={'state':14,'value':15.5,'terminal':14,'title':16.5}


def fmt(v):
    """Slide style: .729, 1.00, 0."""
    if v==0:return '0'
    return f'{v:.2f}' if v>=1 else f'{v:.3f}'[1:]


def greedy(value,previous=None):
    result={}
    for s in STATES:
        q=q_values(value,s);best=max(q.values())
        result[s]=previous[s] if previous and q[previous[s]]==best else next(a for a in ACTS if q[a]==best)
    return result


def t_star(value):
    return {s:max(q_values(value,s).values()) for s in STATES}


def t_policy(value,policy):
    return {s:q_values(value,s)[policy[s]] for s in STATES}


def policy_iteration(initial):
    policy=initial.copy();stages=[]
    for _ in range(100):
        value=evaluate(policy)
        candidate=greedy(value,policy)
        stages.append((policy.copy(),value,[s for s in STATES if policy[s]!=candidate[s]]))
        if candidate==policy:return stages
        next_value=evaluate(candidate)
        assert all(next_value[s]>=value[s] for s in STATES)
        assert any(next_value[s]>value[s] for s in STATES)
        policy=candidate
    raise AssertionError('finite policy loop did not terminate')


def value_iteration(epsilon=F(1,1000000),initial=None):
    """Synchronous VI with the returned-new-table error bound in slide lines 3–5."""
    if epsilon<=0:raise ValueError('epsilon must be positive')
    value={s:F(0) for s in STATES} if initial is None else initial.copy()
    for sweep in range(1,10000):
        new=t_star(value)  # All state targets depend on the same old table.
        delta=max(abs(new[s]-value[s]) for s in STATES)
        value=new
        error_bound=G*delta/(1-G)
        if error_bound<=epsilon:
            return value,greedy(value),sweep,error_bound
    raise AssertionError('VI failed to meet the requested bound')


def draw_map(ax,value,policy,title,changed=(),fs=None):
    fs=fs or MAP_FS
    lookup={xy:s for s,xy in POSITIONS.items()}
    for y in range(3):
        for x in range(3):
            s=lookup.get((x,y));yy=2-y
            if s is None:
                ax.add_patch(Rectangle((x,yy),1,1,color=INK));continue
            v=0 if s=='G' else float(value[s])
            face='#E9C978' if s=='G' else plt.cm.GnBu(.08+.53*np.clip(v,0,1))
            ax.add_patch(Rectangle((x,yy),1,1,facecolor=face,edgecolor='#91A3AA',lw=.8))
            if s=='S4':ax.add_patch(Rectangle((x+.035,yy+.035),.93,.93,fill=False,edgecolor=GOLD,lw=2,ls='--'))
            if s in changed:ax.add_patch(Rectangle((x+.025,yy+.025),.95,.95,fill=False,edgecolor=RED,lw=2))
            ax.text(x+.06,yy+.80,s,fontsize=fs['state'],color=INK)
            if s=='G':
                ax.text(x+.5,yy+.40,'终止',fontfamily=CJK_FAMILY,ha='center',fontsize=fs['terminal'])
                continue
            ax.text(x+.5,yy+.47,fmt(v),ha='center',fontsize=fs['value'],color=INK)
            dx,dy=ACTIONS[policy[s]];dy=-dy
            ax.arrow(x+.5-.15*dx,yy+.22-.15*dy,.3*dx,.3*dy,color=TEAL,
                     width=.012,head_width=.10,head_length=.09,length_includes_head=True)
    ax.set(xlim=(-.02,3.02),ylim=(-.02,3.02),aspect='equal');ax.axis('off')
    ax.set_title(title,fontsize=fs['title'],pad=6)


def save(fig,name):
    for ext in ('pdf','png'):fig.savefig(OUT/f'{name}.{ext}',bbox_inches='tight',dpi=200)
    plt.close(fig)


def numeric(v):return {s:float(v[s]) for s in STATES}


def main():
    OUT.mkdir(parents=True,exist_ok=True)
    old=evaluate(OLD);new=evaluate(NEW)
    stages=policy_iteration({s:'up' for s in STATES})
    assert len(stages)==6
    assert stages[-1][0]==NEW
    p,r=independent_arrays()
    matrix_errors=[]
    for policy,value,_ in stages:
        solved=matrix_value(policy,p,r)
        matrix_errors.append(max(abs(float(value[s])-solved[i]) for i,s in enumerate(STATES)))
    assert max(matrix_errors)<1e-12
    # 11-21 全局方案：第 4 章红框统一为“这一步改了动作的格子”（与 ch04-pi-not-enough、ch04-pi-loop 一致）。
    # sigma_k 图中红框标出第 k 次改进改了动作的格子，角标 2 表示该格第二次改动；sigma_0 无红框。
    marks=[[]];counts={s:0 for s in STATES}
    for k in range(1,len(stages)):
        diff=[s for s in STATES if stages[k][0][s]!=stages[k-1][0][s]]
        for s in diff:counts[s]+=1
        marks.append([(s,counts[s]) for s in diff])
    for name,subset,offset in [('pi-early',stages[:3],0),('pi-late',stages[3:],3)]:
        # 11-21 r1121-110741：全向上序列记作 sigma_0..sigma_5，与本章泥路策略 pi_0 区分。
        fig,axes=plt.subplots(1,3,figsize=(6.6,2.45))
        for i,(ax,(policy,value,_)) in enumerate(zip(axes,subset)):
            mk=marks[offset+i]
            draw_map(ax,value,policy,fr'$\sigma_{{{offset+i}}},\ v_{{\sigma_{{{offset+i}}}}}$',[s for s,_ in mk])
            lookup={s:xy for s,xy in POSITIONS.items()}
            for s,c in mk:
                if c>1:
                    x,y=lookup[s];ax.text(x+.93,2-y+.07,str(c),ha='right',va='bottom',
                                          fontsize=MAP_FS['state'],color=RED,fontweight='bold')
        fig.tight_layout(w_pad=1.0);save(fig,name)
    fig,axes=plt.subplots(1,2,figsize=(4.5,2.45))
    draw_map(axes[0],old,OLD,r'$\pi_0,\ v_{\pi_0}$',['S7'])
    draw_map(axes[1],new,NEW,r'$\pi_1,\ v_{\pi_1}$')
    fig.tight_layout(w_pad=2);save(fig,'improvement-values')

    hist=[{s:F(0) for s in STATES}]
    for _ in range(26):hist.append(t_star(hist[-1]))
    # Independent finite-horizon optimal returns, using coordinate geometry rather
    # than the shared outcomes() routine or the vector Bellman implementation.
    lookup={xy:s for s,xy in POSITIONS.items()}
    @lru_cache(None)
    def horizon(s,n):
        if s=='G' or n==0:return F(0)
        x,y=POSITIONS[s];answers=[]
        for a,(dx,dy) in ACTIONS.items():
            successor=lookup.get((x+dx,y+dy),s)
            success=F(1,10) if s=='S4' else F(1)
            answers.append(success*(int(successor=='G')+G*horizon(successor,n-1))
                           +(1-success)*G*horizon(s,n-1))
        return max(answers)
    for n in range(9):
        for s in STATES:assert hist[n][s]==horizon(s,n)
    fig,axes=plt.subplots(1,3,figsize=(6.6,2.45))
    for ax,k in zip(axes,(2,5,6)):
        draw_map(ax,hist[k],greedy(hist[k]),fr'$V_{{{k}}},\ \mathrm{{greedy}}(V_{{{k}}})$',fs=VI_FS)
    fig.tight_layout(w_pad=1.0);save(fig,'vi-front')

    # Exhaustively compare deterministic stationary policies against the final PI
    # value using a second transition representation and a floating-point solver.
    best=np.full(7,-np.inf)
    for choices in itertools.product(ACTS,repeat=7):
        v=matrix_value(dict(zip(STATES,choices)),p,r);best=np.maximum(best,v)
    optimal_error=max(abs(float(new[s])-best[i]) for i,s in enumerate(STATES))
    assert optimal_error<1e-12
    returned,returned_policy,sweeps,bound=value_iteration()
    actual=max(abs(returned[s]-new[s]) for s in STATES)
    assert actual<=bound<=F(1,1000000)
    # The retained asynchronous figure is one exact sweep of the same NEW policy.
    sync=t_policy({s:F(0) for s in STATES},NEW)
    inplace={s:F(0) for s in STATES}
    for s in ('S2','S1','S3','S5','S6','S7','S4'):
        inplace[s]=q_values(inplace,s)[NEW[s]]
    assert inplace['S7']==G**5 and sync['S7']==0
    assert inplace['S4']==sync['S4']==F(1,10)
    # Check the optimal residual certificate on several arbitrary intermediate tables.
    certs=[]
    for k in (0,1,2,5,6,12,26):
        value=hist[k];tv=t_star(value);pol=greedy(value);vp=evaluate(pol)
        rho=max(abs(tv[s]-value[s]) for s in STATES)
        err=max(abs(new[s]-value[s]) for s in STATES)
        loss=max(new[s]-vp[s] for s in STATES)
        assert err<=rho/(1-G)
        assert loss<=2*rho/(1-G)
        certs.append({'iteration':k,'residual':float(rho),'value_error':float(err),
                      'greedy_policy_loss':float(loss),'policy_bound':float(2*rho/(1-G))})
    # Exact policy-improvement and prefix inequalities for deterministic policies.
    rng=np.random.default_rng(25);improvements=0
    for _ in range(32):
        pol={s:ACTS[rng.integers(4)] for s in STATES}
        v=evaluate(pol);candidate=greedy(v,pol);vp=evaluate(candidate)
        assert all(vp[s]>=v[s] for s in STATES)
        prefix=v
        for n in range(1,9):
            following=t_policy(prefix,candidate)
            assert all(v[s]<=prefix[s]<=following[s]<=vp[s] for s in STATES)
            prefix=following
        improvements+=1
    # Max-operator contraction check independent of actual policy iterations.
    for _ in range(64):
        u={s:F(int(rng.integers(-30,31)),10) for s in STATES}
        v={s:F(int(rng.integers(-30,31)),10) for s in STATES}
        tu,tv=t_star(u),t_star(v)
        assert max(abs(tu[s]-tv[s]) for s in STATES)<=G*max(abs(u[s]-v[s]) for s in STATES)
    record={'gamma':float(G),'old_q_S7':{a:float(x) for a,x in q_values(old,'S7').items()},
            'old_values':numeric(old),'new_values':numeric(new),
            'policy_iteration_stages':[{'policy':pol,'value':numeric(v),'changed':changed} for pol,v,changed in stages],
            'independent_matrix_max_error':max(matrix_errors),'exhaustive_policies':4**7,
            'exhaustive_optimal_max_error':optimal_error,'finite_horizon_exact_matches':9*len(STATES),
            'policy_improvement_prefix_checks':improvements,'contraction_checks':64,
            'VI_S7':{str(k):{'value':float(hist[k]['S7']),'greedy':greedy(hist[k])['S7'],
                             'greedy_value':float(evaluate(greedy(hist[k]))['S7'])} for k in (2,5,6)},
            'residual_certificates':certs,
            'VI_stopping':{'epsilon':1e-6,'sweeps':sweeps,'returned_table_bound':float(bound),
                           'actual_value_error':float(actual),'greedy_policy':returned_policy},
            'one_sweep':{'synchronous':numeric(sync),'in_place':numeric(inplace)},
            'new_environment_samples':0}
    (OUT/'checks.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({k:record[k] for k in ('independent_matrix_max_error','exhaustive_policies',
                      'exhaustive_optimal_max_error','finite_horizon_exact_matches','VI_S7')},indent=2))


if __name__=='__main__':main()
