"""Exact DP-evaluation figures and independent checks; no sampled training.

Run from any directory: python /path/to/demos/course25_dp_evaluation.py
The model is imported from the existing mud_world.py; its files are unchanged.
"""
from fractions import Fraction as F
from pathlib import Path
import json
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from mud_world import STATES, OLD, outcomes

OUT = Path(__file__).resolve().parents[1] / "assets/course25-dp-evaluation"
GAMMA = F(9, 10)


def branches(s):
    return [(F(str(p)), nxt, F(str(r)), done) for p, nxt, r, done in outcomes(s, OLD[s])]


def apply(v, gamma=GAMMA):
    return {s: sum(p*(r+gamma*(0 if done else v[nxt]))
                   for p, nxt, r, done in branches(s)) for s in STATES}


def distance(u, v):
    return max(abs(u[s]-v[s]) for s in STATES)


def solve(gamma=GAMMA):
    # Independent direct linear solve of (I-gamma P_pi)v=r_pi.
    n = len(STATES)
    matrix = [[F(int(i == j)) for j in range(n)]+[F(0)] for i in range(n)]
    for i, s in enumerate(STATES):
        for p, nxt, r, done in branches(s):
            matrix[i][-1] += p*r
            if not done:
                matrix[i][STATES.index(nxt)] -= gamma*p
    for j in range(n):
        pivot = next(i for i in range(j, n) if matrix[i][j])
        matrix[j], matrix[pivot] = matrix[pivot], matrix[j]
        scale = matrix[j][j]
        matrix[j] = [x/scale for x in matrix[j]]
        for i in range(n):
            if i != j:
                scale = matrix[i][j]
                matrix[i] = [a-scale*b for a, b in zip(matrix[i], matrix[j])]
    return {s: matrix[i][-1] for i, s in enumerate(STATES)}


def finite_path_return(s, horizon):
    # Explicit finite trajectory tree: no intermediate value table is cached.
    if not horizon:
        return F(0)
    return sum(p*(r+GAMMA*(0 if done else finite_path_return(nxt, horizon-1)))
               for p, nxt, r, done in branches(s))


def checks():
    vstar = solve()
    assert vstar["S4"] == F(10, 19) and vstar["S7"] == F(9, 19)
    assert apply(vstar) == vstar
    zero = dict.fromkeys(STATES, F(0))
    one = dict.fromkeys(STATES, F(1))
    rows, hist, gaps = [], [zero.copy()], []
    v, u = zero.copy(), one.copy()
    epsilon = F(1, 10**6)
    stop = None
    for k in range(130):
        new, unew = apply(v), apply(u)
        gap = distance(v, u)
        assert distance(new, unew) <= GAMMA*gap
        gaps.append(gap)
        delta = distance(new, v)
        eold, enew = distance(v, vstar), distance(new, vstar)
        old_bound, new_bound = delta/(1-GAMMA), GAMMA*delta/(1-GAMMA)
        assert eold <= old_bound and enew <= new_bound
        assert enew <= GAMMA*eold
        if k <= 6:
            assert all(v[s] == finite_path_return(s, k) for s in STATES)
        if stop is None and new_bound <= epsilon:
            stop = dict(returned_sweep=k+1, delta=delta,
                        actual_returned_error=enew, certified_error=new_bound,
                        epsilon=epsilon)
        rows.append(dict(k=k, S4=v["S4"], S7=v["S7"], delta=delta,
                         actual_old_error=eold, actual_new_error=enew,
                         old_error_bound=old_bound, new_error_bound=new_bound))
        v, u = new, unew
        hist.append(v.copy())
    assert hist[1]["S4"] == F(1, 10) and hist[1]["S7"] == 0
    assert hist[2]["S4"] == F(181, 1000) and hist[2]["S7"] == F(9, 100)
    # An arbitrary old table demonstrates synchronous data dependence.
    sample = {s: F(2, 5) for s in STATES}
    sample["S4"] = F(1, 2)
    assert apply(sample)["S4"] == F(101, 200)
    assert apply(sample)["S7"] == F(9, 20)
    # Check signed arbitrary tables, not only the two initializations plotted.
    samples = [{s: F((i+shift)%5-2, 3) for i, s in enumerate(STATES)} for shift in range(5)]
    for a in samples:
        for b in samples:
            assert distance(apply(a), apply(b)) <= GAMMA*distance(a, b)
    # At gamma=0 one complete backup is exact, independently of the old table.
    assert apply(samples[0], F(0)) == solve(F(0))
    assert F(0)*distance(apply(samples[0], F(0)), samples[0])/(1-F(0)) == 0
    return dict(gamma=GAMMA, true_values=vstar, first_sweeps=hist[:4],
                rows=rows, differences=gaps, stop=stop,
                gamma_zero_one_backup_exact=True, sampled_episodes=0, training_runs=0)


def figures(report):
    # 11-21 审阅站请求 r1121-110741（第 194 页）：改用课件字体；字号按页面缩放后
    # 刻度约 7.5pt、轴标签约 8pt（图宽 7.9in 放在 14.4cm 宽、4.1cm 高的框里）；
    # 左图标出 u0、u1、u2，与第 182 页的数列对上。原设置见 data/history 备份。
    from plot_fonts import use_course_fonts, CJK_FAMILY, no_leading_zero
    use_course_fonts()
    plt.rcParams.update({"font.size": 13, "axes.labelsize": 14,
                         "xtick.labelsize": 13, "ytick.labelsize": 13,
                         "legend.fontsize": 13,
                         "axes.spines.top": False, "axes.spines.right": False,
                         "axes.unicode_minus": False})
    fig, axes = plt.subplots(1, 2, figsize=(7.9, 2.35))
    ax = axes[0]
    x = np.linspace(0, 1.05, 100)
    ax.plot(x, x, color="#61757D", ls="--", lw=1.5, label=r"$y=u$")
    ax.plot(x, .1+.81*x, color="#087E8B", lw=2, label=r"$F(u)=$ .1 + .81$u$")
    u = F(0)
    seq = [u]
    for _ in range(6):
        nxt = F(1, 10)+F(81, 100)*u
        ax.plot([float(u), float(u), float(nxt)], [float(u), float(nxt), float(nxt)],
                color="#C65335", lw=1.2)
        u = nxt
        seq.append(u)
    # 前三个迭代点在对角线上，标签放在对角线下方的空白处，用细线连到点。
    for i, (tx, ty) in enumerate([(.13, -.01), (.28, .06), (.44, .14)]):
        ui = float(seq[i])
        lab = "0" if i == 0 else f"{ui:.3g}".lstrip("0")
        ax.scatter([ui], [ui], color="#C65335", s=14, zorder=6, clip_on=False)
        ax.annotate(rf"$u_{i}=$" + lab, (ui, ui), (tx, ty), color="#C65335", fontsize=12,
                    va="bottom", annotation_clip=False,
                    arrowprops={"arrowstyle": "-", "color": "#C65335", "lw": .6,
                                "shrinkA": 1, "shrinkB": 2})
    ax.scatter([10/19], [10/19], color="#182E38", s=22, zorder=5)
    ax.annotate(r"$u_*=10/19$", (10/19, 10/19), (.70, .34),
                arrowprops={"arrowstyle": "->", "color": "#182E38"}, fontsize=13)
    ax.set(xlim=(0, 1.05), ylim=(0, 1.05))
    ax.set_xlabel(r"旧值 $u=V(\mathrm{S4})$", fontfamily=CJK_FAMILY)
    ax.set_ylabel("更新后的值")
    ax.xaxis.set_major_formatter(no_leading_zero)
    ax.yaxis.set_major_formatter(no_leading_zero)
    ax.legend(frameon=False, loc="upper left", handlelength=1.4, borderaxespad=0)
    ax = axes[1]
    k = np.arange(36)
    gap = np.array([float(v) for v in report["differences"][:36]])
    ax.semilogy(k, gap, lw=2, color="#087E8B", label=r"$\|T_\pi^kU_0-T_\pi^kV_0\|_\infty$")
    ax.semilogy(k, .9**k, lw=1.6, ls="--", color="#C65335", label=r".9$^k\|U_0-V_0\|_\infty$")
    ax.set_xlabel(r"同步更新轮数 $k$", fontfamily=CJK_FAMILY)
    ax.set_ylabel("两表最大差")
    ax.legend(frameon=False, loc="lower left", handlelength=1.4, borderaxespad=0)
    fig.tight_layout(pad=.4, w_pad=1.6)
    fig.savefig(OUT/"contraction.pdf", bbox_inches="tight")
    fig.savefig(OUT/"contraction.png", bbox_inches="tight", dpi=180)
    plt.close(fig)


def serial(v):
    if isinstance(v, F):
        return {"fraction": str(v), "decimal": float(v)}
    if isinstance(v, dict):
        return {k: serial(x) for k, x in v.items()}
    if isinstance(v, (list, tuple)):
        return [serial(x) for x in v]
    return v


if __name__ == "__main__":
    OUT.mkdir(parents=True, exist_ok=True)
    report = checks()
    figures(report)
    (OUT/"checks.json").write_text(json.dumps(serial(report), indent=2)+"\n")
    print(json.dumps({"checks_passed": True, "training_runs": 0,
                      "epsilon": float(report["stop"]["epsilon"]),
                      "returned_sweep": report["stop"]["returned_sweep"],
                      "actual_returned_error": float(report["stop"]["actual_returned_error"]),
                      "certified_error": float(report["stop"]["certified_error"])}))
