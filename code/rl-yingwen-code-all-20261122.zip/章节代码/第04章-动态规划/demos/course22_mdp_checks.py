"""Exact checks for the MDP/DP teaching sequence; no sampled training.

Run from any directory: python /path/to/rl-course/demos/course22_mdp_checks.py
Standard library only. Reads the shared mud_world.outcomes model, solves finite
linear systems with Fractions, and checks against independent closed forms and
finite-path enumeration. Native TikZ figures remain editable in the slide files.
"""
from fractions import Fraction as F
from pathlib import Path
import json
from mud_world import STATES, ACTIONS, OLD, NEW, outcomes

GAMMA = F(9, 10)
OUT = Path(__file__).resolve().parents[1] / 'assets/course22-mdp'


def branches(s, a):
    return [(F(str(p)), nxt, F(str(r)), done) for p, nxt, r, done in outcomes(s, a)]


def actions(policy, s):
    rule = policy[s]
    return rule.items() if isinstance(rule, dict) else [(rule, F(1))]


def solve(matrix, rhs):
    aug = [list(row) + [value] for row, value in zip(matrix, rhs)]
    for col in range(len(aug)):
        pivot = next(i for i in range(col, len(aug)) if aug[i][col])
        aug[col], aug[pivot] = aug[pivot], aug[col]
        value = aug[col][col]
        aug[col] = [x / value for x in aug[col]]
        for i in range(len(aug)):
            if i == col:
                continue
            value = aug[i][col]
            aug[i] = [x - value * y for x, y in zip(aug[i], aug[col])]
    return [row[-1] for row in aug]


def evaluate(policy):
    index = {s: i for i, s in enumerate(STATES)}
    matrix = [[F(int(i == j)) for j in range(len(STATES))]
              for i in range(len(STATES))]
    rhs = [F(0) for _ in STATES]
    for s in STATES:
        for a, action_prob in actions(policy, s):
            for p, nxt, reward, done in branches(s, a):
                prob = F(action_prob) * p
                rhs[index[s]] += prob * reward
                if not done:
                    matrix[index[s]][index[nxt]] -= GAMMA * prob
    return dict(zip(STATES, solve(matrix, rhs)))


def q_values(values, s):
    return {a: sum(p * (r + GAMMA * (0 if done else values[nxt]))
                   for p, nxt, r, done in branches(s, a)) for a in ACTIONS}


def numeric(values):
    return {key: float(value) for key, value in values.items()}


def main():
    old = evaluate(OLD)
    # Independent expected-return formulas from deterministic dry-path lengths
    # and geometric mud-waiting times; not an iterative Bellman solver.
    expected = {'S1': GAMMA, 'S2': F(1), 'S3': GAMMA**2, 'S4': F(10, 19),
                'S5': GAMMA**3, 'S6': GAMMA**4, 'S7': F(9, 19)}
    assert old == expected
    assert abs(sum(F(1, 10) * F(9, 10)**k * GAMMA**(k + 1)
                   for k in range(500)) - F(9, 19)) < F(1, 10**14)
    q7 = q_values(old, 'S7')
    assert q7 == {'up': F(9, 19), 'right': F(81, 190),
                  'down': F(81, 190), 'left': GAMMA**5}
    for s in STATES:
        assert q_values(old, s)[OLD[s]] == old[s]
    mixed = {**OLD, 'S7': {'up': F(1, 2), 'left': F(1, 2)}}
    mix_value = evaluate(mixed)
    assert mix_value['S7'] == F(1, 2) * (F(9, 19) + GAMMA**5)
    # Enumerate all paths of length at most two, keeping terminal paths absorbed.
    finite = {}
    for start in STATES:
        paths = [(start, F(1), F(0))]
        finite[start] = []
        for t in range(2):
            extended = []
            for s, probability, total_return in paths:
                if s == 'G':
                    extended.append((s, probability, total_return))
                else:
                    for p, nxt, reward, done in branches(s, OLD[s]):
                        extended.append((nxt, probability * p,
                                         total_return + GAMMA**t * reward))
            paths = extended
            finite[start].append(sum(p * g for _, p, g in paths))
    assert finite['S4'] == [F(1, 10), F(181, 1000)]
    assert finite['S7'] == [F(0), F(9, 100)]
    policy = OLD.copy()
    iterations = []
    while True:
        values = evaluate(policy)
        improved = {}
        for s in STATES:
            qs = q_values(values, s)
            largest = max(qs.values())
            improved[s] = policy[s] if qs[policy[s]] == largest else next(
                a for a in ACTIONS if qs[a] == largest)
        changed = [s for s in STATES if improved[s] != policy[s]]
        iterations.append({'policy': policy.copy(), 'values': numeric(values),
                           'q_S7': numeric(q_values(values, 'S7')),
                           'changed_states': changed, 'stable': not changed})
        if not changed:
            break
        policy = improved
        assert len(iterations) < 20
    assert policy == NEW
    assert len(iterations) == 2
    assert iterations[0]['changed_states'] == ['S7']
    # Joint-kernel marginal and immediate-reward check at the mud state.
    assert sum(p for p, _, _, _ in branches('S4', 'up')) == 1
    assert sum(p * r for p, _, r, _ in branches('S4', 'up')) == F(1, 10)
    result = {'gamma': float(GAMMA), 'old_policy': OLD, 'old_values': numeric(old),
              'old_q_S7': numeric(q7), 'mixed_policy_value_S7': float(mix_value['S7']),
              'first_two_sweeps_by_path_enumeration':
                  {s: [float(x) for x in vals] for s, vals in finite.items()},
              'policy_iteration': iterations, 'new_policy': policy,
              'new_value_S7': iterations[-1]['values']['S7'],
              'checks_passed': True, 'sampled_episodes': 0, 'training_runs': 0,
              'scope': 'Exact model calculations, closed-form checks, and finite-path enumeration.'}
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / 'checks.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'checks_passed': True, 'q_S7': result['old_q_S7'],
                      'mixed_policy_value_S7': result['mixed_policy_value_S7'],
                      'policy_iteration_rounds': len(iterations),
                      'new_value_S7': result['new_value_S7']}))


if __name__ == '__main__':
    main()
