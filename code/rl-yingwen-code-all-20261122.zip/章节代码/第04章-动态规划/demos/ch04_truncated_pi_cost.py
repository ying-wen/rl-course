#!/usr/bin/env python3
"""Cost of truncated policy iteration on the mud task (slide ch04-tension).

Run: python3 demos/ch04_truncated_pi_cost.py
Exact rational arithmetic, no sampling, terminal output only.

Accounting used on the slide: one greedy improvement evaluates all
7 states x 4 actions = 28 one-step model expectations; that pass also gives
the new value of the chosen action, i.e. it doubles as the first evaluation
sweep.  Each further sweep of fixed-policy evaluation costs 7 expectations.
Start from the zero table.  Stop when the value error w.r.t. v_* is <= tol
and the greedy policy is optimal (judged with the true v_*; analysis only).
"""
from fractions import Fraction as F
from mud_world import STATES, ACTIONS, NEW
from course22_mdp_checks import evaluate, q_values

ACTS = tuple(ACTIONS)


def greedy(value, previous=None):
    result = {}
    for s in STATES:
        q = q_values(value, s); best = max(q.values())
        keep = previous is not None and q[previous[s]] == best
        result[s] = previous[s] if keep else next(a for a in ACTS if q[a] == best)
    return result


def t_policy(value, policy):
    return {s: q_values(value, s)[policy[s]] for s in STATES}


V_STAR = evaluate(NEW)


def run(m, tol):
    """Return (improvements, greedy cost, extra-evaluation cost)."""
    value = {s: F(0) for s in STATES}; policy = None; improvements = 0; extra = 0
    while True:
        policy = greedy(value, policy); improvements += 1
        if m is None:            # m -> infinity: exact evaluation
            value = evaluate(policy)
        else:
            value = t_policy(value, policy)
            for _ in range(m - 1):
                value = t_policy(value, policy); extra += 7
        error = max(abs(value[s] - V_STAR[s]) for s in STATES)
        optimal = all(q_values(V_STAR, s)[policy[s]] == V_STAR[s] for s in STATES)
        if error <= tol and optimal:
            return improvements, 28 * improvements, extra
        assert improvements < 5000


def main():
    for tol in (F(1, 100), F(1, 1000)):
        print(f'tol = {float(tol)}')
        rows = [(m,) + run(m, tol) for m in range(1, 13)]
        for m, k, greedy_cost, extra in rows:
            print(f'  m={m:2d}  improvements={k:3d}  greedy={greedy_cost:4d}  '
                  f'extra={extra:4d}  total={greedy_cost + extra:4d}')
        best = min(rows, key=lambda r: r[2] + r[3])
        print(f'  cheapest m = {best[0]}, total = {best[2] + best[3]}')
        print(f'  policy iteration (m -> inf): improvements = {run(None, tol)[0]}')


if __name__ == '__main__':
    main()
