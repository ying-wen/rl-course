# DP evaluation: sources and numerical protocol

All new drawings and numbers are model calculations, not training results.
The original `demos/mud_world.py` model and existing experiment files are unchanged.

- Sutton and Barto, *Reinforcement Learning: An Introduction*, Ch4, section4.1,
  PDF pages95–99: full known model, Bellman equations versus assignments,
  synchronous two-table evaluation, and the distinction from in-place updates.
- David Silver, Lecture3, *Planning by Dynamic Programming*, pages3–11 and35–39:
  overlapping subproblems, reuse of value functions, synchronous backups,
  maximum norm, and contraction. Current official PDF:
  https://davidstarsilver.wordpress.com/wp-content/uploads/2025/04/lecture-3-planning-by-dynamic-programming-.pdf
  The old davidsilver.uk/wp-content/uploads/2020/03/DP.pdf URL returned404.
- The mud maze is the existing Machado-based task used throughout the course.
  Its transition rules are imported rather than reimplemented as a new environment.

The proof uses bounded discounted returns to establish existence of v_pi,
then proves uniqueness and convergence directly from contraction. It does
not rely on an unstated form of the Banach theorem. The scope is finite
stationary MDPs with bounded rewards and 0 <= gamma < 1.

`course25_dp_evaluation.py` compares synchronous table updates with independent
finite trajectory-tree expansion and a rational direct linear solve. It also
checks arbitrary signed input tables, every displayed residual bound, and
the gamma=0 boundary. The plot compares two different initial tables with
terminal value0; the direct solve is a verification reference, not an input
to the iterative evaluation algorithm.
