# 第 4 章　动态规划：程序

本目录可以单独运行：在本目录下执行下面的命令即可，结果写回本目录的 `assets/`。目录由 `rl-course/tools/export_chapter_code.py` 从课程目录生成，改程序请改课程目录里的原件，再重新导出。

## 准备

```sh
python3 -m pip install -r requirements.txt
```

需要的第三方包：matplotlib、numpy。复现附录要求 Python 3.10 或更新版本；核验时用的版本见下表。

## 运行（与复现附录相同）

```sh
python3 demos/course25_dp_evaluation.py
python3 demos/course25_dp_control.py
python3 demos/course15_mdp_dp.py
python3 demos/v18_classic.py
python3 demos/mud_prediction_lens.py
python3 demos/ch04_truncated_pi_cost.py
```

## 本目录的程序

| 程序 | 说明 | 核验 |
|---|---|---|
| `demos/course25_dp_evaluation.py` | Exact DP-evaluation figures and independent checks; no sampled training. | 通过（1 秒） |
| `demos/course15_mdp_dp.py` | Finite MDP and exact-model DP on the course's shared mud maze. | 通过（4 秒） |
| `demos/course25_dp_control.py` | Exact-model DP control on the existing seven-state mud task. | 通过（2 秒） |
| `demos/v18_classic.py` | Exact teaching objects for v18 chapters 2--6. No training. | 通过（2 秒） |
| `demos/mud_prediction_lens.py` | One prediction, three sources of information (Chapters 3–5). | 通过（0 秒） |
| `demos/ch04_truncated_pi_cost.py` | Cost of truncated policy iteration on the mud task (slide ch04-tension). | 通过（0 秒） |

被上面程序 import 的本课模块：`demos/course22_mdp_checks.py`、`demos/mud_world.py`、`demos/plot_fonts.py`。

## 复现附录本章一节

本章的评价表、收缩界、策略迭代与价值迭代的各阶段，以及动作区间和更新顺序的图，都在已知的泥地模型上精确计算，不含训练。策略评价程序用有理数运算，表中的分数可以逐项核对。

| 位置 | 结果 | 设置 | 程序 | 数据与输出 |
|---|---|---|---|---|
| “同步迭代策略评价”（课件 `course15-dp-evaluate-code`、`course15-dp-first-sweeps`） | 第 1、2、5 轮同步评价表；旧表 $V(\mathrm{S4})=.5$ 时新 S4 为 .505、新 S7 为 .45，原地更新得 .4545 | 共用泥地任务，旧策略 $\pi_0$（S7 向上），$\gamma=.9$，从全零表开始，精确模型 | `demos/course25_dp_evaluation.py`；`demos/course15_mdp_dp.py` | `assets/course25-dp-evaluation/checks.json`、`assets/course15-mdp-dp/evaluation-maps.png`、`assets/course15-mdp-dp/evaluation.csv` |
| “Bellman 算子的收缩性与停止条件”（课件 `course15-dp-contraction-plot`、`course15-dp-stopping`） | 泥地标量递推与统一收缩界；第 10 轮 $\Delta_9\approx.016677$，误差上界 .15010，实际误差 .07110；按停止规则在第 67 轮返回 | 同上，有理数精确运算，并以联立方程直接求解核对 | `demos/course25_dp_evaluation.py` | `assets/course25-dp-evaluation/contraction.png`、`assets/course25-dp-evaluation/checks.json` |
| “策略改进定理”（课件 `course15-dp-improved-map`） | 旧策略与改进后策略的真实价值；$q_{\pi_0}(\mathrm{S7},\uparrow)=.4737$，$q_{\pi_0}(\mathrm{S7},\leftarrow)=.59049$ | 精确模型下的一步动作比较 | `demos/course25_dp_control.py` | `assets/course25-dp-control/improvement-values.png`、`assets/course25-dp-control/checks.json` |
| “策略改进定理”（课件 `course15-dp-approximate-improvement`） | 旧表 S4 加 .02、S6 减 .02 时的动作区间：向上 .491684、向左 .57249，误差半径 .018 | 精确计算，无训练 | `demos/v18_classic.py` | `assets/v18-classic/action-intervals.png`、`assets/v18-classic/checks.json` |
| “Bellman 最优方程、策略迭代与价值迭代”（课件 `course15-dp-policy-iteration`、`course15-dp-pi-early`、`course15-dp-pi-late`、`course15-dp-vi-map`） | 策略迭代的前 3 个与后 3 个策略；价值迭代的中间表及其贪心动作 | 精确策略迭代从全部向上的策略开始；价值迭代从全零表开始，停止阈值 $10^{-6}$ | `demos/course25_dp_control.py` | `assets/course25-dp-control/pi-early.png`、`assets/course25-dp-control/pi-late.png`、`assets/course25-dp-control/vi-front.png`、`assets/course25-dp-control/checks.json` |
| “广义策略迭代与计算开销”（课件 `course15-dp-asynchronous`） | 改变 S7 动作时表值仍为 .474，重新评价后为 .590；同一初表的一轮同步评价与一轮原地评价 | 精确计算，无训练 | `demos/v18_classic.py` | `assets/v18-classic/gpi-s7.png`、`assets/v18-classic/dp-order.png`、`assets/v18-classic/checks.json` |
| “动态规划的实现与核验” | 策略评价与价值迭代每轮七个状态的数值、有限期限首动作比较、抽样轨迹的逐步记录及汇总 | 精确模型；抽样轨迹 6 回合，随机数种子 7，仅作演示，不进入 DP 目标 | `demos/course15_mdp_dp.py` | `assets/course15-mdp-dp/evaluation.csv`、`assets/course15-mdp-dp/value-iteration.csv`、`assets/course15-mdp-dp/finite-horizon.csv`、`assets/course15-mdp-dp/sample-trajectories.csv`、`assets/course15-mdp-dp/results.json` |
| “固定策略的模型期望与轨迹样本”（课件 `course25-method-dp-sampling`） | DP 目标 .505；TD 目标的条件期望 .505；MC 回报的条件期望 $10/19$ | 旧估计 .5；程序默认 `--old 0.5`、`--alpha 0.2` | `demos/mud_prediction_lens.py` | 只在终端输出，不写文件 |
| “三种方法的代价”“评价轮数的取舍”（课件 `ch04-method-table`、`ch04-tension`） | 截断策略迭代在 $m=1,\dots,12$ 时的改进次数与一步期望计算次数；误差要求 .01 时 $m=5$ 最省（224 次），价值迭代 532 次，策略迭代改进 4 次；误差要求 .001 时 $m=8$ 最省（308 次），价值迭代 840 次 | 从零表出发，有理数精确运算；一次贪心改进计 28 个一步期望并兼作第一轮评价，此后每轮评价计 7 个；停止规则用真值 $v_*$ 判定，只作分析用 | `demos/ch04_truncated_pi_cost.py` | 只在终端输出，不写文件 |

外部代码（出处）：无。模型图 model.svg 与单步图 step.svg 由 TikZ 绘制。

运行：
```sh
python3 demos/course25_dp_evaluation.py
python3 demos/course25_dp_control.py
python3 demos/course15_mdp_dp.py
python3 demos/v18_classic.py
python3 demos/mud_prediction_lens.py
python3 demos/ch04_truncated_pi_cost.py
```

## 参考数据

`assets/`（以及 `demos/NN-results/`）下复制了 9 个数据文件（json、csv 等），即课程目前使用的结果；图片没有复制，运行程序会重新画出。重跑会覆盖这些文件，可以先另存一份再对照。
