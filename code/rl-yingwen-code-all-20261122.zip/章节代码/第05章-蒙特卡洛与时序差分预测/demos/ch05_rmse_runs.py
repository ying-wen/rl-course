"""Online and batch error on the mud task, with run counts and standard errors.

11-21 审阅站请求 r1121-111024（第 5 章 p269、p272）。
Run: python3 demos/ch05_rmse_runs.py --figure assets/sample14-mctd/matched-steps-2000.pdf

Part 1 (p269): the same paired runs as ch05_matched_steps.py (first-visit MC with
1/N and with alpha=.05, online TD(0) with alpha=.05), now over RUNS independent
runs. The standard error of each final RMSE and of the TD - MC(alpha) gap is a
bootstrap over runs.

Part 2 (p272): batch first-visit MC against batch TD(0) on groups of K episodes.
Batch TD(0) on a table converges to the certainty-equivalence value: from the
counts, S4 succeeds with probability p = K / (number of S4 visits), so
V(S4) = p / (1 - gamma (1 - p)) and V(S7) = gamma V(S4).
Batch first-visit MC averages first-visit returns: gamma^(L-1) for S4 and
gamma^L for S7, where L is the number of S4 visits in the episode.
"""
import argparse
from pathlib import Path

import numpy as np

from ch05_matched_steps import paired_run
from sample14_mctd import GAMMA, SUCCESS

RUNS, EPISODES, ALPHA = 2000, 500, .05
GROUPS, KS = 200_000, (1, 3, 10, 30, 100)
BOOT = 2000


def truth():
    v4 = SUCCESS / (1 - GAMMA * (1 - SUCCESS))
    return np.array([GAMMA * v4, v4])


def online(seed0=1000):
    final = np.stack([paired_run(seed, EPISODES, ALPHA)[-1] for seed in range(seed0, seed0 + RUNS)])
    sq = np.mean((final - truth()) ** 2, axis=2)  # runs x methods, averaged over S7, S4
    rmse = np.sqrt(sq.mean(axis=0))
    rng = np.random.default_rng(7)
    boot = np.empty((BOOT, 3))
    for b in range(BOOT):
        idx = rng.integers(0, RUNS, RUNS)
        boot[b] = np.sqrt(sq[idx].mean(axis=0))
    gap = boot[:, 2] - boot[:, 1]
    print(f"online, {RUNS} runs x {EPISODES} episodes, alpha={ALPHA}")
    for name, r, s in zip(("MC 1/N", "MC alpha", "TD alpha"), rmse, boot.std(axis=0)):
        print(f"  {name:9} RMSE {r:.4f}  SE {s:.4f}")
    print(f"  TD - MC(alpha) gap {rmse[2]-rmse[1]:.4f}  SE {gap.std():.4f}")


def batch(seed=11):
    rng = np.random.default_rng(seed)
    v = truth()
    print(f"batch, {GROUPS} groups per K")
    rows = []
    for k in KS:
        lengths = rng.geometric(SUCCESS, size=(GROUPS, k))  # S4 visits per episode
        mc4 = np.mean(GAMMA ** (lengths - 1), axis=1)
        mc = np.stack([GAMMA * mc4, mc4], axis=1)
        p = k / lengths.sum(axis=1)
        td4 = p / (1 - GAMMA * (1 - p))
        td = np.stack([GAMMA * td4, td4], axis=1)
        r_mc = np.sqrt(np.mean((mc - v) ** 2))
        r_td = np.sqrt(np.mean((td - v) ** 2))
        better = np.mean(np.sum((td - v) ** 2, axis=1) < np.sum((mc - v) ** 2, axis=1))
        rows.append((k, r_mc, r_td))
        print(f"  K={k:3}  MC {r_mc:.3f}  TD {r_td:.3f}  TD closer in {better:.0%} of groups")
    return rows


def figure(path):
    """Redraw the online curves of ch05_matched_steps.py with RUNS runs and slide fonts."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.ticker import FuncFormatter
    from plot_fonts import CJK_FAMILY, no_leading_zero, use_course_fonts
    use_course_fonts()
    est = np.stack([paired_run(seed, EPISODES, ALPHA) for seed in range(1000, 1000 + RUNS)])
    rmse = np.sqrt(np.mean((est - truth()) ** 2, axis=(0, 3)))
    # shown at ~.6 of a 16 cm slide (~9.4 cm); width 5.2 in -> scale .71; 11pt -> ~7.9pt
    fig, ax = plt.subplots(figsize=(5.2, 2.6), layout="constrained")
    x = np.arange(1, EPISODES + 1)
    lines = [("首访 MC，1/N", "#48616f", ":"), ("首访 MC，α = .05", "#ac452c", "--"),
             ("一步 TD，α = .05", "#096b76", "-")]
    for column, (label, color, style) in enumerate(lines):
        ax.plot(x, rmse[:, column], style, label=label, color=color, lw=1.8)
    ax.set(xscale="log", xlim=(1, EPISODES), ylim=(0, .51))
    ax.set_xlabel("已完成回合数", fontsize=11)
    ax.set_ylabel("均方根误差", fontsize=11)
    ticks = [1, 5, 20, 100, 500]
    ax.set_xticks(ticks, labels=[str(k) for k in ticks])
    ax.yaxis.set_major_formatter(FuncFormatter(no_leading_zero))
    ax.tick_params(labelsize=10)
    ax.spines[["top", "right"]].set_visible(False)
    ax.grid(axis="y", alpha=.18)
    ax.legend(frameon=False, fontsize=10, prop={"family": CJK_FAMILY, "size": 10})
    fig.savefig(path)
    plt.close(fig)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--figure", type=Path)
    parser.add_argument("--skip-online", action="store_true")
    args = parser.parse_args()
    batch()
    if not args.skip_online:
        online()
    if args.figure:
        figure(args.figure)


if __name__ == "__main__":
    main()
