"""Compare first-visit MC (two step sizes) and online TD on identical mud episodes.

Run: python3 demos/ch05_matched_steps.py --figure assets/sample14-mctd/matched-steps.pdf
(a .pdf figure path also writes the matching .png at 144 dpi)
Only the final scoring step uses the analytic values. Each curve is RMSE over
the two reachable states and all independent runs, evaluated at episode end.
"""
import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np

from sample14_mctd import GAMMA, SUCCESS, cjk_rc, discounted_returns, episode, mc_first_visit, td_step


def paired_run(seed, episodes, alpha):
    rng = np.random.default_rng(seed)
    states = ("S7", "S4")
    mc_mean, mc_constant, td = ({s: 0.0 for s in states} for _ in range(3))
    counts = {s: 0 for s in states}
    estimates = np.empty((episodes, 3, 2))
    for k in range(episodes):
        transitions = episode(rng)
        for state, reward, successor, done in transitions:
            td_step(td, state, reward, successor, done, alpha)
        mc_first_visit(transitions, mc_mean, counts)
        returns = discounted_returns(transitions)
        seen = set()
        for (state, _, _, _), target in zip(transitions, returns):
            if state not in seen:
                seen.add(state)
                mc_constant[state] += alpha * (target - mc_constant[state])
        estimates[k] = [[table[s] for s in states] for table in (mc_mean, mc_constant, td)]
    return estimates


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--figure", type=Path)
    args = parser.parse_args()
    episodes, alpha = 500, .05
    estimates = np.stack([paired_run(seed, episodes, alpha) for seed in range(1000, 1064)])
    mud_value = SUCCESS / (1 - GAMMA * (1 - SUCCESS))
    truth = np.array([GAMMA * mud_value, mud_value])
    rmse = np.sqrt(np.mean((estimates - truth) ** 2, axis=(0, 3)))
    print("episode     MC:1/N   MC:0.05   TD:0.05")
    for k in (1, 5, 20, 100, episodes):
        print(f"{k:7}     " + "     ".join(f"{x:.4f}" for x in rmse[k-1]))
    if args.figure:
        plt.rcParams.update({"font.family": "DejaVu Sans"})
        plt.rcParams.update(cjk_rc())
        fig, ax = plt.subplots(figsize=(7.5, 3.4), layout="constrained")
        x = np.arange(1, episodes+1)
        lines = [("首访 MC，1/N", "#48616f", ":"), ("首访 MC，α = 0.05", "#ac452c", "--"),
                 ("一步 TD，α = 0.05", "#096b76", "-")]
        for column, (label, color, style) in enumerate(lines):
            ax.plot(x, rmse[:, column], style, label=label, color=color, lw=2)
        ax.set(xscale="log", xlim=(1, episodes), ylim=(0, .51),
               xlabel="已完成回合数", ylabel="RMSE")
        ticks = [1, 5, 20, 100, 500]
        ax.set_xticks(ticks, labels=[str(k) for k in ticks])
        ax.spines[["top", "right"]].set_visible(False)
        ax.grid(axis="y", alpha=.18)
        ax.legend(frameon=False, fontsize=11)
        fig.savefig(args.figure)
        if args.figure.suffix == ".pdf":
            fig.savefig(args.figure.with_suffix(".png"), dpi=144)
        plt.close(fig)


if __name__ == "__main__":
    main()
