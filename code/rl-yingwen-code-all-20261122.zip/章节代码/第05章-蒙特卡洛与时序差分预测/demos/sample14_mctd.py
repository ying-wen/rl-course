"""MC and TD prediction on the course's fixed-policy mud task.

Run from any working directory:
    python3 sample14_mctd.py
Dependencies: numpy, matplotlib. No model is passed to either learner.

Task: reset at S7, take up, then repeatedly take up at S4.
S7 -> S4 has reward 0. At S4, up succeeds with probability .1;
success enters terminal G and gives reward 1. Failure stays in S4, reward 0.
The discount is .9. Analytical values are used only for checks and plots.

Outputs: figures (PDF/PNG), a complete one-episode trace, seed-level learning
records, and a report describing settings and independent numerical checks.
"""
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, Circle, FancyArrowPatch

GAMMA = 0.9
SUCCESS = 0.1
TEAL, RED, GOLD, INK, GRAY = "#087e8b", "#c65335", "#c4942a", "#182e38", "#61757d"
COLORS = [TEAL, RED]
# A transition is (state, reward, next_state, terminated); policy is fixed up.
# No action field is necessary because this prediction task has no choice.


def step(state, rng):
    """Only this environment function uses the true transition probability."""
    if state == "S7":
        return 0.0, "S4", False
    if state != "S4":
        raise ValueError("Reset after reaching terminal G")
    done = rng.random() < SUCCESS
    return float(done), "G" if done else "S4", done


def episode(rng):
    """Collect a genuinely completed episode; do not truncate its return."""
    state, records = "S7", []
    while True:
        reward, nxt, done = step(state, rng)
        records.append((state, reward, nxt, done))
        if done:
            return records
        state = nxt


# BEGIN returns

def discounted_returns(records, gamma=GAMMA):
    returns, g = [0.0] * len(records), 0.0
    for t in reversed(range(len(records))):
        g = records[t][1] + gamma * g
        returns[t] = g
    return returns
# END returns


# BEGIN mc

def mc_first_visit(records, values, counts, gamma=GAMMA):
    returns = discounted_returns(records, gamma)
    seen = set()
    for (state, _, _, _), g in zip(records, returns):
        if state not in seen:
            seen.add(state)
            counts[state] += 1
            values[state] += (g - values[state]) / counts[state]
# END mc


# BEGIN td

def td_step(values, state, reward, nxt, done, alpha, gamma=GAMMA):
    current = values[state]              # read the old table before writing
    tail = 0.0 if done else values[nxt]   # terminal value is zero
    target = reward + gamma * tail
    delta = target - current
    values[state] = current + alpha * delta
    return current, tail, target, delta, values[state]
# END td


# BEGIN training

def train(rng, n_episodes, alpha=0.05):
    """Same observed episodes, different update times; neither learner acts."""
    mc, td = {"S7": 0.0, "S4": 0.0}, {"S7": 0.0, "S4": 0.0}
    counts, rows, transitions = {"S7": 0, "S4": 0}, [], 0
    for k in range(1, n_episodes + 1):
        state, records = "S7", []
        while True:
            # 1. The environment generates one real transition.
            reward, nxt, done = step(state, rng)
            records.append((state, reward, nxt, done))
            # 2. TD writes now, before the next reward exists.
            td_step(td, state, reward, nxt, done, alpha)
            transitions += 1
            if done:
                break
            state = nxt
        # 3. Only after true termination are complete MC returns available.
        mc_first_visit(records, mc, counts)
        # 4. Compare both tables after exactly the same environmental data.
        rows.append([k, transitions, mc["S7"], mc["S4"], td["S7"], td["S4"]])
    return np.asarray(rows)
# END training


def batch_ab(alpha=0.05, tol=1e-13):
    """Sum all increments against one old table, then write once per sweep."""
    data = [("A", 0.0, "B", False), ("B", 0.0, "G", True)]
    data += [("B", 1.0, "G", True)] * 6 + [("B", 0.0, "G", True)]
    v = {"A": 0.0, "B": 0.0}
    history = [[0.0, 0.0]]
    for _ in range(10000):
        update = {"A": 0.0, "B": 0.0}
        for state, reward, nxt, done in data:
            update[state] += reward + (0.0 if done else v[nxt]) - v[state]
        new = {s: v[s] + alpha * update[s] for s in v}
        history.append([new["A"], new["B"]])
        if max(abs(new[s] - v[s]) for s in v) < tol:
            return new, np.asarray(history)
        v = new
    raise RuntimeError("batch TD did not converge")


def independent_checks():
    # (1) Closed geometric series vs independent two-state matrix solution.
    exact = np.array([GAMMA * SUCCESS / (1 - (1-SUCCESS)*GAMMA),
                      SUCCESS / (1 - (1-SUCCESS)*GAMMA)])
    p = np.array([[0., 1.], [0., 1-SUCCESS]])
    r = np.array([0., SUCCESS])
    matrix = np.linalg.solve(np.eye(2) - GAMMA*p, r)
    np.testing.assert_allclose(exact, matrix, rtol=0, atol=1e-14)
    # (2) Enumerated waiting times, not the Bellman recursion used above.
    k = np.arange(500)
    prob = SUCCESS * (1-SUCCESS)**k
    enum = np.sum(prob * GAMMA**k)
    assert abs(enum - exact[1]) < 1e-13
    # (3) Direct sums vs backward recursion, on a fixed illustrative path.
    records = [("S7",0.,"S4",False), ("S4",0.,"S4",False),
               ("S4",0.,"S4",False), ("S4",1.,"G",True)]
    returns = discounted_returns(records)
    direct = [sum(GAMMA**(j-t)*records[j][1] for j in range(t,len(records)))
              for t in range(len(records))]
    np.testing.assert_allclose(returns, direct, atol=1e-14)
    np.testing.assert_allclose(returns, [.729,.81,.9,1.], atol=1e-14)
    # (4) First visit must mean the earliest visit, not the last seen in reverse.
    mc, counts = {"S7":0.,"S4":0.}, {"S7":0,"S4":0}
    mc_first_visit(records, mc, counts)
    assert counts == {"S7":1,"S4":1}
    np.testing.assert_allclose([mc["S7"],mc["S4"]], [.729,.81])
    # (5) Independently hand-computed online writes, including the self-loop.
    td, trace = {"S7":.4,"S4":.5}, []
    for t,(s,reward,nxt,done) in enumerate(records):
        old,tail,y,d,new = td_step(td,s,reward,nxt,done,.2)
        trace.append(dict(t=t,state=s,reward=reward,next_state=nxt,terminated=done,
                          old_current=old,old_tail=tail,target=y,delta=d,new_current=new,
                          S7=td["S7"],S4=td["S4"]))
    np.testing.assert_allclose([x["new_current"] for x in trace],[.41,.49,.4802,.58416])
    # Terminal reward is kept. Nonterminal time limits must not set done=True.
    v={"S7":.4,"S4":.5}
    assert td_step(v,"S4",1.,"G",True,.2)[2] == 1.
    # (6) Batch TD fixed point from empirical normal equations, not its loop.
    vb,hist = batch_ab()
    empirical = np.linalg.solve(np.array([[1.,-1.],[0.,8.]]),np.array([0.,6.]))
    np.testing.assert_allclose([vb["A"],vb["B"]],empirical,atol=2e-12)
    # (7) Mean TD residual vs truth difference; both are different quantities.
    mean_delta = .9*(.9*.5-.5)+.1*(1-.5)
    assert abs(mean_delta-.005)<1e-15
    return exact, records, trace, hist, {
        "closed_form_values":dict(zip(["S7","S4"],exact.tolist())),
        "matrix_values":matrix.tolist(),"enumerated_S4":float(enum),
        "fixed_path_returns":returns,"first_visit_on_one_path":mc,
        "batch_TD":vb,"batch_MC":{"A":0.,"B":.75},
        "mean_TD_delta_at_half":mean_delta,"checks_passed":7}


def setup_style():
    plt.rcParams.update({"font.family":"DejaVu Sans","font.size":14,
                        "axes.labelsize":14,"axes.titlesize":16,
                        "xtick.labelsize":12,"ytick.labelsize":12,
                        "text.color":INK,"axes.labelcolor":INK,
                        "axes.spines.top":False,"axes.spines.right":False,
                        "axes.grid":False,"savefig.dpi":190,
                        "pdf.fonttype":42})
    plt.rcParams.update(cjk_rc())


def cjk_rc():
    """Keep DejaVu Sans for Latin text and digits; fall back to a CJK font for Chinese labels."""
    from matplotlib import font_manager
    for font in ["/System/Library/Fonts/PingFang.ttc", "/System/Library/Fonts/STHeiti Light.ttc"]:
        if Path(font).exists():
            font_manager.fontManager.addfont(font)
            return {"font.family": ["DejaVu Sans", font_manager.FontProperties(fname=font).get_name()]}
    return {}


def save(fig, out, name):
    fig.savefig(out/(name+".pdf"),bbox_inches="tight",facecolor="white")
    fig.savefig(out/(name+".png"),bbox_inches="tight",facecolor="white")
    plt.close(fig)


def arrow(ax,p,q,color=TEAL,lw=2.2,**kw):
    ax.add_patch(FancyArrowPatch(p,q,arrowstyle="-|>",mutation_scale=16,
                                color=color,lw=lw,**kw))


def grid(ax, values=None, title="", policy=True):
    places={(0,2):"S1",(1,2):"S2",(2,2):"G",(0,1):"S3",(2,1):"S4",
            (0,0):"S5",(1,0):"S6",(2,0):"S7"}
    for x in range(3):
        for y in range(3):
            s=places.get((x,y)); active=s in ("S7","S4","G")
            fill=INK if s is None else "#f0f2f3" if not active else "#f7e4bb" if s=="S4" else "#dfefed"
            ax.add_patch(Rectangle((x,y),1,1,facecolor=fill,edgecolor="#9caeb1",lw=.8))
            if s:
                ax.text(x+.08,y+.83,s,fontsize=12,color=INK if active else "#9caeb1")
                if s=="G":ax.text(x+.5,y+.43,"终止",ha="center",fontsize=12)
                elif active and values:
                    ax.text(x+.5,y+.48,f"{values[s]:.3f}",ha="center",fontsize=19,fontweight="bold")
                elif not active:ax.text(x+.5,y+.43,"—",ha="center",color="#aab4b8",fontsize=16)
                if policy and s in ("S7","S4"):arrow(ax,(x+.5,y+.12),(x+.5,y+.3),lw=1.8)
    ax.set(xlim=(-.05,3.05),ylim=(-.05,3.05),aspect="equal");ax.axis("off")
    ax.set_title(title,pad=10)


def plot_seed7(out, exact, example, alpha):
    """Seed 7 final value maps and per-episode estimates (Chinese labels)."""
    with plt.rc_context(cjk_rc()):
        # Seed 7 final maps; arrows stay fixed, only estimates are learned.
        fig,axs=plt.subplots(1,3,figsize=(10.1,3.7))
        end=example[-1]
        for ax,v,title in [(axs[0],{"S7":end[2],"S4":end[3]},"首访 MC：回报平均"),
                           (axs[1],{"S7":end[4],"S4":end[5]},f"TD(0)：α = {alpha:g}"),
                           (axs[2],dict(zip(["S7","S4"],exact)),"解析价值（参照）")]:grid(ax,v,title)
        save(fig,out,"learned-values")
        fig,axs=plt.subplots(1,2,figsize=(10.4,3.2))
        for ax,j,s in [(axs[0],0,"S7"),(axs[1],1,"S4")]:
            ax.plot(example[:,0],example[:,2+j],color=TEAL,lw=1.5,label="首访 MC，1/N")
            ax.plot(example[:,0],example[:,4+j],color=RED,lw=1.3,label=f"TD(0)，α = {alpha:g}")
            ax.axhline(exact[j],color=GRAY,ls="--",lw=1.4,label="真实价值")
            ax.set(xlabel="已完成回合数",ylabel="价值估计",title=s,ylim=(-.05,1.05))
        axs[1].legend(fontsize=10,loc="upper right");save(fig,out,"one-seed-learning")


def make_figures(out, exact, records, trace, histories, example, alpha):
    # Task: the grid and its actual state transition graph, not a text-module map.
    fig,ax=plt.subplots(figsize=(4.4,4.4));grid(ax,title="");save(fig,out,"task")
    # Complete episode: positions are temporal occurrences; S4 appears three times.
    fig,ax=plt.subplots(figsize=(10.8,2.5));ax.set(xlim=(-.5,4.5),ylim=(-.7,1.2));ax.axis("off")
    for i,s in enumerate(["S7","S4","S4","S4","G"]):
        ax.add_patch(Circle((i,.4),.18,facecolor="#f7e4bb" if s=="S4" else "#dfefed",edgecolor=INK,lw=1.4))
        ax.text(i,.4,s,ha="center",va="center",fontsize=17)
        ax.text(i,-.12,f"t={i}",ha="center",color=GRAY)
        if i<4:
            arrow(ax,(i+.2,.4),(i+.8,.4),RED if i==3 else TEAL)
            ax.text(i+.5,.79,f"R={int(records[i][1])}",ha="center",color=RED if i==3 else INK)
            ax.text(i,-.5,f"G={GAMMA**(3-i):.3g}",ha="center",color=TEAL,fontsize=17)
    save(fig,out,"episode")
    # MC vs TD availability is a time plot, not four boxes of text.
    fig,ax=plt.subplots(figsize=(10.5,2.6));ax.set(xlim=(-.2,4.6),ylim=(-.65,1.65))
    ax.hlines([0,1],0,4,color="#cad4d7",lw=2)
    ax.scatter([1,2,3,4],[1]*4,s=110,c=TEAL,zorder=3)
    ax.scatter([4],[0],s=150,c=RED,zorder=3)
    for i in [1,2,3,4]:ax.text(i,1.23,f"$\\delta_{i-1}$",ha="center",color=TEAL,fontsize=17)
    ax.text(4,-.4,"all returns",ha="center",color=RED)
    ax.axvline(4,color=GRAY,ls="--",lw=1)
    ax.set(yticks=[0,1],yticklabels=["MC","TD(0)"],xticks=range(5),xlabel="observed transitions")
    ax.tick_params(axis="y",length=0);ax.spines[["left","bottom"]].set_visible(False)
    save(fig,out,"availability")
    # One real online update sequence from the specified illustrative episode.
    fig,axs=plt.subplots(1,2,figsize=(10.5,3.3),sharex=True)
    for ax,s,initial in zip(axs,["S7","S4"],[.4,.5]):
        vals=[initial]+[z[s] for z in trace]
        ax.step(range(5),vals,where="post",lw=2.5,color=TEAL)
        ax.scatter(range(5),vals,s=45,color=TEAL,zorder=3)
        for t,v in enumerate(vals):ax.annotate(f"{v:.4g}",(t,v),xytext=(0,10 if t%2==0 else -20),textcoords="offset points",ha="center",fontsize=12)
        ax.set(xticks=range(5),ylim=(.34,.65),xlabel="completed transitions",title=s)
    axs[0].set_ylabel("current value estimate")
    save(fig,out,"online-writes")
    # Frozen-table mean residual: a sample can move away even below true value.
    fig,ax=plt.subplots(figsize=(7.8,3.5))
    x=np.linspace(0,1,100);ax.plot(x,.1-.19*x,color=TEAL,lw=2.8)
    ax.axhline(0,color=GRAY,lw=1);ax.axvline(exact[1],color=GRAY,ls="--",lw=1)
    ax.scatter([.5,exact[1]],[.005,0],color=[RED,TEAL],s=70,zorder=3)
    ax.annotate("$u^*=10/19$",(exact[1],0),xytext=(.65,.04),arrowprops=dict(arrowstyle="->",color=GRAY),fontsize=15)
    ax.annotate("$F(.5)=.005$",(.5,.005),xytext=(.08,-.05),arrowprops=dict(arrowstyle="->",color=GRAY),fontsize=15)
    ax.set(xlabel="current estimate u",ylabel="mean TD residual F(u)",ylim=(-.1,.11))
    save(fig,out,"mean-residual")
    # One-step target distribution vs complete return distribution.
    fig,axs=plt.subplots(1,2,figsize=(10.5,3.4),sharey=True)
    axs[0].vlines([.45,1],0,[.9,.1],colors=RED,lw=5)
    axs[0].scatter([.45,1],[.9,.1],s=55,color=RED)
    k=np.arange(35);vals=GAMMA**k;pr=SUCCESS*(1-SUCCESS)**k
    axs[1].vlines(vals,0,pr,color=TEAL,lw=2);axs[1].scatter(vals,pr,s=15,color=TEAL)
    # The omitted tail is represented as a bin with its correct mass.
    axs[1].bar(GAMMA**35/2,(1-SUCCESS)**35,width=GAMMA**35,color=GOLD)
    for ax,mean,title in zip(axs,[.505,exact[1]],["TD target: fixed V(S4)=.5","MC return from S4"]):
        ax.axvline(exact[1],color=GRAY,ls="--",lw=1.5,label="true value")
        ax.axvline(mean,color=RED if ax==axs[0] else TEAL,lw=1.5,label="target mean")
        ax.set(xlim=(0,1.04),ylim=(0,.98),xlabel="target / return",title=title)
    axs[0].set_ylabel("probability");axs[1].legend(fontsize=11,loc="upper right")
    save(fig,out,"target-distributions")
    plot_seed7(out, exact, example, alpha)
    errors=np.stack([histories[:,:,2:4]-exact,histories[:,:,4:6]-exact],axis=2)
    rmse=np.sqrt(np.mean(errors**2,axis=(0,3))) # seed and two visited states
    fig,ax=plt.subplots(figsize=(8.8,3.4))
    for j,label in enumerate(["first-visit MC, 1/N",f"TD(0), alpha={alpha:g}"]):ax.plot(np.arange(1,len(rmse)+1),rmse[:,j],color=COLORS[j],lw=2.3,label=label)
    ax.set(xlabel="completed episodes",ylabel="RMSE over seeds and S7/S4",ylim=(0,.65))
    ax.legend(fontsize=12);save(fig,out,"learning-rmse")
    # Batch A/B data: all eight records visible, grouped only by identical form.
    fig,ax=plt.subplots(figsize=(9.4,3.8));ax.set(xlim=(-2.3,4.5),ylim=(-.65,2.7));ax.axis("off")
    for y,count,nodes,rewards in [(2,"1 episode",[(0,"A"),(2,"B"),(4,"end")],[0,0]),
                                  (1,"6 episodes",[(2,"B"),(4,"end")],[1]),
                                  (0,"1 episode",[(2,"B"),(4,"end")],[0])]:
        ax.text(-2.15,y,count,va="center",fontsize=14)
        for x,s in nodes:
            ax.add_patch(Circle((x,y),.22,facecolor="#dfefed" if s!="end" else "#f0f2f3",edgecolor=INK,lw=1.3))
            ax.text(x,y,s,ha="center",va="center",fontsize=15)
        for ((x,_),(nx,_)),r in zip(zip(nodes,nodes[1:]),rewards):
            arrow(ax,(x+.24,y),(nx-.24,y),RED if r else TEAL)
            ax.text((x+nx)/2,y+.19,f"R={r}",ha="center",fontsize=15)
    save(fig,out,"ab-data")
    fig,ax=plt.subplots(figsize=(8.2,3.0))
    vb,bh=batch_ab()
    ax.plot(bh[:100,0],color=TEAL,lw=2.5,label="batch TD: A")
    ax.plot(bh[:100,1],color=RED,lw=2.5,label="batch TD: B")
    ax.axhline(.75,color=GRAY,ls="--",lw=1.2)
    ax.axhline(0,color=TEAL,ls=":",lw=2,label="batch MC: A")
    ax.set(xlabel="batch sweeps (no new experience)",ylabel="value estimate",ylim=(-.04,.85))
    ax.legend(fontsize=11,loc="lower right");save(fig,out,"ab-learning")
    return rmse


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--episodes",type=int,default=500)
    parser.add_argument("--seeds",type=int,default=64)
    parser.add_argument("--alpha",type=float,default=.05)
    parser.add_argument("--output",type=Path,default=Path(__file__).resolve().parents[1]/"assets"/"sample14-mctd")
    args=parser.parse_args()
    if args.episodes<2 or args.seeds<2 or not 0<args.alpha<=1:parser.error("episodes/seeds >=2 and 0<alpha<=1 required")
    out=args.output;out.mkdir(parents=True,exist_ok=True)
    exact,records,trace,batch_hist,checks=independent_checks()
    histories=np.stack([train(np.random.default_rng(1000+i),args.episodes,args.alpha) for i in range(args.seeds)])
    example=train(np.random.default_rng(7),args.episodes,args.alpha)
    setup_style();rmse=make_figures(out,exact,records,trace,histories,example,args.alpha)
    with (out/"one-episode-trace.csv").open("w",newline="") as f:
        writer=csv.DictWriter(f,fieldnames=list(trace[0]));writer.writeheader();writer.writerows(trace)
    with (out/"learning-by-seed.csv").open("w",newline="") as f:
        writer=csv.writer(f);writer.writerow(["seed","episode","real_transitions","MC_S7","MC_S4","TD_S7","TD_S4"])
        for i,run in enumerate(histories):
            for row in run:writer.writerow([1000+i,*row.tolist()])
    report={"task":{"discount":GAMMA,"S4_success_probability":SUCCESS,"start":"S7","policy":"up in S7 and S4","terminal_reward":1,"other_rewards":0},
            "experiment":{"seeds":list(range(1000,1000+args.seeds)),"episodes_per_seed":args.episodes,"MC":"first-visit sample mean","TD_alpha":args.alpha,"paired_data":True,"initial_values":0,"states_in_RMSE":["S7","S4"],"seed7_final":example[-1].tolist(),"real_transitions_range":[int(histories[:,-1,1].min()),int(histories[:,-1,1].max())]},
            "checks":checks,"fixed_illustrative_trace":trace,
            "final_RMSE":{"MC":float(rmse[-1,0]),"TD":float(rmse[-1,1])},
            "interpretation":"Prediction under one fixed policy. MC uses 1/N while TD uses constant alpha; this is not a tuned algorithm ranking. Exact values never enter model-free updates."}
    (out/"report.json").write_text(json.dumps(report,ensure_ascii=False,indent=2))
    print(json.dumps({"output":str(out),"checks_passed":checks["checks_passed"],"seed7_final":report["experiment"]["seed7_final"],"final_RMSE":report["final_RMSE"]},indent=2))


if __name__=="__main__":
    main()
