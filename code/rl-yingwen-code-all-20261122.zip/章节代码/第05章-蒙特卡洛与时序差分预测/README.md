# 第 5 章　蒙特卡洛与时序差分预测：程序

本目录可以单独运行：在本目录下执行下面的命令即可，结果写回本目录的 `assets/`。目录由 `rl-course/tools/export_chapter_code.py` 从课程目录生成，改程序请改课程目录里的原件，再重新导出。

## 准备

```sh
python3 -m pip install -r requirements.txt
```

需要的第三方包：matplotlib、numpy。复现附录要求 Python 3.10 或更新版本；核验时用的版本见下表。

## 运行（与复现附录相同）

```sh
python3 demos/sample14_mctd.py
python3 demos/ch05_matched_steps.py --figure assets/sample14-mctd/matched-steps.pdf
python3 demos/mud_prediction_lens.py
python3 demos/v18_classic.py
python3 demos/v17_classic.py
```

## 本目录的程序

| 程序 | 说明 | 核验 |
|---|---|---|
| `demos/sample14_mctd.py` | MC and TD prediction on the course's fixed-policy mud task. | 通过（4 秒） |
| `demos/mud_prediction_lens.py` | One prediction, three sources of information (Chapters 3–5). | 通过（0 秒） |
| `demos/ch05_rmse_runs.py` | Online and batch error on the mud task, with run counts and standard errors. | 通过（16 秒） |
| `demos/v18_classic.py` | Exact teaching objects for v18 chapters 2--6. No training. | 通过（2 秒） |
| `demos/v17_classic.py` | Small exact checks and instructional figures for chapters 3--6. | 通过（1 秒） |
| `demos/ch05_matched_steps.py` | Compare first-visit MC (two step sizes) and online TD on identical mud episodes. | 通过（1 秒） |

被上面程序 import 的本课模块：`demos/mud_world.py`、`demos/plot_fonts.py`。

## 复现附录本章一节

本章的四步轨迹、学习曲线、价值表、误差曲线和批量 A/B 例来自本课的模拟。解析价值只用于核对与作图，MC 与 TD 的更新从不读取它，所以曲线反映的是两种方法从样本中学到的结果。冻结表上 TD 误差的分解是精确计算，由另一个程序作图。

| 位置 | 结果 | 设置 | 程序 | 数据与输出 |
|---|---|---|---|---|
| 5.1 节（课件 `sample14-mctd-episode`、`sample14-mctd-mc-code`） | 固定向上策略的任务图；一回合四步轨迹及各次访问后的回报 .729、.81、.9、1；首次访问回报 S7 为 .729、S4 为 .81 | 泥地固定策略：从 S7 出发，S7 与 S4 都向上，S4 成功概率 .1，$\gamma=.9$ | `demos/sample14_mctd.py` | `assets/sample14-mctd/task.png`、`assets/sample14-mctd/episode.png`、`assets/sample14-mctd/report.json` |
| 5.2 节“一步转移与后继价值”（课件 `sample14-mctd-td-write`） | 旧值 .5、步长 .2 时 TD 新估计 .49，常步长 MC 新估计 .562 | 一步算术，程序默认 `--old 0.5`、`--alpha 0.2` | `demos/mud_prediction_lens.py` | 只在终端输出，不写文件 |
| 5.2 节“TD 误差与价值更新”（课件 `sample14-mctd-td-path`、`sample14-mctd-when`） | 同一四步轨迹上的在线 TD 表：目标 .45、.45、.441、1，更新值 .41、.49、.4802、.58416；两表项的逐步更新图；TD 与 MC 可更新时刻的对照 | 固定示例轨迹 S7→S4→S4→S4→G，初值 $V(\mathrm{S7})=.4,V(\mathrm{S4})=.5$，TD 步长 .2 | `demos/sample14_mctd.py` | `assets/sample14-mctd/one-episode-trace.csv`、`assets/sample14-mctd/online-writes.png`、`assets/sample14-mctd/availability.png` |
| 5.3 节（课件 `sample14-mctd-fixedpoint`、`sample14-mctd-noise`） | 平均 TD 误差随当前估计的变化，在真值处为零；旧表 .5 时平均 TD 误差 .005；固定尾值时的 TD 目标分布与 MC 回报分布 | 按模型对两种后果求期望的精确计算 | `demos/sample14_mctd.py` | `assets/sample14-mctd/mean-residual.png`、`assets/sample14-mctd/target-distributions.png`、`assets/sample14-mctd/report.json` |
| 5.4 节（课件 `sample14-mctd-values`、`sample14-mctd-learning`） | 500 回合、5473 次真实转移后，MC 为 $V(\mathrm{S7})=.47643,V(\mathrm{S4})=.52936$，TD 为 .49179、.52600；解析值 $9/19,10/19$；同一运行的逐回合估计 | 本课的模拟：首次访问 MC 用样本均值，TD(0) 步长 .05，零初值，单次运行，随机数种子 7，500 回合 | `demos/sample14_mctd.py` | `assets/sample14-mctd/learned-values.png`、`assets/sample14-mctd/one-seed-learning.png`、`assets/sample14-mctd/report.json`、`assets/sample14-mctd/learning-by-seed.csv` |
| 5.4 节（课件 `sample14-mctd-rmse`） | 第 500 回合的 RMSE：步长 $1/N$ 的 MC 为 .0129，固定步长 .05 的 MC 为 .0451，TD 为 .0481（各值标准误不超过 .0007）；TD 比 MC 高 .0031（标准误 .0006） | 本课的模拟：三个估计器共用同一批回合，每次运行 500 回合，零初值，独立运行 2000 次；RMSE 对 S7、S4 两个状态与全部运行取平方平均后开方，标准误对运行做自助法重抽样。同一程序还给出 5.5 节批量 MC 与批量 TD 的对照（每个 $K$ 取 200000 组） | `demos/ch05_rmse_runs.py`（调用 ch05_matched_steps.py 的配对运行） | `assets/sample14-mctd/matched-steps-2000.pdf`；数字由程序输出到终端 |
| 5.5 节“八个回合中的共享后继”（课件 `sample14-mctd-ab-data`） | A 出现一次、B 出现八次的数据；批量 TD 给 A、B 都是 .75，批量 MC 给 A 为 0、B 为 .75 | 固定八个回合，反复做冻结旧表的批量 TD 更新直到收敛 | `demos/sample14_mctd.py` | `assets/sample14-mctd/ab-data.png`、`assets/sample14-mctd/ab-learning.png`、`assets/sample14-mctd/report.json` |
| 5.7 节“完整回报误差与一步 TD 误差” | 冻结 $V(\mathrm{S7})=.4,V(\mathrm{S4})=.5$ 时四项折扣 TD 误差之和 .329，等于 .729 减 .4 | 精确计算，无训练 | `demos/v18_classic.py` | `assets/v18-classic/frozen-td-sum.png`、`assets/v18-classic/checks.json` |
| “参考”后的补充计算 | 五元组映射、泥地概率树与单步控制图 | 精确模型，无训练 | `demos/v17_classic.py` | `assets/v17-classic/mdp-objects.png`、`assets/v17-classic/probability-tree.png`、`assets/v17-classic/control-feedback.png`、`assets/v17-classic/checks.json` |

外部代码（出处）：无。随机游走上批量 TD 与批量 MC 的比较取自 Sutton（1988）勘误版图 3；统一视角图取自 Sutton 与 Barto 第一版图 10.1；备份图取自 Silver 的课程讲义。

运行：
```sh
python3 demos/sample14_mctd.py
python3 demos/ch05_matched_steps.py --figure assets/sample14-mctd/matched-steps.pdf
python3 demos/mud_prediction_lens.py
python3 demos/v18_classic.py
python3 demos/v17_classic.py
```

## 参考数据

`assets/`（以及 `demos/NN-results/`）下复制了 6 个数据文件（json、csv 等），即课程目前使用的结果；图片没有复制，运行程序会重新画出。重跑会覆盖这些文件，可以先另存一份再对照。
