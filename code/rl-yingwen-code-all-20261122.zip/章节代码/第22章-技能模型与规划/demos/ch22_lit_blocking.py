# -*- coding: utf-8 -*-
"""第 22 章文献原型：Sutton 与 Barto 第 2 版例 8.2 堵路迷宫（图 8.4）。

论文（书）设定（按文献核对报告）：前 1000 步最短路在挡板右侧；1000 步后右侧被堵、
左侧开一条更长的路；横轴 0-3000 步，纵轴为累计奖励；Dyna-Q+ 的曲线始终高于 Dyna-Q。
Dyna-Q+ 在规划中用 r + kappa*sqrt(tau) 作奖励，tau 为该状态-动作对上次实际尝试以来
的步数；规划中允许从未试过的动作，其初始模型为回到原状态、奖励为 0。

本课自定（书中正文没有写迷宫尺寸，按图重画，尺寸待核）：
- 6 行 9 列，起点在底行第 4 列，目标在右上角；挡板在第 4 行（自上数），
  前 1000 步占第 1-8 列（右端留口），之后占第 2-9 列（左端留口）；
- 到目标得 +1 并回到起点，其余为 0；主设定 gamma=0.95，alpha=1.0，epsilon=0.1，
  每个真实步后规划 n=50 次，kappa=1e-3；3000 步，RUNS 次独立运行；
- 另做一个小扫描：n 取 10/50，alpha 取 0.5/1.0，kappa 取 1e-4/1e-3，各 RUNS 次，
  只记第 1000 步与第 3000 步的累计奖励，看“Dyna-Q+ 始终更高”对参数是否敏感。

只用 numpy。用法：
    python3 demos/ch22_lit_blocking.py [运行次数，默认 30]
输出写 assets/ch22-lit-blocking/results.json。
"""
import json, os, sys, time
import numpy as np

ROWS, COLS = 6, 9
START, GOAL = (5, 3), (0, 8)
MOVES = [(-1, 0), (1, 0), (0, -1), (0, 1)]
CHANGE, T = 1000, 3000
GAMMA, ALPHA, EPS, NPLAN, KAPPA = 0.95, 1.0, 0.1, 50, 1e-3


def walls(t):
    return {(3, c) for c in (range(0, 8) if t < CHANGE else range(1, 9))}


def env_step(s, a, wl):
    r, c = s[0] + MOVES[a][0], s[1] + MOVES[a][1]
    if not (0 <= r < ROWS and 0 <= c < COLS) or (r, c) in wl:
        r, c = s
    if (r, c) == GOAL:
        return START, 1.0
    return (r, c), 0.0


def run(rng, plus):
    Q = np.zeros((ROWS, COLS, 4))
    model = {}
    last = np.zeros((ROWS, COLS, 4))         # 上次实际尝试的时刻
    seen = set()                              # 实际到过的状态
    s = START
    cum = np.zeros(T)
    total = 0.0
    for t in range(T):
        wl = walls(t)
        seen.add(s)
        if rng.random() < EPS:
            a = int(rng.integers(4))
        else:
            q = Q[s]
            a = int(rng.choice(np.flatnonzero(q == q.max())))
        s2, r = env_step(s, a, wl)
        total += r
        cum[t] = total
        Q[s][a] += ALPHA * (r + GAMMA * Q[s2].max() - Q[s][a])
        model[(s, a)] = (s2, r)
        last[s][a] = t
        # 规划
        if plus:
            keys = [(x, b) for x in seen for b in range(4)]
        else:
            keys = list(model.keys())
        for _ in range(NPLAN):
            x, b = keys[rng.integers(len(keys))]
            x2, rr = model.get((x, b), (x, 0.0))
            if plus:
                rr = rr + KAPPA * np.sqrt(t - last[x][b])
            Q[x][b] += ALPHA * (rr + GAMMA * Q[x2].max() - Q[x][b])
        s = s2
    return cum


def main():
    global NPLAN, ALPHA, KAPPA
    runs = int(sys.argv[1]) if len(sys.argv) > 1 else 30
    t0 = time.time()
    rng = np.random.default_rng(20261119)
    out = dict(rows=ROWS, cols=COLS, start=START, goal=GOAL, change=CHANGE, steps=T, runs=runs,
               gamma=GAMMA, alpha=ALPHA, epsilon=EPS, n_planning=NPLAN, kappa=KAPPA)
    for name, plus in (("DynaQ", False), ("DynaQplus", True)):
        C = np.array([run(rng, plus) for _ in range(runs)])
        mean = C.mean(0)
        se = C.std(0, ddof=1) / np.sqrt(runs)
        pts = list(range(0, T + 1, 100))
        out[name] = dict(
            curve=[[p, float(mean[min(p, T - 1)])] for p in pts],
            at={str(p): [float(mean[p - 1]), float(se[p - 1])] for p in (1000, 1500, 2000, 3000)},
            gain_after=[float((C[:, -1] - C[:, CHANGE - 1]).mean()),
                        float((C[:, -1] - C[:, CHANGE - 1]).std(ddof=1) / np.sqrt(runs))],
            # 改路后第一次再拿到奖励的步数（相对第 1000 步）
            first_reward_after=float(np.mean([int(np.argmax(c[CHANGE:] > c[CHANGE - 1])) + 1 for c in C])),
        )
        print(name, out[name]["at"], "after", out[name]["gain_after"], "first", out[name]["first_reward_after"],
              f"{time.time()-t0:.1f}s", flush=True)
    main_set = (NPLAN, ALPHA, KAPPA)
    sweep = []
    for n in (10, 50):
        for al in (0.5, 1.0):
            for k in (1e-4, 1e-3):
                NPLAN, ALPHA, KAPPA = n, al, k
                A = np.array([run(rng, False) for _ in range(runs)])
                B = np.array([run(rng, True) for _ in range(runs)])
                above = float(np.mean(B.mean(0)[99:] >= A.mean(0)[99:]))
                sweep.append(dict(n=n, alpha=al, kappa=k,
                                  dynaq=[float(A[:, 999].mean()), float(A[:, -1].mean())],
                                  dynaqplus=[float(B[:, 999].mean()), float(B[:, -1].mean())],
                                  frac_steps_plus_above=above))
                print(sweep[-1], f"{time.time()-t0:.1f}s", flush=True)
    NPLAN, ALPHA, KAPPA = main_set
    out["sweep"] = sweep
    out["seconds"] = round(time.time() - t0, 1)
    d = os.path.join(os.path.dirname(__file__), "..", "assets", "ch22-lit-blocking")
    os.makedirs(d, exist_ok=True)
    with open(os.path.join(d, "results.json"), "w") as f:
        json.dump(out, f, ensure_ascii=False, indent=1)


if __name__ == "__main__":
    main()
