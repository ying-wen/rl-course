# -*- coding: utf-8 -*-
"""第 22 章文献原型：Sutton 等 (2023) 尊重奖励的子任务，两房间例。

出处：R. S. Sutton, M. C. Machado, G. Z. Holland, D. Szepesvari, F. Timbers,
B. Tanner, A. White. Reward-respecting subtasks for model-based reinforcement
learning. Artificial Intelligence 324 (2023) 104001。图 1（两房间）。

论文设定（按文献核对报告）：起点在一个房间，终止目标在另一个房间，中间一个走廊；
到达目标得 +1，起点到走廊之间的灰色区域每步 -1；gamma=0.99；最优路线绕开负奖励区，
v*(s0)=0.99^17≈0.843。论文结论：用尊重奖励的 option 规划明显快于用最短路 option
或只用原始动作，而最短路 option 甚至慢于只用动作（100 次运行平均）。

本课自定（论文图的格数未核，按“最优 18 步、v*(s0)=0.99^17”重构布局）：
- 左房间 5x5，右房间 5x7，中间墙上一个走廊；起点在左房间中行最左；灰色区为
  起点与走廊之间的 3x3 块；目标在右房间右上角；确定性移动，撞墙不动；
- 进入灰格得 -1，进入目标得 +1 并终止；
- 两种走廊 option（从左房间任一格出发，到走廊停止）：
  最短路 option：按步数最短走到走廊，不看奖励（同长时按 上、下、左、右 的次序取第一个）；
  尊重奖励的 option：内部回报 = 真实奖励 + 到走廊时的停止奖金 1，取最优内部策略；
- 规划：精确模型上的同步值迭代，V 从 0 开始，记起点估值 V_k(s0) 逐轮的变化。
  论文用的是边学边用的模型与样本规划，这里只是最简单的一种规划。

只用 numpy。用法：
    python3 demos/ch22_lit_rrs.py
输出写 assets/ch22-lit-rrs/results.json。
"""
import json, os, time
import numpy as np

LAYOUT = [
    "###############",
    "#.....#.......#",
    "#.ggg.#.......#",
    "#.ggg.........#",
    "#.ggg.#.......#",
    "#.....#.......#",
    "###############",
]
H, W = len(LAYOUT), len(LAYOUT[0])
CELLS = [(r, c) for r in range(H) for c in range(W) if LAYOUT[r][c] != "#"]
IDX = {rc: i for i, rc in enumerate(CELLS)}
N = len(CELLS)
MOVES = [(-1, 0), (1, 0), (0, -1), (0, 1)]
NEXT = [[IDX.get((r + dr, c + dc), i) for dr, dc in MOVES] for i, (r, c) in enumerate(CELLS)]
GAMMA = 0.99
S0 = IDX[(3, 1)]
HALLWAY = IDX[(3, 6)]
GOAL = IDX[(1, 13)]
GRAY = {IDX[rc] for rc in CELLS if LAYOUT[rc[0]][rc[1]] == "g"}
LEFT = {IDX[(r, c)] for r in range(1, 6) for c in range(1, 6)}


def reward(s2):
    if s2 == GOAL:
        return 1.0
    return -1.0 if s2 in GRAY else 0.0


def bfs(target, allowed):
    dist = {target: 0}
    fr = [target]
    while fr:
        nx = []
        for x in fr:
            for y in NEXT[x]:
                if y in allowed and y not in dist:
                    dist[y] = dist[x] + 1
                    nx.append(y)
        fr = nx
    return dist


def path_from_policy(pol, s, stop):
    path = []
    for _ in range(200):
        if s in stop:
            break
        s = NEXT[s][pol[s]]
        path.append(s)
    return path


def sp_option():
    d = bfs(HALLWAY, LEFT | {HALLWAY})
    pol = {s: min(range(4), key=lambda a: d.get(NEXT[s][a], 10 ** 6)) for s in LEFT}
    return {s: path_from_policy(pol, s, {HALLWAY}) for s in LEFT}


def rr_option(bonus=1.0):
    V = np.zeros(N)
    for _ in range(500):
        Vn = V.copy()
        for s in LEFT:
            Vn[s] = max(reward(NEXT[s][a]) + GAMMA * (bonus if NEXT[s][a] == HALLWAY else V[NEXT[s][a]])
                        for a in range(4))
        V = Vn
    pol = {}
    for s in LEFT:
        q = [reward(NEXT[s][a]) + GAMMA * (bonus if NEXT[s][a] == HALLWAY else V[NEXT[s][a]]) for a in range(4)]
        pol[s] = int(np.argmax(q))
    return {s: path_from_policy(pol, s, {HALLWAY}) for s in LEFT}


def option_model(paths):
    """路径 -> (折扣奖励, 折扣, 终点)。"""
    m = {}
    for s, p in paths.items():
        r, disc = 0.0, 1.0
        for x in p:
            r += disc * reward(x)
            disc *= GAMMA
            if x == GOAL:
                break
        m[s] = (r, disc, p[-1])
    return m


def value_iteration(option_models, iters=40):
    V = np.zeros(N)
    hist = [float(V[S0])]
    allV = [V.copy()]
    for _ in range(iters):
        Vn = np.zeros(N)
        for s in range(N):
            if s == GOAL:
                continue
            best = max(reward(NEXT[s][a]) + GAMMA * V[NEXT[s][a]] for a in range(4))
            for om in option_models:
                if s in om:
                    r, disc, end = om[s]
                    best = max(best, r + disc * V[end])
            Vn[s] = best
        V = Vn
        hist.append(float(V[S0]))
        allV.append(V.copy())
    return hist, allV


def main():
    t0 = time.time()
    sp, rr = sp_option(), rr_option()
    msp, mrr = option_model(sp), option_model(rr)
    out = dict(layout=LAYOUT, gamma=GAMMA, n_cells=N)
    res = {}
    for name, oms in (("A", []), ("A+SP", [msp]), ("A+RR", [mrr])):
        hist, allV = value_iteration(oms)
        vstar = hist[-1]
        first = next(k for k, v in enumerate(hist) if abs(v - vstar) <= 0.01 * abs(vstar))
        res[name] = dict(v_s0=hist, v_star_s0=vstar, iters_to_1pct=first)
        print(name, "v*(s0)=", round(vstar, 4), "iters within 1%:", first, [round(x, 3) for x in hist[:20]])
    out["planning"] = res
    out["v_star_check"] = [GAMMA ** 17, res["A"]["v_star_s0"]]
    vstar_all = value_iteration([], 60)[1][-1]
    out["sp_option_from_s0"] = dict(steps=len(sp[S0]), gray=sum(x in GRAY for x in sp[S0]),
                                    value_then_optimal=msp[S0][0] + msp[S0][1] * float(vstar_all[HALLWAY]))
    out["rr_option_from_s0"] = dict(steps=len(rr[S0]), gray=sum(x in GRAY for x in rr[S0]),
                                    value_then_optimal=mrr[S0][0] + mrr[S0][1] * float(vstar_all[HALLWAY]))
    out["v_star_hallway"] = float(vstar_all[HALLWAY])
    out["seconds"] = round(time.time() - t0, 2)
    print({k: out[k] for k in ("v_star_check", "sp_option_from_s0", "rr_option_from_s0", "v_star_hallway")})
    d = os.path.join(os.path.dirname(__file__), "..", "assets", "ch22-lit-rrs")
    os.makedirs(d, exist_ok=True)
    with open(os.path.join(d, "results.json"), "w") as f:
        json.dump(out, f, ensure_ascii=False, indent=1)


if __name__ == "__main__":
    main()
