# -*- coding: utf-8 -*-
"""第 22 章文献原型：Wan、Naik 与 Sutton (2021) 的持续式四房间。

出处：Y. Wan, A. Naik, R. S. Sutton. Average-Reward Learning and Planning with
Options. NeurIPS 2021。图 1（环境）、图 2（inter-option Differential Q-learning，G1）。

论文设定（按文献核对报告）：智能体反复从起点走到目标，进入目标得 +1，其余为 0；
8 个走廊 option 加 4 个原始动作，共 12 个；最短路 16 步，最优奖励率 1/16=0.0625；
epsilon=0.1，200,000 步，30 次运行，alpha=2^-3，eta=10^-1（论文另列 beta=2^-1）。

本课自定（论文图中位置未逐格核对）：
- 104 格的 13x13 四房间布局，确定性移动，撞墙不动；
- 起点取左上角 (1,1)，目标 G1 取右下房间 (10,8)，使最短路恰为 16 步；
- 进入目标得 +1 后，下一步从起点重新出发（不复位学习器，计时不停）；
- 走廊 option：在本房间（与另一走廊）内沿最短路走向目标走廊，出房间即停；
  在起始集之外被选中时，随机走一步后停止（对“无标记格子中均匀随机行动”的本课解读）；
- 更新用不带时长估计的简化写法：option 交回后
  delta = R - Rbar * tau + max_o' Q(S', o') - Q(S, O)，Q += alpha*delta，Rbar += eta*alpha*delta；
  论文列出的 beta 本课未用。

只用 numpy。用法：
    python3 demos/ch22_lit_wan_fourrooms.py [运行次数，默认 30] [步数，默认 200000]
输出写 assets/ch22-lit-wan-fourrooms/results.json。
"""
import json, os, sys, time
import numpy as np

LAYOUT = [
    "#############",
    "#.....#.....#",
    "#.....#.....#",
    "#...........#",
    "#.....#.....#",
    "#.....#.....#",
    "##.####.....#",
    "#.....###.###",
    "#.....#.....#",
    "#.....#.....#",
    "#...........#",
    "#.....#.....#",
    "#############",
]
H, W = len(LAYOUT), len(LAYOUT[0])
CELLS = [(r, c) for r in range(H) for c in range(W) if LAYOUT[r][c] == "."]
IDX = {rc: i for i, rc in enumerate(CELLS)}
N = len(CELLS)
MOVES = [(-1, 0), (1, 0), (0, -1), (0, 1)]
NEXT = [[IDX.get((r + dr, c + dc), i) for dr, dc in MOVES] for i, (r, c) in enumerate(CELLS)]
HALL = {"N": (3, 6), "W": (6, 2), "E": (7, 9), "S": (10, 6)}
ROOMS = {
    "TL": (lambda r, c: 1 <= r <= 5 and 1 <= c <= 5, ("N", "W")),
    "TR": (lambda r, c: 1 <= r <= 6 and 7 <= c <= 11, ("N", "E")),
    "BL": (lambda r, c: 7 <= r <= 11 and 1 <= c <= 5, ("W", "S")),
    "BR": (lambda r, c: 8 <= r <= 11 and 7 <= c <= 11, ("E", "S")),
}
START = IDX[(1, 1)]
GOAL = IDX[(10, 8)]


def bfs(target, allowed):
    dist = {target: 0}
    fr = [target]
    while fr:
        nx = []
        for x in fr:
            for y in NEXT[x]:
                if y in allowed and y not in dist:
                    dist[y] = dist[x] + 1
                    nx.append(y)
        fr = nx
    return dist


def build_options():
    opts = []
    for name, (f, halls) in ROOMS.items():
        room = {IDX[rc] for rc in CELLS if f(*rc)}
        for h in halls:
            t = IDX[HALL[h]]
            other = IDX[HALL[[x for x in halls if x != h][0]]]
            d = bfs(t, room | {t, other})
            pol = {}
            for s in room | {other}:
                best = min(range(4), key=lambda a: d.get(NEXT[s][a], 10 ** 6))
                pol[s] = best
            opts.append(dict(room=room, pol=pol))
    return opts


OPTS = build_options()


def run(rng, use_a, use_h, T, alpha=2 ** -3, eta=0.1, eps=0.1, window=10000, Q=None, learn=True):
    choices = []
    if use_a:
        choices += [("a", a) for a in range(4)]
    if use_h:
        choices += [("o", k) for k in range(len(OPTS))]
    nc = len(choices)
    if Q is None:
        Q = np.zeros((N, nc))
    rbar = 0.0
    s, t = START, 0
    rewards = np.zeros(T)
    while t < T:
        if rng.random() < eps:
            j = int(rng.integers(nc))
        else:
            q = Q[s]
            m = q.max()
            js = np.flatnonzero(q == m)
            j = int(js[rng.integers(len(js))]) if len(js) > 1 else int(js[0])
        kind, x = choices[j]
        R, tau, s0 = 0.0, 0, s
        if kind == "a":
            s2 = NEXT[s][x]
            tau = 1
            if s2 == GOAL:
                R, s2 = 1.0, START
                rewards[t] = 1.0
            t += 1
            s = s2
        else:
            opt = OPTS[x]
            while t < T:
                a = opt["pol"].get(s)
                if a is None:
                    a = int(rng.integers(4))
                s2 = NEXT[s][a]
                tau += 1
                if s2 == GOAL:
                    R += 1.0
                    rewards[t] = 1.0
                    t += 1
                    s = START
                    break
                t += 1
                s = s2
                if s not in opt["room"]:
                    break
        if learn:
            delta = R - rbar * tau + Q[s].max() - Q[s0, j]
            Q[s0, j] += alpha * delta
            rbar += eta * alpha * delta
    nb = T // window
    return rewards[: nb * window].reshape(nb, window).mean(1), rbar, Q


def main():
    runs = int(sys.argv[1]) if len(sys.argv) > 1 else 30
    T = int(sys.argv[2]) if len(sys.argv) > 2 else 200000
    t0 = time.time()
    d_opt = bfs(GOAL, set(range(N)))[START]
    out = dict(n_cells=N, layout=LAYOUT, start=CELLS[START], goal=CELLS[GOAL],
               shortest_path=d_opt, optimal_rate=1.0 / d_opt, runs=runs, steps=T,
               alpha=2 ** -3, eta=0.1, epsilon=0.1, window=10000)
    rng = np.random.default_rng(20261119)
    res = {}
    for name, ua, uh in (("A", 1, 0), ("H", 0, 1), ("AuH", 1, 1)):
        curves, rbars, greedy = [], [], []
        for _ in range(runs):
            c, rb, Q = run(rng, ua, uh, T)
            curves.append(c)
            rbars.append(rb)
            # 训练结束后冻结 Q，按贪心（epsilon=0）再走 10,000 步，看学到的策略本身的奖励率
            g, _, _ = run(rng, ua, uh, 10000, eps=0.0, Q=Q.copy(), learn=False)
            greedy.append(float(g.mean()))
        C = np.array(curves)
        mean = C.mean(0)
        se = C.std(0, ddof=1) / np.sqrt(runs)
        last5 = C[:, -5:].mean(1)
        res[name] = dict(curve=[float(x) for x in mean], se=[float(x) for x in se],
                         last50k=[float(last5.mean()), float(last5.std(ddof=1) / np.sqrt(runs))],
                         first50k=[float(C[:, :5].mean()), float(C[:, :5].mean(1).std(ddof=1) / np.sqrt(runs))],
                         rbar_final=[float(np.mean(rbars)), float(np.std(rbars, ddof=1) / np.sqrt(runs))],
                         greedy_after=[float(np.mean(greedy)), float(np.std(greedy, ddof=1) / np.sqrt(runs))],
                         greedy_optimal_runs=int(sum(abs(x - 1 / 16) < 1e-9 for x in greedy)))
        print(name, "first50k", res[name]["first50k"], "last50k", res[name]["last50k"],
              "rbar", res[name]["rbar_final"], "greedy", res[name]["greedy_after"],
              res[name]["greedy_optimal_runs"], f"{time.time()-t0:.1f}s", flush=True)
    out["results"] = res
    out["seconds"] = round(time.time() - t0, 1)
    d = os.path.join(os.path.dirname(__file__), "..", "assets", "ch22-lit-wan-fourrooms")
    os.makedirs(d, exist_ok=True)
    with open(os.path.join(d, "results.json"), "w") as f:
        json.dump(out, f, ensure_ascii=False, indent=1)
    print("shortest", d_opt, "seconds", out["seconds"])


if __name__ == "__main__":
    main()
