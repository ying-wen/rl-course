# 第 22 章　技能模型与规划：程序

本目录可以单独运行：在本目录下执行下面的命令即可，结果写回本目录的 `assets/`。目录由 `rl-course/tools/export_chapter_code.py` 从课程目录生成，改程序请改课程目录里的原件，再重新导出。

## 准备

```sh
python3 -m pip install -r requirements.txt
```

需要的第三方包：matplotlib、mpmath、numpy。复现附录要求 Python 3.10 或更新版本；核验时用的版本见下表。

## 运行（与复现附录相同）

```sh
python3 demos/crl_joint_v12.py                     # 8 个种子 × 3 组 × 120,000 步，写 assets/crl-joint-v12
python3 demos/sample14_average_option.py           # 写 assets/sample14-avg-option
python3 demos/crl_v8_mechanisms.py --figures       # 写 assets/crl-v8
python3 demos/crl_skill_discovery_trial.py         # 写 assets/crl-skill-discovery-trial
python3 demos/ch22_lit_wan_fourrooms.py    # 文献原型：持续四房间，写 assets/ch22-lit-wan-fourrooms
python3 demos/ch22_lit_blocking.py         # 文献原型：堵路迷宫，写 assets/ch22-lit-blocking
python3 demos/ch22_lit_rrs.py              # 文献原型：尊重奖励的子任务，写 assets/ch22-lit-rrs
python3 demos/crl_ladder_learners.py --exp ch22 --seeds 60 --seed0 100 --steps 2000000 --tag formal   # 四区仓库阶梯，写 assets/crl-ladder-world/runs/formal-ch22.json
python3 demos/crl_ladder_figures.py ch22           # 写 assets/crl-ladder-world/fig/ladder-ch22.png
```

## 本目录的程序

| 程序 | 说明 | 核验 |
|---|---|---|
| `demos/crl_joint_v12.py` | One continuing navigation task, learned skills, GVFs and rate-aware planning. | 通过（59 秒） |
| `demos/sample14_average_option.py` | Three-station worked example: rate -> differential TD -> learned option model -> action. | 通过（6 秒） |
| `demos/crl_v8_mechanisms.py` | Small, reproducible calculations for CRL teaching; not a full research agent. | 通过（2 秒） |
| `demos/crl_skill_discovery_trial.py` | Discover and test one reusable delivery skill on a single continuing trajectory. | 通过（10 秒） |
| `demos/ch22_lit_wan_fourrooms.py` | 第 22 章文献原型：Wan、Naik 与 Sutton (2021) 的持续式四房间。 | 通过（98 秒） |
| `demos/ch22_lit_blocking.py` | 第 22 章文献原型：Sutton 与 Barto 第 2 版例 8.2 堵路迷宫（图 8.4）。 | 超时：300 秒内未跑完（启动正常） |
| `demos/ch22_lit_rrs.py` | 第 22 章文献原型：Sutton 等 (2023) 尊重奖励的子任务，两房间例。 | 通过（0 秒） |
| `demos/crl_ladder_learners.py` | 四区仓库的学习器阶梯（例子方案第三步）。 | 超时：300 秒内未跑完（启动正常） |
| `demos/crl_ladder_figures.py` | 阶梯世界（四区仓库）阅读稿用图：地图与各章“占天花板”条形。 | 通过（1 秒） |
| `demos/multiscale_models.py` | Compare recursive and direct prediction with exactly the same observed paths. | 通过（2 秒） |
| `demos/continual_figures.py` | Render original figures from formulas and multiscale CSV; requires matplotlib. | 通过（2 秒） |
| `demos/crl_ladder_world.py` | 四区仓库：第三部分的能力阶梯世界（环境与精确参照）。 | 通过（15 秒） |
| `demos/crl_ladder_world_checks.py` | 四区仓库的独立检查（照 v12 的做法：手算、枚举、独立实现互查）。 | 通过（20 秒） |
| `demos/crl_ladder_power.py` | 四区仓库学习器阶梯：试点估 σ_Δ 定种子数，正式跑后出第 24 章的账本。 | 通过（0 秒） |
| `demos/crl_ladder_ceiling.py` | 四区仓库学习器阶梯：每个试验条件的“天花板”，供账本算“离最优还差多少”。 | 超时：300 秒内未跑完（启动正常） |
| `demos/crl_ladder_diagnostics.py` | 四区仓库阶梯的诊断与改法（11-20）。 | 通过（0 秒） |

被上面程序 import 的本课模块：`demos/plot_fonts.py`。

表中后 7 个程序复现附录本章一节没有列出，来自课件、阅读稿、CODE-MAP 或文件名前缀（第三部分另含学习器阶梯）。

## 第三部分的学习器阶梯（例子方案第三步）

四区仓库世界与 L0–L10 阶梯学习器。每章一个实验，三档：没有、设计者给定、从经验学到。比较都是配对的：同一种子下两档用同一份世界随机数。

```sh
python3 demos/crl_ladder_world.py --fast                     # 各区参考线，写 reference.json（全量去掉 --fast）
python3 demos/crl_ladder_world_checks.py                     # 世界本身的核对
python3 demos/crl_ladder_ceiling.py                          # 各条件的天花板（ε-软最好率），写 ceiling.json
python3 demos/crl_ladder_learners.py --exp ch22 --seeds 2 --steps 200000 --procs 2 --tag smoke   # 冒烟：写 assets/crl-ladder-world/runs/smoke-ch22.json
python3 demos/crl_ladder_learners.py --exp ch22 --seeds 60 --seed0 100 --steps 2000000 --tag formal   # 正式设置（种子数与 runs/ 里的正式记录相同）
python3 demos/crl_ladder_power.py ledger --runs formal-ch22     # 配对差与 95% 区间，写 ledger-formal-ch22.json
python3 demos/crl_ladder_figures.py ch22                       # 阅读稿用的地图与条形图（读账本）
```

参考记录在 `assets/crl-ladder-world/runs/`（随本目录复制）。正式设置一章要跑数十分钟到数小时；冒烟一行只确认程序能走通。正式结果与读法见 `assets/crl-ladder-world/README.md` 第八节，改进与诊断见第九节。

## 复现附录本章一节

本章来自本课程序的结果有：三站实验中的一次完成调用，奖励改变前后的模型读出与行为，双房间后继表示与特征方向技能，22.7 节规划读模型的配对实验，三个文献原型（22.2 节四房间上的差分 Q 选项学习、22.5 节堵路迷宫、22.7 节两房间），以及 22.7 节四区仓库上选项规划与原始动作规划的阶梯比较。阶梯比较是初步结果，四个 $h$ 各检验一次，未做多重比较校正。

固定步长 $\alpha=.2$ 的演算（$2.6$、$6.2$）、门槛 $3.4$ 与 $6.8$ 步、自测第 7 题的 $10.2$ 与 $4.2$ 由正文推导直接算出。22.5 节调用检验的模拟（改版前后预测用时之差与报警，4000 次运行），程序暂未收入本附录。22.6 节子目标模型的四面板图取自 Lo 等原文，见表后。

| 位置 | 结果 | 设置 | 程序 | 数据与输出 |
|---|---|---|---|---|
| 22.1 节“在交回时学习技能后果”“平均奖励规划中的GVF” | 从 $A$ 到 $C$ 的一趟执行在第 40,003 个原始步结束，$G=3$、$\tau_o=7$、$Y=C$；该步的奖励、时间、停在 $C$ 三个累积量为 3、1、1 | 本课的模拟：三站持续任务，滑动概率 $.1$，第 60,000 步改变 $C$ 的到站奖励；无规划、规划、冻结三组各 120,000 个原始步，不重置，独立重复 8 次；记录取种子 0 规划组第 40,000 步以后第一次以 $C$ 为目标的完成调用 | `demos/crl_joint_v12.py` | `assets/crl-joint-v12/one-real-transition.json`；`assets/crl-joint-v12/manifest.json` |
| 22.2 节“平均奖励技能模型规划”“时长预测误差与动作间隔” | $t=244$ 时 $C$ 的到站奖励由 3 降为 $.1$，$t=250$ 与 $t=260$ 两次观察后模型改写；学得奖励率由 $1/3$ 变为 $.2$；$t=266$ 在 $A$ 改选 $B$，换回变化前模型则仍选 $C$；前 600 步更新组 148、冻结组 112.4；读出前后的分数柱图与时长误差图 | 本课的确定性模拟（种子 1429）：同一套预训练技能（每个目的站 2,400 个可重置回合，共 33,965 个原始步）；部署后两组共走 28 步覆盖路线，此后一组在交回时更新模型（TD 步长 $.1$，奖励率步长 $.01$），另一组读第 28 步的模型；规划枚举 8 个高层策略；计分到第 600 步 | `demos/sample14_average_option.py` | `assets/sample14-avg-option/sample14-manifest.json`；`assets/sample14-avg-option/sample14-option-events.csv`；`assets/sample14-avg-option/sample14-option-decisions.csv`；`assets/sample14-avg-option/sample14-option-model-updates.json`；`assets/sample14-avg-option/sample14-option-trajectory.csv`；`assets/sample14-avg-option/sample14-option-frozen-trajectory.csv`；图 `assets/sample14-avg-option/sample14-option-reader.png`、`assets/sample14-avg-option/sample14-option-behavior.png`、`assets/sample14-avg-option/sample14-option-duration-error.png` |
| 22.6 节“访问结构与特征方向子任务”及延伸“双房间中的估计误差、方向奖励与终止动作” | 41 个状态上样本后继表示的学习曲线，20 万次转移后相对误差 $.0380$；由第二大实特征向量给出的内部奖励、动作与终止轨迹（12 步后停止） | 本课的模拟（种子 141908）：均匀随机原始动作，$\gamma=.9$，逐状态步长 $.8/N(s)^{.55}$；方向子任务 12,000 回合（共 76,433 次转移），$\gamma_o=.95$，$\alpha=.2$，$\varepsilon=.2$，含立即停止动作 | `demos/crl_v8_mechanisms.py` | `assets/crl-v8/sr-learning.csv`；`assets/crl-v8/eigenoption-map.csv`；`assets/crl-v8/eigenoption-trajectory.csv`；`assets/crl-v8/manifest.json`；图 `assets/crl-v8/sr-learning.png`、`assets/crl-v8/eigenoption.png` |
| 22.7 节“练之前，用模型排队”“练了，规划却没改选”（课件 ch15-f06-discovery、ch22-plan-no-reselect） | 均匀试练、按分排序、只用原始动作的每步主奖励 $.8926/.9774/.9987$；排序减均匀 $+.08479\,[.07007,.09951]$，排序减只用原始动作 $-.02133\,[-.03671,-.00595]$，允许减禁止调用 $+.00332\,[.00217,.00446]$，探索率对齐后 $-.00010\,[-.00040,.00021]$；每个 lifetime 调用约 204 次、约 36 次内部动作不同、约 55% 的优势在窗口内；种子 0 第 388 步分数 $2.825$ 对 $1.437$ | 本课的模拟：与第 21 章“技能的去留”同一实验（五条支路，到站奖励 $1,2,3,4,6$ 的随机排列，差分 Q 学习步长 $.15$、探索率 $.1$，256 步共同探索，16 个 128 步试练窗口），每条 lifetime 8192 步，配对 lifetime 独立重复 64 次，95% 配对 $t$ 区间 | `demos/crl_skill_discovery_trial.py` | `assets/crl-skill-discovery-trial/runs.csv`；`assets/crl-skill-discovery-trial/summary.json`；`assets/crl-skill-discovery-trial/curves.csv`；`assets/crl-skill-discovery-trial/seed-0-events.json`；`assets/crl-skill-discovery-trial/discovery-comparison.png` |
| 22.2 节（课件 ch22-lit-wan-fourrooms） | 每 $10^4$ 步的每步奖励曲线（A、H、A∪H）；首个 $10^4$ 步 .0064/.0489/.0456；贪心 .0625/.0505/.0555，达最优 30/30、0/30、8/30 | 本课的模拟：104 格四房间、确定性，到 G 得 $+1$ 后回起点、不复位；inter-option Differential Q-learning 简化写法，$\varepsilon=.1$，$\alpha=2^{-3}$，$\eta=.1$；30 次独立运行，各 $2\times10^5$ 步 | `demos/ch22_lit_wan_fourrooms.py` | `assets/ch22-lit-wan-fourrooms/results.json` |
| 22.5 节（课件 ch22-lit-blocking） | Dyna-Q 与 Dyna-Q+ 累计奖励曲线；第 1000/3000 步 45.4/75.8 与 69.9/165.6，改路后所得 30.4 与 95.7；8 组参数扫描 | 本课的模拟：6×9 堵路迷宫，第 1000 步改路（10 步变 16 步）；$\gamma=.95$，$\alpha=1$，$\varepsilon=.1$，每步规划 50 次，$\kappa=10^{-3}$；30 次独立运行，3000 步；扫描规划 10/50、步长 .5/1、$\kappa$ $10^{-4}$/$10^{-3}$，各 30 次 | `demos/ch22_lit_blocking.py` | `assets/ch22-lit-blocking/results.json` |
| 22.7 节（课件 ch22-lit-rrs） | 起点估值到位轮数 18/16/10；两项技能从起点的步数、灰格数与价值（−2.093、.843） | 本课的计算：61 格两房间、确定性，灰区每进一格 $-1$，目标 $+1$，$\gamma=.99$；停在走廊奖金 1；精确模型同步值迭代，无随机误差 | `demos/ch22_lit_rrs.py` | `assets/ch22-lit-rrs/results.json` |
| 22.7 节（课件 `ch22-ladder`） | 规律常换时选项规划胜过原始动作规划；交互项为同种子上两种规划增益之差；初步结果 | 本课的模拟：四区仓库，200 万步，60 个种子，差分 Q，SMDP 备份；四个 $h$ 各检验一次，未做多重比较校正 | `demos/crl_ladder_learners.py` 实验 `ch22` | `assets/crl-ladder-world/runs/formal-ch22.json`、`assets/crl-ladder-world/fig/ladder-ch22.png` |

运行：
```sh
python3 demos/crl_joint_v12.py                     # 8 个种子 × 3 组 × 120,000 步，写 assets/crl-joint-v12
python3 demos/sample14_average_option.py           # 写 assets/sample14-avg-option
python3 demos/crl_v8_mechanisms.py --figures       # 写 assets/crl-v8
python3 demos/crl_skill_discovery_trial.py         # 写 assets/crl-skill-discovery-trial
python3 demos/ch22_lit_wan_fourrooms.py    # 文献原型：持续四房间，写 assets/ch22-lit-wan-fourrooms
python3 demos/ch22_lit_blocking.py         # 文献原型：堵路迷宫，写 assets/ch22-lit-blocking
python3 demos/ch22_lit_rrs.py              # 文献原型：尊重奖励的子任务，写 assets/ch22-lit-rrs
python3 demos/crl_ladder_learners.py --exp ch22 --seeds 60 --seed0 100 --steps 2000000 --tag formal   # 四区仓库阶梯，写 assets/crl-ladder-world/runs/formal-ch22.json
python3 demos/crl_ladder_figures.py ch22           # 写 assets/crl-ladder-world/fig/ladder-ch22.png
```

22.6 节“子目标模型与原始动作估值”的四面板图 `assets/crl-formal-maps/gsp-action-values.png` 按正文取自 Lo 等原文的四房间实验，项目中没有生成它的程序，未列入表中。

## 参考数据

`assets/`（以及 `demos/NN-results/`）下复制了 187 个数据文件（json、csv 等），即课程目前使用的结果；图片没有复制，运行程序会重新画出。重跑会覆盖这些文件，可以先另存一份再对照。
