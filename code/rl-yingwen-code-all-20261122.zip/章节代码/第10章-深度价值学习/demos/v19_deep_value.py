#!/usr/bin/env python3
"""Bellman targets, neural derivatives, and retained DQN policies.

Run: python demos/v19_deep_value.py [--out DIRECTORY]
The finite calculations are new. Learning snapshots are read from the original
seed-0 experiment; this script never overwrites or relabels that experiment.
"""
from pathlib import Path
import argparse, csv, hashlib, json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
from plot_fonts import chinese_font
import dqn_model_v11 as task

ROOT = Path(__file__).resolve().parents[1]
TEAL, RED, GOLD, INK = '#087E8B', '#C65335', '#C4942A', '#182E38'
FONT = chinese_font()
plt.rcParams.update({'font.size': 14, 'pdf.fonttype': 42,
                     'axes.spines.top': False, 'axes.spines.right': False})

def save(fig, out, name):
    for ext in ('pdf', 'png'):
        fig.savefig(out/f'{name}.{ext}', bbox_inches='tight', dpi=180)
    plt.close(fig)

def grid(ax, q, route=False):
    """Color is max Q; arrows show all nonterminal greedy actions."""
    for (x,y) in task.WALLS:
        ax.add_patch(Rectangle((x,y),1,1,color=INK))
    for s,(x,y) in enumerate(task.STATES):
        if s==task.GOAL:
            ax.add_patch(Rectangle((x,y),1,1,color='#EAF4F3'))
            ax.text(x+.5,y+.5,'G',ha='center',va='center',color=RED,fontsize=18)
            continue
        color=plt.cm.viridis(np.clip((q[s].max()+.2)/1.2,0,1))
        ax.add_patch(Rectangle((x,y),1,1,facecolor=color,edgecolor='white'))
        a=int(q[s].argmax());dx,dy=task.DELTAS[a]
        if route:
            ax.arrow(x+.5-.15*dx,y+.5-.15*dy,.3*dx,.3*dy,
                     width=.025,head_width=.17,length_includes_head=True,color='white')
        else:
            ax.text(x+.5,y+.5,f'{q[s].max():.2f}',ha='center',va='center',
                    color='white' if q[s].max()<.4 else INK,fontsize=13)
    path=[task.INDEX[(0,0)]]
    if route:
        for _ in range(16):
            s=path[-1];a=int(q[s].argmax());sp,_,done=task.transition(s,a)
            path.append(sp)
            if done or sp==s or sp in path[:-1]:break
        xy=np.array([task.STATES[s] for s in path])+.5
        ax.plot(xy[:,0],xy[:,1],color='#FF7D27',lw=3,marker='o',ms=4)
    ax.set(xlim=(0,5),ylim=(0,5),aspect='equal');ax.axis('off')
    return path

def propagation(out):
    # Querying every transition is allowed only in this known-model comparison.
    # It illustrates the exact table operation that neural regression approximates.
    q=np.zeros((len(task.STATES),4));snaps={0:q.copy()}
    for k in range(1,9):
        new=np.zeros_like(q)
        for s in task.STARTS:
            for a in range(4):
                sp,r,done=task.transition(s,a)
                new[s,a]=r+task.GAMMA*(not done)*q[sp].max()
        q=new
        if k in (1,4,8):snaps[k]=q.copy()
    # Independent backward recursion over a finite horizon.
    from functools import lru_cache
    @lru_cache(None)
    def finite(s,a,h):
        sp,r,done=task.transition(s,a)
        return r if done or h==1 else r+task.GAMMA*max(finite(sp,b,h-1) for b in range(4))
    err=0.
    for k in (1,4,8):
        for s in task.STARTS:
            for a in range(4):err=max(err,abs(snaps[k][s,a]-finite(s,a,k)))
    assert err<1e-12
    fig,axs=plt.subplots(1,3,figsize=(10,3.25))
    for ax,k in zip(axs,(1,4,8)):
        grid(ax,snaps[k]);ax.set_title(f'{k} 次同步 Bellman 更新',fontproperties=FONT,fontsize=17)
    fig.tight_layout();save(fig,out,'bellman-propagation')
    return {'operation':'exact synchronous table update, known model',
            'max_error_vs_finite_horizon_recursion':err,
            'start_values':{str(k):float(x[task.INDEX[(0,0)]].max()) for k,x in snaps.items()}}

def learned_behavior(out):
    source=ROOT/'assets/dqn-model-v11/grid-q-map.csv'
    rows=list(csv.DictReader(source.open()));snap={}
    for row in rows:
        k=int(row['checkpoint']);snap.setdefault(k,np.zeros((len(task.STATES),4)))
        s=task.INDEX[(int(row['x']),int(row['y']))]
        snap[k][s]=[float(row[n]) for n in ('up','right','down','left')]
    fig,axs=plt.subplots(2,3,figsize=(10,5.25),gridspec_kw={'height_ratios':[1.7,1]})
    records=[];start=task.INDEX[(0,0)]
    for col,k in enumerate((0,1000,10000)):
        q=snap[k];path=grid(axs[0,col],q,route=True)
        axs[0,col].set_title(f'{k:,} 次真实交互',fontproperties=FONT,fontsize=17)
        colors=[TEAL]*4;colors[int(q[start].argmax())]=GOLD
        axs[1,col].bar(range(4),q[start],color=colors,width=.65)
        axs[1,col].set_xticks(range(4),['上','右','下','左'],fontproperties=FONT)
        axs[1,col].set_ylim(-.25,1.02);axs[1,col].axhline(0,c='#61757D',lw=.6)
        axs[1,col].set_ylabel(r'$Q((0,0),a)$')
        for a,value in enumerate(q[start]):
            axs[1,col].text(a,value+.035,f'{value:.2f}',ha='center',fontsize=12)
        records.append({'training_steps':k,'start_q':q[start].tolist(),
                        'greedy_path':[list(task.STATES[s]) for s in path]})
    fig.tight_layout();save(fig,out,'learned-value-policy')
    fig,ax=plt.subplots(figsize=(3.4,3.4));grid(ax,snap[10000],route=True)
    save(fig,out,'learned-policy-final')
    final=np.load(ROOT/'assets/dqn-model-v11/grid-weights.npz')
    net=task.MLP(np.random.default_rng(0));net.p=[final[f'seed0_p{i}'] for i in range(4)]
    np.testing.assert_allclose(net.forward(task.FEATURES)[task.STARTS],snap[10000][task.STARTS],atol=1e-12)
    return {'source':str(source.relative_to(ROOT)),'sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
            'seed':0,'new_training':False,'snapshots':records,'stored_weights_match':True}

def frozen_target(out):
    # A nonterminal move from the original task. Target and online initially agree
    # numerically but occupy independent arrays. We differentiate ONLY the online
    # prediction. This is an actual SGD step, not the historical Adam training.
    online=task.MLP(np.random.default_rng(0));target=task.MLP(np.random.default_rng(1))
    target.p=[p.copy() for p in online.p]
    s=task.INDEX[(4,0)];a=0;sp,r,done=task.transition(s,a)
    tail=target.forward(task.FEATURES[sp:sp+1])[0]
    y=r+task.GAMMA*(not done)*tail.max()
    before=online.forward(task.FEATURES).copy();x=task.FEATURES[s:s+1]
    loss,grad=online.loss_grad(x,np.array([a]),np.array([y]))
    eps=1e-6;fd=[]
    for block,index in [(0,(s,0)),(1,(0,)),(2,(0,a)),(3,(a,))]:
        p=online.p[block];old=p[index];p[index]=old+eps
        plus=.5*(online.forward(x)[0,a]-y)**2;p[index]=old-eps
        minus=.5*(online.forward(x)[0,a]-y)**2;p[index]=old
        fd.append(abs((plus-minus)/(2*eps)-grad[block][index]))
    assert max(fd)<1e-9
    alpha=.1
    for p,g in zip(online.p,grad):p-=alpha*g
    after=online.forward(task.FEATURES)
    np.testing.assert_array_equal(target.forward(task.FEATURES[sp:sp+1])[0],tail)
    assert np.max(abs(after[sp]-before[sp]))>0
    fig,axs=plt.subplots(1,2,figsize=(10,2.8))
    for ax,loc,title in [(axs[0],s,'当前状态 (4,0)'),(axs[1],sp,'后继状态 (4,1)')]:
        ax.bar(np.arange(4)-.2,before[loc],.38,color='#AFBDBF',label='更新前')
        ax.bar(np.arange(4)+.2,after[loc],.38,color=TEAL,label='在线网络更新后')
        ax.set_xticks(range(4),['上','右','下','左'],fontproperties=FONT)
        ax.set_title(title,fontproperties=FONT,fontsize=17);ax.axhline(0,c='#61757D',lw=.6)
        ax.set_ylim(-.14,.31);ax.set_ylabel(r'$Q$')
    axs[0].axhline(y,color=RED,ls='--',label='固定标签 y')
    axs[1].scatter(range(4),tail,c=RED,marker='_',s=160,label='目标副本（不变）',zorder=4)
    axs[0].legend(prop=FONT,loc='upper left',frameon=False);axs[1].legend(prop=FONT,loc='upper left',frameon=False)
    fig.tight_layout();save(fig,out,'frozen-target-step')
    return {'transition':{'s':[4,0],'a':'up','r':r,'sp':[4,1],'terminal':done},
            'target_q':tail.tolist(),'target':float(y),'sgd_step':alpha,'before':before[s].tolist(),
            'after':after[s].tolist(),'successor_before':before[sp].tolist(),
            'successor_after':after[sp].tolist(),'initial_loss':loss,
            'max_gradient_difference':max(fd),'target_unchanged':True}

def fitted_prediction(out):
    # Same fully covered off-policy prediction problem as chapter 9.
    x=np.array([1.,2.]);mu=np.array([.95,.05]);gamma=.9
    C=np.sum(mu*x*x);b_multiplier=gamma*np.sum(mu*x*2)
    factor=b_multiplier/C
    assert np.isclose(C,1.15) and np.isclose(factor,1.89/1.15)
    assert np.isclose(np.sum(mu*x*(x-gamma*2)),-.74)
    w=1.;history=[w];normal_residual=[]
    for _ in range(10):
        target=np.full(2,gamma*2*w)
        fit=np.linalg.lstsq((np.sqrt(mu)*x)[:,None],np.sqrt(mu)*target,rcond=None)[0][0]
        normal_residual.append(float(np.sum(mu*x*(x*fit-target))))
        assert np.isclose(fit,factor*w)
        w=float(fit);history.append(w)
    assert max(abs(np.array(normal_residual)))<1e-12
    u=np.linspace(-.2,3,200);loss=.5*np.sum(mu[None,:]*(u[:,None]*x-1.8)**2,axis=1)
    fig,(ax,bx)=plt.subplots(1,2,figsize=(10,2.8))
    ax.plot(u,loss,color=TEAL,lw=2);ax.axvline(factor,color=GOLD,ls='--')
    ax.scatter([factor],[.5*np.sum(mu*(factor*x-1.8)**2)],c=GOLD,zorder=3)
    ax.set(xlabel='w',ylabel=r'$L(w;\bar w=1)$');ax.set_title('固定标签：精确最小化',fontproperties=FONT,fontsize=16)
    bx.plot(range(11),history,'o-',color=RED,lw=2);bx.axhline(0,color=TEAL,ls='--')
    bx.set_xlabel('目标刷新次数',fontproperties=FONT);bx.set_ylabel(r'$\hat v(s_0)=w$')
    bx.set_title('反复刷新：预测持续增长',fontproperties=FONT,fontsize=16)
    fig.tight_layout();save(fig,out,'fitted-prediction')
    return {'features':x.tolist(),'behavior_state_weights':mu.tolist(),'factor':factor,
            'regression_hessian':C,'mean_td_A':-.74,'history':history,
            'normal_equation_max_residual':max(abs(np.array(normal_residual)))}


def main():
    p=argparse.ArgumentParser();p.add_argument('--out',type=Path,default=ROOT/'assets/v19-deep-value');a=p.parse_args()
    a.out.mkdir(parents=True,exist_ok=True)
    results={'bellman_propagation':propagation(a.out),'learned_behavior':learned_behavior(a.out),'frozen_target':frozen_target(a.out),'fitted_prediction':fitted_prediction(a.out)}
    (a.out/'results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({k:('ok') for k in results},ensure_ascii=False))

if __name__=='__main__':main()
