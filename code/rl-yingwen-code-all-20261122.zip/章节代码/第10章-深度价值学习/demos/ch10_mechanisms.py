# -*- coding: utf-8 -*-
"""第 10 章机制页的数值。

A. K 个无偏估计取最大的期望偏差（标准正态误差），与 sqrt(2 ln K) 对照。
B. 只看最近 k 帧时，灯的信息在岔口是否还在窗口里（T 形走廊，表格 Q 学习复算）。
C. 7×7 网格（12 堵墙）中，固定交互步数、改变回放比（每步更新次数）时的贪心策略得分。
D. 同一组网格任务上，两种回放比在 3 次与 20 次运行下的均值、中位数、IQM 及分层自助置信区间。

运行：python3 demos/ch10_mechanisms.py，结果写入 demos/ch10-mechanisms-results/results.json。
"""
import json
import math
import os

import numpy as np

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'ch10-mechanisms-results')


# ---------- A. 取最大的偏差 ----------
def emax_normal(K, n=20001):
    x = np.linspace(-9, 9, n)
    phi = np.exp(-x * x / 2) / math.sqrt(2 * math.pi)
    Phi = 0.5 * (1 + np.vectorize(math.erf)(x / math.sqrt(2)))
    f = K * x * phi * Phi ** (K - 1)
    return float(np.trapezoid(f, x))


def part_a():
    Ks = [1, 2, 3, 4, 6, 8, 12, 16, 18, 24, 32, 48, 64]
    rows = [{'K': K, 'emax': round(emax_normal(K), 4),
             'bound': round(math.sqrt(2 * math.log(K)), 4) if K > 1 else 0.0} for K in Ks]
    # 双估计：一组选、另一组评；各动作真值相同、误差独立时期望为 0
    rng = np.random.default_rng(0)
    dbl = {}
    for K in [2, 4, 18]:
        a = rng.standard_normal((200000, K)); b = rng.standard_normal((200000, K))
        dbl[K] = round(float(b[np.arange(len(a)), a.argmax(1)].mean()), 4)
    # 真值不等时：真值 0, -0.5, -1, ...；单估计偏高，双估计偏低
    rng = np.random.default_rng(1)
    K = 4; q = -0.5 * np.arange(K)
    a = q + rng.standard_normal((200000, K)); b = q + rng.standard_normal((200000, K))
    spread = {'q': q.tolist(), 'single': round(float(a.max(1).mean()), 4),
              'double': round(float(b[np.arange(len(a)), a.argmax(1)].mean()), 4)}
    return {'rows': rows, 'double_equal': dbl, 'unequal_K4': spread}


# ---------- B. 只看最近 k 帧 ----------
def part_b(Ls=range(1, 11), ks=(1, 2, 4, 8), episodes=4000):
    """走廊长 L：第 0 步看到灯（红/绿），之后 L 步走廊，到岔口选左/右。
    观测为最近 k 帧；岔口处表格 Q 学习，学完后看贪心成功率。"""
    res = {}
    for k in ks:
        line = []
        for L in Ls:
            rng = np.random.default_rng(100 + 10 * k + L)
            Q = {}
            for ep in range(episodes):
                lamp = int(rng.integers(2))
                frames = ['red' if lamp == 0 else 'green'] + ['corr'] * (L - 1) + ['junc']
                obs = tuple(frames[-k:])
                q = Q.setdefault(obs, np.zeros(2))
                a = int(rng.integers(2)) if rng.random() < 0.2 else int(np.argmax(q))
                r = 1.0 if a == lamp else 0.0
                q[a] += 0.05 * (r - q[a])
            succ = 0
            for lamp in (0, 1):
                frames = ['red' if lamp == 0 else 'green'] + ['corr'] * (L - 1) + ['junc']
                q = Q.get(tuple(frames[-k:]), np.zeros(2))
                succ += 1.0 if int(np.argmax(q)) == lamp else 0.0
            line.append(succ / 2)
        res[k] = line
    return {'L': list(Ls), 'success': res}


# ---------- C/D. 网格与回放比 ----------
ACT = [(0, 1), (1, 0), (0, -1), (-1, 0)]
GAMMA, STEP_R, N = 0.97, -0.02, 7


def make_task(rng):
    while True:
        walls = set()
        while len(walls) < 12:
            c = (int(rng.integers(N)), int(rng.integers(N)))
            if c not in [(0, 0), (N - 1, N - 1)]:
                walls.add(c)
        d = bfs(walls)
        if d is not None and d >= 12:
            return walls, d


def bfs(walls):
    from collections import deque
    dist = {(0, 0): 0}; dq = deque([(0, 0)])
    while dq:
        s = dq.popleft()
        for dx, dy in ACT:
            t = (s[0] + dx, s[1] + dy)
            if 0 <= t[0] < N and 0 <= t[1] < N and t not in walls and t not in dist:
                dist[t] = dist[s] + 1; dq.append(t)
    return dist.get((N - 1, N - 1))


def step(walls, s, a):
    t = (s[0] + ACT[a][0], s[1] + ACT[a][1])
    if not (0 <= t[0] < N and 0 <= t[1] < N) or t in walls:
        t = s
    if t == (N - 1, N - 1):
        return t, 1.0, True
    return t, STEP_R, False


def g_of(d):
    return STEP_R * (1 - GAMMA ** (d - 1)) / (1 - GAMMA) + GAMMA ** (d - 1) if d is not None else None


G_FAIL = STEP_R * (1 - GAMMA ** 40) / (1 - GAMMA)


def bfs_from_goal(walls):
    from collections import deque
    g = (N - 1, N - 1); dist = {g: 0}; dq = deque([g])
    while dq:
        s = dq.popleft()
        for dx, dy in ACT:
            t = (s[0] + dx, s[1] + dy)
            if 0 <= t[0] < N and 0 <= t[1] < N and t not in walls and t not in dist:
                dist[t] = dist[s] + 1; dq.append(t)
    return dist


def greedy_score(walls, Q, d):
    """从每个可达的非终点格出发，按贪心策略走，归一化回报取平均：0 为 40 步内到不了，1 为最短路。"""
    dist = bfs_from_goal(walls); vals = []
    for s0, k in dist.items():
        if k == 0:
            continue
        s, G, disc = s0, 0.0, 1.0
        for _ in range(40):
            a = int(np.argmax(Q[s]))
            s, r, done = step(walls, s, a)
            G += disc * r; disc *= GAMMA
            if done:
                break
        vals.append((G - G_FAIL) / (g_of(k) - G_FAIL))
    return float(np.mean(vals))


def run(walls, d, rr, budget, rng, alpha=0.5, eps=0.1):
    Q = {(x, y): np.zeros(4) for x in range(N) for y in range(N)}
    buf = []
    s = (0, 0); t_ep = 0
    for t in range(budget):
        q = Q[s]
        if rng.random() < eps:
            a = int(rng.integers(4))
        else:
            m = q.max(); a = int(rng.choice(np.flatnonzero(q == m)))
        s2, r, done = step(walls, s, a)
        buf.append((s, a, r, s2, done))
        batch = [buf[-1]] + [buf[int(rng.integers(len(buf)))] for _ in range(rr - 1)]
        for (x, b, rw, y, dn) in batch:
            target = rw if dn else rw + GAMMA * Q[y].max()
            Q[x][b] += alpha * (target - Q[x][b])
        t_ep += 1
        if done or t_ep >= 100:
            s, t_ep = (0, 0), 0
        else:
            s = s2
    return greedy_score(walls, Q, d)


def scores_at(tasks, rr, budget, seeds):
    S = np.zeros((len(tasks), seeds))
    for i, (w, d) in enumerate(tasks):
        for j in range(seeds):
            S[i, j] = run(w, d, rr, budget, np.random.default_rng(1000 * i + j))
    return S


def part_c(n_tasks=10, rrs=(1, 2, 4, 8, 16), budgets=range(100, 1600, 100), seeds=8,
           agg_budget=400, agg_rrs=(4, 8), agg_seeds=20):
    rng = np.random.default_rng(7)
    tasks = [make_task(rng) for _ in range(n_tasks)]
    curves = {rr: [round(float(scores_at(tasks, rr, b, seeds).mean()), 3) for b in budgets] for rr in rrs}
    scores = {rr: scores_at(tasks, rr, agg_budget, agg_seeds) for rr in agg_rrs}
    return tasks, list(budgets), curves, scores


def iqm(x):
    x = np.sort(np.asarray(x).ravel()); n = len(x)
    lo, hi = int(math.floor(n * 0.25)), int(math.ceil(n * 0.75))
    return float(x[lo:hi].mean())


AGG = {'mean': lambda S: float(S.mean()),
       'median': lambda S: float(np.median(S.mean(1))),
       'iqm': lambda S: iqm(S)}


def boot_ci(S, f, reps=2000, rng=None):
    n_t, n_s = S.shape
    vals = []
    for _ in range(reps):
        idx = rng.integers(n_s, size=(n_t, n_s))
        vals.append(f(np.take_along_axis(S, idx, 1)))
    return [round(float(np.percentile(vals, 2.5)), 3), round(float(np.percentile(vals, 97.5)), 3)]


def part_d(scores, pair=(4, 8)):
    rng = np.random.default_rng(11)
    out = {}
    for rr in pair:
        S = scores[rr]
        out[rr] = {}
        for nrun in (3, 20):
            sub = S[:, :nrun]
            out[rr][nrun] = {k: {'point': round(f(sub), 3), 'ci': boot_ci(sub, f, rng=rng)}
                             for k, f in AGG.items()}
    # 只用 3 次运行时，按前 3 次、第 4–6 次……分组，看两种回放比的均值差有几组反号
    diffs = []
    for g in range(0, 18, 3):
        diffs.append(round(float(scores[pair[1]][:, g:g + 3].mean() - scores[pair[0]][:, g:g + 3].mean()), 3))
    out['diff_by_triplet'] = diffs
    return out


def main():
    os.makedirs(OUT, exist_ok=True)
    res = {'maxbias': part_a(), 'frames': part_b()}
    tasks, budgets, curves, scores = part_c()
    res['replay_ratio'] = {
        'tasks_shortest': [d for _, d in tasks],
        'budgets': budgets,
        'curves': {str(rr): v for rr, v in curves.items()},
        'agg_per_task': {str(rr): [round(float(v), 3) for v in S.mean(1)] for rr, S in scores.items()},
    }
    res['aggregates'] = {str(k): v for k, v in part_d(scores).items()}
    with open(os.path.join(OUT, 'results.json'), 'w', encoding='utf-8') as f:
        json.dump(res, f, ensure_ascii=False, indent=1)
    print(json.dumps(res, ensure_ascii=False)[:4000])


if __name__ == '__main__':
    main()
