"""Exact two-step control example for Double DQN. Run with Python 3."""

from fractions import Fraction
from itertools import product
from statistics import mean

from dqn_target_check import double_target, target


def estimates(true_values):
    """One reward observation per action with independent two-point noise."""
    for errors in product((-1, 1), repeat=len(true_values)):
        yield tuple(value + error for value, error in zip(true_values, errors))


def distribution(true_values, copy_probability):
    """Return target means and the probability that A's greedy action is left.

    A->B pays zero, gamma=1; A->terminal pays zero. A's left estimate is set
    to the sampled target. Break ties in B by the first index.
    """
    readings = list(estimates(true_values))
    n = len(readings)
    dqn_mean = mean(target(0, 1, False, frozen) for frozen in readings)
    double_mean = Fraction(0)
    left_probability = Fraction(0)
    for online in readings:
        for frozen in readings:
            # V copies all of U or is drawn independently from the same law.
            weight = (1 - copy_probability) / (n * n)
            if frozen == online:
                weight += copy_probability / n
            y = double_target(0, 1, False, online, frozen)
            double_mean += weight * y
            left_probability += weight * (y > 0)
    return dqn_mean, double_mean, left_probability


def main():
    q = Fraction(-1, 10)
    same_values = (q, q)
    for rho in (Fraction(x, 10) for x in range(11)):
        same, double, choose_left = distribution(same_values, rho)
        assert same == Fraction(2, 5)
        assert double == q + rho / 2
        assert choose_left == Fraction(1, 2) + rho / 4
        print(f"copy={rho!s:>4}  DQN={same}  double={double}  P_double(left)={choose_left}")

    # With distinct true values, selecting a suboptimal action yields a
    # negative bias even when its independent evaluation is conditionally unbiased.
    _, double, _ = distribution((Fraction(0), Fraction(-1, 2)), Fraction(0))
    assert double == Fraction(-1, 8)

    positive, negative = q + 1, q - 1
    frozen = (positive, negative)
    pair = [double_target(0, 1, False, online, frozen)
            for online in [frozen, tuple(reversed(frozen))]]
    assert pair == [positive, negative]
    assert target(0, 1, False, frozen) == positive

    print("B with distinct values (0, -1/2), independent evaluation:", double)
    print("Fixed target copy: DQN =", positive, "at both times; Double DQN =", *pair)


if __name__ == "__main__":
    main()
