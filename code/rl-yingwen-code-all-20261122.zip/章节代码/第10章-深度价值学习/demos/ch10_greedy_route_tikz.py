"""Write the three greedy-route maps of slide dqn-v11-maps as TikZ code.

11-21 审阅站请求 r1121-113957（第 647 页）：原 greedy-route.pdf 内文字 2--4pt，
改由本脚本从同一份逐格动作价值 assets/dqn-model-v11/grid-q-map.csv 生成 TikZ，
文字随课件字体与字号排版。原 PNG/PDF 与 course32_navigation_figure.py 保留不动。

Run: python3 demos/ch10_greedy_route_tikz.py
Output: assets/course32-methods/greedy-route-tikz.tex (input it inside a tikzpicture-free context).
"""
import csv
from pathlib import Path

import numpy as np

import dqn_model_v11 as task

ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "assets/course32-methods/greedy-route-tikz.tex"
STEPS = (0, 1000, 10000)
ACTIONS = ("up", "right", "down", "left")
DIRECTIONS = ("上", "右", "下", "左")
STOPS = [(-.2, (0xf6, 0xf6, 0xf1)), (.4, (0x9a, 0xcd, 0xc5)), (1., (0x1b, 0x78, 0x6f))]
CELL = .34          # cm per grid cell
GAP = 1.60          # cm between grids


def colour(v):
    """Piecewise-linear colour map, the same stops as the original figure."""
    v = min(max(v, STOPS[0][0]), STOPS[-1][0])
    for (v0, c0), (v1, c1) in zip(STOPS, STOPS[1:]):
        if v <= v1:
            t = (v - v0) / (v1 - v0)
            return tuple(round(a + t * (b - a)) for a, b in zip(c0, c1))
    return STOPS[-1][1]


def fill(rgb):
    return "{rgb,255:red,%d;green,%d;blue,%d}" % rgb


def fmt(x):
    s = f"{x:.3f}"
    return s.replace("0.", ".", 1) if s.startswith(("0.", "-0.")) else s


def greedy_path(q):
    current = task.INDEX[(0, 0)]
    path = [current]
    while current != task.GOAL:
        choice = int(q[task.STATES[current]].argmax())
        current, _, done = task.transition(current, choice)
        if current in path:
            path.append(current)
            break
        path.append(current)
        if done:
            break
    return path


def main():
    values = {step: {} for step in STEPS}
    with (ROOT / "assets/dqn-model-v11/grid-q-map.csv").open() as records:
        for r in csv.DictReader(records):
            step = int(r["checkpoint"])
            if step in values:
                values[step][(int(r["x"]), int(r["y"]))] = np.array([float(r[a]) for a in ACTIONS])

    out = ["% 由 demos/ch10_greedy_route_tikz.py 生成；不要手改。",
           "\\begin{tikzpicture}[x=%.2fcm,y=%.2fcm]" % (CELL, CELL)]
    width = 5 + GAP / CELL
    for k, step in enumerate(STEPS):
        q = values[step]
        x0 = k * width
        out.append("\\begin{scope}[shift={(%.3f,0)}]" % x0)
        for xy in task.WALLS:
            out.append("\\fill[fill={rgb,255:red,54;green,71;blue,78},draw=white,line width=.6pt](%d,%d)rectangle+(1,1);" % xy)
        for xy in task.STATES:
            rgb = (0xf7, 0xdc, 0x9c) if task.INDEX[xy] == task.GOAL else colour(max(q[xy]))
            out.append("\\fill[fill=%s,draw=white,line width=.6pt](%d,%d)rectangle+(1,1);" % ((fill(rgb),) + xy))
        out.append("\\node[font=\\scriptsize\\bfseries]at(4.5,4.5){终};")
        path = greedy_path(q)
        assert (len(path), path[-1] == task.GOAL) == ((2, False) if not step else (9, True))
        pts = "--".join("(%.1f,%.1f)" % (task.STATES[s][0] + .5, task.STATES[s][1] + .5) for s in path)
        if len(path) > 2:
            out.append("\\draw[white,line width=2.6pt,line cap=round,line join=round]%s;" % pts)
            out.append("\\draw[draw={rgb,255:red,170;green,66;blue,31},line width=1.3pt,line cap=round,line join=round]%s;" % pts)
        else:  # self-loop: the greedy action points into the wall
            out.append("\\draw[draw={rgb,255:red,170;green,66;blue,31},line width=1.3pt,-{Latex[length=4pt]}](.5,.5)--(.04,.5);")
        out.append("\\filldraw[fill=white,draw={rgb,255:red,170;green,66;blue,31},line width=.9pt](.5,.5)circle(.16);")
        best = q[(0, 0)]
        out.append("\\node[font=\\scriptsize,anchor=south]at(2.5,5.05){%s 次真实交互};" % f"{step:,}".replace(",", "\\,"))
        out.append("\\node[font=\\scriptsize,anchor=north]at(2.5,-.08){起点选%s，最大 $Q=%s$};"
                   % (DIRECTIONS[int(best.argmax())], fmt(best.max())))
        out.append("\\end{scope}")
    # vertical colour bar to the right of the third grid
    xb = 3 * width - GAP / CELL + 1.6
    n = 24
    for i in range(n):
        v0 = -.2 + 1.2 * i / n
        out.append("\\fill[fill=%s](%.3f,%.4f)rectangle(%.3f,%.4f);"
                   % (fill(colour(v0 + .6 / n)), xb, 5 * i / n, xb + .55, 5 * (i + 1) / n))
    for v in (-.2, .4, 1.):
        y = 5 * (v + .2) / 1.2
        lab = fmt(v).rstrip("0").rstrip(".") if v not in (1.,) else "1"
        lab = {"-.2": "$-.2$", ".4": "$.4$", "1": "$1$"}[lab]
        out.append("\\draw(%.3f,%.3f)--+(.2,0)node[right,font=\\scriptsize,inner sep=1pt]{%s};" % (xb + .55, y, lab))
    out.append("\\node[font=\\scriptsize,rotate=90,anchor=north]at(%.3f,2.5){各格最大 $Q$};" % (xb + 2.5))
    out.append("\\end{tikzpicture}")
    OUTPUT.write_text("\n".join(out) + "\n", encoding="utf-8")
    # numbers quoted on the slide, checked against the same file
    q1 = values[1000][(3, 3)]
    print("checkpoint 1000, (3,3):", dict(zip(DIRECTIONS, np.round(q1, 3))))
    print("start (0,0) best per checkpoint:", {s: (DIRECTIONS[int(values[s][(0, 0)].argmax())], round(values[s][(0, 0)].max(), 3)) for s in STEPS})


if __name__ == "__main__":
    main()
