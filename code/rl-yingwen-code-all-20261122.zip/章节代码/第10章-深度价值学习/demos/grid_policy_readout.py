"""Trace the frozen greedy policies in the saved seed-0 DQN experiment.

Use the learned Q table only to choose actions. Score each action and each
trajectory using the original grid dynamics. Make a compact offline figure.
Run from rl-course: python demos/grid_policy_readout.py
"""
import argparse
import csv
import json
from collections import defaultdict
from pathlib import Path

import numpy as np
from dqn_model_v11 import GAMMA, GOAL, INDEX, STARTS, STATES, WALLS, oracle, transition

DATA = Path(__file__).resolve().parents[1] / "assets" / "dqn-model-v11"
ACTIONS = ("up", "right", "down", "left")
HORIZON = 64


def rollout(start, actions):
    """Display a path up to its first repeated state; score all actual steps."""
    state = start
    path = [state]
    cycle = None
    value = 0.
    for t in range(HORIZON):
        state, reward, terminal = transition(state, actions[state])
        value += GAMMA**t * reward
        if cycle is None:
            if state in path:
                cycle = path.index(state)
            path.append(state)
        if terminal:
            break
    return dict(path=path, cycle=cycle, steps=t+1, success=terminal, value=value)


def readout(directory):
    with (directory / "grid-evaluations.csv").open() as src:
        scores = {
            int(r["env_steps"]): [float(r[k]) for k in
                ("discounted_return", "success", "q_mae", "optimal_action_fraction")]
            for r in csv.DictReader(src) if r["method"] == "DQN" and r["seed"] == "0"
        }
    tables = defaultdict(dict)
    with (directory / "grid-q-map.csv").open() as src:
        for row in csv.DictReader(src):
            state = INDEX[int(row["x"]), int(row["y"])]
            values = [float(row[a]) for a in ACTIONS]
            action = int(np.argmax(values))
            assert action == int(row["action"])
            tables[int(row["checkpoint"])][state] = values
    optimal = oracle()
    snapshots = {}
    for step, q in sorted(tables.items()):
        assert set(q) == set(STARTS)
        greedy = {s: int(np.argmax(q[s])) for s in STARTS}
        runs = {}
        errors, correct = [], []
        for state in STARTS:
            result = rollout(state, greedy)
            gap = float(max(optimal[state]) - optimal[state, greedy[state]])
            errors.extend(abs(optimal[state] - q[state]))
            correct.append(gap < 1e-9)
            runs[state] = dict(q=q[state], action=greedy[state], gap=gap, **result)
        measured = [np.mean([r[k] for r in runs.values()]) for k in ("value", "success")]
        np.testing.assert_allclose(measured + [np.mean(errors), np.mean(correct)],
                                   scores[step], rtol=1e-12, atol=1e-12)
        snapshots[step] = runs
    return dict(gamma=GAMMA, horizon=HORIZON, goal=GOAL, states=STATES, walls=sorted(WALLS),
                optimal=optimal.tolist(), scores=scores, snapshots=snapshots)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-dir", type=Path, default=DATA)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    output = args.output or args.data_dir / "policy-readout.json"
    output.write_text(json.dumps(readout(args.data_dir), separators=(",", ":")) + "\n")
