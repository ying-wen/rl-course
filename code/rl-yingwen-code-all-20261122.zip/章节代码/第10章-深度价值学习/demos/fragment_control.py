"""Q-learning with one-transition fragments of the course's two-step tree.

    A: stop -> +1, terminal; continue -> 0, B
    B: low  -> +1, terminal; high     -> +3, terminal

The external collector can start at either decision state. It records the real
successor before resetting. Three learners read the very same transitions.
Run directly for final values; --output DIRECTORY also writes the data and plot.
Run with --replay-probability 1/20 to evaluate two-step replay on this tree.
"""
import argparse
import csv
from dataclasses import dataclass
from fractions import Fraction
from pathlib import Path
from typing import Optional

from dqn_target_check import target

GAMMA, ALPHA = .9, .25
MODES = ('real_successor', 'treat_cut_as_terminal', 'use_reset_state')
ACTIONS = {'A': ('stop', 'continue'), 'B': ('low', 'high')}


def transition(state, action, b_rewards=(1., 3.)):
    if state == 'A' and action == 'continue':
        return 'B', 0., False
    if action not in ACTIONS[state]:
        raise ValueError((state, action))
    reward = 1. if state == 'A' else b_rewards[ACTIONS['B'].index(action)]
    return None, reward, True


@dataclass(frozen=True)
class Record:
    state: str
    action: str
    reward: float
    successor: Optional[str]
    terminated: bool
    reset_state: str


def replay_targets(beta):
    """Enumerate contiguous two-step trajectories starting from (A, continue).

    The frozen B estimates equal the two true terminal rewards. Only the
    behavior probability of the high-reward action changes.
    """
    successor, first_reward, _ = transition('A', 'continue')
    discount = Fraction(str(GAMMA))
    returns = {}
    for action in ACTIONS[successor]:
        _, reward, terminal = transition(successor, action)
        assert terminal
        returns[action] = Fraction(first_reward) + discount * Fraction(reward)
    stop = Fraction(transition('A', 'stop')[1])
    two_step = (1 - beta) * returns['low'] + beta * returns['high']
    tie_probability = (stop - returns['low']) / (returns['high'] - returns['low'])
    return stop, max(returns.values()), two_step, tie_probability


def collect_cycle():
    # On the first line the actual successor is B; the next fragment starts in A.
    schedule = [('A', 'continue'), ('A', 'stop'), ('B', 'low'), ('B', 'high')]
    records = []
    for i, (s, a) in enumerate(schedule):
        successor, reward, terminal = transition(s, a)
        next_start = schedule[(i + 1) % len(schedule)][0]
        records.append(Record(s, a, reward, successor, terminal, next_start))
    return records


def greedy(q, state):
    # On ties choose the first available action (stop at A, low at B).
    return max(ACTIONS[state], key=lambda a: q[state][a])


def evaluate(q, horizon):
    """Deploy without collector resets. Count the actual discounted rewards."""
    state, total = 'A', 0.
    for step in range(horizon):
        state, reward, terminal = transition(state, greedy(q, state))
        total += GAMMA**step * reward
        if terminal:
            break
    return total


def train(cycles=80):
    records = collect_cycle()
    rows = []
    for mode in MODES:
        q = {s: dict.fromkeys(actions, 0.) for s, actions in ACTIONS.items()}
        for cycle in range(cycles + 1):
            rows.append(dict(mode=mode, transitions=4 * cycle, stop_q=q['A']['stop'],
                             continue_q=q['A']['continue'], action=greedy(q, 'A'),
                             one_step_score=evaluate(q, 1), full_task_score=evaluate(q, 2)))
            if cycle == cycles:
                break
            for rec in records:
                # All records have a collection boundary. Only nonterminals bootstrap.
                terminal = rec.terminated or mode == 'treat_cut_as_terminal'
                successor = rec.reset_state if mode == 'use_reset_state' else rec.successor
                next_values = () if terminal else q[successor].values()
                label = target(rec.reward, GAMMA, terminal, next_values)
                q[rec.state][rec.action] += ALPHA * (label - q[rec.state][rec.action])
    return rows


def verify(rows):
    # Solve each limiting operator independently. The incorrect reset operator
    # has x=.9 max(1,x) at A, hence x=.9. The true B value is 3.
    ends = {r['mode']: r for r in rows if r['transitions'] == 320}
    for mode, expected in zip(MODES, [2.7, 0., .9]):
        assert abs(ends[mode]['continue_q'] - expected) < 1e-7
    assert [ends[m]['action'] for m in MODES] == ['continue', 'stop', 'stop']
    assert [ends[m]['full_task_score'] for m in MODES] == [2.7, 1., 1.]
    assert [ends[m]['one_step_score'] for m in MODES] == [0., 1., 1.]
    # If every fragment starts at A, changing all B rewards is unobservable.
    for action in ACTIONS['A']:
        assert transition('A', action, (1., 3.)) == transition('A', action, (0., 0.))
    assert transition('B', 'high', (1., 3.))[1] != transition('B', 'high', (0., 0.))[1]


def draw(rows, out):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from plot_fonts import chinese_font
    plt.rcParams.update({'font.family': chinese_font().get_name(), 'svg.hashsalt': 'fragment-control',
                         'svg.fonttype': 'path', 'pdf.fonttype': 42, 'axes.spines.top': False, 'axes.spines.right': False})
    fig, (left, right) = plt.subplots(1, 2, figsize=(9, 3.7), layout='constrained',
                                     gridspec_kw={'width_ratios': [1.6, 1]})
    colors = ['#056e6d', '#a74928', '#615888']
    names = ['真实后继 B', '截断作终止', '重置起点 A']
    for mode, color, name in zip(MODES, colors, names):
        run = [r for r in rows if r['mode'] == mode and r['transitions'] <= 100]
        left.plot([r['transitions'] for r in run], [r['continue_q'] for r in run],
                  lw=2.4, color=color, label=name)
    left.axhline(1, color='#566068', lw=1, ls=':', label='停止的真实价值')
    left.set(xlabel='已采样的真实转移数', ylabel='起点 A 的「继续」动作估值', ylim=(-.12, 3))
    left.legend(fontsize=9, loc='center right', framealpha=.93)
    left.set_title('每四条记录各更新一个状态–动作对', loc='left', fontsize=11)
    last = {r['mode']: r for r in rows if r['transitions'] == 320}
    bars = right.barh([2,1,0],[last[m]['full_task_score'] for m in MODES],color=colors,height=.46)
    for bar, mode in zip(bars, MODES):
        score = last[mode]['full_task_score']
        right.text(score + .045, bar.get_y()+bar.get_height()/2, format(score,'.1f'),va='center')
    right.set(yticks=[2,1,0],yticklabels=names,xlabel='从 A 执行学得策略的折扣回报',xlim=(0,3.15))
    right.set_title('320 条记录后，在原任务中行动', loc='left',fontsize=11)
    fig.savefig(out/'learning.svg', metadata={'Date':None})
    fig.savefig(out/'learning.pdf', metadata={'CreationDate':None, 'ModDate':None})
    plt.close(fig)

    # The projection version uses the same logged values and direct labels.
    fig, ax = plt.subplots(figsize=(5.1, 2.65), layout='constrained')
    for mode, color, label in zip(MODES, colors, ['真实后继', '误作终点', '重置起点']):
        run = [r for r in rows if r['mode'] == mode and r['transitions'] <= 100]
        ax.plot([r['transitions'] for r in run], [r['continue_q'] for r in run],
                lw=2.4, color=color)
        ax.text(102, run[-1]['continue_q'], label, color=color, fontsize=13, va='center')
    ax.set(xlabel='真实转移数', ylabel='继续的动作估值', xlim=(-2, 136),
           ylim=(-.22, 3.0), yticks=(0, .9, 2.7), xticks=(0, 40, 80))
    ax.tick_params(labelsize=12)
    fig.savefig(out/'values-slide.pdf', metadata={'CreationDate':None, 'ModDate':None})
    plt.close(fig)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path)
    parser.add_argument('--replay-probability', type=Fraction, metavar='BETA',
                        help='probability of high at B, as a decimal or fraction')
    args = parser.parse_args()
    if args.replay_probability is not None:
        if not 0 <= args.replay_probability <= 1:
            parser.error('BETA must lie in [0, 1]')
        stop, greedy_value, replay_mean, tie = replay_targets(args.replay_probability)
        print(f'停止 = {stop}，继续的一步最优目标 = {float(greedy_value):g}')
        print(f'行为策略选高奖的概率 = {args.replay_probability}，'
              f'继续的两步回放均值 = {float(replay_mean):g}，与停止打平的概率 = {tie}')
        if not args.output:
            raise SystemExit(0)
    rows = train()
    verify(rows)
    for r in rows:
        if r['transitions'] == 320:
            print(f"{r['mode']:24}  Q(A,continue)={r['continue_q']:.6f}  "
                  f"action={r['action']:8}  return={r['full_task_score']:.1f}")
    if args.output:
        args.output.mkdir(exist_ok=True, parents=True)
        with (args.output/'learning.csv').open('w', newline='') as stream:
            writer = csv.DictWriter(stream,fieldnames=rows[0].keys())
            writer.writeheader()
            writer.writerows(rows)
        draw(rows,args.output)
