"""Exact DQN mechanics, Python standard library; not neural training."""
import json
from fractions import Fraction
from itertools import product

def target(r, gamma, terminal, q):
    """A true terminal has no subsequent action to maximize over."""
    if terminal:
        return r
    return r + gamma * max(q)


def double_target(r, gamma, terminal, online, frozen):
    if terminal:
        return r
    action = max(range(len(online)), key=online.__getitem__)
    return r + gamma * frozen[action]


def selection_means():
    """Two true values are zero. Enumerate every possible estimate pair."""
    errors = list(product((-1, 1), repeat=2))
    same = independent = 0
    for online in errors:
        # A tied maximum consistently selects the first action.
        chosen = max(range(2), key=online.__getitem__)
        same += online[chosen]
        for frozen in errors:
            independent += frozen[chosen]
    return {
        "same_estimates_select_and_evaluate": same / len(errors),
        "independent_estimates_select_and_evaluate": independent / len(errors)**2,
    }


def replay_updates():
    """One frozen five-record buffer: expected parameter increments divided by alpha."""
    rewards = (1, 1, 1, 1, -1)
    current = Fraction(1, 2)
    errors = [r - current for r in rewards]  # terminal targets equal their rewards
    n = len(errors)
    uniform = [Fraction(1, n)] * n
    total_priority = sum(abs(error) for error in errors)
    probabilities = [abs(error) / total_priority for error in errors]
    weights = [Fraction(1, n) / probability for probability in probabilities]
    uniform_mean = sum(p * e for p, e in zip(uniform, errors))
    priority_mean = sum(p * e for p, e in zip(probabilities, errors))
    corrected_mean = sum(p * w * e for p, w, e in zip(probabilities, weights, errors))
    assert (uniform_mean, priority_mean, corrected_mean) == (
        Fraction(1, 10), Fraction(-5, 14), Fraction(1, 10)
    )
    return {
        "td_errors": [str(x) for x in errors],
        "sampling_probabilities": [str(x) for x in probabilities],
        "importance_weights": [str(x) for x in weights],
        "uniform_mean": str(uniform_mean),
        "prioritized_mean": str(priority_mean),
        "corrected_mean": str(corrected_mean),
    }


def main():
    selection=selection_means()
    bias=selection["same_estimates_select_and_evaluate"]
    assert bias == .5 and selection["independent_estimates_select_and_evaluate"] == 0.
    assert target(1,.9,True,[])==1
    assert double_target(1,.9,True,[],[])==1
    assert target(1,.9,False,[5])==5.5
    dqn=target(1,.9,False,[2,6]);ddqn=double_target(1,.9,False,[5,4],[2,6])
    assert abs(dqn-6.4)<1e-12 and abs(ddqn-2.8)<1e-12
    # Independently check selected-output squared-loss derivative by finite difference.
    outputs=[2.,5.,1.]; y=3.;h=1e-6
    def loss(q):return .5*(q[0]-y)**2
    gradient=[]
    for k in range(3):
        up=outputs[:];down=outputs[:];up[k]+=h;down[k]-=h
        gradient.append((loss(up)-loss(down))/(2*h))
    assert max(abs(a-b) for a,b in zip(gradient,[-1.,0.,0.]))<1e-8
    print(json.dumps(dict(maximization_bias=bias,terminal=1,truncation=5.5,dqn_target=dqn,double_dqn_target=ddqn,finite_difference_output_gradient=gradient,
                          selected_value_means=selection,replay=replay_updates()),indent=2))
if __name__=='__main__':main()
