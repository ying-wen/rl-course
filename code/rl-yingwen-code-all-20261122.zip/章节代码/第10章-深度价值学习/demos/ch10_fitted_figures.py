#!/usr/bin/env python3
"""Chapter 10.3 figures in the slide fonts (11-21 review request r1121-113957).

Run: python demos/ch10_fitted_figures.py
Writes two new files and leaves the older English/number-dense figures alone:
  assets/v19-deep-value/bellman-frontier.pdf  (page "一轮传一步")
  assets/v18-methods/dqn-one-update-zh.pdf    (page "一次 Adam 更新")
"""
from pathlib import Path
from collections import deque
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
from matplotlib.ticker import FuncFormatter
from plot_fonts import use_course_fonts, no_leading_zero, CJK_FAMILY
import dqn_model_v11 as task

ROOT = Path(__file__).resolve().parents[1]
TEAL, RED, GOLD, INK, MUTED = '#087E8B', '#C65335', '#C4942A', '#182E38', '#61757D'


def save(fig, path):
    fig.savefig(path.with_suffix('.pdf'), bbox_inches='tight')
    fig.savefig(path.with_suffix('.png'), bbox_inches='tight', dpi=180)
    plt.close(fig)


def fmt(v):
    s = f'{v:.2f}'
    return s.replace('0.', '.', 1) if s.startswith(('0.', '-0.')) else s


def frontier_figure():
    # Exact synchronous table update with the known model, same as v19_deep_value.py.
    q = np.zeros((len(task.STATES), 4)); snaps = {}
    for k in range(1, 9):
        new = np.zeros_like(q)
        for s in task.STARTS:
            for a in range(4):
                sp, r, done = task.transition(s, a)
                new[s, a] = r + task.GAMMA*(not done)*q[sp].max()
        q = new
        if k in (1, 4, 8):
            snaps[k] = q.copy()
    # Distance (in steps) from each cell to the goal.
    dist = {task.GOAL: 0}; dq = deque([task.GOAL])
    while dq:
        s = dq.popleft()
        for a in range(4):
            x, y = task.STATES[s]; dx, dy = task.DELTAS[a]
            n = task.INDEX.get((x+dx, y+dy))
            if n is not None and n not in dist:
                dist[n] = dist[s]+1; dq.append(n)
    # Greedy route from the start under the round-8 table (ties: up, right, down, left).
    route = [task.INDEX[(0, 0)]]
    while route[-1] != task.GOAL:
        s = route[-1]; sp, _, _ = task.transition(s, int(snaps[8][s].argmax())); route.append(sp)
    fig, axs = plt.subplots(1, 3, figsize=(9.6, 3.55))
    for ax, k in zip(axs, (1, 4, 8)):
        v = snaps[k]
        for (x, y) in task.WALLS:
            ax.add_patch(Rectangle((x, y), 1, 1, color=INK))
        for s, (x, y) in enumerate(task.STATES):
            if s == task.GOAL:
                ax.add_patch(Rectangle((x, y), 1, 1, facecolor='#EAF4F3', edgecolor='white'))
                ax.text(x+.5, y+.5, 'G', ha='center', va='center', color=RED, fontsize=19)
                continue
            m = v[s].max()
            ax.add_patch(Rectangle((x, y), 1, 1, facecolor=plt.cm.viridis(np.clip((m+.2)/1.2, 0, 1)),
                                   edgecolor='white'))
            if s in route:
                ax.text(x+.5, y+.5, fmt(m), ha='center', va='center', fontsize=15,
                        color='white' if m < .4 else INK)
        for s, d in dist.items():
            if d == k:
                x, y = task.STATES[s]
                ax.add_patch(Rectangle((x+.04, y+.04), .92, .92, fill=False, edgecolor=RED, lw=2.6))
        ax.set(xlim=(0, 5), ylim=(0, 5), aspect='equal'); ax.axis('off')
        ax.set_title(f'第 {k} 轮', fontsize=18, fontfamily=CJK_FAMILY)
    fig.tight_layout(w_pad=1.2)
    save(fig, ROOT/'assets/v19-deep-value/bellman-frontier')
    start = task.INDEX[(0, 0)]
    return {k: float(snaps[k][start].max()) for k in snaps}, [task.STATES[s] for s in route]


def one_update_figure():
    # Same controlled calculation as v18_methods.dqn_one_update (seed 0, 32 copies, one Adam step).
    net = task.MLP(np.random.default_rng(0)); before = net.forward(task.FEATURES)
    state = task.INDEX[(3, 4)]; action = 1
    sp, reward, terminal = task.transition(state, action)
    assert sp == task.GOAL and reward == 1 and terminal
    batch = np.repeat(task.FEATURES[state][None], 32, axis=0)
    net.update(batch, np.full(32, action), np.full(32, 1.))
    after = net.forward(task.FEATURES); change = after-before
    fig, (ax, bx) = plt.subplots(1, 2, figsize=(9, 3.0), gridspec_kw={'width_ratios': [1.1, 1.]})
    x = np.arange(4)
    ax.bar(x-.18, before[state], .36, label='更新前', color=MUTED, alpha=.5)
    ax.bar(x+.18, after[state], .36, label='一次 Adam 更新后', color=TEAL)
    ax.axhline(0, color=MUTED, lw=.6)
    ax.set_xticks(x, ['上', '右', '下', '左'], fontsize=18)
    ax.tick_params(axis='y', labelsize=17)
    ax.yaxis.set_major_formatter(FuncFormatter(no_leading_zero))
    ax.set_ylabel('圈中状态的 $Q(s,a)$', fontsize=17, fontfamily=CJK_FAMILY)
    ax.set_title('记录的动作：右，奖励 1', fontsize=18)
    ax.spines[['top', 'right']].set_visible(False)
    ax.legend(frameon=False, fontsize=16, loc='upper left')
    arr = np.full((5, 5), np.nan)
    for i, (xx, yy) in enumerate(task.STATES):
        if i != task.GOAL:
            arr[yy, xx] = change[i, action]
    limit = np.nanmax(abs(arr)); cmap = plt.get_cmap('coolwarm').copy(); cmap.set_bad(INK)
    im = bx.imshow(arr, origin='lower', extent=(-.5, 4.5, -.5, 4.5), vmin=-limit, vmax=limit, cmap=cmap)
    bx.add_patch(Rectangle((3.5, 3.5), 1, 1, facecolor='#EAF4F3', edgecolor=MUTED))
    bx.text(4, 4, 'G', ha='center', va='center', fontsize=16, color=RED)
    bx.scatter([3], [4], facecolors='none', edgecolors=INK, s=190, lw=1.5)
    bx.annotate('', (3.78, 4), (3.18, 4), arrowprops={'arrowstyle': '->', 'lw': 1.7, 'color': INK})
    bx.set_xticks([]); bx.set_yticks([])
    bx.set_title('各格“右”的估值改变量', fontsize=18)
    cb = fig.colorbar(im, ax=bx, shrink=.84, pad=.03)
    cb.ax.tick_params(labelsize=16); cb.ax.yaxis.set_major_formatter(FuncFormatter(no_leading_zero))
    fig.tight_layout()
    save(fig, ROOT/'assets/v18-methods/dqn-one-update-zh')
    return float(before[state, action]), float(after[state, action])


if __name__ == '__main__':
    print('fonts found:', use_course_fonts())
    print('start values by round, route:', frontier_figure())
    print('Q(s,right) before/after:', one_update_figure())
