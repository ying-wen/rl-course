#!/usr/bin/env python3
"""Exact calculations for target-network and Double-DQN teaching figures.

Run with --mean-path --p .95 --copy-every 5 for the 20-step calculation.
Run without arguments to regenerate the figures.
No environment training is performed. The two-state prediction example uses the
same features and behavior/target policies as the preceding approximation pages.
Its weighted regression is not a DQN control experiment.
"""
from pathlib import Path
import argparse
import json

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'assets/course24-deep'
TEAL, RED, GOLD, MUTED, INK = '#087E8B', '#C65335', '#C4942A', '#61757D', '#182E38'
def plot_style():
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from plot_fonts import chinese_font
    plt.rcParams.update({'font.size': 14, 'pdf.fonttype': 42,
                         'axes.spines.top': False, 'axes.spines.right': False})
    return plt, chinese_font()


def save(fig, name):
    from matplotlib import pyplot as plt
    for extension in ('pdf', 'png'):
        fig.savefig(OUT / f'{name}.{extension}', bbox_inches='tight', dpi=200)
    plt.close(fig)


def fixed_target():
    """Fit frozen labels exactly, then copy the fit into the next target."""
    import numpy as np
    plt, font = plot_style()
    x = np.array([1., 2.])
    mu = np.array([.95, .05])
    gamma = .9
    # Both states go to s1 under the fixed target policy, so x' = 2.
    xp = np.full(2, 2.)
    C = mu @ (x*x)
    B = gamma * (mu @ (x*xp))
    multiplier = B/C
    target_w = 1.
    history = [target_w]
    residual_errors = []
    for _ in range(5):
        labels = gamma * xp * target_w
        # Independent least-squares solve; no closed-form multiplier in this step.
        fitted_w = np.linalg.lstsq(np.sqrt(mu)[:, None]*x[:, None],
                                   np.sqrt(mu)*labels, rcond=None)[0][0]
        residual_errors.append(abs(fitted_w-multiplier*target_w))
        target_w = fitted_w
        history.append(target_w)
    np.testing.assert_allclose(history, multiplier**np.arange(6), atol=1e-12)

    # Enumerate actual behavior state/action pairs and importance-ratio updates.
    # b(a0)=.95, b(a1)=.05; action aj always arrives at state sj.
    behavior = np.array([.95, .05])
    target = np.array([0., 1.])
    def drift(state_prob, action_prob, use_bootstrap=True):
        total = 0.
        for s in range(2):
            for a in range(2):
                if action_prob[a] == 0:
                    continue
                rho = target[a]/action_prob[a]
                label = gamma*x[a] if use_bootstrap else 0.
                total += state_prob[s]*action_prob[a]*rho*(label-x[s])*x[s]
        return total
    off_policy = drift(mu, behavior)
    on_policy = drift(np.array([0., 1.]), target)
    regression = drift(mu, behavior, False)
    np.testing.assert_allclose([off_policy, on_policy, regression], [.74, -.4, -1.15])

    # A finite number of inner gradient steps gives the same recurrence.
    alpha, steps, bar = .1, 10, 1.
    w = bar
    for _ in range(steps):
        w -= alpha*(C*w-B*bar)
    finite_factor = (1-alpha*C)**steps + multiplier*(1-(1-alpha*C)**steps)
    np.testing.assert_allclose(w, finite_factor, atol=1e-14)

    fig, axes = plt.subplots(1, 2, figsize=(11, 3.15), gridspec_kw={'width_ratios':[1.2, 1]})
    ax = axes[0]
    grid = np.linspace(0, 2.15, 120)
    ax.plot(grid, grid, '--', color=MUTED, lw=1.7, label='复制前：w=1')
    ax.axhline(1.8, color=GOLD, lw=2, label='冻结标签：y=1.8')
    ax.plot(grid, multiplier*grid, color=TEAL, lw=2.3, label='精确拟合：w=1.6435')
    for state, weight in zip(range(2), mu):
        ax.plot([x[state], x[state]], [1.8, multiplier*x[state]], color=RED, lw=2)
        ax.scatter(x[state], 1.8, s=500*weight, color=GOLD, edgecolors='white', zorder=5)
        ax.scatter(x[state], multiplier*x[state], s=45, color=TEAL, zorder=6)
    ax.text(.98, 1.98, '95%', color=GOLD, ha='right', fontsize=13)
    ax.text(2.04, 1.5, '5%', color=GOLD, fontsize=13)
    ax.set_xticks([0,1,2], ['0', '$x(s_0)=1$', '$x(s_1)=2$'])
    ax.set(xlim=(0,2.27), ylim=(-.12,3.65), yticks=[0,1,1.8,3.3])
    ax.set_xlabel('共享直线的输入特征', fontproperties=font)
    ax.set_ylabel('预测 / 标签', fontproperties=font)
    ax.set_title('① 固定标签，按状态权重拟合', fontproperties=font, fontsize=17)
    ax.legend(prop=font, fontsize=10, frameon=False, loc='upper left', bbox_to_anchor=(0,1.03))
    ax = axes[1]
    ax.plot(range(6), history, 'o-', color=TEAL, lw=2.5)
    ax.axhline(0, color=MUTED, ls='--', lw=1.5)
    ax.text(3.1, .5, '真实价值：0', fontproperties=font, color=MUTED)
    for k in (0,1,3,5):
        ax.annotate(f'{history[k]:.2f}', (k,history[k]), textcoords='offset points',
                    xytext=(0,8), ha='center', fontsize=13)
    ax.text(.55, 8.8, '每次复制 ×1.6435', fontproperties=font, fontsize=16, color=TEAL)
    ax.set(xlim=(-.2,5.35), ylim=(-.5,14), xticks=range(6), yticks=[0,4,8,12])
    ax.set_xlabel('完成精确拟合并复制的次数', fontproperties=font)
    ax.set_ylabel(r'$\bar w$', rotation=0, labelpad=8)
    ax.set_title('② 复制参数，再构造标签', fontproperties=font, fontsize=17)
    fig.tight_layout(w_pad=2)
    save(fig, 'fixed-target-outer-loop')
    return {'calculation':'exact weighted prediction regression; no training',
            'C':float(C), 'B':float(B), 'exact_copy_multiplier':float(multiplier),
            'copied_weights':history, 'independent_lstsq_max_error':max(residual_errors),
            'expected_td_drifts':{'off_policy':off_policy,'on_policy':on_policy,
                                  'zero_label_regression':regression},
            'finite_inner':{'alpha':alpha,'steps':steps,'multiplier':float(finite_factor),
                            'direct_iteration_error':float(abs(w-finite_factor))}}


def double_dqn():
    """Two value estimates at one next state; separate selection/evaluation."""
    import numpy as np
    plt, font = plot_style()
    online = np.array([5.,4.])
    target = np.array([2.,6.])
    action = int(online.argmax())
    dqn = 1+.9*target.max()
    ddqn = 1+.9*target[action]
    np.testing.assert_allclose([dqn,ddqn],[6.4,2.8])
    fig, axes = plt.subplots(1, 2, figsize=(10, 2.8), sharey=True)
    for ax, values, title, color in zip(axes, (online,target),
           ('① 在线网络选择动作', '② 目标网络读取同一动作'), (TEAL,GOLD)):
        bars=ax.bar(range(2), values, width=.53, color=[color, '#C9D3D5'])
        for i,v in enumerate(values):
            ax.text(i,v+.16,f'{v:g}',ha='center',fontsize=18,color=INK)
        ax.set_xticks([0,1], ['$a_1$','$a_2$'])
        ax.set(ylim=(0,7.7),yticks=[0,2,4,6],xlim=(-.65,1.65))
        ax.set_ylabel(r"$Q(s',a)$")
        ax.set_title(title,fontproperties=font,fontsize=17)
    axes[0].annotate('选择最大值',xy=(0,5),xytext=(.45,7),fontproperties=font,
                     ha='center',color=TEAL,arrowprops=dict(arrowstyle='->',color=TEAL,lw=2))
    axes[1].annotate('读取 2，不重新取最大值',xy=(0,2),xytext=(.2,4.4),fontproperties=font,
                     ha='center',color=GOLD,arrowprops=dict(arrowstyle='->',color=GOLD,lw=2))
    fig.tight_layout(w_pad=2)
    save(fig, 'double-dqn-selection')
    return {'online':online.tolist(),'target':target.tolist(),'selected_action_index':action,
            'reward':1.,'gamma':.9,'dqn_target':float(dqn),'double_dqn_target':float(ddqn),
            'claim':'constructed target calculation, not a performance comparison'}



def mean_prediction_path(p, copy_every, steps=20):
    """Apply the exact expected semi-gradient to two states, then copy on schedule."""
    if not (0 <= p < 1):
        raise ValueError("p must lie in [0, 1) so the behavior covers the target action")
    if not isinstance(copy_every, int) or copy_every < 1 or steps < 0:
        raise ValueError("copy_every must be a positive integer and steps nonnegative")
    weights = (p, 1 - p)
    features = (1, 2)
    online = target = 1.0
    rows = []
    for step in range(1, steps + 1):
        # Conditional on the target action, the successor always has feature 2.
        label = 0.9 * 2 * target
        update = sum(prob * (label - online * x) * x for prob, x in zip(weights, features))
        online += 0.1 * update
        if step % copy_every == 0:
            target = online
        rows.append({'step': step, 'label_before': label, 'online_after': online,
                     'target_after': target, 'v_s1_after': 2 * online})
    return rows


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--mean-path', action='store_true', help='print mean updates without writing figures')
    parser.add_argument('--p', type=float, default=.95, help='behavior probability of going to state 0')
    parser.add_argument('--copy-every', type=int, default=5, help='number of updates between copies')
    args = parser.parse_args()
    if args.mean_path:
        try:
            path = mean_prediction_path(args.p, args.copy_every)
        except ValueError as error:
            parser.error(str(error))
        print(json.dumps(path, indent=2))
        raise SystemExit(0)
    OUT.mkdir(parents=True, exist_ok=True)
    report = {'frozen_regression':fixed_target(),'double_dqn':double_dqn()}
    (OUT/'checks.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(report,ensure_ascii=False,indent=2))
