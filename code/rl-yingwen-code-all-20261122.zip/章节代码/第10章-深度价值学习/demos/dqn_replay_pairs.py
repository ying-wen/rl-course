"""Enumerate adjacent and uniform replay pairs from AAAABBBB, as in chapter 10."""

from fractions import Fraction
from itertools import product


def main():
    regions = "AAAABBBB"
    indices = range(len(regions))
    pairs = {
        "adjacent": list(zip(indices, indices[1:])),
        "independent replay": list(product(indices, repeat=2)),
    }
    for name, batch in pairs.items():
        same = sum(regions[i] == regions[j] for i, j in batch)
        in_a = sum((regions[i] == "A") + (regions[j] == "A") for i, j in batch)
        expected_in_a = Fraction(in_a, len(batch))
        print(f"{name}: same region {same}/{len(batch)}, E[A count] {expected_in_a}")
        assert expected_in_a == 1
        assert Fraction(same, len(batch)) == (
            Fraction(6, 7) if name == "adjacent" else Fraction(1, 2)
        )


if __name__ == "__main__":
    main()
