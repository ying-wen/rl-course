#!/usr/bin/env python3
"""Independent finite calculations for the v9 Ch10-13 rewritten examples.
Standard library only. Does not train or claim to implement full DQN/PPO/Dreamer.
Run: python3 demos/deep_v9_checks.py [--json output.json]
"""
import argparse
import json
import math
from pathlib import Path

def near(a, b, tol=1e-8):
    assert abs(a-b) <= tol, (a, b, tol)

def fd(f, x, h=1e-6):
    return (f(x+h)-f(x-h))/(2*h)

def sigmoid(x):
    return 1/(1+math.exp(-x))

def softmax(x):
    e=[math.exp(v-max(x)) for v in x]
    return [v/sum(e) for v in e]

def check_score():
    h=[0.,math.log(3)]
    analytic=[.75,-.75]
    numeric=[]
    for j in range(2):
        def f(x):
            v=h.copy();v[j]=x
            return math.log(softmax(v)[0])
        numeric.append(fd(f,h[j]));near(numeric[-1],analytic[j])
    # Parameter theta has nontrivial logit Jacobian: h=(2theta,theta+log3).
    d=fd(lambda t: math.log(softmax([2*t,t+math.log(3)])[0]),0.)
    near(d,.75)
    return dict(logit_score=analytic,finite_difference=numeric,parameter_score=d)

def check_value_policy():
    q=[2.,5.,1.]; target=8.; step=.75
    numerical=fd(lambda v:.5*(v-target)**2,q[0]);near(numerical,-6.)
    updated=q.copy();updated[0]-=step*numerical;near(updated[0],6.5)
    def behavior(values):
        best=max(range(3),key=values.__getitem__)
        return [.2/3+(.8 if a==best else 0.) for a in range(3)]
    before,after=behavior(q),behavior(updated)
    near(sum(before),1.);near(sum(after),1.)
    assert before[1]>before[0] and after[0]>after[1]
    return dict(target=target,gradient=numerical,q_before=q,q_after=updated,behavior_before=before,behavior_after=after)

def check_ppo():
    def objective(t):
        p=sigmoid(t)
        out=[]
        for ratio,adv in [(2*p,1.),(2*(1-p),-1.)]:
            clipped=max(.8,min(1.2,ratio))
            out.append(min(ratio*adv,clipped*adv))
        return sum(out)/2
    g=fd(objective,0.);near(g,.5)
    theta=.5; p=sigmoid(theta);r=[2*p,2*(1-p)]
    assert r[0]>1.2 and r[1]<.8
    flat=fd(objective,theta);near(flat,0.)
    return dict(initial_gradient=g,theta_after=theta,probability_after=p,ratios_after=r,next_gradient=flat)

def check_c51():
    # Brute-force linear interpolation onto fixed grid, including exact-grid case.
    grid=[-1.,0.,1.]
    def project(y,mass=1.):
        y=max(grid[0],min(grid[-1],y));out=[0.]*3
        for k,z in enumerate(grid):
            if y==z: out[k]=mass;return out
        for k in range(2):
            if grid[k]<y<grid[k+1]:
                out[k]=mass*(grid[k+1]-y)/(grid[k+1]-grid[k])
                out[k+1]=mass*(y-grid[k])/(grid[k+1]-grid[k]);return out
        raise AssertionError(y)
    p=project(.25,.4);near(p[1],.3);near(p[2],.1)
    near(sum(p),.4);near(sum(z*m for z,m in zip(grid,p)),.4*.25)
    exact=project(0.);near(sum(exact),1.);near(exact[1],1.)
    clipped=project(2.);near(sum(z*m for z,m in zip(grid,clipped)),1.)
    return dict(mass_at_quarter=p,exact_grid=exact,clipped_mean=1.,unclipped_value=2.)

def check_entropy():
    def f(p):
        if p==0: return 0.
        if p==1: return 1.
        return p-p*math.log(p)-(1-p)*math.log(1-p)
    analytic=sigmoid(1.)
    grid=max((i/100000 for i in range(100001)),key=f)
    assert abs(grid-analytic)<1e-5
    near(fd(f,analytic),0.)
    return dict(boltzmann_action1=analytic,grid_optimum=grid)

def check_variance():
    rates=[.2,.8];mean=sum(rates)/2
    within=sum(p*(1-p) for p in rates)/2
    between=sum((p-mean)**2 for p in rates)/2
    # Independent direct marginal Bernoulli variance, not the decomposition itself.
    direct=mean*(1-mean)
    near(within,.16);near(between,.09);near(within+between,direct)
    return dict(within=within,between=between,total=direct,known_fair_coin_model_variance=0.)

def check_mopo():
    # Exact two-state evaluation by solving the Bellman 2x2 system, no rollouts.
    gamma=.8; P=[[.7,.3],[.2,.8]]; Ph=[[.6,.4],[.4,.6]];r=[.1,1.];mu=[1.,0.]
    def solve(A,b):
        det=A[0][0]*A[1][1]-A[0][1]*A[1][0]
        return [(b[0]*A[1][1]-A[0][1]*b[1])/det,(A[0][0]*b[1]-b[0]*A[1][0])/det]
    def value(T,reward):
        return solve([[1-gamma*T[0][0],-gamma*T[0][1]],[-gamma*T[1][0],1-gamma*T[1][1]]],reward)
    v,vh=value(P,r),value(Ph,r)
    delta=[sum((P[i][j]-Ph[i][j])*v[j] for j in range(2)) for i in range(2)]
    # Occupancy independently sums the distribution sequence under model transitions.
    d=[0.,0.];cur=mu.copy();weight=1-gamma
    for _ in range(300):
        for i in range(2):d[i]+=weight*cur[i]
        cur=[sum(cur[i]*Ph[i][j] for i in range(2)) for j in range(2)]
        weight*=gamma
    true_diff=v[0]-vh[0]; identity=gamma/(1-gamma)*sum(d[i]*delta[i] for i in range(2))
    near(true_diff,identity)
    u=[abs(x) for x in delta]
    pessimistic=value(Ph,[r[i]-gamma*u[i] for i in range(2)])[0]
    assert v[0]>=pessimistic-1e-9
    return dict(true_values=v,model_values=vh,model_occupancy=d,actual_difference=true_diff,identity=identity,pessimistic_model_return=pessimistic)

def check_flow():
    a,noise,t=.6,.2,.5
    path=lambda eta:eta*a+(1-eta)*noise
    residual=noise-a
    near(path(t),.4);near(fd(path,t),.4);near(residual,-.4)
    near(fd(path,t),-residual)
    old=.1;grad=fd(lambda out:.5*(out-residual)**2,old);near(grad,.5)
    updated=old-.2*grad;near(updated,0.)
    return dict(input=path(t),path_derivative=a-noise,residual_target=residual,output_gradient=grad,output_after=updated)

def main():
    p=argparse.ArgumentParser();p.add_argument('--json',type=Path);args=p.parse_args()
    results={name:fn() for name,fn in [('score',check_score),('value_policy',check_value_policy),('ppo',check_ppo),('c51',check_c51),('entropy',check_entropy),('variance',check_variance),('model_performance_identity',check_mopo),('flow_sign',check_flow)]}
    data={'status':'pass','checks':len(results),'scope':'Finite calculations and independent finite differences; not full algorithm training.','results':results}
    output=json.dumps(data,ensure_ascii=False,indent=2)
    if args.json:args.json.parent.mkdir(parents=True,exist_ok=True);args.json.write_text(output+'\n')
    print(output)
if __name__=='__main__':main()
