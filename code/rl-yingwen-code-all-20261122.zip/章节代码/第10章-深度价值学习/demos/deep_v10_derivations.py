#!/usr/bin/env python3
"""Finite mechanisms for v10 chapters 10,12,13. Standard library only.
Run from any directory. --output overrides assets/deep-v10.
No full neural, language-model or robot training is performed.
"""
import argparse,csv,json,math
from pathlib import Path

def near(x,y,tol=1e-8):
 assert abs(x-y)<tol,(x,y)
def fd(f,x,h=1e-6):return (f(x+h)-f(x-h))/(2*h)
def softmax(h):
 e=[math.exp(x-max(h)) for x in h];return [x/sum(e) for x in e]
def sigmoid(x):return 1/(1+math.exp(-x))
def writecsv(out,name,header,rows):
 with (out/name).open('w',newline='') as f:
  w=csv.writer(f);w.writerow(header);w.writerows(rows)
def run(out):
 out.mkdir(parents=True,exist_ok=True);results={}
 # Fixed-target SGD vs total residual derivative, independently finite-differenced.
 w,bar,gamma=1.,1.,.9
 frozen_grad=fd(lambda x:.5*(x-gamma*2*bar)**2,w)
 residual_grad=fd(lambda x:.5*(x-gamma*2*x)**2,w)
 near(frozen_grad,-.8);near(residual_grad,.64)
 seq=[1.8**k for k in range(7)]
 assert all(seq[k+1]>seq[k] for k in range(6))
 writecsv(out,'target-refresh.csv',['cycle','w'],enumerate(seq))
 results['dqn']={'fixed_target_gradient':frozen_grad,'full_residual_gradient':residual_grad,'exact_fits_after_copy':seq,'zero_is_representable':True}
 # C51: terminal reward .75, grid[-1,0,1], target[0,.25,.75].
 grid=[-1.,0.,1.];target=[0.,.25,.75];old=[1/3]*3;h=[0.]*3
 grad=[old[i]-target[i] for i in range(3)]
 def ce(h):return -sum(t*math.log(p) for t,p in zip(target,softmax(h)))
 for j in range(3):
  def loss(x):v=h.copy();v[j]=x;return ce(v)
  near(fd(loss,0.),grad[j])
 hp=[-g for g in grad];new=softmax(hp);mean=sum(z*p for z,p in zip(grid,new))
 assert ce(hp)<ce(h) and mean>.15
 writecsv(out,'c51-update.csv',['z','before','target','after'],zip(grid,old,target,new))
 results['c51']={'target':target,'gradient':grad,'new_logits':hp,'new_probabilities':new,'new_mean':mean,'alternative_q':.15}
 # Fit known-form dynamics from actual finite samples, then compare shooting vs Bellman DP.
 data=[(1.,0.,.8),(-1.,1.,.2)]
 ahat=sum(x*(xp-u) for x,u,xp in data)/sum(x*x for x,u,xp in data);near(ahat,.8)
 near(sum(x*(xp-ahat*x-u) for x,u,xp in data),0.)
 U=[-1.,0.,1.];g=.9
 def transition(x,u):return ahat*x+u
 def reward(x,u):return -transition(x,u)**2-.1*u*u
 candidates=[]
 for u in U:
  x1=transition(1.,u)
  for v in U:
   x2=transition(x1,v);value=reward(1.,u)+g*reward(x1,v);candidates.append([u,v,x1,x2,value])
 best=max(candidates,key=lambda row:row[4])
 def bellman(x,depth):
  if not depth:return 0.
  return max(reward(x,u)+g*bellman(transition(x,u),depth-1) for u in U)
 near(best[4],bellman(1.,2));assert best[:2]==[-1.,0.]
 writecsv(out,'mpc-candidates.csv',['u0','u1','x1','x2','value'],candidates)
 writecsv(out,'model-data.csv',['x','u','next_x'],data)
 results['model_mpc']={'estimated_a':ahat,'best_sequence':best,'independent_bellman_value':bellman(1.,2)}
 # Offline indistinguishability. All qc agree on observed endpoints, not at unseen actions.
 q=lambda a,c:.5+.5*a+c*(1-a*a)
 for a in [-1.,1.]:near(q(a,0),q(a,2))
 astar=.125;near(fd(lambda a:q(a,2),astar),0.)
 dense=[i/10000 for i in range(-10000,10001)]
 brute=max(dense,key=lambda a:q(a,2));near(brute,astar,1e-5)
 writecsv(out,'offline-extrapolation.csv',['action','true_q','unsupported_q'],[(a,q(a,0),q(a,2)) for a in [i/100 for i in range(-100,101)]])
 results['offline']={'data_actions':[-1.,1.],'data_rewards':[0.,1.],'unsupported_argmax':astar,'unsupported_prediction':q(astar,2),'actual_reward_at_chosen_action':q(astar,0),'supported_best_reward':1.,'previous_state_false_target':.9*q(astar,2)}
 # Weighted categorical maximum likelihood, independently checked by exhaustive probability grid.
 b=[.9,.1];Q=[0.,2.];beta=1.;weight=[b[i]*math.exp(beta*Q[i]) for i in range(2)]
 p=weight[1]/sum(weight)
 def loss(p):return -weight[0]*math.log(1-p)-weight[1]*math.log(p)
 dense=[i/100000 for i in range(1,100000)];gridp=min(dense,key=loss)
 assert abs(gridp-p)<1e-5;near(fd(loss,p),0.)
 writecsv(out,'weighted-extraction.csv',['action','behavior','weight','policy'],[(i,b[i],math.exp(beta*Q[i]),weight[i]/sum(weight)) for i in range(2)])
 results['extraction']={'behavior':b,'q':Q,'policy':[1-p,p],'grid_optimum_probability_action1':gridp,'policy_value':2*p}
 # V-trace rho clipping changes the one-step Bellman fixed point; no Monte Carlo assumption.
 b=[.8,.2];pi=[.2,.8];rho=[min(1.,pi[i]/b[i]) for i in range(2)]
 omega=[b[i]*rho[i] for i in range(2)];pclip=[x/sum(omega) for x in omega]
 def expected_update(v):return sum(b[i]*rho[i]*(i-v) for i in range(2))
 root=.5;near(expected_update(root),0.);assert abs(expected_update(.8))>.1
 results['vtrace']={'rho':rho,'unnormalized_mass':omega,'effective_policy':pclip,'fixed_point':root,'target_policy_value':.8}
 # Two decision program task. Enumerate all paths separately from value-based PG.
 def success(theta0,thetap):return sigmoid(theta0)*sigmoid(thetap)
 exact=[fd(lambda z:success(z,0.),0.),fd(lambda z:success(0.,z),0.)]
 enum_g=[0.,0.]
 for sign in [0,1]:
  for literal in [0,1]:
   probability=.25;reward=float(sign==1 and literal==1)
   enum_g[0]+=probability*reward*(sign-.5)
   enum_g[1]+=probability*reward*(literal-.5) if sign else 0.
 for a,b in zip(exact,enum_g):near(a,b)
 advantages=[.5-.25,1.-.5];sample_g=[advantages[0]*.5,advantages[1]*.5];newtheta=[.4*x for x in sample_g]
 newp=[sigmoid(x) for x in newtheta]
 assert success(*newtheta)>.25
 writecsv(out,'token-update.csv',['decision','advantage','score','gradient','theta_after','probability_after'],[(i,advantages[i],.5,sample_g[i],newtheta[i],newp[i]) for i in range(2)])
 results['tokens']={'true_root_v':.25,'true_plus_v':.5,'expected_gradient_by_finite_difference':exact,'expected_gradient_by_enumeration':enum_g,'sample_success_gradient':sample_g,'new_logits':newtheta,'new_probabilities':newp,'new_success_probability':success(*newtheta)}
 # One-step lateral robot correction: least squares parameters recovered from three real-form samples.
 x=.4;r=lambda u:-(x+u)**2-.1*u*u
 us=[-.4,0.,.4];ys=[r(u) for u in us]
 phi0=-ys[1];phi1=(ys[0]-ys[2])/.8;phi2=-(ys[0]+ys[2]+2*phi0)/(.32)
 pred=lambda u:-phi0-phi1*u-phi2*u*u
 for u,y in zip(us,ys):near(pred(u),y)
 near(phi0,.16);near(phi1,.8);near(phi2,1.1)
 initial=0.;gradient=-phi1-2*phi2*initial;near(fd(pred,initial),gradient)
 update=initial+.25*gradient;near(update,-.2)
 assert r(update)>r(initial)
 optimum=-phi1/(2*phi2);near(fd(r,optimum),0.)
 writecsv(out,'robot-value.csv',['action','true_q','fitted_q'],[(u,r(u),pred(u)) for u in [i/100 for i in range(-50,51)]])
 writecsv(out,'robot-data.csv',['action','reward'],zip(us,ys))
 results['robot']={'data':list(zip(us,ys)),'critic_parameters':[phi0,phi1,phi2],'actor_gradient':gradient,'action_before':initial,'action_after':update,'reward_before':r(initial),'reward_after':r(update),'optimal_action':optimum}
 payload={'status':'pass','scope':'8 finite mechanism checks; not full DQN/Dreamer/LLM/robot learning experiments.','groups':len(results),'results':results}
 (out/'results.json').write_text(json.dumps(payload,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps(payload,ensure_ascii=False,indent=2))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=Path(__file__).resolve().parents[1]/'assets/deep-v10');args=p.parse_args();run(args.output)
