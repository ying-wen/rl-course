"""Plot three greedy routes from the saved seed-0 DQN action values."""
import csv
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap, Normalize
from matplotlib.patches import Rectangle
import numpy as np

import dqn_model_v11 as task
from plot_fonts import chinese_font

ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "assets/course32-methods"
FONT = chinese_font()
STEPS = (0, 1000, 10000)
ACTIONS = ("up", "right", "down", "left")
DIRECTIONS = ("上", "右", "下", "左")


def render():
    values = {step: {} for step in STEPS}
    with (ROOT / "assets/dqn-model-v11/grid-q-map.csv").open() as records:
        for r in csv.DictReader(records):
            step = int(r["checkpoint"])
            if step in values:
                pos = (int(r["x"]), int(r["y"]))
                values[step][pos] = np.array([float(r[a]) for a in ACTIONS])

    fig, axes = plt.subplots(1, 3, figsize=(10.4, 3.7))
    fig.subplots_adjust(left=.025, right=.975, top=.85, bottom=.18, wspace=.18)
    cmap = LinearSegmentedColormap.from_list("value", ["#f6f6f1", "#9acdc5", "#1b786f"])
    scale = Normalize(vmin=-.2, vmax=1, clip=True)
    for ax, step in zip(axes, STEPS):
        q = values[step]
        for xy in task.WALLS:
            ax.add_patch(Rectangle(xy, 1, 1, facecolor="#36474e", edgecolor="white"))
        for xy in task.STATES:
            color = "#f7dc9c" if task.INDEX[xy] == task.GOAL else cmap(scale(max(q[xy])))
            ax.add_patch(Rectangle(xy, 1, 1, facecolor=color, edgecolor="white", linewidth=1.3))
        current = task.INDEX[(0, 0)]
        path = [current]
        while current != task.GOAL:
            choice = int(q[task.STATES[current]].argmax())
            current, _, done = task.transition(current, choice)
            if current in path:
                path.append(current)
                break
            path.append(current)
            if done:
                break
        # The original snapshots give a self-loop, followed by two eight-step routes.
        assert (len(path), path[-1] == task.GOAL) == ((2, False) if not step else (9, True))
        xy = np.array([task.STATES[s] for s in path]) + .5
        ax.plot(xy[:, 0], xy[:, 1], color="white", linewidth=5, solid_capstyle="round")
        ax.plot(xy[:, 0], xy[:, 1], color="#aa421f", linewidth=2.5, solid_capstyle="round")
        if step == 0:
            ax.annotate("", xy=(.02, .5), xytext=(.45, .5),
                        arrowprops=dict(arrowstyle="-|>", lw=2.5, color="#aa421f"))
        ax.scatter(*xy[0], s=43, facecolor="white", edgecolor="#aa421f", linewidth=2, zorder=3)
        ax.text(4.5, 4.5, "G", ha="center", va="center", fontsize=13, fontweight="bold",
                bbox=dict(facecolor="#f7dc9c", edgecolor="none", pad=1.2))
        maximum = q[(0, 0)].max()
        action = DIRECTIONS[q[(0, 0)].argmax()]
        ax.set_title(f"{step:,} 次真实交互", fontproperties=FONT, fontsize=16, pad=9)
        ax.text(.5, -.08, f"起点选{action}　最大 Q = {maximum:.3f}",
                ha="center", va="top", transform=ax.transAxes, fontproperties=FONT, fontsize=13)
        ax.set(xlim=(0, 5), ylim=(0, 5), aspect="equal")
        ax.axis("off")

    cb = fig.colorbar(plt.cm.ScalarMappable(norm=scale, cmap=cmap),
                      cax=fig.add_axes([.35, .012, .3, .022]), orientation="horizontal")
    cb.set_ticks([-.2, .4, 1])
    cb.outline.set_visible(False)
    cb.ax.tick_params(labelsize=9, length=2, pad=2)
    fig.text(.338, .019, "各格的最大 Q", ha="right", va="center",
             fontproperties=FONT, fontsize=11)
    OUTPUT.mkdir(exist_ok=True)
    fig.savefig(OUTPUT / "greedy-route.pdf", bbox_inches="tight", pad_inches=.08)
    fig.savefig(OUTPUT / "greedy-route.png", dpi=160, bbox_inches="tight", pad_inches=.08)
    plt.close(fig)


if __name__ == "__main__":
    render()
