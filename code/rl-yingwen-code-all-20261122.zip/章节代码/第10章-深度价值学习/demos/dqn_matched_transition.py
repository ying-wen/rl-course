"""One grid transition, one SGD step: exact table and network predictions.

Run: python3 demos/dqn_matched_transition.py
The initial weights are specified for a hand calculation. The environment,
network forward pass, and loss gradient come from the chapter's grid experiment.
"""
from copy import deepcopy
import numpy as np

from dqn_model_v11 import FEATURES, GAMMA, INDEX, MLP, transition


def initial_network(s, sp):
    net = MLP(np.random.default_rng(0))
    for parameter in net.p:
        parameter.fill(0.)
    # Activate one shared tanh unit. Its outputs at s and sp are .5 and .75.
    net.p[0][s, 0] = np.arctanh(.5)
    net.p[0][sp, 0] = np.arctanh(.75)
    net.p[2][0] = [.8, -.4, 0., 0.]
    return net


def main():
    s, a = INDEX[(1, 2)], 0  # up
    sp, reward, done = transition(s, a)
    assert sp == INDEX[(1, 3)] and not done
    online = initial_network(s, sp)
    target = deepcopy(online)
    before = online.forward(FEATURES)
    table = before.copy()
    y = reward + GAMMA * (1 - done) * target.forward(FEATURES[[sp]]).max()
    delta = y - before[s, a]
    alpha = .1
    table[s, a] += alpha * delta
    _, grad = online.loss_grad(FEATURES[[s]], np.array([a]), np.array([y]))
    for parameter, component in zip(online.p, grad):
        parameter -= alpha * component
    after = online.forward(FEATURES)
    assert np.allclose([y, delta, table[s, a]], [.562, .162, .4162])
    assert np.count_nonzero(table != before) == 1
    assert np.allclose(target.forward(FEATURES), before)
    assert after[sp, a] > before[sp, a] and after[s, 1] < before[s, 1]
    print(f'target {y:.6f}; TD error {delta:.6f}; learning rate {alpha:.2f}')
    print('state/action       before    table      net      frozen')
    for name, i in [('s ', s), ("s'", sp)]:
        for action, j in [('up', 0), ('right', 1)]:
            print(f'{name:2s} {action:5s} {before[i,j]:13.6f} {table[i,j]:9.6f}'
                  f' {after[i,j]:9.6f} {target.forward(FEATURES[[i]])[0,j]:9.6f}')
    new_y = reward + GAMMA * after[sp].max()
    print(f'next label: frozen {y:.6f}, if copied now {new_y:.6f}')


if __name__ == '__main__':
    main()
