# 第 10 章　深度价值学习：程序

本目录可以单独运行：在本目录下执行下面的命令即可，结果写回本目录的 `assets/`。目录由 `rl-course/tools/export_chapter_code.py` 从课程目录生成，改程序请改课程目录里的原件，再重新导出。

## 准备

```sh
python3 -m pip install -r requirements.txt
```

需要的第三方包：matplotlib、numpy、torch；只有个别程序需要的：fitz（course_v12_visuals.py）。复现附录要求 Python 3.10 或更新版本；核验时用的版本见下表。

## 运行（与复现附录相同）

```sh
python demos/v18_methods.py
python demos/v19_deep_value.py
python3 demos/deep_v9_checks.py
python3 demos/deep_v10_derivations.py
python3 demos/dqn_matched_transition.py
python3 demos/dqn_replay_pairs.py
python3 demos/course24_deep_coupling.py
python demos/fragment_control.py --replay-probability 1/20
python demos/fragment_control.py --replay-probability 1/18
python3 demos/course_v12_visuals.py
python3 demos/deep_v13_connections.py
python3 demos/ch10_mechanisms.py
python3 demos/maximization_control.py
python3 demos/dqn_target_check.py
python demos/value_policy_mechanisms.py
python3 demos/dqn_model_v11.py
python3 demos/dqn_model_v11.py --test-only
python demos/course32_navigation_figure.py
python demos/grid_policy_readout.py
```

## 本目录的程序

| 程序 | 说明 | 核验 |
|---|---|---|
| `demos/v18_methods.py` | One-update scientific diagrams for chapters 7--11; no training runs. | 通过（3 秒） |
| `demos/v19_deep_value.py` | Bellman targets, neural derivatives, and retained DQN policies. | 通过（4 秒） |
| `demos/deep_v9_checks.py` | Independent finite calculations for the v9 Ch10-13 rewritten examples. | 通过（0 秒） |
| `demos/deep_v10_derivations.py` | Finite mechanisms for v10 chapters 10,12,13. Standard library only. | 通过（0 秒） |
| `demos/dqn_matched_transition.py` | One grid transition, one SGD step: exact table and network predictions. | 通过（0 秒） |
| `demos/dqn_replay_pairs.py` | Enumerate adjacent and uniform replay pairs from AAAABBBB, as in chapter 10. | 通过（0 秒） |
| `demos/course24_deep_coupling.py` | Exact calculations for target-network and Double-DQN teaching figures. | 通过（2 秒） |
| `demos/fragment_control.py` | Q-learning with one-transition fragments of the course's two-step tree. | 通过（0 秒） |
| `demos/dqn_model_v11.py` | CPU learning experiments for chapters 10 and 12, not paper reproductions. | 通过（12 秒） |
| `demos/course_v12_visuals.py` | Exact teaching examples and credited source crops for the v12 course bridges. | 通过（1 秒） |
| `demos/deep_v13_connections.py` | Recompute the numerical mechanisms used in Chapters 9--12. | 通过（2 秒） |
| `demos/ch10_mechanisms.py` | 第 10 章机制页的数值。 | 通过（159 秒） |
| `demos/maximization_control.py` | Exact two-step control example for Double DQN. Run with Python 3. | 通过（0 秒） |
| `demos/dqn_target_check.py` | Exact DQN mechanics, Python standard library; not neural training. | 通过（0 秒） |
| `demos/value_policy_mechanisms.py` | Small, exact calculations for chapters 9--11. Python 3 + numpy + matplotlib. | 通过（2 秒） |
| `demos/course32_navigation_figure.py` | Plot three greedy routes from the saved seed-0 DQN action values. | 通过（1 秒） |
| `demos/grid_policy_readout.py` | Trace the frozen greedy policies in the saved seed-0 DQN experiment. | 通过（0 秒） |
| `demos/ch10_fitted_figures.py` | Chapter 10.3 figures in the slide fonts (11-21 review request r1121-113957). | 通过（2 秒） |
| `demos/ch10_greedy_route_tikz.py` | Write the three greedy-route maps of slide dqn-v11-maps as TikZ code. | 通过（0 秒） |

被上面程序 import 的本课模块：`demos/course15_traces.py`、`demos/mud_world.py`、`demos/plot_fonts.py`、`demos/ppo_sac_v11_lab.py`、`demos/sample14_pg.py`、`demos/sample14_sac.py`、`demos/v17_methods.py`。

表中后 2 个程序复现附录本章一节没有列出，来自课件、阅读稿、CODE-MAP 或文件名前缀（第三部分另含学习器阶梯）。

## 复现附录本章一节

本章的单次更新与目标冻结算例、终止与截断的对照、最大化偏差、网格上 DQN 与表格 Q-learning 的对比、回放比与三次运行的统计，都来自本课的程序。DQN 原图、Rainbow 消融与 Seaquest 价值曲线取自原论文，不在表中。

| 位置 | 结果 | 设置 | 程序 | 数据与输出 |
|---|---|---|---|---|
| 10.1 节“一条终止记录对共享预测的影响”；课件 deep-dqn-coordinate | 在 $(3,4)$ 向右进入终点的终止记录（标签 1）做一次 Adam 更新，所执行动作的输出从 $.02943$ 增至 $.04009$，其他三个输出与其他格的右动作值也因共享参数改变；有限差分核对共享输出权重的导数 | 本课的计算：一次随机初始化的 $22\to32\tanh\to4$ 网络，步长 $.001$，批次为同一条记录的 32 个副本，一次 Adam 更新，不刷新目标网络 | `demos/v18_methods.py` | `assets/v18-methods/report.json`；`assets/v18-methods/dqn-one-update.png` |
| 10.3 节“从精确最优性迭代到拟合 Q 迭代”“固定目标的梯度与整个Bellman残差的梯度”；课件 deep-dqn-fitted | 冻结目标一步：标签 $y=.14097$，更新前预测 $-.04082$，误差 $.18179$，更新后上动作预测 $.01171$；已知模型的同步 Bellman 更新；两状态例 $T_\pi Q_k=(1.8,1.8)$ 投影回直线得 $(1.6435,3.287)$，复制倍数 $1.6435$ | 本课的计算：已知模型的精确表格计算与加权投影回归，不训练网络；目标副本用独立数组保存 | `demos/v19_deep_value.py` | `assets/v19-deep-value/results.json`（`frozen_target`、`bellman_propagation`、`fitted_prediction`）；图 frozen-target-step、bellman-propagation、fitted-prediction 的 PNG 与 PDF 在同一目录 |
| 10.3 节“Q更新与行为概率” | 只更新被选动作的独立参数后，两组更新所得的行为概率 | 本课的计算：有限枚举，仅用 Python 标准库 | `demos/deep_v9_checks.py`（`check_value_policy`） | 终端输出；加 `--json` 可写出 JSON |
| 10.3 节；“阅读与实现” | 固定目标外循环的复制序列（$w$：$1\to1.8\to\cdots$），固定目标梯度 $-.8$ | 本课的计算：有限算例，不训练网络 | `demos/deep_v10_derivations.py` | `assets/deep-v10/results.json`（`dqn`）；`assets/deep-v10/target-refresh.csv` |
| 10.2 节开头的同一转移对照；课件 ch10-matched-update、ch10-shared-write、ch10-bridge-naive | 同一网格转移一次 SGD 后，表格与网络的预测：$\delta=+.162$，相关预测 $.4162,.4319,.6257$ 与 $-.2058,-.3017$，标签 $.562\to.587$，误差 $.130$ 与 $.155$ | 本课的计算：指定初始权重，网格环境、前向传播与损失梯度沿用本章网格实验 | `demos/dqn_matched_transition.py` | 终端输出 |
| 10.2 节“经验回放” | 八条记录前四条来自区域 A、后四条来自区域 B，批量为 2：按时间连续取两条时同区概率 $6/7$，独立均匀有放回地抽两次时为 $1/2$ | 本课的计算：枚举 7 个相邻对与 64 个有序对 | `demos/dqn_replay_pairs.py` | 终端输出 |
| 课件 deep-v10-dqn-refresh | 目标副本重复复制后权重仍逐轮放大（复制倍数 $1.6435$），副本没有消除第 9 章两状态反例的发散 | 本课的计算：两状态预测例的精确加权回归与重复复制，特征、行为与目标策略同第 9 章，不训练环境；20 步路径用 `--mean-path --p .95 --copy-every 5` | `demos/course24_deep_coupling.py` | `assets/course24-deep/checks.json`；`assets/course24-deep/fixed-target-outer-loop.pdf` |
| 10.2 节“终止、截断与自举目标”；10.5 节“一步与多步离策略控制”；课件 deep-16、core-v8-multistep-dqn | 两步决策树上三种末端处理学得的动作价值与贪心策略：正确目标 $Q(A,\text{继续})=.9\times3=2.7$，把截断写成终止得 $0$；两步回放的均值 $.9+1.8b_{\mathrm h}$ 与停止价值交于 $b_{\mathrm h}=1/18$ | 本课的模拟：A 停止得 $1$，继续得 $0$ 并到 B；B 取 $1$ 或 $3$ 后终止；$\gamma=.9$；三个学习器读同一批单步记录，左图前 100 条，右图用 320 条后学得的策略执行完整任务；回放概率取 $1/20$ 与 $1/18$ | `demos/fragment_control.py` | `assets/fragment-control/learning.csv`；`assets/fragment-control/learning.svg`；课件图 `assets/fragment-control/values-slide.pdf` |
| 10.2 节“DQN 的小批量更新” | 0、1000、10000 次真实交互时的最大 Q、贪心箭头、实际执行路线与起点四项动作价值 | 本课的模拟：网格 DQN，学习率 $.001$，$\varepsilon$ 在 6000 步内从 1 降至 $.1$，每次训练 10000 次交互、9873 次批量更新、98 次目标复制；独立训练 5 次，图取其中种子 0 一次；本程序只读取保存的快照，不重新训练 | `demos/v19_deep_value.py`；训练见 `demos/dqn_model_v11.py` | `assets/dqn-model-v11/grid-q-map.csv`；`assets/v19-deep-value/results.json`（`learned_behavior`，含源文件校验值）；`assets/v19-deep-value/learned-value-policy.png` |
| 10.7 节“长序列探索与Bootstrapped DQN” | 十步任务的成功概率随探索方式变化的曲线 | 本课的计算：枚举有限结果，不训练智能体 | `demos/course_v12_visuals.py` | `assets/course-v12/checks.json`；`assets/course-v12/exploration-probability.png` |
| 10.3 节“奖励缩放、裁剪与数值处理” | 方案 $(5,0)$ 与 $(2,2)$ 的回报 $5$ 与 $3.8$，符号裁剪后为 $1$ 与 $1.9$，偏好反转 | 本课的计算：两个确定性两步方案，折扣 $.9$ | `demos/deep_v13_connections.py` | `assets/deep-v13/checks.json`（`reward_clipping`）；`assets/deep-v13/reward-clipping.png` |
| 10.6 节“观测窗口与序列回放”；课件 ch10-lamp | 只看最近 $k$ 帧时岔口处贪心策略选对的比例：$L<k$ 时为 1，$L\ge k$ 时为 $.5$ | 本课的模拟：T 形走廊，起点灯色红绿各半，$k\in\{1,2,4,8\}$，$L=1,\dots,10$，表格 Q 学习，每格 4000 回合 | `demos/ch10_mechanisms.py` | `demos/ch10-mechanisms-results/results.json`（`frames`） |
| 10.4 节开头；课件 deep-18；“方法对照、主线矛盾与自测” | A–B 任务：左动作真值 $-.1$，DQN 一步标签均值 $+.4$，偏差 $.5$，贪心策略以 $3/4$ 的概率选左；Double DQN 标签均值与选左概率 | 本课的计算：每个动作一次两点噪声观测，$\gamma=1$，按复制概率混合在线与目标估计，用分数精确枚举 | `demos/maximization_control.py`（调用 `demos/dqn_target_check.py` 的目标函数） | 终端输出 |
| 10.4 节“动作越多，偏差越大”；课件 ch10-max-k | $K$ 个无偏估计取最大的偏差（以 $\sigma$ 为单位）$.564,1.029,1.82,2.344$ 与 $\sqrt{2\ln K}$ 对照；真值 $0,-.5,-1,-1.5$ 时单估计标签均值 $+.479$，双估计 $-.367$ | 本课的计算：标准正态误差；双估计各取 $2\times10^5$ 次抽样 | `demos/ch10_mechanisms.py` | `demos/ch10-mechanisms-results/results.json`（`maxbias`） |
| 10.5 节“动作共享、回放分配与多步目标”；课件 deep-15；“阅读与实现” | 五条终止记录的优先回放与重要性校正，校正后恢复 $+.10$；所选输出回归梯度的有限差分检查；最大化偏差、终止与截断、Double DQN 目标的枚举 | 本课的计算：精确的 DQN 机制，仅用 Python 标准库，不训练网络 | `demos/dqn_target_check.py` | 终端输出 |
| 课件 core-v8-per、core-v8-quantile；10.5 节 | 回放修正算例；C51 投影；精确分位数损失；100 组概率质量检查 | 本课的计算：有限算例 | `demos/value_policy_mechanisms.py` | `assets/v8-mechanisms/replay-correction.pdf`；`assets/v8-mechanisms/quantile-loss.pdf`；`assets/v8-mechanisms/categorical-projection.pdf` |
| 10.5 节“C51的交叉熵梯度与动作选择”；课件 deep-v10-c51-action | 三原子 C51 一次更新：目标质量 $(0,.25,.75)$，更新后概率 $(.2272,.2918,.4810)$，均值 $.2538$，对照动作 $.15$ | 本课的计算：有限算例 | `demos/deep_v10_derivations.py` | `assets/deep-v10/c51-update.csv`；`assets/deep-v10/results.json`（`c51`） |
| 10.9 节开头；课件 dqn-v11-learning、dqn-v11-maps | 10000 步时 DQN 与表格 Q-learning 的平均评价回报均为 $.8484$，动作价值平均绝对误差 $.00455$ 与 $.03954$；种子 0 在 750 到 1000 步间误差 $.239\to.083$，选对最优动作的状态 $18/21\to19/21$，到达终点的起点 $19/21\to15/21$，折扣回报 $.709\to.447$；第 1000 步起点最大估值 $.445$、实际回报 $.680$，$(3,3)$ 处向上与向左估值 $.9480,.9888$，64 步回报 $-.572$；$(1,2)$ 处 $2\bar\xi_s$ 在 1000 步与 10000 步为 $.13406,.01064$；三条贪心路线图 | 本课的模拟：22 状态 one-hot 输入，32 个 tanh 隐单元，4 个输出，Adam $.001$，回放池 2000，预热 128，批量 32，每条转移更新一次，每 100 次更新复制目标；表格 Q-learning 每条转移在线更新一次，$\alpha=.2$；$\gamma=.97$，评价窗口 64 步；独立重复 5 次（种子 0–4），每次 10000 步；$2\bar\xi_s$ 由保存的 Q 表与精确 $q_*$ 相减得到 | `demos/dqn_model_v11.py`；路线图 `demos/course32_navigation_figure.py`；策略读出 `demos/grid_policy_readout.py` | `assets/dqn-model-v11/results.json`（`grid`）；`assets/dqn-model-v11/grid-evaluations.csv`；`assets/dqn-model-v11/grid-q-map.csv`；`assets/dqn-model-v11/grid-weights.npz`；`assets/dqn-model-v11/policy-readout.json`（`optimal`、`scores`）；`assets/dqn-model-v11/grid-learning.png`；`assets/course32-methods/greedy-route.pdf` |
| 10.9 节“DeadlineChain实验”；课件 deep-51 | DQN 与 Double DQN 的冻结策略评价曲线，阴影为 5 次训练之间的样本标准差 | 本课的模拟：5 个位置，输入含剩余时限，12 步真实期限，1200 次训练交互；每次 585 次梯度更新、12 次目标同步；独立重复 5 次；每个训练产物另做 12 次冻结策略评价 | 训练程序暂未收入本附录 | `assets/deep/results/provenance.json`；逐次记录 assets/deep/results/deep-dqn-seed-0.csv 至 seed-4，deep-double_dqn-seed-0.csv 至 seed-4；课件曲线读 `assets/deep/results/deep-dqn.dat` 与 `assets/deep/results/deep-double_dqn.dat` |
| 10.8 节“每步更新几次”；课件 ch10-replay-ratio | 回放比 1、2、4、8、16 时 1500 步得分 $.651,.924,.975,.974,.962$，得分到 $.9$ 的步数 $>1500,1300,700,500,400$ | 本课的模拟：十个随机 $7\times7$ 迷宫，各 12 堵墙，最短路 12 步；表格 Q 学习，$\gamma=.97$，步长 $.5$，$\varepsilon=.1$；每步先用当前转移更新一次，再从池中均匀抽其余几条；每个回放比 10 个任务各运行 8 次 | `demos/ch10_mechanisms.py` | `demos/ch10-mechanisms-results/results.json`（`replay_ratio`） |
| 10.9 节“三次运行够不够”；课件 ch10-iqm | 回放比 4 与 8 在 3 次与 20 次运行下的均值、中位数、IQM 及 95% 区间；六组三次运行的均值差 $.286,.298,.415,.236,.342,.195$，20 次合计 $.291$ | 本课的模拟：同一组迷宫，走 400 步后评价，每种回放比独立重复 20 次；分层自助法，任务内重抽运行，2000 次 | `demos/ch10_mechanisms.py` | `demos/ch10-mechanisms-results/results.json`（`aggregates`） |

运行：
```sh
python demos/v18_methods.py
python demos/v19_deep_value.py
python3 demos/deep_v9_checks.py
python3 demos/deep_v10_derivations.py
python3 demos/dqn_matched_transition.py
python3 demos/dqn_replay_pairs.py
python3 demos/course24_deep_coupling.py
python demos/fragment_control.py --replay-probability 1/20
python demos/fragment_control.py --replay-probability 1/18
python3 demos/course_v12_visuals.py
python3 demos/deep_v13_connections.py
python3 demos/ch10_mechanisms.py
python3 demos/maximization_control.py
python3 demos/dqn_target_check.py
python demos/value_policy_mechanisms.py
python3 demos/dqn_model_v11.py
python3 demos/dqn_model_v11.py --test-only
python demos/course32_navigation_figure.py
python demos/grid_policy_readout.py
```

外部代码与公开数据（出处）：DQN 网络结构与 Atari 结果原图（Mnih 等，Nature 2015，图 1，assets/machado/dqn-nature2015-fig1.png）；Rainbow 消融曲线（Hessel 等，2018，assets/course31-deep/rainbow-ablation.png）；Seaquest 价值曲线（assets/course31-deep/seaquest-value.png）；DQN 表示图（assets/v17-background/dqn-representation.pdf）；Atari 100k 上 SPR 重置前后的 IQM $.380\to.478$（Nikishin 等，2022）。

## 参考数据

`assets/`（以及 `demos/NN-results/`）下复制了 60 个数据文件（json、csv 等），即课程目前使用的结果；图片没有复制，运行程序会重新画出。重跑会覆盖这些文件，可以先另存一份再对照。
