# 代表性成果的原图

图用于解释相应论文中的任务、方法或结果。原作者保留图像版权。没有将原论文的曲线作为本课程复现结果。具体裁剪矩形见 `sources.json`。

- `tdgammon-board.png`：Tesauro (1995), *Temporal Difference Learning and TD-Gammon*, Fig. 2。来自作者文章的获准转载页：https://www.bkgm.com/articles/tesauro/tdl.html 。原GIF转为PNG，保留完整图与原图注。
- `dqn-representation.pdf/png`：Mnih et al. (2015), *Human-level control through deep reinforcement learning*, Fig. 4。https://storage.googleapis.com/deepmind-media/dqn/DQNNaturePaper.pdf 。保留表示散点、价值色标及对应游戏画面。
- `alphazero.pdf/png`：Silver et al. (2018), *A general reinforcement learning algorithm that masters chess, shogi, and Go through self-play*, Fig. 1。https://storage.googleapis.com/deepmind-media/DeepMind.com/Blog/alphazero-shedding-new-light-on-chess-shogi-and-go/alphazero_preprint.pdf 。保留三游戏的全部轴、曲线和图例。
- `swift-track.pdf/png` 与 `swift-turn.pdf/png`：Kaufmann et al. (2023), *Champion-level drone racing using deep reinforcement learning*, Figs. 1a, 4c–d。https://rpg.ifi.uzh.ch/docs/Nature23_Kaufmann.pdf 。使用任务与实际轨迹子图。
- `r1-training.pdf/png`：DeepSeek-AI (2025), *DeepSeek-R1*, arXiv v1 Fig. 2。https://arxiv.org/pdf/2501.12948v1 。保留完整曲线、轴和图例；此处明确讨论v1报告。

OpenAI Five课件中的地图为原创结构示意，不表示某一场比赛的实测坐标。其任务条件依据 https://cdn.openai.com/dota-2.pdf 。
