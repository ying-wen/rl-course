# -*- coding: utf-8 -*-
"""第 15 章文献原型：Sutton、Koop 与 Silver (2007) 的 Black and White 世界。

出处：R. S. Sutton, A. Koop, D. Silver. On the Role of Tracking in Stationary
Environments. ICML 2007, pp. 871-878.

环境（原文第 2 节、图 1）：20 个格子首尾相接成环，左 10 格上方为黑、右 10 格为白。
每步动作 look / left / right 的概率为 0.5 / 0.25 / 0.25；只有 look 时看到颜色。
学习者只有一个权重 w：y = sigmoid(w) 预测"看到黑"的概率，损失为交叉熵（自然对数），
看到颜色时 w <- w + alpha * (z - y)。

本程序做四件事：
1. 固定步长扫描（原文图 3、图 9）：每次运行 200,000 步，只统计后 100,000 步中
   look 步的平均损失；另记"后半段任一时刻把权重冻结、拿去长期使用"的损失。
2. IDBD 调步长（原文图 8 与算法 1）：mu = 2^-13，1,000,000 步，几个初始步长，
   记最后 10,000 步的步长范围。
3. 去掉时间相关的反例（原文第 5 节、图 10）：只有一个状态，每步随机黑白各半，
   w0 = -5，1,000 步，固定步长与 IDBD（mu = 2^-10）对比。
4. 一段 60 步的样本轨迹（alpha = 4），供页上作图。

只用 numpy。用法：
    python3 demos/ch15_lit_blackwhite.py [运行次数，默认 30]
输出写 assets/ch15-lit-blackwhite/results.json。
"""
import json, os, sys, time
import numpy as np

N_STATES = 20
BLACK = np.arange(N_STATES) < 10                    # 左 10 格为黑
P_LOOK, P_LEFT = 0.5, 0.25
LN2 = float(np.log(2.0))


def softplus(x):
    return np.logaddexp(0.0, x)


def frozen_loss(w):
    """把权重 w 冻结后长期使用的期望损失：黑白各占一半。"""
    return 0.5 * (softplus(-w) + softplus(w))


def walk(rng, runs, T):
    """各运行独立的随机游走。返回 look 标志与当步颜色 (T, runs)。"""
    u = rng.random((T, runs))
    look = u < P_LOOK
    step = np.where(u < P_LOOK, 0, np.where(u < P_LOOK + P_LEFT, -1, 1))
    pos0 = rng.integers(0, N_STATES, size=runs)
    pos = (pos0[None, :] + np.cumsum(step, axis=0)) % N_STATES
    z = BLACK[pos].astype(float)
    return look, z


def fixed_alpha(alphas, runs, rng, T=200_000, burn=100_000):
    look, z = walk(rng, runs, T)
    A = np.asarray(alphas, float)[:, None]          # (P, 1)
    w = np.zeros((len(alphas), runs))
    loss_sum = np.zeros_like(w)
    n_look = np.zeros(runs)
    froz_sum = np.zeros_like(w)
    for t in range(T):
        m = look[t]
        y = 1.0 / (1.0 + np.exp(-w))
        if t >= burn:
            zz = z[t]
            L = zz * softplus(-w) + (1 - zz) * softplus(w)
            loss_sum += L * m
            n_look += m
            froz_sum += frozen_loss(w)
        w = w + A * (z[t] - y) * m
    online = loss_sum / n_look[None, :]
    froz = froz_sum / (T - burn)
    return online, froz, w


def idbd_black_white(alpha0s, runs, rng, T=1_000_000, mu=2.0 ** -13, tail=10_000):
    look, z = walk(rng, runs, T)
    K = len(alpha0s)
    beta = np.log(np.asarray(alpha0s, float))[:, None] * np.ones((K, runs))
    w = np.zeros((K, runs))
    h = np.zeros((K, runs))
    a_min = np.full((K, runs), np.inf)
    a_max = np.full((K, runs), -np.inf)
    for t in range(T):
        m = look[t]
        y = 1.0 / (1.0 + np.exp(-w))
        d = (z[t] - y) * m
        beta = beta + mu * d * h
        a = np.exp(beta)
        w = w + a * d
        h = np.where(m, h * (1 - a * y * (1 - y)) + a * d, h)
        if t >= T - tail:
            a_min = np.minimum(a_min, a)
            a_max = np.maximum(a_max, a)
    return a_min, a_max


def incoherent(alphas, runs, rng, T=1000, mu=2.0 ** -10, w0=-5.0):
    z = (rng.random((T, runs)) < 0.5).astype(float)
    P = len(alphas)
    res = {}
    for use_idbd in (False, True):
        beta = np.log(np.asarray(alphas, float))[:, None] * np.ones((P, runs))
        w = np.full((P, runs), w0)
        h = np.zeros((P, runs))
        loss_sum = np.zeros((P, runs))
        for t in range(T):
            y = 1.0 / (1.0 + np.exp(-w))
            zz = z[t]
            loss_sum += zz * softplus(-w) + (1 - zz) * softplus(w)
            d = zz - y
            if use_idbd:
                beta = beta + mu * d * h
            a = np.exp(beta)
            w = w + a * d
            if use_idbd:
                h = h * (1 - a * y * (1 - y)) + a * d
        res['idbd' if use_idbd else 'fixed'] = loss_sum / T
    return res


def summarize(x):
    """x: (P, runs) -> 均值与标准误"""
    return x.mean(1).tolist(), (x.std(1, ddof=1) / np.sqrt(x.shape[1])).tolist()


def sample_trace(rng, alpha=4.0, warm=5000, length=60):
    look, z = walk(rng, 1, warm + length)
    w = 0.0
    ys, zs, ls = [], [], []
    for t in range(warm + length):
        y = 1.0 / (1.0 + np.exp(-w))
        if t >= warm:
            ys.append(round(float(y), 4)); zs.append(int(z[t, 0])); ls.append(bool(look[t, 0]))
        if look[t, 0]:
            w += alpha * (z[t, 0] - y)
    return {'alpha': alpha, 'y': ys, 'black_above': zs, 'look': ls}


def main():
    runs = int(sys.argv[1]) if len(sys.argv) > 1 else 30
    t0 = time.time()
    rng = np.random.default_rng(2007)
    out = {'setting': {
        'states': N_STATES, 'black_cells': 'left 10 of 20', 'p_look_left_right': [0.5, 0.25, 0.25],
        'loss': 'cross entropy, natural log, averaged over look steps', 'runs': runs,
        'steps_per_run': 200_000, 'scored_steps': 'last 100,000', 'w0': 0.0}}

    coarse = [2.0 ** k for k in range(-8, 7)]
    fine = [2.0 + 0.5 * i for i in range(13)]           # 2.0 ... 8.0
    alphas = coarse + [a for a in fine if a not in coarse]
    online, froz, w_end = fixed_alpha(alphas, runs, rng)
    on_m, on_se = summarize(online)
    fr_m, fr_se = summarize(froz)
    out['fixed_alpha'] = {'alpha': alphas, 'online_loss_mean': on_m, 'online_loss_se': on_se,
                          'frozen_loss_mean': fr_m, 'frozen_loss_se': fr_se,
                          'converged_loss_ln2': LN2}
    i_best = int(np.argmin(on_m))
    i4 = alphas.index(4.0)
    out['fixed_alpha']['best_alpha'] = alphas[i_best]
    out['fixed_alpha']['best_loss'] = on_m[i_best]
    out['fixed_alpha']['alpha4_loss'] = on_m[i4]
    out['fixed_alpha']['alpha4_frozen'] = fr_m[i4]
    out['fixed_alpha']['ratio_converged_over_alpha4'] = LN2 / on_m[i4]
    t1 = time.time()

    alpha0s = [0.1, 1, 2, 3, 4, 5, 6, 7, 10]
    idbd_runs = 3
    a_min, a_max = idbd_black_white(alpha0s, idbd_runs, rng)
    out['idbd'] = {'mu': 2.0 ** -13, 'steps': 1_000_000, 'alpha0': alpha0s, 'runs_per_alpha0': idbd_runs,
                   'last10k_alpha_min': float(a_min.min()), 'last10k_alpha_max': float(a_max.max()),
                   'per_alpha0_min': a_min.min(1).tolist(), 'per_alpha0_max': a_max.max(1).tolist()}
    t2 = time.time()

    inc = incoherent(coarse, runs, rng)
    f_m, f_se = summarize(inc['fixed']); i_m, i_se = summarize(inc['idbd'])
    out['incoherent'] = {'alpha0': coarse, 'steps': 1000, 'mu': 2.0 ** -10, 'w0': -5.0, 'runs': runs,
                         'fixed_mean': f_m, 'fixed_se': f_se, 'idbd_mean': i_m, 'idbd_se': i_se,
                         'converged_loss_ln2': LN2,
                         'best_fixed': min(f_m), 'best_idbd': min(i_m)}
    out['trace'] = sample_trace(rng)
    out['seconds'] = {'fixed_alpha': round(t1 - t0, 1), 'idbd': round(t2 - t1, 1),
                      'total': round(time.time() - t0, 1)}

    d = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'assets', 'ch15-lit-blackwhite')
    os.makedirs(d, exist_ok=True)
    with open(os.path.join(d, 'results.json'), 'w', encoding='utf-8') as f:
        json.dump(out, f, ensure_ascii=False, indent=1)
    fa = out['fixed_alpha']
    print('alpha=4 online %.4f  frozen %.4f  best alpha %.2f (%.4f)  ln2 %.4f' %
          (fa['alpha4_loss'], fa['alpha4_frozen'], fa['best_alpha'], fa['best_loss'], LN2))
    print('IDBD last-10k alpha range %.3f-%.3f' % (out['idbd']['last10k_alpha_min'], out['idbd']['last10k_alpha_max']))
    print('incoherent best fixed %.4f best idbd %.4f' % (out['incoherent']['best_fixed'], out['incoherent']['best_idbd']))
    print('seconds', out['seconds'])


if __name__ == '__main__':
    main()
