"""11-21 请求 r1121-125631（第 15 章 T1）：复算第 15.1–15.2 节页面上的数。

货运仓库：每趟出发前灯亮左或右，各半；本例灯指向交货点 B（另一世界左右对称）。
走对一趟 3 步（出发 0，到 B 得 4，回仓 0）；走反一趟 5 步（出发 0，进 W 得 0，到 C 得 1，到 B 0，回仓 0）。
询问占一步（得 0），之后知道灯的含义。
甲：第 1 趟在 J 询问；乙：第 3 趟在 J 询问；询问前在 J 总向左，询问后随灯。
另算：两臂老虎机上的样本均值学习器与固定策略（新页 ch15-r21-bandit）。
"""
from fractions import Fraction as F
from functools import lru_cache

def lifetime(ask_trip, T):
    """前向枚举：返回 J_1..J_T（灯指向 B 的世界；指示每趟独立、各半）。"""
    # 状态：(位置, 趟次, 本趟灯, 已知含义, 本趟已问)
    dist = {}
    for light in 'LR':
        dist[('D', 1, light, False, False)] = F(1, 2)
    J, out = F(0), []
    for t in range(T):
        new = {}
        for (pos, trip, light, known, asked), p in dist.items():
            def add(s, r, q=F(1)):
                nonlocal J
                new[s] = new.get(s, 0) + p * q
                J += p * q * r
            if pos == 'D':
                add(('J', trip, light, known, False), 0)
            elif pos == 'J':
                if not known and trip == ask_trip and not asked:
                    add(('J', trip, light, True, True), 0)
                else:
                    go = light if known else 'L'
                    if go == light:
                        add(('B', trip, light, known, asked), 4)
                    else:
                        add(('W', trip, light, known, asked), 0)
            elif pos == 'W':
                add(('C', trip, light, known, asked), 1)
            elif pos == 'C':
                add(('B', trip, light, known, asked), 0)
            elif pos == 'B':
                for nl in 'LR':
                    add(('D', trip + 1, nl, known, False), 0, F(1, 2))
        dist = new
        out.append(J)
    return out

jia, yi = lifetime(1, 16), lifetime(3, 16)
print('T  : ' + ' '.join(f'{t:>5}' for t in range(1, 17)))
print('甲 : ' + ' '.join(f'{str(x):>5}' for x in jia))
print('乙 : ' + ' '.join(f'{str(x):>5}' for x in yi))
print('甲 J8 =', jia[7], ' J16-J8 =', jia[15] - jia[7])

# 转角 J 处的 Bayes 最优值：known=是否已知含义，n=剩余步数
@lru_cache(None)
def V(pos, known, n):
    if n == 0:
        return F(0)
    if pos == 'D':
        return V('J', known, n - 1)
    if pos == 'B':
        return V('D', known, n - 1)
    if pos == 'W':
        return 1 + V('C', known, n - 1)
    if pos == 'C':
        return V('B', known, n - 1)
    return max(Qj(known, n).values())

def Qj(known, n):
    q = {'ask': V('J', True, n - 1)}
    if known:
        q['go'] = 4 + V('B', True, n - 1)
    else:  # 猜一侧：一半走对，一半走反；走过一次也就知道了含义
        q['guess'] = F(1, 2) * (4 + V('B', True, n - 1)) + F(1, 2) * (0 + V('W', True, n - 1))
    return q

for n in range(1, 8):
    print('n =', n, '已问过:', {k: str(v) for k, v in Qj(True, n).items()},
          ' 没问过:', {k: str(v) for k, v in Qj(False, n).items()})

# 两臂老虎机：两个世界各半；E1 左臂付 1、右臂付 0；E2 反之。确定性支付。
def bandit(learner, world, T):
    Q, N, total, rows = [F(1, 2), F(1, 2)], [0, 0], F(0), []
    for t in range(T):
        if learner == 'fixed':
            a = 0
        else:
            a = 0 if Q[0] >= Q[1] else 1
        r = 1 if (a == 0) == (world == 1) else 0
        rows.append((t, tuple(map(str, Q)), tuple(N), 'LR'[a], r))
        if learner != 'fixed':
            N[a] += 1
            Q[a] += (r - Q[a]) / N[a]
        total += r
    return total, rows

T = 10
for L in ('greedy', 'fixed'):
    tot = [bandit(L, w, T)[0] for w in (1, 2)]
    print(L, '各世界', tot, ' J_T =', sum(tot) / 2)
for row in bandit('greedy', 2, 4)[1]:
    print('E2 greedy', row)
