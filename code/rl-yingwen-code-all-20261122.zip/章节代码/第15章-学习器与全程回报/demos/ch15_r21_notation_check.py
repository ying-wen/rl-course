"""11-21 请求 r1121-125631：第 15 章仓库例的精确枚举（记号对照页与小例页用）。

每趟的指示独立、左右各半；顺路一趟 3 步，第 2 步得 4；绕行一趟 5 步，第 3 步得 1；
询问在转角多停一步、奖励 0，此后本趟顺路。甲第 1 趟询问，乙第 3 趟询问，
“总向左”是从不改写规则的固定策略，“随灯”是知道世界时的最优策略，给出台阶 J_T°。
运行：python3 demos/ch15_r21_notation_check.py
"""
from fractions import Fraction as F
from itertools import product

TRIP = {'good': [0, 4, 0], 'bad': [0, 0, 1, 0, 0], 'ask': [0, 0, 4, 0]}


def lifetime_return(rule, T, n_trips=12):
    total = F(0)
    for lights in product([True, False], repeat=n_trips):  # True: 交货点在左
        rewards, k = [], 0
        while len(rewards) < T:
            act = rule(k)
            if act == 'left':
                rewards += TRIP['good' if lights[k] else 'bad']
            else:
                rewards += TRIP[act]
            k += 1
        total += sum(rewards[:T])
    return total / 2 ** n_trips


RULES = {
    '甲': lambda k: 'ask' if k == 0 else 'good',
    '乙': lambda k: 'left' if k < 2 else ('ask' if k == 2 else 'good'),
    '总向左': lambda k: 'left',
    '随灯': lambda k: 'good',
}

if __name__ == '__main__':
    T, r_star = 16, F(4, 3)
    j_opt = lifetime_return(RULES['随灯'], T)
    print(f'T={T}  Tr*={T * r_star}  J_T°={j_opt}  边界项={T * r_star - j_opt}')
    for name in ('甲', '乙', '总向左'):
        j = lifetime_return(RULES[name], T)
        print(f'{name}: J_T={j} ({float(j):.4f})  学习代价={j_opt - j}  遗憾={T * r_star - j}')
