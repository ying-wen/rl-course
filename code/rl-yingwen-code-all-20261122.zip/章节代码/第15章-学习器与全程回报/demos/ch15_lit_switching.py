# -*- coding: utf-8 -*-
"""第 15 章文献原型：仿 Abel 等 (NeurIPS 2023) 第 4.2 节的 switching MDP 实验。

原文设定（已核）：n = 10 个底层 MDP，状态与动作空间相同，转移与奖励不同；每步以 0.001
的概率切换；智能体看不到当前是哪一个；以平均奖励评价；epsilon-greedy Q 学习，
epsilon = 0.15，常数步长 alpha = 0.1 对比"随时间退火到 0"的步长，250 次运行。
原文环境取自 Luketina 等，网格、墙与奖励位置的细节本课没有核到，所以这里是仿作：

本课仿照的世界：5x5 网格，四个动作，撞边不动；10 个底层 MDP 各有一个目标格
（10 个不同的格子，固定），走进目标格得 1，随即被放到一个随机的非目标格，不复位、
不分回合。每步以 0.001 的概率切换到另外 9 个之一。
学习器（都用 gamma = 0.9 的 Q 学习，epsilon = 0.15，Q 初值 0）：
  continual：alpha = 0.1 常数；
  anneal   ：alpha_t = 0.1 / (1 + t / 10^4)（本课取定的退火方式，原文未给公式）；
  oracle   ：看得见当前是哪个 MDP，每个 MDP 一张表，alpha = 0.1（参照，原文没有）。
另算一个精确参照：知道当前 MDP 且不探索的最短路策略的奖励率（10 个 MDP 平均）。

只用 numpy。用法：
    python3 demos/ch15_lit_switching.py [运行次数，默认 100] [步数，默认 200000]
输出写 assets/ch15-lit-switching/results.json。
"""
import json, os, sys, time
import numpy as np

SIZE, N_MDP, P_SWITCH = 5, 10, 0.001
N_S, N_A = SIZE * SIZE, 4
GAMMA, EPS, ALPHA = 0.9, 0.15, 0.1
ANNEAL_TAU = 1e4
MOVES = np.array([(-1, 0), (1, 0), (0, -1), (0, 1)])


def build_next():
    nxt = np.zeros((N_S, N_A), int)
    for s in range(N_S):
        r, c = divmod(s, SIZE)
        for a, (dr, dc) in enumerate(MOVES):
            rr, cc = min(max(r + dr, 0), SIZE - 1), min(max(c + dc, 0), SIZE - 1)
            nxt[s, a] = rr * SIZE + cc
    return nxt


NEXT = build_next()
GOALS = np.random.default_rng(10).choice(N_S, size=N_MDP, replace=False)


def exact_rate(goal):
    """不探索的最短路策略：从均匀的非目标格出发，平均要走曼哈顿距离那么多步得 1。"""
    gr, gc = divmod(int(goal), SIZE)
    d = [abs(r - gr) + abs(c - gc) for r in range(SIZE) for c in range(SIZE) if r * SIZE + c != goal]
    return 1.0 / np.mean(d)


def run(runs, T, rng, window=10_000):
    names = ['continual', 'anneal', 'oracle']
    Q = {'continual': np.zeros((runs, N_S, N_A)), 'anneal': np.zeros((runs, N_S, N_A)),
         'oracle': np.zeros((runs, N_MDP, N_S, N_A))}
    pos = {k: rng.integers(0, N_S, size=runs) for k in names}
    mdp = rng.integers(0, N_MDP, size=runs)               # 三个学习器共用同一串切换
    rew_win = {k: np.zeros((T // window, runs)) for k in names}
    idx = np.arange(runs)
    n_switch = np.zeros(runs)
    for t in range(T):
        sw = rng.random(runs) < P_SWITCH
        if sw.any():
            jump = rng.integers(1, N_MDP, size=runs)
            mdp = np.where(sw, (mdp + jump) % N_MDP, mdp)
            n_switch += sw
        goal = GOALS[mdp]
        u_eps = rng.random(runs) < EPS
        a_rand = rng.integers(0, N_A, size=runs)
        reset_to = rng.integers(0, N_S - 1, size=runs)
        reset_to = np.where(reset_to >= goal, reset_to + 1, reset_to)   # 均匀的非目标格
        tie = rng.random((runs, N_A)) * 1e-9
        for k in names:
            s = pos[k]
            q_s = Q[k][idx, mdp, s] if k == 'oracle' else Q[k][idx, s]
            a = np.where(u_eps, a_rand, np.argmax(q_s + tie, axis=1))
            s2 = NEXT[s, a]
            hit = s2 == goal
            r = hit.astype(float)
            s_next = np.where(hit, reset_to, s2)
            if k == 'oracle':
                target = r + GAMMA * Q[k][idx, mdp, s_next].max(1)
                Q[k][idx, mdp, s, a] += ALPHA * (target - Q[k][idx, mdp, s, a])
            else:
                alpha = ALPHA if k == 'continual' else ALPHA / (1.0 + t / ANNEAL_TAU)
                target = r + GAMMA * Q[k][idx, s_next].max(1)
                Q[k][idx, s, a] += alpha * (target - Q[k][idx, s, a])
            pos[k] = s_next
            rew_win[k][t // window] += r
    return {k: rew_win[k] / window for k in names}, n_switch


def main():
    runs = int(sys.argv[1]) if len(sys.argv) > 1 else 100
    T = int(sys.argv[2]) if len(sys.argv) > 2 else 200_000
    window = 10_000
    t0 = time.time()
    rng = np.random.default_rng(2023)
    rates, n_switch = run(runs, T, rng, window)
    out = {'setting': {'grid': '5x5', 'n_mdp': N_MDP, 'p_switch': P_SWITCH, 'goals': GOALS.tolist(),
                       'gamma': GAMMA, 'epsilon': EPS, 'alpha': ALPHA,
                       'anneal': 'alpha_t = 0.1/(1+t/1e4)', 'runs': runs, 'steps': T, 'window': window},
           'mean_switches_per_run': float(n_switch.mean()),
           'exact_rate_shortest_path_mean': float(np.mean([exact_rate(g) for g in GOALS]))}
    curves = {}
    for k, R in rates.items():
        m = R.mean(1); se = R.std(1, ddof=1) / np.sqrt(runs)
        life = R.mean(0)                                   # 每次运行的 lifetime 平均奖励
        late = R[-(R.shape[0] // 2):].mean(0)              # 后半段
        curves[k] = {'window_mean': m.round(5).tolist(), 'window_se': se.round(5).tolist(),
                     'lifetime_mean': float(life.mean()), 'lifetime_se': float(life.std(ddof=1) / np.sqrt(runs)),
                     'second_half_mean': float(late.mean()),
                     'second_half_se': float(late.std(ddof=1) / np.sqrt(runs))}
    diff = rates['continual'].mean(0) - rates['anneal'].mean(0)
    out['paired_lifetime_diff_continual_minus_anneal'] = {
        'mean': float(diff.mean()), 'sd': float(diff.std(ddof=1)), 'se': float(diff.std(ddof=1) / np.sqrt(runs)),
        'n_positive': int((diff > 0).sum())}
    out['curves'] = curves
    out['seconds'] = round(time.time() - t0, 1)
    d = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'assets', 'ch15-lit-switching')
    os.makedirs(d, exist_ok=True)
    with open(os.path.join(d, 'results.json'), 'w', encoding='utf-8') as f:
        json.dump(out, f, ensure_ascii=False, indent=1)
    for k, c in curves.items():
        print('%-9s lifetime %.4f (se %.4f)  second half %.4f  first window %.4f last window %.4f' %
              (k, c['lifetime_mean'], c['lifetime_se'], c['second_half_mean'], c['window_mean'][0], c['window_mean'][-1]))
    print('paired diff', out['paired_lifetime_diff_continual_minus_anneal'])
    print('exact shortest-path rate', out['exact_rate_shortest_path_mean'], 'switches', out['mean_switches_per_run'])
    print('seconds', out['seconds'])


if __name__ == '__main__':
    main()
