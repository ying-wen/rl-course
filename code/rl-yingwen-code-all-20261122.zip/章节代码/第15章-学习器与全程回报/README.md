# 第 15 章　学习器与全程回报：程序

本目录可以单独运行：在本目录下执行下面的命令即可，结果写回本目录的 `assets/`。目录由 `rl-course/tools/export_chapter_code.py` 从课程目录生成，改程序请改课程目录里的原件，再重新导出。

## 准备

```sh
python3 -m pip install -r requirements.txt
```

需要的第三方包：matplotlib、numpy。复现附录要求 Python 3.10 或更新版本；核验时用的版本见下表。

## 运行（与复现附录相同）

```sh
python3 demos/crl_joint_v12.py         # 重新产生三站实验原始记录；默认写 assets/crl-joint-v12，可用 --output-dir 另写
python3 demos/v19_continual.py         # 读 assets/crl-joint-v12，写 assets/v19-continual
python3 demos/crl_v10_derivations.py   # 写 assets/crl-v10
python3 demos/ch15_lit_blackwhite.py              # 文献原型：黑白世界，写 assets/ch15-lit-blackwhite
python3 demos/ch15_lit_switching.py 250 300000    # 文献原型：切换的 MDP，写 assets/ch15-lit-switching
python3 demos/ch15_r21_check.py                   # 只打印
python3 demos/ch15_r21_notation_check.py          # 只打印
python3 demos/crl_ladder_learners.py --exp ch15 --seeds 60 --seed0 100 --steps 2000000 --tag formal   # 四区仓库阶梯，写 assets/crl-ladder-world/runs/formal-ch15.json
python3 demos/crl_ladder_figures.py ch15           # 写 assets/crl-ladder-world/fig/ladder-ch15.png
```

## 本目录的程序

| 程序 | 说明 | 核验 |
|---|---|---|
| `demos/v19_continual.py` | Bounded calculations for the v19 continual-learning bridge. | 通过（2 秒） |
| `demos/crl_joint_v12.py` | One continuing navigation task, learned skills, GVFs and rate-aware planning. | 通过（92 秒） |
| `demos/crl_v10_derivations.py` | Small exact calculations accompanying chapter 14's v10 derivations. | 通过（4 秒） |
| `demos/ch15_lit_blackwhite.py` | 第 15 章文献原型：Sutton、Koop 与 Silver (2007) 的 Black and White 世界。 | 通过（23 秒） |
| `demos/ch15_lit_switching.py` | 第 15 章文献原型：仿 Abel 等 (NeurIPS 2023) 第 4.2 节的 switching MDP 实验。 | 通过（88 秒） |
| `demos/ch15_r21_check.py` | 11-21 请求 r1121-125631（第 15 章 T1）：复算第 15.1–15.2 节页面上的数。 | 通过（0 秒） |
| `demos/ch15_r21_notation_check.py` | 11-21 请求 r1121-125631：第 15 章仓库例的精确枚举（记号对照页与小例页用）。 | 通过（0 秒） |
| `demos/crl_ladder_learners.py` | 四区仓库的学习器阶梯（例子方案第三步）。 | 超时：300 秒内未跑完（启动正常） |
| `demos/crl_ladder_figures.py` | 阶梯世界（四区仓库）阅读稿用图：地图与各章“占天花板”条形。 | 通过（2 秒） |
| `demos/crl_ladder_world.py` | 四区仓库：第三部分的能力阶梯世界（环境与精确参照）。 | 通过（50 秒） |
| `demos/crl_ladder_world_checks.py` | 四区仓库的独立检查（照 v12 的做法：手算、枚举、独立实现互查）。 | 通过（51 秒） |
| `demos/crl_ladder_power.py` | 四区仓库学习器阶梯：试点估 σ_Δ 定种子数，正式跑后出第 24 章的账本。 | 通过（0 秒） |
| `demos/crl_ladder_ceiling.py` | 四区仓库学习器阶梯：每个试验条件的“天花板”，供账本算“离最优还差多少”。 | 超时：300 秒内未跑完（启动正常） |
| `demos/crl_ladder_diagnostics.py` | 四区仓库阶梯的诊断与改法（11-20）。 | 通过（7 秒） |

表中后 5 个程序复现附录本章一节没有列出，来自课件、阅读稿、CODE-MAP 或文件名前缀（第三部分另含学习器阶梯）。

## 第三部分的学习器阶梯（例子方案第三步）

四区仓库世界与 L0–L10 阶梯学习器。每章一个实验，三档：没有、设计者给定、从经验学到。比较都是配对的：同一种子下两档用同一份世界随机数。

```sh
python3 demos/crl_ladder_world.py --fast                     # 各区参考线，写 reference.json（全量去掉 --fast）
python3 demos/crl_ladder_world_checks.py                     # 世界本身的核对
python3 demos/crl_ladder_ceiling.py                          # 各条件的天花板（ε-软最好率），写 ceiling.json
python3 demos/crl_ladder_learners.py --exp ch15 --seeds 2 --steps 200000 --procs 2 --tag smoke   # 冒烟：写 assets/crl-ladder-world/runs/smoke-ch15.json
python3 demos/crl_ladder_learners.py --exp ch15 --seeds 60 --seed0 100 --steps 2000000 --tag formal   # 正式设置（种子数与 runs/ 里的正式记录相同）
python3 demos/crl_ladder_power.py ledger --runs formal-ch15     # 配对差与 95% 区间，写 ledger-formal-ch15.json
python3 demos/crl_ladder_figures.py ch15                       # 阅读稿用的地图与条形图（读账本）
# 改进与诊断（README 第九节）：同一套世界随机数，跑完用 --compare 出配对差
python3 demos/crl_ladder_diagnostics.py --arms ch15/h0.001-full/learned-win8 --seeds 2 --steps 200000 --procs 2 --tag smoke   # 冒烟：写 runs/diag-smoke-*.json
python3 demos/crl_ladder_diagnostics.py --arms ch15/h0.001-full/learned-win8 ch15/h0.001-coarse/learned-win8 --seeds 20 --procs 3
python3 demos/crl_ladder_diagnostics.py --compare ch15/h0.001-full/learned-win8 ch15/h0.001-full/learned
```

参考记录在 `assets/crl-ladder-world/runs/`（随本目录复制）。正式设置一章要跑数十分钟到数小时；冒烟一行只确认程序能走通。正式结果与读法见 `assets/crl-ladder-world/README.md` 第八节，改进与诊断见第九节。

## 复现附录本章一节

本章来自本课程序的结果有三组。第一组是 15.3 节的两张图：三站实验中持续更新与冻结学习的对照，以及两臂设定下先试探与始终选已知动作的期望累计奖励。第二组是课件中仓库例的逐步核对，包括甲、乙两个学习器的询问时机、全程回报 $J$ 的逐步计算与记号小例，由两个只在终端输出的程序做精确枚举与有限算术。第三组是 15.3 节四区仓库上的阶梯实验，比较识别情境与常数步长两种学习器的 lifetime 奖励率。此外有两个文献原型：15.1 节按 Sutton、Koop 与 Silver（2007）重跑的黑白世界，以及 15.3 节仿照 Abel 等（2023）的切换 MDP。

讲义中 15.1 节仓库例甲、乙 16 步的逐步累计奖励（终值 20 与 13）及冻结测试的得分、配送车算例、15.3 节“两种探测时机的数值计算”中成功率 $.3/.7$ 一例的 $.58$、10 步门槛及信息价值 $.09558$（$h=9$）与 $.11409$（$h=10$），以及全程回报分解中的数，由正文推导直接算出。章内其余图为示意图，或取自 Sutton 与 Barto 等文献。

| 位置 | 结果 | 设置 | 程序 | 数据与输出 |
|---|---|---|---|---|
| 15.3 节“持续学习的一种定义”中的延伸“冻结后的测试起点、三站任务的轨迹与含噪探测”（图 `lifetime-versus-policy.png`） | 持续更新组全程平均率 $.208758$、末次策略率 $.149052$；第 60,000 步后冻结组分别为 $.167127$ 与 $.065767$；从初始化起的累计收益曲线 | 本课的模拟：第 24 章三站持续导航任务（八格 Y 形网格，三站奖励 $1$、$.2$、$3$，第 60,000 步起 C 站降为 $.1$，滑移概率 $.1$），每次运行 120,000 个原始步，不重置；继续更新与冻结学习两组，各独立重复 8 次（种子 0–7）；末次策略率由已知环境对含探索的冻结策略求稳态率，只用于评价；阴影为 8 次均值的标准误。本章的程序只重新分析保存的原始转移，不重新训练 | `demos/v19_continual.py`；原始记录由 `demos/crl_joint_v12.py` 产生 | 输入 `assets/crl-joint-v12/learning-curves.csv` 与同目录 `raw-no_planning-seed0.npz` 至 `raw-frozen-seed7.npz`；输出 `assets/v19-continual/lifetime-evaluation.csv`（`t=120000` 两行）、`assets/v19-continual/lifetime-versus-policy.png`、`assets/v19-continual/checks.json` |
| 15.3 节“两种探测时机的数值计算”（图 15.1 `lifetime-information.png`） | 总预算 $T=1$ 时始终选 $a$ 较高（$.6$ 对 $.5$），$T\ge2$ 起先试 $b$ 反超（$T=2$ 时 $1.3$ 对 $1.2$） | 本课的计算：已知动作 $a$ 每步得 $.6$；$b$ 的奖励 $\Theta\in\{0,1\}$ 固定、先验各半，试一次即知；$T=1$ 到 $20$，闭式 $.6T$ 与 $.5+.8(T-1)$ 与信念动态规划对照；确定性计算，无随机重复 | `demos/crl_v10_derivations.py` | `assets/crl-v10/results.json`（`lifetime` 一项）；`assets/crl-v10/lifetime-information.png` |
| 15.1 节“实验：黑白世界中的跟踪与冻结”（页 `ch15-lit-blackwhite`、`ch15-lit-blackwhite-frozen`） | 固定 $\alpha=4$ 时 look 步平均交叉熵 $.2477$，收敛解 $\ln 2=.6931$；最优固定步长 $4.5$（$.2469$）；IDBD 最后 1 万步的步长 $4.47$–$4.60$（初始步长 $.1$ 一组为 $4.24$ 且仍在上升）；后半段任取一刻冻结 $\alpha=4$ 的权重，长期损失 $2.08$；单状态反例中最优固定 $.7428$、最优 IDBD $.7430$；60 步样本轨迹 | 本课重跑 Sutton、Koop 与 Silver（ICML 2007）的 Black and White 世界：20 格成环，左 10 格为黑，look/left/right 概率 $.5/.25/.25$，单权重 logistic 预测、交叉熵，$w_0=0$；固定步长 25 个取值，各 30 次独立运行 × 200,000 步，统计后 100,000 步的 look 步；IDBD $\mu=2^{-13}$，9 个初始步长各 3 次 × 1,000,000 步；单状态反例 $w_0=-5$、$\mu=2^{-10}$、30 次 × 1000 步；随机种子 2007 | `demos/ch15_lit_blackwhite.py` | `assets/ch15-lit-blackwhite/results.json` |
| 15.3 节“实验：切换的 MDP”（页 `ch15-lit-switching`） | 全程平均奖励：常数步长 $.1574$，退火 $.0996$，配对差 $.0578$（250 次全部为正）；看得到下标的参照 $.2339$；知道下标且不探索的最短路奖励率 $.311$；每 1 万步窗口平均曲线 | 本课仿照 Abel 等（NeurIPS 2023）Fig. 2(b) 的 switching MDP（原环境取自 Luketina 等，细节未核）：5×5 网格，10 个 MDP 各一个目标格，走进得 1 后落到随机非目标格，不复位；每步以 $.001$ 的概率切换，智能体看不到下标；$\gamma=.9$、$\varepsilon=.15$ 的 Q 学习，常数 $\alpha=.1$ 对 $\alpha_t=.1/(1+t/10^4)$；250 次独立运行 × 300,000 步；随机种子 2023 | `demos/ch15_lit_switching.py` | `assets/ch15-lit-switching/results.json` |
| 15.1 节（课件 `ch15-r21-bandit`）；15.2 节（课件 `ch15-forward-numeric`）；课件 `ch15-old-results` | 仓库例：甲第 1 趟在转角询问、乙第 3 趟询问，两者的逐趟累计奖励；全程回报 $J$ 由 0 到 2 再到 $5/2$ 的逐步计算；两臂赌博机上样本均值学习器与固定策略的对照 | 本课的计算：精确枚举与有限算术，无训练 | `demos/ch15_r21_check.py` | 只在终端输出，不写文件 |
| 15.3 节（课件 `ch15-r21-notation-map`、`ch15-r21-notation-example`） | 记号对照页与小例页的数：$T=16$，$r^*=4/3$，固定策略“总向左”、知道世界时的最优策略“随灯”与甲、乙的台阶 | 本课的计算：每趟指示独立、左右各半，精确枚举 | `demos/ch15_r21_notation_check.py` | 只在终端输出，不写文件 |
| 15.3 节（课件 `ch15-ladder`） | 识别情境（RL-CD 的简化）学成后达到天花板的 86%，常数步长 71%；两者 lifetime 率差 $+.0013\pm.0015$，不显著 | 本课的模拟：四区仓库（demos/crl_ladder_world.py），200 万步，60 个种子，各档同种子配对 | `demos/crl_ladder_learners.py` 实验 `ch15` | `assets/crl-ladder-world/runs/formal-ch15.json`、`assets/crl-ladder-world/fig/ladder-ch15.png` |

运行：
```sh
python3 demos/crl_joint_v12.py         # 重新产生三站实验原始记录；默认写 assets/crl-joint-v12，可用 --output-dir 另写
python3 demos/v19_continual.py         # 读 assets/crl-joint-v12，写 assets/v19-continual
python3 demos/crl_v10_derivations.py   # 写 assets/crl-v10
python3 demos/ch15_lit_blackwhite.py              # 文献原型：黑白世界，写 assets/ch15-lit-blackwhite
python3 demos/ch15_lit_switching.py 250 300000    # 文献原型：切换的 MDP，写 assets/ch15-lit-switching
python3 demos/ch15_r21_check.py                   # 只打印
python3 demos/ch15_r21_notation_check.py          # 只打印
python3 demos/crl_ladder_learners.py --exp ch15 --seeds 60 --seed0 100 --steps 2000000 --tag formal   # 四区仓库阶梯，写 assets/crl-ladder-world/runs/formal-ch15.json
python3 demos/crl_ladder_figures.py ch15           # 写 assets/crl-ladder-world/fig/ladder-ch15.png
```

## 参考数据

`assets/`（以及 `demos/NN-results/`）下复制了 158 个数据文件（json、csv 等），即课程目前使用的结果；图片没有复制，运行程序会重新画出。重跑会覆盖这些文件，可以先另存一份再对照。
