"""On-policy GVF prediction along two consecutive deliveries (ordinary tabular TD(lambda)).

Run python3 demos/delivery_trace.py --help for the two independent choices.
The environment keeps running after an arrival, including when continuation is zero.
"""
import argparse
import json
from fractions import Fraction as F
from pathlib import Path


# The policy always takes the same route. Each trip goes J -> D -> J.
# The observed signal on arrival is 1 for a late delivery and 0 for an on-time delivery.
OBSERVED_TRIPS = (1, 0)
LATE_PROBABILITY = F(1, 4)
ALPHA = F(4, 5)
ARRIVAL_CONTINUATIONS = (F(0), F(1, 2))
TRACE_PARAMETERS = (F(0), F(1, 2), F(1))


def evaluate(arrival, lam):
    """Run an online learner; the analytical value is shown only for comparison."""
    value = dict(J=F(0), D=F(0))
    trace = dict(J=F(0), D=F(0))
    previous_continuation = F(0)  # No visits precede the first observed transition.
    rows = []
    for late in OBSERVED_TRIPS:
        for state, next_state, signal, continuation in (
            ('J', 'D', 0, F(1)), ('D', 'J', late, arrival)
        ):
            old = value.copy()
            target = signal + continuation * old[next_state]
            error = target - old[state]
            for s in value:
                trace[s] = previous_continuation * lam * trace[s] + int(s == state)
                value[s] += ALPHA * error * trace[s]
            rows.append(dict(state=state, next_state=next_state, signal=signal,
                             incoming=previous_continuation, outgoing=continuation,
                             before=old, target=target, delta=error,
                             trace=trace.copy(), after=value.copy()))
            previous_continuation = continuation
    # From either state, the next arrival has expected signal p. Each arrival
    # multiplies future trips by arrival, and the blanks within a trip have weight 1.
    return dict(truth=LATE_PROBABILITY / (1 - arrival), steps=rows)


def all_settings():
    return {str(k): {str(lam): evaluate(k, lam) for lam in TRACE_PARAMETERS}
            for k in ARRIVAL_CONTINUATIONS}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--arrival', type=F, choices=ARRIVAL_CONTINUATIONS, default=F(0),
                        help='Continuation when arriving, 0 or 1/2; en route it is always 1.')
    parser.add_argument('--lam', type=F, choices=TRACE_PARAMETERS, default=F(1, 2),
                        help='Trace parameter, 0, 1/2, or 1.')
    parser.add_argument('--export', type=Path, help='Write all six combinations for the offline reader.')
    args = parser.parse_args()
    if args.export:
        args.export.parent.mkdir(parents=True, exist_ok=True)
        args.export.write_text(json.dumps(all_settings(), default=str, indent=2) + '\n',
                               encoding='utf-8')
    else:
        result = evaluate(args.arrival, args.lam)
        print(f'Known expected return at J and D: {result["truth"]}; alpha={ALPHA}.')
        print('step transition  C  k_in k_out  target  delta   e(J,D)    V_after(J,D)')
        for step, r in enumerate(result['steps'], 1):
            print(f'{step:>4} {r["state"]}->{r["next_state"]}       {r["signal"]}   '
                  f'{str(r["incoming"]):>3} {str(r["outgoing"]):>4}   {str(r["target"]):>5} '
                  f'{str(r["delta"]):>6}   ({r["trace"]["J"]},{r["trace"]["D"]})  '
                  f'({r["after"]["J"]},{r["after"]["D"]})')


if __name__ == '__main__':
    main()
