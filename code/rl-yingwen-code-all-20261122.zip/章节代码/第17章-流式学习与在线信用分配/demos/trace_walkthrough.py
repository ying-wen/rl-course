"""Read one mud-path transition at a time. Uses the chapter's TD implementations.

python demos/trace_walkthrough.py --stalls 2 --lam .8 --mix
python demos/trace_walkthrough.py --out assets/course15-traces/prefixes.json
"""
import argparse
import json
from pathlib import Path
import numpy as np
from course15_traces import FEATURES, accumulating, online_forward, true_online


def return_components(states, rewards, values, start, gamma, lam):
    """Yield (horizon, weight, n-step return) for one visit and its visible suffix."""
    last = len(rewards) - start
    reward_sum = 0.0
    for n in range(1, last + 1):
        reward_sum += gamma ** (n - 1) * rewards[start + n - 1]
        # At a true terminal the endpoint value is zero. A cut within S4 retains its tail value.
        target = reward_sum + gamma ** n * values[states[start + n]]
        weight = lam ** (n - 1) * (1 - lam if n < last else 1)
        yield n, weight, target


def frozen_prefix(states, rewards, initial, gamma, lam, alpha):
    """Two independent totals on the observed prefix. A live endpoint bootstraps."""
    length = len(rewards)
    baseline = FEATURES @ initial
    errors = [r + gamma * baseline[y] - baseline[x]
              for x, r, y in zip(states, rewards, states[1:])]
    by_visit = np.zeros(2)
    by_error = np.zeros(2)
    trace = np.zeros(2)
    targets = []
    for k in range(length):
        target = sum(weight * value for _, weight, value in
                     return_components(states, rewards, baseline, k, gamma, lam))
        targets.append(target)
        by_visit += alpha * (target - baseline[states[k]]) * FEATURES[states[k]]
        trace = gamma * lam * trace + FEATURES[states[k]]
        by_error += alpha * errors[k] * trace
    np.testing.assert_allclose(by_visit, by_error, atol=1e-13)
    return (initial + by_visit).tolist(), targets


def unseen_predictions(weights, initial, parameter_trace):
    """Keep the entire S7/S4 trajectory fixed. Read S6 with three fixed linear maps."""
    probes = {'table': (0, 0, 1), 'tied': (0, 1, 0), 'signed': (1, -1, 1)}
    result = {}
    # Neither visited state uses a third feature. Its weight and trace never change.
    for name, coordinates in probes.items():
        x6 = np.asarray(coordinates, dtype=float)
        # Match the initial S6 prediction to the S4 prediction for every encoder.
        offset = initial[1] - x6[:2] @ initial if x6[2] else 0.
        extended_weights = np.append(weights, offset)
        direction = np.append(parameter_trace, 0.)
        result[name] = {'prediction': float(x6 @ extended_weights),
                        'trace_projection': float(x6 @ direction)}
    return result


def walk(stalls, lam, initial):
    """The sampled policy enters the mud, stays 'stalls' times, then reaches G."""
    states = [0] + [1] * (stalls + 1) + [2]
    rewards = [0] * (stalls + 1) + [1]
    alpha, gamma = .2, .9
    features = FEATURES[states]
    initial = np.asarray(initial, dtype=float)
    ordinary, steps = accumulating(features, rewards, initial, alpha, gamma, lam)
    true = true_online(features, rewards, initial, alpha, gamma, lam)
    forward = online_forward(features, rewards, initial, alpha, gamma, lam)
    np.testing.assert_allclose(true, forward, rtol=1e-12, atol=1e-13)
    rows = []
    for h in range(len(rewards) + 1):
        frozen, targets = frozen_prefix(states[:h + 1], rewards[:h], initial,
                                        gamma, lam, alpha)
        row = dict(h=h, frozen=frozen, ordinary=ordinary[h].tolist(),
                   true_online=true[h].tolist(), online_forward=forward[h].tolist(),
                   frozen_target_first=targets[0] if h else None)
        parameter_trace = steps[h-1]['trace'] if h else [0., 0.]
        row['unvisited'] = unseen_predictions(ordinary[h], initial, parameter_trace)
        if h:
            row['step'] = steps[h - 1]
            for name, probe in row['unvisited'].items():
                before = rows[-1]['unvisited'][name]['prediction']
                predicted_change = alpha * steps[h-1]['delta'] * probe['trace_projection']
                np.testing.assert_allclose(probe['prediction'] - before, predicted_change, atol=1e-13)
        rows.append(row)
    return dict(states=states, rewards=rewards, gamma=gamma, alpha=alpha,
                lam=lam, rows=rows)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--stalls', type=int, default=2)
    parser.add_argument('--lam', type=float, default=.8)
    parser.add_argument('--zero', action='store_true', help='Start both predictions at zero.')
    parser.add_argument('--mix', action='store_true', help='Show the full frozen forward mixture and error allocation for S7.')
    parser.add_argument('--out', type=Path, help='Export all classroom settings for the reader.')
    args = parser.parse_args()
    if args.stalls < 0 or args.stalls > 20 or not 0 <= args.lam <= 1:
        parser.error('Use 0–20 stalls and lambda in [0, 1].')
    if args.out:
        cases = {}
        for stalls in (0, 2):
            for lam in (0, .8, 1):
                for name, initial in [('warm', [.4, .5]), ('zero', [0, 0])]:
                    cases[f'{stalls}/{lam}/{name}'] = walk(stalls, lam, initial)
        args.out.parent.mkdir(parents=True, exist_ok=True)
        args.out.write_text(json.dumps(cases, allow_nan=False, separators=(',', ':'))+'\n')
        return
    data = walk(args.stalls, args.lam, [0, 0] if args.zero else [.4, .5])
    if args.mix:
        states, rewards = data['states'], data['rewards']
        values = FEATURES @ np.asarray(data['rows'][0]['frozen'])
        gamma, lam = data['gamma'], data['lam']
        print('S7 frozen forward view: all n-step targets start at the same visit.')
        print('n    weight     n-step target     contribution')
        for n, weight, target in return_components(states, rewards, values, 0, gamma, lam):
            print(f'{n:<3}  {weight:8.6f}   {target:11.6f}     {weight * target:11.6f}')
        print(f"frozen lambda-return = {data['rows'][-1]['frozen_target_first']:.6f}")
        print('Frozen error at each transition and its contribution to the S7 target error:')
        print('t    TD error     trace at S7     contribution')
        for t, reward in enumerate(rewards):
            delta = reward + gamma * values[states[t + 1]] - values[states[t]]
            trace = (gamma * lam) ** t  # S7 occurs once, at t=0.
            print(f'{t:<3}  {delta:8.6f}     {trace:8.6f}     {delta * trace:11.6f}')
        print()
    print('S7: start, S4: mud, G: terminal. Each pair is V(S7), V(S4).')
    print('h   observed   reward       frozen sum         accumulating       online forward = true online')
    for row in data['rows']:
        h = row['h']
        label = ('S7', 'S4', 'G')[data['states'][h]]
        reward = '-' if not h else str(data['rewards'][h-1])
        values = ['(' + ', '.join(f'{x:.6f}' for x in row[m]) + ')'
                  for m in ('frozen','ordinary','true_online')]
        print(f'{h}   {label:8}   {reward:>4}   '+ '   '.join(values))
    print('S6 is never visited. Readouts of the same ordinary TD parameter updates:')
    print('h   independent    tied to S4    signed overlap')
    for row in data['rows']:
        values = [row['unvisited'][key]['prediction'] for key in ('table','tied','signed')]
        print(f"{row['h']:<3} " + "    ".join(f"{v: .6f}" for v in values))


if __name__ == '__main__':
    main()
