# -*- coding: utf-8 -*-
"""第 17 章文献原型的本课重跑：随机游走上的 n 步 TD、λ 回报与三种 TD(λ)。

两组实验，只用 numpy：

1. 19 状态随机游走（Sutton 与 Barto 第 2 版例 7.1；图 7.2、12.3、12.6、12.8 的设定）。
   19 个非终止状态，从中间出发，左右各 0.5；左端结局 -1，右端 +1，其余奖励 0；
   γ = 1，初值 0。度量：每回合结束时 19 个状态的 RMS 误差，取前 10 个回合平均，
   再对 100 次独立运行平均；所有参数用同一组游走。
   方法：n 步 TD、离线 λ 回报、累积迹 TD(λ)、替换迹 TD(λ)、真在线 TD(λ)。
   另用直接按定义计算的在线 λ 回报，在少量回合上核对它与真在线 TD(λ) 逐步相等。

2. van Seijen 等（JMLR 2016）图 1 的设定：10 个状态排成一行，左侧一个终止状态；
   每步 0.7 向左、0.3 向右（最右状态向右即原地）；每步奖励 1，γ = 1，λ = 1，α = 0.2；
   从最右状态出发。初值取 0（本课假设，原文未写）。度量：全部状态的 RMS 误差除以初始 RMS 误差。

输出写到 assets/ch17-lit-rw19/：rw19.json（实验 1）、vs-fig1.json（实验 2）。
用法：python3 demos/ch17_lit_rw19.py [--runs 100] [--out assets/ch17-lit-rw19]
"""
import argparse
import json
import time
from pathlib import Path

import numpy as np

N_STATES = 19
EPISODES = 10
ALPHAS = np.round(np.arange(0.05, 1.0001, 0.05), 2)
LAMBDAS = [0.0, 0.4, 0.8, 0.9, 0.95, 0.975, 0.99, 1.0]
NSTEPS = [1, 2, 4, 8, 16, 32, 64, 128, 256, 512]
BLOW_UP = 1e6


# ---------------------------------------------------------------- 19 状态随机游走
def true_values_rw19():
    # 状态 1..19，终止 0 与 20；v(i) = (i - 10) / 10
    v = np.zeros(N_STATES + 2)
    v[1:N_STATES + 1] = (np.arange(1, N_STATES + 1) - 10) / 10.0
    return v


def make_walks(runs, rng):
    """每次运行 10 个回合；每个回合是 (状态序列, 奖励序列)。状态含终止 0 或 20。"""
    walks = []
    for _ in range(runs):
        eps = []
        for _ in range(EPISODES):
            s = 10
            states = [s]
            rewards = []
            while True:
                s = s + (1 if rng.random() < 0.5 else -1)
                states.append(s)
                if s == 0:
                    rewards.append(-1.0)
                    break
                if s == N_STATES + 1:
                    rewards.append(1.0)
                    break
                rewards.append(0.0)
            eps.append((np.array(states), np.array(rewards)))
        walks.append(eps)
    return walks


def rms(W, vtrue):
    # W: (n_alpha, 21)；只算 19 个非终止状态
    d = W[:, 1:N_STATES + 1] - vtrue[1:N_STATES + 1]
    return np.sqrt(np.mean(d * d, axis=1))


def finish(err_sum, count, diverged):
    out = err_sum / count
    out[diverged] = np.nan
    return out


def run_nstep(walks, n, vtrue):
    na = len(ALPHAS)
    a = ALPHAS[:, None]
    err = np.zeros(na)
    div = np.zeros(na, bool)
    cnt = 0
    for eps in walks:
        W = np.zeros((na, N_STATES + 2))
        for states, rewards in eps:
            T = len(rewards)
            for tau in range(T):
                # 更新时刻 tau 的状态，目标 G_{tau:tau+n}
                h = min(tau + n, T)
                G = np.sum(rewards[tau:h])  # γ = 1
                if h < T:
                    G = G + W[:, states[h]]
                s = states[tau]
                W[:, s] += ALPHAS * (G - W[:, s])
            # 注：上面按回合末一次性做完；n 步 TD 的在线更新时刻是 tau+n，
            # 目标只读到 tau+n 为止的权重，这里在回合内按 tau 顺序更新，
            # 读到的 W[:, states[h]] 恰是第 h 步之前已写入的值，与在线版本一致。
            W[~np.isfinite(W)] = BLOW_UP
            div |= np.abs(W).max(axis=1) >= BLOW_UP
            err += rms(W, vtrue)
            cnt += 1
    return finish(err, cnt, div)


def run_offline_lambda(walks, lam, vtrue):
    na = len(ALPHAS)
    err = np.zeros(na)
    div = np.zeros(na, bool)
    cnt = 0
    for eps in walks:
        W = np.zeros((na, N_STATES + 2))
        for states, rewards in eps:
            T = len(rewards)
            V0 = W.copy()  # 回合内不改权重：自举读回合开始时的值
            G = np.zeros((T, na))
            g = np.zeros(na)
            for t in range(T - 1, -1, -1):
                if t == T - 1:
                    g = np.full(na, rewards[t])
                else:
                    g = rewards[t] + (1 - lam) * V0[:, states[t + 1]] + lam * g
                G[t] = g
            for t in range(T):
                s = states[t]
                W[:, s] += ALPHAS * (G[t] - W[:, s])
            W[~np.isfinite(W)] = BLOW_UP
            div |= np.abs(W).max(axis=1) >= BLOW_UP
            err += rms(W, vtrue)
            cnt += 1
    return finish(err, cnt, div)


def run_td_lambda(walks, lam, vtrue, kind):
    """kind: 'acc' 累积迹，'rep' 替换迹，'tot' 真在线 TD(λ)。表格特征，γ = 1。"""
    na = len(ALPHAS)
    err = np.zeros(na)
    div = np.zeros(na, bool)
    cnt = 0
    with np.errstate(all="ignore"):
        for eps in walks:
            W = np.zeros((na, N_STATES + 2))
            for states, rewards in eps:
                T = len(rewards)
                E = np.zeros((na, N_STATES + 2))
                v_old = np.zeros(na)
                for t in range(T):
                    s, s2 = states[t], states[t + 1]
                    v = W[:, s].copy()
                    v2 = W[:, s2].copy() if t < T - 1 else np.zeros(na)
                    delta = rewards[t] + v2 - v
                    if kind == "acc":
                        E *= lam
                        E[:, s] += 1.0
                        W += ALPHAS[:, None] * delta[:, None] * E
                    elif kind == "rep":
                        E *= lam
                        E[:, s] = 1.0
                        W += ALPHAS[:, None] * delta[:, None] * E
                    else:  # 真在线：Dutch 迹 + (v - v_old) 修正
                        es = E[:, s].copy()
                        E *= lam
                        E[:, s] += 1.0 - ALPHAS * lam * es
                        W += ALPHAS[:, None] * (delta + v - v_old)[:, None] * E
                        W[:, s] -= ALPHAS * (v - v_old)
                        v_old = v2.copy()
                W[~np.isfinite(W)] = BLOW_UP
                div |= np.abs(W).max(axis=1) >= BLOW_UP
                np.clip(W, -BLOW_UP, BLOW_UP, out=W)
                err += rms(W, vtrue)
                cnt += 1
    return finish(err, cnt, div)


def online_lambda_return_episode(w0, states, rewards, lam, alpha):
    """按定义计算在线 λ 回报（S&B §12.4），返回每一步结束时的权重（表格，γ = 1）。"""
    T = len(rewards)
    finals = [w0.copy()]  # finals[h] = w_h（视界 h 的最终权重）
    for h in range(1, T + 1):
        w = w0.copy()
        for t in range(h):
            # G^λ_{t:h} = (1-λ) Σ_{n=1}^{h-t-1} λ^{n-1} G_{t:t+n} + λ^{h-t-1} G_{t:h}
            G = 0.0
            for n in range(1, h - t):
                Gn = np.sum(rewards[t:t + n]) + finals[t + n - 1][states[t + n]]
                G += (1 - lam) * lam ** (n - 1) * Gn
            Gh = np.sum(rewards[t:h]) + (finals[h - 1][states[h]] if h < T else 0.0)
            G += lam ** (h - t - 1) * Gh
            w[states[t]] += alpha * (G - w[states[t]])
        finals.append(w)
    return finals[1:]


def check_true_online(walks, lam=0.9, alpha=0.4, n_check=5):
    """在前 n_check 个回合上核对：真在线 TD(λ) 每步写完后与在线 λ 回报相等。"""
    maxdiff = 0.0
    w_on = np.zeros(N_STATES + 2)
    w_to = np.zeros(N_STATES + 2)
    for states, rewards in walks[0][:n_check]:
        finals = online_lambda_return_episode(w_on, states, rewards, lam, alpha)
        T = len(rewards)
        e = np.zeros(N_STATES + 2)
        v_old = 0.0
        for t in range(T):
            s, s2 = states[t], states[t + 1]
            v = w_to[s]
            v2 = w_to[s2] if t < T - 1 else 0.0
            delta = rewards[t] + v2 - v
            es = e[s]
            e *= lam
            e[s] += 1.0 - alpha * lam * es
            w_to += alpha * (delta + v - v_old) * e
            w_to[s] -= alpha * (v - v_old)
            v_old = v2
            maxdiff = max(maxdiff, float(np.abs(w_to - finals[t]).max()))
        w_on = finals[-1].copy()
    return maxdiff


# ---------------------------------------------------------------- van Seijen 图 1 设定
VS_N = 10


def vs_true_values():
    # 状态 1..10，终止 0；v(i) = 1 + 0.7 v(i-1) + 0.3 v(i+1)，v(11) := v(10)
    A = np.zeros((VS_N, VS_N))
    b = np.ones(VS_N)
    for i in range(1, VS_N + 1):
        A[i - 1, i - 1] += 1.0
        if i - 1 >= 1:
            A[i - 1, i - 2] -= 0.7
        j = min(i + 1, VS_N)
        A[i - 1, j - 1] -= 0.3
    v = np.zeros(VS_N + 1)
    v[1:] = np.linalg.solve(A, b)
    return v


def vs_episode(rng):
    s = VS_N
    states = [s]
    while s != 0:
        s = s - 1 if rng.random() < 0.7 else min(s + 1, VS_N)
        states.append(s)
    return np.array(states)


def vs_run(episodes, vtrue, alpha=0.2, lam=1.0):
    """返回三种方法在每个时间步结束时的归一化 RMS 误差序列（跨回合连续计时）。"""
    init = np.sqrt(np.mean(vtrue[1:] ** 2))

    def nrms(w):
        return float(np.sqrt(np.mean((w[1:] - vtrue[1:]) ** 2)) / init)

    out = {"offline": [], "accumulate": [], "true_online": []}
    w_off = np.zeros(VS_N + 1)
    w_acc = np.zeros(VS_N + 1)
    w_to = np.zeros(VS_N + 1)
    for states in episodes:
        T = len(states) - 1
        e_acc = np.zeros(VS_N + 1)
        e_to = np.zeros(VS_N + 1)
        v_old = 0.0
        for t in range(T):
            s, s2 = states[t], states[t + 1]
            r = 1.0
            # 累积迹
            v2 = w_acc[s2] if s2 != 0 else 0.0
            d = r + v2 - w_acc[s]
            e_acc *= lam
            e_acc[s] += 1.0
            w_acc += alpha * d * e_acc
            # 真在线
            v = w_to[s]
            v2 = w_to[s2] if s2 != 0 else 0.0
            d = r + v2 - v
            es = e_to[s]
            e_to *= lam
            e_to[s] += 1.0 - alpha * lam * es
            w_to += alpha * (d + v - v_old) * e_to
            w_to[s] -= alpha * (v - v_old)
            v_old = v2
            # 离线：回合内不改
            if t == T - 1:
                V0 = w_off.copy()
                G = 0.0
                Gs = np.zeros(T)
                for k in range(T - 1, -1, -1):
                    if k == T - 1:
                        G = 1.0
                    else:
                        G = 1.0 + (1 - lam) * V0[states[k + 1]] + lam * G
                    Gs[k] = G
                for k in range(T):
                    w_off[states[k]] += alpha * (Gs[k] - w_off[states[k]])
            out["offline"].append(nrms(w_off))
            out["accumulate"].append(nrms(w_acc))
            out["true_online"].append(nrms(w_to))
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--runs", type=int, default=100)
    ap.add_argument("--vs-runs", type=int, default=1000)
    ap.add_argument("--out", default="assets/ch17-lit-rw19")
    args = ap.parse_args()
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    t0 = time.time()

    # 实验 1
    rng = np.random.default_rng(17)
    walks = make_walks(args.runs, rng)
    vtrue = true_values_rw19()
    lens = [len(r) for eps in walks for (_, r) in eps]
    res = {"alphas": ALPHAS.tolist(), "lambdas": LAMBDAS, "nsteps": NSTEPS,
           "runs": args.runs, "episodes": EPISODES,
           "mean_episode_length": float(np.mean(lens)),
           "nstep": {}, "offline_lambda": {}, "td_acc": {}, "td_rep": {}, "true_online": {}}
    for n in NSTEPS:
        res["nstep"][str(n)] = run_nstep(walks, n, vtrue)
    for lam in LAMBDAS:
        res["offline_lambda"][str(lam)] = run_offline_lambda(walks, lam, vtrue)
        res["td_acc"][str(lam)] = run_td_lambda(walks, lam, vtrue, "acc")
        res["td_rep"][str(lam)] = run_td_lambda(walks, lam, vtrue, "rep")
        res["true_online"][str(lam)] = run_td_lambda(walks, lam, vtrue, "tot")

    def best(arr):
        arr = np.asarray(arr, float)
        if np.all(np.isnan(arr)):
            return None
        i = int(np.nanargmin(arr))
        return {"alpha": float(ALPHAS[i]), "rms": float(arr[i])}

    summary = {}
    for key in ["nstep", "offline_lambda", "td_acc", "td_rep", "true_online"]:
        summary[key] = {k: best(v) for k, v in res[key].items()}
    for key in ["nstep", "offline_lambda", "td_acc", "td_rep", "true_online"]:
        res[key] = {k: [None if np.isnan(x) else round(float(x), 4) for x in v]
                    for k, v in res[key].items()}
    res["best"] = summary
    res["true_online_vs_online_lambda_return_maxdiff"] = check_true_online(walks)

    # 配对比较：各方法取 λ = 0.8 下各自最好的 α，逐次运行求差，给出差的均值与标准误
    def per_run(fn, lam, kind=None):
        rows = []
        for run in walks:
            rows.append(fn([run], lam, vtrue) if kind is None else fn([run], lam, vtrue, kind))
        return np.array(rows)  # (runs, n_alpha)

    lam = 0.8
    pr = {"offline_lambda": per_run(run_offline_lambda, lam),
          "td_acc": per_run(run_td_lambda, lam, "acc"),
          "td_rep": per_run(run_td_lambda, lam, "rep"),
          "true_online": per_run(run_td_lambda, lam, "tot")}
    pick = {k: int(np.nanargmin(np.nanmean(v, axis=0))) for k, v in pr.items()}
    paired = {}
    for a_key, b_key in [("true_online", "offline_lambda"), ("td_rep", "true_online"), ("td_acc", "offline_lambda")]:
        d = pr[a_key][:, pick[a_key]] - pr[b_key][:, pick[b_key]]
        paired[f"{a_key}-{b_key}"] = {"lambda": lam, "alpha_a": float(ALPHAS[pick[a_key]]),
                                      "alpha_b": float(ALPHAS[pick[b_key]]),
                                      "mean_diff": round(float(d.mean()), 4),
                                      "se": round(float(d.std(ddof=1) / np.sqrt(len(d))), 4)}
    res["paired_lambda_0.8"] = paired
    (out / "rw19.json").write_text(json.dumps(res, ensure_ascii=False, indent=1))

    # 实验 2
    rng2 = np.random.default_rng(1701)
    vv = vs_true_values()
    single = vs_run([vs_episode(rng2) for _ in range(3)], vv)
    ep_end = {"offline": [[], [], []], "accumulate": [[], [], []], "true_online": [[], [], []]}
    mean_over_steps = {"offline": [], "accumulate": [], "true_online": []}
    ep_lens = []
    for _ in range(args.vs_runs):
        eps = [vs_episode(rng2) for _ in range(3)]
        ep_lens.append([len(e) - 1 for e in eps])
        o = vs_run(eps, vv)
        ends = np.cumsum([len(e) - 1 for e in eps]) - 1
        for m in o:
            for j in range(3):
                ep_end[m][j].append(o[m][ends[j]])
            mean_over_steps[m].append(float(np.mean(o[m])))
    vs = {"true_values": vv[1:].round(4).tolist(),
          "single_run": {k: [round(x, 4) for x in v] for k, v in single.items()},
          "single_run_episode_lengths": None,
          "runs": args.vs_runs,
          "mean_episode_length": float(np.mean(ep_lens)),
          "mean_nrms_at_episode_end": {m: [round(float(np.mean(ep_end[m][j])), 4) for j in range(3)]
                                       for m in ep_end},
          "mean_nrms_over_first3_episodes": {m: round(float(np.mean(v)), 4) for m, v in mean_over_steps.items()}}
    (out / "vs-fig1.json").write_text(json.dumps(vs, ensure_ascii=False, indent=1))
    print(f"done in {time.time() - t0:.1f}s")
    print(json.dumps(summary, indent=1))
    print("maxdiff", res["true_online_vs_online_lambda_return_maxdiff"])
    print(json.dumps(res["paired_lambda_0.8"], indent=1))
    print(json.dumps({k: vs[k] for k in ["mean_episode_length", "mean_nrms_at_episode_end", "mean_nrms_over_first3_episodes"]}, indent=1))


if __name__ == "__main__":
    main()
