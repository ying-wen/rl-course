# 第 17 章　流式学习与在线信用分配：程序

本目录可以单独运行：在本目录下执行下面的命令即可，结果写回本目录的 `assets/`。目录由 `rl-course/tools/export_chapter_code.py` 从课程目录生成，改程序请改课程目录里的原件，再重新导出。

## 准备

```sh
python3 -m pip install -r requirements.txt
```

需要的第三方包：matplotlib、numpy。复现附录要求 Python 3.10 或更新版本；核验时用的版本见下表。

## 运行（与复现附录相同）

```sh
python3 demos/crl_joint_v12.py
python3 demos/delivery_trace.py --export assets/delivery-trace/steps.json
python3 demos/course15_traces.py --out assets/course15-traces
python3 demos/trace_walkthrough.py --out assets/course15-traces/prefixes.json
python3 demos/crl_v8_mechanisms.py --figures
python3 demos/ch17_lit_rw19.py             # 文献原型：19 状态随机游走与真在线 TD，写 assets/ch17-lit-rw19
python3 demos/crl_ladder_learners.py --exp ch17 --seeds 60 --seed0 100 --steps 2000000 --tag formal   # 四区仓库阶梯，写 assets/crl-ladder-world/runs/formal-ch17.json
python3 demos/crl_ladder_figures.py ch17           # 写 assets/crl-ladder-world/fig/ladder-ch17.png
python3 demos/crl_ladder_diagnostics.py --list   # 列出诊断档；单档用 --arms 档名 --seeds 20 运行
```

## 本目录的程序

| 程序 | 说明 | 核验 |
|---|---|---|
| `demos/crl_joint_v12.py` | One continuing navigation task, learned skills, GVFs and rate-aware planning. | 通过（91 秒） |
| `demos/delivery_trace.py` | On-policy GVF prediction along two consecutive deliveries (ordinary tabular TD(lambda)). | 通过（0 秒） |
| `demos/course15_traces.py` | Chapter 7: n-step TD, accumulating traces, and true-online TD(lambda). | 通过（17 秒） |
| `demos/trace_walkthrough.py` | Read one mud-path transition at a time. Uses the chapter's TD implementations. | 通过（0 秒） |
| `demos/crl_v8_mechanisms.py` | Small, reproducible calculations for CRL teaching; not a full research agent. | 通过（4 秒） |
| `demos/ch17_lit_rw19.py` | 第 17 章文献原型的本课重跑：随机游走上的 n 步 TD、λ 回报与三种 TD(λ)。 | 通过（219 秒） |
| `demos/crl_ladder_learners.py` | 四区仓库的学习器阶梯（例子方案第三步）。 | 超时：300 秒内未跑完（启动正常） |
| `demos/crl_ladder_diagnostics.py` | 四区仓库阶梯的诊断与改法（11-20）。 | 通过（20 秒） |
| `demos/crl_ladder_figures.py` | 阶梯世界（四区仓库）阅读稿用图：地图与各章“占天花板”条形。 | 通过（2 秒） |
| `demos/crl_ladder_world.py` | 四区仓库：第三部分的能力阶梯世界（环境与精确参照）。 | 通过（30 秒） |
| `demos/crl_ladder_world_checks.py` | 四区仓库的独立检查（照 v12 的做法：手算、枚举、独立实现互查）。 | 通过（52 秒） |
| `demos/crl_ladder_power.py` | 四区仓库学习器阶梯：试点估 σ_Δ 定种子数，正式跑后出第 24 章的账本。 | 通过（0 秒） |
| `demos/crl_ladder_ceiling.py` | 四区仓库学习器阶梯：每个试验条件的“天花板”，供账本算“离最优还差多少”。 | 超时：300 秒内未跑完（启动正常） |

表中后 4 个程序复现附录本章一节没有列出，来自课件、阅读稿、CODE-MAP 或文件名前缀（第三部分另含学习器阶梯）。

## 第三部分的学习器阶梯（例子方案第三步）

四区仓库世界与 L0–L10 阶梯学习器。每章一个实验，三档：没有、设计者给定、从经验学到。比较都是配对的：同一种子下两档用同一份世界随机数。

```sh
python3 demos/crl_ladder_world.py --fast                     # 各区参考线，写 reference.json（全量去掉 --fast）
python3 demos/crl_ladder_world_checks.py                     # 世界本身的核对
python3 demos/crl_ladder_ceiling.py                          # 各条件的天花板（ε-软最好率），写 ceiling.json
python3 demos/crl_ladder_learners.py --exp ch17 --seeds 2 --steps 200000 --procs 2 --tag smoke   # 冒烟：写 assets/crl-ladder-world/runs/smoke-ch17.json
python3 demos/crl_ladder_learners.py --exp ch17 --seeds 60 --seed0 100 --steps 2000000 --tag formal   # 正式设置（种子数与 runs/ 里的正式记录相同）
python3 demos/crl_ladder_power.py ledger --runs formal-ch17     # 配对差与 95% 区间，写 ledger-formal-ch17.json
python3 demos/crl_ladder_figures.py ch17                       # 阅读稿用的地图与条形图（读账本）
# 改进与诊断（README 第九节）：同一套世界随机数，跑完用 --compare 出配对差
python3 demos/crl_ladder_diagnostics.py --arms ch17/d20/early0.3 --seeds 2 --steps 200000 --procs 2 --tag smoke   # 冒烟：写 runs/diag-smoke-*.json
python3 demos/crl_ladder_diagnostics.py --arms ch17/d20/early0.3 --seeds 20 --procs 3
python3 demos/crl_ladder_diagnostics.py --compare ch17/d20/early0.3 ch17/d20/learned
```

参考记录在 `assets/crl-ladder-world/runs/`（随本目录复制）。正式设置一章要跑数十分钟到数小时；冒烟一行只确认程序能走通。正式结果与读法见 `assets/crl-ladder-world/README.md` 第八节，改进与诊断见第九节。

## 复现附录本章一节

本章来自本课程序的结果有：17.2 节的真实轨迹与配送迹，17.3 节的泥地目标分布，17.4 节之后的逐前缀等价核对，17.6 节 Stream-X 的尺度曲线，19 状态随机游走与真在线 TD 两个文献原型，以及 17.2 节四区仓库上支付延迟 20 步的阶梯实验。阶梯实验的三种改法由诊断程序另外运行，与学到延迟的一档按种子配对。17.6 节引用的 Stream Q($\lambda$)、Stream-AC 与 ObGD 是原作者的代码，出处见表后。

其余数字由正文推导直接算出，包括路口一步 Sarsa 的写入、回放次序、.81 与 .5184、期望迹 .08、17.5 节离策略平均方向中的 $+.2w$、$-.016w$、$-3.4w$、$2^n-1$ 和尺度对照表。assets/crl-formal-maps 下的路口与迹示意图是手绘 SVG，没有绘图程序。

| 位置 | 结果 | 设置 | 程序 | 数据与输出 |
|---|---|---|---|---|
| 17.2 重复访问下的线性资格迹 | 第 39,997 步在 A 原地停留、第 39,998 步离开 A、第 40,003 步到 C 的实际轨迹；该段上 $\lambda=.8$、$\alpha=.1$ 的迹 $.8^6+.8^5=.589824$ 由这段轨迹手算 | 本课的模拟：三站连续配送（Y 形格，打滑概率 .1，C 站到站奖励在第 60,000 步由 3 降为 .1），每次运行 120,000 个原始转移、不回放、不重置；不规划、规划（每完成一个选项另做 5 次模型备份）、冻结三种条件，独立重复 8 次。正文取规划条件种子 0 的第 39,996–40,002 行 | `demos/crl_joint_v12.py` | `assets/crl-joint-v12/raw-planning-seed0.npz`、`assets/crl-joint-v12/manifest.json` |
| 17.2 资格迹与时间信用分配 | $\lambda=.5$、$\alpha=.8$ 时迹 $(.4,.8)$、误差 $.72$、增量 $(.40,.16)$；到站延续取 .5 时第三步的迹 $(1.125,.25)$ | 本课的计算：配送路线上的晚到信号，$\lambda$ 与到站延续系数各取课内给定的几档，逐步列出迹、误差与增量；确定性计算，无随机重复 | `demos/delivery_trace.py` | `assets/delivery-trace/steps.json`（六种组合） |
| 17.3 节“改走右边还缺什么证据”（课件 `ch15-f07-backup-depth-breadth`，加深与加宽） | 一步期望目标 .505、两步期望目标 .50905 | 本课的计算：泥地例，成功概率 .1，$\gamma=.9$，尾值 $v=.5$；对 $n=1,2,4,16$ 精确枚举目标分布的均值、方差与均方误差。单条路径的 .45、.405 由正文推导直接算出 | `demos/course15_traces.py` | `assets/course15-traces/report.json`（target_distributions）、`assets/course15-traces/target-distribution.png` |
| 17.4 节“Dutch 迹与逐前缀前向计算的等价性”（课件 `course15-trace-true-online-check`） | 第 4 步后泥格 S4 的预测：普通累积迹 .7090，真在线 TD 与逐前缀前向重算 .6713，冻结表前向和（各次写入都按初表算再相加）.6966，离线 λ 回报（目标读初表，回合末按时间次序写入）.6718（`report.json` 的 `offline_final`） | 本课的计算：泥地例的四步轨迹，线性特征初值 $(.4,.5)$，$\alpha=.2$、$\gamma=.9$、$\lambda=.8$；确定性计算，另用 40 组随机线性特征核对前向与真在线结果一致 | `demos/course15_traces.py`、`demos/trace_walkthrough.py`（课堂设定导出） | `assets/course15-traces/report.json`、`assets/course15-traces/four-step-trace.csv`、`assets/course15-traces/online-equivalence.png`、`assets/course15-traces/prefixes.json` |
| 17.6 Stream-X 的尺度控制 | $\alpha=.05$、$\beta=.9$；尖峰 $u=20$ 时固定步长位移为 1，峰值控制后的步长约 .05 | 本课的计算：给定增量序列（8 个 .2、一次 20、30 个 .2、一次 $-8$、20 个 $-.2$），逐步比较固定步长与逐坐标峰值控制；确定性计算 | `demos/crl_v8_mechanisms.py` | `assets/crl-v8/streaming-optimizer.csv`、`assets/crl-v8/streaming-optimizer.png`、`assets/crl-v8/checks.json` |
| 17.2 节“19 状态随机游走：误差隔约一百步才到”（课件 `ch17-lit-randomwalk`） | 离线 $\lambda$ 回报最好 .252（$\lambda=.8$，$\alpha=.4$）；$n$ 步 TD 最好 .255（$n=4$，$\alpha=.4$）；$\lambda=.9$ 时累积迹在 $\alpha=.65$ 误差 1.23、$\alpha\ge.75$ 发散，离线 $\lambda$ 回报全程不超过 .452 | 复现 Sutton 与 Barto 例 7.1 及图 7.2、12.3、12.6、12.8 的设定：19 状态、两端奖励 $-1$ 与 $+1$、$\gamma=1$、初值 0；$n=1\ldots512$，$\lambda\in\{0,.4,.8,.9,.95,.975,.99,1\}$，$\alpha=.05\ldots1$；100 次独立运行，每次 10 个回合，各参数用同一批游走；度量为每回合末 19 个状态的 RMS 误差，取前 10 个回合平均；另核对真在线 TD 与在线 $\lambda$ 回报逐步相同 | `demos/ch17_lit_rw19.py` | `assets/ch17-lit-rw19/rw19.json` |
| 17.4 节“真在线 TD 的检验”（课件 `ch17-lit-true-online`） | 图 1 设定单次运行的阶梯 1→.727→.565→.522；1000 次平均的前三回合末误差，离线与真在线 .681、.495、.384，累积迹 .722、.574、.496；19 状态 $\lambda=.8$ 最好 RMS：离线 .252、累积迹 .253、真在线 .245、替换迹 .240，配对差（真在线−离线）$-.0074\pm.0009$、（替换迹−真在线）$-.0054\pm.0009$ | 复现 van Seijen 等（JMLR 2016）图 1 的设定：10 状态，.7 向左，每步奖励 1，$\gamma=\lambda=1$，$\alpha=.2$，从最右一格出发，初值取 0（本课假设）；单次运行 3 个回合，另 1000 次独立运行；19 状态部分同上一行 | `demos/ch17_lit_rw19.py` | `assets/ch17-lit-rw19/vs-fig1.json`、`assets/ch17-lit-rw19/rw19.json`（paired_lambda_0.8 字段） |
| 17.2 节（课件 `ch17-ladder`） | 支付晚 20 步到账时，带迹的学习器 lifetime 率只到天花板的三成多；学到延迟到八成，比给定延迟少一成 | 本课的模拟：四区仓库，规律 R0，支付延后 20 步，200 万步，60 个种子；三种改法各 20 个种子，与学到延迟配对 | `demos/crl_ladder_learners.py` 实验 `ch17`；`demos/crl_ladder_diagnostics.py` | `assets/crl-ladder-world/runs/formal-ch17.json`、`assets/crl-ladder-world/fig/ladder-ch17.png`；assets/crl-ladder-world/runs/ 下的 diag-ch17_*.json |

运行：
```sh
python3 demos/crl_joint_v12.py
python3 demos/delivery_trace.py --export assets/delivery-trace/steps.json
python3 demos/course15_traces.py --out assets/course15-traces
python3 demos/trace_walkthrough.py --out assets/course15-traces/prefixes.json
python3 demos/crl_v8_mechanisms.py --figures
python3 demos/ch17_lit_rw19.py             # 文献原型：19 状态随机游走与真在线 TD，写 assets/ch17-lit-rw19
python3 demos/crl_ladder_learners.py --exp ch17 --seeds 60 --seed0 100 --steps 2000000 --tag formal   # 四区仓库阶梯，写 assets/crl-ladder-world/runs/formal-ch17.json
python3 demos/crl_ladder_figures.py ch17           # 写 assets/crl-ladder-world/fig/ladder-ch17.png
python3 demos/crl_ladder_diagnostics.py --list   # 列出诊断档；单档用 --arms 档名 --seeds 20 运行
```

外部代码（出处）：17.6 的 Stream Q($\lambda$)、Stream-AC 与 ObGD 引自 Elsayed 等的 streaming-drl 仓库（github.com/mohmdelsayed/streaming-drl），提交 407dca7 中的 stream_q.py、optim.py、stream_ac_discrete.py，以及提交 9326fc3 中的 stream_ac_discrete.py、optimizer.py。

## 参考数据

`assets/`（以及 `demos/NN-results/`）下复制了 162 个数据文件（json、csv 等），即课程目前使用的结果；图片没有复制，运行程序会重新画出。重跑会覆盖这些文件，可以先另存一份再对照。
