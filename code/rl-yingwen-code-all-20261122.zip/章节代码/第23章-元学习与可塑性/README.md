# 第 23 章　元学习与可塑性：程序

本目录可以单独运行：在本目录下执行下面的命令即可，结果写回本目录的 `assets/`。目录由 `rl-course/tools/export_chapter_code.py` 从课程目录生成，改程序请改课程目录里的原件，再重新导出。

## 准备

```sh
python3 -m pip install -r requirements.txt
```

需要的第三方包：matplotlib、mpmath、numpy。复现附录要求 Python 3.10 或更新版本；核验时用的版本见下表。

## 运行（与复现附录相同）

```sh
python3 demos/continual_v6_calculations.py --figures   # 写 assets/continual/v6
python3 demos/crl_v10_derivations.py                   # 写 assets/crl-v10
python3 demos/crl_v8_mechanisms.py --figures           # 写 assets/crl-v8
python3 demos/crl_question_selection.py                # 96 对 × 2048 步，写 assets/crl-question-selection
python3 demos/crl_skill_discovery_trial.py             # 64 对 × 8192 步，写 assets/crl-skill-discovery-trial
python3 demos/crl_meta_reader_trial.py                 # 64 对 × 24000 步，写 assets/crl-meta-reader-trial
python3 demos/ch23_lit_idbd.py             # 文献原型：IDBD 原始实验，写 assets/ch23-lit-idbd
python3 demos/crl_ladder_learners.py --exp ch23 --seeds 20 --seed0 100 --steps 2000000 --tag formal   # 四区仓库阶梯，写 assets/crl-ladder-world/runs/formal-ch23.json
python3 demos/crl_ladder_figures.py ch23           # 写 assets/crl-ladder-world/fig/ladder-ch23.png
python3 demos/ch23_r21_ab2_eval_window.py   # 写 assets/ch23-r21/ab2-eval-window.pdf
```

## 本目录的程序

| 程序 | 说明 | 核验 |
|---|---|---|
| `demos/continual_v6_calculations.py` | Chapter 14 worked calculations and small subtask training. | 通过（2 秒） |
| `demos/crl_v10_derivations.py` | Small exact calculations accompanying chapter 14's v10 derivations. | 通过（2 秒） |
| `assets/crl-formal-maps/exploration-score.py` | Draw two analytical consequences of changing a univariate Gaussian policy's scale. | 通过（1 秒） |
| `demos/crl_v8_mechanisms.py` | Small, reproducible calculations for CRL teaching; not a full research agent. | 通过（2 秒） |
| `demos/crl_question_selection.py` | Select an event GVF for a route model from a single continuing stream. | 通过（1 秒） |
| `demos/crl_skill_discovery_trial.py` | Discover and test one reusable delivery skill on a single continuing trajectory. | 通过（10 秒） |
| `demos/crl_meta_reader_trial.py` | Closed-loop duration meta-learning on the chapter 15 continuing three-station task. | 通过（8 秒） |
| `demos/crl_joint_v12.py` | One continuing navigation task, learned skills, GVFs and rate-aware planning. | 通过（49 秒） |
| `demos/ch23_lit_idbd.py` | 第 23 章文献原型：Sutton (1992) IDBD 的两个实验（AAAI-92，pp. 171-176）。 | 通过（16 秒） |
| `demos/crl_ladder_learners.py` | 四区仓库的学习器阶梯（例子方案第三步）。 | 超时：300 秒内未跑完（启动正常） |
| `demos/ch23_r21_ab2_eval_window.py` | 第 23 章 23.8 节：评价窗口改变“最好的步长”。 | 通过（2 秒） |
| `demos/crl_ladder_figures.py` | 阶梯世界（四区仓库）阅读稿用图：地图与各章“占天花板”条形。 | 通过（1 秒） |
| `demos/ch23_r21_stream_stepsize.py` | 第 23 章章首左图：一条不重置的经验流上，元梯度把共享预测器的步长调到哪里。 | 通过（1 秒） |
| `demos/ch23_r21_ab2_stream_change.py` | 11-21 请求 r1121-133704（第 23 章 p1870 ch23-bridge-plasticity）：连续经验流上元梯度调步长，世界改变后能否调回。 | 通过（2 秒） |
| `demos/ch23_r21_module_stepsize.py` | 第 23 章 23.2 节：步长分到多细——整个智能体一个、每个模块一个、每个参数一个。 | 通过（33 秒） |
| `demos/crl_ladder_world.py` | 四区仓库：第三部分的能力阶梯世界（环境与精确参照）。 | 通过（22 秒） |
| `demos/crl_ladder_world_checks.py` | 四区仓库的独立检查（照 v12 的做法：手算、枚举、独立实现互查）。 | 通过（16 秒） |
| `demos/crl_ladder_power.py` | 四区仓库学习器阶梯：试点估 σ_Δ 定种子数，正式跑后出第 24 章的账本。 | 通过（0 秒） |
| `demos/crl_ladder_ceiling.py` | 四区仓库学习器阶梯：每个试验条件的“天花板”，供账本算“离最优还差多少”。 | 超时：300 秒内未跑完（启动正常） |
| `demos/crl_ladder_diagnostics.py` | 四区仓库阶梯的诊断与改法（11-20）。 | 通过（0 秒） |

被上面程序 import 的本课模块：`demos/plot_fonts.py`。

表中后 8 个程序复现附录本章一节没有列出，来自课件、阅读稿、CODE-MAP 或文件名前缀（第三部分另含学习器阶梯）。

## 第三部分的学习器阶梯（例子方案第三步）

四区仓库世界与 L0–L10 阶梯学习器。每章一个实验，三档：没有、设计者给定、从经验学到。比较都是配对的：同一种子下两档用同一份世界随机数。

```sh
python3 demos/crl_ladder_world.py --fast                     # 各区参考线，写 reference.json（全量去掉 --fast）
python3 demos/crl_ladder_world_checks.py                     # 世界本身的核对
python3 demos/crl_ladder_ceiling.py                          # 各条件的天花板（ε-软最好率），写 ceiling.json
python3 demos/crl_ladder_learners.py --exp ch23 --seeds 2 --steps 200000 --procs 2 --tag smoke   # 冒烟：写 assets/crl-ladder-world/runs/smoke-ch23.json
python3 demos/crl_ladder_learners.py --exp ch23 --seeds 20 --seed0 100 --steps 2000000 --tag formal   # 正式设置（种子数与 runs/ 里的正式记录相同）
python3 demos/crl_ladder_power.py ledger --runs formal-ch23     # 配对差与 95% 区间，写 ledger-formal-ch23.json
python3 demos/crl_ladder_figures.py ch23                       # 阅读稿用的地图与条形图（读账本）
```

参考记录在 `assets/crl-ladder-world/runs/`（随本目录复制）。正式设置一章要跑数十分钟到数小时；冒烟一行只确认程序能走通。正式结果与读法见 `assets/crl-ladder-world/README.md` 第八节，改进与诊断见第九节。

## 复现附录本章一节

本章来自本课程序的结果有：23.1、23.2 节两张按公式绘制的图，23.6 节探索分布的两图与特征替换的小例，23.7 节三组配对实验，IDBD 原始实验的复现，23.2 节四区仓库上打滑率漂移的阶梯实验，以及 23.8 节评价窗口与最好步长的关系。最后一项按均值与方差递推精确计算，不抽样。

23.1 节延伸中单次元导数的 $-.16$ 与 $.24$、23.4 节“遗忘再重学”的小例、23.6 节学习曲线的 $1,2,2.5$ 与 $2.25$、$1.27$，以及休眠比例 $.5$、有效秩 $4$ 与 $1$ 的算例，由正文推导直接算出。23.2 节逐坐标步长的对照与 23.4 节暗室准则的对照，程序暂未收入本附录。23.5 节 DiscoRL 的实现是原作者的代码，23.6 节持续反向传播的原图引自原文，出处见表后。

| 位置 | 结果 | 设置 | 程序 | 数据与输出 |
|---|---|---|---|---|
| 23.1 节延伸“单次元导数的方向取决于后续目标” | 图 23.1：下一步损失随本次步长变化，后续目标为 $1$ 与 $-1$ 时元梯度方向相反 | 按公式计算：$w_t=0$、$y_t=1$，下一目标取 $1$ 或 $-1$，横轴为步长；无随机重复 | `demos/continual_v6_calculations.py` | `assets/continual/v6/manifest.json`；图 `assets/continual/v6/meta-step-loss.png`、`assets/continual/v6/meta-step-loss.svg` |
| 23.2 节“资格迹与步长敏感度” | 图 23.2：两次更新后的参数与对数步长敏感度（$\alpha=.8$ 时 $w_2=.16$、$s_2^{\eta}=-.48$） | 按公式计算：一个特征，两趟目标依次为 $1$ 与 $0$；敏感度递推另与有限差分对照；无随机重复 | `demos/crl_v10_derivations.py` | `assets/crl-v10/results.json`（`meta_sensitivity_vs_finite_difference`）；图 `assets/crl-v10/trace-and-sensitivity.png` |
| 23.6 节“探索分布、更新尺度与适应速度” | 缩小高斯策略标准差时，超过阈值的动作概率变小、得分函数对均值参数的二阶矩变大（两图） | 按公式计算：一元高斯策略，改变标准差；无随机重复 | `assets/crl-formal-maps/exploration-score.py` | 图 `assets/crl-formal-maps/exploration-score.svg`、`assets/crl-formal-maps/exploration-score.pdf` |
| 23.6 节延伸“学习可塑性” | 替换一个失活特征后，输出连接先学习、输入连接随后恢复，预测超过 $.99$ | 本课的确定性计算：两个无偏置的 ReLU 特征，输入权重初值均为 $-1$（失活），输入与目标均为 $1$，SGD 步长 $.1$，共 60 次更新；第 10 次更新时把一个特征的输入权重换成 $.5$、输出权重置零，另一组不替换作对照；无随机重复 | `demos/crl_v8_mechanisms.py`（`renewal`） | `assets/crl-v8/feature-renewal.csv`；`assets/crl-v8/checks.json`；`assets/crl-v8/manifest.json`；图 `assets/crl-v8/feature-renewal.png` |
| 23.7 节“规划使用哪一个预测问题”（24.6 节“局部学习与全程收益的实验对照”表第一行引用） | 按探测上的奖励预测误差选通道：正确通道占比由均匀选择的 $32.9\%$ 升至 $90.2\%$，每原始步收益增 $.0746$，配对标准误 $.0027$；规划改读无条件平均值时两组收益逐对相同 | 本课的模拟：三个给定预测通道，每次运行 2,048 个原始步，探测概率 $.15$，每 16 次探测复核一次所选通道；配对运行独立重复 96 次 | `demos/crl_question_selection.py` | `assets/crl-question-selection/paired.csv`；`assets/crl-question-selection/summary.json` |
| 23.7 节“子目标选择、技能调用与练习成本” | 每步收益：均匀 $.8926$、排序 $.9774$、只用原始动作 $.9987$；排序减均匀 $+.08479\,[.07007,.09951]$，约 $55\%$ 来自试练窗口（窗口内 $1718.28$ 对 $1337.80$）；种子 0 的逐次事件（第 256、384、388 步，$2.8251$、$1.4374$）；图“发现与练习的对照” | 本课的模拟：五个候选目标；前 256 步共同随机探索，此后共 16 次试练机会，每次至多 64 步练习、64 步估计；每条 lifetime 8,192 步，配对 lifetime 独立重复 64 次，95% 配对 $t$ 区间 | `demos/crl_skill_discovery_trial.py` | `assets/crl-skill-discovery-trial/runs.csv`；`assets/crl-skill-discovery-trial/curves.csv`；`assets/crl-skill-discovery-trial/seed-0-events.json`；`assets/crl-skill-discovery-trial/summary.json`；`assets/crl-skill-discovery-trial/protocol.md`；`assets/crl-skill-discovery-trial/README.md`；图 `assets/crl-skill-discovery-trial/discovery-comparison.png` |
| 23.7 节“元步长、时长模型与闭环控制” | 自适应减固定步长：每千步奖励差，平稳世界 $-.299\,[-.787,.057]$，支路变慢 $-.662\,[-1.274,-.123]$；时长均方根误差差 $-.0070$、$-.0446$；规划读逐步 TD 估计时 21/64 与 64/64 个种子出现不同选择；第 1,270 步的估计差由 $-.00334$ 变为 $+.00516$ 等逐步核算；图 A、B | 本课的模拟：三站任务（同 24 章），时长 GVF 初始步长 $.08$，元步长率 $.03$，Huber 阈值 $4$，每块 64 步；规划读完成行程估计或逐步 TD 估计，分平稳与支路变慢两种世界；每条 lifetime 24,000 步，种子起点 140000，配对 lifetime 独立重复 64 次，95% 配对区间 | `demos/crl_meta_reader_trial.py`（调用 `demos/crl_joint_v12.py`） | `assets/crl-meta-reader-trial/results.json`；`assets/crl-meta-reader-trial/runs.csv`；`assets/crl-meta-reader-trial/curves.csv`；`assets/crl-meta-reader-trial/first-divergences.csv`；`assets/crl-meta-reader-trial/README.md`；图 `assets/crl-meta-reader-trial/meta-reader-effects.png` |
| 23.2 节“IDBD 的原始实验”（课件 ch23-lit-idbd） | 最好 LMS $3.37$（$\alpha=.03$）、IDBD $1.62$（$\theta=.005$）；$\theta=.001$ 学 25 万样本后相关输入步长 $.131\pm.006$、无关约 $.0076$；固定步长扫描最低点在 $.13$ 与 $.14$ 之间；与 Sutton（1992）图 3–5 并列，$\theta$ 小时误差高于论文 | 本课重跑：20 个标准正态输入，5 个相关、系数 $\pm1$，每 20 个样本翻转一个符号；先学 2 万再在其后 1 万样本上算 MSE，IDBD 初始步长 $.05$；固定步长扫描只施加在相关输入上；每档 100 次独立运行 | `demos/ch23_lit_idbd.py` | `assets/ch23-lit-idbd/results.json` |
| 23.2 节（课件 `ch23-ladder`） | 写定步长 .1 已近最好；IDBD 从 .1 起步比写定 .1 高 .0007，每次打滑率变化后少损失约 43 个单位奖励 | 本课的模拟：四区仓库，200 万步，规律 R0，打滑率每 5 万步重抽，20 个种子；差分 Q，状态含灯 | `demos/crl_ladder_learners.py` 实验 `ch23` | `assets/crl-ladder-world/runs/formal-ch23.json`、`assets/crl-ladder-world/fig/ladder-ch23.png` |
| 23.8 节（课件 `ch23-r21-ab2-horizon`） | 评价前 20 趟时最好的步长为 .31，评价整段 lifetime 时为 .07 | 本课的计算：固定步长下按均值与方差递推精确计算，不抽样；第 500 趟后右指示的回报由 1 改为 3 | `demos/ch23_r21_ab2_eval_window.py` | `assets/ch23-r21/ab2-eval-window.pdf` |

运行：
```sh
python3 demos/continual_v6_calculations.py --figures   # 写 assets/continual/v6
python3 demos/crl_v10_derivations.py                   # 写 assets/crl-v10
python3 demos/crl_v8_mechanisms.py --figures           # 写 assets/crl-v8
python3 demos/crl_question_selection.py                # 96 对 × 2048 步，写 assets/crl-question-selection
python3 demos/crl_skill_discovery_trial.py             # 64 对 × 8192 步，写 assets/crl-skill-discovery-trial
python3 demos/crl_meta_reader_trial.py                 # 64 对 × 24000 步，写 assets/crl-meta-reader-trial
python3 demos/ch23_lit_idbd.py             # 文献原型：IDBD 原始实验，写 assets/ch23-lit-idbd
python3 demos/crl_ladder_learners.py --exp ch23 --seeds 20 --seed0 100 --steps 2000000 --tag formal   # 四区仓库阶梯，写 assets/crl-ladder-world/runs/formal-ch23.json
python3 demos/crl_ladder_figures.py ch23           # 写 assets/crl-ladder-world/fig/ladder-ch23.png
python3 demos/ch23_r21_ab2_eval_window.py   # 写 assets/ch23-r21/ab2-eval-window.pdf
```

外部代码（出处）：23.5 节 DiscoRL 的内层与外层，链接到原作者仓库 google-deepmind/disco_rl 中的 `disco.py`、`meta_train.ipynb`、`eval.ipynb`（Oh 等，Nature 2025）。23.6 节的持续反向传播原图引自 Dohare 等（Nature 2024）。

## 参考数据

`assets/`（以及 `demos/NN-results/`）下复制了 177 个数据文件（json、csv 等），即课程目前使用的结果；图片没有复制，运行程序会重新画出。重跑会覆盖这些文件，可以先另存一份再对照。
