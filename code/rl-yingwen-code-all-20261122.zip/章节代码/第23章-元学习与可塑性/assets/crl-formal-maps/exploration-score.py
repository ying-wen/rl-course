"""Draw two analytical consequences of changing a univariate Gaussian policy's scale."""
import math
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager
import numpy as np

out = Path(__file__).resolve().parent
# Prefer the course's CJK sans serif; a Noto installation also works on Linux.
bundled_font = Path("/System/Library/Fonts/STHeiti Light.ttc")
if bundled_font.exists():
    font_manager.fontManager.addfont(str(bundled_font))
for name in ["Heiti TC", "Heiti SC", "Noto Sans CJK SC", "Microsoft YaHei"]:
    try:
        font_manager.findfont(name, fallback_to_default=False)
    except ValueError:
        continue
    plt.rcParams["font.family"] = name
    break
plt.rcParams.update({"axes.spines.top": False, "axes.spines.right": False,
                     "pdf.fonttype": 42, "svg.fonttype": "path", "axes.unicode_minus": False})
fig, (left, right) = plt.subplots(1, 2, figsize=(10.0, 2.60))
fig.subplots_adjust(left=.062, right=.982, bottom=.21, top=.81, wspace=.42)
x = np.linspace(-3, 3, 901)
for scale, color in [(1, "#375a75"), (.5, "#ad511b")]:
    density = np.exp(-.5*(x/scale)**2)/(scale*math.sqrt(2*math.pi))
    left.plot(x, density, color=color, lw=2, label=rf"$\sigma={scale:g}$")
    left.fill_between(x, 0, density, where=x>=1, color=color, alpha=.24)
left.axvline(1, color="#4a595c", lw=1, ls="--")
left.set(xlim=(-2.8,2.9), ylim=(0,.93), yticks=[0,.4,.8], xlabel="动作相对均值的偏移", title="超过同一阈值的动作减少")
left.legend(frameon=False, fontsize=9, loc="upper left", handlelength=1.5)
left.text(1.07,.57,"阈值 1",fontsize=9)
scale = np.linspace(.45,1.10,200)
right.plot(scale,1/scale**2, color="#396d68", lw=2)
for s, color, offset in [(1,"#375a75",(.012,.18)), (.5,"#ad511b",(.015,.12))]:
    right.scatter([s],[1/s**2],color=color,zorder=3)
    right.text(s+offset[0],1/s**2+offset[1],f"{1/s**2:g}",fontsize=11,color=color)
right.set(xlabel="动作标准差 σ",title="均值参数的得分函数二阶矩增大",
          xlim=(.43,1.13),ylim=(0,5.3),xticks=[.5,.75,1],yticks=[0,1,2,3,4,5])
for ax in (left, right):
    ax.tick_params(labelsize=9)
    ax.grid(axis="y", alpha=.14)
for suffix in ["pdf", "svg"]:
    fig.savefig(out / ("exploration-score." + suffix), facecolor="white")
