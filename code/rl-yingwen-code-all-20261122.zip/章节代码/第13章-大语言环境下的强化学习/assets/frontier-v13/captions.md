# 第13章原图图注与课堂问题

下列图像来自原论文或官方报告。裁切和选图保留原数据、坐标轴与图例。每项列出出处、读图要点和课堂讨论问题；图号与页码也保存在 `manifest.json`。

## prorl-fig4-passk

**短图注**：同一次RL训练可提高单次正确率，却在不同任务上缩小、保持或扩大大k采样覆盖。

**出处**：[ProRL v1](https://arxiv.org/abs/2505.24864v1)，2025-05-30，PDF7 Fig.4。`crops/prorl-fig4-passk.png`，同名PDF为矢量裁图。

**怎么看**：每行是一类随训练变化的任务，横轴为测试时样本数k，三条线为base/intermediate/final。先看k=1，再看k=256；不要只展示Sustained行。这里的有限采样“边界”不是对分布支持的证明。训练阶段还改动过奖励、数据、长度和重置设置。

**课堂问题**：若单次更好而大k更差，训练究竟改善了成功概率、答案多样性还是可解题目集合？

## prorl-fig4-selected

**短图注**：原Fig.4各取一个例子：math的覆盖缩小、gpqa的收益饱和、codecontests的持续增益。

**出处与变换**：同一原论文PDF7 Fig.4，按Diminish/Plateau/Sustained三行分别选math、gpqa_diamond、codecontests，保留原坐标、数据、标题、图例、类别标签，仅横向排列。`crops/prorl-fig4-selected.pdf`为矢量组合，PNG预览同名；完整九panel图仍为`prorl-fig4-passk.pdf`。选例不代表三类在整个题集中的比例。

**课堂问题**：三列在k=1和k=256时，对base/intermediate/final的排序怎样变化？

## prorl-fig1-training

**短图注**：在作者的多阶段训练配方下，pass@1与pass@16随训练推进提高。

**出处**：[ProRL v1](https://arxiv.org/abs/2505.24864v1)，PDF2 Fig.1。`crops/prorl-fig1-training.png`。

**讲解**：左侧才是训练步数曲线；中/右为novelty代理和任务指标。不能从一张组合图推出只增加训练步数就普遍有益；creativity index仅度量与指定语料的重叠。

**课堂问题**：为了判断延长训练本身的贡献，还要固定哪些因素？

## openai-deepresearch-tool-budget

**短图注**：对固定已训练模型，放宽工具调用预算可提高这组内部任务的通过率。

**出处**：[Introducing deep research](https://openai.com/index/introducing-deep-research/)，2025-02-02；[官方网页PDF](https://cdn.openai.com/API/docs/deep_research_blog.pdf)，PDF12，未编号图“Pass Rate vs Max Tool Calls”；页眉快照日期2025-02-21。`crops/openai-deepresearch-tool-budget.png`。

**讲解**：横轴是最大工具调用数，纵轴是内部expert-level任务通过率。论文式完整训练细节、误差条与所有评测条件未在该图公开。课堂只讲测试时交互预算，不能把曲线说成在线改权重。

**课堂问题**：多一次搜索可能增加什么信息？为什么它与多做一次梯度更新不是同一个预算？

## areal-fig2-system

**短图注**：生成、评分、训练分离后，参数传播和样本年龄成为学习过程的一部分。

**出处**：[AReaL v1](https://arxiv.org/abs/2505.24298v1)，2025-05-30，PDF4 Fig.2；机制精读PDF4–6。`crops/areal-fig2-system.png`。

**讲解**：沿prompt→rollout→reward→buffer→trainer追一条轨迹，再沿参数服务回到rollout。中断续生会让同一回答含不同版本；旧KV重算。buffer内数据本设置使用一次，不据名称推断反复replay。

**课堂问题**：等待全部长回答结束，与持续生成旧版本回答，分别损失什么？

## anthropic-agent-loop

**短图注**：工具动作获得环境反馈后进入下一次决策；图中尚没有参数更新。

**出处**：[Building effective agents](https://www.anthropic.com/research/building-effective-agents)，2024-12-19，Agents小节“Autonomous agent”未编号原图。`originals/anthropic-agent-loop.png`为原始PNG。

**讲解**：Feedback可包括运行测试失败或检索结果；它与给训练更新用的标量奖励区分。停止条件也属于系统接口。

**课堂问题**：执行器返回一个错误后，哪些状态发生了变化，哪些参数可能仍完全相同？

## gemini15-fig1-agent

**短图注**：高层ER模型用工具、计划和进度判断组织任务，VLA将短指令转成实际动作。

**出处**：[Gemini Robotics1.5技术报告](https://storage.googleapis.com/deepmind-media/gemini-robotics/Gemini-Robotics-1-5-Tech-Report.pdf)，2025-09，PDF2 Fig.1；精读PDF3–4 §2。`crops/gemini15-fig1-agent.png`。

**讲解**：上半图是ER，下面是动作模型；这里不是两个相同LLM在轮流聊天。VLA被高层当作一种具有物理后果的工具。

**课堂问题**：把“搜索当地回收规定”和“放下物体”都叫工具调用，会隐藏哪些时间与后果差异？

## gemini15-fig4-motion-transfer

**短图注**：跨本体数据与Motion Transfer配方对不同机器人、不同泛化条件的作用可分别比较。

**出处**：[Gemini Robotics1.5技术报告](https://storage.googleapis.com/deepmind-media/gemini-robotics/Gemini-Robotics-1-5-Tech-Report.pdf)，PDF7 Fig.4；精读PDF7–9。`crops/gemini15-fig4-motion-transfer.png`。

**讲解**：三组机器人、三种训练条件，纵轴是progress score；它不是每项任务整段成功率。跨本体数据与MT的作用并不在所有列都同样强，保留原误差条。

**课堂问题**：增加别的机器人数据与改变数据对齐配方，可以用哪两组柱子分别辨认？

## anthropic-robotics-vla-familiar

**短图注**：在MolmoAct熟悉的LIBERO-40任务中，被测LLM监督组合仍低于VLA独立运行。

**出处**：[Claude plays robotics](https://www.anthropic.com/research/claude-plays-robotics)，2026-07-09，Tools bridge some of the gap→VLA supervision，未编号原图“LIBERO-40 success with VLA supervision”。`originals/anthropic-robotics-vla-familiar.png`。

**讲解**：左为整任务成功率，右为每trial最佳进展；LIBERO40×5seeds。LLM接受/修改/替换VLA建议，覆盖率不是监督质量本身。暂停模拟器的设置与真实时间运行分开。

**课堂问题**：既然低层策略已熟悉任务，高层推理可能在哪些地方反而破坏它？

## anthropic-robotics-vla-novel

**短图注**：陌生任务另测监督价值；左轴是抓取率，右轴是最佳进展。

**出处**：[Claude plays robotics](https://www.anthropic.com/research/claude-plays-robotics)，2026-07-09，同节未编号原图“VLA-supervised performance on novel scenes”；3tasks×12seeds。`originals/anthropic-robotics-vla-novel.png`。

**讲解**：蓝柱为VLA独立运行；任务数小，原图保留置信区间。不要与familiar图的左轴成功率直接作同单位差值。更会接管与更会完成整任务是不同指标。

**课堂问题**：在VLA不熟悉的场景，什么证据才能说明接管改善了整体控制，而非只增加一次接触？

## anthropic-robotics-perception

**短图注**：相同模型的导航表现会随罗盘、第三人称图像等可见信息改变。

**出处**：[Claude plays robotics](https://www.anthropic.com/research/claude-plays-robotics)，2026-07-09，Perceptual aids change locomotion，未编号原图。`originals/anthropic-robotics-perception.png`。

**讲解**：图测相对RGB baseline的变化，不是模型预训练增益。接口/信息的提升不能归成权重学习。

**课堂问题**：罗盘解决了状态构建的哪项歧义？为何增加thinking tokens未必解决同一歧义？

## recap-fig3-training

**短图注**：价值模型将混合经验转成优势条件，条件再进入VLA的动作训练。

**出处**：[π*0.6技术报告v2](https://arxiv.org/abs/2511.14759v2)，2025-11-19，PDF4 Fig.3；精读PDF4–7。`crops/recap-fig3-training.png`。

**讲解**：区分价值训练与条件动作训练；展示web/机器人数据混合。动作头通过flow目标训练，不能将其直接画成∇aQ穿过动作头的FQL更新。

**课堂问题**：价值预测误差进入哪一个标签后，会让下一轮动作分布改变？

## veo-fig4-ranking

**短图注**：视频模拟的策略排名与真实测试相关，但绝对成功率明显偏低。

**出处**：[Evaluating Gemini Robotics Policies in a Veo World Simulator v1](https://arxiv.org/abs/2512.10675v1)，2025-12-11，PDF5 Fig.4。`crops/veo-fig4-ranking.png`。

**讲解**：8个策略变体，80种scene-instruction，8秒rollout，人类二元评分；Pearson .88、MMRV .03。两轴均成功率却明显不同尺度/范围，排名可用性和概率校准分别检验。

**课堂问题**：选最好的checkpoint与预测一天会失败几次，需要世界模型的同一种准确性吗？

## veo-fig11-hallucination

**短图注**：接触小物体时，视频模拟可能凭空生成新物体。

**出处**：[Veo机器人评价论文v1](https://arxiv.org/abs/2512.10675v1)，PDF12 Fig.11与§7。`crops/veo-fig11-hallucination.png`。

**讲解**：与前一张排名正结果成对；这是论文保留的模型失真，不能改成对策略真的发生过的硬件事故。

**课堂问题**：若策略学习器可以利用这个模拟漏洞，如何用少量真实试验辨认？

## dreamzero-fig16-failure

**短图注**：这两例中，联合视频预测失败，执行动作也沿着失败计划前进。

**出处**：[World Action Models are Zero-shot Policies v1](https://arxiv.org/abs/2602.15922v1)，2026-02-17，PDF29 Fig.16。`crops/dreamzero-fig16-failure.png`。

**讲解**：上下两组为画白板与烤可颂；每组对照Generated/Execution。观察反馈更新KV不等于所有后续控制错误消失。原文PDF8脚注2未验证只能依靠记忆成功的任务。

**课堂问题**：联合建模让视频/动作一致时，为什么一致仍可能一起错？

## 视频观察卡（5项）

| 视频 | 课堂观察问题 | 本轮阅读状态 |
|---|---|---|
| [Anthropic Building more effective AI agents](https://www.youtube.com/watch?v=uhJJgc-0iTQ)，2025-10-17 | 发言中哪些是训练模型获得的能力，哪些是runtime赋予的工具与分工？官方目录12:25 test-time compute段可作为候选，需授课人先观看。 | 已读官方说明与章节目录；未听完/无转录。 |
| [Google Introducing Gemini Robotics2](https://www.youtube.com/watch?v=-rYFDefcq3k)，2026-07-31 | 研究者讨论中的高层计划、低层动作、经验训练与evaluation分别落在哪个组件？ | 已读官方视频描述及39分钟播客条目；未听完/无转录。 |
| [Google Gemini Robotics2展示](https://www.youtube.com/watch?v=4lSQnrMC6nY)，随2026-07-30官方文发布 | 在一个动作停止或物体移动的时刻，什么外部观测进入下一次选择？哪些成功判据可以现场看见？ | 已核对官方嵌入入口及文章说明；未逐帧观看。 |
| [PI π*0.6实时演示列表](https://www.youtube.com/playlist?list=PLAhKUlcpD-aRObglQ5mRhWc9757ykD_Ae)，随2025-11-17博客发布 | 选同样一小时：怎样数成功次数、失败、接管、恢复与不可操作时间？哪个量进入吞吐分母？ | 已核对官方博客到列表链接；未看完整小时级内容。 |
| [Figure Helix02 Video1](https://www.figure.ai/news/helix-02)，2026-01-27 | 拿起物体、转身、跨步时，S2、S1和S0中哪个闭环必须仍连续工作？ | 读官方4分钟/无重置演示说明；未完整看视频。 |
