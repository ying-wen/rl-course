# 第 13 章　大语言环境下的强化学习：程序

本目录可以单独运行：在本目录下执行下面的命令即可，结果写回本目录的 `assets/`。目录由 `rl-course/tools/export_chapter_code.py` 从课程目录生成，改程序请改课程目录里的原件，再重新导出。

## 准备

```sh
python3 -m pip install -r requirements.txt
```

需要的第三方包：matplotlib、numpy。复现附录要求 Python 3.10 或更新版本；核验时用的版本见下表。

## 运行（与复现附录相同）

```sh
python3 demos/language_query_policy.py
python3 demos/ch13_r21_r4_figs.py        # 写 assets/ch13-r21
python3 demos/ch13_r21_r4_numbers.py     # 只打印
python3 demos/ch13_r21_mas.py            # 写 assets/ch13-r21-mas
python3 demos/ch13_r21_si_ledger.py      # 写 assets/ch13-r21-si
python3 demos/ch13_r21_discrete_toy.py   # 只打印
cd reader-source
python3 check_autoregressive_credit.py
python3 check_multiturn_estimators.py
python3 check_group_sampling.py
python3 credit_budget_comparison.py
python3 check_feedback_objectives.py
python3 decision_returns.py
python3 stream_revaluation.py --json stream-revaluation-results.json
python3 probe_policy_learning.py --budget exact --json probe-policy-results.json
python3 probe_event_state.py --seed 112000 --json probe-state-results.json
python3 probe_event_state.py --seed 124000 --json probe-state-validation.json
python3 probe_event_state.py --calibrate --seed 136000 --repetitions 24 --json probe-state-calibration.json
python3 probe_event_state.py --seed 112000 --use-calibration probe-state-calibration.json --json probe-state-functional-results.json
python3 probe_event_state.py --seed 124000 --use-calibration probe-state-calibration.json --json probe-state-functional-validation.json
```

附录里 `cd ../…` 指向课程目录之外的程序目录；本目录已把它复制成同名子目录，命令相应改成 `cd` 到子目录。

## 本目录的程序

| 程序 | 说明 | 核验 |
|---|---|---|
| `demos/language_query_policy.py` | A query policy learns both whether to read and how to use a reading. | 通过（0 秒） |
| `demos/ch13_r21_r4_figs.py` | 11-21 请求 r1121-122749：第 13 章 13.3 后半两张新图。 | 通过（1 秒） |
| `demos/ch13_r21_r4_numbers.py` | 11-21 请求 r1121-122749（第 13 章 13.3 后半，第 1020–1044 页）所用数字的复算。 | 通过（0 秒） |
| `demos/ch13_r21_mas.py` | 11-21 请求 r1121-122749（第 13 章 13.8 节，第 1205–1214 页及新增页）的图与数。 | 通过（1 秒） |
| `demos/ch13_r21_si_ledger.py` | Worked example for section 13.9 (self-improvement): when the | 通过（2 秒） |
| `demos/ch13_r21_discrete_toy.py` | 11-21 请求 r1121-122749：第 13.10 节新页 ch13-r21-discrete-loss 的算例（本课计算）。 | 通过（0 秒） |
| `demos/ch13_two_dists_contour.py` | Chapter 13, p1159 "同一权重，两个分布" (11-21 review request r1121-122749). | 通过（1 秒） |
| `demos/ch13_open_numbers.py` | Numbers for the added chapter 13 pages. Python standard library only. | 通过（0 秒） |

被上面程序 import 的本课模块：`demos/plot_fonts.py`。

另有课程目录之外的程序 28 个，在 `reader-source` 子目录：`analyze_credit_budget.py`、`build_feedback_tokens.py`、`check_autoregressive_credit.py`、`check_feedback_objectives.py`、`check_group_sampling.py`、`check_multiturn_estimators.py`、`credit_budget_comparison.py`、`decision_returns.py`、`draw_credit_budget_comparison.py`、`draw_credit_pairs.py`、`draw_language_decision_figures.py`、`draw_learned_event_state.py`、`draw_probe_factorial.py`、`draw_probe_policy.py`、`draw_probe_purchase.py`、`draw_probe_value_boundary.py`、`draw_reward_capability.py`、`draw_stream_revaluation.py`、`decision_returns.py`、`probe_event_state.py`、`probe_policy_learning.py`、`probe_representation_trace.py`、`stream_revaluation.py`、`probe_event_state.py`、`probe_policy_learning.py`、`probe_representation_trace.py`、`reservation_trace.py`、`stream_revaluation.py`。

表中后 2 个程序复现附录本章一节没有列出，来自课件、阅读稿、CODE-MAP 或文件名前缀（第三部分另含学习器阶梯）。

## 复现附录本章一节

本章的数字来自两处程序。demos/ 下的程序给出讲义“怎样检验”一节查询与读数利用的精确枚举，以及课件 13.3、13.8、13.9、13.10 节的四组算例：可验证奖励下 pass@k 的边界、多智能体的通信与辩论、自我改进的分布递推、离散化的决策损失。这四组都是精确计算或小规模模拟，不含模型训练。

长序列信用分配、多轮估计、组内采样与反馈目标的推导核对，以及来源反转、探测时机和探测状态的流式部署模拟，来自配套阅读稿的程序。这些程序与结果文件放在 `web/chapter-13/reading/reader-source/`（相对于课程根目录 01-完整版课程，不在 rl-course 内），表中只写路径，不加链接；运行命令里的 cd 一行进入该目录。

语言环境定义图与记忆更新图取自作者原文，Search-R1 轨迹、ProRL 曲线与 SWE-bench 的 Flask 轨迹取自公开材料，均不在表中。

| 位置 | 结果 | 设置 | 程序 | 数据与输出 |
|---|---|---|---|---|
| 课件 a-03-token-message、d1-message-score、d1-private-credit、ch13-operation-credit | 逐词元与整条消息两种分组下策略梯度的恒等式（页内例 $.4s(z_1)+.6s(z_2)$）；长度 1–12 的两个长序列例全部通过；可变长度交互树上 27 组参数三元组的梯度与有限差分的最大误差 | 本课的计算：精确枚举，无采样；交互树参数取 $\{-.8,0,.6\}^3$ | `web/chapter-13/reading/reader-source/check_autoregressive_credit.py` | 终端输出 |
| 课件 b-message-q、d2-assigned-value、d2-sample-targets、d2-prefix-is | 各组大小下原梯度、自含基线与留一基线的梯度；旧参数处整句裁剪与逐词裁剪代理的梯度（正优势上侧裁剪 $1.2$）；费用留在被跳过的观测位与归给产生费用的行动两种记账 | 本课的计算：多轮轨迹的精确枚举与记账核对，不读模型或训练日志 | `web/chapter-13/reading/reader-source/check_multiturn_estimators.py` | 终端输出 |
| 课件 b-group、d1-update-granularity | 组大小 $K$ 下、成功率 $p=.05,.50,.95$ 时组内标准化相对原成功率梯度的倍率；八条运行覆盖深处两个分支的概率 | 本课的计算：对组内通过数按二项分布取期望；执行预算算例中完成后的通过率 $(.40,.80)$ | `web/chapter-13/reading/reader-source/check_group_sampling.py` | 终端输出 |
| 课件 algo-branch-prefix、ch13-branch-allocation、b-budget | 异向任务：选中两处的局部优势 RMSE，同题 GRPO $.153$，分支法 $.077$；整策略增益由 $1.77$ 变为 $1.55$ 个百分点。同向任务对应为 $.163$、$.076$ 与 $1.17$、$.98$ | 本课的模拟：受控生成树，每条回答 48 次二元选词，候选位置 24 类中选 2 处；每法 27,648 个生成词元、576 次核验（先导 192、更新 384），组大小 8，一步更新的轨迹 KL 为 $.01$；独立重复 192 次，按种子配对 | `web/chapter-13/reading/reader-source/credit_budget_comparison.py` | `web/chapter-13/reading/reader-source/credit-budget-results.json`（`scenarios.shifted`、`scenarios.aligned`） |
| 课件 d1-chance-tilt、d1-feedback-equivalence、d1-comparison-graph | 单轮情形的共同最优 $P(\text{first})$；DPO 的前缀项抵消到第 5 个词元；8 条多轮路径；部署差距 $V-J$；环境分支 $.5$ 与倾斜后的样本概率 $\sigma(1)$ | 本课的计算：可精确枚举的教学模型 | `web/chapter-13/reading/reader-source/check_feedback_objectives.py` | 终端输出 |
| 课件 c-heldout-sources | 留出环境 B 中已学策略与等频随机策略的平均净回报 $1.474$ 与 $1.255$（高 $.219$），可靠性反转后 $1.149$ 与 $1.223$（低 $.074$）；反转时固定写入、只打乱来源，精确期望由 $1.143$ 升至 $1.270$ | 本课的模拟：策略只在来源环境训练一次后固定，等频随机策略打乱可见条件与操作的对应、保持平均频率；每策略每环境独立运行 16,000 次（函数 `evaluate`）；反转环境另做精确期望 | `web/chapter-13/reading/reader-source/decision_returns.py` | 终端输出 |
| 课件 c-source-revaluation、lang-memory-deployment-curves、d5-delayed-source-algorithm | 来源反转后按核验回执修订记忆与只做抽查的累计净回报曲线；修订减抽查的配对差 $118.12$，约 95% 区间 $[108.51,127.73]$；算法 13.8 | 本课的模拟：每条部署流 2,400 组委托，第 801 组起来源可靠性反转；抽查率 $.32$，核验标签延迟 3 组，抽查费用 $.02$，修订费用 $.25$；每 40 组绘一个均值；每种工况独立重复 96 次 | `web/chapter-13/reading/reader-source/stream_revaluation.py`；曲线页另有 `draw_stream_revaluation.py` | `web/chapter-13/reading/reader-source/stream-revaluation-results.json`（`scenarios.reversal.paired_contrasts.revise_minus_probe`） |
| 课件 c-lifetime-evidence | 等额探测下学得时机策略减固定策略的全程净回报差 $-3.38$，约 95% 区间 $[-17.67,10.91]$ | 本课的模拟：每流 2,400 组委托，第 801 组反转，每窗 12 组、两份核验，每流恰好 400 份；源策略只在独立来源环境训练；探测策略每流重新初始化，迹衰减 $.8$，步长 $.02$，种子 81200 起；独立重复 96 对 | `web/chapter-13/reading/reader-source/probe_policy_learning.py` | `web/chapter-13/reading/reader-source/probe-policy-results.json`（`scenarios.reversal.difference`） |
| 课件 d3-event-timescales、d5-event-state-algorithm、d3-factorial-control、d3-return-state、d3-return-trace | 第一批短迹学得表示：四窗均方误差由恒零预测的 $4.539$ 降至 $4.470$，两支改为均值预测后再降 $.0063$；学得减屏蔽的每流净回报差 $-.67\,[-1.98,.64]$ 等四个区间；长迹减短迹 $-9.81\,[-20.45,.83]$、$-8.63\,[-24.86,7.60]$（等参数步）与 $-.07\,[-15.24,15.09]$、$-17.72\,[-34.66,-.78]$（等概率位移）；算法 13.10 | 本课的模拟：来源反转的流式语言接口，每条部署 200 窗、每窗两份核验，共 400 份；屏蔽、冻结、学得三种历史表示 × 迹衰减 $.80$ 与 $.97$ 六组；事件频次以 $.90$、$.99$ 衰减，预测头步长 $.02$；等参数步把非零参数步归一为 $.04$，等概率位移由 24 条校准流选定长迹步长 $.062$；两批各 96 条独立流，种子 112000 与 124000，校准种子 136000 | `web/chapter-13/reading/reader-source/probe_event_state.py`；图页另有 `draw_learned_event_state.py` | 同目录 `probe-state-results.json`、`probe-state-validation.json`、`probe-state-calibration.json`、`probe-state-functional-results.json`、`probe-state-functional-validation.json`（`worlds.reversal.summary`、`worlds.reversal.contrasts`） |
| “怎样检验”一节“探索与利用读数” | 查询概率 $\sigma(a)$ 与跟随读数概率 $\sigma(b)$ 下的期望成功率 $J$ 及 $\partial J/\partial a$、$\partial J/\partial b$；五组 $(a,b,q,c_{\rm obs})$：$(0,0,.9,.1)$、$(0,2,.9,.1)$、$(-6,0,.9,.1)$、$(0,2,.5,.1)$、$(0,2,1,0)$ | 本课的计算：两把钥匙、一个有噪声传感器，枚举全部轨迹；闭式期望与有限差分核对，无采样 | `demos/language_query_policy.py` | 终端输出 |
| 13.3 节（课件 `r9-rlvr-boundary`） | 两题例：训练前通过率 .5 与 .02，训练后 .9 与 0；pass@1 由 .26 到 .45，pass@64 由 .86 到 .50；两条曲线在 $k\approx3.8$ 处相交 | 本课的计算：两道题的通过率按二项式精确计算，无训练；数值与 demos/ch13_r21_r4_numbers.py 的打印一致 | `demos/ch13_r21_r4_figs.py`；`demos/ch13_r21_r4_numbers.py` | `assets/ch13-r21/passk-curves.pdf`、`assets/ch13-r21/entropy-knobs.pdf` |
| 13.8 节（课件 `ch13-r21-plan-dp`、`ch13-r21-topology`、`ch13-r21-debate`） | 辩论：单个判断正确率 $q=.6$ 时，3 轮后判断正确的概率约 .648，9 轮 .733，12 轮 .754，另画 40 条模拟信念路径；拓扑：调和数 $H_N$ 为 1、1.5、2.28（$N=5$）、2.93（$N=10$）；规划：词元总数 16 对 12，约 1.33 倍 | 本课的计算与模拟：精确递推给出辩论曲线，信念路径为随机模拟 | `demos/ch13_r21_mas.py` | `assets/ch13-r21-mas/comm-plane.pdf`、`assets/ch13-r21-mas/debate-belief.pdf` |
| 13.9 节（课件 `ch13-r21-si-example`） | $\pi_0=(.6,.3,.1)$ 下四条曲线：金线 .706、.774、.814、.835、.846，趋于 .857；红线由 .80 起，第 10 代 .68、第 20 代 .42、第 30 代 .20；绿线一代后 .938，趋于 1；蓝线 .792（真实数据占 20%，阈值 .1） | 本课的计算：理论曲线按递推精确计算，与 3000 次模拟的平均一致 | `demos/ch13_r21_si_ledger.py` | `assets/ch13-r21-si/si-example.pdf` |
| 13.10 节（课件 `ch13-r21-discrete-loss`） | 离散化合并需要不同动作的状态时的决策价值损失；图块网格把定位量化到块中心时点中小目标的概率（附蒙特卡洛核对）；Chameleon 码率：每个码 13 比特对应 $16\times16$ 像素，原始像素为 6144 比特 | 本课的计算，无训练 | `demos/ch13_r21_discrete_toy.py` | 只在终端输出，不写文件 |

运行：

```sh
python3 demos/language_query_policy.py
python3 demos/ch13_r21_r4_figs.py        # 写 assets/ch13-r21
python3 demos/ch13_r21_r4_numbers.py     # 只打印
python3 demos/ch13_r21_mas.py            # 写 assets/ch13-r21-mas
python3 demos/ch13_r21_si_ledger.py      # 写 assets/ch13-r21-si
python3 demos/ch13_r21_discrete_toy.py   # 只打印
cd ../web/chapter-13/reading/reader-source
python3 check_autoregressive_credit.py
python3 check_multiturn_estimators.py
python3 check_group_sampling.py
python3 credit_budget_comparison.py
python3 check_feedback_objectives.py
python3 decision_returns.py
python3 stream_revaluation.py --json stream-revaluation-results.json
python3 probe_policy_learning.py --budget exact --json probe-policy-results.json
python3 probe_event_state.py --seed 112000 --json probe-state-results.json
python3 probe_event_state.py --seed 124000 --json probe-state-validation.json
python3 probe_event_state.py --calibrate --seed 136000 --repetitions 24 --json probe-state-calibration.json
python3 probe_event_state.py --seed 112000 --use-calibration probe-state-calibration.json --json probe-state-functional-results.json
python3 probe_event_state.py --seed 124000 --use-calibration probe-state-calibration.json --json probe-state-functional-validation.json
```

外部代码与公开数据（出处）：语言环境定义图与记忆更新图（温颖原文图一、图六，assets/ch13-language/lle-definition.png、memory-update.png）；Search-R1 作者公布的单次检索轨迹（assets/ch13-language/search-r1-execution.png，许可见同目录 Search-R1-LICENSE.txt）；ProRL 原图 4 的三个任务（assets/frontier-v13/crops/prorl-fig4-selected.png）；SWE-bench bash-only 排行榜公开的 Claude Opus 4.6 轨迹与评测报告，任务 pallets__flask-5014（swe-bench-submissions.s3.amazonaws.com）。

## 参考数据

`assets/`（以及 `demos/NN-results/`）下复制了 50 个数据文件（json、csv 等），即课程目前使用的结果；图片没有复制，运行程序会重新画出。重跑会覆盖这些文件，可以先另存一份再对照。
