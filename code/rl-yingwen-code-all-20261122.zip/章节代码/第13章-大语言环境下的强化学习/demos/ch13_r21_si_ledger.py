"""Worked example for section 13.9 (self-improvement): when the
generate-filter-train loop plateaus, collapses, or keeps improving.

Run from rl-course:
    python demos/ch13_r21_si_ledger.py

Writes
    assets/ch13-r21-si/si-example.pdf   (page ch13-r21-si-example)

11-21 审阅站请求 r1121-122749 之 13.9 节总评作者批注（崩塌与稳定提升的条件）。
All numbers are teaching values computed here; none come from a paper.

Model.  Each task has three kinds of answers: C correct, D wrong and
detectable by the judge, U wrong and accepted by the judge (blind spot, or an
answer crafted to pass it).  pi_0 = (.6, .3, .1).  The judge accepts kind t
with probability acc[t]; ideal write-back gives
    pi_{k+1}(t) = pi_k(t) acc[t] / sum_s pi_k(s) acc[s],
optionally mixed with a fraction lam of anchor data.

Diversity.  n samples per generation, refit by frequency (Wright-Fisher).
Gini-Simpson H = 1 - sum_i f_i^2 obeys, in expectation,
    H_{k+1} = (1 - 1/n) [ (1-lam)^2 H_k + (1 - (1-lam)^2) H_0 ],
checked against a simulation below.
"""
from pathlib import Path
import sys

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter

sys.path.insert(0, str(Path(__file__).resolve().parent))
from plot_fonts import use_course_fonts, CJK_FAMILY, no_leading_zero  # noqa: E402

TEAL = "#1f7a7a"
NAVY = "#2c5d8a"
GOLD = "#b8860b"
RED = "#b03a2e"
MUTED = "#7f8c8d"
OUT = Path(__file__).resolve().parent.parent / "assets" / "ch13-r21-si"

PI0 = np.array([.6, .3, .1])
C_ONLY = np.array([1.0, 0.0, 0.0])


def run(acc, lam=0.0, anchor=None, K=20):
    p = PI0.copy()
    out = [p[0]]
    for _ in range(K):
        q = p * acc
        q = q / q.sum()
        if lam:
            q = (1 - lam) * q + lam * anchor
        p = q
        out.append(p[0])
    return np.array(out)


def regimes(K=20):
    return {
        "A": run(np.array([1.0, .5, 1.0]), K=K),                       # self-judge, blind spot
        "B": run(np.array([.9, .3, 1.0]), K=K),                        # judge favours U
        "C": run(np.array([1.0, .1, .1]), K=K),                        # external verifier
        "D": run(np.array([.9, .3, 1.0]), lam=.2, anchor=C_ONLY, K=K), # B + 20% real data
        "E": run(np.array([.9, .3, 1.0]), lam=.2, anchor=PI0, K=K),    # B + 20% base samples
    }


def diversity(lam, K=100, n=50, H0=1.0):
    H = [H0]
    for _ in range(K):
        H.append((1 - 1 / n) * ((1 - lam) ** 2 * H[-1] + (1 - (1 - lam) ** 2) * H0))
    return np.array(H)


def check_diversity(lam, K=100, n=50, R=3000, seed=0):
    rng = np.random.default_rng(seed)
    f0 = np.array([.5, .2, .15, .1, .05])
    H0 = 1 - (f0 ** 2).sum()
    P = np.tile(f0, (R, 1))
    for _ in range(K):
        m = (1 - lam) * P + lam * f0
        P = np.stack([rng.multinomial(n, mi) for mi in m]) / n
    return (1 - (P ** 2).sum(1)).mean() / H0


def main():
    use_course_fonts()
    OUT.mkdir(parents=True, exist_ok=True)
    r = regimes()
    for k, v in r.items():
        print(k, np.round(v[:6], 3), "k10", round(v[10], 3), "k20", round(v[20], 3),
              "peak", round(v.max(), 3), "at", int(v.argmax()))
    rB30 = run(np.array([.9, .3, 1.0]), K=30)
    print("B k30", round(rB30[30], 3))
    hr, hm = diversity(0.0), diversity(.1)
    print("H/H0 replace k100", round(hr[100], 3), "mix .1 k100", round(hm[100], 3))
    print("simulated", round(check_diversity(0.0), 3), round(check_diversity(.1), 3))

    fmt = FuncFormatter(no_leading_zero)
    fig = plt.figure(figsize=(5.6, 2.15))
    ax = fig.add_axes([.105, .22, .33, .74])
    bx = fig.add_axes([.80, .22, .18, .74])
    k = np.arange(21)
    style = {
        "C": (TEAL, "-", "外部验证器"),
        "D": (NAVY, "-", "钻空子 + 两成真实数据"),
        "A": (GOLD, "-", "自评，有盲区"),
        "E": (MUTED, "--", "钻空子 + 两成基座样本"),
        "B": (RED, "-", "自评偏爱钻空子"),
    }
    ends = {"C": 1.03, "D": .95, "A": .855, "E": .71, "B": .40}
    for key, (c, ls, lab) in style.items():
        ax.plot(k, r[key], color=c, ls=ls, lw=1.8, marker="o" if ls == "-" else None,
                ms=2.6)
        ax.text(20.6, ends[key], lab, color=c, fontsize=10, va="center",
                fontfamily=CJK_FAMILY)
    ax.annotate("峰值 .80", xy=(3, r["B"][3]), xytext=(5.3, .55), color=RED,
                fontsize=10, fontfamily=CJK_FAMILY,
                arrowprops=dict(arrowstyle="-", color=RED, lw=.8))
    ax.set_xlim(0, 20)
    ax.set_ylim(.3, 1.05)
    ax.set_xticks([0, 5, 10, 15, 20])
    ax.set_yticks([.4, .6, .8, 1.0])
    ax.yaxis.set_major_formatter(fmt)
    ax.set_xlabel("代 $k$", fontsize=11, fontfamily=CJK_FAMILY)
    ax.set_ylabel("外部正确率 $p_k$", fontsize=11, fontfamily=CJK_FAMILY)

    kk = np.arange(101)
    bx.plot(kk, hr, color=RED, lw=1.8)
    bx.plot(kk, hm, color=TEAL, lw=1.8)
    bx.text(3, .03, "只用自产\n数据：.13", color=RED, fontsize=10,
            ha="left", va="bottom", fontfamily=CJK_FAMILY)
    bx.text(100, .84, "混入一成\n真实数据：.90", color=TEAL, fontsize=10,
            ha="right", va="top", fontfamily=CJK_FAMILY)
    bx.set_xlim(0, 100)
    bx.set_ylim(0, 1.05)
    bx.set_xticks([0, 50, 100])
    bx.set_yticks([0, .5, 1.0])
    bx.yaxis.set_major_formatter(fmt)
    bx.set_xlabel("代 $k$", fontsize=11, fontfamily=CJK_FAMILY)
    bx.set_ylabel("多样性 $H_k/H_0$", fontsize=11, fontfamily=CJK_FAMILY)

    for a in (ax, bx):
        a.tick_params(labelsize=10)
        for s in ("top", "right"):
            a.spines[s].set_visible(False)
    fig.savefig(OUT / "si-example.pdf")
    print("wrote", OUT / "si-example.pdf")


if __name__ == "__main__":
    main()
