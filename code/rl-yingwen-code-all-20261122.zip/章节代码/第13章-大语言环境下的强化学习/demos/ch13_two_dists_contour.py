"""Chapter 13, p1159 "同一权重，两个分布" (11-21 review request r1121-122749).

Per-token log-prob difference between inference and training engines has
std sigma; with L independent tokens the sequence log-ratio has std
sigma*sqrt(L), so the ratio at +1 std is exp(sigma*sqrt(L)).
Draws the level lines exp(sigma*sqrt(L)) = 1.1, 1.5, 2 in the (L, sigma)
plane (log-log axes) and marks the six settings of the old table.

Run:  python3 demos/ch13_two_dists_contour.py
Output: assets/ch13-r21/two-dists-contour.pdf
"""
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter
from plot_fonts import use_course_fonts, CJK_FAMILY, no_leading_zero

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'assets' / 'ch13-r21'


def main():
    use_course_fonts()
    OUT.mkdir(parents=True, exist_ok=True)
    fig, ax = plt.subplots(figsize=(3.0, 2.15))
    ax.set_xscale('log'); ax.set_yscale('log')
    ax.set_xlim(100, 2e4); ax.set_ylim(5e-4, 8e-2)
    L = np.logspace(2, 4.3, 200)
    labels = []
    levels = [(1.1, '#1f7a7a'), (1.5, '#b8860b'), (2.0, '#b03a2e')]
    for k, col in levels:
        sig = np.log(k) / np.sqrt(L)
        ax.plot(L, sig, color=col, lw=1.4)
        labels.append((k, col))
    pts = []
    for s in (.001, .003, .01):
        for n in (1000, 8000):
            v = np.exp(s * np.sqrt(n))
            pts.append((n, s, v))
            ax.plot(n, s, 'o', ms=3.5, color='#b03a2e' if v > 2 else '#333333')
            ax.annotate(f'{v:.2f}', (n, s), textcoords='offset points', xytext=(4, -2),
                        fontsize=6.5, color='#555555')
    ax.set_xlabel('回答长度 $L$（词元）', fontfamily=CJK_FAMILY, fontsize=8)
    ax.set_ylabel('逐词元差的标准差 $\\sigma$', fontfamily=CJK_FAMILY, fontsize=8)
    ax.yaxis.set_major_formatter(FuncFormatter(no_leading_zero))
    ax.tick_params(labelsize=7)
    for sp in ('top', 'right'):
        ax.spines[sp].set_visible(False)
    fig.tight_layout(pad=.3)
    # Label each level line along its slope, measured in display coordinates.
    x0, x1 = 150.0, 300.0
    for k, col in labels:
        p0 = ax.transData.transform((x0, np.log(k) / np.sqrt(x0)))
        p1 = ax.transData.transform((x1, np.log(k) / np.sqrt(x1)))
        ang = np.degrees(np.arctan2(p1[1] - p0[1], p1[0] - p0[0]))
        ax.text(x0, np.log(k) / np.sqrt(x0) * 1.12, f'$e^{{\\sigma\\sqrt{{L}}}}={k:g}$',
                color=col, fontsize=7, rotation=ang, rotation_mode='anchor',
                ha='left', va='bottom')
    fig.savefig(OUT / 'two-dists-contour.pdf')
    for n, s, v in pts:
        print(n, s, round(v, 3), round(np.exp(-s * np.sqrt(n)), 3))


if __name__ == '__main__':
    main()
