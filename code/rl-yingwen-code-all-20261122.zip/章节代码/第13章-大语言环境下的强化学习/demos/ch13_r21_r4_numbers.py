"""11-21 请求 r1121-122749（第 13 章 13.3 后半，第 1020–1044 页）所用数字的复算。

运行：python3 demos/ch13_r21_r4_numbers.py
每一节对应一页，打印页上引用的数。
"""
import math


def sig(x):
    return 1.0 / (1.0 + math.exp(-x))


def keep_prob(p, G):
    return 1 - p ** G - (1 - p) ** G


print('— 组内筛选（course-group-selection）')
print('  G=4, p=.5: s =', keep_prob(.5, 4))
for p in (.001, .01):
    print(f'  G=16, p={p}: s = {keep_prob(p, 16):.5f}, 近似 Gp = {16 * p:.4f}')

print('— 除以标准差（r9-group-std-objective / ch13-sec3-summary）')
for p in (.5, .1, .05, .01):
    print(f'  p={p}: 1/sqrt(p(1-p)) = {1 / math.sqrt(p * (1 - p)):.3f}')

print('— 三种裁剪的系数（d1-update-granularity），正优势，系数 = d/dlog p 的乘子')
r = [1.5, .7, 1.1]
W = r[0] * r[1] * r[2]
print(f'  W = {W:.4f}, s = W^(1/3) = {W ** (1 / 3):.4f}')
grpo = [0 if x > 1.2 else x for x in r]
cispo = [min(x, 1.2) for x in r]
print('  GRPO', grpo, ' CISPO', cispo)
for tau in (1, 5):
    coef = [x * 4 * sig(tau * (x - 1)) * (1 - sig(tau * (x - 1))) for x in r]
    print(f'  SAPO tau={tau}:', [round(c, 4) for c in coef])
# 一个离群词元拖动整句：把第 3 词比率改成 3
r_out = [1.0, 1.0, 3.0]
s_out = (r_out[0] * r_out[1] * r_out[2]) ** (1 / 3)
print(f'  离群：r=(1,1,3) 时 s = {s_out:.3f}，越过 1.2，整句三个词同时失去梯度')

print('— SAPO 平滑门（c13v5-lang-sapo），系数 r f\'(r)，f\'(r)=4σ(τ(r-1))(1-σ(τ(r-1)))')
for tau in (1, 5):
    for x in (.8, 1.2, 1.5, 2.0):
        c = x * 4 * sig(tau * (x - 1)) * (1 - sig(tau * (x - 1)))
        print(f'  tau={tau}, r={x}: {c:.3f}')

print('— 熵的一步变化（ch13-entropy-budget / ch13-entropy-knobs）')
pi = [.70, .20, .08, .02]
H = -sum(p * math.log(p) for p in pi)
print(f'  H0 = {H:.4f}')
for name, A in (('强化 a1', [.3, -.7, -.7, -.7]), ('强化 a3', [-.08, -.08, .92, -.08])):
    dz = [p * a for p, a in zip(pi, A)]
    m = sum(p * d for p, d in zip(pi, dz))
    dlog = [d - m for d in dz]  # softmax 对平移不变：居中后 Δz_a ≈ Δlog π_a
    contrib = [p * (math.log(p) + H) * d for p, d in zip(pi, dlog)]
    cov = sum(contrib)
    z = [math.log(p) + d for p, d in zip(pi, dz)]
    Z = sum(math.exp(v) for v in z)
    new = [math.exp(v) / Z for v in z]
    H1 = -sum(p * math.log(p) for p in new)
    print(f'  {name}: 居中 Δz = {[round(d, 3) for d in dlog]}, 各词贡献 {[round(c, 4) for c in contrib]},'
          f' Cov = {cov:.4f}, 实际 ΔH = {H1 - H:.4f}, 新 π = {[round(p, 3) for p in new]}')
print(f'  log 1.2 = {math.log(1.2):.3f}, log .8 = {math.log(.8):.3f}, log 1.28 = {math.log(1.28):.3f}')
print(f'  .08 × 1.2 = {.08 * 1.2:.3f}, .08 × 1.28 = {.08 * 1.28:.4f}')

print('— pass@k（r9-rlvr-boundary）')
before, after = (.5, .02), (.9, 0.0)
for k in (1, 2, 4, 8, 64):
    pb = sum(1 - (1 - p) ** k for p in before) / 2
    pa = sum(1 - (1 - p) ** k for p in after) / 2
    print(f'  k={k}: 训练前 {pb:.3f}, 训练后 {pa:.3f}')
# 交点：在实数 k 上二分
lo, hi = 1.0, 64.0
f = lambda k: sum(1 - (1 - p) ** k for p in before) / 2 - sum(1 - (1 - p) ** k for p in after) / 2
for _ in range(60):
    mid = (lo + hi) / 2
    if f(mid) < 0:
        lo = mid
    else:
        hi = mid
print(f'  交点 k ≈ {lo:.2f}；1-.98^64 = {1 - .98 ** 64:.3f}')

print('— 抽查的残差校正（d1-audited-gradient）')
S, Z, a = .5, 1, .2
print('  抽中值', S + (Z - S) / a, ' 期望', (1 - a) * S + a * (S + (Z - S) / a))
print('  额外方差因子 (1/a-1)(Z-S)^2 =', (1 / a - 1) * (Z - S) ** 2)

print('— 信息量（ch13-sec3-open）')
for p in (.5, .1, .05, .01):
    h = -(p * math.log2(p) + (1 - p) * math.log2(1 - p))
    print(f'  h({p}) = {h:.3f}')
