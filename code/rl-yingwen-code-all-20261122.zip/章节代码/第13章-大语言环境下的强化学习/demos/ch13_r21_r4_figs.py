"""11-21 请求 r1121-122749：第 13 章 13.3 后半两张新图。

  assets/ch13-r21/passk-curves.pdf    可验证奖励的边界：两题算例的 pass@k
  assets/ch13-r21/entropy-knobs.pdf   调熵的旋钮：log π_a 与一步 Δlog π_a

运行：python3 demos/ch13_r21_r4_figs.py
数字与 demos/ch13_r21_r4_numbers.py 一致。
"""
import math
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter

from plot_fonts import use_course_fonts, no_leading_zero, CJK_FAMILY

TEAL, RED, GOLD, MUTED, INK = '#096B76', '#AA412D', '#A27618', '#52666E', '#182E38'
OUT = Path(__file__).resolve().parent.parent / 'assets' / 'ch13-r21'


def style(ax):
    for side in ('top', 'right'):
        ax.spines[side].set_visible(False)
    for side in ('left', 'bottom'):
        ax.spines[side].set_color(MUTED)
    ax.tick_params(colors=INK, labelsize=9.5, length=3)


def passk():
    before, after = (.5, .02), (.9, 0.0)
    ks = [2 ** (i / 20) for i in range(0, 121)]  # 1 … 64
    f = lambda ps, k: sum(1 - (1 - p) ** k for p in ps) / len(ps)
    fig, ax = plt.subplots(figsize=(3.3, 2.25))
    ax.plot(ks, [f(before, k) for k in ks], color=MUTED, lw=1.8, label='训练前')
    ax.plot(ks, [f(after, k) for k in ks], color=TEAL, lw=1.8, label='训练后')
    ax.set_xscale('log', base=2)
    ax.set_xticks([1, 2, 4, 8, 16, 32, 64])
    ax.set_xticklabels(['1', '2', '4', '8', '16', '32', '64'])
    ax.set_ylim(.15, .92)
    ax.set_yticks([.3, .5, .7, .9])
    ax.yaxis.set_major_formatter(FuncFormatter(no_leading_zero))
    ax.set_xlabel('采样次数 $k$', fontsize=10.5, fontfamily=CJK_FAMILY)
    ax.set_ylabel('平均 pass@$k$', fontsize=10.5, fontfamily=CJK_FAMILY)
    for k in (1, 64):
        for ps, c in ((before, MUTED), (after, TEAL)):
            ax.plot([k], [f(ps, k)], 'o', color=c, ms=4)
    ax.annotate('.26', (1, .26), xytext=(5, -12), textcoords='offset points', fontsize=9.5, color=MUTED)
    ax.annotate('.45', (1, .45), xytext=(5, -13), textcoords='offset points', fontsize=9.5, color=TEAL)
    ax.annotate('.86', (64, .863), xytext=(-20, 4), textcoords='offset points', fontsize=9.5, color=MUTED)
    ax.annotate('.50', (64, .50), xytext=(-20, -12), textcoords='offset points', fontsize=9.5, color=TEAL)
    ax.axvline(3.77, color=GOLD, lw=1, ls='--')
    ax.text(3.6, .88, '交点 $k\\approx3.8$', fontsize=9.5, color=GOLD, ha='right', fontfamily=CJK_FAMILY)
    ax.legend(loc='lower right', fontsize=9.5, frameon=False)
    ax.text(1.05, .74, '单次准确率升高', fontsize=9, color=INK)
    ax.text(62, .62, '覆盖缩小', fontsize=9, color=INK, ha='right')
    style(ax)
    fig.tight_layout(pad=.3)
    fig.savefig(OUT / 'passk-curves.pdf')
    plt.close(fig)


def entropy_knobs():
    pi = [.70, .20, .08, .02]
    H = -sum(p * math.log(p) for p in pi)
    logp = [math.log(p) for p in pi]

    def centred(dz):
        m = sum(p * d for p, d in zip(pi, dz))
        return [d - m for d in dz]

    cases = (('强化 $a_1$', [.3, -.7, -.7, -.7], RED, 'o'),
             ('强化 $a_3$', [-.08, -.08, .92, -.08], TEAL, 's'))
    fig, ax = plt.subplots(figsize=(3.4, 2.5))
    ax.axhspan(math.log(.8), math.log(1.2), color='#EAF4F3', zorder=0)
    ax.axhline(math.log(1.2), color=TEAL, lw=.8)
    ax.axhline(math.log(.8), color=TEAL, lw=.8)
    ax.axhline(math.log(1.28), color=GOLD, lw=1, ls='--')
    ax.axhline(0, color=MUTED, lw=.6)
    ax.text(-4.25, math.log(1.2) + .012, '$\\log1.2$', fontsize=9, color=TEAL)
    ax.text(-4.25, math.log(.8) - .045, '$\\log.8$', fontsize=9, color=TEAL)
    ax.text(-2.3, math.log(1.28) + .012, '上界 $1.28$', fontsize=9, color=GOLD, fontfamily=CJK_FAMILY)
    for name, A, c, mk in cases:
        dz = centred([p * a for p, a in zip(pi, A)])
        ax.plot(logp, dz, mk, color=c, ms=5, label=name, zorder=3)
        if mk == 'o':
            contrib = [p * (lp + H) * d for p, lp, d in zip(pi, logp, dz)]
            j = max(range(4), key=lambda i: contrib[i])
            ax.plot([logp[j]], [dz[j]], 'x', color=INK, ms=10, mew=1.6, zorder=4)
            ax.annotate('Clip-Cov 截此词', (logp[j], dz[j]), xytext=(8, -4),
                        textcoords='offset points', fontsize=9, color=INK)
    # 熵奖励 α ∂H/∂z_a，换成 Δlog π_a：减去 Σ_b π_b ∂H/∂z_b
    alpha = .3
    c0 = -sum(p * p * (math.log(p) + H) for p in pi)
    xs = [-4.2 + i * .02 for i in range(201)]
    ax.plot(xs, [alpha * (-math.exp(x) * (x + H) - c0) for x in xs], color=MUTED, lw=1.3, ls='-.')
    ax.text(-3.95, .135, '熵奖励 $\\alpha=.3$', fontsize=9, color=MUTED, fontfamily=CJK_FAMILY)
    ax.set_xlim(-4.3, 0)
    ax.set_ylim(-.30, .30)
    ax.set_xticks([-4, -3, -2, -1, 0])
    ax.set_yticks([-.2, -.1, 0, .1, .2])
    ax.yaxis.set_major_formatter(FuncFormatter(no_leading_zero))
    ax.set_xlabel('$\\log\\pi_a$（左罕见，右常见）', fontsize=10.5, fontfamily=CJK_FAMILY)
    ax.set_ylabel('一步的 $\\Delta\\log\\pi_a$', fontsize=10.5, fontfamily=CJK_FAMILY)
    leg = ax.legend(loc='lower center', bbox_to_anchor=(.5, 1.0), ncol=2, fontsize=9.5, frameon=False,
                    handletextpad=.2, borderaxespad=.1)
    for t in leg.get_texts():
        t.set_fontfamily(CJK_FAMILY)
    style(ax)
    fig.tight_layout(pad=.3)
    fig.savefig(OUT / 'entropy-knobs.pdf')
    plt.close(fig)


if __name__ == '__main__':
    OUT.mkdir(parents=True, exist_ok=True)
    print('fonts ok:', use_course_fonts())
    passk()
    entropy_knobs()
    print('wrote', OUT)
