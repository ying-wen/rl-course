"""11-21 请求 r1121-122749（第 13 章 13.8 节，第 1205–1214 页及新增页）的图与数。

运行：python3 demos/ch13_r21_mas.py
输出：assets/ch13-r21-mas/comm-plane.pdf（通信页 L–rho 平面）
      assets/ch13-r21-mas/debate-belief.pdf（辩论页：信念是鞅，正确率仍可升）
并打印各页引用的数。
"""
import math
import os
import sys

import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter

sys.path.insert(0, os.path.dirname(__file__))
from plot_fonts import use_course_fonts, no_leading_zero, CJK_FAMILY  # noqa: E402

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, 'assets', 'ch13-r21-mas')
os.makedirs(OUT, exist_ok=True)
TEAL, RED, MUTED, INK = '#00737A', '#B23A3A', '#7A7A7A', '#1F2A30'


def n_eff(n, rho):
    return n / (1 + (n - 1) * rho)


print('— 为什么要拆（ch13-8-why-split）')
print(f'  N=5, rho=.5: N_eff = {n_eff(5, .5):.4f}; 1/rho = {1 / .5:.1f}')
print(f'  N=5, rho=.2: N_eff = {n_eff(5, .2):.4f}')

print('— 三笔代价（ch13-8-costs）')
print(f'  3^(1-4) = {3 ** -3:.4f}')
print(f'  .95^10 = {.95 ** 10:.4f};  每步残留 .05*(1-.8) = {.05 * .2:.3f};  .99^10 = {.99 ** 10:.4f}')

print('— 团队信用（ch13-8-credit）：协作当且仅当 q(R_syn-R_col) >= R_ind-R_col')
R_syn, R_col, R_ind = 4, 0, 1
print(f'  R_syn={R_syn}, R_col={R_col}, R_ind={R_ind}: q >= {(R_ind - R_col) / (R_syn - R_col):.2f}')

print('— 编排是规划（ch13-r21-plan-dp）：T(x) = min{w(x), w0 + max_j T(x_j) + wm}, w0 = wm = 1')


def T(w, splits):
    """w: 子任务工作量; splits: 该任务可拆成的子任务（dict 名字 -> (w, splits)）"""
    direct = w
    if not splits:
        return direct, '自己做'
    sub = [T(sw, ss)[0] for sw, ss in splits]
    via = 1 + max(sub) + 1
    return (via, '拆') if via < direct else (direct, '自己做')


leaf3 = (3, [(1.5, []), (1.5, [])])
six = (6, [leaf3, leaf3])
four = (4, [(2, []), (2, [])])
task = (12, [six, four, (2, [])])
print('  T(3 -> 1.5,1.5) =', T(*leaf3))
print('  T(6 -> 3,3) =', T(*six))
print('  T(4 -> 2,2) =', T(*four), '（打平，不拆）')
print('  T(12 -> 6,4,2) =', T(*task))


def C_plan(w, splits):
    """按时延最优的方案执行时花的词元：拆就加 w0+wm 并对子任务求和"""
    if not splits or T(w, splits)[1] == '自己做':
        return w
    return 1 + sum(C_plan(sw, ss) for sw, ss in splits) + 1


print('  时延最优方案的词元 =', C_plan(*task), '; 比值', round(C_plan(*task) / 12, 3), '; 时延加速', round(12 / T(*task)[0], 3))
print('  拆分划算 iff w0+wm < w - max_j w_j: 12:', 2 < 12 - 6, ' 6:', 2 < 6 - 3, ' 3:', 2 < 3 - 1.5)

print('— 拓扑与时序（ch13-r21-topology）：N 个子任务耗时 iid 指数(均值 1)，同步屏障一轮 E[max] = H_N')
for n in (1, 2, 5, 10):
    print(f'  N={n}: H_N = {sum(1 / k for k in range(1, n + 1)):.4f}')

print('— 通信（ch13-8-comm）：每条消息占窗口 l=b/L，合并者装 N=1/l 条，N_eff = 1/(l+(1-l)rho)')
for l, r in ((.1, 0), (.1, .5), (.5, .5), (.1, .3), (.2, .4)):
    print(f'  l={l}, rho={r}: N_eff = {1 / (l + (1 - l) * r):.3f}')

# ---------- 图 1：L–rho 平面 ----------
use_course_fonts()
fig, ax = plt.subplots(figsize=(4.2, 3.0))
ls = np.linspace(.01, .6, 400)
for ne, lab_x in ((1.5, .45), (2, .30), (3, .2), (5, .12)):
    rho = (1 / ne - ls) / (1 - ls)
    m = (rho >= 0) & (rho <= 1)
    ax.plot(ls[m], rho[m], color=TEAL, lw=1.0, alpha=.35 + .13 * ne / 5 * 2)
    yy = (1 / ne - lab_x) / (1 - lab_x)
    ax.text(lab_x, yy + .015, f'$N_{{\\rm eff}}={ne:g}$', color=TEAL, fontsize=8,
            ha='left', va='bottom')
pts = [  # (l, rho, 名字, 对齐) 位置为示意：按各方法的机制定性放置
    (.50, .72, '完整轨迹', 'right'),
    (.20, .42, '发布订阅', 'left'),
    (.10, .30, '压缩回报', 'left'),
    (.035, .22, '任务优化消息', 'left'),
    (.02, .62, '隐状态', 'left'),
    (.28, .60, '共享记忆', 'left'),
]
for l, r, name, ha in pts:
    ax.plot(l, r, 'o', color=RED, ms=4)
    dx = -.012 if ha == 'right' else .012
    ax.text(l + dx, r, name, fontsize=8, ha=ha, va='center', color=INK, fontfamily=CJK_FAMILY)
ax.set_xlim(0, .6)
ax.set_ylim(0, 1)
ax.set_xlabel('每条消息占接收者窗口的比例 $\\ell=b/L$', fontsize=8, fontfamily=CJK_FAMILY)
ax.set_ylabel('成员错误相关 $\\rho$', fontsize=8, fontfamily=CJK_FAMILY)
ax.xaxis.set_major_formatter(FuncFormatter(no_leading_zero))
ax.yaxis.set_major_formatter(FuncFormatter(no_leading_zero))
ax.tick_params(labelsize=7)
for s in ('top', 'right'):
    ax.spines[s].set_visible(False)
fig.tight_layout(pad=.3)
fig.savefig(os.path.join(OUT, 'comm-plane.pdf'))
plt.close(fig)

# ---------- 图 2：辩论的信念 ----------
q = .6           # 每轮论证给出的证据指向真答案的概率
lr = q / (1 - q)  # 似然比
rng = np.random.default_rng(0)
T_ROUNDS = 12
paths = []
for _ in range(40):
    truth = rng.random() < .5          # 先验 .5
    logit = 0.0
    b = [.5]
    for _t in range(T_ROUNDS):
        sig_ok = rng.random() < q
        towards_A = sig_ok if truth else not sig_ok
        logit += math.log(lr) if towards_A else -math.log(lr)
        b.append(1 / (1 + math.exp(-logit)))
    paths.append(b)
paths = np.array(paths)


def acc(t, qq):
    """t 轮证据后贝叶斯裁判判对的概率（平局随机）。"""
    if qq == .5:
        return .5
    tot = 0.0
    for k in range(t + 1):
        p = math.comb(t, k) * qq ** k * (1 - qq) ** (t - k)
        if 2 * k > t:
            tot += p
        elif 2 * k == t:
            tot += .5 * p
    return tot


print('— 辩论（ch13-r21-debate）：q=.6 时 t 轮后判对概率')
for t in (0, 1, 3, 5, 9, 12):
    print(f'  t={t}: {acc(t, q):.4f}')
print('  E[b_t] 精确值恒为 .5（鞅）；40 条模拟路径末轮均值 =', round(float(paths[:, -1].mean()), 3))

fig, axs = plt.subplots(1, 2, figsize=(5.4, 2.3))
ax = axs[0]
for b in paths:
    ax.plot(range(T_ROUNDS + 1), b, color=MUTED, lw=.6, alpha=.45)
ax.axhline(.5, color=RED, lw=1.2)
ax.text(T_ROUNDS, .53, '均值 $\\mathbb{E}\\,b_t$ 恒为 .5', color=RED, fontsize=8, ha='right', va='bottom',
        fontfamily=CJK_FAMILY)
ax.set_xlabel('辩论轮数 $t$', fontsize=8, fontfamily=CJK_FAMILY)
ax.set_ylabel('裁判信念 $b_t$', fontsize=8, fontfamily=CJK_FAMILY)
ax.set_ylim(0, 1)
ax2 = axs[1]
ts = list(range(T_ROUNDS + 1))
ax2.plot(ts, [acc(t, q) for t in ts], color=TEAL, lw=1.4, marker='o', ms=2.5)
ax2.plot(ts, [.5] * len(ts), color=MUTED, lw=1.2, ls='--')
ax2.text(T_ROUNDS, .63, '论证带证据 $q=.6$', color=TEAL, fontsize=8, ha='right',
         va='top', fontfamily=CJK_FAMILY)
ax2.text(T_ROUNDS, .52, '只交换结论 $q=.5$', color=MUTED, fontsize=8, ha='right', va='bottom',
         fontfamily=CJK_FAMILY)
ax2.set_xlabel('辩论轮数 $t$', fontsize=8, fontfamily=CJK_FAMILY)
ax2.set_ylabel('判对的概率', fontsize=8, fontfamily=CJK_FAMILY)
ax2.set_ylim(.45, .85)
for a in axs:
    a.xaxis.set_major_formatter(FuncFormatter(no_leading_zero))
    a.yaxis.set_major_formatter(FuncFormatter(no_leading_zero))
    a.tick_params(labelsize=7)
    for s in ('top', 'right'):
        a.spines[s].set_visible(False)
fig.tight_layout(pad=.3, w_pad=1.2)
fig.savefig(os.path.join(OUT, 'debate-belief.pdf'))
plt.close(fig)
print('图已写入', OUT)
