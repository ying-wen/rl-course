"""A query policy learns both whether to read and how to use a reading.

Run: python3 language_query_policy.py
q: probability that a calibrated reader reports the correct lock type.
k: price of one reading. Both lock types have prior probability 1/2.
At the first decision, query with probability p. Otherwise submit key A.
After a query, follow the reading with probability f; otherwise reverse it.
"""
from math import exp, isclose


def sigmoid(x):
    return 1 / (1 + exp(-x))


def enumerate_returns(a, b, q=.9, k=.1):
    """Sum over both lock types, both readings, and both agent decisions.

    a and b are the query and follow logits. Return J and its gradient.
    For a Bernoulli action x, d log pi(x)/d logit = x - pi(1).
    The sensor probability weights the trajectory; it has no policy score.
    """
    p, f = sigmoid(a), sigmoid(b)
    J = grad_a = grad_b = 0.0
    for lock in (0, 1):  # lock=0 is opened by key A
        reward = float(lock == 0)
        weight = .5 * (1 - p)
        J += weight * reward
        grad_a += weight * reward * (0 - p)
        for reading in (0, 1):
            sensor = q if reading == lock else 1 - q
            for follow in (0, 1):
                key = reading if follow else 1 - reading
                reward = float(key == lock) - k
                weight = .5 * p * sensor * (f if follow else 1 - f)
                J += weight * reward
                grad_a += weight * reward * (1 - p)
                grad_b += weight * reward * (follow - f)
    return J, grad_a, grad_b


def analytic(a, b, q, k):
    p, f = sigmoid(a), sigmoid(b)
    gain = (2 * q - 1) * (f - .5) - k
    return .5 + p * gain, p * (1 - p) * gain, p * (2 * q - 1) * f * (1 - f)


if __name__ == "__main__":
    print("q      cost    P(read)   P(follow)    J        dJ/da      dJ/db")
    for a, b, q, k in [(0, 0, .9, .1), (0, 2, .9, .1),
                        (-6, 0, .9, .1), (0, 2, .5, .1), (0, 2, 1., 0.)]:
        values = enumerate_returns(a, b, q, k)
        assert all(isclose(x, y, abs_tol=1e-12) for x, y in zip(values, analytic(a, b, q, k)))
        eps = 1e-5
        for i, (da, db) in enumerate([(eps, 0), (0, eps)], 1):
            hi = enumerate_returns(a + da, b + db, q, k)[0]
            lo = enumerate_returns(a - da, b - db, q, k)[0]
            assert isclose(values[i], (hi - lo) / (2 * eps), abs_tol=1e-9)
        print(f"{q:.2f}   {k:.2f}    {sigmoid(a):.4f}    {sigmoid(b):.4f}      "
              f"{values[0]:.4f}   {values[1]:+.5f}   {values[2]:+.5f}")
