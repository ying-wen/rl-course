"""11-21 请求 r1121-122749：第 13.10 节新页 ch13-r21-discrete-loss 的算例（本课计算）。
1) 离散化合并了需要不同动作的状态时的决策价值损失；
2) 图块网格把定位量化到块中心时，点中小目标的概率；
3) Chameleon 码率换算（512^2 RGB，1024 个码，码本 8192）。"""
import math, random

# 1) 两个隐藏状态：截图角落有报错（概率 p）/ 没有。动作：修 CSS 加载 / 改按钮样式。
p = .3
Q = {('err', 'fix_css'): 1, ('err', 'restyle'): 0, ('ok', 'fix_css'): 0, ('ok', 'restyle'): 1}
P = {'err': p, 'ok': 1 - p}
v_full = sum(P[s] * max(Q[(s, a)] for a in ('fix_css', 'restyle')) for s in P)
v_merged = max(sum(P[s] * Q[(s, a)] for s in P) for a in ('fix_css', 'restyle'))
H = -p * math.log2(p) - (1 - p) * math.log2(1 - p)
print(f'value full={v_full:.3f} merged={v_merged:.3f} loss={v_full - v_merged:.3f}  I(s;x)={H:.3f} bit, I(s;q)=0')

# 2) 定位只到 28x28 图块中心；目标中心在块内均匀分布。
patch = 28
for w in (16, 24, 32):
    per_axis = min(1.0, w / patch)
    exact = per_axis ** 2
    random.seed(0)
    n = 200000
    hit = sum(abs(random.uniform(-patch / 2, patch / 2)) <= w / 2 and abs(random.uniform(-patch / 2, patch / 2)) <= w / 2 for _ in range(n)) / n
    print(f'target {w}px: hit exact={exact:.3f} mc={hit:.3f}; max offset per axis={patch/2:.0f}px, diag={math.hypot(patch/2, patch/2):.1f}px')

# 3) 码率
raw = 512 * 512 * 24
code = 1024 * math.log2(8192)
print(f'raw={raw/1e6:.2f} Mbit, codes={code:.0f} bit, ratio={raw/code:.0f}, bit/pixel={code/(512*512):.3f}')
print('pixels per code =', 512 * 512 // 1024, '(16x16), raw bits per code =', 256 * 24)
