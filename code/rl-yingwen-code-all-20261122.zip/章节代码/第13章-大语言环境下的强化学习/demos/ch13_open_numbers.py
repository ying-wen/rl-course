"""Numbers for the added chapter 13 pages. Python standard library only.

Every number printed here appears on a page in new-slides/ch13-open2/.
Run:  python3 ch13_open_numbers.py
"""
from math import exp, log, sqrt


def section(title):
    print('\n== ' + title)


# ---------------------------------------------------------------- 13.1 autoregression
def error_accumulation():
    section('13.1  all-correct probability (1-eps)^T')
    for eps in (1e-2, 1e-3, 1e-4):
        row = ', '.join(f'T={T}: {(1 - eps) ** T:.3f}' for T in (100, 500, 1000, 2000, 5000))
        print(f'  eps={eps:g}: {row}')
    print(f'  check eps=1e-3, T=2000 -> {(1 - 1e-3) ** 2000:.4f}  (about .135)')


# ---------------------------------------------------------------- 13.2 prior and coverage
def coverage():
    section('13.2  seen at least once in N samples: 1-(1-u0)^N')
    for u0 in (1e-2, 1e-3, 1e-4):
        row = ', '.join(f'N={N}: {1 - (1 - u0) ** N:.4f}' for N in (16, 256, 4096))
        print(f'  u0={u0:g}: {row}')
    print('  N needed for 50% at u0=1e-4:', round(log(.5) / log(1 - 1e-4)))


def path_credit():
    section('13.2  composing steps: whole-path vs per-step signal')
    p = .3
    for k in (2, 3, 5):
        whole = p ** k
        print(f'  {k} steps of {p}: path prob {whole:.5f}; '
              f'P(at least one success in 16) = {1 - (1 - whole) ** 16:.3f}')
    # per-step credit: push step 1 to .9, the path rises from .09 to .27
    print(f'  after step 1 is pushed to .9: path {0.9 * 0.3:.2f}; both to .9: {0.9 * 0.9:.2f}')


# ---------------------------------------------------------------- 13.4 roles: replicator and optimizer
def replicator():
    section('13.4  replicator dynamics for behaviour X')
    r_x, r_not = .6, .3
    dr = r_x - r_not
    for pi in (.05, .5, .95):
        print(f'  pi={pi}: d(logit diff)/step = 2 pi (1-pi) dR = {2 * pi * (1 - pi) * dr:.4f} eta')
    lo, hi = log(.05 / .95), log(.95 / .05)
    # SGD: dl/dt = 2 s(1-s) dR eta  =>  t = int dl / (2 s(1-s) dR) ; 1/(s(1-s)) = 2 + e^l + e^-l
    integral = (2 * hi + exp(hi) - exp(-hi)) - (2 * lo + exp(lo) - exp(-lo))
    print(f'  logit gap to cover: {hi - lo:.2f}')
    print(f'  plain gradient: about {integral / (2 * dr):.0f}/eta steps from 5% to 95%')
    # sign-like update (Adam at steady state): each of the two logits moves eta per step
    print(f'  sign-like update: logit gap moves 2 eta per step -> about {(hi - lo) / 2:.1f}/eta steps')


def optimizer_coupling():
    section('13.4  coupling through the optimizer (gradients from ch13six-role-coupling)')
    gi, gj, a = (1., .5), (.6, -.2), .1
    sgd = a * sum(x * y for x, y in zip(gi, gj))
    sign = a * sum((1 if x > 0 else -1) * y for x, y in zip(gi, gj))
    print(f'  SGD   : delta f_j = {sgd:.3f}')
    print(f'  sign  : delta f_j = {sign:.3f}')
    gj2 = (.6, -.8)
    sgd2 = a * sum(x * y for x, y in zip(gi, gj2))
    sign2 = a * sum((1 if x > 0 else -1) * y for x, y in zip(gi, gj2))
    print(f'  if grad f_j = (.6,-.8): SGD {sgd2:.3f}, sign {sign2:.3f}  (sign flips)')
    drift, T = 1e-4, 8000
    print(f'  per-token log-ratio drift {drift:g} over {T} tokens: ratio e^{drift * T:.1f} = {exp(drift * T):.2f}')


# ---------------------------------------------------------------- how to test
def error_bars():
    section('how to test: 95% half-width at accuracy 50%')
    for n in (30, 100, 500, 2000):
        print(f'  n={n}: +-{100 * 1.96 * sqrt(.25 / n):.1f} points')


def main():
    error_accumulation()
    coverage()
    path_credit()
    replicator()
    optimizer_coupling()
    error_bars()


if __name__ == '__main__':
    main()
