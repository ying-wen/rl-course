"""Draw role-aware token comparisons from the frozen tokenizer output. No network or JS library."""
import json
from pathlib import Path
from html import escape
here=Path(__file__).resolve().parent
data=json.loads((here/'ordinary-token-spans.json').read_text())
messages=data['messages']
pairs=[
 ('rlhf','RLHF','偏好 → 奖励模型','另取同一起点的候选回答及人的排序，先拟合奖励模型。','行为策略与环境共同生成新轨迹；在最后一次作答后，由固定奖励模型评分。','本条轨迹的生成位置乘估计优势；外部返回不取策略得分。'),
 ('dpo','DPO','成对偏好 → 概率比','固定含工具返回的同一上下文。离线采集者提供两份完整续写，人或指定评审给甲、乙排序。','标注者读完两份回答才给出甲胜乙；训练者重算两份回答在当前策略和固定参考策略下的概率。','共同前缀逐项相消；只比较分叉后的两条条件概率路径。'),
 ('rlvr','RLVR','执行验收 → 回报','对本条运行按预先规定的准则验收，另有独立、标明日期的有效记录。','行为策略与环境共同生成新轨迹；最后将回答与有效记录比较，取得验收分。','得分或由它估计的优势回传到模型生成的请求和回答。'),
 ('opd','OPD','教师概率 → 当步纠偏','学生采样每个模型词元。固定教师读同一前缀，对学生选出的词给出概率；此处采用共享词表的白盒教师。','每次选词后即可查询教师；也可在生成结束后按原前缀批量重算，无需等用户给分。','各生成位置各有一个教师与学生的对数概率差；此处只给本步加权。')]
style="""<style>
#feedback-at-token{margin:1.35rem 0;background:#fdfcf8;border:1px solid #c3d2cb;border-radius:9px;padding:clamp(.65rem,2.1vw,1.1rem);line-height:1.52}
#feedback-at-token h4{margin:0;color:#183e43;font-size:1.12rem;line-height:1.45}
#feedback-at-token .ft-sub,#feedback-at-token .ft-legend{font-size:.83rem;color:#455c60;margin:.4rem 0}
#feedback-at-token .ft-controls{display:flex;flex-wrap:wrap;gap:.33rem;margin:.72rem 0}
#feedback-at-token .ft-controls button{border:1px solid #a5bbb7;border-radius:16px;padding:.27rem .82rem;background:#fff;color:#244c53;font:600 .86rem/1.5 var(--sans);cursor:pointer}
#feedback-at-token .ft-controls button[aria-pressed=true]{background:#245a61;color:white;border-color:#245a61}
#feedback-at-token .ft-panel{border-top:1px solid #bbc9c4;padding:.63rem 0 .1rem}
#feedback-at-token .ft-row{display:grid;grid-template-columns:7.1rem minmax(0,1fr);gap:.2rem .6rem;align-items:center;margin:.36rem 0}
#feedback-at-token .ft-role{font-weight:650;color:#334b51;font-size:.83rem}
#feedback-at-token .ft-strip{display:flex;flex-wrap:wrap;align-items:center;gap:2px;min-width:0}
#feedback-at-token .ft-token{font:600 .88rem/1.42 ui-monospace,monospace;border:1px solid #cbd3d2;border-bottom-width:2px;color:#455559;background:#f0f1ee;min-width:1.3rem;padding:.11rem .19rem;cursor:pointer;border-radius:3px}
#feedback-at-token .ft-token[data-c=up]{color:#124b49;background:#ddf1e8;border-color:#96c2b6;border-bottom-color:#1d7067}
#feedback-at-token .ft-token[data-c=down]{color:#803e20;background:#f9e9dd;border-color:#d9b4a1;border-bottom:2px dashed #944c2b}
#feedback-at-token .ft-token[data-c=local]{color:#4e366c;background:#eee7f6;border-color:#c9b3da;border-bottom-color:#755591}
#feedback-at-token .ft-token[data-c=common]{color:#53635b;background:#f3f2ed;border-bottom:2px dotted #a6a9a0}
#feedback-at-token .ft-token.ft-chosen{outline:2px solid #263f42;outline-offset:1px}
#feedback-at-token button:focus-visible{outline:3px solid #236fa7;outline-offset:2px}
#feedback-at-token .ft-lens{background:#f2f4ef;border-left:3px solid #8fa69f;padding:.48rem .62rem;font-size:.85rem;margin:.62rem 0}
#feedback-at-token .ft-lens code{color:#1f464a;white-space:pre-wrap;overflow-wrap:anywhere}
#feedback-at-token .ft-notes{display:grid;grid-template-columns:4rem minmax(0,1fr);gap:.25rem .6rem;margin:.56rem 0 0;font-size:.85rem}
#feedback-at-token .ft-notes dt{color:#214e53;font-weight:650}#feedback-at-token .ft-notes dd{margin:0}
#feedback-at-token figcaption{padding:.52rem 0 0;border-top:1px solid #d8ddd7;margin-top:.72rem;font-size:.80rem}
#feedback-at-token [hidden]{display:none!important}
@media(max-width:570px){#feedback-at-token .ft-row{grid-template-columns:minmax(0,1fr);gap:.12rem}#feedback-at-token .ft-role{font-size:.77rem}#feedback-at-token .ft-notes{grid-template-columns:3.5rem minmax(0,1fr);gap:.3rem}#feedback-at-token .ft-token{min-width:1.18rem}}
@media print{#feedback-at-token [hidden]{display:block!important}#feedback-at-token .ft-controls{display:none}}
</style>"""
role={'user':'① 用户 · 提问','request':'② 模型 · 请求','tool':'③ 工具 · 返回','answer':'④ 模型 · 回答','foil':'④ 模型 · 回答乙'}
def kind(k,i,m):
 if k in ('tool','user'):return 'obs'
 if m=='dpo':
  if k=='request':return 'obs'
  if i<5:return 'common'
  return 'up' if k=='answer' else 'down'
 return 'local' if m=='opd' else 'up'
def explanation(k,i,m):
 if k=='user':return '用户给定的词。它改变模型的条件输入，不是本次策略损失中的行动。'
 if k=='tool':return '这是工具提供的观测。训练后果模型时它可以作预测标签；训练行动策略时它只进入后续上下文。'
 if m=='dpo':
  if k=='request':return '请求已经包含在这对回答的给定历史中。这个偏好标签不比较两种请求。'
  if i<5:return '甲乙在此处的前缀和所选词均相同，两个显式对数概率梯度相消；共享参数仍可能因别处更新而改变这里的概率。'
  diff='这是两条回答首次分叉的位置。' if i==5 else '两边虽可能写同一个词，分叉后的条件前缀不同。'
  return diff+('甲的此项以正号进入偏好对数胜算。' if k=='answer' else '乙的此项以负号进入偏好对数胜算。')
 if m=='opd':return '学生在此选词。教师也读这个前缀：教师给所选词的概率越高于学生，当步对数比越正；下一步的教师信号不自动回传到这一步。'
 return '生成策略在此选择。'+('奖励模型评分' if m=='rlhf' else '独立验收得分')+'可用于估计其优势，权重可正可负。单个终局分数不能指出这一词造成了多少改善。'
def renderpanel(m,title,head,who,when,delta):
 ks=['user','request','tool','answer']+(['foil'] if m=='dpo' else [])
 a=[f'<div class="ft-panel" id="ft-view-{m}" data-ft-panel="{m}"><b>{title}　{head}</b>']
 for k in ks:
  msg=messages[k]; tokens=msg['tokens']; ro=('④ 模型 · 回答甲' if m=='dpo' and k=='answer' else role[k]);a.append(f'<div class="ft-row"><span class="ft-role">{ro}</span><span class="ft-strip">')
  for i,(tok,n) in enumerate(zip(tokens,msg['ids'])):
   clean=lambda v:v.replace('Ġ','␠')
   prefix=''.join(tokens[:i]).replace('Ġ',' ') or '〈消息起点〉'
   tip=explanation(k,i,m); a.append(f'<button type="button" class="ft-token" data-k="{k}" data-i="{i}" data-c="{kind(k,i,m)}" data-pre="{escape(prefix,quote=True)}" data-id="{n}" data-tip="{tip}" aria-label="{ro}，第{i+1}词 {clean(tok)}，编号{n}">{escape(clean(tok))}</button>')
  a.append('</span></div>')
 initial={'dpo':'甲乙的前五个词在同一前缀上相消。选 7 和 9 的分叉处，或各自后面的冒号，可查看确切条件。','rlhf':'绿色是参与策略更新的位置，颜色不代表优势为正。点选回执和回答里的 7，比较两处的角色。','rlvr':'绿色是可由验收回报加权的生成位置，颜色不代表优势为正。点选第二行请求，查看晚到的反馈怎样参与更新。','opd':'紫色是可查询教师的生成位置。点选任一词元，查看教师在哪个前缀给分。'}[m]
 a.extend([f'<div class="ft-lens" aria-live="polite">{initial}</div>',f'<dl class="ft-notes"><dt>前缀来源</dt><dd>{who}</dd><dt>反馈时刻</dt><dd>{when}</dd><dt>更新方向</dt><dd>{delta}</dd></dl></div>']);return ''.join(a)
s=[style,'<figure id="feedback-at-token" aria-labelledby="feedback-sources-caption"><h4>同一条交互，四种训练信号</h4><p class="ft-sub">读图顺序：用户提问 → 模型查询今天的开放时间 → 工具返回 → 模型作答。切换方法，再点一个词元看它在该损失中的作用。</p><div class="ft-controls" role="group" aria-label="选择反馈方式">']
s.extend(f'<button type="button" data-ft="{m}" aria-controls="ft-view-{m}">{t}</button>' for m,t,*_ in pairs);s.append('</div>')
s.extend(renderpanel(*p) for p in pairs)
s.append('<figcaption id="feedback-sources-caption"><b>概率属于作选择的一方。</b>同样是数字 7，在工具返回中是观测，在回答中是行动。图中 ␠ 为空格，灰色为给定内容；DPO 绿色与橙色分别标出偏好对中取正、负号的词元项。按消息正文独立分词，省去协议边界；若结束符也由策略选择，完整损失须计入。比较使用教学构造的交互，各方法所需的监督另行取得。<a href="reader-source/ordinary-token-spans.json">词元文本与编号</a> · <a href="'+data['source']+'">分词器</a> · <a href="#method-equivalence">同解条件</a>。</figcaption></figure>')
s.append("""<script>(()=>{const f=document.getElementById('feedback-at-token');const show=id=>{for(const p of f.querySelectorAll('[data-ft-panel]'))p.hidden=p.dataset.ftPanel!==id;for(const b of f.querySelectorAll('[data-ft]'))b.setAttribute('aria-pressed',String(b.dataset.ft===id))};show('dpo');f.addEventListener('click',ev=>{const b=ev.target.closest('button');if(!b||!f.contains(b))return;if(b.dataset.ft){show(b.dataset.ft);return}const p=b.closest('.ft-panel');p.querySelectorAll('.ft-chosen').forEach(t=>t.classList.remove('ft-chosen'));b.classList.add('ft-chosen');const lens=p.querySelector('.ft-lens'); const tag=document.createElement('b');tag.textContent=b.getAttribute('aria-label')+'。';const c=document.createElement('code');c.textContent=b.dataset.pre;const role=b.dataset.k;const conditional=(role==='answer'||role==='foil')?'用户提问＋查询请求＋工具返回，再接本句前缀 ':role==='request'?'用户提问，再接请求前缀 ':role==='tool'?'工具返回内已出现的文字 ':'用户消息内已出现的文字 ';lens.replaceChildren(tag,' '+conditional,c,'。'+b.dataset.tip);});})();</script>""")
(here/'feedback-sources-figure.html').write_text('\n'.join(s)+'\n')
