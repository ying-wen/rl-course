"""Factorial experiment on source-review progress and policy-score credit duration.

Run from this directory with python3 probe_representation_trace.py --json probe-factorial-results.json
"""
import argparse
import json
from dataclasses import asdict, replace
from pathlib import Path
from statistics import mean

from decision_returns import train
from probe_policy_learning import Timing, TimingActor, deploy
from stream_revaluation import mean_interval


class ReviewProgressActor(TimingActor):
    """Expose one scalar the memory updater knows before the buying decision."""

    def __init__(self, arm, cfg):
        super().__init__(arm, cfg)
        self.weights.append(0.)
        self.trace.append(0.)

    def features(self, s, v, memory):
        base = super().features(s, v, memory)
        # Only paired, delivered feedback in this condition's current block.
        complete_pairs = len(memory.blocks[s]) // 2
        progress = complete_pairs / memory.config.pairs_per_block
        assert 0 <= progress < 1
        return (*base, progress)


CELLS = {
    "basic_short": (TimingActor, .8),
    "progress_short": (ReviewProgressActor, .8),
    "basic_long": (TimingActor, .97),
    "progress_long": (ReviewProgressActor, .97),
}


CONTRASTS = {
    "mean_progress_effect": {
        "progress_short": .5, "basic_short": -.5, "progress_long": .5, "basic_long": -.5,
    },
    "mean_long_trace_effect": {
        "basic_long": .5, "basic_short": -.5, "progress_long": .5, "progress_short": -.5,
    },
    "progress_at_short": {"progress_short": 1, "basic_short": -1},
    "progress_at_long": {"progress_long": 1, "basic_long": -1},
    "long_at_basic": {"basic_long": 1, "basic_short": -1},
    "long_at_progress": {"progress_long": 1, "progress_short": -1},
    "difference_in_differences": {
        "progress_long": 1, "basic_long": -1, "progress_short": -1, "basic_short": 1,
    },
}


def deployment_record(initial, cfg, scenario, seed, cell):
    actor_class, decay = CELLS[cell]
    run = deploy(initial, replace(cfg, trace_decay=decay), scenario, "learned", seed,
                 keep_trace=True, budget="cap", actor_class=actor_class)
    events = run["events"]
    p = [event["probability"] for event in events]
    # Online credit includes every score in the decayed trace. Record the size of
    # actual parameter increments to distinguish credit duration from update scale.
    previous = [0.] * len(events[0]["weights_after"])
    sum_squared = 0.
    for event in events:
        weights = event["weights_after"]
        sum_squared += sum((new-old)**2 for new, old in zip(weights, previous))
        previous = weights
    return dict(seed=seed, net=run["total"], labels=run["n_audits"],
                revisions=len(run["revisions"]),
                mean_probability=mean(p),
                low_or_high_probability=mean(value < .15 or value > .85 for value in p),
                rms_step=(sum_squared/len(events))**.5,
                revision_times=sorted(r["t"] for r in run["revisions"].values()))


def run_experiment(cfg):
    initial = train()
    result = dict(config=asdict(cfg), max_labels=400, budget="cap",
                  arms={name: {"trace_decay": decay,
                               "review_progress": cls is ReviewProgressActor}
                        for name, (cls, decay) in CELLS.items()}, worlds={})
    for scenario in ("stable", "reversal"):
        rows = {cell: [deployment_record(initial, cfg, scenario, cfg.seed+i, cell)
                       for i in range(cfg.repetitions)] for cell in CELLS}
        fields = ("net", "labels", "revisions", "mean_probability",
                  "low_or_high_probability", "rms_step")
        summary = {cell: {field: mean_interval([r[field] for r in records])
                          for field in fields} for cell, records in rows.items()}
        contrasts = {}
        for name, coefficients in CONTRASTS.items():
            contrasts[name] = {}
            for field in ("net", "labels", "revisions"):
                paired = [sum(coeff * rows[cell][i][field] for cell, coeff in coefficients.items())
                          for i in range(cfg.repetitions)]
                contrasts[name][field] = mean_interval(paired)
        result["worlds"][scenario] = dict(summary=summary, contrasts=contrasts, streams=rows)
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--json", type=Path, required=True)
    parser.add_argument("--seed", type=int, default=Timing().seed,
                        help="First of 96 consecutive independent deployment seeds.")
    args = parser.parse_args()
    result = run_experiment(Timing(seed=args.seed))
    args.json.write_text(json.dumps(result, indent=2, ensure_ascii=False)+"\n")
    for name, world in result["worlds"].items():
        print(name, {arm: round(stats["net"]["mean"], 3) for arm, stats in world["summary"].items()})
