"""单流中的来源可靠性、估值与局部记忆修订。只依赖同目录的 decision_returns.py。
运行 python3 stream_revaluation.py --json results.json。时间 t 以一组连续双委托为单位，从 1 起算。
"""
import argparse
from collections import defaultdict, deque
from dataclasses import asdict, dataclass
import json
from math import comb, sqrt
from pathlib import Path
from random import Random
from statistics import mean, median, stdev

from decision_returns import COST, HOLDOUT, REVERSED, WRITE_COST, train


@dataclass(frozen=True)
class Protocol:
    horizon: int = 2400
    change_at: int = 801             # 仅由模拟环境和事后评价使用
    probe_rate: float = .32          # 仅 s=1,2 有探测机会
    label_delay: int = 3             # t 时付费，t+3 开始前可读结果
    pairs_per_block: int = 32
    max_looks: int = 6               # 每类条件的检验次数上限
    alpha: float = .05
    audit_cost: float = .02
    revision_cost: float = .25
    repetitions: int = 96
    bin_width: int = 40


CONFIG = Protocol()
ARMS = ("frozen", "probe", "revise")
START_SEED = 73000


def upper_sign_p(wins, losses):
    """精确单侧符号检验。条件化在不一致对数上，平局不贡献信息。"""
    n = wins + losses
    return sum(comb(n, k) for k in range(wins, n + 1)) / (2 ** n)


def pick(probs, u):
    if u < probs[0]:
        return 0
    return 1 if u < probs[0] + probs[1] else 2


@dataclass(frozen=True)
class Label:
    origin: int
    setting: int
    action: int
    cue_correct: int
    task_return: float  # 两次验收所得净回报；未重复扣除比较两支时相同的标签费


class SourceMemory:
    """受训首词策略的局部修订。该对象无权读取期限内的环境编号、真值或未选分支。"""
    def __init__(self, initial, config):
        self.config = config
        self.actions = list(initial)
        self.old = {s: max((1, 2), key=lambda a: initial[s][a]) for s in (1, 2)}
        self.second = {1: None, 2: None}
        self.blocks = {1: [], 2: []}
        self.looks = {1: 0, 2: 0}
        self.revisions = {}
        self.checks = []

    def select(self, setting, probe, order_u, sample_u):
        if not probe:
            return pick(self.actions[setting], sample_u)
        # 选择顺序只依赖可见条件、预定抽样与此类未完成的一对；不依赖真值。
        second = self.second[setting]
        if second is not None:
            self.second[setting] = None
            return second
        old = self.old[setting]
        action = old if order_u < .5 else 3 - old
        self.second[setting] = 3 - action
        return action

    def observe(self, label, now, enable_revision):
        s = label.setting
        if s in self.revisions or self.looks[s] >= self.config.max_looks:
            return False
        rows = self.blocks[s]
        rows.append(label)
        if len(rows) < 2 * self.config.pairs_per_block:
            return False
        self.looks[s] += 1
        old, alternative = self.old[s], 3 - self.old[s]
        wins = losses = 0
        for first, second in zip(rows[::2], rows[1::2]):
            assert first.action != second.action
            incumbent, other = (first, second) if first.action == old else (second, first)
            wins += int(other.cue_correct > incumbent.cue_correct)
            losses += int(other.cue_correct < incumbent.cue_correct)
        groups = {a: [r for r in rows if r.action == a] for a in (old, alternative)}
        qhat = {a: mean(r.task_return for r in group) for a, group in groups.items()}
        phat = {a: mean(r.cue_correct for r in group) for a, group in groups.items()}
        pvalue = upper_sign_p(wins, losses)
        limit = self.config.alpha / (2 * self.config.max_looks)
        revise = enable_revision and pvalue <= limit and qhat[alternative] > qhat[old]
        event = dict(t=now, first=rows[0].origin, last=rows[-1].origin, setting=s,
                     look=self.looks[s], old=old, alt=alternative, wins=wins, losses=losses,
                     ties=self.config.pairs_per_block-wins-losses, p_value=pvalue,
                     q_old=qhat[old], q_alt=qhat[alternative], p_old=phat[old],
                     p_alt=phat[alternative], revised=revise)
        self.checks.append(event)
        rows.clear()
        if revise:
            # 将原条件的规则归档，新的局部路由交换两来源的利用概率。
            # 其他条件、直接提交的概率、作答规则和临时写入规则均固定。
            previous = self.actions[s]
            revised = list(previous)
            revised[old], revised[alternative] = revised[alternative], revised[old]
            self.revisions[s] = dict(**event, previous=list(previous), current=list(revised))
            self.actions[s] = tuple(revised)
        return revise


def deploy(fixed, cfg, scenario, arm, seed, keep_trace=False):
    rng = Random(seed)
    memory = SourceMemory(fixed[0], cfg)
    follow_prob, write_probs = fixed[1:]
    labels = deque()
    total = 0.
    curves = [total]
    events = []
    costs = defaultdict(float)
    n_probes = 0
    for t in range(1, cfg.horizon + 1):
        # 到期后才把独立核验结果交给学习者。最后三轮到期前的费用照计。
        while labels and labels[0].origin + cfg.label_delay == t:
            label = labels.popleft()
            if memory.observe(label, t, arm == "revise"):
                total -= cfg.revision_cost
                costs["revision"] += cfg.revision_cost
            if keep_trace:
                events.append(dict(t=t, kind="label", **asdict(label)))

        setting, reuse_cue, fact = rng.randrange(3), rng.randrange(2), rng.randrange(2)
        # 每步固定外生抽样次序，便于跨策略配对；只用实际选中来源的可靠性产生一个观测。
        probe_u, order_u, sample_u, source_u, follow_u, write_u, reuse_u = (
            rng.random() for _ in range(7))
        fresh_fact, fallback_answer = rng.randrange(2), rng.randrange(2)
        probe = arm != "frozen" and setting != 0 and probe_u < cfg.probe_rate
        # 对固定的示意记录同时保存行为概率与组内配对设计概率。
        # 一对中第二次的探测动作已确定；该次利用策略本身仍保有三个行动。
        pending_action = memory.second.get(setting)
        action = memory.select(setting, probe, order_u, sample_u)
        family = REVERSED if scenario == "reversal" and t >= cfg.change_at else HOLDOUT[1]
        reliable = source_u < family.reliability[setting][action]
        cue = fact if reliable else 1 - fact
        answer = cue if follow_u < follow_prob else 1 - cue
        write = int(write_u < write_probs[reuse_cue])
        next_fact = fact if reuse_u < family.reuse[reuse_cue] else fresh_fact
        next_answer = cue if write else fallback_answer
        task_return = int(answer == fact) + int(next_answer == next_fact) - COST[action] - write*WRITE_COST
        costs["operation"] += COST[action]
        costs["temporary_write"] += write*WRITE_COST
        # 评测者旁收两次委托的成绩。可靠性证据与比较所需的回报只在付费抽查后送达。
        total += task_return
        if probe:
            n_probes += 1
            costs["audit"] += cfg.audit_cost
            total -= cfg.audit_cost
            labels.append(Label(t, setting, action, int(reliable), task_return))
            if keep_trace:
                within_pair = .5 if pending_action is None else float(action == pending_action)
                behavior_prob = ((1-cfg.probe_rate)*memory.actions[setting][action]
                                 + cfg.probe_rate*within_pair)
                events.append(dict(t=t, kind="probe", setting=setting, action=action,
                                   cue=cue, audit_due=t+cfg.label_delay, probe_prob=cfg.probe_rate,
                                   action_given_probe=within_pair, behavior_prob=behavior_prob))
        if t % cfg.bin_width == 0 or t == cfg.horizon:
            curves.append(total)
    return dict(total=total, curves=curves, costs=dict(costs), probes=n_probes,
                checks=memory.checks, revisions=memory.revisions, events=events)


def mean_interval(values):
    """以独立部署为统计单位的 95% 正态近似区间。"""
    m = mean(values)
    radius = 1.96 * stdev(values) / sqrt(len(values))
    return dict(mean=m, low=m-radius, high=m+radius)


def fraction(k, n):
    z = 1.96
    p = k/n
    center = (p+z*z/(2*n))/(1+z*z/n)
    half = z*sqrt(p*(1-p)/n+z*z/(4*n*n))/(1+z*z/n)
    return dict(count=k, n=n, rate=p, low=max(0., center-half), high=min(1., center+half))


def detection(runs, cfg):
    post_times = [[event["t"] for event in run["revisions"].values()
                   if event["t"] >= cfg.change_at] for run in runs]
    delays = [min(times) - cfg.change_at for times in post_times if times]
    return dict(
        any_revision=fraction(sum(bool(r["revisions"]) for r in runs), len(runs)),
        by_setting={s: fraction(sum(s in r["revisions"] for r in runs), len(runs)) for s in (1, 2)},
        early=fraction(sum(any(e["t"] < cfg.change_at for e in r["revisions"].values()) for r in runs),len(runs)),
        post_any=fraction(sum(bool(times) for times in post_times),len(runs)),
        post_both=fraction(sum(len(times) == 2 for times in post_times),len(runs)),
        post_by_setting={s: fraction(sum(r["revisions"].get(s, {}).get("t", 0) >= cfg.change_at
                                         for r in runs), len(runs)) for s in (1, 2)},
        mean_delay_if_detected=mean(delays) if delays else None,
        median_delay_if_detected=median(delays) if delays else None,
        undetected_by_horizon=sum(not times for times in post_times))


def run_protocol(cfg):
    fixed = train()
    scenarios = {}
    times = [0] + list(range(cfg.bin_width, cfg.horizon+1, cfg.bin_width))
    if times[-1] != cfg.horizon:
        times.append(cfg.horizon)
    for scenario in ("stable", "reversal"):
        runs = {arm: [deploy(fixed, cfg, scenario, arm, START_SEED+i)
                      for i in range(cfg.repetitions)] for arm in ARMS}
        curves = [dict(t=t, **{a: mean(run["curves"][i] for run in runs[a]) for a in ARMS})
                  for i, t in enumerate(times)]
        summary = {a: dict(mean_total=mean_interval([run["total"] for run in runs[a]]),
                           mean_probes=mean(run["probes"] for run in runs[a]),
                           mean_costs={c: mean(run["costs"].get(c, 0.) for run in runs[a])
                                       for c in ("operation", "temporary_write", "audit", "revision")})
                   for a in ARMS}
        contrasts = {}
        for a, b in (("revise", "frozen"), ("revise", "probe"), ("probe", "frozen")):
            contrasts[f"{a}_minus_{b}"] = mean_interval(
                [ra["total"]-rb["total"] for ra, rb in zip(runs[a], runs[b])])
        assert all(ra["probes"] == rb["probes"] for ra, rb in zip(runs["probe"], runs["revise"]))
        out = dict(curves=curves, summary=summary, paired_contrasts=contrasts)
        measured = detection(runs["revise"], cfg)
        if scenario == "stable":
            out["false_revisions"] = dict(any=measured["any_revision"], by_setting=measured["by_setting"])
        else:
            out["detection"] = measured
        scenarios[scenario] = out
    example = deploy(fixed, cfg, "reversal", "revise", START_SEED, keep_trace=True)
    return dict(config=asdict(cfg), scenarios=scenarios,
                example=dict(seed=START_SEED, traces=example["events"], checks=example["checks"],
                             revisions=example["revisions"]))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--json", type=Path, help="保存完整数值、单条经验流及分支检验")
    args = parser.parse_args()
    result = run_protocol(CONFIG)
    if args.json:
        args.json.write_text(json.dumps(result, ensure_ascii=False, indent=2)+"\n")
    print("全程净回报：每条独立部署累计两次委托成绩，扣除操作、写入、探测及修订费用。")
    for scenario, data in result["scenarios"].items():
        print(scenario, {a: round(data["summary"][a]["mean_total"]["mean"], 2) for a in ARMS})
        print("配对差及期望的近似区间", data["paired_contrasts"])
        print("局部记忆修订", data.get("detection", data.get("false_revisions")))
    print("固定示例种子", result["example"]["seed"], "局部检验", result["example"]["checks"])
