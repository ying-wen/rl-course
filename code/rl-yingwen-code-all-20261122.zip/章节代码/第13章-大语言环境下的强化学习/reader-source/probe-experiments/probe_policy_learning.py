"""Single-stream learning of audit timing with exactly one paired audit per window.

Run: python3 probe_policy_learning.py --json /tmp/ch13-probe-policy-results.json
With optional purchasing: python3 probe_policy_learning.py --budget cap --json cap.json
Each run starts with a newly initialized actor. The frozen source policy is trained
only on the separate source environment in decision_returns.train().
"""
import argparse
from collections import deque
from dataclasses import asdict, dataclass
import json
from math import exp
from pathlib import Path
from random import Random
from statistics import mean

from decision_returns import COST, HOLDOUT, REVERSED, WRITE_COST, train
from stream_revaluation import Label, Protocol, SourceMemory, mean_interval


@dataclass(frozen=True)
class Timing:
    horizon: int = 2400
    window: int = 12
    change_at: int = 801
    labels_per_window: int = 2
    repetitions: int = 96
    seed: int = 81200
    trace_decay: float = .8
    step_size: float = .02
    probability_floor: float = .1
    center: float = 15.


ARMS = ("fixed", "periodic", "learned")


class TimingActor:
    def __init__(self, arm, cfg):
        self.arm = arm
        self.cfg = cfg
        self.weights = [0.] * 5
        self.trace = [0.] * 5
        self.counts = {(s, a): [0, 0] for s in (1, 2) for a in (1, 2)}

    def observe_audit(self, label):
        tally = self.counts[label.setting, label.action]
        tally[0] += label.cue_correct
        tally[1] += 1

    def features(self, s, v, memory):
        old = memory.old[s]

        def rate(action):
            wins, n = self.counts[s, action]
            return (1 + wins) / (2 + n)

        return (1., 2.*(s == 2)-1., 2.*v-1., rate(3-old)-rate(old),
                float(s in memory.revisions))

    def probability(self, x, window_index=0):
        if self.arm == "never":
            return 0.
        if self.arm == "alternating":
            return float(window_index % 2 == 0)
        if self.arm == "periodic":
            return 1.
        if self.arm == "fixed":
            return .5
        z = sum(w * value for w, value in zip(self.weights, x))
        # This form stays finite even if a very long run saturates the sigmoid.
        unit = 1/(1+exp(-z)) if z >= 0 else exp(z)/(1+exp(z))
        floor = self.cfg.probability_floor
        return floor + (1-2*floor)*unit

    def choose(self, x, u, window_index=0):
        p = self.probability(x, window_index)
        early = int(u < p)
        if self.arm == "learned":
            floor = self.cfg.probability_floor
            unit = (p-floor)/(1-2*floor)
            multiplier = (early-p)*(1-2*floor)*unit*(1-unit)/(p*(1-p))
            self.trace = [self.cfg.trace_decay * e + multiplier * value
                          for e, value in zip(self.trace, x)]
        return early, p

    def observe_invoice(self, invoice):
        if self.arm == "learned":
            self.weights = [w + self.cfg.step_size*(invoice-self.cfg.center)*e
                            for w, e in zip(self.weights, self.trace)]


def deploy(initial, cfg, scenario, arm, seed, keep_trace=False, budget="exact",
           actor_class=TimingActor):
    rng = Random(seed)
    gate = actor_class(arm, cfg)
    observe_execution = getattr(gate, "observe_execution", None)
    memory_cfg = Protocol()
    memory = SourceMemory(initial[0], memory_cfg)
    follow_prob, write_probs = initial[1:]
    labels = deque()
    n_audits = 0
    curves = [0.]
    events = []
    timing_stats = {}
    invoices = []
    for window_index in range(cfg.horizon // cfg.window):
        # Both opportunities are sampled from the same law. The actor sees only
        # the first when choosing. The environment never passes it the later pair.
        first = rng.randint(1, 2), rng.randrange(2)
        second = rng.randint(1, 2), rng.randrange(2)
        gate_uniform = rng.random()
        first_group = 1 + cfg.window * window_index
        invoice = 0.
        matured = []
        revisions = []
        paid_times = []
        for offset in range(cfg.window):
            t = first_group + offset
            while labels and labels[0].origin + memory_cfg.label_delay == t:
                label = labels.popleft()
                gate.observe_audit(label)
                if keep_trace:
                    matured.append(dict(t=t, **asdict(label)))
                if memory.observe(label, t, enable_revision=True):
                    invoice -= memory_cfg.revision_cost
                    revisions.append(t)
            if offset == 0:
                x = gate.features(*first, memory)
                early, p = gate.choose(x, gate_uniform, window_index)
                phase = "first_50" if window_index < 50 else "middle_100" if window_index < 150 else "last_50"
                stratum = (phase, *first)
                summary = timing_stats.setdefault(stratum, [0, 0., 0])
                summary[0] += 1
                summary[1] += p
                summary[2] += early

            setting, v = rng.randrange(3), rng.randrange(2)
            if offset in (0, 1):
                setting, v = first
            elif offset in (6, 7):
                setting, v = second
            paid = (offset in (0, 1) and early) or (
                budget == "exact" and offset in (6, 7) and not early)
            # All arms consume the same exogenous draws before applying their
            # own actions; only the executed branch yields an observation.
            fact, fresh, fallback = (rng.randrange(2) for _ in range(3))
            order_u, sample_u, source_u, follow_u, write_u, reuse_u = (
                rng.random() for _ in range(6))
            action = memory.select(setting, paid, order_u, sample_u)
            env = REVERSED if scenario == "reversal" and t >= cfg.change_at else HOLDOUT[1]
            correct = source_u < env.reliability[setting][action]
            cue = fact if correct else 1-fact
            answer = cue if follow_u < follow_prob else 1-cue
            write = int(write_u < write_probs[v])
            next_fact = fact if reuse_u < env.reuse[v] else fresh
            next_answer = cue if write else fallback
            if observe_execution is not None:
                observe_execution(t, setting, action, paid)
            task_return = (int(answer == fact) + int(next_answer == next_fact)
                           - COST[action] - write*WRITE_COST)
            # Per-group unpurchased labels and scores are never passed to the actor.
            invoice += task_return
            if paid:
                n_audits += 1
                paid_times.append(t)
                invoice -= memory_cfg.audit_cost
                labels.append(Label(t, setting, action, int(correct), task_return))
        gate.observe_invoice(invoice)
        curves.append(curves[-1] + invoice)
        if arm == "learned":
            invoices.append((early, p, invoice))
        if keep_trace:
            events.append(dict(start=first_group, end=t, first_context=list(first),
                               early=early, probability=p, x=list(x), invoice=invoice,
                               audited=paid_times, matured=matured, revisions=revisions,
                               trace=list(gate.trace), weights_after=list(gate.weights),
                               next_probability_same_x=gate.probability(x)))
    total_cap = cfg.labels_per_window * (cfg.horizon // cfg.window)
    assert n_audits <= total_cap and (budget == "cap" or n_audits == total_cap)
    assert not labels
    return dict(curves=curves, total=curves[-1], n_audits=n_audits,
                revisions=memory.revisions, events=events, timing_stats=timing_stats,
                invoices=invoices)


def action_value_difference(invoices, lookahead, center):
    """Chosen vs unchosen first pair; subsequent actions use the online actor.

    Each eligible start is weighted equally, including starts with no revision.
    Only the first gate is reweighted. Never use the unexecuted action or the
    evaluator's per-group rewards. A constant invoice center leaves the randomized
    contrast unchanged in expectation. Endpoints all have full follow-up.
    """
    cumulative = [0.]
    for _, _, invoice in invoices:
        cumulative.append(cumulative[-1] + invoice - center)
    contrasts = []
    for j in range(len(invoices) - lookahead + 1):
        early, p, _ = invoices[j]
        outcome = cumulative[j+lookahead] - cumulative[j]
        contrast_weight = 1/p if early else -1/(1-p)
        contrasts.append(contrast_weight* outcome)
    return mean(contrasts)


def run_optional_purchase(cfg=Timing()):
    """Same per-window ceiling for all arms. An unused opportunity expires."""
    arms = ("never", "fixed", "alternating", "periodic", "learned")
    initial = train()
    results = {}
    for scenario in ("stable", "reversal"):
        runs = {arm: [deploy(initial, cfg, scenario, arm, cfg.seed+i,
                             keep_trace=(arm == "learned" and i == 0), budget="cap")
                      for i in range(cfg.repetitions)] for arm in arms}
        summary = {}
        for arm, group in runs.items():
            labels = [r["n_audits"] for r in group]
            summary[arm] = dict(net=mean_interval([r["total"] for r in group]),
                                labels=mean_interval(labels), label_range=[min(labels), max(labels)],
                                mean_revisions=mean(len(r["revisions"]) for r in group))
        contrasts = {arm: mean_interval([a["total"]-b["total"]
                                         for a,b in zip(runs["learned"],runs[arm])])
                     for arm in arms if arm != "learned"}
        clock_contrasts = {arm: mean_interval([a["total"]-b["total"]
                                              for a,b in zip(runs[arm],runs["alternating"])])
                           for arm in arms}
        quarter = cfg.horizon // cfg.window // 4
        probabilities = [mean(r["invoices"][j][1] for r in runs["learned"]
                              for j in range(q*quarter, (q+1)*quarter)) for q in range(4)]
        local = {k: mean_interval([action_value_difference(r["invoices"], k, cfg.center)
                                   for r in runs["learned"]]) for k in (1, 8)}
        curves = [dict(t=i*cfg.window, **{a: mean(r["curves"][i] for r in runs[a])
                                          for a in arms}) for i in range(cfg.horizon//cfg.window+1)]
        results[scenario] = dict(summary=summary, learned_minus=contrasts,
                                 minus_alternating=clock_contrasts, buy_minus_skip_value=local,
                                 probability_by_quarter=probabilities, curves=curves,
                                 example=runs["learned"][0]["events"])
    return dict(budget="cap", config=asdict(cfg), max_labels=2*cfg.horizon//cfg.window,
                audit_cost=Protocol().audit_cost, scenarios=results)


def run_protocol(cfg=Timing()):
    if cfg.window != 12 or cfg.horizon % cfg.window or cfg.labels_per_window != 2:
        raise ValueError("This protocol has two candidate pairs per 12-group window.")
    initial = train()
    scenarios = {}
    for scenario in ("stable", "reversal"):
        runs = {arm: [deploy(initial, cfg, scenario, arm, cfg.seed+i, keep_trace=(i == 0 and arm == "learned"))
                      for i in range(cfg.repetitions)] for arm in ARMS}
        curves = []
        for i in range(cfg.horizon//cfg.window+1):
            row = dict(t=i*cfg.window)
            for arm in ARMS:
                row[arm] = mean(run["curves"][i] for run in runs[arm])
            for arm, key in (("fixed", "delta"), ("periodic", "delta_periodic")):
                interval = mean_interval([r["curves"][i]-b["curves"][i]
                                          for r,b in zip(runs["learned"],runs[arm])])
                row[key] = interval["mean"]
                row[key+"_low"], row[key+"_high"] = interval["low"], interval["high"]
            curves.append(row)
        summary = {}
        for arm in ARMS:
            group = runs[arm]
            assert len({r["n_audits"] for r in group}) == 1
            summary[arm] = dict(net=mean_interval([r["total"] for r in group]),
                                label_count=group[0]["n_audits"],
                                mean_revisions=mean(len(r["revisions"]) for r in group))
        # Sample frequencies and decision probabilities aggregated by visible cue.
        strata = sorted(set().union(*(r["timing_stats"] for r in runs["learned"])))
        timing = []
        for stratum in strata:
            values = [r["timing_stats"].get(stratum, [0, 0., 0]) for r in runs["learned"]]
            n, summed_p, early_count = map(sum, zip(*values))
            phase, s, v = stratum
            timing.append(dict(phase=phase, setting=s, reuse=v, n=n,
                               mean_probability=summed_p/n, early_fraction=early_count/n))
        diff = {arm: mean_interval([r["total"]-b["total"]
                                    for r, b in zip(runs["learned"], runs[arm])])
                for arm in ("fixed", "periodic")}
        scenarios[scenario] = dict(curves=curves, summary=summary, difference=diff["fixed"],
                                   difference_periodic=diff["periodic"], timing=timing,
                                   example=runs["learned"][0]["events"],
                                   early_minus_defer_value={
                                       k: mean_interval([action_value_difference(r["invoices"], k, cfg.center)
                                                         for r in runs["learned"]])
                                       for k in (1, 8)})
    memory_cfg = Protocol()
    return dict(config={**asdict(cfg), "audit_cost": memory_cfg.audit_cost,
                        "revision_cost": memory_cfg.revision_cost,
                        "label_delay": memory_cfg.label_delay,
                        "pairs_per_block": memory_cfg.pairs_per_block},
                scenarios=scenarios)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--json", type=Path)
    parser.add_argument("--budget", choices=("exact", "cap"), default="exact")
    args = parser.parse_args()
    results = run_protocol() if args.budget == "exact" else run_optional_purchase()
    if args.json:
        args.json.write_text(json.dumps(results, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
    for world, data in results["scenarios"].items():
        print(world, {a: round(v["net"]["mean"], 3) for a,v in data["summary"].items()})
        if args.budget == "exact":
            print("learned minus fixed", data["difference"], "minus periodic", data["difference_periodic"])
        else:
            print("actual label use", {a: v["labels"]["mean"] for a,v in data["summary"].items()})
            print("learned minus comparisons", data["learned_minus"])
