"""Online event representation for equal-budget probe timing.

python3 probe_event_state.py --seed 112000 --json probe-state-results.json
python3 probe_event_state.py --seed 124000 --json probe-state-validation.json
The simulator and all experiments use the Python standard library.
"""
import argparse
import json
from collections import deque
from concurrent.futures import ProcessPoolExecutor
from math import exp, log, sqrt, tanh
from pathlib import Path
from random import Random
from statistics import mean

from decision_returns import train
from probe_policy_learning import Timing, deploy
from stream_revaluation import mean_interval

VOCAB = ("probe", "reserve", "now", "here", "later", "second")
EXEC_START = len(VOCAB)
RECEIPT_START = EXEC_START + 9
EVENT_COUNT = RECEIPT_START + 8
DECAYS = (.90, .99)
HORIZON = 4
ACTOR_NORM = .04
AUX_STEP = .02
STRATEGIES = ("basic", "frozen", "learned")
CELLS = {mode + "_" + length: (mode, decay) for mode in STRATEGIES
         for length, decay in (("short", .8), ("long", .97))}
MASK = (1 << 64) - 1

def dot(a, b):
    return sum(x*y for x, y in zip(a, b))

def sigmoid(x):
    return 1/(1+exp(-x)) if x >= 0 else exp(x)/(1+exp(x))

def squared_norm(x):
    return sum(u*u for u in x)


class EventHistory:
    """Decayed event frequencies. Lazy updates are exactly the dense recurrence."""

    def __init__(self):
        self.t = 0
        self.last = [0] * EVENT_COUNT
        self.stored = [[0.] * EVENT_COUNT for _ in DECAYS]

    def add(self, event):
        self.t += 1
        dt = self.t - self.last[event]
        for row, decay in zip(self.stored, DECAYS):
            row[event] = row[event] * decay**dt + (1-decay)
        self.last[event] = self.t

    def snapshot(self):
        return tuple(tuple(v * decay**(self.t-last) for v, last in zip(row, self.last))
                     for row, decay in zip(self.stored, DECAYS))


class Predictor:
    """Train action-conditional return predictions and shared event embeddings."""

    def __init__(self):
        rng = Random(471)
        self.initial = tuple(tuple(rng.uniform(-1.,1.) for _ in range(EVENT_COUNT))
                             for _ in DECAYS)
        self.embeddings = [list(row) for row in self.initial]
        self.heads = [[0.] * (3+len(DECAYS)) for _ in (0,1)]

    def hidden(self, trace, frozen=False):
        embeddings = self.initial if frozen else self.embeddings
        return [tanh(dot(row, z)) for row,z in zip(embeddings,trace)]

    def outputs(self, context, trace):
        x = (*context, *self.hidden(trace))
        return tuple(dot(head, x) for head in self.heads)

    def fit(self, context, trace, action, prob, target):
        h = self.hidden(trace)
        x = (*context, *h)
        head = self.heads[action]
        coeffs = [head[3+k]*(1-u*u) for k,u in enumerate(h)]
        embedding_gradient_sq = sum(c*c*squared_norm(z) for c,z in zip(coeffs,trace))
        gradient_sq = squared_norm(x) + embedding_gradient_sq
        error = target - dot(head, x)
        delta = AUX_STEP*error/(2*prob*(1+gradient_sq))
        for row, z, c in zip(self.embeddings, trace, coeffs):
            for k, value in enumerate(z):
                row[k] += delta*c*value
        for k, value in enumerate(x):
            head[k] += delta*value
        return delta*delta*gradient_sq, delta*delta*embedding_gradient_sq


class EventActor:
    def __init__(self, arm, cfg, *, mode, decay, seed, example, step_length=ACTOR_NORM):
        self.mode, self.decay, self.cfg = mode, decay, cfg
        self.step_length = step_length
        self.history = EventHistory()
        self.predictor = Predictor()
        self.surface_rng = Random((seed ^ 0x9E3779B97F4A7C15) & MASK)
        self.weights = [0.]*4
        self.trace = [0.]*4
        self.pending = deque()
        self.audit_ids = {}
        self.log = [] if example else None
        self.windows = self.aux_count = self.nonzero_steps = 0
        self.step_squares = self.prob_squares = self.aux_squares = 0.
        self.joint_prob_squares = self.encoding_prob_squares = 0.
        self.pred_error = self.null_error = self.importance_sum = 0.
        self.contrast_sum = self.half_contrast_sum = self.adv_square = 0.
        self.embedding_squares = self.history_gap_squares = self.history_gain = 0.

    def observe_execution(self, group, setting, source, purchased):
        self.history.add(EXEC_START + 3*setting + source)
        if purchased:
            self.audit_ids[group] = (setting,source)
        if self.log is not None and group<=12:
            self.log.append(dict(group=group, role="runtime", executed=source, setting=setting))

    def observe_audit(self, label):
        setting, source = self.audit_ids.pop(label.origin)
        assert (setting,source) == (label.setting,label.action)
        event = RECEIPT_START + 4*(setting-1) + 2*(source-1) + label.cue_correct
        self.history.add(event)
        if self.log is not None and label.origin+3<=12:
            self.log.append(dict(group=label.origin+3, role="evaluator",
                                 origin=label.origin, source=source, correct=label.cue_correct))

    def features(self, setting, reuse, memory):
        # Only the observed prompt and event history enter the representation.
        # SourceMemory is kept by the common baseline. Its review count is private.
        self.context = (1., 2.*(setting==2)-1, 2.*reuse-1)
        self.snapshot = self.history.snapshot()
        self.q = self.predictor.outputs(self.context, self.snapshot)
        # Same predecision heads and prompt, with history embeddings set to zero.
        self.q_without_events = tuple(dot(head[:3], self.context)
                                      for head in self.predictor.heads)
        self.gap = self.q[1]-self.q[0]
        extra = 0.
        if self.mode == "learned":
            extra = tanh(self.gap)
        elif self.mode == "frozen":
            hidden = self.predictor.hidden(self.snapshot, frozen=True)
            extra = (hidden[0] - hidden[1])/2
        self.x = (*self.context, extra)
        return self.x

    def probability(self, x, window_index=0):
        return .1+.8*sigmoid(dot(self.weights, x))

    def choose(self, x, uniform, window_index=0):
        unit = sigmoid(dot(self.weights, x))
        self.p = .1+.8*unit
        self.action = int(uniform < self.p)
        coeff = (self.action-self.p)*.8*unit*(1-unit)/(self.p*(1-self.p))
        self.trace = [self.decay*t+coeff*v for t,v in zip(self.trace,x)]
        # Token 1 selects a family. Token 2 has a prefix-specific support. The
        # runtime schedules a pair only after a grammatical request is complete.
        first = 0 if self.action else 1
        variant = self.surface_rng.randrange(2)
        second = (2 if first==0 else 4) + variant
        self.history.add(first)
        self.history.add(second)
        executed_early = int((first,second) in ((0,2),(0,3)))
        assert executed_early == self.action
        if self.log is not None and window_index == 0:
            self.log.append(dict(group=1, role="agent", tokens=[VOCAB[first], VOCAB[second]],
                                 token_probabilities=[self.p if self.action else 1-self.p,.5],
                                 executed_timing=executed_early))
        return executed_early, self.p

    def observe_invoice(self, invoice):
        self.windows += 1
        residual = invoice-self.cfg.center
        norm = sqrt(squared_norm(self.trace))
        # A constant Euclidean increment isolates direction from update size.
        # Gradient normalization changes the estimator and its objective guarantees.
        before = self.probability(self.x)
        if norm > 1e-12 and abs(residual)>1e-10:
            step = (self.step_length if residual>0 else -self.step_length)/norm
            increment = [step*u for u in self.trace]
            self.weights = [w+dw for w,dw in zip(self.weights,increment)]
            self.nonzero_steps += 1
            self.step_squares += squared_norm(increment)
        after_actor = self.probability(self.x)
        self.prob_squares += (after_actor-before)**2
        self.joint_prob_squares += (after_actor-before)**2
        prob = self.p if self.action else 1-self.p
        self.pending.append((self.context,self.snapshot,self.action,prob,self.q,
                             self.q_without_events,residual))
        if len(self.pending) < HORIZON:
            return
        target = sum(item[-1] for item in self.pending)/HORIZON
        context, snapshot, action, prob, q, empty, _ = self.pending.popleft()
        importance = 1/(2*prob)
        self.pred_error += importance*(target-q[action])**2
        self.null_error += importance*target**2
        self.importance_sum += importance
        # Prospective loss improvement against the two heads' own no-action-gap
        # prediction. Distinguishes level prediction from branch discrimination.
        center = (q[0]+q[1])/2
        self.half_contrast_sum += importance*((target-center)**2 - (target-q[action])**2)
        predicted_gap = q[1]-q[0]
        self.adv_square += predicted_gap**2
        self.contrast_sum += predicted_gap*(target-center)*(1 if action else -1)/prob
        self.history_gain += importance*((target-empty[action])**2-(target-q[action])**2)
        self.history_gap_squares += (predicted_gap - (empty[1]-empty[0]))**2
        aux, embedding = self.predictor.fit(context,snapshot,action,prob,target)
        self.aux_squares += aux
        self.embedding_squares += embedding
        if self.mode == "learned":
            # Keep the original history fixed and recompute the probability after
            # both the actor step and the auxiliary event-representation update.
            new_q = self.predictor.outputs(self.context, self.snapshot)
            after_both = self.probability((*self.context, tanh(new_q[1]-new_q[0])))
            self.joint_prob_squares += (after_both-before)**2 - (after_actor-before)**2
            self.encoding_prob_squares += (after_both-after_actor)**2
        self.aux_count += 1

    def metrics(self):
        assert not self.audit_ids and self.aux_count == self.windows-HORIZON+1
        return dict(policy_rms=sqrt(self.step_squares/self.windows),
                    effective_updates=self.nonzero_steps,
                    probability_rms=sqrt(self.prob_squares/self.windows),
                    joint_probability_rms=sqrt(self.joint_prob_squares/self.windows),
                    encoding_probability_rms=sqrt(self.encoding_prob_squares/self.windows),
                    predictor_rms=sqrt(self.aux_squares/self.aux_count),
                    embedding_rms=sqrt(self.embedding_squares/self.aux_count),
                    history_gap_rms=sqrt(self.history_gap_squares/self.aux_count),
                    history_gain=self.history_gain/self.importance_sum,
                    prospective_mse=self.pred_error/self.importance_sum,
                    zero_mse=self.null_error/self.importance_sum,
                    gap_gain=self.half_contrast_sum/self.importance_sum,
                    gap_rms=sqrt(self.adv_square/self.aux_count),
                    average_gap_target_product=self.contrast_sum/self.aux_count)


def single(payload):
    initial, cfg, scenario, seed, long_step = payload
    rows = {}
    transcript = None
    for name, (mode, decay) in CELLS.items():
        actors = []
        def factory(arm, config):
            actor = EventActor(arm, config, mode=mode, decay=decay, seed=seed,
                               example=(name=="learned_short" and seed==cfg.seed),
                               step_length=long_step if decay==.97 else ACTOR_NORM)
            actors.append(actor)
            return actor
        run = deploy(initial, cfg, scenario, "learned", seed, actor_class=factory)
        actor, = actors
        assert run["n_audits"] == 400
        rows[name] = dict(seed=seed, net=run["total"], labels=run["n_audits"],
                          revisions=len(run["revisions"]), **actor.metrics())
        if actor.log is not None:
            transcript = actor.log
    return scenario, rows, transcript


CONTRASTS = {}
for base in ("basic","frozen"):
    CONTRASTS["learned_minus_"+base] = {"learned_short":.5,"learned_long":.5,
                                        base+"_short":-.5,base+"_long":-.5}
    CONTRASTS["interaction_"+base] = {"learned_short":-1.,"learned_long":1.,
                                     base+"_short":1.,base+"_long":-1.}
for mode in STRATEGIES:
    CONTRASTS["long_at_"+mode] = {mode+"_long":1.,mode+"_short":-1.}
CONTRASTS["long_average"] = {k:(1/3 if k.endswith("_long") else -1/3) for k in CELLS}


def functional_match(rows):
    """RMS over all decision windows, before and after updating on that window."""
    result = {}
    for mode in STRATEGIES:
        def pooled(cell):
            return sqrt(mean(r["joint_probability_rms"]**2 for r in rows[cell]))
        short, long = pooled(mode+"_short"), pooled(mode+"_long")
        result[mode] = dict(short=short, long=long, long_over_short=long/short)
    return result


def run(cfg, workers, long_step=ACTOR_NORM):
    initial = train()
    scenarios=("stable","reversal")
    payloads = [(initial,cfg,s,cfg.seed+i,long_step)
                for s in scenarios for i in range(cfg.repetitions)]
    data = {s:{name:[] for name in CELLS} for s in scenarios}
    examples = {}
    with ProcessPoolExecutor(workers) as pool:
        for scenario, rows, transcript in pool.map(single,payloads,chunksize=3):
            for name,row in rows.items():
                data[scenario][name].append(row)
            if transcript: examples[scenario] = transcript
    worlds = {}
    for scenario, group in data.items():
        summary = {name:{key:mean_interval([row[key] for row in rows])
                         for key in rows[0] if key!="seed"} for name,rows in group.items()}
        effects = {}
        for name, terms in CONTRASTS.items():
            effects[name] = {key:mean_interval([sum(c*group[k][i][key] for k,c in terms.items())
                                                for i in range(cfg.repetitions)])
                            for key in ("net","gap_gain","probability_rms")}
        worlds[scenario] = dict(summary=summary, contrasts=effects, streams=group,
                                example=examples.get(scenario,[]), functional_match=functional_match(group))
    settings = {k:getattr(cfg,k) for k in ("horizon","window","change_at","labels_per_window",
                                           "repetitions","seed","probability_floor","center")}
    return dict(config=settings,credit_horizon=HORIZON,event_decays=DECAYS,
                actor_step_length=ACTOR_NORM,aux_step=AUX_STEP,
                long_actor_step_length=long_step,
                event_codebook=dict(generated=VOCAB,execute="6+3*s+a",
                                    receipt="15+4*(s-1)+2*(a-1)+correct"),
                arms={k:dict(mode=v[0],beta=v[1]) for k,v in CELLS.items()},worlds=worlds)


def calibrate(cfg, workers):
    """Choose one long-trace step length using only functional increments."""
    candidates = (.040,.046,.050,.052,.054,.056,.058,.062,.066,.070)
    records = []
    for step in candidates:
        result = run(cfg, workers, long_step=step)
        ratios = {}
        for world, data in result["worlds"].items():
            for mode, paired in data["functional_match"].items():
                ratios[world+":"+mode] = paired["long_over_short"]
        records.append(dict(step=step, ratios=ratios,
                            max_log_ratio_error=max(abs(log(r)) for r in ratios.values())))
    chosen = min(records, key=lambda row:row["max_log_ratio_error"])
    return dict(seed=cfg.seed, repetitions=cfg.repetitions, calibration_metric="joint_probability_rms",
                selection="minimize worst absolute log ratio across 2 environments x 3 state variants",
                candidates=records, long_actor_step_length=chosen["step"])


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--seed",type=int,default=112000)
    p.add_argument("--repetitions",type=int,default=96)
    p.add_argument("--workers",type=int,default=4)
    p.add_argument("--json",type=Path,required=True)
    group=p.add_mutually_exclusive_group()
    group.add_argument("--calibrate",action="store_true")
    group.add_argument("--use-calibration",type=Path)
    args=p.parse_args()
    if args.repetitions<2 or args.workers<1:
        p.error("Use at least two independent streams and one worker.")
    cfg=Timing(seed=args.seed,repetitions=args.repetitions)
    if args.calibrate:
        result=calibrate(cfg,args.workers)
    elif args.use_calibration:
        record=json.loads(args.use_calibration.read_text())
        if max(args.seed,record["seed"]) < min(args.seed+args.repetitions,
                                                record["seed"]+record["repetitions"]):
            p.error("Calibration and evaluation streams must be disjoint.")
        result=run(cfg,args.workers,record["long_actor_step_length"])
        result["functional_calibration"]=args.use_calibration.name
    else:
        result=run(cfg,args.workers)
    args.json.write_text(json.dumps(result,ensure_ascii=False,indent=2)+"\n")
    for s,world in result.get("worlds",{}).items():
        print(s,{k:round(v["net"]["mean"],3) for k,v in world["summary"].items()})
        for k,v in world["contrasts"].items(): print(k,v["net"])
