"""Enumerate the two long-sequence examples and an interacting variable-length policy.

Run with Python 3.8+; no external dependencies or model downloads.
"""

from itertools import product
from math import exp, isclose


def logistic(x):
    return 1 / (1 + exp(-x))


def check_long_credit():
    for length in range(1, 13):
        paths = list(product((0, 1), repeat=length))
        mass = 1 / len(paths)
        estimates = [(w[0] - 0.5) * sum(i - 0.5 for i in w) for w in paths]
        mean = mass * sum(estimates)
        variance = mass * sum((estimate - mean) ** 2 for estimate in estimates)
        assert isclose(mean, 1 / 4)
        assert isclose(variance, (length - 1) / 16, abs_tol=1e-14)

        for prob in (0.3, 0.5, 0.8):
            # Condition on the first choice and enumerate only the suffix.
            values = []
            for first in (0, 1):
                value = 0.0
                for suffix in product((0, 1), repeat=length - 1):
                    ones = sum(suffix)
                    likelihood = prob ** ones * (1 - prob) ** (len(suffix) - ones)
                    value += likelihood * all((first,) + suffix)
                values.append(value)
            assert isclose(values[1] - values[0], prob ** (length - 1))


def paths_and_scores(theta):
    """Yield probability, return, and action-score entries including prior costs.

    Bit zero at the first two positions means a sampled EOS. At the last position
    both bits are answer tokens and the external length limit ends generation.
    An environment bit arrives between the first and second action.
    """
    def choices(features):
        prob = logistic(sum(w * x for w, x in zip(theta, features)))
        for token in (0, 1):
            likelihood = prob if token else 1 - prob
            score = tuple((token - prob) * x for x in features)
            yield token, likelihood, score

    def terminal(mass, success, cost, entries):
        for outcome in (0, 1):
            yield mass * (success if outcome else 1 - success), outcome - cost, entries

    for request, mass, score in choices((1, 0, 0)):
        entries = [(score, 0.0, not request)]
        if not request:
            yield from terminal(mass, 0.37, 0.0, entries)
            continue
        cost = 0.14
        for obs, chance in ((0, 0.27), (1, 0.73)):
            sign = 2 * obs - 1
            for extend, likelihood, next_score in choices((sign, 1, 0)):
                next_mass = mass * chance * likelihood
                next_entries = entries + [(next_score, -cost, not extend)]
                if not extend:
                    yield from terminal(next_mass, 0.24 + 0.3 * obs, cost, next_entries)
                    continue
                for answer, last_prob, last_score in choices((0, sign, 1)):
                    success = 0.92 if answer == obs else 0.13
                    yield from terminal(next_mass * last_prob, success, cost,
                                        next_entries + [(last_score, -cost, False)])


def expected_return(theta):
    return sum(mass * total_return for mass, total_return, _ in paths_and_scores(theta))


def check_interacting_gradient():
    max_error = 0.0
    for theta in product((-0.8, 0.0, 0.6), repeat=3):
        exact, reward_to_go, missed_stop = ([0.0] * 3 for _ in range(3))
        path_mass = 0.0
        for mass, total_return, entries in paths_and_scores(theta):
            path_mass += mass
            for score, previous_reward, is_stop in entries:
                for k, component in enumerate(score):
                    exact[k] += mass * total_return * component
                    reward_to_go[k] += mass * (total_return - previous_reward) * component
                    if not is_stop:
                        missed_stop[k] += mass * total_return * component
        assert isclose(path_mass, 1.0)
        for k in range(3):
            plus, minus = list(theta), list(theta)
            plus[k] += 0.00001
            minus[k] -= 0.00001
            fd = (expected_return(plus) - expected_return(minus)) / 0.00002
            error = max(abs(exact[k] - fd), abs(reward_to_go[k] - fd))
            max_error = max(max_error, error)
            assert error < 1e-9, (theta, k, fd, exact[k], reward_to_go[k])
        assert max(abs(x - y) for x, y in zip(exact, missed_stop)) > 0.01
    return max_error


if __name__ == "__main__":
    check_long_credit()
    err = check_interacting_gradient()
    print("Lengths 1–12 passed. 27 parameter triples checked on the interaction tree.")
    print(f"Maximum gradient error versus finite differences: {err:.2e}.")
