"""Plot the two estimates obtained on the same training data at matched policy KL."""
from argparse import ArgumentParser
from html import escape
from io import StringIO
import json
from math import ceil, floor, isclose
from pathlib import Path
import re
from statistics import mean

import matplotlib
matplotlib.use("svg")
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle

HERE = Path(__file__).resolve().parent
TITLE = "局部估值精度与完整策略回报的配对变化"
CSS = """
#credit-paired-outcomes {border-block:1px solid #b7cbc3;margin:1.5rem 0;padding:.75rem 0 .5rem}
#credit-paired-outcomes p {margin:.25em 0;line-height:1.6}
#credit-paired-outcomes .cpr-title {font-size:1.07rem;font-weight:700}
#credit-paired-outcomes .cpr-lede,#credit-paired-outcomes .cpr-count {font-size:.88rem}
#credit-paired-outcomes .cpr-panels {display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:1rem;margin:.6rem 0}
#credit-paired-outcomes .cpr-panel {min-width:0;border-top:1px solid #ccd7ce;padding-top:.3rem}
#credit-paired-outcomes .cpr-panel h5 {margin:0 0 .3em;font-size:.96rem;color:#274f51}
#credit-paired-outcomes .cpr-y,#credit-paired-outcomes .cpr-x {font-size:.79rem;color:#374f53;margin:.10em 0}
#credit-paired-outcomes .cpr-x {text-align:center}
#credit-paired-outcomes svg {display:block;width:100%;height:auto}
#credit-paired-outcomes svg text {font-family:var(--sans)!important}
#credit-paired-outcomes .cpr-count b {color:#954820}
#credit-paired-outcomes figcaption {padding:.4rem 0 0;border-top:1px solid #d4dfda;font-size:.82rem}
@media(max-width:650px) {#credit-paired-outcomes .cpr-panels{grid-template-columns:1fr;gap:.7rem}#credit-paired-outcomes .cpr-panel{max-width:460px;width:100%;margin:auto}}
"""


def paired_observations(case):
    """Both y values are exact prompt-distribution returns relative to the same old policy."""
    points = []
    for row in case["seeds_detail"]:
        original = row["masked_branch"]
        branch = row["methods"]["branch"]["metrics"]
        if any(not isclose(metrics["trajectory_kl"], .01, abs_tol=1e-8)
               for metrics in (branch, original)):
            raise ValueError(f'Unmatched trajectory KL at seed {row["seed"]}')
        x = 100 * (original["selected_rmse"] - branch["selected_rmse"])
        y = 100 * (branch["gain"] - original["gain"])
        points.append((row["seed"], x, y))
    if len({seed for seed, _, _ in points}) != len(points):
        raise ValueError("Training seeds must identify unique comparisons")
    # The independently stored paired summaries use the opposite sign for RMSE.
    for column, metric, sign in [(1, "selected_rmse", -1), (2, "gain", 1)]:
        reported = case["mask_branch_feedback"][metric]["branch_minus_masked"]["mean"]
        if not isclose(mean(p[column] for p in points), 100 * sign * reported, abs_tol=1e-6):
            raise ValueError(f"The paired {metric} contrast disagrees with the results file")
    return points


def common_limits(cases):
    x = [p[1] for points in cases.values() for p in points]
    y = [p[2] for points in cases.values() for p in points]
    return (
        (5 * floor(min(0, min(x)) / 5) - 2, 5 * ceil(max(0, max(x)) / 5) + 2),
        (.05 * floor(min(0, min(y)) / .05) - .012, .05 * ceil(max(0, max(y)) / .05) + .012),
    )


def render_scatter(points, case_name, limits):
    (xmin, xmax), (ymin, ymax) = limits
    fig = plt.figure(figsize=(3.35, 2.04))
    axis = fig.add_axes([.12, .135, .86, .84])
    axis.set(xlim=(xmin, xmax), ylim=(ymin, ymax), axisbelow=True)
    axis.set_xticks([-10, 0, 20, 40, 60], labels=["−10", "0", "20", "40", "60"])
    axis.set_yticks([-.2, 0, .2, .4, .6], labels=["−0.2", "0", "+0.2", "+0.4", "+0.6"])
    axis.tick_params(length=0, pad=3, labelsize=9, colors='#395456')
    for spine in axis.spines.values():
        spine.set_visible(False)
    axis.grid(color="#d8e0db", linewidth=.55)
    axis.add_patch(Rectangle((0, ymin), xmax, -ymin, color="#fff0e2", zorder=0))
    axis.axvline(0, color="#5b6f70", linewidth=.85)
    axis.axhline(0, color="#455f62", linewidth=.85)
    # Keep equal marker areas and all observations, including tails above 0.6.
    groups = {True: [], False: []}
    for seed, x, y in points:
        groups[x > 0 and y < 0].append((seed, x, y))
    for highlighted, rows in groups.items():
        artist = axis.scatter([x for _, x, _ in rows], [y for _, _, y in rows],
                              s=11, color="#a95321" if highlighted else "#217068",
                              linewidths=0, alpha=.5, zorder=3)
        artist.set_gid("region-low" if highlighted else "region-other")
    target = StringIO()
    fig.savefig(target, format="svg", transparent=True)
    plt.close(fig)
    svg = target.getvalue()
    svg = svg[svg.index("<svg "):svg.index("</svg>") + 6]
    svg = re.sub(r"<(?:metadata|style)\b[^>]*>.*?</(?:metadata|style)>|<!--.*?-->", "", svg, flags=re.S)
    svg = re.sub(r'\bid="([^"]+)"', lambda m: f'id="cpr-{case_name}-{m[1]}"', svg)
    svg = re.sub(r'(url\(#|href="#)([\w.:-]+)', lambda m: f'{m[1]}cpr-{case_name}-{m[2]}', svg)
    # Place a data tooltip on the actual vector mark. Coordinates are unchanged.
    for highlighted, rows in groups.items():
        region = "region-low" if highlighted else "region-other"
        start = svg.index(f'<g id="cpr-{case_name}-{region}">')
        end = svg.index('</g>\n   </g>', start)
        subset = svg[start:end]
        marks = re.compile(r"<use\b[^>]*?/>")
        if len(marks.findall(subset)) != len(rows):
            raise ValueError("Each seed must correspond to one plotted mark")
        ordered = iter(rows)
        def annotate(mark):
            seed, x, y = next(ordered)
            return (mark.group()[:-2] + f' data-seed="{seed}"><title>训练 {seed}，'
                    f'局部 RMSE 降低 {x:+.3f}，完整通过率改变 {y:+.4f} 个百分点'
                    '</title></use>')
        svg = svg[:start] + marks.sub(annotate, subset) + svg[end:]
    description = (f"横轴表示局部 RMSE 降低，纵轴表示完整策略通过率的配对改变量。"
                   f"{len(points)} 次训练中，右下象限有 {len(groups[True])} 次。")
    return svg.replace("<svg ", f'<svg role="img" aria-label="{escape(description)}" ', 1)


def render(data):
    cases = {name: paired_observations(case) for name, case in data["scenarios"].items()}
    limits = common_limits(cases)
    panels = []
    for case_name, points in cases.items():
        n = len(points)
        improving_local = sum(x > 0 for _, x, y in points)
        opposite = sum(x > 0 and y < 0 for _, x, y in points)
        panel_title = "同一选词在不同提示上作用同向" if case_name == "aligned" else "同一选词在不同提示上作用异向"
        chart = render_scatter(points, case_name, limits)
        panels.append(f'''<div class="cpr-panel"><h5>{panel_title}</h5>
<p class="cpr-y">完整策略通过率改变量（百分点）↑</p>{chart}
<p class="cpr-x">局部价值差的 RMSE 降低（百分点）→</p>
<p class="cpr-count">局部误差降低 {improving_local}/{n} 次。其中 <b>{opposite} 次落在右下方</b>，占全部训练的 {opposite/n:.1%}（{opposite}/{n}）。</p></div>''')
    return f'''<figure id="credit-paired-outcomes" aria-labelledby="cpr-title"><style>{CSS}</style>
<p class="cpr-title" id="cpr-title">{TITLE}</p>
<p class="cpr-lede">每个点是一次训练中的两次更新之差。两次使用同一批数据、同一对前缀。一次用从头生成的轨迹估值，另一次将这两处估值换成独立续写的结果。两次更新的整轨迹 KL 均为 0.01 nat。</p>
<div class="cpr-panels">{''.join(panels)}</div>
<figcaption>横轴为正表示局部估值更准，纵轴为正表示从原始提示出发的完整通过率更高。浅橙色标出局部估值更准、完整通过率反而下降的训练。共同的 KL 约束允许整体步长随更新方向改变。两幅图共用坐标范围，点的深浅来自重叠。<a href="reader-source/credit-budget-results.json">逐次训练结果</a></figcaption></figure>
'''


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, default=HERE / "credit-budget-results.json")
    parser.add_argument("--output", type=Path, default=HERE / "credit-paired-outcomes.html")
    args = parser.parse_args()
    with matplotlib.rc_context({'svg.fonttype': 'none', 'svg.hashsalt': 'ch13-credit-pairs'}):
        args.output.write_text(render(json.loads(args.input.read_text())), encoding='utf-8')
