"""独立重跑、组内标准化与执行预算。运行 python3 check_group_sampling.py。"""

from itertools import combinations, product
from math import comb, isclose, prod, sqrt
from statistics import mean


def standardized_multiplier(probability, size, epsilon=0.0):
    """按二项分布对组内通过数 m 取期望，返回相对原成功率梯度的倍率。"""
    total = 0.
    for passes in range(1, size):
        fraction = passes / size
        probability_of_group = (comb(size, passes) * probability**passes
                                * (1-probability)**(size-passes))
        sample_sd = sqrt(size * fraction * (1-fraction) / (size-1))
        total += probability_of_group * fraction * (1-fraction) / (sample_sd+epsilon)
    return total / (probability * (1-probability))


def compare_estimators(size, p_action):
    """一项二元选择引起随机验收。枚举全部 K 条运行以核对梯度和方差。"""
    states = list(product((0, 1), repeat=2))  # (模型选择，独立验收)
    pass_given_action = (.24, .70)
    probability = {}
    for action, result in states:
        passed = pass_given_action[action]
        probability[action, result] = ((p_action if action else 1-p_action) *
                                       (passed if result else 1-passed))
    def score(state):
        return state[0] - p_action  # 相对行动 logit 的对数概率梯度
    def paired(first, second):
        return .5 * (score(first)-score(second)) * (first[1]-second[1])
    exact = p_action * (1-p_action) * (pass_given_action[1]-pass_given_action[0])
    first_order = {a: sum(probability[b]*paired(a,b) for b in states)-exact for a in states}
    v1 = sum(probability[a]*first_order[a]**2 for a in states)
    v2 = sum(probability[a]*probability[b]*(paired(a,b)-exact-first_order[a]-first_order[b])**2
             for a,b in product(states, repeat=2))
    empirical_variance = empirical_standardized_gradient = 0.
    for runs in product(states, repeat=size):
        likelihood = prod(probability[r] for r in runs)
        total_passes = sum(r[1] for r in runs)
        centered = mean(score(r)*(r[1]-total_passes/size) for r in runs)
        loo = mean(score(r)*(r[1]-(total_passes-r[1])/(size-1)) for r in runs)
        assert isclose(loo,mean(paired(a,b) for a,b in combinations(runs,2)),abs_tol=1e-12)
        empirical_variance += likelihood * (loo-exact)**2
        if 0 < total_passes < size:
            fraction = total_passes/size
            sd = sqrt(size*fraction*(1-fraction)/(size-1))
            empirical_standardized_gradient += likelihood * centered/sd
    p_success = sum(probability[a,1] for a in (0,1))
    assert isclose(empirical_standardized_gradient,
                   standardized_multiplier(p_success,size)*exact,abs_tol=1e-12)
    assert isclose(empirical_variance,4*v1/size+2*v2/(size*(size-1)),abs_tol=1e-12)


def check_response_length():
    """等成功率的两个首词。只改变各类回答的生成长度，枚举留一估计器。"""
    runs = [(1, 1, 2), (1, 0, 6), (0, 1, 6), (0, 0, 2)]
    summed, response_means = [], []
    for first, second in product(runs, repeat=2):
        contributions = []
        normalized = []
        for (word, passed, length), (_, other_passed, _) in ((first, second), (second, first)):
            term = (word - 0.5) * (passed - other_passed)
            contributions.append(term)
            normalized.append(term / length)
        summed.append(mean(contributions))
        response_means.append(mean(normalized))
    assert isclose(mean(summed), 0.0, abs_tol=1e-12)
    assert isclose(mean(response_means), 1 / 24, abs_tol=1e-12)


def check_prefix_coverage():
    """从组根抽取八次，按各分支计数做多项分布枚举。"""
    size, reach, choose_a = 8, 0.02, 0.5
    pa, pb = reach * choose_a, reach * (1 - choose_a)
    both = 0.0
    for count_a in range(1, size):
        for count_b in range(1, size - count_a + 1):
            other = size - count_a - count_b
            ways = comb(size, count_a) * comb(size - count_a, count_b)
            both += ways * pa**count_a * pb**count_b * (1-reach)**other
    by_complement = 1 - (1-pa)**size - (1-pb)**size + (1-reach)**size
    assert isclose(both, by_complement, abs_tol=1e-12)
    return both


def check_completed_only():
    """首词选择影响完成与成功。对完成者通过率做独立有限差分。"""
    complete = (0.85, 0.25)
    passed_given_complete = (0.40, 0.80)
    def fraction_on_time(probability):
        joint = [(1-probability) * complete[0], probability * complete[1]]
        return sum(j * z for j,z in zip(joint, passed_given_complete)) / sum(joint)
    probability = 0.37
    point = fraction_on_time(probability)
    mass = sum((1-probability, probability)[a] * complete[a] for a in (0,1))
    score_gradient = sum(
        (1-probability, probability)[a] * complete[a] *
        (a-probability) * (passed_given_complete[a]-point) for a in (0,1)
    ) / mass
    delta = 1e-5
    derivative = (fraction_on_time(probability+delta)-fraction_on_time(probability-delta))/(2*delta)
    assert isclose(score_gradient, probability * (1-probability) * derivative, rel_tol=1e-8)


if __name__ == '__main__':
    check_response_length()
    check_completed_only()
    print('八条运行覆盖深处两个分支的概率', round(check_prefix_coverage(), 8))
    for group_size in (2,3,4,5,6):
        for action_probability in (.03,.25,.7,.95):
            compare_estimators(group_size,action_probability)
        print('K =',group_size,'p 为 .05/.50/.95 时的标准化梯度倍率',
              [round(standardized_multiplier(p,group_size),4) for p in (.05,.5,.95)])
