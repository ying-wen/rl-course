"""Recover the local error decomposition and whole-policy gains from saved runs."""

import argparse
import json
import math
from pathlib import Path
from statistics import mean, variance


def analyze(protocol, scenario, method):
    routes = protocol["old_route1"]
    stages = len(protocol["positions"])
    runs = [row["methods"][method] for row in scenario["seeds_detail"]]
    squared_bias = sampling_variance = 0.0
    for c, route_one in enumerate(routes):
        for r, reach in enumerate((1 - route_one, route_one)):
            for j in range(stages):
                column = (2 * c + r) * stages + j
                truth = scenario["gap_at_last"][c][r] if j == stages - 1 else 0.0
                errors = [run["prefix_differences"][column] - truth for run in runs]
                weight = reach / (len(routes) * stages)
                v = variance(errors)
                # Remove finite-seed variance from the squared average error.
                squared_bias += weight * (mean(errors) ** 2 - v / len(runs))
                sampling_variance += weight * v

    max_error = 0.0
    for run in runs:
        new = run["new_probabilities"]
        gain = 0.0
        for c, (old_route, base) in enumerate(zip(routes, protocol["base"])):
            gain += (new[c] - old_route) * (base[1] - base[0]) / len(routes)
            for r, reach in enumerate((1 - new[c], new[c])):
                column = (2 * c + r) * stages + stages - 1
                movement = new[len(routes) + column] - protocol["old_local_action1"]
                gain += reach * movement * scenario["gap_at_last"][c][r] / len(routes)
        max_error = max(max_error, abs(gain - run["metrics"]["gain"]))
    # Source JSON rounds probabilities to ten decimal places.
    if not math.isfinite(max_error) or max_error >= 1e-8:
        raise ValueError(f"Whole-policy gain disagrees for {method}: {max_error}")
    return squared_bias, sampling_variance, max_error


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("data", type=Path, nargs="?",
                        default=Path(__file__).with_name("credit-budget-results.json"))
    data = json.loads(parser.parse_args().data.read_text())
    for name, scenario in data["scenarios"].items():
        for method in ("grpo", "branch", "critic"):
            bias, var, error = analyze(data["protocol"], scenario, method)
            print(f"{name:8} {method:6} squared bias {bias: .6f}, "
                  f"sampling variance {var:.6f}, max gain residual {error:.2e}")
