"""第13章：精确枚举与轨迹记账。运行：python3 check_multiturn_estimators.py
仅使用 Python 标准库；不需要模型或训练日志。
"""
from itertools import product
from math import exp, isclose, prod
from statistics import mean


def close(x, y):
    assert isclose(x, y, abs_tol=1e-9, rel_tol=1e-7), (x, y)


def group_baselines(p=.27, k=4):
    """动作是伯努利变量，奖励就是动作；对其 logit 求导。"""
    plain = centered = leave_one_out = mixed = 0.
    for actions in product((0, 1), repeat=k):
        prob = prod(p if a else 1-p for a in actions)
        avg = mean(actions)
        mixed += prob * (0 < avg < 1)
        for a in actions:
            weighted_score = prob * (a - p) / k
            plain += weighted_score * a
            centered += weighted_score * (a - avg)
            leave_one_out += weighted_score * (a - (k * avg - a) / (k - 1))
    close(plain, p * (1-p))
    close(centered, (1-1/k)*plain)
    close(leave_one_out, plain)
    close(mixed, 1-p**k-(1-p)**k)
    return plain, centered, leave_one_out


def token_or_message():
    """同一条含两个所选词、优势为一的消息：检验一阶局部等价。"""
    def terms(x):
        p = 1/(1+exp(-x))
        r = p / .5  # 两位置共享 logit，旧 logit 为零；两次均取 1
        clip = lambda u: min(u, 1.2)  # 正优势的 PPO 上侧裁剪
        return clip(r*r), 2*clip(r)
    h = 1e-5
    gp = [(a-b)/(2*h) for a,b in zip(terms(h),terms(-h))]
    close(gp[0], gp[1])
    # 比较相对旧参数的变化；两种代理的常数项不同。
    old, now = terms(0), terms(.3)
    assert abs((now[0]-old[0]) - (now[1]-old[1])) > .05
    return gp


def masked_gae(mask, rewards, v, lam, tail=0.):
    """按生成位置倒推，gamma=1；输出未白化的优势，允许显式传入尾价值。"""
    next_value, next_adv = tail, 0.
    result = [None] * len(mask)
    for i in reversed(range(len(mask))):
        if mask[i]:
            next_adv = rewards[i] + next_value - v[i] + lam * next_adv
            next_value = v[i]
            result[i] = next_adv
    return result


def event_bookkeeping():
    # [生成请求，工具返回，再次生成]。第一项行动费用为 1；最后验收给 3。
    mask, v = [1,0,1], [0.,0.,0.]
    posted_on_tool = masked_gae(mask,[0.,-1.,3.],v,1.)
    booked_on_action = masked_gae(mask,[-1.,0.,3.],v,1.)
    close(posted_on_tool[0],3.)
    close(booked_on_action[0],2.)
    # 提前切断记录，真实后续的条件价值是 3。
    close(masked_gae([1],[-1.],[0.],1.,tail=3.)[0],2.)
    close(masked_gae([1],[-1.],[0.],1.,tail=0.)[0],-1.)
    return posted_on_tool[0], booked_on_action[0]


if __name__ == "__main__":
    for k in (2,3,4,7):
        print("组大小、原梯度、自含基线、留一基线：", k, group_baselines(k=k))
    print("旧参数处：整句与逐词裁剪代理的梯度：", token_or_message())
    print("将费用留在被跳过的观测位 / 归给产生费用的行动：", event_bookkeeping())
