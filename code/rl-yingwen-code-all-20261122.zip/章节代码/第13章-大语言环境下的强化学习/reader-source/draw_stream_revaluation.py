"""根据 stream_revaluation.py 的 JSON 结果重绘第 13 章的单流实验图。"""
import argparse
from html import escape
import json
import math
from pathlib import Path


COLORS = {"ink": "#173f46", "learn": "#006d68", "cost": "#a05230", "grid": "#cad5d1"}


def nice_tick(span):
    rough = max(span, .001) / 4
    floor = 10 ** math.floor(math.log10(rough))
    return min((1, 2, 2.5, 5, 10), key=lambda n: abs(n - rough / floor)) * floor


def number(x):
    return f"{x:g}".replace("-", "−")


def chart(series, change, xmax, ylabel, description):
    """同一批数值按两种图幅绘制。线型和颜色同时编码策略。"""
    values = [y for _, points, _, _ in series for _, y in points] + [0.]
    unit = nice_tick(max(values) - min(values))
    low = math.floor(min(values) / unit) * unit
    high = max(low + unit, math.ceil(max(values) / unit) * unit)
    figures = []
    for mode, width, height in (("wide", 612, 199), ("narrow", 307, 181)):
        left, right, top, bottom = 42, width-12, 30, height-39
        xp = lambda t: left + t / xmax * (right-left)
        yp = lambda v: bottom-(v-low)/(high-low)*(bottom-top)
        parts = [f'<svg class="sr-{mode}" viewBox="0 0 {width} {height}" role="img" aria-label="{escape(description)}">',
                 f'<text class="sr-axis-title" x="{left}" y="16">{escape(ylabel)}</text>']
        count = round((high-low)/unit)
        for i in range(count+1):
            val = low + i * unit
            y = yp(val)
            style = ' class="sr-zero"' if abs(val) < 1e-8 else ' class="sr-grid"'
            parts.append(f'<line{style} x1="{left}" y1="{y:.1f}" x2="{right}" y2="{y:.1f}"/>')
            parts.append(f'<text class="sr-tick" x="{left-6}" y="{y+4:.1f}" text-anchor="end">{number(val)}</text>')
        for tick in (0, xmax//4, xmax//2, 3*xmax//4, xmax):
            x = xp(tick)
            align = "end" if tick == xmax else "middle"
            parts.append(f'<path class="sr-grid" d="M{x:.1f} {bottom}v4"/>')
            parts.append(f'<text class="sr-tick" x="{x:.1f}" y="{bottom+18}" text-anchor="{align}">{tick}</text>')
        parts.append(f'<text class="sr-tick" x="{right}" y="{height-1}" text-anchor="end">部署进度（委托组）</text>')
        if change is not None:
            x = xp(change)
            parts.append(f'<line class="sr-change" x1="{x:.2f}" x2="{x:.2f}" y1="{top}" y2="{bottom}"/>')
            parts.append(f'<text class="sr-tick" x="{x+4:.2f}" y="{top+10}">反转</text>')
        for label, points, col, dashed in series:
            assert len(points) > 1 and all(math.isfinite(y) for _, y in points), label
            assert points[0][0] == 0 and points[-1][0] == xmax, label
            coords = " ".join(f"{xp(t):.2f},{yp(y):.2f}" for t,y in points)
            dash = ' stroke-dasharray="5 3"' if dashed else ''
            parts.append(f'<polyline points="{coords}" fill="none" stroke="{col}"{dash} stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><title>{escape(label)}</title></polyline>')
        figures.append(''.join(parts)+'</svg>')
    return ''.join(figures)


STYLE = """
<style>
.stream-reval {--sr-ink:#173f46;--sr-learn:#006d68;--sr-red:#a05230;--sr-grid:#cad5d1;container-type:inline-size;color:#213a3e;background:#fffefa;border:1px solid var(--sr-grid);border-top:3px solid var(--sr-learn);margin:1.2rem 0;padding:.88rem clamp(.56rem,2.8vw,1.1rem);font: .94rem/1.55 var(--sans,sans-serif)}
.stream-reval .sr-title {margin:0 0 .25rem;font:700 1.24rem/1.48 var(--serif,serif);color:var(--sr-ink)}
.stream-reval .sr-note, .stream-reval figcaption {font: .87rem/1.6 var(--sans,sans-serif);color:#4b5d60}
.stream-reval p {margin:.32rem 0 .58rem;line-height:1.6}
.stream-reval .sr-part {margin:.92rem 0 .28rem;padding:.56rem 0 0;border-top:1px solid var(--sr-grid);font:660 1.01rem/1.52 var(--sans,sans-serif);color:var(--sr-ink)}
.stream-reval .sr-pane {min-width:0}
.stream-reval svg {display:block;width:100%;max-width:none;height:auto}
.stream-reval svg text {font:14px var(--sans,sans-serif);fill:var(--sr-ink)}
.stream-reval svg .sr-tick {font-size:12px;fill:#40595d}
.stream-reval svg .sr-axis-title {font-size:13px}
.stream-reval svg .sr-grid {stroke:var(--sr-grid);stroke-width:1}
.stream-reval svg .sr-zero {stroke:#617679;stroke-width:1.25}
.stream-reval svg .sr-change {stroke:#596c72;stroke-width:1;stroke-dasharray:2 3}
.stream-reval .sr-narrow {display:none}
.stream-reval .sr-legend {display:flex;gap:.8rem;flex-wrap:wrap;font-size:.84rem;align-items:center;margin:.4rem 0 .2rem}
.stream-reval .sr-legend span {display:inline-flex;align-items:center;gap:.25rem}
.stream-reval .sr-legend i {display:inline-block;border-top:3px solid var(--sr-learn);width:1.55rem}
.stream-reval .sr-legend .sr-probe {border-top:3px dashed var(--sr-red)}
.stream-reval fieldset {border:0;padding:0;margin:.35rem 0}
.stream-reval legend {font-size:.82rem;color:#4b5d60;padding:0}
.stream-reval label {display:inline-flex;align-items:center;background:#f4f5f1;border:1px solid #adbdb9;border-radius:3px;gap:.25rem;padding:.25rem .45rem;font-size:.86rem;margin:.12rem .22rem .08rem 0;cursor:pointer}
.stream-reval label:has(:checked) {background:#deede7;border-color:#47776d}
.stream-reval input {accent-color:var(--sr-learn);margin:0}
.stream-reval .sr-stationary {display:none}
.stream-reval:has(#sr-static:checked) .sr-stationary {display:block}
.stream-reval:has(#sr-static:checked) .sr-changing {display:none}
.stream-reval figcaption {border-top:1px solid var(--sr-grid);margin-top:.68rem;padding-top:.45rem}
.stream-reval .sr-delay {margin:.58rem 0;padding:.42rem .56rem;background:#eff4f0}
.stream-reval .sr-lane {display:grid;grid-template-columns:minmax(6.5rem,1fr) minmax(1rem,.38fr) minmax(7.2rem,1.25fr);align-items:center;column-gap:.5rem;padding:.27rem 0;font-size:.9rem}
.stream-reval .sr-connector {display:block;border-top:1.5px dashed #658379;position:relative}
.stream-reval .sr-connector::after {content:"";position:absolute;right:0;top:-3.6px;width:5px;height:5px;border:solid #658379;border-width:1.5px 1.5px 0 0;transform:rotate(45deg)}
.stream-reval .sr-block {padding:.38rem 0 .47rem;display:grid;grid-template-columns:minmax(7.6rem,1.4fr) minmax(6rem,1fr);align-items:center;gap:.3rem .65rem}
.stream-reval .sr-block+.sr-block {border-top:1px dotted var(--sr-grid)}
.stream-reval .sr-block h5 {font:650 .94rem/1.55 var(--sans,sans-serif);color:var(--sr-ink);margin:0}
.stream-reval .sr-block .sr-stat {color:#40595d;font-size:.82rem}
.stream-reval .sr-pair-bar {display:flex;height:1rem;border:1px solid #78948a;overflow:hidden}
.stream-reval .sr-better {background:#006d68}
.stream-reval .sr-worse {background:repeating-linear-gradient(135deg,#fffefa 0,#fffefa 3px,#9c553a 3px,#9c553a 5px)}
.stream-reval .sr-tie {background:#e6eaeb}
.stream-reval .sr-key {display:inline-block;width:.72em;height:.72em;border:1px solid #70807e;vertical-align:0}
.stream-reval .sr-decision {font-size:.88rem;color:var(--sr-ink)}
.stream-reval .sr-pair-legend {font-size:.8rem;color:#485c5e}
.stream-reval .sr-col {padding:.2rem .06rem;font-variant-numeric:tabular-nums}
.stream-reval .sr-state {border-left:3px solid var(--sr-learn);padding:.2rem .55rem;background:#f1f6f2}
@container(max-width:21rem) {.stream-reval .sr-lane{grid-template-columns:minmax(4rem,1fr) .8rem minmax(5rem,1.2fr);column-gap:.22rem}.stream-reval .sr-block {grid-template-columns:1fr}}
@container(max-width:28rem) {.stream-reval .sr-wide {display:none}.stream-reval .sr-narrow {display:block}}
@media print {.stream-reval fieldset {display:none}.stream-reval .sr-pane.sr-changing,.stream-reval .sr-pane.sr-stationary{display:block!important}.stream-reval *{print-color-adjust:exact}}
</style>
"""

def return_panel(config, scenario, changed):
    rows = scenario['curves']
    if rows[0]['t'] != 0:
        rows = [{'t': 0, 'frozen': 0., 'probe': 0., 'revise': 0.}] + rows
    label = '来源可靠性反转' if changed else '来源可靠性稳定'
    series = [
        ('探测并修订', [(r['t'], r['revise']-r['frozen']) for r in rows], COLORS['learn'], False),
        ('只探测', [(r['t'], r['probe']-r['frozen']) for r in rows], COLORS['cost'], True),
    ]
    last = rows[-1]
    assert last['t'] == config['horizon']
    final_text = '、'.join(
        f'{name} {last[key]:,.1f}' for key,name in
        [('frozen','冻结'),('probe','只探测'),('revise','探测并修订')])
    description = f'{label}。全程平均累计净回报，{final_text}。曲线显示相对冻结策略的累计差额。'
    graph = chart(series, config['change_at'] if changed else None, config['horizon'],
                  '累计净回报相对冻结策略的差（分）', description)
    return (f'<div class="sr-pane sr-{"changing" if changed else "stationary"}"><b>{label}</b>{graph}'
            f'<div class="sr-col">第 {last["t"]:,} 组的累计净回报（分）<br>{final_text}。</div></div>')


def block_bar(when, positives, negatives, ties, prob, verdict):
    counts = (positives, negatives, ties)
    total = sum(counts)
    assert total > 0
    scale = ''.join(f'<span class="sr-{style}" style="width:{100*n/total:.4f}%"></span>'
                    for style, n in zip(('better','worse','tie'), counts))
    summary = f'候选胜 {positives} 对，旧来源胜 {negatives} 对，相同 {ties} 对'
    return (f'<div class="sr-block"><div><h5>{when}</h5><span class="sr-stat">{summary}</span>'
            f'<div class="sr-pair-bar" role="img" aria-label="{summary}">{scale}</div></div>'
            f'<div class="sr-decision">单侧 <i>p</i> = {prob:.6f}<br>{verdict}</div></div>')


def receipt(sent, arrived, source, success):
    label = '线索吻合' if success else '线索不符'
    return (f'<div class="sr-lane"><span>第 {sent} 组 · {source}</span>'
            f'<i class="sr-connector" aria-hidden="true"></i>'
            f'<span>第 {arrived} 组 · {label}</span></div>')


def protocol_panel(c):
    return (f'<div class="sr-part">全程累计净回报 <small>· 步骤 5</small></div>'
            f'<p>每种策略各运行 {c["repetitions"]} 条独立部署流。每组都计入两次委托的净回报，额外核对与记忆修订的费用在发生时扣除。'
            f'纵轴以冻结策略为零；低于零表示从部署开始累计付出的代价仍大于所得收益。</p>'
            f'<fieldset><legend>部署环境</legend>'
            f'<label><input id="sr-reverse" type="radio" name="sr-world" checked aria-controls="sr-curves">中途反转</label>'
            f'<label><input id="sr-static" type="radio" name="sr-world" aria-controls="sr-curves">保持稳定</label></fieldset>'
            f'<div class="sr-legend"><span><i></i>探测并修订</span><span><i class="sr-probe"></i>只探测</span>'
            f'<span>零线 · 冻结</span></div>')


def trace_panel(result):
    cfg, sample = result["config"], result["example"]
    rev = min(sample["revisions"].values(), key=lambda r: r["t"])
    setting, old, alt = rev["setting"], rev["old"], rev["alt"]
    condition = {1: "甲", 2: "乙"}[setting]
    names = {1: '查询', 2: '核验'}
    blocks = [c for c in sample["checks"] if c["setting"] == setting and c["t"] <= rev["t"]]
    labels = [e for e in sample["traces"] if e["kind"] == "label" and e["setting"] == setting]
    assert all(e["t"] - e["origin"] == cfg["label_delay"] for e in labels)
    first_block = blocks[0]
    in_first = [l for l in labels if first_block["first"] <= l["origin"] <= first_block["last"]]
    pair = next(pair for pair in zip(in_first[::2], in_first[1::2])
                if any(l["action"] == old and not l["cue_correct"] for l in pair))
    assert max(l["t"] for l in pair) < cfg["change_at"]
    assert {l["action"] for l in pair} == {old,alt}
    lanes = ''.join(receipt(l["origin"], l["t"], names[l["action"]], l["cue_correct"]) for l in pair)
    bars = []
    threshold = cfg["alpha"] / (2 * cfg["max_looks"])
    for r in blocks:
        assert r["wins"] + r["losses"] + r["ties"] == cfg["pairs_per_block"]
        status = '修订来源选择规则' if r["revised"] else '保留原规则'
        bars.append(block_bar(f'第 {r["look"]} 块 · 第 {r["t"]} 组收齐标签',
                              r["wins"],r["losses"],r["ties"],r["p_value"],status))
    old_pct, new_pct = rev["previous"][alt], rev["current"][alt]
    return f"""
<div class="sr-part">配对探测与延迟反馈 <small>· 步骤 1–2</small></div>
<p>固定一条部署流（种子 {sample["seed"]}），只看条件{condition}（程序中 s = {setting}）。原策略优先{names[old]}，候选来源为{names[alt]}。每对探测占用两次独立的委托机会，各执行一项操作，顺序由随机分配决定。</p>
<div class="sr-delay"><b>变化前，原来源的一次失误</b>{lanes}</div>
<p class="sr-note">左侧为实际行动，右侧为与独立真值的比对结果。两次行动各付 {cfg["audit_cost"]:g} 分取得标签。一次失误只记入本块，须等到 {cfg["pairs_per_block"]} 对标签收齐才比较来源。</p>
<div class="sr-part">重新估计两种来源 <small>· 步骤 3</small></div>
<div class="sr-pair-legend"><i class="sr-key sr-better"></i> {names[alt]}正确、{names[old]}错误　<i class="sr-key sr-worse"></i> {names[old]}正确、{names[alt]}错误　<i class="sr-key sr-tie"></i> 两者同对或同错</div>
{''.join(bars)}
<p class="sr-note">每条横带代表 {cfg["pairs_per_block"]} 对探测。单侧符号检验只使用命中结果不同的对，检验阈值 {threshold:.5f}。模拟器在第 {cfg["change_at"]} 组反转来源可靠性，学习者只收到探测标签。</p>
<div class="sr-state"><b>第 {rev["t"]} 组的记忆修订 · 步骤 4</b><br>这块样本中，{names[old]}的行动净回报均值为 {rev["q_old"]:.3f} 分，{names[alt]}为 {rev["q_alt"]:.3f} 分，计入当前和下一委托的得分、操作与暂存费用。命中率的比较通过检验，且{names[alt]}的平均净回报更高。智能体只修订这一条件的来源记录，非探测时选{names[alt]}的概率由 {old_pct:.1%} 调至 {new_pct:.1%}。这次修订另付 {cfg["revision_cost"]:g} 分。</div>"""


def panel_with_interval(config, scenario, changed):
    panel = return_panel(config, scenario, changed)
    interval = scenario['paired_contrasts']['revise_minus_frozen']
    credit = f'修订策略相对冻结的全程净回报差为 {interval["mean"]:+.1f} 分，配对均值差的 95% 区间为 [{interval["low"]:.1f}, {interval["high"]:.1f}]。'
    if changed:
        credit += '只探测也会改变实际选中的来源。实线与虚线的差额衡量两组具有相同探测机制时，修订规则带来的额外收益。'
    else:
        audit_cost = scenario['summary']['probe']['mean_costs']['audit']
        credit += f'稳定环境中两条曲线重合。每条流平均花 {audit_cost:.1f} 分取得独立标签，其余差额来自探测改变了操作收益及费用。'
    return panel[:-6] + f'<p class="sr-note">{credit}</p></div>'


def render(data):
    c = data["config"]
    return f"""<figure class="stream-reval" id="stream-revaluation-figure" aria-labelledby="sr-title" aria-describedby="sr-caption">
{STYLE}
<div class="sr-title" id="sr-title">来源可靠性的重新估计与全程净回报</div>
{trace_panel(data)}
{protocol_panel(c)}
<div id="sr-curves" aria-live="polite">
{panel_with_interval(c,data["scenarios"]["reversal"],True)}
{panel_with_interval(c,data["scenarios"]["stable"],False)}
</div>
<figcaption id="sr-caption">上图使用一条部署流中实际选中的来源及其反馈。下图每 {c["bin_width"]} 组记录一次累计净回报，在相同外生随机条件下配对比较三项策略。图中的数据来自本章的教学模拟。<a href="#continuous-source-revaluation">算法 13.8</a> · <a href="reader-source/stream_revaluation.py">实验程序</a></figcaption>
</figure>"""


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('json', type=Path, help='stream_revaluation.py --json 导出的文件')
    parser.add_argument('--output', type=Path, default=Path(__file__).with_name('stream-revaluation-figure.html'))
    args = parser.parse_args()
    args.output.write_text(render(json.loads(args.json.read_text()))+'\n')

