"""第 13 章三轮预约：讲义样本回报，及可枚举策略的词元梯度核对。

运行：python3 reservation_trace.py。只用标准库。
竖线所隔部分是教学字段。下面的小策略每次在两种字段之间选一个教学符号。
它没有商业模型的分词器、输出概率、隐藏状态或训练记录。

迁移评测另需在清空上下文的留出委托中，交叉更换新旧记忆和参数。
四组使用相同任务分布、执行预算和可用接口。此脚本不产生这四组的测量结果。
"""

from dataclasses import dataclass
from itertools import product
from math import exp, isclose


FIELDS = (
    (("查询", "不查询"), ("时段", "其他")),
    (("预约", "不预约"), ("周二", "周三"), ("v7", "v8")),
    (("核验", "结束"), ("#42", "其他编号")),
)
# 每个字段有一个参数，最后一项为共享参数。
PARAMETERS = (.2, -.3, .4, .1, -.15, .22, .6, .4)


@dataclass(frozen=True)
class Turn:
    message: tuple
    execution: str
    observation: str
    reward: float


def execute(t, message, version, registered):
    """独立的服务端。最终成功取决于已登记的预约；读取回执不改变登记。"""
    verb = message[0]
    if t == 0:
        if verb == "不查询":
            return Turn(message, "不读取", "无读数", 0.), registered
        receipt = f"周二有位，版本 {version}" if message[1] == "时段" else "无时段信息"
        return Turn(message, "读取" + message[1], receipt, -.10), registered
    if t == 1:
        registered = message == ("预约", "周二", version)
        receipt = "待确认 #42" if registered else "无有效预约"
        return Turn(message, "登记预约请求" if verb == "预约" else "跳过登记", receipt, 0.), registered
    checked = verb == "核验"
    if checked:
        receipt = "#42 已确认" if registered and message[1] == "#42" else "未查到"
    else:
        receipt = "无回执"
    return Turn(message, "读取请求状态" if checked else "不读取",
                receipt, float(registered) - .05 * checked), registered


def returns(turns):
    result = [0.] * len(turns)
    tail = 0.
    for t in reversed(range(len(turns))):
        tail += turns[t].reward
        result[t] = tail
    return result


def action_feature(receipt, prefix, role):
    """生成时仅使用已送达的文本和本轮已经生成的字段。"""
    f = 1.0 + .15 * len(prefix)
    if "v7" in receipt:
        f += .6
    if "v8" in receipt:
        f -= .6
    if "#42" in receipt:
        f += .4
    if prefix and prefix[0] == FIELDS[role][0][0]:
        f += .25
    return f


def episode(parameters, bits, version):
    """轨迹概率由固定的环境概率与七个决策的条件概率相乘。"""
    receipt = "请预约周二"
    registered = False
    probability = .5  # 服务端版本 v7 或 v8，各占一半，与策略参数无关。
    turns, decisions = [], []
    i = 0
    for t, fields in enumerate(FIELDS):
        prefix = []
        for alternatives in fields:
            f = action_feature(receipt, prefix, t)
            p = 1. / (1. + exp(-(parameters[i] + parameters[-1] * f)))
            bit = bits[i]
            probability *= p if bit else 1. - p
            # 选词的对数概率对字段参数的导数是 bit-p，对共享参数再乘 f。
            decisions.append((t, i, bit - p, f))
            prefix.append(alternatives[0 if bit else 1])
            i += 1
        turn, registered = execute(t, tuple(prefix), version, registered)
        turns.append(turn)
        receipt = turn.observation
    return turns, probability, decisions


def enumerate_policy(parameters):
    expected_return, mass = 0., 0.
    gradient = [0.] * len(parameters)
    for version in ("v7", "v8"):
        for bits in product((0, 1), repeat=7):
            turns, probability, decisions = episode(parameters, bits, version)
            gains = returns(turns)
            mass += probability
            expected_return += probability * gains[0]
            # 基线只读本轮之前的信息。当前生成的字段和回执均不进入它。
            baselines = [0., .2 * ("v7" in turns[0].observation),
                         .3 * ("#42" in turns[1].observation)]
            for t, i, score, f in decisions:
                contribution = probability * (gains[t] - baselines[t]) * score
                gradient[i] += contribution
                gradient[-1] += contribution * f
    assert isclose(mass, 1., abs_tol=1e-12)
    return expected_return, gradient


def main():
    bits = [1] * 7
    turns, _, decisions = episode(PARAMETERS, bits, "v7")
    gains = returns(turns)
    assert [r.reward for r in turns] == [-.10, 0., .95]
    assert all(isclose(a, b, abs_tol=1e-12) for a, b in zip(gains, (.85, .95, .95)))
    print("轮   生成的教学字段        实际操作       环境回执                净奖励  回报")
    for t, (turn, gain) in enumerate(zip(turns, gains)):
        print(t, " | ".join(turn.message), turn.execution, turn.observation,
              f"{turn.reward:+.2f}", f"{gain:.2f}", sep="   ")
    assert len(decisions) == 7  # 回执由服务端产生，决策列表只含策略生成位置。
    assert action_feature("周二有位，版本 v7", [], 1) != action_feature("无读数", [], 1)

    # 锁定同一已登记状态，只改最后是否读取；实际登记和成功奖保持相同。
    skipped, _, _ = episode(PARAMETERS, bits[:5] + [0, 1], "v7")
    assert isclose(returns(skipped)[0] - gains[0], .05, abs_tol=1e-12)

    value, gradient = enumerate_policy(PARAMETERS)
    errors, eps = [], 1e-5
    for i in range(len(PARAMETERS)):
        hi, lo = list(PARAMETERS), list(PARAMETERS)
        hi[i] += eps
        lo[i] -= eps
        numeric = (enumerate_policy(hi)[0] - enumerate_policy(lo)[0]) / (2. * eps)
        errors.append(abs(gradient[i] - numeric))
    assert max(errors) < 1e-8
    print(f"教学模型的枚举期望净回报 {value:.6f}；"
          f"八个偏导与中心差分的最大绝对差 {max(errors):.2e}。")


if __name__ == "__main__":
    main()
