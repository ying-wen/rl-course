"""Render the chapter's paired budget experiment from its recorded results.

Run after credit_budget_comparison.py. Input is credit-budget-results.json;
the output is an HTML figure with inline vector plots.
"""
import argparse
from html import escape
from io import StringIO
from math import isfinite
from pathlib import Path
import json
import re

import matplotlib
matplotlib.use("svg")
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.ticker import MaxNLocator

HERE = Path(__file__).resolve().parent
METHODS = {
    "grpo": ("GRPO", "#725493"),
    "branch": ("前缀分支", "#16776f"),
    "critic": ("前缀估值", "#b26330"),
}
METRICS = {
    "selected_rmse": "局部价值差的估计误差",
    "gain": "更新后的完整策略回报增益",
}
CSS = """
.cb-exp{margin:1.7em 0;padding:.8em 0 .2em;border-block:1px solid #aebfba;color:#213e40}
.cb-exp .cb-title{font-weight:680;font-size:1.11em;margin:0 0 .3em;line-height:1.4}
.cb-exp .cb-meta,.cb-exp .cb-note,.cb-exp figcaption{font-size:.88em;line-height:1.6;margin:.35em 0;color:#405657}
.cb-exp .cb-methods{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:.8em;margin:.7em 0}
.cb-exp .cb-method{padding:.45em 0;border-block-start:2px solid var(--method);font-size:.88em;line-height:1.5}
.cb-exp .cb-method b{color:var(--method);display:block;font-weight:660}
.cb-exp .cb-method svg{display:block;max-width:160px;height:auto;margin:.15em 0}
.cb-exp .cb-case{margin:1em 0 0;border-block-start:1px solid #b3c1ba}
.cb-exp .cb-case-title{font-weight:650;font-size:.98em;line-height:1.5;margin:.3em 0;color:#173e47}
.cb-exp .cb-charts{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:1.1em}
.cb-exp .cb-panel{min-width:0}
.cb-exp .cb-panel p{font-size:.85em;font-weight:590;line-height:1.45;margin:.3em 0}
.cb-exp .cb-panel svg{width:100%;height:auto;display:block;overflow:visible}
.cb-exp .cb-panel svg text{font-family:var(--sans)!important}
.cb-exp figcaption{padding:.45em 0 0;border-top:1px solid #ccd6cf}
@media(max-width:640px){.cb-exp .cb-charts{grid-template-columns:1fr;gap:.18em}.cb-exp .cb-methods{gap:.18em;grid-template-columns:1fr}.cb-exp .cb-method{display:grid;grid-template-columns:86px 1fr;gap:0 .6em;align-items:center;padding:.2em 0}.cb-exp .cb-method svg{grid-row:1/3;grid-column:1;margin:0}.cb-exp .cb-method b,.cb-exp .cb-method span{grid-column:2}.cb-exp .cb-panel svg{max-width:430px}.cb-exp .cb-methods{margin:.5em 0}.cb-exp .cb-case-title{margin:.4em 0}}
"""
TREE_PATHS = {
    "grpo": (
        '<path d="M12 30 Q43 30 64 10 H128 M12 30 H128 M12 30 Q43 30 64 50 H128"/>'
        '<circle cx="12" cy="30" r="4" class="solid"/>',
        "同一起点独立生成，组内比较终局结果。",
    ),
    "branch": (
        '<path d="M12 30H65" class="past"/><circle cx="65" cy="30" r="4" class="solid"/>'
        '<path d="M65 30 Q86 30 94 10 H128 M65 30 Q86 30 94 50 H128"/>',
        "恢复经验选出的前缀，比较两个词元的后续回报。",
    ),
    "critic": (
        '<path d="M12 30H128"/><circle cx="12" cy="30" r="3" class="solid"/>'
        '<path d="M128 27Q104 -2 70 23 M128 27Q85 -5 44 23" stroke-dasharray="3 3"/>'
        '<path d="m74 23-5 1 2-5 m-23 4-5 1 2-5"/>'
        '<rect x="39" y="26" width="8" height="8"/><rect x="65" y="26" width="8" height="8"/>',
        "两折拟合前缀价值。选词的效应在同一路线的提示间共享。",
    ),
}
ENDS = {"grpo": (10,30,50), "branch": (10,50), "critic": (30,)}


def sampling_drawing(method):
    inner, meaning = TREE_PATHS[method]
    ends = ''.join(f'<circle cx="129" cy="{y}" r="4" fill="white"/>' for y in ENDS[method])
    return (
        f'<div class="cb-method" style="--method:{METHODS[method][1]}">'
        f'<b>{METHODS[method][0]}</b><svg role="img" aria-label="{meaning}" viewBox="0 0 145 60">'
        '<g fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" '
        f'style="color:{METHODS[method][1]}">{inner}{ends}</g></svg><span>{meaning}</span></div>'
    ).replace('class="solid"', 'fill="currentColor"').replace('class="past"', 'stroke="#829195" stroke-dasharray="3 3"')


def interval(case, method, metric):
    stat = case['methods'][method]['metrics'][metric]
    mean, low, high = (100.0 * float(stat[k]) for k in ('mean','lo','hi'))
    if not all(map(isfinite,(mean,low,high))) or low>high:
        raise ValueError(f"Invalid interval for {method} {metric}: {stat!r}")
    return mean,low,high


def domain(cases, metric):
    bounds = [n for case in cases.values() for method in METHODS for n in interval(case,method,metric)]
    low=min(0.0,*bounds)
    high=max(0.0,*bounds)
    if high==low:
        high=low+1
    ticks = MaxNLocator(nbins=4, steps=[1,2,2.5,5,10]).tick_values(low,high)
    return float(ticks[0]),float(ticks[-1]),ticks


def trim_svg(svg):
    svg = svg[svg.index('<svg '):svg.index('</svg>')+6]
    svg = re.sub(r'<metadata>.*?</metadata>', '', svg, flags=re.S)
    svg = re.sub(r'<!--.*?-->', '', svg, flags=re.S)
    svg = re.sub(r'<style[^>]*>.*?</style>', '', svg, flags=re.S)
    return svg


def draw_panel(case, case_id, metric, scale):
    low,high,ticks = scale
    tag=f"cb-{case_id}-{metric}"
    fig=plt.figure(figsize=(3.5,1.30))
    axis=fig.add_axes([.20,.24,.62,.66])
    axis.set_xlim(low,high)
    axis.set_ylim(2.55,-.55)
    axis.set_yticks([0,1,2], [METHODS[m][0] for m in METHODS])
    axis.set_xticks(ticks, [f'{t:g}' for t in ticks])
    axis.tick_params(axis='both',length=0,labelsize=9.5,pad=3,colors='#384d50')
    for edge in axis.spines.values():
        edge.set_visible(False)
    axis.grid(axis='x',color='#d8e2dd',linewidth=.7)
    axis.axvline(0,color='#829693',linewidth=1)
    labels=[]
    for row,method in enumerate(METHODS):
        val,lo,hi=interval(case,method,metric)
        name,color=METHODS[method]
        axis.plot([lo,hi],[row,row],color=color,linewidth=2.1,zorder=3)
        axis.vlines([lo,hi],row-.15,row+.15,color=color,linewidth=1,zorder=4)
        axis.plot(val,row,'o',color=color,markersize=4.6,zorder=5)
        value=f'{val:+.2f}' if metric=='gain' else f'{val:.2f}'
        axis.text(1.03,row,value,transform=axis.get_yaxis_transform(),ha='left',va='center',
                  fontsize=9.5,color=color)
        labels.append(f'{name} {value}，区间 {lo:.2f} 至 {hi:.2f}')
    buf=StringIO()
    fig.savefig(buf,format='svg',transparent=True)
    plt.close(fig)
    svg=trim_svg(buf.getvalue())
    # Matplotlib creates a fresh figure_1 and axes_1 for each chart.
    # Prefix both declarations and references when the plots share one HTML page.
    for ident in re.findall(r'\bid="([^"]+)"',svg):
        svg=svg.replace(f'id="{ident}"',f'id="{tag}-{ident}"')
        svg=svg.replace(f'#{ident})',f'#{tag}-{ident})').replace(f'="#{ident}"',f'="#{tag}-{ident}"')
    accessibility=METRICS[metric]+'，单位为百分点。'+'。'.join(labels)+'。'
    return svg.replace('<svg ',f'<svg role="img" aria-label="{escape(accessibility,quote=True)}" ',1)


def render(data):
    cases=data['scenarios']
    p=data['protocol']
    scales={metric:domain(cases,metric) for metric in METRICS}
    parts=['<figure id="credit-budget-comparison-figure" class="cb-exp" aria-labelledby="cb-exp-title">',
           '<style>'+CSS+'</style>',
           '<div id="cb-exp-title" class="cb-title">固定采样预算下的局部信用与策略回报</div>',
           '<div class="cb-methods">'+''.join(sampling_drawing(m) for m in METHODS)+'</div>']
    parts.append(f'<p class="cb-meta">每次训练生成 {p["total_generated_tokens"]:,} 个词元，取得 {p["total_verifications"]:,} 次核验。'
        f'先用其中 {p["pilot_verifications"]} 次核验，在 {p["candidates"]} 类候选前缀中按两词通过率差的绝对值减一倍标准误排序，选前 {p["selected"]} 类。'
        f'余下 {p["update_verifications"]} 次核验用于估值和更新。分支续写省下的词元用于估计原提示下的路线访问率。</p>')
    for key,case in cases.items():
        event=case['methods']['branch']['metrics']['own_discovery_rate']['mean']
        random_event=case['methods']['branch_random']['metrics']['own_discovery_rate']['mean']
        label=case['label'].replace('跨提示作用','同一词元在不同提示中的作用')
        parts.append(f'<div class="cb-case"><div class="cb-case-title">{escape(label)}</div>'
                     f'<p class="cb-note">选中的前缀中，真实价值差非零的占 {event:.1%}，随机选择时占 {random_event:.1%}。</p>'
                     '<div class="cb-charts">')
        for metric in METRICS:
            caption='局部价值差 RMSE（百分点，越低越准）' if metric=='selected_rmse' else '完整策略回报增益（百分点，0 为更新前）'
            parts.append(f'<div class="cb-panel"><p>{caption}</p>{draw_panel(case,key,metric,scales[metric])}</div>')
        before = 100 * case['mask_branch_feedback']['selected_rmse']['masked']['mean']
        after = interval(case, 'branch', 'selected_rmse')[0]
        pair = case['mask_branch_feedback']['gain']['branch_minus_masked']
        parts.append('</div><p class="cb-note"><strong>只替换选中两处的估值。</strong>'
                     f'局部误差 {before:.2f} → {after:.2f} 个百分点，'
                     f'完整策略通过率额外改变 {100*pair["mean"]:+.4f} 个百分点'
                     f'（配对 95% 区间 {100*pair["lo"]:+.4f} 至 {100*pair["hi"]:+.4f}）。</p></div>')
    all_kl=[case['methods'][m]['metrics']['trajectory_kl']['mean'] for case in cases.values() for m in METHODS]
    kl_text=f'{all_kl[0]:g}' if max(all_kl)-min(all_kl)<1e-8 else f'{min(all_kl):.4f}–{max(all_kl):.4f}'
    baselines=[case['old_return'] for case in cases.values()]
    old=f'{baselines[0]:.2%}' if max(baselines)-min(baselines)<1e-8 else f'{min(baselines):.2%}–{max(baselines):.2%}'
    parts.append(f'<p class="cb-note"><strong>局部估值怎样影响全程回报。</strong>在这个任务中，每处选词对回报的贡献等于新策略到达该处的概率、选词 1 的概率改变量与旧策略的两词价值差三者之积。'
                 f'全程增益还包含首词更改路线的贡献。原策略通过率为 {old}，各方法实际一步更新的整轨迹 KL 为 {kl_text} nat。</p>')
    parts.append(f'<figcaption>空心圆表示终局核验，方框表示前缀估值。误差按所选前缀类比较估计与真值，再对 {p["seeds"]} 次独立训练取平均。GRPO 的局部估计用同批终局结果的条件均值差，策略实际用组内标准化分数更新。'
                 f'增益由原始提示上的完整策略枚举求出。线段为训练种子均值的 95% 自助区间。同一指标在两种条件下共用标尺。'
                 ' <a href="reader-source/credit-budget-results.json">实验数据</a></figcaption></figure>')
    return '\n'.join(parts)+'\n'


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input',type=Path,default=HERE/'credit-budget-results.json')
    parser.add_argument('--output',type=Path,default=HERE/'credit-budget-comparison.html')
    args=parser.parse_args()
    matplotlib.rcParams.update({'svg.fonttype':'none','svg.hashsalt':'chapter-13-credit-budget'})
    system_fonts={font.name for font in font_manager.fontManager.ttflist}
    fonts=[s for s in ('PingFang SC','Hiragino Sans GB','Noto Sans CJK SC','Arial Unicode MS') if s in system_fonts]
    if fonts:
        matplotlib.rcParams['font.family']=fonts+['DejaVu Sans']
    data=json.loads(args.input.read_text(encoding='utf-8'))
    args.output.write_text(render(data),encoding='utf-8')


if __name__=='__main__':
    main()
