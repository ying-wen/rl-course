"""根据同预算探测实验的配对结果重绘图。只使用 Python 标准库。"""
import argparse
import json
import math
from pathlib import Path

from draw_stream_revaluation import nice_tick, number


STYLE = """
<style>
.probe-policy{container-type:inline-size;background:var(--surface,#fffefa);border-block:2px solid #6d908b;padding:.8rem .15rem;color:#183b40}
.probe-policy .pp-title{font:700 1.22rem/1.42 var(--serif,serif);margin:0 0 .56rem}
.probe-policy p,.probe-policy figcaption{margin:.35rem 0 .52rem;padding:0;font: .9rem/1.62 var(--sans,sans-serif)}
.probe-policy .pp-key{display:flex;gap:.24rem 1.1rem;flex-wrap:wrap;font-size:.86rem;align-items:center;line-height:1.5}
.probe-policy .pp-key span{display:inline-flex;align-items:center;gap:.35rem}
.probe-policy .pp-icon{display:inline-flex;align-items:center;justify-content:center;width:1.15rem;height:1.15rem;vertical-align:middle}
.probe-policy .pp-icon:before{content:"";display:block;width:.68rem;height:.68rem;border:2px solid #1c6a77;border-radius:50%;background:#d9ebec}
.probe-policy .pp-obs:before{border-color:#965936;background:#efdfce;border-radius:0;transform:rotate(45deg);width:.55rem;height:.55rem}
.probe-policy .pp-window{margin:.68rem 0 .5rem;display:grid;grid-template-columns:minmax(4.2rem,1fr) repeat(12,minmax(0,.36fr));row-gap:.2rem;align-items:center}
.probe-policy .pp-window>*{min-width:0}
.probe-policy .pp-label{font-size:.87rem;font-weight:650;line-height:1.35}
.probe-policy .pp-time{font:.77rem/1.35 var(--sans,sans-serif);color:#5f7070}
.probe-policy .pp-cell{text-align:center;line-height:1.1;color:#526868;font-size:.79rem;padding-block:.18rem}
.probe-policy .pp-moment{display:flex;justify-content:center;align-items:center;height:1.55rem;background:linear-gradient(to bottom,transparent 47%,#c9d7d5 48%,#c9d7d5 52%,transparent 53%)}
.probe-policy .pp-moment .pp-icon{background:var(--surface,#fffefa)}
.probe-policy .pp-updates{display:grid;grid-template-columns:minmax(4.5em,.65fr) .9em minmax(5.9em,1fr) .9em minmax(5em,1fr);align-items:center;gap:.13rem .28rem;margin:.65rem 0;padding:.4rem .28rem .38rem;border-block:1px solid #cbd7d1;font:.85rem/1.55 var(--sans,sans-serif)}
.probe-policy .pp-updates b{font-weight:650}.probe-policy .pp-arrow{color:#54746b}
.probe-policy .pp-sample{border-left:2px solid #b5c9c3;padding-left:.65rem;margin:.52rem 0}
.probe-policy .pp-sample summary{font:.85rem/1.56 var(--sans,sans-serif);color:#225f63;cursor:pointer}
.probe-policy .pp-sample p{margin:.22rem 0 .28rem;font-size:.84rem}
@container(max-width:19.8rem){.probe-policy .pp-updates{grid-template-columns:minmax(4.1em,.7fr) .75em minmax(4.8em,1fr) .75em minmax(4em,1fr);gap:.12rem;padding-inline:0}}
.probe-policy .pp-subtitle{font:650 1rem/1.48 var(--sans,sans-serif);margin:1.12rem 0 .32rem}
.probe-policy .pp-lines{display:flex;gap:.27rem 1.2rem;flex-wrap:wrap;font-size:.82rem;align-items:center}
.probe-policy .pp-lines span{display:inline-flex;align-items:center;gap:.33rem}
.probe-policy .pp-lines i{display:block;width:1.65rem;border-top:3px solid #006a6b}
.probe-policy .pp-lines .pp-regular{border-top:2px dashed #a3542e}
.probe-policy .pp-charts{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:.6rem 1rem;margin:.78rem 0 .55rem}
.probe-policy .pp-charts article{min-width:0}
.probe-policy .pp-charts h5{font:650 .95rem/1.5 var(--sans,sans-serif);margin:0}
.probe-policy svg{width:100%;height:auto;display:block;max-width:420px}
.probe-policy svg text{font:12.5px var(--sans,sans-serif);fill:#385459}
.probe-policy svg .pp-axis{fill:#344f54;font-size:13px}
.probe-policy .pp-numbers{border-top:1px solid #c2d1cb;padding-top:.32rem;font:.83rem/1.55 var(--sans,sans-serif);font-variant-numeric:tabular-nums}
.probe-policy figcaption{font-size:.84rem;color:#52656a;margin-bottom:.2rem}
@container(max-width:35rem){.probe-policy .pp-charts{grid-template-columns:1fr}.probe-policy .pp-window{grid-template-columns:4.15rem repeat(12,minmax(0,1fr))}}
@media print{.probe-policy *{print-color-adjust:exact}.probe-policy .pp-charts{grid-template-columns:repeat(2,minmax(0,1fr))}}
</style>
"""


def timeline(window, delay):
    """画出同一窗口的两种可选时机。每条实际部署只执行其中一行。"""
    assert window == 12 and delay == 3
    parts = ['<div class="pp-window" role="img" aria-label="窗口含12组委托。立即探测在第1、2组付费，分别于第4、5组收回结果。延期探测在第7、8组付费，分别于第10、11组收回。每窗实际只执行一行。">',
             '<span class="pp-time">窗内组序</span>']
    parts.extend(f'<span class="pp-cell">{j}</span>' for j in range(1, window + 1))
    for label, start in [('立即探测', 1), ('延期探测', 7)]:
        parts.append(f'<span class="pp-label">{label}</span>')
        for j in range(1, window + 1):
            icon = ('pp-act' if j in (start,start + 1) else
                    'pp-obs' if j in (start + delay,start + delay + 1) else None)
            shape = f'<i class="pp-icon {icon}"></i>' if icon else ''
            parts.append(f'<span class="pp-moment" aria-hidden="true">{shape}</span>')
    return ''.join(parts) + '</div>'


def cumulative_chart(curves, ticks, horizon, change):
    """所有场景共享坐标范围。两个差值均以各自对照的同流表现为参照。"""
    width, height = 330, 209
    left, right, top, bottom = 39, width - 12, 33, height - 36
    def xp(n):
        return left + (right - left) * n / horizon
    def yp(n):
        return bottom - (bottom - top) * (n - ticks[0]) / (ticks[-1] - ticks[0])
    svg = [f'<svg viewBox="0 0 {width} {height}" role="img" aria-label="两种配对累计净回报差。实线为学习时机减随机固定概率，虚线为学习时机减固定周期。图下给出终点读数。">',
           f'<text x="{left}" y="16" class="pp-axis">累计净回报差（分）</text>']
    for v in ticks:
        y = yp(v)
        svg.append(f'<path d="M{left},{y:.2f}H{right}" stroke="{"#7d9692" if v == 0 else "#dce3df"}" stroke-width="{1.5 if v == 0 else 1}"/>')
        svg.append(f'<text x="{left-5}" y="{y+4:.2f}" text-anchor="end">{number(v)}</text>')
    # Pointwise paired intervals refer to the fixed-probability control.
    upper = [(r['t'],r['delta_high']) for r in curves]
    lower = [(r['t'],r['delta_low']) for r in reversed(curves)]
    band = ' '.join(f'{xp(t):.2f},{yp(v):.2f}' for t,v in upper + lower)
    svg.append(f'<polygon points="{band}" fill="#bcdcd4" opacity=".60"/>')
    svg.append(f'<path d="M{left},{yp(0):.2f}H{right}" stroke="#80928e" stroke-dasharray="3 2"/>')
    if change:
        x = xp(change)
        svg.append(f'<path d="M{x:.2f},{top-3}V{bottom}" stroke="#6c7b79" stroke-dasharray="2 3"/>')
        svg.append(f'<text x="{x+4:.2f}" y="{top-1}">反转</text>')
    for t in (0,horizon//3,2*horizon//3,horizon):
        x = xp(t)
        svg.append(f'<text x="{x:.2f}" y="{bottom+15}" text-anchor="{"end" if t == horizon else "middle"}">{t}</text>')
    svg.append(f'<text x="{right}" y="{height-5}" text-anchor="end">委托组</text>')
    for which, col, dash in [('periodic','#a3542e',' stroke-dasharray="5 4"'),('fixed','#006a6b','')]:
        values = [(row['t'],row['learned'] - row[which]) for row in curves]
        coords = ' '.join(f'{xp(t):.2f},{yp(value):.2f}' for t,value in values)
        svg.append(f'<polyline points="{coords}" fill="none" stroke="{col}" stroke-width="2.65"{dash} stroke-linejoin="round" stroke-linecap="round"/>')
        svg.append(f'<circle cx="{xp(horizon)}" cy="{yp(values[-1][1]):.2f}" r="3" fill="{col}"/>')
    return ''.join(svg) + '</svg>'


def curve_rows(scenario, horizon):
    rows = list(scenario['curves'])
    if rows[0]['t'] > 0:
        rows.insert(0,dict(t=0,learned=0.,fixed=0.,periodic=0.,delta_low=0.,delta_high=0.))
    assert rows[0]['t'] == 0 and rows[-1]['t'] == horizon
    assert all(a['t'] < b['t'] for a,b in zip(rows,rows[1:]))
    assert all(math.isfinite(row[k]) for k in ('learned','fixed','periodic') for row in rows)
    return rows


def shared_ticks(rows_by_scenario):
    differences = [r['learned'] - r[key] for rows in rows_by_scenario.values()
                   for r in rows for key in ('fixed','periodic')] + [0.]
    differences.extend(r[bound] for rows in rows_by_scenario.values() for r in rows
                       for bound in ('delta_low','delta_high'))
    step = nice_tick(max(differences)-min(differences))
    left = math.floor(min(differences)/step)
    right = max(left + 1,math.ceil(max(differences)/step))
    return [i * step for i in range(left,right + 1)]


def signed(value, digits=1):
    return ('+' if value > 0 else '−' if value < 0 else '') + f'{abs(value):.{digits}f}'


def sample_window(scenario, cfg):
    event = scenario['example'][0]
    early = '立即' if event['early'] else '延期'
    setting, reuse = event['first_context']
    expected_arrivals = [t + cfg['label_delay'] for t in event['audited']]
    assert expected_arrivals == [r['t'] for r in event['matured']]
    receipts = '、'.join(str(t) for t in expected_arrivals)
    marks = '、'.join('吻合' if r['cue_correct'] else '不符' for r in event['matured'])
    return (f'<details class="pp-sample"><summary>一次实际更新 · 模拟流 {cfg["seed"]} 的首窗</summary>'
            f'<p>首组为条件{"甲" if setting == 1 else "乙"}，复用提示为{"高" if reuse else "低"}。'
            f'以 {event["probability"]:.1%} 的立即探测概率采样，本次选中{early}探测。'
            f'第 {receipts} 组分别收到两份回执，来源线索与真值的比较结果为{marks}。'
            f'本窗口的实际净回报为 {event["invoice"]:.2f} 分，较固定基线 {cfg["center"]:g} 分低 '
            f'{cfg["center"]-event["invoice"]:.2f} 分。更新后，重新输入这组特征，立即探测概率为 '
            f'{event["next_probability_same_x"]:.2%}。</p></details>')


def graphic(result):
    c = result['config']
    horizon, window = c['horizon'], c['window']
    if horizon % window:
        raise ValueError('此图要求完整的部署窗口')
    n_windows = horizon // window
    n_labels = n_windows * c['labels_per_window']
    scenarios = result['scenarios']
    rows_by_scenario = {k:curve_rows(scenarios[k],horizon) for k in ('stable','reversal')}
    ticks = shared_ticks(rows_by_scenario)
    panels = []
    for key, name in [('stable','稳定环境'),('reversal','变化环境')]:
        rows,sc = rows_by_scenario[key],scenarios[key]
        end = rows[-1]
        paired = sc['difference']
        periodic = sc['difference_periodic']
        assert abs(end['learned'] - end['fixed'] - paired['mean']) < .02
        assert paired['low'] <= paired['mean'] <= paired['high']
        for arm in ('fixed','learned','periodic'):
            assert sc['summary'][arm]['label_count'] == n_labels
            assert abs(sc['summary'][arm]['net']['mean'] - end[arm]) < .02
        diff_line = ('全程差值与 95% 配对区间<br>'
                     f'对固定概率 <b>{signed(paired["mean"],2)}</b> '
                     f'[{signed(paired["low"],2)}, {signed(paired["high"],2)}]<br>'
                     f'对固定周期 <b>{signed(periodic["mean"],2)}</b> '
                     f'[{signed(periodic["low"],2)}, {signed(periodic["high"],2)}]')
        totals = '　'.join(f'{label} {end[arm]:,.1f}' for arm,label in
                         [('learned','学习'),('fixed','固定概率'),('periodic','固定周期')])
        change = c['change_at'] if key == 'reversal' else None
        heading = name if change is None else f'{name} · 第 {change} 组来源可靠性反转'
        panels.append(f'<article><h5>{heading}</h5>{cumulative_chart(rows,ticks,horizon,change)}'
                      f'<div class="pp-numbers">{diff_line}<br>全程净回报（分）<br>{totals}</div></article>')
    return f"""{STYLE}
<figure id="probe-policy-figure" class="probe-policy" aria-labelledby="pp-head">
<h4 id="pp-head" class="pp-title">固定探测预算下的时机选择</h4>
<p>每 {window} 组委托可探测一对来源。窗首，当前委托的条件、复用提示和已有的来源记录可见。第二次机会的委托尚未出现。此时决定立即探测，或保留配额并在第二次机会执行。</p>
{timeline(window,c['label_delay'])}
<div class="pp-key"><span><i class="pp-icon"></i>付费探测，每组取一个来源</span><span><i class="pp-icon pp-obs"></i>收到该次独立核验回执</span></div>
<p>每窗只执行一行。在选定的两组委托上，旧来源与备选来源各用一次。其余委托按已有来源记录行动。两类反馈更新不同的决策。</p>
<div class="pp-updates">
<b>独立核验回执</b><span class="pp-arrow">→</span><span>积累同条件的配对比较</span><span class="pp-arrow">→</span><span>保留或修订来源记录</span>
<b>窗末净回报</b><span class="pp-arrow">→</span><span>收益偏差乘以策略资格迹</span><span class="pp-arrow">→</span><span>更新探测时机策略</span>
</div>
{sample_window(scenarios['stable'],c)}
<h5 class="pp-subtitle">同一探测预算下的全程净回报</h5>
<p>每条经验流含 {n_windows} 个窗口，各策略均取得 {n_labels} 个标签。固定概率策略逐窗以 ½ 概率立即探测，固定周期策略每窗都立即探测。两项对照采用相同的来源修订规则。</p>
<div class="pp-lines"><span><i></i>学习时机 − 固定概率</span><span><i class="pp-regular"></i>学习时机 − 固定周期</span></div>
<div class="pp-charts">{''.join(panels)}</div>
<figcaption>每点为 {c['repetitions']} 条配对模拟流截至该组的平均累计差。浅色带为实线的逐点 95% 配对区间。零线上方表示学习时机获得更高净回报。账面扣除操作、暂存、独立核验和修订费用。终点区间以整条经验流为配对单位。</figcaption>
</figure>
"""


def main():
    directory = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('results', type=Path, nargs='?', default=directory/'probe-policy-results.json')
    parser.add_argument('--output', type=Path, default=directory/'probe-policy-figure.html')
    args = parser.parse_args()
    args.output.write_text(graphic(json.loads(args.results.read_text())),encoding='utf-8')


if __name__ == '__main__':
    main()
