"""教学模拟：从单分支经验学习查询、核验和记忆写入。运行 python3 decision_returns.py。"""
from dataclasses import dataclass
from math import exp
from random import Random
from statistics import mean

# 首词指定作答方式：沿用已有线索、查询、核验。费用与成功的奖励使用同一单位。
ACTIONS = ("直接", "查询", "核验")
COST = (0.0, 0.085, 0.065)
WRITE_COST = 0.10
BATCH_SIZE = 128
INITIAL_LOGITS = [0.0] * 9 + [0.0, 0.0, 0.0]


@dataclass(frozen=True)
class Family:
    # 三类可见条件。行内给出三个信息来源中，各自返回正确线索的概率。
    reliability: tuple
    # 两类可见复用条件下，后一委托沿用前一委托隐藏事实的概率。
    reuse: tuple


TRAIN = (
    Family(((.91, .93, .89), (.53, .94, .60), (.54, .62, .94)), (.04, .92)),
    Family(((.87, .92, .88), (.52, .91, .66), (.55, .59, .91)), (.08, .86)),
)
HOLDOUT = (
    Family(((.85, .91, .87), (.56, .89, .58), (.58, .60, .90)), (.10, .82)),
    Family(((.90, .93, .88), (.57, .93, .68), (.55, .66, .93)), (.05, .88)),
)
# 反转查询和核验的可靠性。算法从未见过这种环境族。
REVERSED = Family(((.90, .90, .90), (.55, .57, .94), (.55, .94, .57)), (.05, .88))


@dataclass(frozen=True)
class Record:
    setting: int
    reuse_cue: int
    operation: int
    observation: int
    follow: int
    write: int
    behavior_probabilities: tuple  # 三次实际选择各自的条件概率
    rewards: tuple                # 操作成本、当前成绩、写入成本、下次成绩

    def returns(self):
        cost, score, write_cost, later_score = self.rewards
        gate_return = write_cost + later_score
        answer_return = score + gate_return
        return cost + answer_return, answer_return, gate_return


def sigmoid(x):
    return 1 / (1 + exp(-x))


def softmax(logits):
    top = max(logits)
    weights = [exp(x - top) for x in logits]
    total = sum(weights)
    return tuple(w / total for w in weights)


def probabilities(weights):
    operations = [softmax(weights[3*k:3*k+3]) for k in range(3)]
    follow = sigmoid(weights[9])
    write = tuple(sigmoid(x) for x in weights[10:])
    return operations, follow, write


def collect(policy, family, rng):
    """仅执行选中的操作。监督者知道隐藏事实，行为策略只读线索。"""
    operations, follow_prob, write_prob = policy
    setting = rng.randrange(3)
    reuse_cue = rng.randrange(2)
    fact = rng.randrange(2)
    op = rng.choices(range(3), weights=operations[setting], k=1)[0]
    # 直接回答使用已有线索。查询/核验用实际得到的新线索。
    reliable = rng.random() < family.reliability[setting][op]
    cue = fact if reliable else 1 - fact
    follow = int(rng.random() < follow_prob)
    answer = cue if follow else 1 - cue
    accepted = int(answer == fact)
    write = int(rng.random() < write_prob[reuse_cue])
    memory = cue if write else None
    # 清空当前上下文。后续会话固定使用保留下来的线索，无记录时随机猜测。
    next_fact = fact if rng.random() < family.reuse[reuse_cue] else rng.randrange(2)
    next_answer = memory if memory is not None else rng.randrange(2)
    later = int(next_answer == next_fact)
    # 当前提交的成绩在写入前确定。写入门的回报只含后续成绩及写入费用。
    propensities = (operations[setting][op], follow_prob if follow else 1-follow_prob,
                    write_prob[reuse_cue] if write else 1-write_prob[reuse_cue])
    return Record(setting, reuse_cue, op, cue, follow, write, propensities,
                  (-COST[op], accepted, -WRITE_COST*write, later))


def branch_means(rows):
    """固定均匀探索策略。同一行内行动随机，继而执行同一后续策略。"""
    first_values = [[[] for _ in ACTIONS] for _ in range(3)]
    gate_values = [[[], []] for _ in range(2)]
    for row in rows:
        first, _, gate = row.returns()
        first_values[row.setting][row.operation].append(first)
        gate_values[row.reuse_cue][row.write].append(gate)
    # 未采到的分支无样本均值，不能赋零。
    def avg(values):
        return mean(values) if values else None

    return ([[avg(values) for values in group] for group in first_values],
            [[avg(values) for values in group] for group in gate_values])


def batch_gradient(policy, rows):
    """在旧策略处累加各次真实选择的 score × return-to-go。"""
    operations, follow_prob, write_prob = policy
    grad = [0.] * len(INITIAL_LOGITS)
    for row in rows:
        g_op, g_answer, g_write = row.returns()
        # 固定基线 (1, 1, 0.5) 在决策前就已给定。
        for a, prob in enumerate(operations[row.setting]):
            grad[3*row.setting + a] += ((row.operation == a) - prob) * (g_op - 1.)
        grad[9] += (row.follow - follow_prob) * (g_answer - 1.)
        grad[10 + row.reuse_cue] += (row.write - write_prob[row.reuse_cue]) * (g_write - .5)
    return [v / len(rows) for v in grad]


def train(seed=3107):
    rng = Random(seed)
    weights = INITIAL_LOGITS.copy()
    for _ in range(500):
        policy = probabilities(weights)
        rows = [collect(policy, rng.choice(TRAIN), rng) for _ in range(BATCH_SIZE)]
        gradient = batch_gradient(policy, rows)
        weights = [w + .4 * g for w, g in zip(weights, gradient)]
    return probabilities(weights)


def expected_return(policy, family):
    """仅供核对：按已知模拟器穷举条件期望，学习器没有这个接口。"""
    operations, follow, write = policy
    value = 0.
    for setting, distribution in enumerate(operations):
        for v, persistence in enumerate(family.reuse):
            for op, prob in enumerate(distribution):
                q = family.reliability[setting][op]
                current = follow*q + (1-follow)*(1-q)
                future = .5 + write[v]*persistence*(q-.5)
                value += prob*(current + future - COST[op] - write[v]*WRITE_COST)/6
    return value


def frequency_matched(policy):
    # 六种可见起点等概率。此对照保留提交/查询/核验和写入的边际频率，
    # 并保留答题策略，仅消除操作随可见条件改变的依赖关系。
    operations, follow, write = policy
    pooled = tuple(mean(row[a] for row in operations) for a in range(3))
    return [pooled] * 3, follow, (mean(write),) * 2


def check_gradient():
    weights = [0.15, -.3, .2, .4, -.05, .1, -.2, .1, .35, .6, -.4, .7]
    policy = probabilities(weights)
    family = TRAIN[0]
    rng = Random(1703)
    rows = [collect(policy, family, rng) for _ in range(80000)]
    estimated = batch_gradient(policy, rows)
    gradients = []
    for k in range(len(weights)):
        hi, lo = weights.copy(), weights.copy()
        hi[k] += .00001
        lo[k] -= .00001
        gradients.append((expected_return(probabilities(hi), family)
                          - expected_return(probabilities(lo), family)) / .00002)
    errors = [abs(x-y) for x, y in zip(estimated, gradients)]
    assert max(errors) < .006, errors
    return max(errors)


def evaluate(policy, family, seed, n=16000):
    rng = Random(seed)
    return mean(collect(policy, family, rng).returns()[0] for _ in range(n))


if __name__ == "__main__":
    print(f"同策略样本梯度相对精确目标中心差分的最大绝对误差 {check_gradient():.4f}")
    rng = Random(8105)
    probe = probabilities(INITIAL_LOGITS)
    sampled = [collect(probe, TRAIN[0], rng) for _ in range(60000)]
    first_values, gate_values = branch_means(sampled)
    print("均匀探索策略下的首步价值，依次为直接、查询、核验")
    for values in first_values:
        print(" ".join(f"{value:.3f}" for value in values))
    print("写入相对跳过的净价值差，依次为低、高复用条件",
          *(f"{write-skip:+.3f}" for skip, write in gate_values))
    learned = train()
    print("直接/查询/核验的概率，按可见条件分行")
    for row in learned[0]:
        print(" ".join(f"{p:.3f}" for p in row))
    print("写入概率，按未来复用线索分组", *(f"{p:.3f}" for p in learned[2]))
    print("环境                      初始策略    同频随机    已学策略")
    for i, (name, family) in enumerate(zip(("留出环境 A", "留出环境 B", "可靠性反转"), (*HOLDOUT, REVERSED))):
        policies = (probabilities(INITIAL_LOGITS), frequency_matched(learned), learned)
        values = [evaluate(p, family, 8200 + i*10 + j) for j, p in enumerate(policies)]
        for policy, value in zip(policies, values):
            assert abs(value - expected_return(policy, family)) < .025
        print(name, *(f"{v:12.3f}" for v in values))
    operations, follow, write = learned
    pooled_operations, _, pooled_write = frequency_matched(learned)
    print("反转环境的精确期望净回报，来源选择 × 写入规则")
    for source_name, source_rule in (("已学来源", operations), ("等频来源", pooled_operations)):
        for gate_name, gate in (("已学写入", write), ("等频写入", pooled_write)):
            value = expected_return((source_rule, follow, gate), REVERSED)
            print(source_name, gate_name, f"{value:.3f}")
