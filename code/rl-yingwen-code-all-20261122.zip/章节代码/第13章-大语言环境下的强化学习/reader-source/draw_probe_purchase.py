"""从实际部署结果重绘可放弃核验实验的标签购买量与净回报。"""
import argparse
import json
import math
from pathlib import Path

from draw_stream_revaluation import nice_tick, number


ARMS = [
    ('never','从不购买'),
    ('alternating','隔窗购买'),
    ('fixed','随机购买'),
    ('periodic','每窗购买'),
    ('learned','学习购买'),
]


STYLE = """
<style>
.probe-purchase{container-type:inline-size;border-block:2px solid #698c85;padding:.82rem .2rem .42rem;color:#16393e;font: .92rem/1.58 var(--sans,sans-serif)}
.probe-purchase .buy-title{font:700 1.18rem/1.5 var(--serif,serif);margin:0 0 .35rem}
.probe-purchase p,.probe-purchase figcaption{padding:0;margin:.38rem 0 .58rem;font:.88rem/1.6 var(--sans,sans-serif)}
.probe-purchase .buy-panel{margin:1rem 0 .9rem}
.probe-purchase h5{font:650 .96rem/1.5 var(--sans,sans-serif);margin:.15rem 0}
.probe-purchase .buy-row{display:grid;grid-template-columns:minmax(5rem,.6fr) minmax(7.05rem,1fr) minmax(8.5rem,1.25fr);column-gap:1rem;align-items:center}
.probe-purchase .buy-label{font-size:.88rem}
.probe-purchase .buy-cell{display:grid;grid-template-columns:minmax(1.5rem,1fr) 4.1rem;gap:.45rem;align-items:center;min-width:0}
.probe-purchase .buy-num{font: .84rem/1.44 var(--sans,sans-serif);font-variant-numeric:tabular-nums;text-align:right;white-space:nowrap}
.probe-purchase .buy-fill,.probe-purchase .buy-net{display:block;height:.48rem;background:#e2e9e5}
.probe-purchase .buy-fill i{display:block;height:100%;background:#709c9c}
.probe-purchase .buy-net{position:relative;background:linear-gradient(to bottom,transparent 36%,#b9c7c2 37%,#b9c7c2 64%,transparent 65%)}
.probe-purchase .buy-net i{position:absolute;display:block;border:1.5px solid #4d7f80;background:#fffefa;width:.65rem;height:.65rem;top:50%;transform:translate(-50%,-50%);border-radius:50%}
.probe-purchase .buy-row.data{border-top:1px solid #dae2de;padding:.32rem .12rem}
.probe-purchase .buy-row.actor{background:#eaf1ed;font-weight:650}
.probe-purchase .actor .buy-fill i,.probe-purchase .actor .buy-net i{background:#176965}
.probe-purchase .actor .buy-net i{border-color:#176965}
.probe-purchase .buy-header{align-items:end;color:#38585a;padding:0 .12rem .24rem;font-size:.81rem;line-height:1.4}
.probe-purchase .buy-ticks{font: .72rem/1.4 var(--sans,sans-serif);color:#4f686a;margin:.1rem 4.55rem 0 0;display:flex;justify-content:space-between;white-space:nowrap}
.probe-purchase .buy-key{font-size:.83rem;color:#3e555a}
.probe-purchase .buy-paired{padding:.29rem .12rem 0;border-top:1px solid #cbd7ce;font:.84rem/1.6 var(--sans,sans-serif)}
.probe-purchase figcaption{font-size:.83rem;color:#526269;padding-top:.26rem;border-top:1px solid #cbd7ce}
@container(max-width:34rem){
.probe-purchase .buy-row{grid-template-columns:minmax(3.3rem,.66fr) minmax(5.2rem,1.03fr) minmax(6.3rem,1.22fr);column-gap:.45rem}
.probe-purchase .buy-cell{display:flex;flex-direction:column;gap:.12rem;align-items:stretch;padding:.15rem 0}
.probe-purchase .buy-num{text-align:center;font-size:.79rem}
.probe-purchase .buy-ticks{margin-right:0}
.probe-purchase .buy-label{font-size:.84rem}
}
@media print{.probe-purchase *{print-color-adjust:exact}}
</style>
"""


def interval_str(e):
    def as_signed(n):
        sign = '+' if n > 0 else '−' if n < 0 else ''
        return f'{sign}{abs(n):.2f}'
    assert e['low'] <= e['mean'] <= e['high']
    return f'{as_signed(e["mean"])} [{as_signed(e["low"])}, {as_signed(e["high"])}]'


def axis(nets):
    step = nice_tick(max(nets)-min(nets))
    a = math.floor(min(nets)/step)*step
    b = max(a+step,math.ceil(max(nets)/step)*step)
    # Leave visual space for the endpoints of the marked interval.
    return a,b


def row(arm, name, stats, budget, lo, hi):
    count, net = stats['labels']['mean'],stats['net']['mean']
    assert 0 <= count <= budget
    lower,upper = stats['label_range']
    assert 0 <= lower <= count <= upper <= budget
    assert lo <= net <= hi
    amount = f'{count:.1f}' if count % 1 else f'{int(count)}'
    pct = 100 * count / budget
    pos = 100 * (net-lo) / (hi-lo)
    return f"""
<div class="buy-row data{' actor' if arm == 'learned' else ''}" role="row">
<span class="buy-label" role="rowheader">{name}</span>
<div class="buy-cell" role="cell" title="每条经验流实际购买 {lower} 至 {upper} 个标签"><span class="buy-fill" aria-hidden="true"><i style="width:{pct:.3f}%"></i></span><span class="buy-num">{amount}</span></div>
<div class="buy-cell" role="cell"><span class="buy-net" aria-hidden="true"><i style="left:{pos:.3f}%"></i></span><span class="buy-num">{net:,.1f}</span></div>
</div>"""


def panel(title, scenario, budget):
    arm_stats = scenario['summary']
    nets = [arm_stats[k]['net']['mean'] for k,_ in ARMS]
    a,b = axis(nets)
    heads = f"""
<div class="buy-row buy-header" role="row">
<span role="columnheader">购买规则</span>
<span role="columnheader">实际标签数<span class="buy-ticks"><span>0</span><span>{budget}</span></span></span>
<span role="columnheader">全程净回报（分）<span class="buy-ticks"><span>{number(a)}</span><span>{number(b)}</span></span></span>
</div>"""
    rows = ''.join(row(arm, name, arm_stats[arm],budget,a,b) for arm,name in ARMS)
    assert arm_stats['never']['labels']['mean'] == 0
    assert arm_stats['alternating']['labels']['mean'] == budget/2
    assert arm_stats['periodic']['labels']['mean'] == budget
    differences = scenario['learned_minus']
    for key,interval in differences.items():
        assert abs(interval['mean'] - arm_stats['learned']['net']['mean'] + arm_stats[key]['net']['mean']) < .01
    return f"""<div class="buy-panel"><h5>{title}</h5>
<div role="table" aria-label="{title}中五种购买规则的平均标签购买量和累计净回报">{heads}{rows}</div>
<div class="buy-paired">学习策略的全程净回报差（分，95% 配对区间）<br>
对随机购买　{interval_str(differences['fixed'])}　<br class="buy-break">对隔窗购买　{interval_str(differences['alternating'])}</div></div>"""


def graphic(result):
    c, scenarios = result['config'],result['scenarios']
    window = c['window']
    horizon = c['horizon']
    budget = 2*horizon//window
    panels = panel('来源可靠性稳定',scenarios['stable'],budget) + panel(
        f'来源可靠性在第 {c["change_at"]} 组反转',scenarios['reversal'],budget)
    return f"""{STYLE}
<figure id="probe-purchase-figure" class="probe-purchase" aria-labelledby="buy-head">
<h4 id="buy-head" class="buy-title">可放弃核验时的购买量与净回报</h4>
<p>每 {window} 组委托有一次购买机会。购买即在第 1、2 组分别核验一个来源，放弃则整窗沿用已有来源记录。共同上限为每条经验流 {budget} 个标签。隔窗购买固定花一半配额，随机购买逐窗以 ½ 概率购买。</p>
{panels}
<figcaption>每行汇总 {c["repetitions"]} 条独立模拟流，每条 {horizon:,} 组委托。横条表示平均实际购买量。圆点表示平均累计净回报，绝对数值列在同一行。两个环境的净回报刻度分别标出。净回报已扣除实际发生的操作、暂存、核验和修订费用。区间以整条经验流为配对单位。</figcaption>
</figure>
"""


def main():
    folder = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('results',type=Path,nargs='?',default=folder/'probe-purchase-results.json')
    parser.add_argument('--output',type=Path,default=folder/'probe-purchase-figure.html')
    args = parser.parse_args()
    args.output.write_text(graphic(json.loads(args.results.read_text())),encoding='utf-8')


if __name__ == '__main__':
    main()
