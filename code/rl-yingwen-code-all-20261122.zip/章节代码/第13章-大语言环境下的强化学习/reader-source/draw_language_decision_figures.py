"""Draw the analytical figures for message probabilities, feedback and policy improvement."""
import math
from html import escape
from pathlib import Path

HERE = Path(__file__).resolve().parent
TEAL = "#176b67"
BLUE = "#366487"
RUST = "#9b4e2e"
INK = "#243b41"
GRAY = "#607379"
PAPER = "#fffcf5"
LIGHT = "#dae3de"


def label(x, y, words, size=13, align="middle", color=INK, bold=False):
    weight = 650 if bold else 450
    return (f'<text x="{x}" y="{y}" text-anchor="{align}" style="font-size:{size}px;'
            f'font-weight:{weight};fill:{color}">{escape(words)}</text>')


def line(x1, y1, x2, y2, color=GRAY, width=1, extra=""):
    return f'<path d="M{x1} {y1} L{x2} {y2}" fill="none" stroke="{color}" stroke-width="{width}" {extra}/>'


def rect(x, y, w, h, color, stroke="none"):
    return f'<rect x="{x}" y="{y}" width="{w}" height="{h}" fill="{color}" stroke="{stroke}"/>'


def svg(words, h, body):
    return f'<svg viewBox="0 0 340 {h}" role="img" aria-label="{escape(words,quote=True)}">{body}</svg>'


def panel(title, graph, note):
    return f'<div class="ld-panel"><h5>{title}</h5>{graph}<p>{note}</p></div>'


def save(slug, title, lead, inner, caption):
    markup = (f'<figure id="{slug}" class="ld-figure" aria-labelledby="{slug}-title">'
              f'<h4 id="{slug}-title">{title}</h4><p class="ld-lead">{lead}</p>{inner}'
              f'<figcaption>{caption}</figcaption></figure>\n')
    (HERE/f'{slug}.html').write_text(markup)


def ribbon(x0, y0, x1, y1, height, color, opacity):
    mid = (x0+x1)/2
    path = (f'M{x0},{y0} C{mid},{y0} {mid},{y1} {x1},{y1} v{height} '
            f'C{mid},{y1+height} {mid},{y0+height} {x0},{y0+height} z')
    return f'<path d="{path}" fill="{color}" opacity="{opacity}"/>'


def message():
    # Equal ribbon widths represent equal joint probability throughout both drawings.
    scale = 128
    routes = [(.30,53,53,TEAL),(.30,53+.30*scale,145,BLUE),
              (.10,157,53+.30*scale,TEAL),(.30,157+.10*scale,145+.30*scale,BLUE)]
    first = ''.join(ribbon(59,left,284,right,mass*scale,color,.75) for mass,left,right,color in routes)
    for x,y,h in [(54,53,.6*scale),(54,157,.4*scale),(284,53,.4*scale),(284,145,.6*scale)]:
        first += rect(x,y,5,h,INK)
    first += label(53,34,"私有词元",14)+label(279,34,"外发消息",14)
    first += label(47,81,"疑",14,"end")+label(47,99,"60%",12,"end")
    first += label(47,180,"信",14,"end")+label(47,197,"40%",12,"end")
    first += label(296,78,"查",14,"start",TEAL,True)+label(296,96,"40%",12,"start")
    first += label(296,178,"答",14,"start",BLUE,True)+label(296,197,"60%",12,"start")
    first += label(117,48,"30%",12,color=TEAL)+label(84,149,"10%",12,color=TEAL)
    second = ribbon(59,61,277,61,.30*scale,TEAL,.75)+ribbon(59,61+.30*scale,277,144,.10*scale,RUST,.7)
    second += rect(54,61,5,.40*scale,INK)+rect(277,61,5,.30*scale,INK)+rect(277,144,5,.10*scale,INK)
    second += label(48,34,"已发送",14)+label(278,34,"环境返回",14)
    second += label(45,80,"查",14,"end",TEAL,True)+label(45,99,"40%",12,"end")
    second += label(289,82,"有资料",13,"start")+label(289,154,"无资料",13,"start")
    second += label(160,53,"30% 的全部运行",12,color=TEAL)+label(170,161,"10% 的全部运行",12,color=RUST)
    second += line(54,197,279,197,LIGHT)+label(168,216,"给定已经查询：75% 有资料，25% 无资料",13)
    a=panel("两条生成路径可以发出同一消息",svg("第一词疑占六成，其中一半查；信占四成，其中四分之一查。两股合流，四成运行发送查。",234,first),
            "首词只在智能体内部可见。第二词外发。两条绿色路径的概率分别为 0.60 × 0.50 与 0.40 × 0.25。")
    b=panel("同一消息可以产生不同观测",svg("发送查的四成运行中，三成总运行得到资料，一成总运行得到空回执。",234,second),
            "给定消息“查”，外部服务以 0.75 的概率返回资料。因此从原提示开始，收到这份资料的概率是 0.40 × 0.75 = 0.30。")
    save('language-message-flow','生成路径、外发消息与环境返回',
         '带的宽度表示从同一提示出发的概率。每轮生成两个词元。首词取“疑”或“信”，次词取“查”或“答”。',
         '<div class="ld-grid">'+a+b+'</div>',
         '沿同一条路径乘条件概率，汇入同一消息的路径概率相加。外部服务只看外发消息。回执可以改变智能体下一轮的输入，对该回执的生成概率应由环境响应核建模。图中概率为设定值。智能体—环境边界参见 <a href="https://mitpress.mit.edu/9780262039246/reinforcement-learning/">Sutton 与 Barto 第 2 版，图 3.1</a>。')


def evidence():
    # p is the independent chance of obtaining one perfectly discriminating observation.
    panels = []
    m = .40
    for prob,color,ttl in [(0,GRAY,'相同回执'),(.10,TEAL,'可区分的回执')]:
        chart=''
        x=lambda n:42+8.9*n
        y=lambda loss:161-480*loss
        for loss in (0,.1,.2):
            chart+=line(41,y(loss),314,y(loss),LIGHT)+label(34,y(loss)+4,f'{100*loss:.0f}',12,'end')
        for n in (0,10,20,30):
            chart+=label(x(n),180,str(n),12)
        chart+=label(37,27,'最小期望回报损失（百分点）',14,'start')
        plot=' '.join(f'{("M" if n==0 else "L")}{x(n):.2f},{y(m/2*(1-prob)**n):.2f}' for n in range(31))
        chart+=f'<path d="{plot}" fill="none" stroke="{color}" stroke-width="3"/>'
        val=m/2*(1-prob)**10
        chart+=line(x(10),y(val),x(10),161,GRAY,1,'stroke-dasharray="3 3"')
        chart+=f'<circle cx="{x(10)}" cy="{y(val)}" r="4" fill="{color}"/>'
        chart+=label(x(10)+8,y(val)-8,f'{100*val:.2f}',13,'start',color,True)
        chart+=label(311,202,'训练交互次数',13,'end')
        note=('所有训练回执在两个世界中同分布。十次和三十次交互留下相同的不确定性。' if prob==0 else
              '每次有 10% 概率获得能揭示规律的独立回执。十次仍未得到这种回执的概率约为 35%。')
        panels.append(panel(ttl,svg(note,214,chart),note))
    save('feedback-distinguishability','哪些经验能区分两种相反的行动排序',
         '两个世界等可能。在一个世界采取甲比乙多得 0.40 回报，另一个世界恰好相反。训练期间世界固定，最后依据完整记录作一次选择。',
         '<div class="ld-grid">'+''.join(panels)+'</div>',
         '取得一次可辨回执后即可选对；始终未取得时，两种世界仍等可能，最优决策也有一半机会选错。每次独立获得这种回执的概率为 p，n 次训练后的最小期望损失恰为 0.20 × (1 − p)ⁿ。两幅图给出该模型的解析值。')


def return_area():
    # The split controls the first action; continuation policies stay fixed.
    cases=[]
    for p in (.25,.50,.75):
        cut=42+256*p
        plot=label(44,27,'到达以后，改选答案带来的回报变化',13,'start')
        for change in (-.04,0,.06):
            yy=115-800*change
            plot+=line(42,yy,298,yy,LIGHT)+label(35,yy+4,f'{change*100:+.0f}',12,'end')
        plot+=rect(42,67,cut-42,48,'#88b9ab')+rect(cut,115,298-cut,32,'#d7a588')
        plot+=line(42,115,298,115,INK,1.5)+line(cut,57,cut,156,GRAY,1,'stroke-dasharray="2 3"')
        plot+=label((42+cut)/2,96,'甲',15,color=INK,bold=True)+label((cut+298)/2,137,'乙',15,color=INK,bold=True)
        plot+=label((42+cut)/2,177,f'{p:.0%}',13)+label((cut+298)/2,177,f'{1-p:.0%}',13)
        plot+=label(169,197,'矩形宽度 = 新策略的访问概率',13)
        root_gain=(p-.5)*.20
        new=p*.66+(1-p)*.36
        end_gain=p*.06+(1-p)*(-.04)
        assert math.isclose(root_gain+end_gain,new-.50,abs_tol=1e-12)
        sign=lambda v:f'{100*v:+.1f}' if abs(v)>1e-10 else '0.0'
        body=svg(f'路线甲占{p:.0%}，条件收益正6个百分点；路线乙占{1-p:.0%}，损失4个百分点。',209,plot)
        text=(f'<div class="ld-result"><b>从原始提示作答　50.0% → {new:.1%}</b>'
              f'<p>首次选路线 <strong>{sign(root_gain)}</strong>；到达甲后改选答案 <strong>{sign(p*.06)}</strong>；'
              f'到达乙后改选答案 <strong>{sign((1-p)*(-.04))}</strong>。三项合计 <strong>{sign(new-.50)}</strong> 个百分点。</p></div>')
        cases.append(f'<div class="ld-case">{body}{text}</div>')
    controls=''.join(f'<input id="ld-pr-{k}" name="ld-route" type="radio" {("checked" if k==75 else "")}><label for="ld-pr-{k}">{k}%</label>' for k in [25,50,75])
    save('policy-return-area','局部策略改进在完整回报中占多大分量',
         '首词把回答分入路线甲或乙，旧策略各走一半。在每条路线上，旧策略各以一半概率选答案 1。换用新策略后，甲上选答案 1 的概率升到 60%，乙上降到 30%。',
         '<div class="ld-config"><span>新策略选择路线甲的概率</span>'+controls+
         '<div class="ld-cases">'+''.join(cases)+'</div></div>',
         '答案 1、0 在甲上的通过率为 90%、30%，在乙上为 50%、30%。旧策略的两条路线因此分别值 60%、40%，首次改选路线的增益由这 20 个百分点之差决定。图中绿色面积是甲上改选答案贡献的收益，棕色面积是乙上的损失。纵轴单位为百分点。可切换路线概率，比较同一对局部更新的整策略结果。图示为解析计算。<a href="#credit-paired-outcomes">比较有限预算训练中的成对结果</a>。')



def backup_lattice():
    headers = ["单次采样", "三次采样", "精确期望"]
    cards = ['<div class="ld-lattice">']
    nodes = [(10,58),(61,32),(61,85),(116,11),(116,48),(116,70),(116,104)]
    edges = [(0,1),(0,2),(1,3),(1,4),(2,5),(2,6)]
    for depth in (1,2):
        boundary = '收到回执，用估值接续' if depth==1 else '展开到终局，以成败计分'
        cards.append(f'<p class="ld-band">{boundary}</p>')
        for col, header in enumerate(headers):
            count_sets=([1,0,1,0,0,0],[2,1,1,1,0,1],[1,1,1,1,1,1])
            counts=count_sets[col]
            ends=set()
            graph=''
            for i, (src, dst) in enumerate(edges):
                if depth==1 and src:
                    continue
                x0,y0=nodes[src];x1,y1=nodes[dst];num=counts[i]
                color=TEAL if num else '#a9b8b5'
                graph+=line(x0,y0,x1,y1,color,2.8 if num else 1.25,'' if num else 'stroke-dasharray="3 3"')
                if num:
                    ends.add(dst)
            graph+=f'<circle cx="10" cy="58" r="5" fill="{INK}"/>'
            for i,(x,y) in enumerate(nodes[1:],1):
                if depth==1 and i>2:
                    continue
                colr=TEAL if i in ends else '#a9b8b5'
                if i<=2 and depth==2:
                    graph+=f'<circle cx="{x}" cy="{y}" r="4" fill="{PAPER}" stroke="{colr}" stroke-width="2"/>'
                elif i<=2:
                    graph+=f'<path d="M{x} {y-6} l6 6 -6 6 -6 -6 z" fill="{PAPER}" stroke="{colr}" stroke-width="2"/>'
                else:
                    graph+=rect(x-4,y-4,8,8,PAPER,colr)
            if depth==1:
                if col==1:
                    graph+=label(73,36,'×2',15,'start',TEAL)+label(73,89,'×1',15,'start',TEAL)
                if col==2:
                    graph+=label(73,36,'p',16,'start',TEAL)+label(73,89,'1−p',15,'start',TEAL)
            elif col==2:
                graph+=label(35,32,'p',13,color=TEAL)+label(35,94,'1−p',13,color=TEAL)
            notes=[['一次回执的估值','三个回执的估值取平均','两种回执按概率加权'],
                   ['一次完整回报','三次完整回报取平均','各叶回报按路径概率加权']]
            leg=f'{header}，{boundary}：{notes[depth-1][col]}。'
            cards.append(f'<div class="ld-cell"><b>{header}</b><svg viewBox="0 0 130 116" role="img" aria-label="{leg}">{graph}</svg><span>{notes[depth-1][col]}</span></div>')
    cards.append('</div>')
    save('backup-design-space','动作价值更新的深度与宽度',
         '从同一个已发送的请求出发。横向改变在这个前缀取得多少种后果，纵向改变等待回报的长度。固定后续策略、环境和终局目标。',
         ''.join(cards),
         '每幅小图的实心起点是同一请求。沿实线向右展开，灰色虚线表示本次没有用到的可能分支。菱形读入后续价值估计，方形读入终局回报；随后向左取平均。采三次时按出现次数取平均，右列用已知响应与续行概率加权。深度与宽度的画法参见 <a href="https://mitpress.mit.edu/9780262039246/reinforcement-learning/">Sutton 与 Barto 第 2 版，图 8.11</a>。<a href="#return-backup-tree">展开一棵带概率和更新目标的树</a>。')


if __name__ == '__main__':
    message()
    evidence()
    return_area()
    backup_lattice()
