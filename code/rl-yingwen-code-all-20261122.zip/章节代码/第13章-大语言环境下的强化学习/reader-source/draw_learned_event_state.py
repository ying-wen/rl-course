"""Render a recorded event trace and paired deployment contrasts for chapter 13."""
import argparse
import json
from html import escape
from math import ceil, floor, log10, sqrt
from pathlib import Path
from statistics import mean, stdev

from decision_returns import ACTIONS

HERE = Path(__file__).resolve().parent
BATCHES = ("第一批", "第二批")
WORLDS = (("stable", "稳定环境"), ("reversal", "来源反转"))
COMPARISONS = (
    ("learned_minus_basic", "学得的状态与仅用提示",
     {"learned_short": .5, "learned_long": .5, "basic_short": -.5, "basic_long": -.5}),
    ("learned_minus_frozen", "学得的状态与冻结表示",
     {"learned_short": .5, "learned_long": .5, "frozen_short": -.5, "frozen_long": -.5}),
    ("long_average", "长资格迹与短资格迹",
     {m + "_" + length: weight for m in ("basic", "frozen", "learned")
      for length, weight in (("long", 1/3), ("short", -1/3))}),
)


def signed(number):
    return (f"{number:+.2f}" if abs(number) >= .005 else "0.00").replace("-", "−")


def paired_estimate(streams, coefficients, expected_budget):
    """Compute the effect within each deployment before computing an interval."""
    groups = {key: {row["seed"]: row for row in streams[key]} for key in coefficients}
    seeds = next(iter(groups.values())).keys()
    if any(group.keys() != seeds for group in groups.values()):
        raise ValueError("Unmatched deployment seeds.")
    if any(row["labels"] != expected_budget for group in groups.values() for row in group.values()):
        raise ValueError("Unequal observation budgets.")
    differences = [sum(weight * groups[key][seed]["net"] for key, weight in coefficients.items())
                   for seed in seeds]
    center = mean(differences)
    radius = 1.96 * stdev(differences) / sqrt(len(differences))
    return (center, center - radius, center + radius)


def event_timeline(events):
    request = next(e for e in events if e["role"] == "agent")
    receipts = [e for e in events if e["role"] == "evaluator"]
    actions = {e["group"]: e for e in events if e["role"] == "runtime"}
    if len(request["tokens"]) != 2 or len(receipts) != 2:
        raise ValueError("A two-token request and two observed receipts are required.")
    pairs = [(actions[r["origin"]], r) for r in receipts]
    start, end = min(a["group"] for a, _ in pairs), max(r["group"] for _, r in pairs)
    prob = request["token_probabilities"]
    words = [escape(w) for w in request["tokens"]]
    timing = "第一个机会" if request["executed_timing"] else "第二个机会"
    header = (f'<div class="ev13-request"><span>第 {request["group"]} 组 · 智能体生成</span>'
              f'<span class="ev13-token"><code>{words[0]}</code><small>策略概率 {prob[0]:.2f}</small></span>'
              '<span aria-hidden="true">→</span>'
              f'<span class="ev13-token"><code>{words[1]}</code><small>给定前缀，概率 {prob[1]:.2f}</small></span>'
              f'<span class="ev13-schedule">接口将两个探测名额安排在{timing}</span></div>')
    # All event locations lie on a common group clock. Label each lane by its
    # actual runtime operation. The arrow ends at its own linked receipt.
    def x(group):
        return 76 + (group-start) * 202/(end-start)
    marks = []
    for group in range(start, end+1):
        pos = x(group)
        marks.append(f'<path class="ev13-grid" d="M{pos:g} 25V122"/>'
                     f'<text x="{pos:g}" y="18" text-anchor="middle">{group}</text>')
    descr = []
    for idx, (action, receipt) in enumerate(pairs):
        if action["executed"] != receipt["source"]:
            raise ValueError("Receipt source disagrees with the executed operation.")
        origin, arrival = action["group"], receipt["group"]
        label = ACTIONS[action["executed"]]
        correct = "正确" if receipt["correct"] else "错误"
        descr.append(f'第{origin}组{label}，第{arrival}组收到线索{correct}的回执')
        y, left, right = 49 + idx*53, x(origin), x(arrival)
        marks.append(f'<text x="3" y="{y+4}">来源 · {label}</text>'
                     f'<path class="ev13-delay" d="M{left:g} {y}H{right:g}"/>'
                     f'<path class="ev13-exec" d="M{left-5:g} {y-5}h10v10h-10z"/>'
                     f'<path class="ev13-receipt" d="M{right:g} {y-7}l7 7-7 7-7-7z"/>'
                     f'<text class="ev13-anno" x="{left:g}" y="{y+19}" text-anchor="middle">执行</text>'
                     f'<text class="ev13-anno" x="{right:g}" y="{y+19}" text-anchor="middle">回执 · {correct}</text>')
    return (header + '<svg class="ev13-time" viewBox="0 0 316 128" role="img">'
            f'<title>按委托组计时。{escape("。".join(descr))}。</title>'
            '<text x="3" y="18">委托组</text>' + ''.join(marks) + '</svg>')


def effect_panel(name, rows):
    # A common axis per comparison permits a direct comparison across worlds.
    extent = max(abs(value) for records in rows.values() for interval in records for value in interval)
    base = 10**floor(log10(extent/2)) if extent else 1
    unit = next(v*base for v in (1, 2, 2.5, 5, 10) if 2*v*base >= extent)
    limit = max(unit, ceil(extent/unit)*unit)
    def x(value):
        return 127 + value*94/limit
    marks = []
    table = []
    for idx, (world, world_label) in enumerate(WORLDS):
        y = 34 + idx*68
        marks.append(f'<text class="ev13-world" x="3" y="{y-12}">{world_label}</text>')
        for batch_idx, (center, low, high) in enumerate(rows[world]):
            cy = y + batch_idx*16
            middle, left, right = x(center), x(low), x(high)
            ie = f'{signed(center)} [{signed(low)}, {signed(high)}]'
            desc = f'{world_label}，{BATCHES[batch_idx]}：{ie}'
            table.append(f'<li><span>{world_label} · {BATCHES[batch_idx]}</span><strong>{ie}</strong></li>')
            marker = (f'<circle cx="{middle:.2f}" cy="{cy}" r="3.4"/>' if batch_idx == 0 else
                      f'<rect x="{middle-3:.2f}" y="{cy-3}" width="6" height="6" class="ev13-open"/>')
            marks.append(f'<g class="ev13-batch{batch_idx+1}"><title>{desc}</title>'
                         f'<path d="M{left:.2f} {cy-3}v6m0 -3H{right:.2f}m0 -3v6"/>'
                         f'{marker}<text x="244" y="{cy+4}" text-anchor="end">{signed(center)}</text></g>')
    for v in (-limit, 0., limit):
        tick = x(v)
        marks.append(f'<path class="ev13-grid" d="M{tick:.2f} 130v4"/>'
                     f'<text x="{tick:.2f}" y="148" text-anchor="middle">{v:g}</text>')
    panel = (f'<div class="ev13-panel"><h5>{name}</h5><svg viewBox="0 0 250 154" role="img">'
             f'<title>{name}。横轴为全程净回报差，零为无差。精确区间在图后。</title>'
             '<path class="ev13-zero" d="M127 24v104"/><path class="ev13-grid" d="M33 130h188"/>'
             + ''.join(marks)+'</svg></div>')
    return panel, f'<h5>{name}</h5><ul>{"".join(table)}</ul>'


STYLE = """
<style>
.ev13{color:#233e40;container-type:inline-size;border-block:2px solid #63877f;padding:.86rem 0;font-family:var(--sans,sans-serif)}
.ev13 h4,.ev13 h5,.ev13 p,.ev13 figcaption{margin:0;font:inherit;padding:0}
.ev13 h4{font:700 1.18rem/1.45 var(--serif,serif);color:#173438;margin:0 0 .45rem}
.ev13 h5{font:650 .92rem/1.45 var(--sans,sans-serif);color:#193d40}
.ev13 p,.ev13 figcaption,.ev13 details{font:.84rem/1.65 var(--sans,sans-serif)}
.ev13 .ev13-intro{color:#455d5d}
.ev13 .ev13-record{display:grid;grid-template-columns:1fr 1fr;gap:.7rem 1.1rem;align-items:center;border-bottom:1px solid #bdcdc7;padding:.45rem 0 .7rem}
.ev13 .ev13-request{display:flex;align-items:center;flex-wrap:wrap;gap:.25rem .45rem;line-height:1.45}
.ev13 .ev13-request>span:first-child,.ev13 .ev13-schedule{flex:0 0 100%;font-size:.84rem}
.ev13 .ev13-token{display:inline-flex;flex-direction:column;align-items:center;border:1px solid #b7cac3;padding:.23rem .55rem;background:#f1f5f1;border-radius:.25rem}
.ev13 .ev13-token code{font:600 .92rem/1.4 monospace;color:#22433e}.ev13 .ev13-token small{font:.73rem/1.4 var(--sans,sans-serif)}
.ev13 .ev13-schedule{border-left:2px solid #9c7653;padding-left:.48rem;margin-top:.25rem}
.ev13 svg{display:block;width:100%;height:auto}.ev13 .ev13-time{max-width:24rem}
.ev13 svg text{font:12px var(--sans,sans-serif);fill:#354f50}
.ev13 .ev13-grid{fill:none;stroke:#c1ccc6;stroke-width:.85}
.ev13 .ev13-exec{fill:#17646b}.ev13 .ev13-delay{fill:none;stroke:#738e87;stroke-width:1.6;stroke-dasharray:3.5 2.5}
.ev13 .ev13-receipt{fill:#fff9ef;stroke:#92532d;stroke-width:2}.ev13 .ev13-anno{font-size:11px}
.ev13 .ev13-clocks{margin:.6rem 0 1.15rem}.ev13 .ev13-clocks b{color:#164b4b}
.ev13 .ev13-panelset{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,13.7rem),1fr));gap:.6rem;margin:.6rem 0 .4rem}
.ev13 .ev13-panel{border-top:1px solid #adc3b9;padding-top:.36rem;min-width:0}.ev13 .ev13-panel svg{max-width:22rem}
.ev13 .ev13-world{font-size:11.5px;font-weight:620}
.ev13 .ev13-zero{stroke:#687e75;fill:none;stroke-width:1.15;stroke-dasharray:3 2.5}
.ev13 .ev13-batch1{color:#11656f}.ev13 .ev13-batch2{color:#935028}
.ev13 .ev13-batch1 path,.ev13 .ev13-batch2 path{stroke:currentColor;stroke-width:1.8;fill:none}
.ev13 .ev13-batch1 circle{fill:currentColor}.ev13 .ev13-open{stroke:currentColor;fill:white;stroke-width:1.7}
.ev13 .ev13-batch1 text,.ev13 .ev13-batch2 text{fill:currentColor;font-size:10.5px}
.ev13 .ev13-legend{display:flex;flex-wrap:wrap;gap:.35rem .9rem;color:#48625e}
.ev13 .ev13-legend b:first-child{color:#11656f}.ev13 .ev13-legend b:nth-child(2){color:#935028}
.ev13 figcaption{color:#405956}.ev13 details{margin:.55rem 0 0}.ev13 details summary{cursor:pointer;color:#255956}
.ev13 details ul{margin:.2rem 0 .55rem;padding:0;list-style:none}.ev13 details li{display:flex;flex-wrap:wrap;gap:.2rem .8rem;margin:0}
.ev13 details strong{font-variant-numeric:tabular-nums;font-weight:550}
@container(max-width:31rem){.ev13 .ev13-record{grid-template-columns:1fr}.ev13 .ev13-panelset{grid-template-columns:1fr}.ev13 .ev13-panel svg{max-width:20rem}}
@media print{.ev13 .ev13-panel,.ev13 .ev13-record{break-inside:avoid}.ev13 svg{print-color-adjust:exact}}
</style>
"""


def render(batches):
    cfg = batches[0]["config"]
    count, horizon = cfg["repetitions"], cfg["horizon"]
    budget = horizon//cfg["window"] * cfg["labels_per_window"]
    seed_sets = [set(range(b["config"]["seed"], b["config"]["seed"]+count)) for b in batches]
    if seed_sets[0] & seed_sets[1]:
        raise ValueError("Deployment batches overlap.")
    for b in batches:
        if any(b["config"][key] != cfg[key] for key in ("repetitions", "horizon", "window", "labels_per_window", "change_at")):
            raise ValueError("Different deployment regimes.")
        if not b["actor_step_length"] == b["long_actor_step_length"] == .04:
            raise ValueError("This figure compares matched parameter steps.")
    panels, tables = [], []
    intervals_cover_zero = True
    for key, name, coef in COMPARISONS:
        data = {}
        for world, _ in WORLDS:
            data[world] = []
            for b in batches:
                info = b["worlds"][world]
                values = paired_estimate(info["streams"], coef, budget)
                saved = info["contrasts"][key]["net"]
                if max(abs(a-saved[k]) for a,k in zip(values, ("mean", "low", "high"))) > 1e-8:
                    raise ValueError("Recomputed intervals differ from stored interval.")
                data[world].append(values)
                intervals_cover_zero &= values[1] <= 0 <= values[2]
        panel, table = effect_panel(name, data)
        panels.append(panel)
        tables.append(table)
    example = batches[0]["worlds"]["stable"]["example"]
    first_seed = cfg["seed"]
    interval_note = "本次三个比较在两种环境、两批部署中的区间均包含零。" if intervals_cover_zero else ""
    return STYLE + f"""
<figure class="ev13" aria-labelledby="ev13-caption">
<h4>探测时机的经验、状态与净回报</h4>
<p class="ev13-intro">首窗的生成记录取自稳定环境中种子 {first_seed} 的部署。方块表示接口实际执行，菱形表示评定者送达的回执。虚线连接同一项操作和回执。</p>
<div class="ev13-record">{event_timeline(example)}</div>
<p class="ev13-clocks"><b>状态估计按事件读入。</b> 截至下一次选择，已送达的回执可改变立即与暂缓两支的预测。每次以已选分支随后四窗的平均净回报训练读出和共享表示。<b>策略资格迹按窗口衰减。</b> 一窗的净回报可更新早先选择时记录的策略得分。</p>
<h5>等探测预算、等参数步幅下的全程净回报差</h5>
<p class="ev13-legend"><b>● 第一批</b><b>□ 第二批</b><span>点为配对均值，横线为约 95% 区间，虚线为零。</span></p>
<div class="ev13-panelset">{''.join(panels)}</div>
<figcaption id="ev13-caption">每幅图横轴单位为分，正值表示标题中前一种规则的净回报更高。前两幅对长短迹取平均，第三幅对三种状态读入取平均后比较长迹（0.97）与短迹（0.80）。各幅横轴刻度单独标出。两批各 {count} 条独立部署流，同一条流内六种规则使用配对种子。每条流经历 {horizon} 组，取得 {budget} 个标签；反转发生在第 {cfg["change_at"]} 组。每次非零策略参数增量均为 0.04，行动概率的实际变化还取决于当时的策略和输入。{interval_note}</figcaption>
<details><summary>各环境的净回报差与配对区间</summary>{''.join(tables)}</details>
</figure>
"""


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--first", type=Path, default=HERE / "probe-state-results.json")
    parser.add_argument("--second", type=Path, default=HERE / "probe-state-validation.json")
    parser.add_argument("--out", type=Path, default=HERE / "learned-event-state.html")
    args = parser.parse_args()
    batches = [json.loads(path.read_text()) for path in (args.first, args.second)]
    args.out.write_text(render(batches), encoding="utf-8")
