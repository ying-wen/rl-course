# 学习探测时机：两种预算下的单流实验

使用 Python 3.10 或更高版本。将五个 Python 文件放在同一目录，只需 Python 标准库。

```bash
python3 probe_policy_learning.py --budget exact --json exact.json
python3 probe_policy_learning.py --budget cap --json cap.json
python3 probe_representation_trace.py --seed 81200 --json probe-factorial-results.json
python3 probe_representation_trace.py --seed 96000 --json probe-factorial-validation.json
```

前两个命令使用同一组 96 个部署种子。程序先在独立的来源环境中训练原作答与写入策略，再开始部署；探测策略在每条流中重新初始化，不会继承其他流中学到的权重。每个窗口内的行动影响后续使用的记忆。窗口结算不会重置智能体。

| 参数 | exact：现在或稍后 | cap：买或不买 |
|---|---|---|
| 购买机会 | 第 1、2 组或第 7、8 组，二选一 | 第 1、2 组；放弃后整窗不买 |
| 每条流的预算 | 恰好 400 张 | 最多 400 张；未用机会到期 |
| 比较策略 | 学习、固定概率、固定周期 | 学习、固定概率、隔窗、每窗、从不买 |
| 两组共有的反馈 | 付费标签和逐项净回报延迟三组送达；每窗另有总净回报 | 同左 |

前两个命令的 `summary` 包含各策略的净回报、实际标签量及修订数。`curves` 记录全程累计表现。`early_minus_defer_value` 和 `buy_minus_skip_value` 分别估计两种协议下的行动价值差，所用起点均由学习策略实际访问。1 窗和 8 窗是不同的评价期限。区间按整条部署计算。

后两个命令在允许放弃购买的协议中，交叉比较输入是否含检验进度、资格迹衰减系数是否由 0.8 改为 0.97。每批 96 条部署，种子互不重叠。`worlds` 下的 `streams` 为逐流观测，`contrasts` 为同一批流上各策略全程净回报等指标的配对差。

`probe_policy_learning.py` 实现概率策略、资格迹、两个预算和评估。`stream_revaluation.py` 实现延迟回执、来源比较和记忆修订。`decision_returns.py` 定义委托环境、费用以及部署前的训练。程序输出来自有已知生成规则的教学模拟。

## 从词元、执行与延迟反馈学习状态

这里采用同额协议，每流取得 400 个标签。决策读到当前条件与复用提示。事件历史按来源记录智能体生成的两词请求、实际执行的来源操作和延迟送达的标签。两个可训练的事件嵌入和相应的行动预测头估计自本窗口起四窗的平均净回报，每窗以 15 分为中心。回报全部到达后，才在当时选择的分支上训练。每组都训练预测器，交叉比较策略是否读到预测的行动价值差，以及资格迹衰减系数取 0.8 或 0.97。另加固定随机事件坐标，比较同样输入维数下的结果。

主实验将策略参数的非零更新长度固定为 0.04。概率步幅对照用一批 24 条独立随机流，仅依据原决策历史处的策略概率均方根变化，选择固定的长迹步长。校准后在两批各 96 条独立流上评价全程回报。学习器在每条流中独立初始化，随机流以外的环境生成规则相同。

```bash
python3 probe_event_state.py --seed 112000 --json probe-state-results.json
python3 probe_event_state.py --seed 124000 --json probe-state-validation.json
python3 probe_event_state.py --calibrate --seed 136000 --repetitions 24 --json probe-state-calibration.json
python3 probe_event_state.py --seed 112000 --use-calibration probe-state-calibration.json --json probe-state-functional-results.json
python3 probe_event_state.py --seed 124000 --use-calibration probe-state-calibration.json --json probe-state-functional-validation.json
```

`policy_rms` 记录每窗策略参数更新的均方根长度。`joint_probability_rms` 在同一个决策起点保留原观测历史，用当窗更新后的策略和表示重新计算购买概率，记录其变化的均方根。`history_gap_rms` 在作选择前用同一对预测头分别读入真实或置零的事件嵌入，记录两次行动价值差预测的差额。`gap_gain` 比较使用行动分支预测或两分支均值时的前瞻均方误差，以两种行动等权计，正值表示分支预测更准确。`example` 保留首条流第一窗的角色标注记录。程序数值只涉及这里规定的词表、执行语义和来源环境。
