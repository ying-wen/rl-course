"""Small, exactly enumerable teaching models for §2 and §10. Run: python3 check_feedback_objectives.py"""
from math import exp, log
from pathlib import Path
import json

sigmoid = lambda x: 1 / (1 + exp(-x))
def deriv(f, x, step=1e-5):
    return (f(x + step) - f(x - step)) / (2 * step)
def kl(p, q):
    return p * log(p/q) + (1-p) * log((1-p)/(1-q))
def assert_near(a, b, tolerance=1e-7):
    assert abs(a-b) < tolerance, (a, b)

# Single-turn, two answers. Reference, common reward units and KL price matter.
prior, beta, reward_gap = .4, .8, 1.1
z0 = log(prior/(1-prior)); zstar = z0 + reward_gap/beta
teacher, pref = sigmoid(zstar), sigmoid(reward_gap)
def objectives(z):
    p = sigmoid(z)
    fitted_pref = sigmoid(beta*(z-z0))
    net_return = p*reward_gap - beta*kl(p,prior)
    pref_loglik = pref*log(fitted_pref) + (1-pref)*log(1-fitted_pref)
    return net_return, pref_loglik, -kl(p,teacher)
for k in range(3):
    f = lambda z: objectives(z)[k]
    assert_near(deriv(f,zstar),0)
    assert f(zstar) > f(zstar-.1) and f(zstar) > f(zstar+.1)

# DPO: direct score terms are indexed by (prefix, chosen token), not token ID alone.
seq = json.loads(Path(__file__).with_name('ordinary-token-spans.json').read_text())['messages']
w,l = (seq[k]['ids'] for k in ('answer','foil'))
terms={}
for path,sign in ((w,1),(l,-1)):
    for j,next_token in enumerate(path):
        key = (tuple(path[:j]), next_token)
        terms[key] = terms.get(key,0)+sign
assert w[:5]==l[:5] and w[5]!=l[5]
assert all(terms[(tuple(w[:j]),w[j])]==0 for j in range(5))
assert w[6]==l[6] and terms[(tuple(w[:6]),w[6])]==1 and terms[(tuple(l[:6]),l[6])]==-1

# Two-stage decision: request a=0/1, external return o=0/1, answer b=0/1.
# Check the pathwise residual and the deployment gap = beta times occupancy-weighted KL.
K=(.35,.8)  # P(o=1 | a); common to student, optimal policy and reference
ref=(.45,.6); student=(.3,.72)
def r0(a): return -.2*a
def r1(a,o,b): return float(o==b)+.12*(a==b)
def probs(p): return (1-p,p)
def soft(q0,q1,p):
    z=(1-p)*exp(q0/beta)+p*exp(q1/beta)
    return (beta*log(z),p*exp(q1/beta)/z)
values={}; opt={}
for a in (0,1):
    for o in (0,1):
        values[a,o],opt[a,o]=soft(r1(a,o,0),r1(a,o,1),ref[1])
q=[r0(a)+sum(probs(K[a])[o]*values[a,o] for o in (0,1)) for a in (0,1)]
V,pstar=soft(*q,ref[0])
J=0; lost=beta*kl(student[0],pstar)
for a,pa in enumerate(probs(student[0])):
    for o,po in enumerate(probs(K[a])):
        residual=r0(a)+values[a,o]-q[a]
        lost+=beta*pa*po*kl(student[1],opt[a,o])
        for b,pb in enumerate(probs(student[1])):
            out=r0(a)+r1(a,o,b)
            regularized=out-beta*log(pa/probs(ref[0])[a])-beta*log(pb/probs(ref[1])[b]);J+=pa*po*pb*regularized
            tilt=log(probs(pstar)[a]/probs(ref[0])[a])+log(probs(opt[a,o])[b]/probs(ref[1])[b])
            assert_near(out,V+beta*tilt+residual)
    assert_near(sum(probs(K[a])[o]*(r0(a)+values[a,o]-q[a]) for o in (0,1)),0)
assert_near(lost,V-J)
print(f'Single-turn common optimum P(first) = {teacher:.6f}; DPO prefix cancellation through token 5;')
print(f'8 multiround paths checked. Deployment gap {V-J:.6f}; environment branch .5, tilted samples {sigmoid(1):.6f}.')
