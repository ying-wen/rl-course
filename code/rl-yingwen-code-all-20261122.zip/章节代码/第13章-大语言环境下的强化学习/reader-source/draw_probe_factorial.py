"""Draw paired factorial contrasts from two independent sets of deployments."""
import argparse
import json
from html import escape
from math import ceil, floor, log10
from pathlib import Path


EFFECTS = (
    ("mean_progress_effect", "加入当前检验进度"),
    ("mean_long_trace_effect", "延长资格迹"),
    ("difference_in_differences", "两项改动的交互效应"),
)

STYLE = """
<style>
.pfx{container-type:inline-size;border-block:2px solid #698c85;padding:.85rem 0 .5rem;color:#213b3c;font-family:var(--sans,sans-serif)}
.pfx h4{font:700 1.2rem/1.5 var(--serif,serif);margin:0 0 .32rem}
.pfx p,.pfx figcaption{padding:0;margin:.25rem 0 .48rem;font:.86rem/1.62 var(--sans,sans-serif)}
.pfx .pfx-key{display:flex;flex-wrap:wrap;gap:.42rem 1rem;color:#32504f;font-size:.83rem}
.pfx .pfx-key b:first-child{color:#11626c}.pfx .pfx-key b:nth-child(2){color:#914b28}
.pfx .pfx-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:.8rem}
.pfx .pfx-panel{border-top:1px solid #bdcac6;padding-top:.35rem;min-width:0}
.pfx .pfx-panel h5{font:650 .97rem/1.5 var(--sans,sans-serif);margin:0}
.pfx svg{display:block;width:100%;height:auto}
.pfx svg text{font:12px var(--sans,sans-serif);fill:#2b4647}
.pfx svg .pfx-axis{font-size:10.5px;fill:#475d5d}
.pfx svg .pfx-effect{font-size:13px;font-weight:560}
.pfx svg .pfx-val{font-size:11px;paint-order:stroke;stroke:#fbfaf6;stroke-width:3px;stroke-linejoin:round;fill:currentColor}
.pfx svg .pfx-est{stroke:currentColor;fill:currentColor;stroke-width:1.6}
.pfx svg .pfx-first{color:#146570}.pfx svg .pfx-second{color:#954e2c}
.pfx svg .pfx-zero{stroke:#6f7d78;stroke-width:1.1;stroke-dasharray:3 3}
.pfx svg .pfx-interval{stroke:currentColor;fill:none;stroke-width:1.55}
.pfx svg .pfx-rowline{stroke:#e3e8e3;stroke-width:1}
.pfx .pfx-foot{border-top:1px solid #cad7cf;padding-top:.41rem;color:#43595a}
.pfx details{margin:.26rem 0}.pfx summary{font-size:.83rem}
.pfx dl{display:grid;grid-template-columns:minmax(8rem,auto) 1fr;gap:.22rem .8rem;font-size:.82rem;line-height:1.5;margin:.4rem 0}.pfx dd{margin:0;font-variant-numeric:tabular-nums}
@container(max-width:35rem){.pfx .pfx-grid{grid-template-columns:1fr}.pfx .pfx-panel svg{max-width:27rem}.pfx dl{display:block}.pfx dd{margin:0 0 .36rem}}
@media print{.pfx svg{print-color-adjust:exact}.pfx .pfx-panel{break-inside:avoid}}
</style>
"""


def signed(n):
    if abs(n) < .005:
        return "0.00"
    return f"{n:+.2f}".replace("-", "−")


def tick_range(contrasts):
    lowest = min(0, *(v["low"] for result in contrasts for v in result))
    highest = max(0, *(v["high"] for result in contrasts for v in result))
    rough = (highest - lowest) / 6
    unit = 10**floor(log10(rough)) if rough else 1
    step = next(a*unit for a in [1, 2, 5, 10] if a*unit >= rough)
    return step*floor(lowest/step), step*ceil(highest/step), step


def as_interval(interval):
    return f'{signed(interval["mean"])} [{signed(interval["low"])}, {signed(interval["high"])}]'


def panel(world, title, batches):
    results = [[b["worlds"][world]["contrasts"][k]["net"] for k, _ in EFFECTS]
               for b in batches]
    low, high, step = tick_range(results)
    x = lambda n: 10+(n-low)/(high-low)*295
    body = [f'<svg viewBox="0 0 341 208" role="img" aria-label="{escape(title)}的全程净回报差，均值与约95%配对区间。数值见图下展开表。">',
            '']
    exact = []
    for i, (_, label) in enumerate(EFFECTS):
        top = i*60+15
        body.append(f'<path class="pfx-zero" d="M{x(0):.2f} {top+6}v32"/>')
        body.append(f'<text class="pfx-effect" x="5" y="{top}">{label}</text>')
        if i: body.append(f'<path class="pfx-rowline" d="M5 {top-15}h320"/>')
        exact.append(f'<dt>{title} · {label}</dt><dd>{as_interval(results[0][i])} ｜ {as_interval(results[1][i])}</dd>')
        for batch,(cls,lb,mark) in enumerate([("first","第一批","circle"),("second","第二批","rect")]):
            a=results[batch][i]
            xx,left,right=x(a["mean"]),x(a["low"]),x(a["high"])
            y=top+15+14*batch
            body.append(f'<g class="pfx-{cls}"><title>{lb} {as_interval(a)}</title><path class="pfx-interval" d="M{left:.2f} {y-3}v6m0 -3 H{right:.2f}m0 -3v6"/>')
            if mark=="circle":
                body.append(f'<circle class="pfx-est" cx="{xx:.2f}" cy="{y}" r="2.9"/>')
            else:
                body.append(f'<rect class="pfx-est" style="fill:#fbfaf6" x="{xx-2.7:.2f}" y="{y-2.7}" width="5.4" height="5.4"/>')
            body.append(f'<text class="pfx-val" x="{right+4:.2f}" y="{y+4}" text-anchor="start">{signed(a["mean"])}</text></g>')
    body.append('<path stroke="#8fa49d" d="M10 179h295"/>')
    for k in range(round((high-low)/step)+1):
        value=low+k*step
        body.append(f'<path stroke="#8fa49d" d="M{x(value):.2f} 179v4"/><text class="pfx-axis" x="{x(value):.2f}" y="196" text-anchor="middle">{value:g}</text>')
    body.append('</svg>')
    return f'<div class="pfx-panel"><h5>{title}</h5>{"".join(body)}</div>',"".join(exact)


def figure(batches):
    names=("稳定环境","第 801 组起来源反转")
    assert all(b["config"]["step_size"]==.02 and b["max_labels"]==400 for b in batches)
    count=batches[0]["config"]["repetitions"]
    assert count==batches[1]["config"]["repetitions"]
    for b in batches:
        arms=b["arms"]
        assert all(arms[c]["trace_decay"]==v for c,v in (("basic_short",.8),("basic_long",.97)))
    panels=[panel(s,title,batches) for s,title in zip(("stable","reversal"),names)]
    return STYLE+f'''
<figure id="probe-factorial-figure" class="pfx" aria-labelledby="pfx-heading">
<h4 id="pfx-heading">检验进度与资格迹衰减对全程净回报的影响</h4>
<p>横轴为每条部署的净回报差（分）。加入进度指向策略提供该类来源距下一次检验的进展，延长资格迹将每窗衰减系数从 0.80 改为 0.97。两项主效应分别对另一因素的两个水平取平均。</p>
<div class="pfx-key"><b>● 第一批</b><b>□ 独立第二批</b><span>横线为配对约 95% 区间，竖虚线为零</span></div>
<div class="pfx-grid">{"".join(p[0] for p in panels)}</div>
<figcaption class="pfx-foot">两批各有 {count} 条独立模拟流，每批内四种规则使用相同的部署种子。交互效应是长迹下加入进度的收益减去短迹下加入进度的收益。两种环境分别标注横轴刻度。</figcaption>
<details><summary>查看均值和区间</summary><p>每行按第一批、第二批排列，单位为分。</p><dl>{"".join(p[1] for p in panels)}</dl></details>
</figure>
'''


if __name__=="__main__":
    root=Path(__file__).resolve().parent
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--primary",type=Path,default=root/"probe-factorial-results.json")
    parser.add_argument("--validation",type=Path,default=root/"probe-factorial-validation.json")
    parser.add_argument("--output",type=Path,default=root/"probe-factorial-figure.html")
    args=parser.parse_args()
    batches=[json.loads(path.read_text()) for path in (args.primary,args.validation)]
    args.output.write_text(figure(batches),encoding="utf-8")
