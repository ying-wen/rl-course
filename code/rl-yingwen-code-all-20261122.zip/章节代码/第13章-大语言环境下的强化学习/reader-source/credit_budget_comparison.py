"""Matched token and verification budgets for three ways to estimate prefix credit.

Run with Python 3 and NumPy: python3 credit_budget_comparison.py
All reported uncertainty is across independent training samples, paired by seed.
The environment and an exact evaluator are defined here so the exercise is repeatable.
"""
import argparse
import itertools
import json
from pathlib import Path

import numpy as np

LENGTH = 48
POSITIONS = np.array([8, 16, 24])  # zero-based decision indices
PROMPTS = 4
ROUTES = 2
STAGES = len(POSITIONS)
GROUP = 8
PILOT = 192
UPDATE = 384
SHARED_ROOT = UPDATE // 2
SELECTED = 2
TARGET_KL = 0.01
ROOT_P = np.array([.17, .20, .22, .16])
BASE = np.array([[.56, .39], [.51, .46], [.53, .41], [.48, .45]])
GAPS = {
    "aligned": np.array([[.18, .68], [.24, .60], [0., .48], [.20, .60]]),
    "shifted": np.array([[.34, .68], [-.32, -.62], [0., .50], [.30, -.58]]),
}
SHAPE = (PROMPTS, ROUTES, STAGES)
LABELS = {"grpo": "同提示 GRPO", "branch": "经验前缀分支", "critic": "前缀价值函数",
          "branch_random": "随机前缀分支"}
P0 = np.r_[ROOT_P, np.full(np.prod(SHAPE), .5)]
LOGITS = np.log(P0 / (1-P0))


class Counts:
    def __init__(self):
        self.tokens = 0
        self.verifications = 0

    def generate(self, generator, rows, length):
        self.tokens += rows * length
        return generator.random((rows, length))

    def verify(self, generator, probabilities):
        self.verifications += len(probabilities)
        return (generator.random(len(probabilities)) < probabilities).astype(float)


def terminal_probability(prompts, tokens, gap):
    routes = tokens[:, 0]
    final = tokens[:, POSITIONS[-1]]
    return BASE[prompts, routes] + gap[prompts, routes] * (final-.5)


def rollouts(generator, size, gap, counts):
    # Every quarter-batch has the same number of original prompts.
    prompts = np.arange(size) % PROMPTS
    uniforms = counts.generate(generator, size, LENGTH)
    tokens = (uniforms < .5).astype(int)
    tokens[:, 0] = uniforms[:, 0] < ROOT_P[prompts]
    rewards = counts.verify(generator, terminal_probability(prompts, tokens, gap))
    return prompts, tokens, rewards


def read_actions(data):
    prompts, tokens, rewards = data
    return prompts, tokens[:, 0], tokens[:, POSITIONS], rewards


def cell_estimates(data):
    prompts, routes, actions, rewards = read_actions(data)
    counts = np.zeros(SHAPE+(2,), int)
    successes = np.zeros_like(counts, dtype=float)
    for j in range(STAGES):
        ix = (prompts, routes, np.full(len(prompts), j), actions[:, j])
        np.add.at(counts, ix, 1)
        np.add.at(successes, ix, rewards)
    covered = np.all(counts > 0, axis=-1)
    means = successes / np.maximum(counts, 1)
    difference = np.where(covered, means[..., 1] - means[..., 0], 0.)
    return counts, successes, difference, covered


def choose_prefixes(pilot, rng):
    n, wins, _, covered = cell_estimates(pilot)
    q = (wins+1)/(n+2)
    se = np.sqrt(np.sum(q*(1-q)/(n+2), axis=-1))
    score = np.abs(q[..., 1]-q[..., 0]) - se
    available = np.flatnonzero(covered)
    # A separate random permutation breaks exact ties without privileging a stage.
    order = rng.permutation(available)
    selected = order[np.argsort(-score.flat[order], kind="stable")[:SELECTED]]
    random = rng.choice(available, size=SELECTED, replace=False)
    return [tuple(map(int, np.unravel_index(k, SHAPE))) for k in selected], [
        tuple(map(int, np.unravel_index(k, SHAPE))) for k in random]


def slice_data(data, index):
    return tuple(x[index] for x in data)


def root_difference(data):
    prompts, routes, _, rewards = read_actions(data)
    results = np.zeros(PROMPTS)
    for c in range(PROMPTS):
        cells = [rewards[(prompts == c) & (routes == r)] for r in range(ROUTES)]
        if all(len(values) for values in cells):
            results[c] = np.mean(cells[1]) - np.mean(cells[0])
    return results


def route_frequencies(data):
    prompts, routes, _, _ = read_actions(data)
    counts = np.zeros((PROMPTS, ROUTES), dtype=int)
    np.add.at(counts, (prompts, routes), 1)
    return counts


def from_estimated_gaps(root_gap, local_gap, counts):
    visits = counts / counts.sum(axis=1, keepdims=True) / PROMPTS
    # Bernoulli logit derivative times original-prompt occupancy.
    return np.r_[ROOT_P*(1-ROOT_P)*root_gap/PROMPTS,
                 (visits[:, :, None]*.25*local_gap).ravel()]


def grpo(data):
    prompts, routes, actions, rewards = read_actions(data)
    credit = np.zeros(len(prompts))
    for c in range(PROMPTS):
        mask = prompts == c
        groups = rewards[mask].reshape(-1, GROUP)
        credit[mask] = ((groups-groups.mean(axis=1, keepdims=True)) /
                        (groups.std(axis=1, ddof=1, keepdims=True)+1e-6)).ravel()
    root = np.zeros(PROMPTS)
    np.add.at(root, prompts, credit*(routes-ROOT_P[prompts]))
    local = np.zeros(SHAPE)
    for j in range(STAGES):
        np.add.at(local[:, :, j], (prompts, routes), credit*(actions[:, j]-.5))
    # All responses have fixed length. Its common token-normalizing factor is
    # absorbed by the matched step size. This is the first, on-policy GRPO step.
    return np.r_[root, local.ravel()]/len(prompts), *cell_estimates(data)[2:]


def critic(data):
    # Fit MC return labels at each post-token prefix, in two independent folds.
    # Intercepts distinguish prompt and route. At a given stage, slopes transfer
    # across prompts on the same route; they can use earlier sampled decisions.
    half = len(data[0]) // 2
    full_gap = np.zeros(SHAPE)
    gradient = np.zeros_like(P0)
    for fold in range(2):
        fit = slice_data(data, slice(fold*half, (fold+1)*half))
        evaluate = slice_data(data, slice((1-fold)*half, (2-fold)*half))
        prompts, routes, actions, rewards = read_actions(fit)
        intercepts = np.eye(PROMPTS*ROUTES)[prompts*ROUTES+routes]
        route_interactions = [np.eye(ROUTES)[routes]*(actions[:, j, None]-.5)
                              for j in range(STAGES)]
        local = np.zeros(SHAPE)
        for j in range(STAGES):
            features = np.column_stack([intercepts]+route_interactions[:j+1])
            # A fixed mild ridge penalizes slope coefficients, not intercepts.
            penalty = np.diag(np.r_[np.zeros(PROMPTS*ROUTES), np.ones(ROUTES*(j+1))])
            effects = np.linalg.lstsq(features.T@features+penalty,
                                      features.T@rewards, rcond=None)[0]
            local[:, :, j] = effects[-ROUTES:]
        root = root_difference(fit)
        gradient += .5*from_estimated_gaps(root, local, route_frequencies(evaluate))
        full_gap += .5*local
    return gradient, full_gap, cell_estimates(data)[3]


def branched(root_data, pilot, keys, rng, gap, counts):
    # Fresh root trajectories learn every unselected action and the routing step.
    _, _, local, covered = cell_estimates(root_data)
    root_only_local = local.copy()
    freq = route_frequencies(root_data)
    branch_trials = (UPDATE-SHARED_ROOT)//SELECTED
    saved = 0
    for c, r, j in keys:
        depth = POSITIONS[j]
        prompt, tokens, _ = pilot
        rows = tokens[(prompt == c) & (tokens[:, 0] == r)]
        assert len(rows)
        snapshots = rows[rng.integers(len(rows), size=branch_trials), :depth]
        suffix = (counts.generate(rng, branch_trials, LENGTH-depth) < .5).astype(int)
        completed = np.column_stack((snapshots, suffix))
        scores = counts.verify(rng, terminal_probability(np.full(branch_trials, c),
                                                         completed, gap))
        chosen = suffix[:, 0]
        sides = [scores[chosen == action] for action in (0,1)]
        covered[c, r, j] = all(len(side) for side in sides)
        local[c, r, j] = np.mean(sides[1])-np.mean(sides[0]) if covered[c,r,j] else 0.
        saved += branch_trials*depth
    # Each verified suffix saves depth sampled tokens. Spend them observing
    # first-token route choices at fresh, stratified prompts; route alone controls
    # the visitation weights of all candidate history classes in this task.
    prompts = np.arange(saved) % PROMPTS
    routes = (counts.generate(rng, saved, 1)[:, 0] < ROOT_P[prompts]).astype(int)
    np.add.at(freq, (prompts, routes), 1)
    gradient = from_estimated_gaps(root_difference(root_data), local, freq)
    masked_gradient = from_estimated_gaps(root_difference(root_data), root_only_local, freq)
    return gradient, local, covered, saved, masked_gradient, root_only_local


def route_distribution(probabilities):
    p = probabilities[:PROMPTS]
    return np.column_stack((1-p,p))/PROMPTS


def sigmoid(x):
    return 1/(1+np.exp(-np.clip(x,-35,35)))


def path_kl(probabilities):
    transitions = P0*np.log(P0/probabilities)+(1-P0)*np.log((1-P0)/(1-probabilities))
    return (np.mean(transitions[:PROMPTS])+
            np.sum(route_distribution(P0)[:, :, None]*transitions[PROMPTS:].reshape(SHAPE)))


def matched_update(gradient):
    norm = np.linalg.norm(gradient)
    if norm <= 1e-14:
        return P0.copy()
    direction = gradient/norm
    lo, hi = 0., 1.
    while path_kl(sigmoid(LOGITS+hi*direction)) < TARGET_KL:
        hi *= 2
    for _ in range(36):
        middle = (lo+hi)/2
        if path_kl(sigmoid(LOGITS+middle*direction)) < TARGET_KL:
            lo = middle
        else:
            hi = middle
    return sigmoid(LOGITS+(lo+hi)/2*direction)


def true_return(probabilities, gap):
    post = probabilities[PROMPTS:].reshape(SHAPE)
    return float(np.sum(route_distribution(probabilities)*(BASE+gap*(post[:, :, -1]-.5))))


def enumerated_return(probabilities, gap):
    """Independent complete decision-tree expectation (neutral words sum to one)."""
    total = 0.
    local = probabilities[PROMPTS:].reshape(SHAPE)
    for c,r in itertools.product(range(PROMPTS),range(ROUTES)):
        route_probability = probabilities[c] if r else 1-probabilities[c]
        for actions in itertools.product((0,1), repeat=STAGES):
            chance = np.prod([local[c,r,j] if a else 1-local[c,r,j]
                              for j,a in enumerate(actions)])
            total += route_probability*chance*(BASE[c,r]+gap[c,r]*(actions[-1]-.5))/PROMPTS
    return total


def evaluate_update(output, gap, chosen, executed, counts, saved):
    gradient, estimated, covered = output
    probabilities = matched_update(gradient)
    true = np.zeros(SHAPE)
    true[:, :, -1] = gap
    keys = tuple(np.array(chosen).T)
    adapted = tuple(np.array(executed).T)
    d_old = route_distribution(P0)[:, :, None]
    d_new = route_distribution(probabilities)[:, :, None]
    movement = probabilities[PROMPTS:].reshape(SHAPE)-.5
    effect = d_new*movement*true
    root_effect = (probabilities[:PROMPTS]-ROOT_P)*(BASE[:,1]-BASE[:,0])/PROMPTS
    gain = true_return(probabilities,gap)-true_return(P0,gap)
    if not np.isclose(root_effect.sum()+effect.sum(),gain,atol=1e-12):
        raise AssertionError("Performance-difference decomposition failed.")
    needed = PILOT + UPDATE
    assert (counts.tokens, counts.verifications) == (needed*LENGTH, needed)
    error = estimated-true
    metrics = {
        "selected_rmse": np.sqrt(np.mean(error[keys]**2)),
        "visit_rmse": np.sqrt(np.sum(d_old*error**2)/STAGES),
        "selected_bias": np.mean(error[keys]),
        "selected_coverage": np.mean(covered[keys]),
        "selected_sign": np.mean(np.sign(estimated[keys]) == np.sign(true[keys])),
        "gain": gain, "trajectory_kl": path_kl(probabilities),
        "root_contribution": root_effect.sum(), "selected_contribution": effect[keys].sum(),
        "other_contribution": effect.sum()-effect[keys].sum(),
        "visited_split_tokens":saved, "own_discovery_rate":np.mean(true[adapted]!=0),
        "negative_gain":float(gain<0),
    }
    return {"metrics":{k:float(v) for k,v in metrics.items()},
            "new_probabilities":probabilities.round(10).tolist(),
            "prefix_differences":estimated.ravel().round(8).tolist(),
            "covered":covered.ravel().astype(int).tolist()}


def training_seed(seed, gap):
    streams = np.random.SeedSequence(seed).spawn(5)
    pilot_counts, root_counts = Counts(), Counts()
    pilot = rollouts(np.random.default_rng(streams[0]), PILOT, gap, pilot_counts)
    chosen, random = choose_prefixes(pilot, np.random.default_rng(streams[1]))
    root = rollouts(np.random.default_rng(streams[2]), UPDATE, gap, root_counts)
    rows = {"seed":seed, "selected":chosen, "random_selected":random, "methods":{}}
    for name in LABELS:
        charged = Counts()
        charged.tokens, charged.verifications = pilot_counts.tokens, pilot_counts.verifications
        if name in ("grpo","critic"):
            charged.tokens += root_counts.tokens
            charged.verifications += root_counts.verifications
            output = grpo(root) if name=="grpo" else critic(root)
            used_keys,saved = chosen,0
        else:
            used_keys = random if name=="branch_random" else chosen
            charged.tokens += SHARED_ROOT*LENGTH
            charged.verifications += SHARED_ROOT
            result = branched(slice_data(root,slice(0,SHARED_ROOT)), pilot, used_keys,
                              np.random.default_rng(streams[3]), gap, charged)
            output,saved = result[:3], result[3]
            if name == "branch":
                masked_actor = matched_update(result[4])
                assert np.isclose(path_kl(masked_actor), TARGET_KL, atol=1e-9)
                truth = np.zeros(SHAPE)
                truth[:, :, -1] = gap
                ix = tuple(np.array(chosen).T)
                masked_error = result[5][ix]-truth[ix]
                rows["masked_branch"] = {
                    "selected_rmse": float(np.sqrt(np.mean(masked_error**2))),
                    "gain": true_return(masked_actor, gap)-true_return(P0, gap),
                    "trajectory_kl": path_kl(masked_actor),
                    "new_probabilities": masked_actor.round(10).tolist()}
        rows["methods"][name] = evaluate_update(output,gap,chosen,used_keys,charged,saved)
        probabilities=np.asarray(rows["methods"][name]["new_probabilities"])
        if seed==0:
            assert abs(enumerated_return(probabilities,gap)-true_return(probabilities,gap))<1e-13
    # These two actor-only controls spend the same 576 labels on training. Their
    # local error on the selected pilot conditions would have selection bias.
    all_data = tuple(np.concatenate([xp, xr], axis=0) for xp, xr in zip(pilot, root))
    rows["reused_pilot_gain"] = {}
    for name, algorithm in (("grpo", grpo), ("critic", critic)):
        new = matched_update(algorithm(all_data)[0])
        assert np.isclose(path_kl(new), TARGET_KL, atol=1e-9)
        rows["reused_pilot_gain"][name] = true_return(new, gap) - true_return(P0, gap)
    return rows


def intervals(values, resamples):
    vector = np.asarray(values)
    low,high = np.quantile(vector[resamples].mean(axis=1),[.025,.975])
    return {k:round(float(v),9) for k,v in zip(("mean","lo","hi"),(vector.mean(),low,high))}


def summarize(gap, seeds):
    rows=[training_seed(i,gap) for i in range(seeds)]
    resamples=np.random.default_rng(9001).integers(seeds,size=(3000,seeds))
    methods={}
    for name,label in LABELS.items():
        method_rows=[row["methods"][name] for row in rows]
        metrics={key:intervals([row["metrics"][key] for row in method_rows],resamples)
                 for key in method_rows[0]["metrics"]}
        methods[name]={"label":label,"metrics":metrics,
                       "cost":{"tokens":(PILOT+UPDATE)*LENGTH,"verifications":PILOT+UPDATE}}
    paired={}
    for a,b in itertools.combinations(LABELS,2):
        paired[a+"-"+b]={key:intervals([row["methods"][a]["metrics"][key]-
                                        row["methods"][b]["metrics"][key] for row in rows],
                                       resamples) for key in ("gain","selected_rmse","visit_rmse")}
    reused = {}
    for name in ("grpo", "critic"):
        full = [row["reused_pilot_gain"][name] for row in rows]
        paired_difference = [row["reused_pilot_gain"][name]-row["methods"][name]["metrics"]["gain"]
                             for row in rows]
        reused[name] = {"gain": intervals(full,resamples),
                        "difference_from_reserved": intervals(paired_difference,resamples)}
    masked = {}
    for key in ("selected_rmse", "gain"):
        masked_values = [row["masked_branch"][key] for row in rows]
        added = [row["methods"]["branch"]["metrics"][key]-row["masked_branch"][key]
                 for row in rows]
        masked[key] = {"masked": intervals(masked_values,resamples),
                       "branch_minus_masked": intervals(added,resamples)}
    # Across repetitions, decompose the pooled selected-prefix MSE conditional
    # on WHICH prefix was selected; this has different units than mean per-seed RMSE.
    for name in LABELS:
        errors = {}
        for row in rows:
            estimate = np.array(row["methods"][name]["prefix_differences"]).reshape(SHAPE)
            for c,r,j in row["selected"]:
                target = gap[c,r] if j == STAGES-1 else 0.
                errors.setdefault((c,r,j), []).append(estimate[c,r,j]-target)
        total = seeds*SELECTED
        squared_bias = sum(len(v)*np.mean(v)**2 for v in errors.values())/total
        variance = sum(len(v)*np.var(v) for v in errors.values())/total
        mse = sum(np.sum(np.square(v)) for v in errors.values())/total
        assert abs(mse-squared_bias-variance)<1e-12
        methods[name]["selected_pooled_mse"] = {"mse":mse,
                         "squared_bias_conditioned_on_prefix":squared_bias,
                         "variance_conditioned_on_prefix":variance}
    return {"methods":methods,"paired":paired,"reused_pilot":reused,
            "mask_branch_feedback":masked,"gap_at_last":gap.tolist(),
            "old_return":true_return(P0,gap),"seeds_detail":rows}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seeds",type=int,default=192)
    parser.add_argument("--output",type=Path,default=Path(__file__).with_name("credit-budget-results.json"))
    args=parser.parse_args()
    assert args.seeds>=2
    doc={"protocol":{"length":LENGTH,"pilot_verifications":PILOT,"update_verifications":UPDATE,
         "total_generated_tokens":(PILOT+UPDATE)*LENGTH,"total_verifications":PILOT+UPDATE,
         "seeds":args.seeds,"group_size":GROUP,"target_kl":TARGET_KL,
         "positions":(POSITIONS+1).tolist(),"candidates":int(np.prod(SHAPE)),"selected":SELECTED,
         "base":BASE.tolist(),"old_route1":ROOT_P.tolist(),"old_local_action1":.5,
         "shared_root":SHARED_ROOT,"paired_bootstrap":3000,
         "pilot_role":"Common independent candidate selection, withheld from all primary actor fits. Separate GRPO/critic sensitivity also trains on pilot labels and evaluates only complete return.",
         "candidate_rule":"Rank observed two-sided candidates by absolute Beta(1,1) posterior mean difference minus sqrt(sum(q*(1-q)/(n+2))). This is a selection heuristic, not a simultaneous confidence bound.",
         "branch_accounting":"One half of fresh labels at root, the remaining half at selected snapshots. Saved prefix generations buy independent single-token prompt-stratified route observations to estimate occupancies. The policy route probabilities are also analytically available in this toy task.",
         "gradient_estimand":"One matched-KL local step in 28 independent Bernoulli logits, old policy fixed. Third-stage probabilities affect return, earlier stages may affect step norm.",
         "uncertainty":"Paired bootstrap training seeds with fixed environment. Analytic full-policy evaluation uses no training data."},"scenarios":{}}
    for scenario,gap in GAPS.items():
        result=summarize(gap,args.seeds)
        result["label"]="跨提示作用同向" if scenario=="aligned" else "跨提示作用异向"
        doc["scenarios"][scenario]=result
        for method,val in result["methods"].items():
            mean=lambda k:round(val["metrics"][k]["mean"],5)
            print(scenario,method,mean("selected_rmse"),mean("gain"),mean("own_discovery_rate"),
                  mean("trajectory_kl"),flush=True)
    args.output.write_text(json.dumps(doc,ensure_ascii=False,separators=(",",":"))+"\n")

if __name__=="__main__":
    main()
