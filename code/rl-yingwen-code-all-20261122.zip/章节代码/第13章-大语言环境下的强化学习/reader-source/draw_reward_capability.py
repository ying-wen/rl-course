"""Generate the threshold-decision figure for Chapter 13 using exact expectations.

Run python3 draw_reward_capability.py to regenerate reward-capability-figure.html.
Run python3 draw_reward_capability.py --check for the independent numerical checks.
"""
import argparse
from fractions import Fraction as F
from math import isclose
from pathlib import Path
from random import Random

HERE = Path(__file__).resolve().parent
P, ESTIMATE, TEST_THRESHOLD = F(7, 10), F(2, 5), F(11, 20)
TRAIN_LOWER, TRAIN_UPPER = F(4, 5), F(1)
ACCURACY, COST = F(4, 5), F(3, 100)


def choose(estimate, threshold):
    return "操作" if estimate >= threshold else "基线"


def expected_reward(p, estimate, threshold):
    return p if choose(estimate, threshold) == "操作" else threshold


def mean_regret(p, estimate, lower=F(0), upper=F(1)):
    """Analytic integral of |p-b| on the thresholds with differing actions."""
    if lower >= upper:
        raise ValueError("The threshold distribution must have positive width.")
    lo, hi = max(lower, min(p, estimate)), min(upper, max(p, estimate))
    if lo >= hi:
        return F(0)
    return (hi-lo) * (abs(p-lo)+abs(p-hi)) / (2*(upper-lower))


def enumerate_reward(p, estimate, threshold):
    """Enumerate the two potential Bernoulli outcomes under an independent baseline."""
    total = 0
    for x in (0, 1):
        for y in (0, 1):
            joint = (p if x else 1-p) * (threshold if y else 1-threshold)
            reward = x if choose(estimate, threshold) == "操作" else y
            total += joint*reward
    return total


def optional_check(p, threshold, accuracy):
    """Before acting, an external test detects the one latent binary outcome."""
    mass, hit = [F(0), F(0)], [F(0), F(0)]
    for outcome in (0, 1):
        for signal in (0, 1):
            base = p if outcome else 1-p
            joint = base * (accuracy if signal == outcome else 1-accuracy)
            mass[signal] += joint
            hit[signal] += joint*outcome
    post = [hit[d]/mass[d] for d in (0, 1)]
    with_test = sum(mass[d]*max(post[d], threshold) for d in (0, 1))
    return mass, post, with_test


def check_math():
    # The pointwise decision uses observed terminal outcomes. Integrate the
    # exact regret of that decision independently of mean_regret().
    rng = Random(19)
    for _ in range(160):
        p, estimate = rng.random(), rng.random()
        lo, hi = sorted((rng.random(), rng.random()))
        knots = sorted({lo, hi, *(x for x in (p, estimate) if lo < x < hi)})
        integral = 0.0
        for left, right in zip(knots, knots[1:]):
            b = (left+right)/2
            delta = enumerate_reward(p, p, b)-enumerate_reward(p, estimate, b)
            integral += (right-left)*delta/(hi-lo)
        assert isclose(integral, mean_regret(p, estimate, lo, hi), abs_tol=2e-14)
        assert isclose(mean_regret(p, estimate), (p-estimate)**2/2, abs_tol=2e-14)
    assert mean_regret(P, ESTIMATE) == F(45,1000)
    assert mean_regret(P, ESTIMATE, TRAIN_LOWER, TRAIN_UPPER) == 0
    assert max(P,TEST_THRESHOLD)-enumerate_reward(P, ESTIMATE, TEST_THRESHOLD) == F(15,100)
    mass, post, verified = optional_check(P, TEST_THRESHOLD, ACCURACY)
    assert post == [F(7,19), F(28,31)]
    assert mass == [F(38,100), F(62,100)]
    assert verified == F(769,1000)
    assert verified-max(P, TEST_THRESHOLD)-COST == F(39,1000)


def fmt(x, digits=2):
    return f"{float(x):.{digits}f}"


def payoff_plot(p, estimate, test):
    """Two action-value curves and the integral of lost success probability."""
    left, right, floor, top = 40, 300, 174, 23
    def x(b):
        return float(left + b*(right-left))
    def y(b):
        return float(floor - b*(floor-top))
    a, crossing, mid = x(estimate), x(p), x(test)
    yp, ya, ym = y(p), y(estimate), y(test)
    ticks = []
    for b in [F(0), estimate, p, F(1)]:
        p2 = x(b)
        label = str(int(b)) if b in (0,1) else str(float(b))
        ticks.append(f'<path d="M{p2:.1f} {floor}v4"/><text x="{p2:.1f}" y="192" text-anchor="middle">{label}</text>')
    return f'''<svg class="rc13-plot" viewBox="0 0 320 215" role="img" aria-labelledby="rc13-plot-title rc13-plot-desc">
<title id="rc13-plot-title">两种行动的期望终局奖励</title>
<desc id="rc13-plot-desc">操作成功率固定为 {fmt(p)}。基线成功率随阈值由零升至一。在估计值 {fmt(estimate)} 至真实值 {fmt(p)} 之间，策略误选基线。阴影高度是该任务的成功率损失，面积是均匀任务分布的平均损失。</desc>
<defs><pattern id="rc13-hatch" width="5" height="5" patternUnits="userSpaceOnUse"><path d="M-1 1l2 -2m-1 6l5 -5m-1 6l2 -2" stroke="#ae6a46" stroke-width=".8"/></pattern></defs>
<text x="4" y="13">期望奖励</text>
<g class="rc13-axis"><path d="M{left} {top}V{floor}H{right}"/></g>
<text x="32" y="{top+4}" text-anchor="end">1</text>
<text x="32" y="{yp+4:.1f}" text-anchor="end">{float(p)}</text>
<text x="32" y="{floor+4}" text-anchor="end">0</text>
<path d="M{a:.1f},{yp:.1f} H{crossing:.1f} L{a:.1f},{ya:.1f} Z" fill="#f7e4d5"/>
<path d="M{a:.1f},{yp:.1f} H{crossing:.1f} L{a:.1f},{ya:.1f} Z" fill="url(#rc13-hatch)"/>
<path class="rc13-aux" d="M{a:.1f} {yp:.1f}V{floor} M{crossing:.1f} {yp:.1f}V{floor}"/>
<path d="M{left} {floor}L{right} {top}" stroke="#4978a2" stroke-width="2.5" fill="none"/>
<path d="M{left} {yp:.1f}H{right}" stroke="#17736b" stroke-width="2.8"/>
<text class="rc13-operation" x="46" y="{yp-7:.1f}">操作</text>
<text class="rc13-baseline" x="267" y="21">基线</text>
<path d="M{mid:.1f} {yp:.1f}V{ym:.1f}" stroke="#8c4527" stroke-width="2.5"/>
<circle cx="{mid:.1f}" cy="{yp:.1f}" r="2.6" fill="#8c4527"/>
<circle cx="{mid:.1f}" cy="{ym:.1f}" r="2.6" fill="#8c4527"/>
<path d="M{mid:.1f} {(yp+ym)/2:.1f}l20 22h20" fill="none" stroke="#8c4527"/>
<text class="rc13-note" x="{mid+15:.1f}" y="{(yp+ym)/2+38:.1f}">相差 {fmt(p-test)} </text>
<g class="rc13-ticks">{''.join(ticks)}</g>
<text x="300" y="211" text-anchor="end">备选方案成功率 b</text>
</svg>'''


def threshold_strip():
    return '''<svg class="rc13-coverage" viewBox="0 0 320 81" role="img" aria-label="训练阈值覆盖零点八至一。测试阈值为零点五五，落在不同预测导致不同动作的区间内。">
<path d="M16 10h19" stroke="#a45f3e" stroke-width="2" stroke-dasharray="3 3"/><text x="42" y="14">选择不同</text><path d="M174 10h23" stroke="#4978a2" stroke-width="5"/><text x="204" y="14">训练阈值</text>
<path d="M16 32H304" stroke="#beccce" stroke-width="2"/>
<path d="M246.4 32H304" stroke="#4978a2" stroke-width="8"/>
<path d="M131.2 32H217.6" stroke="#a45f3e" stroke-width="3" stroke-dasharray="3 3"/>
<circle cx="174.4" cy="32" r="5" fill="#974d2b" stroke="#fff" stroke-width="1.2"/>
<text x="16" y="56" text-anchor="middle">0</text><text x="174.4" y="56" text-anchor="middle">0.55</text><text x="246.4" y="56" text-anchor="middle">0.8</text><text x="304" y="56" text-anchor="middle">1</text>
<text class="rc13-note" x="174.4" y="74" text-anchor="middle">留出任务</text></svg>'''


STYLE = """<style>
.rc13{container-type:inline-size;border-block:2px solid #5c7c76;padding:.9rem 0;color:#213c3c}
.rc13 h4,.rc13 h5,.rc13 p,.rc13 figcaption{margin:0;padding:0}
.rc13 h4{font:650 1.15rem/1.4 var(--serif,serif);color:#193d3d}
.rc13 h5{font:650 .94rem/1.5 var(--sans,sans-serif);color:#254647}
.rc13 p,.rc13 figcaption,.rc13 summary{font:.88rem/1.65 var(--sans,sans-serif)}
.rc13 .rc13-definition{margin:.4rem 0 .65rem}
.rc13 .rc13-main{display:grid;grid-template-columns:minmax(0,1.1fr) minmax(0,.9fr);align-items:start;gap:1.25rem}
.rc13 .rc13-side{padding-left:1rem;border-left:1px solid #c7d2cf}
.rc13 .rc13-side p+p,.rc13 .rc13-side svg+p{margin-top:.4rem}
.rc13 .rc13-plot,.rc13 .rc13-coverage{display:block;width:100%;height:auto;margin:.2rem 0}
.rc13 svg text{font:13px var(--sans,sans-serif);fill:#293e43;stroke:none}
.rc13 .rc13-axis path,.rc13 .rc13-ticks path{fill:none;stroke:#748783;stroke-width:1.1}
.rc13 .rc13-aux{stroke:#97a5a4;stroke-width:1;stroke-dasharray:3 3}
.rc13 svg text.rc13-operation{fill:#126159;font-weight:650}
.rc13 svg text.rc13-baseline{fill:#355f86;font-weight:650}
.rc13 svg text.rc13-note{fill:#894427}
.rc13 .rc13-result{font-weight:620;color:#754528}
.rc13 figcaption{margin:.7rem 0 .35rem;padding-top:.55rem;border-top:1px solid #c7d2cf}
.rc13 details{margin-top:.35rem}.rc13 details p{margin:.5rem 0}
@container(max-width:580px){.rc13 .rc13-main{grid-template-columns:minmax(0,1fr);gap:.6rem}
.rc13 .rc13-side{border-left:0;border-top:1px solid #c7d2cf;padding:.5rem 0 0}
.rc13 .rc13-plot{max-width:360px}.rc13 .rc13-coverage{max-width:330px}}
</style>"""


def render():
    p, s, b = P, ESTIMATE, TEST_THRESHOLD
    mass, post, with_test = optional_check(p, b, ACCURACY)
    gross = with_test - max(p,b)
    return STYLE+f'''
<figure id="reward-threshold-figure" class="rc13" aria-labelledby="rc13-title" aria-describedby="rc13-caption">
<h4 id="rc13-title">终局奖励与后果预测</h4>
<p class="rc13-definition">同一可见条件下，<b>p = {fmt(p)}</b> 是执行当前方案的真实成功率，<b>s = {fmt(s)}</b> 是智能体对它的预测。每项任务另有一个备选方案（基线），其成功率 <b>b</b> 事先公布。选定行动后才观测成败，成功得 1，失败得 0。在 s ≥ b 时，智能体执行当前方案。</p>
<div class="rc13-main"><section aria-label="均匀阈值">
<h5>训练任务覆盖全部阈值</h5>
{payoff_plot(p,s,b)}
<p>在 ({fmt(s)}, {fmt(p)}) 内，操作有更高的成功率，策略却选择基线。竖线表示 b = {fmt(b)} 时误选基线损失的期望奖励。阈值均匀分布时，<span class="rc13-result">阴影面积 {fmt(mean_regret(p,s),3)}</span> 就是平均决策损失。</p>
</section><section class="rc13-side" aria-label="受限的训练任务">
<h5>训练任务只覆盖高阈值</h5>
{threshold_strip()}
<p>在训练区间 [{fmt(TRAIN_LOWER)}, 1]，s = {fmt(s)} 与 s = {fmt(p)} 都选基线。两者在训练中的成败分布相同。</p>
<p>在留出的 b = {fmt(b)} 上，前者仍选基线，后者执行操作。期望奖励分别为 <strong>{fmt(b)}</strong> 与 <strong>{fmt(p)}</strong>。</p>
</section></div>
<figcaption id="rc13-caption">当同一预测值用于各种阈值任务，预测偏差会在一整段阈值上改变动作。均匀取样时，平均损失恰等于 ½(p − s)²。数值由这个二行动模型精确计算。按阈值选择能检验预测的决策用途，内部计算过程仍须另外测量。</figcaption>
<details><summary>外部检验怎样改变同一任务的动作价值</summary>
<p>在 b = {fmt(b)} 的决策前，可以取得一次有成本的外部检验。设检验针对本次操作的潜在成败，灵敏度和特异度均为 {fmt(ACCURACY)}，基线结果独立。检验阳性概率 {fmt(mass[1])}，操作成功的后验概率 {fmt(post[1],3)}；检验阴性概率 {fmt(mass[0])}，后验概率 {fmt(post[0],3)}。阳性时应执行操作，阴性时应选基线。</p>
<p>按两种回执的概率求平均，检验后的成功率为 {fmt(with_test,3)}，直接执行操作的成功率为 {fmt(p)}。能据回执择优的智能体最多值得付出 {fmt(gross,3)} 的检验成本。若成本为 {fmt(COST)}，净增益是 {fmt(gross-COST,3)}。这里的似然来自规定的外部检验。由同一输入生成的自评文字，须另行测量它与真实后果的关系。</p>
</details></figure>
'''


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--check", action="store_true")
    args = parser.parse_args()
    check_math()
    if args.check:
        print("160 independent enumerations and analytic boundary cases passed.")
    else:
        (HERE/"reward-capability-figure.html").write_text(render(), encoding="utf-8")
