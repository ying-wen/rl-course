"""从二元来源模型的条件概率重绘反馈价值曲线。"""
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

p = np.linspace(.5, 1., 201)
accuracy, cost = .80, .30
plt.rcParams.update({'font.family': 'Arial Unicode MS', 'font.size': 12,
                     'axes.unicode_minus': False, 'svg.hashsalt': 'probe-value'})
fig, ax = plt.subplots(figsize=(6.25, 3.35), layout='constrained')
ax.axhspan(-.39, 0, color='#f3eeea')
ax.axhline(0, linewidth=1, color='#667671')
ax.axvline(accuracy, ls=':', lw=1, color='#768982')
for count, color, ls in [(8, '#165e76', '-'), (4, '#34876b', '--'), (1, '#96532c', '-.')]:
    gain = count * np.maximum(accuracy - p, 0) - cost
    # 核对条件期望：分别取两个可能回复下最优动作的联合正确概率。
    informed = (np.maximum(p*accuracy,(1-p)*(1-accuracy)) +
                np.maximum(p*(1-accuracy),(1-p)*accuracy))
    np.testing.assert_allclose(gain, count * (informed-p) - cost, atol=1e-14)
    ax.plot(p, gain, color=color, lw=2.4, ls=ls, label=f'{count} 次')
ax.plot([.60], [.50], marker='o', color='#34876b')
ax.annotate('4 次：+0.50', (.60, .50), xytext=(.642, .82),
            arrowprops={'arrowstyle': '-', 'color': '#34876b'}, fontsize=10)
ax.text(.81,.14,'一份反馈不能改变选择',color='#59635e',fontsize=9.5)
ax.set_xlim(.50,1.)
ax.set_ylim(-.4,2.2)
ax.set_xticks([.5,.6,.7,.8,.9,1.])
ax.set_yticks([-.3,0,.5,1,1.5,2])
ax.set_xlabel('现有证据下，旧来源较优的概率 p')
ax.set_ylabel('购买反馈的净收益（分）')
ax.spines[['top','right']].set_visible(False)
ax.grid(axis='y', alpha=.12)
ax.legend(title='收到反馈后的决策次数', loc='upper right', ncol=3,
          fontsize=9, title_fontsize=10, frameon=False, columnspacing=.8)
fig.savefig(Path(__file__).with_name('probe-value-boundary.svg'), metadata={'Date':None})
