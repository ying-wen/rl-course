"""Exact policy landscapes for the chapter's two-decision task.

Run python3 trpo_landscape.py with NumPy and Matplotlib. The same policy,
discounted objective, KL normalization and trial steps are used in
compare_steps.py. Each coordinate is a logit displacement from the old policy.
"""
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import colors
import numpy as np
from numpy.testing import assert_allclose

# 11-21 请求 r1121-114237：图内字体改用课件字体（Latin Modern Sans + FandolHei），刻度去前导 0。
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "demos"))
from matplotlib.ticker import FuncFormatter
from plot_fonts import use_course_fonts, no_leading_zero

from compare_steps import (GAMMA, OLD, OLD_LOGITS, TRUST_BUDGET,
                           diagnostics, local_direction, sigmoids, value)

HERE = Path(__file__).resolve().parent
INK, TEAL, RED, GOLD = "#263d46", "#08757c", "#ad4a34", "#ad7928"
CMAP = colors.LinearSegmentedColormap.from_list("gain", ["#e6c495", "#f6f5e7", "#88beb1", "#227c7e"])
DIRECTION = local_direction()
PROBE = np.log(np.array([.9, .1]) / np.array([.1, .9])) - OLD_LOGITS
GRADIENT = np.array([.0875, .16875])
FISHER_DIAG = (1-GAMMA) * np.array([OLD[0]*(1-OLD[0]),
                                     GAMMA*OLD[0]*OLD[1]*(1-OLD[1])])


def surfaces(x, y):
    p, q = sigmoids(OLD_LOGITS[0]+x), sigmoids(OLD_LOGITS[1]+y)
    actual = 1 - p + GAMMA * p * (1 + 2*q) - value(OLD)
    # Use the OLD reach probability when scoring subsequent decisions.
    surrogate = (p-OLD[0])*(GAMMA*(1+2*OLD[1])-1) + 2*GAMMA*OLD[0]*(q-OLD[1])
    def kl(old, new):
        return old*np.log(old/new)+(1-old)*np.log((1-old)/(1-new))
    mean_kl = (1-GAMMA)*(kl(OLD[0],p) + GAMMA*OLD[0]*kl(OLD[1],q))
    return actual, surrogate, mean_kl


def verify():
    for displacement in (np.zeros(2), DIRECTION, DIRECTION/2, PROBE):
        gain, surrogate, kl = surfaces(*displacement)
        original = diagnostics(OLD_LOGITS+displacement)
        assert_allclose([kl, gain, surrogate], original[:3], atol=2e-12)
    assert_allclose(surfaces(*PROBE)[:2], [-.103,.005])
    for projection in (0, 1):
        gradient = [(surfaces(*(e*1e-5))[projection]-surfaces(*(-e*1e-5))[projection])/2e-5 for e in np.eye(2)]
        assert_allclose(gradient, GRADIENT, atol=1e-10)
    assert_allclose(.5*np.dot(FISHER_DIAG, DIRECTION**2), TRUST_BUDGET)
    full_kl, half_kl = surfaces(*DIRECTION)[2], surfaces(*(DIRECTION/2))[2]
    assert half_kl < TRUST_BUDGET < full_kl
    print(f"old J={value(OLD):.3f}; gradient={GRADIENT}; step={DIRECTION}")
    print(f"full KL={full_kl:.7f}; half KL={half_kl:.7f}; budget={TRUST_BUDGET:g}")


def label_point(ax, xy, text, dx, dy, color=INK, marker="o"):
    ax.scatter(*xy,s=29,zorder=10,marker=marker,c=color,edgecolors="white",linewidths=.7)
    ax.annotate(text,xy,xytext=(dx,dy),textcoords="offset points",fontsize=10,weight="semibold",
                color=color,ha="left" if dx>=0 else "right",va="center",
                bbox=dict(facecolor="white",edgecolor="none",pad=.8,alpha=.90))


def draw_hill():
    axis = np.linspace(-2.6,2.6,85)
    x,y = np.meshgrid(axis,axis); z=surfaces(x,y)[0]+value(OLD)
    fig=plt.figure(figsize=(5.35,3.44));ax=fig.add_subplot(projection="3d")
    ax.view_init(elev=32,azim=-56)
    ax.computed_zorder = False
    ax.set_box_aspect((1.2,1,.63),zoom=1.0)
    ax.plot_surface(x,y,z,cmap=CMAP,alpha=.89,linewidth=0,antialiased=False,rasterized=True,rstride=2,cstride=2,zorder=2)
    ax.plot_wireframe(x,y,z+.005,rstride=9,cstride=9,color="#486f6b",linewidth=.44,alpha=.46,zorder=3)
    levels=[1.,1.175,1.4,1.8,2.15]
    ax.contour(x,y,z,levels=levels,colors=INK,linewidths=.88,alpha=.83,zorder=4)
    ax.contour(x,y,z,levels=levels,zdir="z",offset=.64,colors="#639391",linewidths=.9,zorder=1)
    # The old position is deliberately raised by a hair for z-buffer visibility.
    ax.plot([0],[0],[value(OLD)+.015],marker="o",ms=7,mec="white",mfc=RED,zorder=10)
    ax.plot([0,0],[0,0],[value(OLD)+.03,1.89],c=RED,lw=1.2,zorder=11)
    ax.text(0,0,1.96,r"$\pi_o$",color=RED,size=14,weight="bold",zorder=11)
    ax.set(xlabel=r"$u_0$",ylabel=r"$u_1$",zlabel=r"$J(\pi)$",xlim=(-2.6,2.6),ylim=(-2.6,2.6),zlim=(.64,2.55),
           xticks=[-2,0,2],yticks=[-2,0,2],zticks=[1,1.5,2])
    for pane in (ax.xaxis,ax.yaxis,ax.zaxis):
        pane.set_pane_color((.97,.98,.97,.75))
        pane._axinfo["grid"]["color"]=(.76,.81,.80,.43)
        pane.labelpad=-2
    ax.zaxis.set_major_formatter(FuncFormatter(no_leading_zero))
    ax.tick_params(pad=-2,labelsize=9)
    fig.subplots_adjust(left=-.03,right=1.01,bottom=.04,top=1.04)
    fig.savefig(HERE/"trpo-hill.pdf",pad_inches=.02,dpi=190,bbox_inches="tight")
    plt.close(fig)


def draw_section():
    fig,ax=plt.subplots(figsize=(5.1,2.62))
    t=np.linspace(0,1,180);gain,surrogate,_=surfaces(t*PROBE[0],t*PROBE[1])
    ax.axhline(0,c=INK,lw=.7,alpha=.75)
    ax.plot(t,gain,c=RED,lw=2.5)
    ax.plot(t,surrogate,c=TEAL,lw=2.5)
    ax.plot(t,t*(GRADIENT@PROBE),c=INK,lw=1.55,ls=(0,(3,3)))
    ax.annotate(r"$L_o$",xy=(.70,np.interp(.7,t,surrogate)),xytext=(.62,.044),color=TEAL,
                arrowprops=dict(arrowstyle="-",color=TEAL,lw=.85),fontsize=14)
    ax.annotate(r"$g^\top u$",xy=(.41,.41*(GRADIENT@PROBE)),xytext=(.06,.032),color=INK,
                arrowprops=dict(arrowstyle="-",color=INK,lw=.85),fontsize=10)
    ax.text(.60,-.082,r"$\Delta J$",color=RED,fontsize=14)
    ax.scatter(0,0,c=INK,s=30,zorder=5)
    ax.scatter(1,gain[-1],c=RED,s=26);ax.scatter(1,surrogate[-1],c=TEAL,s=26)
    ax.set(xlim=(-.03,1.05),ylim=(-.12,.057),xticks=[0,.5,1],yticks=[-.1,-.05,0,.05],
           xlabel=r"$t$    $\pi(t):\; u=t\,u_{\rm B}$",ylabel=r"$\Delta J,\; L_o$")
    ax.xaxis.set_major_formatter(FuncFormatter(no_leading_zero)); ax.yaxis.set_major_formatter(FuncFormatter(no_leading_zero))
    ax.spines[["top","right"]].set_visible(False); ax.grid(axis='y',alpha=.15)
    fig.tight_layout(pad=.25);fig.savefig(HERE/"trpo-section.pdf",bbox_inches="tight",pad_inches=.025);plt.close(fig)


def draw_trust():
    x,y=np.meshgrid(np.linspace(-1.27,1.53,301),np.linspace(-1.95,2.13,301))
    actual,_,kl=surfaces(x,y)
    quadratic=.5*(FISHER_DIAG[0]*x*x+FISHER_DIAG[1]*y*y)
    fig,ax=plt.subplots(figsize=(4.7,3.29))
    cset=ax.contour(x,y,actual+value(OLD),levels=[1.03,1.10,1.175,1.3,1.5,1.75],colors="#9ea9a6",linewidths=.72)
    ax.clabel(cset,fmt="%1.2f",fontsize=7,inline_spacing=2)
    ax.contourf(x,y,kl,levels=[-1e-8,TRUST_BUDGET],colors=["#c7e5de"],alpha=.46)
    ax.contour(x,y,kl,levels=[TRUST_BUDGET],colors=[TEAL],linewidths=1.85)
    ax.contour(x,y,quadratic,levels=[TRUST_BUDGET],colors=[GOLD],linestyles="--",linewidths=1.9)
    # Label the tangent plane's supporting contour at the full predicted step.
    ax.contour(x,y,x*GRADIENT[0]+y*GRADIENT[1],levels=[GRADIENT@DIRECTION],colors=[INK],linestyles=":",linewidths=1.35)
    ax.annotate("",DIRECTION,(0,0),arrowprops=dict(arrowstyle="-|>",lw=1.65,color=INK,shrinkA=0,shrinkB=0))
    label_point(ax,(0,0),"O",-6,-7)
    label_point(ax,DIRECTION,"B",7,4,RED,"X")
    label_point(ax,DIRECTION/2,"H",-8,0,TEAL)
    ax.plot([],[],c=TEAL,lw=1.8,label=r"$\bar D=\delta_{\rm KL}$")
    ax.plot([],[],c=GOLD,lw=1.8,ls="--",label=r"$u^\top Fu/2=\delta_{\rm KL}$")
    ax.set(xlim=(-1.22,1.49),ylim=(-1.93,2.1),xlabel=r"$u_0$",ylabel=r"$u_1$",xticks=[-1,0,1],yticks=[-1,0,1,2],aspect="auto")
    ax.legend(loc="upper center",bbox_to_anchor=(.5,1.19),ncols=2,frameon=False,fontsize=10,handlelength=1.65)
    ax.spines[["top","right"]].set_visible(False)
    fig.tight_layout(pad=.22);fig.savefig(HERE/"trpo-trust.pdf",bbox_inches="tight",pad_inches=.035);plt.close(fig)


if __name__=="__main__":
    use_course_fonts()
    plt.rcParams.update({"font.size":11,"text.color":INK,"axes.labelcolor":INK,
                         "xtick.color":INK,"ytick.color":INK,"pdf.fonttype":42})
    verify()
    draw_hill();draw_section();draw_trust()
