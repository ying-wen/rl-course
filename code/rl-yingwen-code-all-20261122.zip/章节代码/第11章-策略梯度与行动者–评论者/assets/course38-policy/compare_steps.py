"""Two-step decision tree. Print exact policy and surrogate changes; draw the lecture figure.

Run: python compare_steps.py       dependencies: NumPy, Matplotlib
The root either stops for reward 1 or continues for reward 0. At the second
state the actions pay 1 or 3 and terminate. All quantities are expectations.
"""
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager

GAMMA = .9
OLD = np.array([.5, .25])   # P(continue | root), P(take 3 | next)
OLD_LOGITS = np.log(OLD / (1 - OLD))
TRUST_BUDGET = .01
CLIP = .2


def sigmoids(logits):
    return 1 / (1 + np.exp(-logits))


def value(probabilities):
    p, q = probabilities
    path_mass = np.array([1 - p, p * (1 - q), p * q])
    path_returns = np.array([1., GAMMA, 3 * GAMMA])
    return path_mass @ path_returns


def advantage_terms():
    p, q = OLD
    v1 = 1 + 2 * q
    v0 = value(OLD)
    # Weights count live decisions per episode with outer gamma^t.
    weights = np.array([p, 1-p, GAMMA*p*q, GAMMA*p*(1-q)])
    advantages = np.array([GAMMA*v1-v0, 1-v0, 3-v1, 1-v1])
    return weights, advantages


def diagnostics(logits):
    p, q = sigmoids(logits)
    p0, q0 = OLD
    ratios = np.array([p/p0, (1-p)/(1-p0), q/q0, (1-q)/(1-q0)])
    weights, advantages = advantage_terms()
    gains = ratios * advantages
    clipped = np.minimum(gains, np.clip(ratios, 1-CLIP, 1+CLIP) * advantages)
    # Zero-reward absorbing tail completes the normalized occupancy; its KL is 0.
    mean_kl = -(1-GAMMA) * (weights @ np.log(ratios))
    return np.array([mean_kl, value((p, q))-value(OLD), weights @ gains, weights @ clipped])


def derivative(fn, x):
    h = 1e-5
    return np.array([(fn(x + h*e)-fn(x-h*e))/(2*h) for e in np.eye(len(x))])


def local_direction():
    p, q = OLD
    gradient = derivative(lambda x: value(sigmoids(x)), OLD_LOGITS)
    fisher = (1-GAMMA)*np.diag([p*(1-p), GAMMA*p*q*(1-q)])
    direction = np.linalg.solve(fisher, gradient)
    return direction * np.sqrt(2*TRUST_BUDGET / (gradient @ direction))


def check_conditional_and_path(continuing, target_high):
    """Reweight the second choice conditional on continuing, then vary the root too."""
    old_continuing, old_high = OLD
    old_actions = np.array([1 - old_high, old_high])
    new_actions = np.array([1 - target_high, target_high])
    action_ratios = new_actions / old_actions
    given_continue = GAMMA * ((old_actions * action_ratios) @ np.array([1., 3.]))
    # Root action 'continue' is fixed in that Q query, but random in a full path.
    old_high_path = old_continuing * old_high
    replace_last = old_high_path * action_ratios[1]
    replace_both = replace_last * continuing / old_continuing
    return given_continue, replace_last, replace_both


def verify(step):
    grad = derivative(lambda x: value(sigmoids(x)), OLD_LOGITS)
    assert np.allclose(grad, [.0875, .16875])
    for j in (2, 3):
        assert np.allclose(grad, derivative(lambda x: diagnostics(x)[j], OLD_LOGITS))
    shared = derivative(lambda w: value(sigmoids(OLD_LOGITS + w[0]*np.array([1., -1.]))), np.array([0.]))
    assert abs(shared[0] - (grad[0]-grad[1])) < 1e-9
    # The chapter introduction changes the visit rate AND the conditional action.
    candidate = np.array([.9, .1])
    q_continue, old_root_high, new_path_high = check_conditional_and_path(*candidate)
    assert np.allclose([q_continue, old_root_high, new_path_high], [1.08, .050, .090])
    assert np.isclose((1 - candidate[0]) + candidate[0] * q_continue, value(candidate))
    print(f"Q(continue) {q_continue:.3f}; P(continue, high) with old/new root "
          f"{old_root_high:.3f}/{new_path_high:.3f}")
    candidate_logits = np.log(candidate / (1 - candidate))
    _, actual, surrogate, _ = diagnostics(candidate_logits)
    assert np.allclose([actual, surrogate], [-.103, .005])
    print(f"Opening example: return change {actual:.3f}; old-visit surrogate {surrogate:+.3f}")
    # At u=.2 in the same two-step task the policy remains inside both budgets.
    # Its increased probability of visiting the second state changes the return.
    candidate = np.array([.58, .22])
    mean_kl, gain, surrogate, clipped = diagnostics(np.log(candidate / (1-candidate)))
    assert np.allclose([mean_kl, gain, surrogate, clipped], [.00141109546, -.00332, .001, .001])
    print(f"Candidate (p=.58,q=.22): mean KL {mean_kl:.6f}, "
          f"return change {gain:+.5f}, surrogate {surrogate:+.5f}, clipped {clipped:+.5f}")
    half, full = [diagnostics(OLD_LOGITS+t*step) for t in (.5,1)]
    assert half[0] < TRUST_BUDGET < full[0] and half[2] > 0
    assert np.allclose(half, [.00275842, .16511041, .15580181, .07877098])
    assert np.allclose(full, [.01172993, .37054659, .33096979, .08994885])
    for t, numbers in zip((.5,1.), (half,full)):
        print(f"step {t:.1f}: KL, actual gain, surrogate, clipped =", *numbers)


def draw(step):
    for candidate in ("/System/Library/Fonts/STHeiti Light.ttc", "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc"):
        if Path(candidate).is_file():
            font_manager.fontManager.addfont(candidate)
            plt.rcParams["font.family"] = font_manager.FontProperties(fname=candidate).get_name()
            break
    plt.rcParams.update({"pdf.fonttype":42,"font.size":13,"axes.spines.top":False,"axes.spines.right":False})
    ts = np.linspace(0, 1.03, 220)
    kl, actual, surrogate, clipped = np.array([diagnostics(OLD_LOGITS+t*step) for t in ts]).T
    fig, (left, right) = plt.subplots(1,2,figsize=(10.2,2.6),gridspec_kw={"width_ratios":[1,1.20]})
    teal, red, grey = "#096b76", "#aa412d", "#586976"
    left.plot(ts, kl, color=teal, lw=2.8)
    left.axhline(TRUST_BUDGET, ls="--", color=grey, lw=1)
    left.text(.04,.01045,"预算 0.01",color=grey,fontsize=12)
    for t, label, color, xy in ((.5,"接受半步",teal,(.13,.0043)),(1,"拒绝全步",red,(.59,.0122))):
        y=diagnostics(OLD_LOGITS+t*step)[0]
        left.scatter(t,y,color=color,s=39,zorder=2)
        left.annotate(label, (t,y),xytext=xy,color=color,fontsize=12,
                      arrowprops={"arrowstyle":"-", "color":color,"lw":1})
    left.set(ylim=(0,.014),yticks=[0,.005,.010],ylabel="平均 KL",xlabel="候选步长比例")
    for y, color, label, style in ((actual,red,"真实回报变化","-"),(surrogate,grey,"旧访问代理","--"),(clipped,teal,"裁剪代理","-")):
        right.plot(ts,y,color=color,label=label,ls=style,lw=2.3)
    right.legend(loc="upper left",frameon=False,fontsize=11)
    right.set(ylim=(-.015,.44),yticks=[0,.2,.4],ylabel="相对旧策略的变化",xlabel="同一候选步长比例")
    for ax in (left,right):
        ax.set(xlim=(0,1.04),xticks=[0,.5,1])
        ax.grid(axis="y",alpha=.12)
    fig.tight_layout(pad=.3,w_pad=1.2)
    fig.savefig(Path(__file__).with_name("compare-steps.pdf"),bbox_inches="tight",pad_inches=.03)
    plt.close(fig)


if __name__ == "__main__":
    direction=local_direction()
    verify(direction)
    draw(direction)
