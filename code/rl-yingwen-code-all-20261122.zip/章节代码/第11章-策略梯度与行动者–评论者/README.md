# 第 11 章　策略梯度与行动者–评论者：程序

本目录可以单独运行：在本目录下执行下面的命令即可，结果写回本目录的 `assets/`。目录由 `rl-course/tools/export_chapter_code.py` 从课程目录生成，改程序请改课程目录里的原件，再重新导出。

## 准备

```sh
python3 -m pip install -r requirements.txt
```

需要的第三方包：matplotlib、numpy、torch。复现附录要求 Python 3.10 或更新版本；核验时用的版本见下表。

## 运行（与复现附录相同）

```sh
python3 demos/short_corridor.py --action-values
python demos/short_corridor.py --output results/short-corridor
python3 demos/corridor_memory.py --output results/corridor-memory
python demos/sample14_pg.py --torch-check
python3 assets/course38-policy/compare_steps.py
python3 assets/course38-policy/trpo_landscape.py
python3 demos/ch11_pg_signals.py
python demos/value_policy_mechanisms.py
python3 demos/deep_v13_connections.py
python3 demos/gae_ppo_walkthrough.py --test
python3 demos/v19_policy_gradient.py
python3 demos/ch11_trust_update.py
python3 demos/ppo_shared_tree.py
python3 demos/ppo_sac_v11_lab.py --check
python3 demos/ppo_sac_v11_lab.py --train --plot --seeds 0 1 2
python demos/ppo_epoch_audit.py
python3 demos/ch11_open_numbers.py
python3 demos/ch11_deterministic_policy.py
python3 demos/ch11_policy_improvement.py
python3 demos/ch11_policy_objectives.py
python3 demos/ch11_soft_stitch.py
python3 demos/ch11_control_operators.py
python3 demos/soft_control_choice.py
python demos/sample14_sac.py --steps 8000 --seeds 0 1 2
python demos/v18_methods.py
python3 demos/policy_gradient_check.py
python3 demos/continuous_control_walkthrough.py --test
```

## 本目录的程序

| 程序 | 说明 | 核验 |
|---|---|---|
| `demos/short_corridor.py` | REINFORCE in Sutton & Barto's short corridor (2nd ed., Example 13.1). | 通过（2 秒） |
| `demos/corridor_memory.py` | Learn with or without the previous key in Sutton & Barto's short corridor. | 通过（1 秒） |
| `demos/sample14_pg.py` | REINFORCE on the two-decision task used in Chapter 11. | 通过（6 秒） |
| `assets/course38-policy/compare_steps.py` | Two-step decision tree. Print exact policy and surrogate changes; draw the lecture figure. | 通过（1 秒） |
| `demos/ch11_pg_signals.py` | Enumerate the policy-gradient signals for Chapter 11's two-decision task. | 通过（0 秒） |
| `demos/value_policy_mechanisms.py` | Small, exact calculations for chapters 9--11. Python 3 + numpy + matplotlib. | 通过（1 秒） |
| `demos/deep_v13_connections.py` | Recompute the numerical mechanisms used in Chapters 9--12. | 通过（2 秒） |
| `demos/gae_ppo_walkthrough.py` | A fixed three-transition GAE/PPO example, not a training experiment. | 通过（0 秒） |
| `assets/course38-policy/trpo_landscape.py` | Exact policy landscapes for the chapter's two-decision task. | 通过（1 秒） |
| `demos/v19_policy_gradient.py` | Small exact calculations for chapter 11; no training and no PyTorch. | 通过（3 秒） |
| `demos/ch11_trust_update.py` | Two finite policy updates for the chapter's two-step MDP (Python standard library). | 通过（0 秒） |
| `demos/ppo_shared_tree.py` | Exact return, old-policy surrogate, and PPO-Clip in a two-step decision tree. | 通过（0 秒） |
| `demos/ppo_sac_v11_lab.py` | CPU teaching lab: actual neural PPO and SAC on a 12-step position regulator. | 通过（96 秒） |
| `demos/ppo_epoch_audit.py` | Read each policy fitted to one old batch in the course's PPO position task. | 通过（20 秒） |
| `demos/ch11_open_numbers.py` | Numbers for the chapter 11 pages added in the 2026-11 revision. | 通过（52 秒） |
| `demos/ch11_deterministic_policy.py` | Analytic continuous-action examples for chapter 11. | 通过（0 秒） |
| `demos/ch11_policy_improvement.py` | Compare policy improvements on one probability simplex and check their propagation. | 通过（0 秒） |
| `demos/ch11_policy_objectives.py` | Reproduce the final decision in chapter 11. Run without options for the numbers. | 通过（0 秒） |
| `demos/ch11_soft_stitch.py` | Two Bellman sweeps over two suboptimal logs in a deterministic, two-step MDP. | 通过（0 秒） |
| `demos/ch11_control_operators.py` | A single transition with a known last-step critic, shared by three backups. | 通过（0 秒） |
| `demos/soft_control_choice.py` | The two-action experiment in the maximum-entropy control section, using only the standard library. | 通过（0 秒） |
| `demos/sample14_sac.py` | Small, complete SAC experiment accompanying the Chapter 11 sample. | 通过（95 秒） |
| `demos/v18_methods.py` | One-update scientific diagrams for chapters 7--11; no training runs. | 通过（4 秒） |
| `demos/policy_gradient_check.py` | Exact checks for chapter 04, Python 3.9+, standard library only. | 通过（0 秒） |
| `demos/continuous_control_walkthrough.py` | Two-step position control: fixed critic errors and SAC pathwise derivatives. | 通过（0 秒） |
| `demos/ch11_target_policy_cn.py` | Chapter 11, slides ch11-td3-target, ch11-policy-simplex, ch11-policy-comparison-case. | 通过（2 秒） |
| `demos/ch11_sac_course_plots.py` | Redraw the two SAC result figures of section 11.12 in the slide fonts. | 通过（3 秒） |
| `demos/ch11_pg_figures_zh.py` | Chinese-label figures for Sections 11.2-11.3 (two-step tree, gamma=.9). | 通过（2 秒） |
| `demos/ch11_ppo_epochs_seeds.py` | 三个种子首批的同批多轮复用：旧批裁剪代理与真实期望回报的增量。 | 通过（1 秒） |

被上面程序 import 的本课模块：`demos/course15_traces.py`、`demos/dqn_model_v11.py`、`demos/mud_world.py`、`demos/plot_fonts.py`、`demos/v17_methods.py`。

表中后 4 个程序复现附录本章一节没有列出，来自课件、阅读稿、CODE-MAP 或文件名前缀（第三部分另含学习器阶梯）。

## 复现附录本章一节

本章的短走廊与一位记忆实验、两步任务上的 REINFORCE、位置控制任务上的 PPO 与 SAC，以及 TRPO、PPO、确定性策略梯度、最大熵控制的各个小算例，都来自本课的程序；其中神经网络训练需要 PyTorch，见上文运行环境。TD3 消融表、soft Q 迷宫图与 SAC 人形机器人画面取自原论文和作者博客，不在表中。

| 位置 | 结果 | 设置 | 程序 | 数据与输出 |
|---|---|---|---|---|
| 11.1 节（短走廊） | 按右初始概率 $p=.25$ 与 $.80$ 两组训练后的期望步数 $11.71$ 与 $11.80$；同一策略在各格的按键价值 | 本课的模拟：Sutton 与 Barto 例 13.1 的短走廊；每 40 回合平均一次 REINFORCE 更新，步长 $.018$，logit 限于 $[-3,3]$，策略不读位置；每次 7200 回合，独立重复 8 次；评价用真实转移方程精确求期望 | `demos/short_corridor.py` | `assets/short-corridor/training.csv`；`assets/short-corridor/learning.svg`；`assets/short-corridor/policy-class.pdf` |
| 11.1 节（一位记忆） | 无记忆与一位记忆策略的期望步数 $11.70$ 与 $4.48$；首步必打滑时 $12.70$ 与 $6.18$；达到同样回合数用去的真实动作约 $28{,}303$ 与 $14{,}882$ | 本课的模拟：同一短走廊，初始按右概率均为一半，每 40 回合更新一次；每次 2400 回合，独立重复 8 次；“上一键记忆”与“首步打滑”是课堂变体 | `demos/corridor_memory.py` | `assets/corridor-memory/training.csv`；`assets/corridor-memory/reader.json`（`summary`）；`assets/corridor-memory/learning.svg` |
| 11.1 节“两步决策任务”；11.2 节；11.3 节开头；课件 sample14-pg-task 至 sample14-pg-critic-direction | 三条轨迹对梯度均值的贡献；一回合高奖轨迹的单次更新（$p,q$ 由 $.5,.25$ 变为 $.534,.290$，$J$ 由 $1.175$ 变为 $1.225$）；自动微分的负损失方向与显式梯度一致；训练后 12 次运行的期望回报平均 $2.659$（初值 $1.175$，最优 $2.7$）；后继价值误差改变更新方向的曲线 | 本课的模拟：两步任务，$\gamma=.9$，初始 $p=.5,q=.25$；每批 32 个完整回合更新一次，步长 $.2$，运行 300 批（每次 9600 回合），独立重复 12 次；评价用已知模型精确计算，不反馈给学习器 | `demos/sample14_pg.py` | `assets/sample14-pg/results.json`；逐次曲线 assets/sample14-pg/seed-0.npy 至 seed-11.npy；图 `assets/sample14-pg/enumeration.png`、`assets/sample14-pg/behavior.png`、`assets/sample14-pg/learning.png`、`assets/sample14-pg/critic-error.png` |
| 课件 sample14-pg-enumerate；11.4 节开头与“TRPO的完整更新顺序”；课件 course28-trpo-algorithm、course22-trpo-summary | 两步树的轨迹枚举与梯度；候选策略（继续 $.5\to.9$，取 3 的概率 $.25\to.10$）：起点项 $.35$ 与 $.14$，$s_1$ 处即时奖励减少 $.30$；条件动作价值 $1.08$，取到 3 的概率 $.125\to.09$（只换末动作为 $.05$）；回溯线搜索各点 | 本课的计算：精确枚举，无采样 | `assets/course38-policy/compare_steps.py` | 终端输出；`assets/course38-policy/compare-steps.pdf` |
| 11.3 节；课件 sample14-pg-baseline | 基线对梯度条件方差的影响 | 本课的计算：两步任务的轨迹概率枚举，不采样、不训练 | `demos/ch11_pg_signals.py` | 终端输出 |
| 11.3 节；课件 core-v8-baseline-optimum | 常数基线与最小方差基线的方差曲线 | 本课的计算：有限算例 | `demos/value_policy_mechanisms.py` | `assets/v8-mechanisms/baseline-variance.pdf` |
| 11.3 节“共享表示下的策略与价值梯度”“行动者与评论者的资格迹” | 同一参数上价值损失反向改变动作概率；行动者与评论者两组迹的一步更新 | 本课的计算：单参数算例与有限差分（`shared_actor_critic`）；资格迹见函数 `actor_critic_trace_step` | `demos/deep_v13_connections.py` | `assets/deep-v13/checks.json`（`shared_actor_critic`、`n_step_and_ac`）；`assets/deep-v13/shared-encoder.png` |
| 11.3 节；课件 deep-35、deep-36 | 三个转移的 GAE 逆序递推、终止与截断的尾值、PPO 概率比与分段梯度 | 本课的计算：固定的三转移片段，不训练；`--test` 做断言检查 | `demos/gae_ppo_walkthrough.py` | 终端输出（JSON）；图 `assets/v5/deep/gae-ppo-walkthrough.svg`，来源与校验值见 `assets/v5/deep/sources.json` |
| 11.4 节“TRPO：从访问误差到分布变化约束”；课件 course22-trpo-opening、deep-38、deep-pg-kl-geometry | 两步树上真实回报、局部代理与切线的山面、截面与 KL 信赖域 | 本课的计算：精确计算与等高线，标出回溯点 | `assets/course38-policy/trpo_landscape.py` | `assets/course38-policy/trpo-hill.pdf`；`assets/course38-policy/trpo-section.pdf`；`assets/course38-policy/trpo-trust.pdf` |
| 11.4 节“TRPO：从访问误差到分布变化约束”；11.11 节“随机转移：不能把好运气当成可控制变量”；11.12 节“SAC的一次更新计算”；课件 sample14-sac-summary | 真实 KL 边界与局部二次近似、Fisher 与回溯；PPO 裁剪梯度；控制即推断的轨迹 KL 展开（真实转移与直接条件化之差）；SAC 显式密度与动作两条导数路径 | 本课的计算：轨迹枚举、有限差分与数值积分，不训练，不读也不覆盖已有训练结果 | `demos/v19_policy_gradient.py` | `assets/v19-policy-gradient/checks.json`（`pg`、`trpo`、`ppo`、`control_as_inference`、`sac`）；`assets/v19-policy-gradient/trpo-geometry.png`、`assets/v19-policy-gradient/cai-dynamics.png`、`assets/v19-policy-gradient/sac-paths.png` |
| 11.5 节“PPO：用裁剪代理进行多轮一阶优化”；课件 deep-pg-ppo-snapshot | 同一批样本上两种有限策略更新的代理值与真实回报；梯度的有限差分核对 | 本课的计算：两步 MDP 的枚举，仅用 Python 标准库 | `demos/ch11_trust_update.py` | 终端输出 |
| 11.5 节“PPO：用裁剪代理进行多轮一阶优化” | 裁剪代理 $-.8\max(d,-.1)+.9\min(d,.1)$ 在 $d=.1$ 处取最大，$p=.40$；起点损失 $.08$，旧访问计入 $.09$，真实只得 $.072$ | 本课的计算：两步决策树的精确回报、旧策略代理与 PPO-Clip，裁剪宽度 $.2$；共享参数例用 `--p 41/100`，独立概率例用 `--candidate .58 .22` | `demos/ppo_shared_tree.py` | 终端输出 |
| 11.5 节“PPO的位置控制任务与实现”；课件 ppo-v11-code、ppo-v11-task、sample14-sac-temperature | PPO 三次训练的最终外部折扣回报 $-.2473,-.2535,-.2507$；学到的动作分布与价值；温度调节页所用的 10000 步 SAC 对照 | 本课的模拟：12 步位置控制，状态含剩余时间，$\gamma=.97$；行动者与评论者各为两层 32 单元 tanh 网络，不共享参数；裁剪 $[.8,1.2]$，小批量 96 条；每次 100 次更新、38{,}400 次真实转移；独立重复 3 次（种子 0、1、2）；评价冻结随机策略，独立随机流 128 回合 | `demos/ppo_sac_v11_lab.py` | `assets/ppo-sac-v11/summary.json`（`ppo`）；`assets/ppo-sac-v11/run-config.json`；`assets/ppo-sac-v11/math-checks.json`；权重与曲线 ppo-seed-0.pt 至 seed-2，sac-seed-0.pt 至 seed-2；`assets/ppo-sac-v11/policy-value-data.npz`；`assets/ppo-sac-v11/ppo-policy-value.png` |
| 11.5 节“PPO的位置控制任务与实现”；课件 ppo-v11-learning、ppo-v11-value | 一次典型运行（种子 2）首批第 5 轮：裁剪代理相对初值 $+.969$，同一起点的真实回报 $-.098$；旧访问频率下未裁剪代理 $+.484$、裁剪代理 $-.248$；三次运行的学习曲线与训练后轨迹 | 本课的模拟：训练与种子同上一行；评价器按动态规划对全部动作路径求和，起点取该批观测到的 32 个起点 | `demos/ppo_epoch_audit.py` | `assets/ppo-epochs/epochs.csv`；`assets/ppo-epochs/ppo-update.png`；`assets/ppo-epochs/epoch.png`、`assets/ppo-epochs/positions.png`、`assets/ppo-epochs/training.png` |
| 11.5 节“七种做法同属一个式子”；11.7 节“连续动作上求不准最大”；11.8 节“把噪声收到零”；11.9 节“探索噪声与目标副本”；11.10 节“行动者专找评论者的错”；11.11 节“保留随机”；课件 ch11-one-formula、ch11-max-grid、ch11-dpg-limit、ch11-ddpg-parts、ch11-ripple-chase、ch11-keep-random | $q=(0,1,2)$、旧策略均匀时：$\eta=\tfrac13$ 期望 $1.22$、KL $.036$，$\eta=1$ 期望 $1.58$、KL $.27$，$\eta\to\infty$ 期望 $2$、KL $\ln3$；连续动作取最大的高估随候选数增长；得分函数单样本方差 $.7056/\sigma^2+15\sigma^2-3.76$（$\sigma=.5,.3,.1$ 时约 $2.8,5.4,67$）；波纹评论者使目标高出 $.05$，为实际损失的 25 倍，$\gamma=.99$ 时累计至 $5$；$\kappa=.2$ 比 $.1$ 每步少得 $.017$ | 本课的计算：六组有限算例，打印的每个数都出现在课件或讲义中 | `demos/ch11_open_numbers.py` | 终端输出 |
| 11.10 节“评论者的斜率误差与 TD3”“行动者专找评论者的错”；课件 deep-continuous-slope、ch11-td3-target | 确定性策略的一步斜率；两条构造估值曲线上的 TD3 目标与噪声积分 | 本课的计算：解析曲线与有限差分；`--figures 目录` 写出课件图 | `demos/ch11_deterministic_policy.py` | 终端输出；`assets/ch11-policy/dpg-step.pdf`；`assets/ch11-policy/td3-target.pdf` |
| 课件 ch11-policy-simplex、ch11-performance-identity；“本章统一视角” | 同一组动作价值在概率单纯形上的约束解与软最优解；局部改善量与全程回报（普通与最大熵目标） | 本课的计算：精确验算；`--figure PATH.pdf` 写出课件图 | `demos/ch11_policy_improvement.py` | 终端输出；`assets/ch11-policy/improvement-simplex.pdf` |
| 课件 ch11-policy-comparison-case | 两动作情形下代理与目标的三幅对照图 | 本课的计算：精确计算；`--figure PATH.pdf` 重绘 | `demos/ch11_policy_objectives.py` | 终端输出；`assets/ch11-policy/terminal-policy.pdf` |
| 11.11 节；课件 ch11-soft-stitch、ch11-soft-stitch-backup | 两条次优记录上两轮 Bellman 同步更新得到的策略概率与精确评价 | 本课的计算：确定性两步 MDP，学习器只看四条记录，环境只用于训练后评价 | `demos/ch11_soft_stitch.py` | 终端输出 |
| 课件 ch11-operators-case | 同一转移、已知末步评论者下三种备份目标 | 本课的计算：末步奖励 $1-a^2$，离散动作集含连续曲线的最大点，SAC 用无界高斯动作；不训练 | `demos/ch11_control_operators.py` | 终端输出 |
| 11.12 节；课件 sample14-sac-entropy | 最大熵控制中的两动作算例 | 本课的计算：仅用 Python 标准库 | `demos/soft_control_choice.py` | 终端输出 |
| 11.12 节“SAC的连续位置控制任务”“soft Bellman方程与策略改进”“SAC算法与训练结果”；课件 sample14-sac-task 至 sample14-sac-learning | 固定动作价值与不同温度的最优分布；三次训练的最终外部折扣回报 $-.2856,-.2829,-.2838$；零动作 $-3.4803$，均匀动作 $-5.2282$，已知动力学的反馈控制器 $-.2436$；从 $x=.8$ 执行 20 个回合的轨迹与动作分布 | 本课的模拟：12 步位置控制；两个 Q 网络与策略网络各为两层 32 单元 tanh；前 500 步均匀动作，此后每步抽 128 条回放更新一次（每次 7501 次梯度更新）；每次 8000 条真实转移，独立重复 3 次（种子 0、1、2）；评价冻结随机策略，独立 256 回合（种子 9001），不含熵奖励 | `demos/sample14_sac.py` | `assets/sample14-sac/results.json`；曲线 curve-0.npy 至 curve-2.npy，权重 initial-0.pt 至 learned-2.pt；`assets/sample14-sac/entropy-choice.png`、`assets/sample14-sac/learning.png`、`assets/sample14-sac/behavior.png` |
| 11.12 节“SAC的回放动作与当前策略动作” | 旧动作 $-.4$ 使位置 $.8\to.7$，奖励 $-.4948$；在 $s$ 新采 $-.9529$ 供行动者更新，在 $s'$ 新采 $-.8347$ 供目标计算；目标独立复算 $-.54965$ | 本课的计算：取自 sample14_sac.py 的一次演示运行（种子 7），不重新训练 | `demos/v18_methods.py` | `assets/v18-methods/report.json`（`sac_queries`）；`assets/v18-methods/sac-three-actions.png` |
| 11.12 节“数值核对”；“阅读与练习” | 轨迹对数策略梯度、因果性与占用；动作求导路径、tanh 密度与温度方向 | 本课的计算：构造的两步 MDP 枚举与有限差分；两步位置控制的固定评论者与路径导数；均不训练 | `demos/policy_gradient_check.py`；`demos/continuous_control_walkthrough.py` | 终端输出（后者默认输出 JSON，`--test` 做断言） |

运行：
```sh
python3 demos/short_corridor.py --action-values
python demos/short_corridor.py --output results/short-corridor
python3 demos/corridor_memory.py --output results/corridor-memory
python demos/sample14_pg.py --torch-check
python3 assets/course38-policy/compare_steps.py
python3 assets/course38-policy/trpo_landscape.py
python3 demos/ch11_pg_signals.py
python demos/value_policy_mechanisms.py
python3 demos/deep_v13_connections.py
python3 demos/gae_ppo_walkthrough.py --test
python3 demos/v19_policy_gradient.py
python3 demos/ch11_trust_update.py
python3 demos/ppo_shared_tree.py
python3 demos/ppo_sac_v11_lab.py --check
python3 demos/ppo_sac_v11_lab.py --train --plot --seeds 0 1 2
python demos/ppo_epoch_audit.py
python3 demos/ch11_open_numbers.py
python3 demos/ch11_deterministic_policy.py
python3 demos/ch11_policy_improvement.py
python3 demos/ch11_policy_objectives.py
python3 demos/ch11_soft_stitch.py
python3 demos/ch11_control_operators.py
python3 demos/soft_control_choice.py
python demos/sample14_sac.py --steps 8000 --seeds 0 1 2
python demos/v18_methods.py
python3 demos/policy_gradient_check.py
python3 demos/continuous_control_walkthrough.py --test
```

外部代码与公开数据（出处）：TD3 作者实现 TD3.py（Fujimoto 等，github.com/sfujim/TD3）与 TD3 消融表（Fujimoto 等，2018）；Spinning Up 的 trpo.py、core.py、ppo.py（OpenAI Spinning Up，PyTorch 版）；soft Q 学习的迷宫与动作密度图（BAIR 博客，assets/ch11-policy/bair-soft-open.png、bair-soft-maze.png、bair-soft-density.png）；SAC 人形机器人画面（Haarnoja 等，assets/course31-deep/sac-humanoid.png）。

## 参考数据

`assets/`（以及 `demos/NN-results/`）下复制了 57 个数据文件（json、csv 等），即课程目前使用的结果；图片没有复制，运行程序会重新画出。重跑会覆盖这些文件，可以先另存一份再对照。
