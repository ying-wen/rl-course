"""A single transition with a known last-step critic, shared by three backups.

The last reward is 1 - a**2. The discrete action set contains the exact
maximizer of the continuous curve. SAC has an unbounded Gaussian action
space in this exercise. No training or function approximation is involved.
"""
from math import exp, isclose, log, pi, sqrt


def last_reward(action):
    return 1.0 - action**2


def gaussian_soft_value(mean, variance, temperature):
    expected_reward = 1 - mean**2 - variance
    entropy = 0.5 * log(2 * pi * exp(1) * variance)
    return expected_reward + temperature * entropy


def target(reward, discount, terminal, continuation):
    return reward if terminal else reward + discount * continuation


def main():
    temperature = 0.5
    variance = 0.25
    continuations = {
        "discrete maximum": max(last_reward(a) for a in (-1, 0, 1)),
        "current deterministic actor": last_reward(0.5),
        "soft Gaussian evaluation": gaussian_soft_value(0., variance, temperature)
    }
    # Integral of exp((1-a**2)/temperature) over the real line.
    # Here the chosen Gaussian also equals the exact soft optimal policy.
    exact_soft_optimum = 1 + temperature * log(sqrt(pi * temperature))
    assert isclose(continuations["soft Gaussian evaluation"], exact_soft_optimum)
    assert isclose(variance, temperature / 2)
    for name, value in continuations.items():
        print(f"{name:28s} U={value:.6f}  y={target(0., .9, False, value):.6f}")
        assert target(2., .9, True, value) == 2.


if __name__ == "__main__":
    main()
