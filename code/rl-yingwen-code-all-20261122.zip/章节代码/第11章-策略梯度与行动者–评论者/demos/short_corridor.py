"""REINFORCE in Sutton & Barto's short corridor (2nd ed., Example 13.1).

python demos/short_corridor.py --output results/short-corridor
python demos/short_corridor.py --action-values
Only the plotting function needs matplotlib. Each action is sampled anew.
The policy and its gradient use no position input.
"""
import argparse
import csv
from math import exp, sqrt, log
from pathlib import Path
from random import Random
from statistics import mean


def successor(position, right):
    """Positions 0,1,2 are live; 3 is the goal. Position 1 reverses the keys."""
    direction = 1 if right else -1
    if position == 1:
        direction = -direction
    return max(0, position + direction)


def expected_steps(p):
    if p in (0, 1):
        return float('inf')
    return 4 / p + 2 / (1 - p)


def action_values(p):
    """True q_pi under a fresh right press with probability p on each step."""
    if not 0 < p < 1:
        raise ValueError("The hitting-time calculation requires 0 < p < 1.")
    # First-step equations give h2 = 3/p and h0 - h1 = 1/p.
    h0 = expected_steps(p)
    remaining = [h0, h0 - 1 / p, 3 / p, 0]
    # Reward -1 on the current move, followed by minus the remaining duration.
    return [tuple(-1 - remaining[successor(s, right)] for right in (False, True))
            for s in range(3)]


def sigmoid(theta):
    return 1 / (1 + exp(-theta))


def sample_episode(p, rng):
    position, right_presses = 0, []
    while position < 3:
        right = rng.random() < p
        right_presses.append(right)
        position = successor(position, right)
    return right_presses


def gradient_sample(right_presses, p):
    # r=-1 on every step, including arrival. G_t=-(T-t).
    # The derivative of log pi(A_t) w.r.t. its logit is I(right)-p.
    length = len(right_presses)
    return sum(-(length-t) * (right-p) for t, right in enumerate(right_presses))


def run(seed, start, batches=180, batch_size=40, rate=.018):
    rng = Random(seed)
    theta = log(start / (1 - start))
    output = []
    for batch in range(batches + 1):
        p = sigmoid(theta)
        if batch % 5 == 0:
            output.append(dict(seed=seed, start=start, episodes=batch * batch_size,
                               probability=p, expected_steps=expected_steps(p)))
        if batch < batches:
            episodes = [sample_episode(p, rng) for _ in range(batch_size)]
            update = mean(gradient_sample(episode, p) for episode in episodes)
            # A bounded logit avoids exceedingly long episodes near p=0 or p=1.
            # The optimum lies strictly inside this interval.
            theta = max(-3., min(3., theta + rate * update))
    return output


def write_results(rows, out):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from plot_fonts import chinese_font
    plt.rcParams.update({'font.family': chinese_font().get_name(), 'font.size': 12,
                         'axes.spines.top': False, 'axes.spines.right': False,
                         'svg.hashsalt': 'corridor-policy'})
    out.mkdir(parents=True, exist_ok=True)
    with (out/'training.csv').open('w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=rows[0].keys())
        writer.writeheader()
        writer.writerows(rows)
    opt = 2-sqrt(2)
    colors = ['#08766c', '#975027']
    fig, ax = plt.subplots(figsize=(4.9, 2.4), layout='constrained')
    ps = [k/1000 for k in range(10,991)]
    ax.plot(ps, [expected_steps(p) for p in ps], color=colors[0], lw=2.6)
    ax.scatter([opt], [expected_steps(opt)], s=38, color=colors[0], zorder=4)
    ax.annotate('最短平均步数 11.66', (opt, expected_steps(opt)), (.43, 44),
                arrowprops={'arrowstyle':'->','color':colors[0]}, fontsize=12)
    ax.scatter([.05,.95], [expected_steps(.05),expected_steps(.95)], color=colors[1], s=35)
    ax.set(xlim=(0,1), ylim=(0,94), xticks=(0,.25,.5,.75,1), yticks=(12,45,82),
           xlabel='每一步按右键的概率 p', ylabel='平均到达步数')
    ax.grid(axis='y', alpha=.12)
    fig.savefig(out/'policy-class.pdf',metadata={'CreationDate':None,'ModDate':None})
    plt.close(fig)
    # Plot the same seed means in both layouts; the page selects by viewport width.
    for narrow in (False, True):
        if narrow:
            fig, axes = plt.subplots(2, 1, figsize=(2.86, 4.25), sharex=True,
                                     layout='constrained')
        else:
            fig, axes = plt.subplots(1, 2, figsize=(9.2, 3.25), layout='constrained')
        for axis, column, title, limit in zip(axes, ['probability','expected_steps'],
                ['从轨迹学得的按右概率', '按当时策略行动的期望步数'],
                [opt, expected_steps(opt)]):
            axis.axhline(limit, color='#666666', ls=':', lw=1.6, label='无记忆策略的最优值')
            for start, color in zip((.25,.8), colors):
                by_time = {}
                for row in rows:
                    if row['start'] == start:
                        by_time.setdefault(row['episodes'], []).append(row[column])
                times = sorted(by_time)
                values = [mean(by_time[t]) for t in times]
                axis.plot(times, values, color=color, lw=2, label=f'初始 p = {start}')
                if narrow and column == 'probability':
                    axis.annotate(f'初始 {start:.2f}', (0, values[0]),
                                  xytext=(4, 2 if start > .5 else -2), textcoords='offset points',
                                  ha='left', va='bottom' if start > .5 else 'top',
                                  color=color, fontsize=13.4)
            axis.grid(axis='y', alpha=.15)
            if not narrow:
                axis.set(xlabel='训练回合数', title=title)
        if narrow:
            axes[0].set(ylim=(.08, .985), yticks=[.25, .6, .8])
            axes[1].set(ylim=(10.8, 19.4), yticks=[12, 15, 18],
                        xticks=[0, 3600, 7200], xlim=(0, 7200))
            axes[0].set_ylabel('按右概率', fontsize=13.4)
            axes[1].set_ylabel('期望到达步数', fontsize=13.4)
            axes[1].set_xlabel('训练回合数', fontsize=13.4)
            for axis in axes:
                axis.tick_params(labelsize=13.4)
            axes[1].annotate('最优 11.66', (7200, expected_steps(opt)), xytext=(-1, 5),
                             textcoords='offset points', ha='right', va='bottom',
                             color='#555555', fontsize=13.4)
        else:
            axes[0].set_ylabel('按右键的概率')
            axes[1].set_ylabel('步数')
            axes[0].legend(fontsize=11, loc='lower right')
        name = 'learning-narrow.svg' if narrow else 'learning.svg'
        fig.savefig(out/name, metadata={'Date':None})
        plt.close(fig)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path)
    parser.add_argument('--action-values', action='store_true',
                        help='Print exact action values for the uniform policy.')
    args = parser.parse_args()
    if args.action_values:
        for position, (left_q, right_q) in enumerate(action_values(.5)):
            print(f"position {position}: q(left)={left_q:g}, q(right)={right_q:g}")
        if args.output is None:
            raise SystemExit(0)
    rows = []
    for start in (.25,.8):
        for seed in range(8):
            rows.extend(run(seed,start))
    for start in (.25,.8):
        final = [r for r in rows if r['start']==start and r['episodes']==7200]
        print(f"start {start:.2f}: mean p {mean(r['probability'] for r in final):.5f}, "
              f"mean expected episode length {mean(r['expected_steps'] for r in final):.5f}")
    print(f"best memoryless p = {2-sqrt(2):.6f}; expected length = {expected_steps(2-sqrt(2)):.6f}")
    if args.output:
        write_results(rows,args.output)
