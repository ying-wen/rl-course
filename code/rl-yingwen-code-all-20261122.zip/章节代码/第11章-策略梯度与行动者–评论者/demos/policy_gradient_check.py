"""Exact checks for chapter 04, Python 3.9+, standard library only.

Run from any directory: python3 /path/to/demos/policy_gradient_check.py
This enumerates a constructed two-step MDP. It does not train a neural policy.
Independent reference: finite differences of the explicitly enumerated objective.
Other checks: score, causality, occupation, baseline, full-trajectory IS,
intentional failures from dropping the outer discount or correcting one action.
"""
from itertools import product
import json
import math


def sigmoid(z):
    return 1.0 / (1.0 + math.exp(-z))


def add(x, y):
    return [a + b for a, b in zip(x, y)]


def scale(k, x):
    return [k * a for a in x]


def policy(theta, state):
    # State s0: logit theta[0]; s1: theta[1]; s2: .3-theta[1].
    return sigmoid(theta[0] if state == 0 else theta[1] if state == 1 else .3-theta[1])


def score(theta, state, action):
    d = action - policy(theta, state)
    return [d, 0.0] if state == 0 else [0.0, d if state == 1 else -d]


def action_prob(theta, state, action):
    p = policy(theta, state)
    return p if action else 1-p


def rewards(a0, a1):
    # a0=1 -> s1, a0=0 -> s2; both second actions terminate.
    r1 = .2 if a0 else -.1
    r2 = (2.0 if a1 else .5) if a0 else (-1.0 if a1 else 1.0)
    return r1, r2


def trajectory_prob(theta, a0, a1):
    return action_prob(theta, 0, a0) * action_prob(theta, 1 if a0 else 2, a1)


def objective(theta, gamma):
    return sum(trajectory_prob(theta, a0, a1) * (rewards(a0, a1)[0] + gamma*rewards(a0, a1)[1])
               for a0, a1 in product((0, 1), repeat=2))


def finite_difference(theta, gamma):
    out = []
    for j in range(2):
        up, down = list(theta), list(theta)
        up[j] += 1e-6
        down[j] -= 1e-6
        out.append((objective(up, gamma)-objective(down, gamma))/2e-6)
    return out


def score_estimate(theta, gamma, causal=False, drop_discount=False, baseline=None):
    total = [0.0, 0.0]
    for a0, a1 in product((0, 1), repeat=2):
        p = trajectory_prob(theta, a0, a1)
        state1 = 1 if a0 else 2
        r1, r2 = rewards(a0, a1)
        g0, g1 = score(theta, 0, a0), score(theta, state1, a1)
        if causal:
            b0, b1 = (baseline(0), baseline(state1)) if baseline else (0.0, 0.0)
            sample = add(scale(r1 + gamma*r2 - b0, g0),
                         scale((1 if drop_discount else gamma)*(r2-b1), g1))
        else:
            sample = scale(r1 + gamma*r2, add(g0, g1))
        total = add(total, scale(p, sample))
    return total


def occupation_gradient(theta, gamma):
    # Direct Bellman evaluation of Q and discounted state occupancies.
    p0, p1, p2 = [policy(theta, s) for s in range(3)]
    v1 = (1-p1)*.5 + p1*2
    v2 = (1-p2)*1 + p2*(-1)
    q0 = [-.1 + gamma*v2, .2 + gamma*v1]
    qs = [q0, [.5, 2], [1, -1]]
    occupancies = [1.0, gamma*p0, gamma*(1-p0)]
    total = [0.0, 0.0]
    for state in range(3):
        for action in (0, 1):
            total = add(total, scale(occupancies[state] * action_prob(theta, state, action) * qs[state][action],
                                     score(theta, state, action)))
    return total


def importance_check(theta, behavior, gamma, full_ratio=True):
    total = [0.0, 0.0]
    for a0, a1 in product((0, 1), repeat=2):
        pb = trajectory_prob(behavior, a0, a1)
        state1 = 1 if a0 else 2
        ratio = trajectory_prob(theta, a0, a1)/pb if full_ratio else (
            action_prob(theta, state1, a1)/action_prob(behavior, state1, a1))
        r1, r2 = rewards(a0, a1)
        total = add(total, scale(pb * ratio * (r1+gamma*r2),
                                 add(score(theta, 0, a0), score(theta, state1, a1))))
    return total


def variance_example(p, baseline):
    values = [(p, (1-baseline)*(1-p)), (1-p, (0-baseline)*(-p))]
    mean = sum(prob*g for prob, g in values)
    var = sum(prob*(g-mean)**2 for prob, g in values)
    return {"mean": mean, "variance": var}


def close(x, y, tolerance=2e-9):
    assert max(abs(a-b) for a, b in zip(x, y)) < tolerance, (x, y)


def main():
    theta, gamma = [.3, -.4], .7
    ref = finite_difference(theta, gamma)
    estimates = {
        "finite_difference": ref,
        "trajectory_score": score_estimate(theta, gamma),
        "causal_reward_to_go": score_estimate(theta, gamma, causal=True),
        "occupation_bellman": occupation_gradient(theta, gamma),
        "action_independent_baseline": score_estimate(theta, gamma, causal=True,
                                                       baseline=lambda s: [.4, .7, -.3][s]),
        "full_trajectory_IS": importance_check(theta, [-.8, .9], gamma),
    }
    for val in estimates.values():
        close(val, ref)
    wrong_discount = score_estimate(theta, gamma, causal=True, drop_discount=True)
    wrong_ratio = importance_check(theta, [-.8, .9], gamma, full_ratio=False)
    assert max(abs(a-b) for a, b in zip(ref, wrong_discount)) > .01
    assert max(abs(a-b) for a, b in zip(ref, wrong_ratio)) > .01
    close(score_estimate(theta, 1, causal=True), finite_difference(theta, 1))
    variances = {str(b): variance_example(.8, b) for b in [0, .8, .2]}
    close([variances[str(b)]["mean"] for b in [0, .8, .2]], [.16]*3)
    close([variances[str(b)]["variance"] for b in [0, .8, .2]], [.0064, .0576, 0])
    report = {
        "status": "all exact checks passed",
        "setting": {"theta": theta, "gamma": gamma, "trajectories": 4,
                    "reward_r1_a0_0_or_1": [-.1, .2], "reward_r2_s1_a0_or_1": [.5, 2],
                    "reward_r2_s2_a0_or_1": [1, -1]},
        "objective": objective(theta, gamma), "gradients": estimates,
        "expected_failure_drop_outer_discount": wrong_discount,
        "expected_failure_last_action_ratio_only": wrong_ratio,
        "bernoulli_logit_p_0.8_baselines": variances,
        "scope": "constructed exact MDP and local estimator variance; no neural training or efficacy claim",
    }
    print(json.dumps(report, indent=2, ensure_ascii=False))


if __name__ == '__main__':
    main()
