"""Learn with or without the previous key in Sutton & Barto's short corridor.

Run: python3 demos/corridor_memory.py --output results/corridor-memory
     python3 demos/corridor_memory.py --walk 1 0 --first-slip
The environment and reward follow Example 13.1. Previous-key memory and
the one-time slip are classroom variations. Only plotting requires Matplotlib.
"""
import argparse
import csv
import json
import math
from pathlib import Path
import random
from statistics import mean

from short_corridor import successor


def step(position, right, first_slip):
    """Apply a key under the normal floor or a blocked first right step."""
    if first_slip and right:
        return position
    return successor(position, right)


def exact_steps(probabilities, first_slip=False):
    """Expected steps starting at position 0 with 'previous key = left'.

    u and v are P(right | left) and P(right | right). In the table below,
    each row costs one step and then continues in the displayed state.
    G is the goal with zero remaining steps.

        position / previous key    left key    right key
                   0L                 0L          1R
                   0R                 0L          1R
                   1L                 2L          0R
                   1R                 2L          0R
                   2L                 1L          G

    For instance, h_0L = 1 + (1-u) h_0L + u h_1R. Eliminating the
    other four hitting times gives the expression below. It avoids
    subtracting the self-loop probability (1-u) from 1 when u is small.
    """
    if len(probabilities) != 2 or any(not math.isfinite(p) or not 0 <= p <= 1
                                     for p in probabilities):
        raise ValueError('Provide two finite probabilities in [0, 1].')
    u, v = probabilities
    # At u=0 the first right key never occurs. At v=1 every key after
    # the first right is also right, so the agent cannot cross position 1.
    if u == 0 or v == 1:
        return math.inf
    normal = (4 + v) / u - 3 + 2 * (2 - u) / (1 - v)
    if first_slip:
        # A blocked first right press reaches 0R instead of 1R. From the
        # first two rows, u * (h_0R - h_1R) = 1 + u - v.
        return normal + (1 + u - v)
    return normal


def walk(probabilities, first_slip=False, seed=0, limit=40):
    """Show the policy's input separately from the position seen by the reader."""
    expected = exact_steps(probabilities, first_slip)
    print(f'Frozen policy: expected steps {expected:.4f}')
    rng = random.Random(seed)
    position, previous_right = 0, False
    for t in range(limit):
        probability = probabilities[int(previous_right)]
        right = rng.random() < probability
        after = step(position, right, first_slip and t == 0)
        print(f'{t + 1:2}: memory={int(previous_right)}, '
              f'action={"R" if right else "L"}, position {position} -> {after}, reward -1')
        previous_right, position = right, after
        if position == 3:
            print(f'Goal after {t + 1} steps.')
            return
    print(f'Display ends after {limit} steps; the episode has not terminated.')


def probabilities(logits):
    return [1 / (1 + math.exp(-theta)) for theta in logits]


def train(read_last_key, seed, batches=60, batch_size=40, rate=.018):
    """REINFORCE sees the policy input, sampled action and rewards (-1 per step)."""
    rng = random.Random(seed)
    logits = [0.] * (2 if read_last_key else 1)
    total_steps = 0
    for batch in range(batches + 1):
        probs = probabilities(logits)
        # Baseline ties the two probabilities by using a single parameter.
        frozen = probs if read_last_key else probs * 2
        if batch % 5 == 0 or batch == batches:
            yield dict(policy='last_key' if read_last_key else 'observation',
                       seed=seed, episodes=batch * batch_size, steps=total_steps,
                       right_initial_or_after_left=frozen[0], right_after_right=frozen[1],
                       mean_steps=exact_steps(frozen), first_slip_steps=exact_steps(frozen, True))
        if batch == batches:
            break
        gradients = [0.] * len(logits)
        for _ in range(batch_size):
            position, previous_right = 0, False
            trajectory = []
            while position != 3:
                slot = int(previous_right) if read_last_key else 0
                right = rng.random() < probs[slot]
                trajectory.append((slot, right))
                position = successor(position, right)
                previous_right = right
            total_steps += len(trajectory)
            for t, (slot, right) in enumerate(trajectory):
                reward_to_go = -(len(trajectory) - t)
                gradients[slot] += reward_to_go * (int(right) - probs[slot])
        # Bound logits identically in both classes, as in short_corridor.py.
        logits = [max(-3., min(3., theta + rate * gradient / batch_size))
                  for theta, gradient in zip(logits, gradients)]


def experiment():
    rows = []
    for read_last_key in (False, True):
        for seed in range(8):
            rows.extend(train(read_last_key, seed))
    return rows


def summarize(rows):
    for policy in ('observation', 'last_key'):
        final = [r for r in rows if r['policy'] == policy and r['episodes'] == 2400]
        print(policy, 'training steps / seed', round(mean(r['steps'] for r in final), 1),
              'frozen mean steps', round(mean(r['mean_steps'] for r in final), 4),
              'with first slip', round(mean(r['first_slip_steps'] for r in final), 4))


def write_figure(rows, out):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from plot_fonts import chinese_font

    plt.rcParams.update({'font.family': chinese_font().get_name(), 'font.size': 12,
                         'axes.spines.top': False, 'axes.spines.right': False,
                         'svg.hashsalt': 'corridor-memory-policy'})
    colors = {'observation': '#8b5525', 'last_key': '#096c70'}
    labels = {'observation': '只看相同观测', 'last_key': '读取上一键'}
    by_policy = {key: [row for row in rows if row['policy'] == key] for key in colors}
    for narrow in (False, True):
        size = (2.72, 3.25) if narrow else (7.4, 3.1)
        fontsize = 13.4 if narrow else 12
        fig, ax = plt.subplots(figsize=size, layout='constrained')
        for policy, runs in by_policy.items():
            for seed in range(8):
                series = [row for row in runs if row['seed'] == seed]
                ax.plot([r['episodes'] for r in series], [r['mean_steps'] for r in series],
                        color=colors[policy], alpha=.16, linewidth=.9)
            epochs = sorted({r['episodes'] for r in runs})
            average = [mean(r['mean_steps'] for r in runs if r['episodes'] == epoch)
                       for epoch in epochs]
            ax.plot(epochs, average, color=colors[policy], lw=2.4, label=labels[policy])
            if narrow:
                ax.plot(epochs[-1], average[-1], 'o', ms=4, color=colors[policy], clip_on=False)
                name = '无记忆' if policy == 'observation' else '记上一键'
                shift = -8 if policy == 'observation' else 29
                ax.annotate(f'{name}  {average[-1]:.2f}', (epochs[-1], average[-1]),
                            xytext=(0, shift), textcoords='offset points', ha='right',
                            va='top' if shift < 0 else 'bottom', color=colors[policy],
                            fontsize=fontsize,
                            arrowprops=({'arrowstyle': '-', 'color': colors[policy],
                                         'lw': .8, 'relpos': (1., 0.)}
                                        if policy == 'last_key' else None))
        ax.axhline(3, color='#56636b', ls=':', lw=1.3)
        ax.text(50 if narrow else 2390, 2.78 if narrow else 3.1,
                '最少 3 步' if narrow else '确定性最短路径 · 3 步',
                va='top' if narrow else 'bottom', ha='left' if narrow else 'right',
                color='#435259', fontsize=fontsize if narrow else 10)
        ax.set(xlim=(0, 2400), ylim=(1.55 if narrow else 2.6, 13.4))
        ax.set_xlabel('训练回合数', fontsize=fontsize)
        ax.set_ylabel('期望到达步数' if narrow else '冻结策略的期望到达步数', fontsize=fontsize)
        if narrow:
            ax.set_xticks([0, 1200, 2400])
            ax.set_yticks([3, 6, 9, 12])
            ax.tick_params(labelsize=fontsize)
        else:
            ax.legend(loc='center right', frameon=False)
        ax.grid(axis='y', alpha=.12)
        filename = 'learning-narrow.svg' if narrow else 'learning.svg'
        fig.savefig(out / filename, metadata={'Date': None})
        plt.close(fig)


def write_reader_data(rows, out):
    final = [r for r in rows if r['episodes'] == 2400]
    example = next(r for r in final if r['policy'] == 'last_key' and r['seed'] == 0)
    data = {'seed0': example, 'summary': {}}
    for policy in ('observation', 'last_key'):
        group = [r for r in final if r['policy'] == policy]
        data['summary'][policy] = {key: mean(r[key] for r in group) for key in
                                   ('steps', 'mean_steps', 'first_slip_steps')}
    (out/'reader.json').write_text(json.dumps(data, indent=2) + '\n')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, help='directory for training.csv, reader.json and learning.svg')
    parser.add_argument('--walk', type=float, nargs=2, metavar=('U', 'V'),
                        help='show one episode with the two specified right-key probabilities')
    parser.add_argument('--first-slip', action='store_true', help='block the first right move at step 1 of --walk')
    parser.add_argument('--seed', type=int, default=0, help='random seed for --walk')
    args = parser.parse_args()
    if args.walk is not None:
        walk(args.walk, args.first_slip, args.seed)
        parser.exit()
    if args.first_slip:
        parser.error('--first-slip requires --walk U V')
    rows = experiment()
    summarize(rows)
    if args.output:
        args.output.mkdir(parents=True, exist_ok=True)
        with (args.output/'training.csv').open('w', newline='') as stream:
            writer = csv.DictWriter(stream, rows[0].keys())
            writer.writeheader()
            writer.writerows(rows)
        write_reader_data(rows, args.output)
        write_figure(rows, args.output)
