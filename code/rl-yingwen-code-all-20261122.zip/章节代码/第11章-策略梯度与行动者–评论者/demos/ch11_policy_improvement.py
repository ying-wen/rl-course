"""Compare policy improvements on one probability simplex and check their propagation.

Run this file for the numerical checks. Use --figure PATH.pdf for the course figure.
"""
import argparse
from math import exp, isclose, log


Q = (0., 1., 2.)
OLD = (.55, .30, .15)
BUDGET = .06
TEMPERATURE = 1.


def expected(values, probabilities):
    return sum(v*p for v, p in zip(values, probabilities))


def entropy(probabilities):
    return -sum(p*log(p) for p in probabilities if p > 0)


def old_to_new_kl(candidate):
    return sum(p*log(p/q) for p, q in zip(OLD, candidate))


def constrained_policy():
    # KKT stationarity for max dot(p,Q) subject to KL(OLD || p) <= budget.
    def policy(c):
        weights = [p/(c-q) for p, q in zip(OLD, Q)]
        return [w/sum(weights) for w in weights]
    left, right = max(Q), max(Q)+1
    while old_to_new_kl(policy(right)) > BUDGET:
        right = max(Q) + 2*(right-max(Q))
    for _ in range(70):
        mid = (left+right)/2
        if old_to_new_kl(policy(mid)) > BUDGET:
            left = mid
        else:
            right = mid
    return policy(right)


def soft_policy():
    weights = [exp((q-max(Q))/TEMPERATURE) for q in Q]
    return [w/sum(weights) for w in weights]


def check():
    step, soft = constrained_policy(), soft_policy()
    assert isclose(old_to_new_kl(step), BUDGET, abs_tol=1e-13)
    assert expected(Q, OLD) < expected(Q, step) < max(Q)
    optimum = TEMPERATURE*log(sum(exp(q/TEMPERATURE) for q in Q))
    assert isclose(expected(Q, soft)+TEMPERATURE*entropy(soft), optimum)
    for i in range(1, 99):
        for j in range(1, 100-i):
            p = [i/100, j/100, (100-i-j)/100]
            if old_to_new_kl(p) <= BUDGET:
                assert expected(Q, p) <= expected(Q, step)+1e-12
    # A separate two-step MDP checks the chapter's final identity. At state 0,
    # stop pays 1; continuing pays 0 and reaches state 1. Last rewards: 1 or 3.
    gamma = .9
    old_continue, old_high = .4, .25
    new_continue, new_high = .65, .60
    def state_value(weights, probabilities, alpha):
        return expected(weights, probabilities) + alpha*entropy(probabilities)
    def probabilities(p):
        return (1-p, p)
    for alpha in (0., .5):
        old_v1 = state_value((1.,3.), probabilities(old_high), alpha)
        new_v1 = state_value((1.,3.), probabilities(new_high), alpha)
        q0 = (1., gamma*old_v1)
        old_v0 = state_value(q0, probabilities(old_continue), alpha)
        new_v0 = state_value((1., gamma*new_v1), probabilities(new_continue), alpha)
        gain0 = state_value(q0, probabilities(new_continue), alpha)-old_v0
        gain1 = new_v1-old_v1
        assert isclose(new_v0-old_v0, gain0+gamma*new_continue*gain1)
        print(f"alpha={alpha}: actual change {new_v0-old_v0:.6f}, "
              f"gain at first state {gain0:.6f}, later contribution {gamma*new_continue*gain1:.6f}")
    print("KL step:", step, "soft optimum:", soft)


def draw(path):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    import matplotlib.tri as tri
    import numpy as np
    from matplotlib.font_manager import FontProperties
    from plot_fonts import chinese_font
    font = chinese_font()
    def fp(size):
        return FontProperties(fname=font.get_file(), size=size)
    def xy(p):
        return p[1]+.5*p[2], .8660254*p[2]
    ink, teal, gold = '#183840', '#096b76', '#a27618'
    p = np.array([(i,j,64-i-j) for i in range(65) for j in range(65-i)])/64
    x, y = xy(p.T)
    mesh = tri.Triangulation(x,y)
    ordinary = p@Q
    H = -(p*np.log(np.maximum(p,1e-12))).sum(axis=1)
    kl = np.sum(OLD*np.log(OLD/np.maximum(p,1e-12)),axis=1)
    fig, axes = plt.subplots(1,2,figsize=(11.4,3.15))
    fig.subplots_adjust(left=.018,right=.982,top=.98,bottom=.14,wspace=.07)
    for ax, values, levels in zip(axes,(ordinary,ordinary+TEMPERATURE*H),
                                  ((.4,.7,1.,1.3,1.6),(1.2,1.6,1.9,2.1,2.26,2.36))):
        ax.set_aspect('equal'); ax.set_xlim(-.19,1.20);ax.set_ylim(-.10, .99);ax.axis('off')
        ax.tricontourf(mesh, values, levels=np.linspace(values.min()-1e-6,values.max()+1e-6,20),
                       cmap=matplotlib.colors.LinearSegmentedColormap.from_list('surface',['#ffffff','#e3f1ed','#b1d6d0']))
        ax.tricontour(mesh,values,levels=levels,colors='#7baca9',linewidths=.8)
        ax.plot([0,1,.5,0],[0,0,.8660254,0],lw=1.25,c=ink)
        for px,py,t,ha in ((-.015,-.052,'总选 $a_1$','right'),(1.02,-.052,'总选 $a_2$','left'),(.5,.905,'总选 $a_3$','center')):
            ax.text(px,py,t,fontproperties=fp(12),color=ink,ha=ha,va='center')
    a,b=axes
    a.tricontour(mesh,kl,levels=[BUDGET],colors=gold,linewidths=2.1)
    start,end=xy(OLD),xy(constrained_policy())
    a.scatter(*start,c=ink,s=28,zorder=4);a.scatter(*end,c=gold,marker='D',s=32,zorder=4)
    a.annotate('',xy=end,xytext=start,arrowprops=dict(arrowstyle='->',lw=1.5,color=ink))
    def label(ax,txt,pos,where,color):
        ax.annotate(txt,xy=pos,xytext=where,ha='center',va='center',fontproperties=fp(12),
                    color=color,arrowprops=dict(arrowstyle='-',lw=1.0,color=color,shrinkB=5))
    label(a,'旧策略',start,(-.01,.18),ink)
    label(a,'KL 预算内的最优步',end,(.91,.48),gold)
    b.scatter(*xy(soft_policy()),s=58,marker='*',color=teal,zorder=4)
    label(b,'奖励加熵的最大点',xy(soft_policy()),(.96,.64),teal)
    a.set_title('固定旧策略，限制本次更新',fontproperties=fp(14),color=ink,y=-.14)
    b.set_title('给熵赋予价值，改变目标',fontproperties=fp(14),color=ink,y=-.14)
    fig.savefig(path,transparent=False)
    plt.close(fig)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--figure')
    args = parser.parse_args()
    check()
    if args.figure:
        draw(args.figure)
