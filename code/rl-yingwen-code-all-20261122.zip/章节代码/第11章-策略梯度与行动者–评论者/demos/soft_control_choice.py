"""The two-action experiment in the maximum-entropy control section, using only the standard library."""
from math import exp, isclose, log


def entropy(probabilities):
    return -sum(p * log(p) for p in probabilities if p > 0.0)


def soft_optimum(action_values, temperature):
    """Solve max_u sum(u_a q_a) + alpha H(u) for a finite action set."""
    max_q = max(action_values)
    weights = [exp((q - max_q) / temperature) for q in action_values]
    partition = sum(weights)
    probabilities = [weight / partition for weight in weights]
    return probabilities, max_q + temperature * log(partition)


def main():
    for alpha in (0.25, 1, 4):
        policy, soft_value = soft_optimum([1.0, 3.0], alpha)
        reward = 1.0 + 2.0 * policy[1]
        print(f"alpha={alpha:4.2f}: P(right)={policy[1]:.6f}, E[R]={reward:.6f}, "
              f"H={entropy(policy):.6f}, V*={soft_value:.6f}")
        assert isclose(reward + alpha * entropy(policy), soft_value)

    policy, terminal_high = soft_optimum([1.0, 3.0], 1.0)
    _, terminal_tie = soft_optimum([1.0, 1.0], 1.0)
    predecessor = 0.9 * (0.5 * terminal_high + 0.5 * terminal_tie)
    print(f"Predecessor with two equally likely successors: Q*={predecessor:.6f}")

    # Right now pays either 1 or 5. True coin odds stay at one half.
    # O=1 has likelihood exp(r-5); the shift makes it at most 1.
    evidence_if_a0 = exp(-4)
    evidence_if_a1 = (exp(-4) + 1.0) / 2.0
    conditional_action = evidence_if_a1 / (evidence_if_a0 + evidence_if_a1)
    conditional_heads = 1.0 / (exp(-4) + 1.0)
    print(f"Conditioned trajectory: P(right|O=1)={conditional_action:.6f}, "
          f"P(heads|right,O=1)={conditional_heads:.6f}")
    print(f"Feasible controller: P(right)={policy[1]:.6f}, P(heads|right)=0.500000")


if __name__ == "__main__":
    main()
