"""Read each policy fitted to one old batch in the course's PPO position task.

Run from rl-course: python demos/ppo_epoch_audit.py
Same training and seeds as ppo_sac_v11_lab.py. The evaluator alone knows step().
It sums over all action paths by dynamic programming. Initial positions for this
evaluation are the 32 observed starts of each batch, held fixed across epochs.
"""
import argparse
import csv
from pathlib import Path
from tempfile import TemporaryDirectory

import numpy as np
import torch

from ppo_sac_v11_lab import GAMMA, H, evaluate, observation, step, train_ppo, tensor

DEST = Path(__file__).resolve().parents[1] / 'assets' / 'ppo-epochs'


class PositionTree:
    """Merge paths that have the same remaining time and position."""
    def __init__(self, starts):
        self.states, self.index, self.reward = [], [], []
        x, counts = np.unique(starts, return_counts=True)
        self.start_mass = counts / counts.sum()
        for t in range(H):
            self.states.append(tensor(observation(x, H-t)))
            successors, reward = step(x[:, None], np.arange(-1, 2)[None, :])
            x, index = np.unique(successors, return_inverse=True)
            self.index.append(index.reshape(reward.shape))
            self.reward.append(reward)
        self.final_size = len(x)

    def policies(self, model):
        with torch.no_grad():
            logits = model.actor(torch.cat(self.states)).double()
            pieces = logits.softmax(-1).split([len(s) for s in self.states])
            return [piece.numpy() for piece in pieces]

    def values(self, policies):
        next_value = np.zeros(self.final_size)
        advantages = [None]*H
        for t in reversed(range(H)):
            q = self.reward[t] + GAMMA * next_value[self.index[t]]
            value = (policies[t]*q).sum(axis=1)
            advantages[t] = q - value[:, None]
            next_value = value
        return self.start_mass @ next_value, advantages

    def occupancy(self, policies):
        mass, visits = self.start_mass, []
        for t in range(H):
            visits.append(mass)
            joint = mass[:, None] * policies[t]
            mass = np.bincount(self.index[t].ravel(), weights=joint.ravel())
            assert np.isclose(mass.sum(), 1)
        return visits


def observer(seed, records, selected):
    def begin(it, model, starts, states, actions, old_probs, old_logp, advantages, weights):
        if it not in selected:
            return None
        n = len(states) // H
        # Use the original float64 starts from the simulator, before converting
        # observations to float32 network inputs.
        tree = PositionTree(starts)
        old = tree.policies(model)
        base_value, true_adv = tree.values(old)
        visits = tree.occupancy(old)

        @torch.no_grad()
        def record(epoch, current, updated):
            pi = tree.policies(current)
            value, _ = tree.values(pi)
            surrogate = clipped = 0.
            for t, (p, base, adv, mu) in enumerate(zip(pi, old, true_adv, visits)):
                old_joint = mu[:, None] * base
                ratio = p / base
                surrogate += GAMMA**t * np.sum(old_joint * ratio * adv)
                clipped += GAMMA**t * np.sum(old_joint * np.minimum(
                    ratio*adv, np.clip(ratio, .8, 1.2)*adv))
            dist = current.dist(states)
            ratio = (dist.log_prob(actions)-old_logp).exp()
            terms = torch.minimum(ratio*advantages, ratio.clamp(.8,1.2)*advantages)
            # Subtract the objective at the old policy. A sampled GAE batch can
            # have nonzero mean advantage even when ratios are all one.
            batch = float((weights*(terms-advantages)).sum() / n)
            kl = float((old_probs*(old_probs.log()-dist.logits)).sum(-1).mean())
            outside = float(((ratio<.8)|(ratio>1.2)).float().mean())
            records.append(dict(seed=seed,batch=it,epoch=epoch,actor_updated=int(updated),
                                real_steps=it*n*H,old_return=base_value,return_gain=value-base_value,
                                old_visit_gain=surrogate,old_visit_clipped_gain=clipped,
                                batch_clipped_gain=batch,kl_uniform_observed_steps=kl,ratio_outside=outside))
            assert clipped < surrogate + 1e-9
            if epoch == 0:
                assert max(abs(x) for x in (value-base_value, surrogate, clipped, batch, kl, outside)) < 1e-6
        return record
    return begin


def run(out):
    records = []
    out.mkdir(parents=True, exist_ok=True)
    for seed in range(3):
        audit = observer(seed, records, {1,25,100})
        with TemporaryDirectory() as tmp:
            curves, trained = train_ppo(seed, 100, Path(tmp), audit=audit)
            if seed == 0:
                paths = evaluate(trained, 'ppo', seed=9201, starts=np.array([-.9,.9]), repeats=1)['x']
        np.save(out / f'ppo-seed-{seed}-curve.npy', curves)
    with (out/'epochs.csv').open('w', newline='') as f:
        w=csv.DictWriter(f,fieldnames=records[0],lineterminator='\n')
        w.writeheader(); w.writerows(records)
    feedback = evaluate(None, 'feedback_discrete')['return'].mean()
    draw(out, records, paths, feedback)
    return records


def draw(out, records, final_paths, feedback_score):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from matplotlib import font_manager
    for candidate in ('/System/Library/Fonts/STHeiti Light.ttc',
                      '/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc'):
        if Path(candidate).exists():
            font_manager.fontManager.addfont(candidate)
            plt.rcParams['font.family'] = font_manager.FontProperties(fname=candidate).get_name()
            break
    plt.rcParams.update({'pdf.fonttype':42, 'font.size':10.5,
                         'axes.spines.top':False, 'axes.spines.right':False,
                         'axes.labelcolor':'#273b42', 'axes.titlecolor':'#182e38'})
    teal, red, grey = '#096b76', '#a44333', '#4d5f67'
    fig, axes = plt.subplots(1, 3, figsize=(12.6,3.3), layout='constrained')
    left, mid, right = axes
    selected = [r for r in records if r['seed']==2 and r['batch']==1]
    times = [r['epoch'] for r in selected]
    left.axhline(0, color='#99a5a8', linewidth=.8)
    left.axvspan(5,8, color='#edf0f0', zorder=0)
    left.plot(times, [r['batch_clipped_gain'] for r in selected], color=teal,
              marker='s', markersize=3, label='旧批裁剪代理')
    left.plot(times, [r['return_gain'] for r in selected], color=red,
              marker='o', markersize=3, label='策略期望回报')
    left.set(title='同一批经验内的更新',xlabel='复用轮数',ylabel='相对第 0 轮的增量',
             xticks=[0,2,5,8],ylim=(-.23,1.2))
    left.text(6.49,.46,'停止\n策略更新',color=grey,ha='center',va='center',fontsize=10)
    left.legend(frameon=False,loc='upper left', fontsize=9)
    curves=np.array([np.load(out/f'ppo-seed-{seed}-curve.npy') for seed in range(3)])
    for k in curves:
        mid.plot(k[:,0]/1000, k[:,1],color='#82abae',linewidth=.9)
    mid.plot(curves[0,:,0]/1000,curves[:,:,1].mean(0),color=teal,linewidth=2,label='PPO，三种子均值')
    mid.axhline(feedback_score,color=red,linestyle='--',linewidth=1.1,label='位置反馈规则')
    mid.set(title='跨批采样后的控制表现',xlabel='累计环境步数（千）',
            ylabel='冻结策略的评估回报',xticks=[0,10,20,30,38.4])
    mid.legend(frameon=False,loc='lower right',fontsize=9)
    for j,(col,mark) in enumerate([(red,'s'),(teal,'o')]):
        right.plot(range(H+1),final_paths[:,j],color=col,marker=mark,markersize=3,
                   label=f'起点 {final_paths[0,j]:+.1f}')
    right.axhline(0,color='#99a5a8',linewidth=.8)
    right.set(title='训练后的两条轨迹',xlabel='环境步',ylabel='位置',xticks=[0,4,8,12],ylim=(-1.13,1.13))
    right.legend(frameon=False,loc='upper right',fontsize=9)
    for ext in ('pdf','png'):
        fig.savefig(out/('ppo-update.'+ext),dpi=170,metadata=({'CreationDate':None,'ModDate':None} if ext=='pdf' else None))
    # On narrow screens each graph is shown at column width with its own axes.
    fig.canvas.draw()
    for axis, name in zip(axes, ('epoch', 'training', 'positions')):
        extent = axis.get_tightbbox(fig.canvas.get_renderer()).transformed(fig.dpi_scale_trans.inverted())
        fig.savefig(out/f'{name}.png', dpi=170, bbox_inches=extent.padded(.065))
    plt.close(fig)


if __name__ == '__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out',type=Path,default=DEST)
    args=parser.parse_args()
    print('saved',len(run(args.out)),'epoch records to',args.out)
