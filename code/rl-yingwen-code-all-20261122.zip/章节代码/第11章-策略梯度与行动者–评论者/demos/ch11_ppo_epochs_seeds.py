"""三个种子首批的同批多轮复用：旧批裁剪代理与真实期望回报的增量。

只读 assets/ppo-epochs/epochs.csv（由 demos/ppo_epoch_audit.py 生成），
输出 assets/ppo-epochs/epoch-seeds.pdf。11-21 审阅站请求 r1121-114237。
"""
import csv
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter
from plot_fonts import use_course_fonts, no_leading_zero, CJK_FAMILY

ROOT = Path(__file__).resolve().parents[1]
CSV = ROOT / 'assets/ppo-epochs/epochs.csv'
OUT = ROOT / 'assets/ppo-epochs/epoch-seeds.pdf'


def main():
    use_course_fonts()
    rows = [r for r in csv.DictReader(open(CSV)) if r['batch'] == '1']
    teal, red = '#0F6E73', '#B03A2E'
    fig, ax = plt.subplots(figsize=(4.2, 2.9))
    styles = {'0': '-', '1': '--', '2': ':'}
    for seed in '012':
        rs = sorted((r for r in rows if r['seed'] == seed), key=lambda r: int(r['epoch']))
        e = [int(r['epoch']) for r in rs]
        sur = [float(r['batch_clipped_gain']) for r in rs]
        ret = [float(r['return_gain']) for r in rs]
        ax.plot(e, sur, styles[seed], color=teal, marker='s', ms=3, lw=1.3)
        ax.plot(e, ret, styles[seed], color=red, marker='o', ms=3, lw=1.3)
        stop = [int(r['epoch']) for r in rs if r['actor_updated'] == '0' and r['epoch'] != '0']
        if stop:
            ax.axvspan(min(stop) - 1, 8, color='#E8ECEC', zorder=0)
    ax.axhline(0, color='#888', lw=.6)
    ax.text(.25, 1.50, '青：旧批裁剪代理', color=teal, fontsize=9)
    ax.text(.25, 1.33, '红：真实期望回报', color=red, fontsize=9)
    ax.text(5.15, -.30, '种子 2：KL 超过 .03，\n停止策略更新', fontsize=8, color='#555')
    ax.annotate('种子 2 回报 −.098', xy=(5, -.098), xytext=(1.6, -.42), fontsize=8,
                color=red, arrowprops=dict(arrowstyle='->', color=red, lw=.7))
    ax.set_xlim(0, 8); ax.set_ylim(-.5, 1.7)
    ax.set_xlabel('复用轮数', fontsize=9)
    ax.set_ylabel('相对第 0 轮的增量', fontsize=9, fontfamily=CJK_FAMILY)
    ax.yaxis.set_major_formatter(FuncFormatter(no_leading_zero))
    ax.tick_params(labelsize=8)
    for sp in ('top', 'right'):
        ax.spines[sp].set_visible(False)
    ax.text(8, 1.66, '实线 种子 0　虚线 种子 1　点线 种子 2', fontsize=7.5, ha='right', color='#555')
    fig.tight_layout(pad=.3)
    fig.savefig(OUT, metadata={'CreationDate': None, 'ModDate': None})


if __name__ == '__main__':
    main()
