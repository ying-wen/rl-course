"""Analytic continuous-action examples for chapter 11.

Run with no arguments to check the slopes and TD3 target examples.
With --figures DIRECTORY also write the figures used in the lecture.
"""
import argparse
import math
from pathlib import Path

import numpy as np


def value(action):
    return -np.square(action)


def critics(action):
    # Both fitted critics have a uniform value error at most .01 on [-1, 1].
    return (value(action) + .01*np.sin(100*action),
            value(action) + .01*np.cos(100*action))


def target_average(actions):
    """Expected clipped-double-Q target value under clipped Gaussian noise.

    Midpoint quadrature for the continuous normal density; assign the two
    clipped tails their exact masses. The action itself is also bounded.
    """
    sigma, cap = .018, .04
    points = np.linspace(-cap, cap, 501)
    mid = (points[1:] + points[:-1])/2
    mass = np.diff([.5*math.erfc(-z/(math.sqrt(2)*sigma)) for z in points])
    tail = .5*math.erfc(cap/(math.sqrt(2)*sigma))
    offsets = np.r_[-cap, mid, cap]
    weights = np.r_[tail, mass, tail]
    sampled = np.clip(np.asarray(actions)[..., None] + offsets, -1., 1.)
    return np.minimum(*critics(sampled)) @ weights


def check():
    action, eps = -.4, 1e-5
    slope = (value(action + eps) - value(action - eps))/(2*eps)
    assert abs(slope - .8) < 1e-9
    assert np.isclose(value(action + .1*slope), -.1024)
    wrong = (critics(eps)[0] - critics(-eps)[0])/(2*eps)
    assert abs(wrong-1) < 1e-6
    center = np.pi/200
    first, second = critics(center)
    assert np.isclose(first-second,.01)
    avg = float(target_average(center))
    print(f"one-step action {action:.2f} -> {action+.1*slope:.2f}; true value -.1600 -> -.1024")
    print(f"at a=0: true slope 0; fitted slope {wrong:.6f}")
    print(f"at b=pi/200: Q1={first:.6f}, Q2={second:.6f}, E[min at noisy b]={avg:.6f}")


def figures(folder):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.font_manager import FontProperties
    from plot_fonts import chinese_font

    folder.mkdir(parents=True, exist_ok=True)
    font = chinese_font()
    ink, teal, red, gold, grey = "#182e38", "#096b76", "#aa412d", "#a27618", "#50686c"

    def label(size):
        return FontProperties(fname=font.get_file(), size=size)

    def axis(axes):
        axes.spines[["right", "top"]].set_visible(False)
        axes.spines[["bottom", "left"]].set_color("#9caaa9")
        axes.tick_params(labelsize=9, colors=grey, length=3)
        axes.set_xlabel("动作", fontproperties=label(11))

    fig, ax = plt.subplots(figsize=(6.1, 3.0), layout="constrained")
    a = np.linspace(-.9,.65,450)
    ax.plot(a, value(a), color=teal, lw=2.5)
    xx=np.linspace(-.64,-.18,30)
    ax.plot(xx,-.16+.8*(xx+.4),color=red,lw=1.65)
    ax.scatter([-.4,-.32],value(np.array([-.4,-.32])),c=[red,teal],s=30,zorder=4)
    ax.annotate("当前动作",(-.4,-.16),(-.77,-.08),fontproperties=label(12),color=red,
                arrowprops=dict(arrowstyle="->",color=red))
    ax.annotate("更新后的动作",(-.32,-.1024),(.03,-.31),fontproperties=label(12),color=teal,
                arrowprops=dict(arrowstyle="->",color=teal))
    ax.annotate("切线斜率  +0.8",(-.57,-.296),(-.67,-.52),fontproperties=label(12),color=red,
                arrowprops=dict(arrowstyle="->",color=red))
    ax.set_xlim(-.91,.65);ax.set_ylim(-.63,.065);ax.set_ylabel("动作价值",fontproperties=label(11))
    axis(ax);fig.savefig(folder/"dpg-step.pdf");plt.close(fig)

    a=np.linspace(-.097,.097,650)
    first, second=critics(a); lower=np.minimum(first,second)
    center=np.pi/200
    fig, (ax,bx)=plt.subplots(1,2,figsize=(10.8,3.24),sharey=True,layout="constrained")
    ax.plot(a,first,c=red,lw=1.55,label=r"$Q_1$")
    ax.plot(a,second,c=gold,lw=1.55,ls="--",label=r"$Q_2$")
    ax.plot(a,lower,c=teal,lw=2.3,label="两者较小值")
    ax.axvline(center,c=grey,ls=":",lw=.9)
    ys=critics(center)
    ax.scatter([center,center],ys,c=[red,teal],s=22,zorder=4)
    ax.legend(prop=label(10),frameon=False,ncol=3,loc="upper center")
    ax.set_title("同一后继动作，各读一次估值",fontproperties=label(14))
    bx.plot(a,lower,c=grey,ls="--",lw=1.4,label="无目标噪声")
    bx.plot(a,target_average(a),c=teal,lw=2.4,label="对目标噪声取平均")
    bx.axvspan(center-.04,center+.04,ymin=0,ymax=.08,color="#e4d7b3")
    bx.scatter([center],[target_average(center)],c=teal,s=24,zorder=4)
    bx.legend(prop=label(10),frameon=False,ncol=2,loc="upper center")
    bx.set_title("同一对估值，改查邻近动作",fontproperties=label(14))
    for pane in (ax,bx):
        axis(pane);pane.set_xticks([-.08,0,.08]);pane.set_ylim(-.022,.0175)
    ax.set_ylabel("后继动作估值",fontproperties=label(11))
    fig.savefig(folder/"td3-target.pdf");plt.close(fig)


if __name__ == "__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--figures",type=Path)
    args=parser.parse_args()
    check()
    if args.figures:
        figures(args.figures)
