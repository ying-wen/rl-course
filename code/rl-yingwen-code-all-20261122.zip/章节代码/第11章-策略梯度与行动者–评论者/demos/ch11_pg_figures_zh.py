"""Chinese-label figures for Sections 11.2-11.3 (two-step tree, gamma=.9).

11-21 审阅站请求 r1121-114237：把 11.2、11.3 的英文图换成中文标签、课程字体版。
Run: python ch11_pg_figures_zh.py
No retraining: behavior-zh redraws the 12 saved runs in assets/sample14-pg/seed-*.npy
(columns: episodes, J, p, q). The other figures are exact computations.
Outputs (new files; the English originals are left untouched):
  assets/sample14-pg/behavior-zh.pdf
  assets/sample14-pg/baseline-optimum-main.pdf
  assets/sample14-pg/critic-error-zh.pdf
  assets/deep-v13/shared-encoder-zh.pdf
"""
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter

from plot_fonts import use_course_fonts, CJK_FAMILY, no_leading_zero
from sample14_pg import GAMMA, INITIAL, exact_gradient

ROOT = Path(__file__).resolve().parents[1]
PG = ROOT/'assets/sample14-pg'
DEEP = ROOT/'assets/deep-v13'
TEAL, RED, GOLD, MUTED, INK = '#096B76', '#AA412D', '#A27618', '#52666E', '#182E38'
FMT = FuncFormatter(no_leading_zero)


def style(fs):
    plt.rcParams.update({'font.size': fs, 'axes.spines.top': False,
                         'axes.spines.right': False, 'axes.unicode_minus': False})


def save(fig, path):
    fig.savefig(path.with_suffix('.pdf'))
    fig.savefig(path.with_suffix('.png'), dpi=180)
    plt.close(fig)


def behavior():
    """Slide: width .98\\textwidth, height 3.8cm -> scale ~.6; ticks 12pt, labels 13.5pt."""
    style(12)
    stack = np.stack([np.load(PG/f'seed-{k}.npy') for k in range(12)])
    steps = stack[0, :, 0]
    fig, axs = plt.subplots(1, 2, figsize=(7.2, 2.5), layout='constrained')
    for j, name, c in [(2, '$s_0$ 选继续', TEAL), (3, '$s_1$ 取 3', RED)]:
        axs[0].plot(steps, stack[:, :, j].mean(0), label=name, lw=2.2, color=c)
    axs[0].set_xlabel('采样回合数', fontsize=13.5)
    axs[0].set_ylabel('动作概率', fontsize=13.5)
    axs[0].set_ylim(0, 1.05)
    axs[0].legend(frameon=False, prop={'family': CJK_FAMILY, 'size': 12})
    names = ['停止', '继续后取 1', '继续后取 3']
    pos = np.arange(3)
    for dx, k, c, label in [(-.21, 0, MUTED, '初始'), (.21, -1, TEAL, '学习后')]:
        p, q = stack[:, k, 2], stack[:, k, 3]
        prob = np.array([1-p, p*(1-q), p*q]).mean(1)
        axs[1].bar(pos+dx, prob, width=.38, color=c, label=label)
    axs[1].set_xticks(pos, names)
    axs[1].set_ylim(0, 1.05)
    axs[1].set_ylabel('轨迹概率', fontsize=13.5)
    axs[1].legend(frameon=False, fontsize=12)
    for ax in axs:
        ax.yaxis.set_major_formatter(FMT)
    save(fig, PG/'behavior-zh')


def baseline_optimum():
    """Main example at s1: q=.25, score .75 (take 3) / -.25 (take 1), returns 3 / 1.
    Var[g(G-beta) | s1] = .1875 (beta-2.5)^2. Slide height ~3cm -> scale ~.6."""
    style(12)
    q = .25
    beta = np.linspace(0, 4, 401)
    second = q*.75**2*(3-beta)**2 + (1-q)*.25**2*(1-beta)**2
    mean = q*.75*(3-beta) + (1-q)*(-.25)*(1-beta)
    var = second - mean**2
    assert np.allclose(mean, .375)
    assert np.allclose(var, .1875*(beta-2.5)**2)
    fig, ax = plt.subplots(figsize=(5.4, 2.1), layout='constrained')
    ax.plot(beta, var, color=TEAL, lw=2.2)
    ax.axvline(1.5, color=GOLD, ls='--', lw=1.4)
    ax.axvline(2.5, color=RED, ls='-', lw=1.4)
    ax.scatter([0, 1.5, 2.5], [1.171875, .1875, 0], color=[MUTED, GOLD, RED], s=26, zorder=4)
    ax.text(1.42, .95, '状态价值\n$v_\\pi(s_1)=1.5$', color=GOLD, ha='right', va='top',
            fontsize=12, fontfamily=CJK_FAMILY)
    ax.text(2.6, .95, '最小方差基线\n$\\beta^*=2.5$', color=RED, ha='left', va='top',
            fontsize=12, fontfamily=CJK_FAMILY)
    ax.set_xlabel('基线 $\\beta$', fontsize=13.5, fontfamily=CJK_FAMILY)
    ax.set_ylabel('条件方差', fontsize=13.5)
    ax.set_xlim(0, 4)
    ax.set_ylim(0, 1.25)
    ax.set_yticks([0, .1875, .5, 1, 1.171875], ['0', '.1875', '.5', '1', '1.172'])
    ax.xaxis.set_major_formatter(FMT)
    save(fig, PG/'baseline-optimum-main')


def critic_error():
    """Slide: width .88\\textwidth, height 3.05cm -> scale ~.55; ticks 13pt, labels 14.5pt."""
    style(13)
    value = np.linspace(0, 2.6, 201)
    direction = .25*(GAMMA*value-1)
    fig, ax = plt.subplots(figsize=(6.0, 2.2), layout='constrained')
    ax.plot(value, direction, color=TEAL, lw=2.4, label='一步行动者–评论者的平均方向')
    ax.axhline(exact_gradient(INITIAL)[0], color=RED, ls='--', lw=1.4,
               label='真实策略梯度 $\\partial J/\\partial\\theta_0$')
    ax.axhline(0, color=MUTED, lw=.8)
    ax.axvline(1.5, color=MUTED, ls=':', lw=1.2)
    ax.scatter([0, .5, 1.5], [-.25, -.1375, .0875], color=[RED, RED, TEAL], s=28, zorder=4)
    ax.set_xlabel('评论者对后继状态的预测 $V_{\\mathbf{w}}(s_1)$', fontsize=14.5, fontfamily=CJK_FAMILY)
    ax.set_ylabel('$\\theta_0$ 的平均方向', fontsize=14.5, fontfamily=CJK_FAMILY)
    ax.xaxis.set_major_formatter(FMT)
    ax.yaxis.set_major_formatter(FMT)
    ax.legend(frameon=False, loc='upper left', prop={'family': CJK_FAMILY, 'size': 12.5})
    save(fig, PG/'critic-error-zh')


def shared_encoder():
    """Same numbers as deep_v13_connections.shared_actor_critic: psi=0, alpha=.1, c_V=1.
    Slide: half width, height 3cm -> scale ~.6; ticks 12pt, labels 13.5pt."""
    style(12)
    sig = lambda z: 1/(1+np.exp(-z))
    g_actor, g_critic = -.5, 1.
    actor_only = sig(0-.1*g_actor)
    joint = sig(0-.1*(g_actor+g_critic))
    assert np.isclose(actor_only, .5124973964842103) and np.isclose(joint, .4875026035157896)
    fig, ax = plt.subplots(figsize=(4.4, 2.0), layout='constrained')
    ax.barh(['只更新行动者', '行动者与评论者'], [actor_only, joint], color=[TEAL, RED], height=.55)
    ax.axvline(.5, color=INK, ls='--', lw=1.2)
    for y, v in [(0, actor_only), (1, joint)]:
        ax.text(v+.001, y, f'{v:.4f}'[1:], va='center', ha='left', fontsize=12, color=INK)
    ax.set_xlim(.47, .53)
    ax.set_xticks([.47, .48, .49, .5, .51, .52, .53])
    ax.xaxis.set_major_formatter(FMT)
    ax.set_xlabel('一次更新后被采动作的概率', fontsize=13.5)
    save(fig, DEEP/'shared-encoder-zh')


if __name__ == '__main__':
    ok = use_course_fonts()
    print('course fonts found:', ok)
    behavior()
    baseline_optimum()
    critic_error()
    shared_encoder()
    print('written to', PG, 'and', DEEP)
