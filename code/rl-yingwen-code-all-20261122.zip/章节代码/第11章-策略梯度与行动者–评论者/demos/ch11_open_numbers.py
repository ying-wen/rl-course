# -*- coding: utf-8 -*-
"""Numbers for the chapter 11 pages added in the 2026-11 revision.

Run with no arguments; every printed number appears on a slide or in its notes.
Sections:
  1. one improvement operator on q = (0, 1, 2)
  2. maximising over a continuous action
  3. deterministic policy gradient as the sigma -> 0 limit
  4. exploration noise and soft target updates
  5. an actor that chases a rippled critic
  6. keeping the policy random lets underestimated actions be corrected
"""
import numpy as np

RNG = np.random.default_rng(20261118)


# ---------------------------------------------------------------- 1
def operator(q, old, eta, kappa):
    """argmax_nu  nu.q + kappa H(nu) - KL(nu||old)/eta  (eta may be inf)."""
    q, old = np.asarray(q, float), np.asarray(old, float)
    if np.isinf(eta):
        if kappa == 0:
            nu = (q == q.max()).astype(float)
            return nu / nu.sum()
        logits = q / kappa
    else:
        logits = (np.log(old) + eta * q) / (1 + eta * kappa)
    logits -= logits.max()
    nu = np.exp(logits)
    return nu / nu.sum()


def kl(p, r):
    p, r = np.asarray(p), np.asarray(r)
    m = p > 0
    return float(np.sum(p[m] * np.log(p[m] / r[m])))


def entropy(p):
    p = np.asarray(p)
    m = p > 0
    return float(-np.sum(p[m] * np.log(p[m])))


def section_operator():
    print("== 1 operator, q=(0,1,2), old uniform")
    q, old = (0., 1., 2.), np.ones(3) / 3
    rows = [("small step", 1 / 3, 0.), ("KL step", 1., 0.), ("greedy", np.inf, 0.),
            ("KL+entropy", 1., .5), ("soft greedy", np.inf, .5), ("soft greedy k=2", np.inf, 2.)]
    for name, eta, kappa in rows:
        nu = operator(q, old, eta, kappa)
        print(f"{name:16s} eta={eta:<6.3g} kappa={kappa:<4} nu={np.round(nu,3)} "
              f"E[q]={nu@q:.3f} KL={kl(nu,old):.3f} H={entropy(nu):.3f}")
    # simplex coordinates: a1=(0,0), a2=(1,0), a3=(.5,.866)
    V = np.array([[0, 0], [1, 0], [.5, np.sqrt(3) / 2]])
    for kappa in (0., .5, 2.):
        etas = np.concatenate([np.geomspace(.01, 100, 25), [np.inf]])
        pts = [operator(q, old, e, kappa) @ V for e in etas]
        coords = " ".join(f"({x:.3f},{y:.3f})" for x, y in pts)
        marks = {e: operator(q, old, e, kappa) @ V for e in (1 / 3, 1., np.inf)}
        print(f"path kappa={kappa}: {coords}")
        print("  marks", {round(float(k), 3): np.round(v, 3).tolist() for k, v in marks.items()})


# ---------------------------------------------------------------- 2
def two_peaks(a):
    return 1.00 * np.exp(-((a - .25) / .08) ** 2) + 1.01 * np.exp(-((a - .75) / .08) ** 2)


def section_max():
    print("== 2 continuous max")
    joints, levels, batch = 7, 10, 256
    per_state = levels ** joints
    print(f"grid: {levels}^{joints} = {per_state:.0e} per state; batch {batch} -> {per_state*batch:.2e}")
    # local ascent on the two-peak critic from a = .40
    a, lr = .40, .002
    for _ in range(3000):
        g = (two_peaks(a + 1e-5) - two_peaks(a - 1e-5)) / 2e-5
        a += lr * g
    grid = np.linspace(0, 1, 100001)
    best = grid[np.argmax(two_peaks(grid))]
    print(f"ascent from .40 stops at a={a:.3f}, Q={two_peaks(a):.3f}; global a={best:.3f}, Q={two_peaks(best):.3f}")
    # K random candidates, critic = truth + independent noise of sd .1 at each candidate
    def truth(x):
        return 1 - (x - .6) ** 2
    sd, runs = .1, 200000
    print("K candidates, critic noise sd .1: bias of max Qhat over truth at chosen action, true loss")
    for K in (1, 4, 16, 64):
        x = RNG.uniform(0, 1, (runs, K))
        qhat = truth(x) + sd * RNG.standard_normal((runs, K))
        i = np.argmax(qhat, axis=1)
        chosen = x[np.arange(runs), i]
        bias = qhat[np.arange(runs), i] - truth(chosen)
        print(f"  K={K:3d}: bias {bias.mean():.3f}  true value {truth(chosen).mean():.3f}")


# ---------------------------------------------------------------- 3
def section_dpg():
    print("== 3 DPG limit, q(a)=1-(a-.6)^2, theta=.2")
    q = lambda a: 1 - (a - .6) ** 2
    theta, alpha = .2, .25
    slope = -2 * (theta - .6)
    print(f"q(theta)={q(theta):.2f}, slope={slope:.2f}, step alpha={alpha} -> theta={theta+alpha*slope:.2f}, "
          f"q={q(theta+alpha*slope):.2f}")
    n = 2_000_000
    eps = RNG.standard_normal(n)
    for sigma in (.5, .3, .1):
        a = theta + sigma * eps
        g = q(a) * eps / sigma
        gb = (q(a) - q(theta)) * eps / sigma
        # exact variances from Gaussian moments
        # g = c0 eps/s + .8 eps^2 - s eps^3, c0 = .84
        print(f"  sigma={sigma}: mean {g.mean():.3f}  var {g.var():.2f}  "
              f"with baseline q(theta): mean {gb.mean():.3f} var {gb.var():.2f}")
    print("  deterministic: slope read from critic, variance 0 (exact critic)")


# ---------------------------------------------------------------- 4
def section_noise():
    print("== 4 OU vs Gaussian, soft update")
    th, sig, dt, T = .15, .2, 1e-2, 400
    x = np.zeros(T)
    for t in range(1, T):
        x[t] = x[t - 1] + th * (0 - x[t - 1]) * dt + sig * np.sqrt(dt) * RNG.standard_normal()
    gauss = .1 * RNG.standard_normal(T)
    ac = lambda z: np.corrcoef(z[:-1], z[1:])[0, 1]
    print(f"OU(theta=.15, sigma=.2, dt=.01): lag-1 corr {ac(x):.3f}, range [{x.min():.3f},{x.max():.3f}]")
    print(f"Gaussian sd .1: lag-1 corr {ac(gauss):.3f}")
    print("OU stationary sd =", round(sig / np.sqrt(2 * th / 1) * np.sqrt(1), 3), "(in units with dt folded in:",
          round(sig * np.sqrt(dt) / np.sqrt(1 - (1 - th * dt) ** 2), 3), ")")
    for tau in (.001, .005):
        print(f"tau={tau}: half-life {np.log(2)/-np.log(1-tau):.0f} steps, 95% after "
              f"{np.log(.05)/np.log(1-tau):.0f} steps")
    # emit a short sparkline sample for the figure: 80 points, every 5th step
    print("OU sample", " ".join(f"{v:.3f}" for v in x[::5][:80]))
    print("Gauss sample", " ".join(f"{v:.3f}" for v in gauss[:80]))


# ---------------------------------------------------------------- 5
def section_ripple():
    print("== 5 actor chasing a rippled critic, truth q(a)=1-(a-.6)^2 on [0,1]")
    truth = lambda a: 1 - (a - .6) ** 2
    amp, freq, runs = .05, 40., 4000
    grid = np.linspace(0, 1, 4001)
    out = {"one critic": [], "min of two": [], "smoothed target": []}
    loss = []
    for _ in range(runs):
        p1, p2 = RNG.uniform(0, 2 * np.pi, 2)
        e1 = amp * np.sin(freq * grid + p1)
        e2 = amp * np.sin(freq * grid + p2)
        q1 = truth(grid) + e1
        i = np.argmax(q1)                       # the actor maximises critic 1
        out["one critic"].append(e1[i])
        out["min of two"].append(min(e1[i], e2[i]))
        # target smoothing: average critic-1 error over a +- N(0,.05) clipped at .1
        d = np.clip(.05 * RNG.standard_normal(64), -.1, .1)
        j = np.clip(np.searchsorted(grid, grid[i] + d), 0, grid.size - 1)
        out["smoothed target"].append(e1[j].mean())
        loss.append(truth(.6) - truth(grid[i]))
    for k, v in out.items():
        print(f"  {k:16s} mean error at actor's action {np.mean(v):+.4f}")
    print(f"  true value lost by following critic 1: {np.mean(loss):.4f} (max {np.max(loss):.4f})")
    print(f"  ripple amplitude {amp}, ripple slope up to {amp*freq:.1f}; true slope at a=.6 is 0")


# ---------------------------------------------------------------- 6
def section_keep_random():
    print("== 6 underestimated action, two arms true (1.0, 1.2), start Qhat=(1.0, 0.7)")
    true = np.array([1.0, 1.2])
    sd_r, steps, runs, lr = .5, 500, 4000, .1
    for kappa in (0., .05, .1, .2):
        best_final, total = 0, 0.
        for _ in range(runs):
            Q = np.array([1.0, .7])
            ret = 0.
            for _t in range(steps):
                if kappa == 0:
                    a = int(np.argmax(Q))
                else:
                    p = np.exp((Q - Q.max()) / kappa); p /= p.sum()
                    a = int(RNG.random() < p[1])
                r = true[a] + sd_r * RNG.standard_normal()
                Q[a] += lr * (r - Q[a])
                ret += true[a]
            best_final += Q[1] > Q[0]
            total += ret / steps
        print(f"  kappa={kappa}: P(estimate ranks arm 2 first after {steps}) {best_final/runs:.3f}, "
              f"mean true reward per step {total/runs:.3f}")


if __name__ == "__main__":
    section_operator()
    section_max()
    section_dpg()
    section_noise()
    section_ripple()
    section_keep_random()
