"""Two finite policy updates for the chapter's two-step MDP (Python standard library)."""
from math import exp, log, sqrt, isclose

GAMMA = 0.9
OLD_P, OLD_Q = 0.5, 0.25


def sigmoid(z):
    return 1 / (1 + exp(-z))


def bernoulli_kl(old, new):
    return old * log(old / new) + (1 - old) * log((1 - old) / (1 - new))


def performance(p, q):
    # Stop for 1 at the root, or continue to a choice paying 1 or 3.
    return (1 - p) + GAMMA * p * (1 + 2 * q)


def surrogate(p, q):
    return 0.35 * (p - OLD_P) + 0.9 * (q - OLD_Q)


def check_trust_region():
    gradient = (0.0875, 0.16875)
    occupancy = (1 - GAMMA, (1 - GAMMA) * GAMMA * OLD_P)
    fisher = tuple(w * b * (1 - b) for w, b in zip(occupancy, (OLD_P, OLD_Q)))
    direction = tuple(g / f for g, f in zip(gradient, fisher))
    scale = sqrt(2 * 0.01 / sum(g*x for g, x in zip(gradient, direction)))
    full = tuple(scale * x for x in direction)
    for fraction in (1, 0.5):
        p, q = (sigmoid(log(b/(1-b)) + fraction * d)
                for b, d in zip((OLD_P, OLD_Q), full))
        kl = sum(w * bernoulli_kl(b, new)
                 for w, b, new in zip(occupancy, (OLD_P, OLD_Q), (p,q)))
        predicted = surrogate(p, q)
        actual = performance(p, q) - performance(OLD_P, OLD_Q)
        assert isclose(actual-predicted, 1.8*(p-OLD_P)*(q-OLD_Q))
        assert (kl <= 0.01 and predicted > 0) == (fraction == 0.5)
        print(f'TRPO step {fraction:g}: KL={kl:.7f}, surrogate={predicted:.7f}, return change={actual:.7f}')


def ppo_contributions(z):
    # Eight complete episodes. Four continue, one of those picks the high reward.
    q = sigmoid(z)
    high, low = q / OLD_Q, (1 - q) / (1 - OLD_Q)
    high_gain = GAMMA / 8 * 1.5 * min(high, 1.2)
    low_gain = GAMMA * 3 / 8 * (-0.5) * max(low, 0.8)
    dq = q * (1 - q)
    high_grad = (GAMMA / 8 * 1.5 / OLD_Q * dq) if high < 1.2 else 0
    low_grad = (GAMMA * 3 / 8 * 0.5 / (1-OLD_Q) * dq) if low > 0.8 else 0
    return high_gain + low_gain, high_grad, low_grad


def check_clipped_updates():
    z = log(OLD_Q / (1 - OLD_Q))
    for step in range(3):
        gain, high_grad, low_grad = ppo_contributions(z)
        h = 1e-5
        numerical = (ppo_contributions(z+h)[0] - ppo_contributions(z-h)[0]) / (2*h)
        assert isclose(high_grad + low_grad, numerical, abs_tol=1e-8)
        print(f'PPO point {step}: q={sigmoid(z):.7f}, objective={gain:.7f}, '
              f'gradient contributions=({high_grad:.7f}, {low_grad:.7f})')
        if step < 2:
            z += 2 * (high_grad + low_grad)


if __name__ == '__main__':
    check_trust_region()
    check_clipped_updates()
