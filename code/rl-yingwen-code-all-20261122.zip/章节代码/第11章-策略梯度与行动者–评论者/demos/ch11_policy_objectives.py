"""Reproduce the final decision in chapter 11. Run without options for the numbers.
Use --figure PATH.pdf to redraw the three panels (Matplotlib with a CJK font).
"""
import argparse
import math

Q0 = 0.25                     # old probability of earning 3, otherwise earn 1
EPS = 0.20                    # PPO clipping parameter
BUDGET = 0.02                 # KL(old || new), nats, for this one state


def value(q):
    return 1 + 2*q


def entropy(q):
    return -sum(x*math.log(x) for x in (q, 1-q) if x > 0)


def kl(q):
    if q in (0.0, 1.0):
        return math.inf
    return Q0*math.log(Q0/q) + (1-Q0)*math.log((1-Q0)/(1-q))


def clip_gain(q):
    # Exact old-policy expectation; positive and negative advantages are both present.
    terms = [(Q0, 3-value(Q0), q/Q0), (1-Q0, 1-value(Q0), (1-q)/(1-Q0))]
    return sum(p*min(r*a, max(1-EPS, min(1+EPS, r))*a) for p, a, r in terms)


def endpoints():
    def edge(outer):
        inner = Q0
        for _ in range(64):
            middle = (inner + outer)/2
            if kl(middle) <= BUDGET: inner = middle
            else: outer = middle
        return inner
    return edge(0), edge(1)


def draw(filename):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.font_manager import FontProperties
    from plot_fonts import chinese_font
    font = chinese_font()
    def fp(size):
        return FontProperties(fname=font.get_file(), size=size)
    fig, ax = plt.subplots(1,3,figsize=(12,3.08))
    fig.subplots_adjust(left=.038,right=.982,top=.83,bottom=.22,wspace=.29)
    qs = [i/400 for i in range(401)]
    ink, teal, gold, muted = '#182e38','#096b76','#a27618','#63787c'
    lo,hi=endpoints()
    qsoft=1/(1+math.exp(-2))
    for a in ax:
        a.set_xlim(0,1);a.set_xticks([0,Q0,.5,.75,1],['0','.25','.5','.75','1'])
        a.spines[['top','right']].set_visible(False)
        a.spines[['left','bottom']].set_color('#a5b7b6')
        a.tick_params(labelsize=9,colors=ink,length=3)
        a.axvline(Q0,color=muted,linestyle=':',linewidth=1)
        a.set_xlabel('取奖励 3 的概率  q',fontproperties=fp(11.2),color=ink)
    a=ax[0]; a.set_title('普通回报与 TRPO 的可行步',fontproperties=fp(14),color=ink)
    a.axvspan(lo,hi,color='#cee8e6')
    a.plot(qs,[value(q) for q in qs],c=teal,lw=2.6)
    a.scatter([Q0,hi],[value(Q0),value(hi)],c=[muted,teal],zorder=4,s=21)
    a.annotate('KL 预算内',xy=(hi,1.71),xytext=(.41,1.32),fontproperties=fp(11),color=teal,
               arrowprops=dict(arrowstyle='->',color=teal,linewidth=.9))
    a.set_ylim(.92,3.23);a.set_yticks([1,2,3])
    a=ax[1];a.set_title('PPO 的裁剪代理',fontproperties=fp(14),color=ink)
    a.plot(qs,[value(q)-value(Q0) for q in qs],ls='--',color=muted,lw=1.6)
    a.plot(qs,[clip_gain(q) for q in qs],color=teal,lw=2.7)
    a.scatter([.3,.4],[clip_gain(.3),clip_gain(.4)],c=teal,s=18,zorder=4)
    a.text(.57,1.03,'真实回报增量',fontproperties=fp(10),color=muted)
    a.text(.60,-.06,'裁剪代理',fontproperties=fp(11),color=teal)
    a.set_ylim(-.55,1.6);a.set_yticks([-.5,0,.5,1,1.5])
    a=ax[2];a.set_title('SAC 的熵正则目标',fontproperties=fp(14),color=ink)
    a.plot(qs,[value(q)+entropy(q) for q in qs],color=gold,lw=2.6)
    a.plot(qs,[value(q) for q in qs],ls='--',color=muted,lw=1.5)
    a.scatter([qsoft],[value(qsoft)+entropy(qsoft)],color=gold,s=26,zorder=4)
    a.annotate('最优 q ≈ .881',xy=(qsoft,value(qsoft)+entropy(qsoft)),xytext=(.38,3.20),
               fontproperties=fp(10.5),color=gold,arrowprops=dict(arrowstyle='->',color=gold,linewidth=.9))
    a.text(.43,1.58,'普通回报',fontproperties=fp(10),color=muted)
    a.set_ylim(.92,3.45);a.set_yticks([1,2,3])
    fig.savefig(filename)
    plt.close(fig)


if __name__ == '__main__':
    args=argparse.ArgumentParser(description=__doc__)
    args.add_argument('--figure'); out=args.parse_args()
    lo,hi=endpoints(); soft=1/(1+math.exp(-2))
    assert math.isclose(kl(lo), BUDGET) and math.isclose(kl(hi), BUDGET)
    assert max(abs(clip_gain(q)-v) for q,v in [(0,-.5),(.25,0),(.3,.1),(.4,.15),(1,.15)]) < 1e-12
    assert abs(2+math.log((1-soft)/soft))<1e-12
    print(f'KL interval = [{lo:.6f}, {hi:.6f}]; clip gain from q=.4 through q=1: {clip_gain(.4):.3f}; entropy optimum = {soft:.6f}')
    if out.figure: draw(out.figure)
