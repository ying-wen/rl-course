"""Enumerate the policy-gradient signals for Chapter 11's two-decision task.

Run with Python 3. No training, external packages, or simulation is needed.
All moments use the trajectory probabilities induced by the policy.
"""

from math import exp, isclose, log


def sigmoid(logit):
    return 1 / (1 + exp(-logit))


def trajectory_terms(theta0, theta1):
    p, q = sigmoid(theta0), sigmoid(theta1)
    # Each entry contains probability, start return, and two log-probability scores.
    return (
        (1 - p, 1.0, (-p, 0.0)),
        (p * (1 - q), 0.9, (1 - p, -q)),
        (p * q, 2.7, (1 - p, 1 - q)),
    )


def objective(theta0, theta1):
    return sum(prob * ret for prob, ret, _ in trajectory_terms(theta0, theta1))


def weighted_mean(probabilities, observations):
    return sum(prob * value for prob, value in zip(probabilities, observations))


def weighted_variance(probabilities, observations):
    mean = weighted_mean(probabilities, observations)
    return weighted_mean(probabilities, [(x - mean) ** 2 for x in observations])


def check_gradient():
    parameters = (0.0, log(1 / 3))
    paths = trajectory_terms(*parameters)
    coordinate_estimates = []
    for coordinate in (0, 1):
        gradient = sum(p * ret * score[coordinate] for p, ret, score in paths)
        plus, minus = list(parameters), list(parameters)
        plus[coordinate] += 1.0e-5
        minus[coordinate] -= 1.0e-5
        finite_diff = (objective(*plus) - objective(*minus)) / 2.0e-5
        assert isclose(gradient, finite_diff, abs_tol=1.0e-9)
        coordinate_estimates.append(gradient)
    assert isclose(coordinate_estimates[0], .0875)
    assert isclose(coordinate_estimates[1], .16875)
    print("Gradient at start (trajectory sum and finite differences):", coordinate_estimates)


def check_conditioning():
    # Four alternatives for the root decision. Within a continue branch the
    # two terminal samples have the same score and the same action value.
    paths = trajectory_terms(0.0, log(1 / 3))
    probabilities = [p for p, _, _ in paths]
    returns = [ret for _, ret, _ in paths]
    q_values = [1.0, 1.35, 1.35]
    value = weighted_mean(probabilities, returns)
    assert isclose(value, 1.175)
    for name, weights in (("G", returns), ("Q", q_values),
                          ("G-v", [ret - value for ret in returns]),
                          ("A", [q - value for q in q_values])):
        estimates = [path[2][0] * weight for path, weight in zip(paths, weights)]
        mean = weighted_mean(probabilities, estimates)
        assert isclose(mean, .0875)
        print(f"Root {name:>3}: mean={mean:.5f}, variance={weighted_variance(probabilities, estimates):.6f}")


def check_baseline():
    # Condition on arrival at s1. The logit is the preference for taking 3.
    probabilities = [.75, .25]
    scores = [-.25, .75]
    returns = [1, 3]
    for baseline, expected_variance in ((0, 1.171875), (1.5, .1875), (2.5, 0.0)):
        estimates = [g * (ret - baseline) for g, ret in zip(scores, returns)]
        mean = weighted_mean(probabilities, estimates)
        variance = weighted_variance(probabilities, estimates)
        assert isclose(mean, .375)
        assert isclose(variance, expected_variance, abs_tol=1e-12)
        print(f"At s1 with fixed baseline {baseline:g}: mean={mean:.3f}, variance={variance:.6f}")
    # A baseline fit perfectly to this very return depends on the drawn action.
    reused_returns = list(returns)
    estimates = [g * (r - b) for g, r, b in zip(scores, returns, reused_returns)]
    biased_mean = weighted_mean(probabilities, estimates)
    assert biased_mean == 0
    print("At s1 with the current return reused as baseline: mean=0; exact gradient=.375")


if __name__ == "__main__":
    check_gradient()
    check_conditioning()
    check_baseline()
