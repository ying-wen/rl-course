"""Exact return, old-policy surrogate, and PPO-Clip in a two-step decision tree.

Run from rl-course: python3 demos/ppo_shared_tree.py
Shared parameter example: python3 demos/ppo_shared_tree.py --p 41/100
Independent probabilities: python3 demos/ppo_shared_tree.py --candidate .58 .22
Only the Python standard library is required. No training or sampling is used.
"""
import argparse
from fractions import Fraction as F


GAMMA = F(9, 10)
EPSILON = F(1, 5)
OLD = F(1, 2)


def path_probabilities(p):
    """P(stop), P(continue then take 1), P(continue then take 3)."""
    return 1 - p, p*p, p*(1-p)


def tree_values(p, q, old_p, old_q):
    """p selects continue at the root; q selects reward 3 after continuing.

    All updates use the exact old advantages. Surrogates are centered so that
    the old policy has value zero. State weights are discounted counts per
    episode, not an average over the number of decision records.
    """
    def start_return(continuation, high):
        return ((1-continuation)*1 + continuation*(1-high)*GAMMA
                + continuation*high*(3*GAMMA))

    old_value = start_return(old_p, old_q)
    new_value = start_return(p, q)
    old_leaf_value = (1-old_q)*1 + old_q*3
    # Each row holds the probability of reaching the state (discounted), the
    # old and candidate probabilities of its first action, and the two old Qs.
    states = (
        (F(1), old_p, p, (GAMMA*old_leaf_value, F(1)), old_value),
        (GAMMA*old_p, old_q, q, (F(3), F(1)), old_leaf_value),
    )
    surrogate = clipped = F(0)
    for visit_weight, old, new, action_values, baseline in states:
        for prob_new, prob_old, value in zip((new, 1-new), (old, 1-old), action_values):
            ratio = prob_new / prob_old
            advantage = value - baseline
            bounded_ratio = min(1+EPSILON, max(1-EPSILON, ratio))
            weight = visit_weight * prob_old
            surrogate += weight * ratio * advantage
            clipped += weight * min(ratio*advantage, bounded_ratio*advantage)

    # The old surrogate weights changes at the second state by gamma*old_p.
    # Its exact missing term uses the difference in visits and in leaf payoffs.
    cross = GAMMA*(p-old_p)*(3-1)*(q-old_q)
    change = new_value - old_value
    return new_value, change, surrogate, cross, clipped


def evaluate(p):
    """Original shared policy: the same p continues at the root and takes 1 below."""
    if not 0 <= p <= 1:
        raise ValueError("p must be in [0, 1]")
    value, change, surrogate, _, clipped = tree_values(p, 1-p, OLD, 1-OLD)
    return value, change, surrogate, clipped


def evaluate_candidate(p, q):
    """Compare independent probabilities to the old policy (.5, .25)."""
    if not (0 <= p <= 1 and 0 <= q <= 1):
        raise ValueError("both probabilities must be in [0, 1]")
    return tree_values(p, q, F(1, 2), F(1, 4))


def probability(text):
    try:
        result = F(text)
    except (ValueError, ZeroDivisionError) as exc:
        raise argparse.ArgumentTypeError("use a decimal or a fraction such as 1/4") from exc
    if not 0 <= result <= 1:
        raise argparse.ArgumentTypeError("probability must be in [0, 1]")
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--p", nargs="+", type=probability,
                      default=[OLD, F(9, 20), F(2, 5), F(7, 20)],
                      help="shared candidates, old p=.5; e.g. .45 2/5")
    mode.add_argument("--candidate", nargs=2, type=probability, metavar=("P", "Q"),
                      help="P(continue) and P(take 3 | continue), old policy (.5, .25)")
    args = parser.parse_args()
    if args.candidate is not None:
        p, q = args.candidate
        print(f"P(continue)={p}; P(take 3 | continue)={q}; gamma={GAMMA}; clip epsilon={EPSILON}")
        print("Old policy (.5, .25); J(old) = 47/40. Surrogates below are centered.")
        labels = ("J(candidate)", "change in J", "old-state surrogate", "visitation cross term",
                  "PPO-Clip surrogate")
        for label, result in zip(labels, evaluate_candidate(p, q)):
            print(f"{label:23} {str(result):>12}    {float(result):+.6f}")
        return

    print("p       visits/100     J(p)       change J     old surrogate     clipped")
    for p in args.p:
        value, change, surrogate, clipped = evaluate(p)
        print(f"{float(p):.4f}   {float(100*p):8.2f}   {float(value):9.5f}   "
              f"{float(change):+10.5f}   {float(surrogate):+13.5f}   {float(clipped):+9.5f}")

    # Ratios are affine in p, so only endpoints or clipping breakpoints can maximize
    # the piecewise-linear objective. The values differ and all intervals have slope.
    knots = (F(0), OLD*(1-EPSILON), OLD*(1+EPSILON), F(1))
    assert [evaluate(p)[3] for p in knots] == [F(-31, 100), F(1, 100), F(-1, 100), F(-37, 100)]
    assert evaluate(F(2, 5)) == (F(174, 125), F(-1, 125), F(1, 100), F(1, 100))


if __name__ == "__main__":
    main()
