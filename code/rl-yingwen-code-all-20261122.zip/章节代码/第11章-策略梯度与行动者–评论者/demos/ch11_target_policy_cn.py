"""Chapter 11, slides ch11-td3-target, ch11-policy-simplex, ch11-policy-comparison-case.

11-21 审阅站请求 r1121-114237：三页的原图（td3-target.pdf、improvement-simplex.pdf、
terminal-policy.pdf）用 matplotlib 默认字体，图字小到 3.5--4.5pt；其中 td3-target.pdf
还被其他页引用。本脚本只写新文件，不覆盖原图：
  assets/ch11-policy/td3-target-cn.pdf           两个评论者取小与目标平滑
  assets/ch11-policy/improvement-simplex-cn.pdf  三动作单纯形上的两种改进准则
  assets/ch11-policy/terminal-policy-cn.pdf      终点决策的三个准则，横轴改记 p
数值全部取自原脚本的函数与常数（ch11_deterministic_policy、ch11_policy_improvement、
ch11_policy_objectives），不另设参数。字体用 plot_fonts.use_course_fonts()。

Run: python demos/ch11_target_policy_cn.py
"""
from __future__ import annotations
import math
import sys
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.tri as tri
from matplotlib.ticker import FuncFormatter
sys.path.insert(0, str(Path(__file__).resolve().parent))
from plot_fonts import use_course_fonts, CJK_FAMILY, no_leading_zero
import ch11_deterministic_policy as dp
import ch11_policy_improvement as pi
import ch11_policy_objectives as po

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'assets/ch11-policy'
INK, TEAL, RED, GOLD, GREY = '#182e38', '#096b76', '#aa412d', '#a27618', '#50686c'
FMT = FuncFormatter(no_leading_zero)


def style(ax, tick=11):
    ax.spines[['right', 'top']].set_visible(False)
    ax.spines[['bottom', 'left']].set_color('#9caaa9')
    ax.tick_params(labelsize=tick, colors=GREY, length=3)
    ax.xaxis.set_major_formatter(FMT)
    ax.yaxis.set_major_formatter(FMT)


def td3_target():
    # Shown at height 3.9cm: figure height 2.45in -> scale ~.63; 11pt ticks -> ~7pt.
    a = np.linspace(-.097, .097, 650)
    first, second = dp.critics(a)
    lower = np.minimum(first, second)
    center = np.pi / 200
    fig, (ax, bx) = plt.subplots(1, 2, figsize=(7.4, 2.45), sharey=True, layout='constrained')
    ax.plot(a, first, c=RED, lw=1.4, label='$Q_1$')
    ax.plot(a, second, c=GOLD, lw=1.4, ls='--', label='$Q_2$')
    ax.plot(a, lower, c=TEAL, lw=2.1, label='两者较小值')
    ax.axvline(center, c=GREY, ls=':', lw=.9)
    ys = dp.critics(center)
    ax.scatter([center, center], ys, c=[RED, TEAL], s=18, zorder=4)
    ax.legend(fontsize=11, frameon=False, ncol=3, loc='upper center', handlelength=1.4,
              columnspacing=.9, borderaxespad=0)
    ax.set_title('同一后继动作，各读一次估值', fontsize=12.5, color=INK)
    bx.plot(a, lower, c=GREY, ls='--', lw=1.3, label='无目标噪声')
    bx.plot(a, dp.target_average(a), c=TEAL, lw=2.2, label='对目标噪声取平均')
    bx.axvspan(center - .04, center + .04, ymin=0, ymax=.08, color='#e4d7b3')
    bx.scatter([center], [dp.target_average(center)], c=TEAL, s=20, zorder=4)
    bx.legend(fontsize=11, frameon=False, ncol=2, loc='upper center', handlelength=1.6,
              columnspacing=.9, borderaxespad=0)
    bx.set_title('同一对估值，改查邻近动作', fontsize=12.5, color=INK)
    for pane in (ax, bx):
        style(pane)
        pane.set_xticks([-.08, 0, .08])
        pane.set_ylim(-.022, .0195)
        pane.set_xlabel('后继动作 $a\'$', fontsize=12, fontfamily=CJK_FAMILY, color=INK)
    ax.set_yticks([-.02, -.01, 0, .01])
    ax.set_ylabel('后继动作估值', fontsize=12, color=INK)
    fig.savefig(OUT / 'td3-target-cn.pdf')
    plt.close(fig)


def improvement_simplex():
    def xy(p):
        return p[1] + .5 * p[2], .8660254 * p[2]
    p = np.array([(i, j, 64 - i - j) for i in range(65) for j in range(65 - i)]) / 64
    x, y = xy(p.T)
    mesh = tri.Triangulation(x, y)
    ordinary = p @ np.array(pi.Q)
    H = -(p * np.log(np.maximum(p, 1e-12))).sum(axis=1)
    old = np.array(pi.OLD)
    kl = np.sum(old * np.log(old / np.maximum(p, 1e-12)), axis=1)
    fig, axes = plt.subplots(1, 2, figsize=(7.6, 2.5))
    fig.subplots_adjust(left=.01, right=.99, top=.99, bottom=.13, wspace=.04)
    cmap = matplotlib.colors.LinearSegmentedColormap.from_list('surface', ['#ffffff', '#e3f1ed', '#b1d6d0'])
    for ax, values, levels in zip(axes, (ordinary, ordinary + pi.TEMPERATURE * H),
                                  ((.4, .7, 1., 1.3, 1.6), (1.2, 1.6, 1.9, 2.1, 2.26, 2.36))):
        ax.set_aspect('equal'); ax.set_xlim(-.24, 1.24); ax.set_ylim(-.12, .97); ax.axis('off')
        ax.tricontourf(mesh, values, levels=np.linspace(values.min() - 1e-6, values.max() + 1e-6, 20), cmap=cmap)
        ax.tricontour(mesh, values, levels=levels, colors='#7baca9', linewidths=.8)
        ax.plot([0, 1, .5, 0], [0, 0, .8660254, 0], lw=1.2, c=INK)
        for px, py, t, ha in ((-.02, -.06, '总选 $a_1$', 'right'), (1.02, -.06, '总选 $a_2$', 'left'),
                              (.5, .92, '总选 $a_3$', 'center')):
            ax.text(px, py, t, fontsize=13, fontfamily=CJK_FAMILY, color=INK, ha=ha, va='center')
    a, b = axes
    a.tricontour(mesh, kl, levels=[pi.BUDGET], colors=GOLD, linewidths=2.0)
    start, end = xy(pi.OLD), xy(pi.constrained_policy())
    a.scatter(*start, c=INK, s=24, zorder=4)
    a.scatter(*end, c=GOLD, marker='D', s=28, zorder=4)
    a.annotate('', xy=end, xytext=start, arrowprops=dict(arrowstyle='->', lw=1.4, color=INK))

    def label(ax, txt, pos, where, color):
        ax.annotate(txt, xy=pos, xytext=where, ha='center', va='center', fontsize=13, color=color,
                    bbox=dict(fc='white', ec='none', alpha=.85, pad=1.5),
                    arrowprops=dict(arrowstyle='-', lw=1.0, color=color, shrinkB=5))
    label(a, '旧策略', start, (-.04, .2), INK)
    label(a, 'KL 预算内的最优步', end, (.95, .5), GOLD)
    b.scatter(*xy(pi.soft_policy()), s=52, marker='*', color=TEAL, zorder=4)
    label(b, '奖励加熵的最大点', xy(pi.soft_policy()), (.98, .66), TEAL)
    a.set_title('固定旧策略，限制本次更新', fontsize=13.5, color=INK, y=-.15)
    b.set_title('给熵赋予价值，改变目标', fontsize=13.5, color=INK, y=-.15)
    fig.savefig(OUT / 'improvement-simplex-cn.pdf')
    plt.close(fig)


def terminal_policy():
    fig, ax = plt.subplots(1, 3, figsize=(8.4, 2.6))
    fig.subplots_adjust(left=.05, right=.985, top=.86, bottom=.24, wspace=.32)
    ps = [i / 400 for i in range(401)]
    lo, hi = po.endpoints()
    psoft = 1 / (1 + math.exp(-2))
    q0 = po.Q0
    for a in ax:
        style(a, tick=12)
        a.set_xlim(0, 1); a.set_xticks([0, q0, .5, 1])
        a.axvline(q0, color=GREY, linestyle=':', linewidth=1)
        a.set_xlabel('选右的概率 $p$', fontsize=13, fontfamily=CJK_FAMILY, color=INK)
    a = ax[0]; a.set_title('普通回报与 TRPO 的可行步', fontsize=13, color=INK)
    a.axvspan(lo, hi, color='#cee8e6')
    a.plot(ps, [po.value(p) for p in ps], c=TEAL, lw=2.4)
    a.scatter([q0, hi], [po.value(q0), po.value(hi)], c=[GREY, TEAL], zorder=4, s=18)
    a.annotate('KL 预算内', xy=(hi, 1.71), xytext=(.45, 1.25), fontsize=12.5, color=TEAL,
               arrowprops=dict(arrowstyle='->', color=TEAL, linewidth=.9))
    a.set_ylim(.92, 3.23); a.set_yticks([1, 2, 3])
    a = ax[1]; a.set_title('PPO 的裁剪代理', fontsize=13, color=INK)
    a.plot(ps, [po.value(p) - po.value(q0) for p in ps], ls='--', color=GREY, lw=1.5)
    a.plot(ps, [po.clip_gain(p) for p in ps], color=TEAL, lw=2.5)
    a.scatter([.3, .4], [po.clip_gain(.3), po.clip_gain(.4)], c=TEAL, s=16, zorder=4)
    a.text(.36, 1.18, '真实回报增量', fontsize=12.5, color=GREY)
    a.text(.52, -.18, '裁剪代理', fontsize=12.5, color=TEAL)
    a.set_ylim(-.55, 1.6); a.set_yticks([-.5, 0, .5, 1, 1.5])
    a = ax[2]; a.set_title('SAC 的熵正则目标', fontsize=13, color=INK)
    a.plot(ps, [po.value(p) + po.entropy(p) for p in ps], color=GOLD, lw=2.4)
    a.plot(ps, [po.value(p) for p in ps], ls='--', color=GREY, lw=1.4)
    a.scatter([psoft], [po.value(psoft) + po.entropy(psoft)], color=GOLD, s=22, zorder=4)
    a.annotate('最优 $p$≈.881', xy=(psoft, po.value(psoft) + po.entropy(psoft)), xytext=(.05, 3.1),
               fontsize=12.5, fontfamily=CJK_FAMILY, color=GOLD,
               arrowprops=dict(arrowstyle='->', color=GOLD, linewidth=.9))
    a.text(.42, 1.45, '普通回报', fontsize=12.5, color=GREY)
    a.set_ylim(.92, 3.45); a.set_yticks([1, 2, 3])
    fig.savefig(OUT / 'terminal-policy-cn.pdf')
    plt.close(fig)


if __name__ == '__main__':
    if not use_course_fonts():
        print('warning: some course fonts were not found')
    lo, hi = po.endpoints()
    print(f'TRPO interval [{lo:.4f}, {hi:.4f}], KL(old||new) at right end {po.kl(hi):.4f}')
    print(f'TD3 at pi/200: Q1={dp.critics(np.pi/200)[0]:.4f}, Q2={dp.critics(np.pi/200)[1]:.4f}, '
          f'smoothed min={float(dp.target_average(np.pi/200)):.4f}')
    td3_target()
    improvement_simplex()
    terminal_policy()
    print('wrote', *(OUT / n for n in ('td3-target-cn.pdf', 'improvement-simplex-cn.pdf', 'terminal-policy-cn.pdf')))
