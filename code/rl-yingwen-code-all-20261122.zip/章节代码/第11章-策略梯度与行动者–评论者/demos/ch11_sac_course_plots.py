"""Redraw the two SAC result figures of section 11.12 in the slide fonts.

11-21 审阅站请求 r1121-114237（第 783、784 页）：原图 behavior-zh.pdf、learning-zh.pdf
字小且用 STHeiti。本脚本只读 sample14_sac.py 已保存的结果（curve-*.npy、
initial-0.pt、learned-0.pt），不重新训练，另存为 *-course.pdf，不覆盖原图。

python ch11_sac_course_plots.py
"""
from pathlib import Path
import sys

import numpy as np
import torch
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from plot_fonts import use_course_fonts, CJK_FAMILY, no_leading_zero  # noqa: E402
import sample14_sac as sac  # noqa: E402

OUT = HERE.parent / 'assets' / 'sample14-sac'
TEAL, GOLD, RED, MUTED, INK = '#087e8b', '#c9a227', '#c65335', '#61757d', '#1f2d33'
def minus(s):
    return s.replace('-', '\u2212')


FMT = FuncFormatter(lambda x, pos=None: minus(no_leading_zero(x)))


def style(ax):
    ax.spines[['top', 'right']].set_visible(False)
    ax.xaxis.set_major_formatter(FMT)
    ax.yaxis.set_major_formatter(FMT)


def learning():
    seeds = [0, 1, 2]
    curves = [np.load(OUT / f'curve-{s}.npy') for s in seeds]
    base = sac.baselines()
    fig, ax = plt.subplots(figsize=(6.2, 2.55), layout='constrained')
    for c, s, ls in zip(curves, seeds, ['-', '--', ':']):
        ax.plot(c[:, 0], c[:, 1], color=TEAL, lw=1.6, ls=ls, label=f'SAC 种子 {s}')
    ax.axhline(base['feedback'], color=RED, lw=1.2, ls='-.')
    ax.axhline(base['zero'], color=MUTED, lw=1.0, ls='--')
    ax.axhline(base['uniform'], color=MUTED, lw=1.0, ls=':')
    xr = curves[0][-1, 0]
    ax.text(xr, base['feedback'] + .25, minus(f'已知模型控制器 {no_leading_zero(round(base["feedback"], 3))}'),
            color=RED, ha='right', va='bottom', fontsize=10.5)
    ax.text(xr, base['zero'] + .12, minus(f'零动作 {base["zero"]:.2f}'), color=MUTED, ha='right', va='bottom', fontsize=10.5)
    ax.text(xr, base['uniform'] + .12, minus(f'均匀动作 {base["uniform"]:.2f}'), color=MUTED, ha='right', va='bottom', fontsize=10.5)
    ax.set_xlabel('真实转移数', fontsize=11.5)
    ax.set_ylabel('外部折扣回报', fontsize=11.5)
    ax.tick_params(labelsize=10.5)
    ax.set_ylim(-8, .4)
    style(ax)
    ax.legend(frameon=False, fontsize=10, loc='center right', ncol=3, bbox_to_anchor=(1, .66))
    fig.savefig(OUT / 'learning-course.pdf')
    plt.close(fig)


def behavior():
    initial = sac.Agent()
    initial.load_state_dict(torch.load(OUT / 'initial-0.pt', weights_only=True))
    learned = sac.Agent()
    learned.load_state_dict(torch.load(OUT / 'learned-0.pt', weights_only=True)['agent'])
    fig, axs = plt.subplots(1, 2, figsize=(7.4, 2.7), layout='constrained')
    for agent, color, label in [(initial, MUTED, '训练前'), (learned, TEAL, '训练后')]:
        run = sac.evaluate(agent, seed=731, starts=[.8], repeats=20)
        for row in run['x'].T:
            axs[0].plot(range(sac.H + 1), row, color=color, alpha=.18, lw=.8)
        axs[0].plot(range(sac.H + 1), run['x'].mean(1), color=color, lw=2.2, label=label)
    axs[0].axhline(0, color=RED, ls='--', lw=1)
    axs[0].set_xlabel('回合内步数 $t$', fontsize=11.5, fontfamily=CJK_FAMILY)
    axs[0].set_ylabel('位置 $x$', fontsize=11.5, fontfamily=CJK_FAMILY)
    axs[0].legend(frameon=False, fontsize=10.5)
    x = np.linspace(-1, 1, 81)
    ss = sac.tensor(sac.observation(x, sac.H))
    for agent, color, label in [(initial, MUTED, '训练前'), (learned, TEAL, '训练后')]:
        with torch.no_grad():
            mu, ls = agent.actor(ss).chunk(2, -1)
            sd = ls.clamp(-5, 1).exp()
            median = mu.tanh().numpy()[:, 0]
            low = (mu - sd).tanh().numpy()[:, 0]
            high = (mu + sd).tanh().numpy()[:, 0]
        axs[1].fill_between(x, low, high, color=color, alpha=.15, lw=0)
        axs[1].plot(x, median, color=color, lw=2.0, label=label)
    axs[1].axhline(0, color='.75', lw=.7)
    axs[1].axvline(0, color='.75', lw=.7)
    axs[1].set_xlabel('位置 $x$（还剩 12 步）', fontsize=11.5, fontfamily=CJK_FAMILY)
    axs[1].set_ylabel('推力 $a$', fontsize=11.5, fontfamily=CJK_FAMILY)
    axs[1].set_ylim(-1.05, 1.05)
    axs[1].legend(frameon=False, fontsize=10.5)
    for ax in axs:
        ax.tick_params(labelsize=10.5)
        style(ax)
    fig.savefig(OUT / 'behavior-course.pdf')
    plt.close(fig)


if __name__ == '__main__':
    use_course_fonts()
    learning()
    behavior()
