#!/usr/bin/env python3
"""Small exact calculations for chapter 11; no training and no PyTorch.

Run from any directory: python /absolute/path/demos/v19_policy_gradient.py
Outputs only assets/v19-policy-gradient. Historical training data are read neither
as labels nor overwritten. Tests use enumeration, finite differences, and quadrature.
"""
from pathlib import Path
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager

OUT = Path(__file__).resolve().parents[1] / 'assets/v19-policy-gradient'
TEAL, RED, INK, GRAY = '#087e8b', '#c65335', '#182e38', '#61757d'
for font in ['/System/Library/Fonts/PingFang.ttc', '/System/Library/Fonts/STHeiti Light.ttc']:
    if Path(font).exists():
        font_manager.fontManager.addfont(font)
        plt.rcParams['font.family'] = font_manager.FontProperties(fname=font).get_name()
        break
plt.rcParams.update({'font.size': 12, 'axes.spines.top': False,
                     'axes.spines.right': False, 'axes.labelcolor': INK,
                     'text.color': INK, 'axes.unicode_minus': False,
                     'pdf.fonttype': 42})

def sigmoid(x): return 1 / (1 + np.exp(-np.asarray(x)))
def logit(p): return np.log(np.asarray(p) / (1-np.asarray(p)))
def fd(f, x, h=1e-5):
    x = np.asarray(x, dtype=float)
    return np.array([(f(x+np.eye(len(x))[i]*h)-f(x-np.eye(len(x))[i]*h))/(2*h)
                     for i in range(len(x))])
def hessian_fd(f, x, h=1e-4):
    x = np.asarray(x, dtype=float)
    return np.column_stack([(fd(f,x+e*h,h/2)-fd(f,x-e*h,h/2))/(2*h)
                            for e in np.eye(len(x))])
def check(a,b,tol=1e-8):
    err=float(np.max(np.abs(np.asarray(a)-np.asarray(b))))
    assert err<tol,(a,b,err)
    return err
def save(fig,name):
    fig.savefig(OUT/f'{name}.pdf',bbox_inches='tight')
    fig.savefig(OUT/f'{name}.png',dpi=180,bbox_inches='tight')
    plt.close(fig)

GAMMA=.9
TH0=logit([.5,.25])
def performance(th):
    p,q=sigmoid(th)
    return 1-p+GAMMA*p*(1+2*q)
def exact_gradient(th):
    p,q=sigmoid(th)
    return np.array([p*(1-p)*(GAMMA*(1+2*q)-1),2*GAMMA*p*q*(1-q)])
def paths(th):
    p,q=sigmoid(th)
    return [(1-p,[0],[1]), (p*(1-q),[1,0],[0,1]),(p*q,[1,1],[0,3])]
def causal_score(th,actions,rewards,outer=True):
    probs=sigmoid(th); g=np.zeros(2)
    for t in range(len(actions)):
        ret=sum(GAMMA**(k-t)*rewards[k] for k in range(t,len(actions)))
        g[t]=(GAMMA**t if outer else 1)*ret*(actions[t]-probs[t])
    return g
def pg_checks():
    enum=sum(w*causal_score(TH0,a,r) for w,a,r in paths(TH0))
    full=np.zeros(2)
    for w,a,r in paths(TH0):
        score=np.zeros(2); score[:len(a)]=np.asarray(a)-sigmoid(TH0)[:len(a)]
        full+=w*sum(GAMMA**t*x for t,x in enumerate(r))*score
    errs={'score_vs_exact':check(enum,exact_gradient(TH0)),
          'trajectory_vs_causal':check(full,enum),
          'pg_finite_difference':check(enum,fd(performance,TH0))}
    wrong=sum(w*causal_score(TH0,a,r,False) for w,a,r in paths(TH0))
    # Entire trajectory ratio recovers both future behavior and state visits.
    bh=logit([.8,.2]); corrected=np.zeros(2); single=np.zeros(2)
    target=paths(TH0)
    for j,(wb,a,r) in enumerate(paths(bh)):
        corrected+=wb*(target[j][0]/wb)*causal_score(TH0,a,r)
        gt=causal_score(TH0,a,r)
        for t,act in enumerate(a):
            pt=sigmoid(TH0)[t] if act else 1-sigmoid(TH0)[t]
            pb=sigmoid(bh)[t] if act else 1-sigmoid(bh)[t]
            single[t]+=wb*(pt/pb)*gt[t]
    errs['full_importance_ratio']=check(corrected,enum)
    assert np.linalg.norm(single-enum)>.05
    return {'objective':performance(TH0),'gradient':enum.tolist(),
            'without_outer_discount':wrong.tolist(),
            'single_action_ratio_on_behavior_returns':single.tolist(),
            'errors':errs}

def kl_bernoulli(old,new):
    return old*np.log(old/new)+(1-old)*np.log((1-old)/(1-new))
def surrogate(th):
    p,q=sigmoid(th); po,qo=sigmoid(TH0)
    return (p-po)*(GAMMA*(1+2*qo)-1)+GAMMA*po*2*(q-qo)
def mean_kl(th):
    p,q=sigmoid(th); po,qo=sigmoid(TH0)
    # Normalized discounted occupancy includes the zero-score absorbing state.
    return (1-GAMMA)*(kl_bernoulli(po,p)+GAMMA*po*kl_bernoulli(qo,q))
def trust_region():
    g=exact_gradient(TH0); po,qo=sigmoid(TH0)
    F=(1-GAMMA)*np.diag([po*(1-po),GAMMA*po*qo*(1-qo)])
    delta=.01; direction=np.linalg.solve(F,g)
    step=np.sqrt(2*delta/(g@direction))*direction
    scales=[1,.5,.25,.125]
    accepted=next(c for c in scales if mean_kl(TH0+c*step)<=delta and surrogate(TH0+c*step)>0)
    errors={'fisher_hessian':check(F,hessian_fd(mean_kl,TH0),1e-7),
            'surrogate_tangent':check(g,fd(surrogate,TH0)),
            'quadratic_budget':check(step@F@step/2,delta)}
    # Independent dense boundary enumeration of this 2-D constrained problem.
    angle=np.linspace(0,2*np.pi,100001)
    boundary=np.sqrt(2*delta)*np.vstack([np.cos(angle)/np.sqrt(F[0,0]),np.sin(angle)/np.sqrt(F[1,1])])
    errors['boundary_optimum']=check(g@step,np.max(g@boundary),1e-7)
    xs=np.linspace(-1.1,1.1,230); ys=np.linspace(-2.3,2.3,230)
    X,Y=np.meshgrid(xs,ys)
    actual=mean_kl(TH0[:,None,None]+np.stack([X,Y]))
    quad=.5*(F[0,0]*X**2+F[1,1]*Y**2)
    fig,ax=plt.subplots(figsize=(3.8,2.2))
    ax.contour(X,Y,actual,levels=[delta],colors=[TEAL],linewidths=2)
    ax.contour(X,Y,quad,levels=[delta],colors=[GRAY],linestyles='--')
    ax.plot([],[],color=TEAL,label='真实平均 KL = 0.01')
    ax.plot([],[],color=GRAY,ls='--',label='局部二次近似 = 0.01')
    ax.annotate('',step,xytext=(0,0),arrowprops=dict(arrowstyle='->',color=RED,lw=2))
    ax.scatter([0,step[0]*accepted],[0,step[1]*accepted],c=[INK,TEAL],s=35,zorder=5)
    ax.annotate('候选步',step,xytext=(.45,1.75),arrowprops=dict(arrowstyle='-',color=GRAY),fontsize=9)
    ax.annotate('减半接受',step*accepted,xytext=(.45,.4),arrowprops=dict(arrowstyle='-',color=GRAY),fontsize=9)
    ax.set(xlabel=r'$\Delta\theta_0$',ylabel=r'$\Delta\theta_1$')
    ax.tick_params(labelsize=9)
    ax.axhline(0,color=GRAY,lw=.5);ax.axvline(0,color=GRAY,lw=.5)
    ax.legend(loc='lower left',fontsize=7.5);fig.tight_layout(pad=.3);save(fig,'trpo-geometry')
    return {'F':F.tolist(),'g':g.tolist(),'delta':delta,'candidate_step':step.tolist(),
            'candidate_KL':float(mean_kl(TH0+step)), 'accepted_scale':accepted,
            'accepted_KL':float(mean_kl(TH0+accepted*step)),
            'true_improvement':float(performance(TH0+accepted*step)-performance(TH0)),
            'surrogate_improvement':float(surrogate(TH0+accepted*step)),'errors':errors}

def ppo_check():
    def objective(th):
        p=float(sigmoid(th[0])); ratios=np.array([2*p,2*(1-p)]); adv=np.array([1.,-1.])
        return np.minimum(ratios*adv,np.clip(ratios,.8,1.2)*adv).mean()
    errors={'initial_gradient':check(fd(objective,[0]),[.5]),
            'flat_gradient':check(fd(objective,[.5]),[0])}
    return {'after_step_probability':float(sigmoid(.5)),
            'ratios':[float(2*sigmoid(.5)),float(2*(1-sigmoid(.5)))],'errors':errors}

def control_as_inference():
    # One action; risky outcome is an environment transition, not chosen by actor.
    rewards=np.array([1.,0.,2.]); prior=np.array([.5,.25,.25]); alpha=1.
    z=float(prior@np.exp(rewards/alpha)); posterior=prior*np.exp(rewards/alpha)/z
    check_errors={}
    for p in [.1,.25,.5,.8,.95]:
        q=np.array([1-p,p/2,p/2]); kl=float(q@np.log(q/posterior))
        objective=float(q@(rewards-alpha*np.log(q/prior)))
        check_errors[str(p)]=check(-alpha*kl,objective-alpha*np.log(z))
    grid=np.linspace(.0001,.9999,10001)
    qs=np.column_stack([1-grid,grid/2,grid/2])
    kls=np.sum(qs*np.log(qs/posterior),axis=1)
    check_errors['variational_grid_optimum']=check(grid[np.argmin(kls)],.5)
    safe=1.; risky=float(np.log((1+np.exp(2))/2))
    fig,axes=plt.subplots(1,2,figsize=(10.4,3.45),gridspec_kw={'width_ratios':[1.25,1]})
    ax=axes[0];ax.axis('off');ax.set(xlim=(-.3,4.7),ylim=(-1.5,1.5))
    ax.text(0,0,'同一起点',ha='center',bbox=dict(boxstyle='circle,pad=.55',fc='white',ec=INK))
    for x,y,lab in [(1.7,.85,'安全'),(1.7,-.65,'随机')]:
        ax.text(x,y,lab,ha='center',va='center',color=TEAL,bbox=dict(boxstyle='round,pad=.22',fc='white',ec=TEAL))
        ax.annotate('',(x-.35,y),xytext=(.5,0),arrowprops=dict(arrowstyle='->',color=TEAL,lw=1.6))
    for x,y,lab,origin in [(3.7,.85,'奖励 1',(2.05,.85)),(3.7,-.15,'奖励 0',(2.05,-.65)),(3.7,-1.15,'奖励 2',(2.05,-.65))]:
        ax.text(x,y,lab,ha='left',va='center')
        ax.annotate('',(x-.15,y),xytext=origin,arrowprops=dict(arrowstyle='->',color=GRAY,lw=1.6))
    ax.text(2.65,-.2,'1/2',fontsize=11);ax.text(2.65,-1.2,'1/2',fontsize=11)
    ax.text(-.1,1.45,'真实环境：随机动作的两种结果等概率',fontsize=12)
    ax.text(0,-1.65,'条件化后“奖励 2”的概率：0.881\n实际执行仍是 0.5',color=RED,fontsize=12)
    ax=axes[1];x=np.arange(2);w=.32
    ax.bar(x-w/2,[safe,1],w,color=TEAL,label='真实期望 E[R]')
    ax.bar(x+w/2,[safe,risky],w,color=RED,label='条件化 log E[exp(R)]')
    ax.text(1+w/2,risky+.04,f'{risky:.3f}',ha='center',color=RED)
    ax.set(xticks=x,xticklabels=['安全动作','随机动作'],ylim=(0,1.85),ylabel='评价值（α = 1）')
    ax.legend(fontsize=10,loc='upper left');fig.tight_layout();save(fig,'cai-dynamics')
    return {'reward_means':[1.,1.],'posterior_risky_action':float(posterior[1:].sum()),
            'posterior_lucky_outcome':float(posterior[2]/posterior[1:].sum()),
            'naive_risky_value':risky,'variational_optimum_risky_probability':.5,
            'kl_identity_errors':check_errors}

def sac_loss(th,eps,x=.8,alpha=.1):
    mu,v=th;u=mu+np.exp(v)*eps;a=np.tanh(u)
    lp=-.5*eps**2-v-.5*np.log(2*np.pi)-2*(np.log(2)-u-np.logaddexp(0,-2*u))
    q=-(x+.25*a)**2-.03*a*a
    return alpha*lp-q
def sac_derivative(th,eps,x=.8,alpha=.1):
    mu,v=th;sigma=np.exp(v);u=mu+sigma*eps;a=np.tanh(u)
    qa=-.5*(x+.25*a)-.06*a
    common=2*alpha*a-qa*(1-a*a)
    return np.array([common,-alpha+common*sigma*eps])
def sac_check():
    th=np.array([-.2,-.7]);eps=.6;alpha=.1; sigma=np.exp(th[1]);u=th[0]+sigma*eps;a=np.tanh(u)
    qa=-.5*(.8+.25*a)-.06*a
    explicit=alpha*np.array([eps/sigma,eps**2-1])
    action=(alpha*(-eps/sigma+2*a)/(1-a*a)-qa)*(1-a*a)*np.array([1,sigma*eps])
    gradient=sac_derivative(th,eps)
    errors={'sample_finite_difference':check(gradient,fd(lambda t:sac_loss(t,eps),th)),
            'explicit_plus_action':check(explicit+action,gradient)}
    # Gauss-Hermite integration independently checks the expected surrogate gradient.
    nodes,weights=np.polynomial.hermite.hermgauss(100);noise=np.sqrt(2)*nodes; weights=weights/np.sqrt(np.pi)
    analytic=sac_derivative(th,noise)@weights
    errors['quadrature_expected_gradient']=check(analytic,fd(lambda t:float(weights@sac_loss(t,noise)),th))
    fig,axes=plt.subplots(1,2,figsize=(10.3,3.6))
    aa=np.linspace(-1,1,400);qq=-(.8+.25*aa)**2-.03*aa*aa
    axes[0].plot(aa,qq,color=TEAL,lw=2,label='固定的末步 Q(s,a)')
    axes[0].scatter([a],[-(.8+.25*a)**2-.03*a*a],color=RED,zorder=3)
    axes[0].annotate(r'本次动作 $\widetilde a$ = %.3f'%a,(a,-(.8+.25*a)**2-.03*a*a),xytext=(-.9,-1.0),arrowprops=dict(arrowstyle='->',color=RED),fontsize=11)
    axes[0].set(xlabel='动作 a',ylabel='动作价值',title='Q 权重固定，动作斜率仍存在')
    axes[0].legend(fontsize=10)
    cats=['显式密度路径','动作路径','两条路径之和'];vals=[explicit[0],action[0],gradient[0]]
    axes[1].bar(cats,vals,color=[GRAY,TEAL,RED],width=.6)
    for i,v in enumerate(vals): axes[1].text(i,v+.012,f'{v:.4f}',ha='center',fontsize=11)
    axes[1].set(ylabel=r'$d\ell/d\bar u$',ylim=(0,.56),title=r'同一噪声 $\xi$ = 0.6 的链式求导')
    fig.tight_layout();save(fig,'sac-paths')
    return {'state_x':.8,'remaining_steps':1,'mu':th[0],'log_std':th[1],'epsilon':eps,
            'alpha':alpha,'action':float(a),'q_action_slope':float(qa),'explicit_path':explicit.tolist(),
            'action_path':action.tolist(),'sample_gradient':gradient.tolist(),
            'expected_gradient_quadrature':analytic.tolist(),'errors':errors}

def main():
    OUT.mkdir(exist_ok=True,parents=True)
    data={'validation_layer':'exact toy calculations; no new training',
          'pg':pg_checks(),'trpo':trust_region(),'ppo':ppo_check(),
          'control_as_inference':control_as_inference(),'sac':sac_check()}
    (OUT/'checks.json').write_text(json.dumps(data,ensure_ascii=False,indent=2))
    print(json.dumps(data,ensure_ascii=False,indent=2))

if __name__=='__main__': main()
