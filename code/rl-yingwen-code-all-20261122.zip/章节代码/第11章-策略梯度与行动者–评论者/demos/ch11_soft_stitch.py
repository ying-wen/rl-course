"""Two Bellman sweeps over two suboptimal logs in a deterministic, two-step MDP.

Run: python3 demos/ch11_soft_stitch.py
The learner sees only the four recorded transitions. The environment is used
after training to evaluate each action sequence and to check the result.
"""
from dataclasses import dataclass
from math import exp, isclose, log

ACTIONS = {"S": ("free", "toll"), "J": ("stop", "deliver")}
TERMINAL = "end"


@dataclass(frozen=True)
class Transition:
    state: str
    action: str
    reward: float
    successor: str


def step(state, action, delivery_reward=3.0):
    """Deterministic dynamics used to collect and evaluate the logs."""
    transitions = {
        ("S", "free"): (0.0, "J"),
        ("S", "toll"): (-2.0, "J"),
        ("J", "stop"): (0.0, TERMINAL),
        ("J", "deliver"): (delivery_reward, TERMINAL),
    }
    reward, successor = transitions[state, action]
    return Transition(state, action, reward, successor)


def collect(route, delivery_reward=3.0):
    state = "S"
    trajectory = []
    for action in route:
        transition = step(state, action, delivery_reward)
        trajectory.append(transition)
        state = transition.successor
    assert state == TERMINAL
    return tuple(trajectory)


def state_value(q, state, temperature):
    if state == TERMINAL:
        return 0.0
    values = [q[state, action] for action in ACTIONS[state]]
    maximum = max(values)
    if temperature == 0.0:
        return maximum
    weights = [exp((value - maximum) / temperature) for value in values]
    return maximum + temperature * log(sum(weights))


def sweep(records, old_q, temperature):
    """Every record uses the previous sweep's values; gamma=1, step size=1."""
    updated = dict(old_q)
    for item in records:
        tail = state_value(old_q, item.successor, temperature)
        updated[item.state, item.action] = item.reward + tail
    return updated


def policy(q, temperature):
    probabilities = {}
    for state, actions in ACTIONS.items():
        if temperature == 0.0:
            greedy_action = max(actions, key=lambda action: q[state, action])
            probabilities[state] = {action: float(action == greedy_action)
                                    for action in actions}
        else:
            value = state_value(q, state, temperature)
            probabilities[state] = {
                action: exp((q[state, action] - value) / temperature)
                for action in actions
            }
    return probabilities


def evaluate(probabilities, temperature):
    """Enumerate real action sequences; report environment and regularized return."""
    reward_mean = 0.0
    soft_mean = 0.0
    for first in ACTIONS["S"]:
        for last in ACTIONS["J"]:
            mass = probabilities["S"][first] * probabilities["J"][last]
            if mass == 0.0:
                continue
            reward = sum(item.reward for item in collect((first, last)))
            reward_mean += mass * reward
            soft_mean += mass * (reward - temperature * log(mass))
    return reward_mean, soft_mean


def main():
    logs = [collect(("free", "stop")), collect(("toll", "deliver"))]
    records = [item for trajectory in logs for item in trajectory]
    pairs = [(state, action) for state, actions in ACTIONS.items() for action in actions]
    assert set(pairs) == {(item.state, item.action) for item in records}
    print("Logged returns:", [sum(item.reward for item in trajectory) for trajectory in logs])
    for temperature in (0.0, 1.0):
        q = dict.fromkeys(pairs, 0.0)
        print(f"alpha={temperature:g}; action order: {pairs}")
        for iteration in range(1, 3):
            q = sweep(records, q, temperature)
            row = ", ".join(f"{q[pair]:.6f}" for pair in pairs)
            print(f"  sweep {iteration}: {row}")
        probabilities = policy(q, temperature)
        reward_mean, soft_mean = evaluate(probabilities, temperature)
        print(f"  P(free)={probabilities['S']['free']:.6f}, "
              f"P(deliver)={probabilities['J']['deliver']:.6f}")
        print(f"  reward={reward_mean:.6f}; regularized return={soft_mean:.6f}")
        assert sweep(records, q, temperature) == q
        assert isclose(soft_mean, state_value(q, "S", temperature))
        if temperature == 0.0:
            assert reward_mean == 3.0
        else:
            assert isclose(probabilities["S"]["free"], 1 / (1 + exp(-2)))
            assert isclose(probabilities["J"]["deliver"], 1 / (1 + exp(-3)))

    # Change the outcome of one unobserved action. All remaining data agree.
    limited = [item for item in records if item.action != "deliver"]
    assert all(step(item.state, item.action, -3.0) == item for item in limited)
    print("Without (J,deliver), environments with delivery reward +3 and -3 "
          "give identical observed transitions and different greedy choices at J.")


if __name__ == "__main__":
    main()
