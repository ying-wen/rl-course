# Chapter 9: shared-parameter prediction

Rebuild with `python demos/course15_approximation.py` (NumPy + Matplotlib), or run the script using its absolute path from any directory.

The 19-state symmetric absorbing random walk starts at 10. Rewards are -1 on exit to 0 and +1 on exit to 20, otherwise 0; gamma=1. Three aggregation groups are 1–6, 7–13, 14–19. Every-visit MC and online semi-gradient TD use the same sampled episodes. `train()` never receives analytic values, the model, or the evaluation weights.

`task`, `sharing`, `projection`, `objective-fixedpoint`, and `weighting` are exact task/calculation figures. `values-visits` combines exact references with actual observed visit counts. `learning` uses actual 8-seed training runs (12,000 episodes/seed), with analytic references drawn separately. `neural-kernel` uses actual seed 0 MC-trained nonlinear parameters; the kernel is a local differential calculation. All these figures are available as PDF and PNG.

`results.json` includes the protocol, final weights, RMSEs and independent numerical checks. `training-data.npz` contains checkpoint parameters and state counts. `learning-checkpoints.csv` contains 3,856 rows, with seed, episode, algorithm, three weights and independently recomputed weighted value RMSE. Bands/error bars are between-seed sample SD.

`observable-objective.png` renders the pre-existing `assets/v8-mechanisms/observable-objective.pdf`; it is a separate exact observability example, not part of the new training experiment.

Reading/validation scope and exact source locations: `research/course15-fa-review.md`. The data are a teaching experiment for this feature class, sampling rule and step-size protocol, not an algorithm ranking across tasks.
