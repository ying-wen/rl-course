"""Chapter 9/11 calculations, diagrams, and a small REINFORCE experiment.

Run: python3 demos/core_v10_learning.py
All training observations are sampled from the two-decision environment.
Exact values and derivatives are used only for analysis and independent checks.
"""
from pathlib import Path
import json, os
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.patches import Circle, FancyArrowPatch
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'assets/core-v10'; OUT.mkdir(parents=True,exist_ok=True)
for f in filter(None,[os.environ.get('CRL_CJK_FONT'),'/System/Library/Fonts/STHeiti Light.ttc','/System/Library/Fonts/Supplemental/Songti.ttc','/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc']):
    if Path(f).is_file():
        font_manager.fontManager.addfont(f);plt.rcParams['font.family']=font_manager.FontProperties(fname=f).get_name();break
plt.rcParams.update({'font.size':12,'axes.spines.top':False,'axes.spines.right':False,'axes.unicode_minus':False,'pdf.fonttype':42})
T,R,G,I='#087e8b','#c65335','#ac7f23','#182e38'
checks={}
def save(fig,name):
    fig.tight_layout();fig.savefig(OUT/(name+'.pdf'));fig.savefig(OUT/(name+'.png'),dpi=170);plt.close(fig)
def sigmoid(theta):return 1/(1+np.exp(-np.asarray(theta)))
def objective(theta,gamma=1.):
    p,q=sigmoid(theta);return (1-p)+p*gamma*(1+2*q)
def gradient(theta,gamma=1.):
    p,q=sigmoid(theta)
    return np.array([p*(1-p)*(gamma*(1+2*q)-1),2*gamma*p*q*(1-q)])
def enumerate_estimates(theta,gamma=1.,baseline=(0.,0.)):
    p,q=sigmoid(theta);b0,b1=baseline
    probs=np.array([1-p,p*(1-q),p*q])
    # Three possible episodes. Each row sums the per-time score * return.
    estimates=np.array([[-p*(1-b0),0],[(1-p)*(gamma-b0),-gamma*q*(1-b1)],[(1-p)*(3*gamma-b0),gamma*(1-q)*(3-b1)]])
    return probs,estimates
th=np.array([0.,np.log(1/3)])
for gamma in [1.,.9]:
    fd=np.array([(objective(th+1e-6*e,gamma)-objective(th-1e-6*e,gamma))/2e-6 for e in np.eye(2)])
    for b in [(0.,0.),(1.25,1.5),(-2.,4.)]:
        prob,est=enumerate_estimates(th,gamma,b)
        assert np.allclose(prob@est,fd,atol=1e-8)
    checks['gradient_gamma_'+str(gamma)]={'analytic':gradient(th,gamma).tolist(),'finite_difference':fd.tolist(),'enumerated':(prob@est).tolist()}
# Geometric projection for A --0--> B --1--> terminal, gamma=.9.
fig,axs=plt.subplots(1,2,figsize=(10.8,3.45))
for ax,p in zip(axs,[.5,.9]):
    truth=np.array([.9,1.]);wmc=1-.1*p;wtd=(1-p)/(1-.9*p)
    ax.plot([0,1.08],[0,1.08],color=I,lw=1.5,label='可表示的预测 (w,w)')
    X,Y=np.meshgrid(np.linspace(.3,1.1,200),np.linspace(.3,1.1,200))
    Z=p*(X-.9)**2+(1-p)*(Y-1)**2
    ax.contour(X,Y,Z,levels=[.003,.01,.03,.08],colors=['#dbe4e1']*4,linewidths=1)
    ax.scatter(*truth,c=I,s=65,marker='*');ax.annotate('真实价值 (.9,1)',truth,xytext=(.50,1.08),arrowprops={'arrowstyle':'-','color':I},fontsize=10)
    ax.scatter(wmc,wmc,c=T,s=50);ax.annotate(f'MC = {wmc:.3f}',(wmc,wmc),xytext=(.33,.93),arrowprops={'arrowstyle':'->','color':T},color=T)
    ax.scatter(wtd,wtd,c=R,s=50);ax.annotate(f'TD = {wtd:.3f}',(wtd,wtd),xytext=(.70,.43),arrowprops={'arrowstyle':'->','color':R},color=R)
    tv=np.array([.9*wtd,1.]);ax.plot([wtd,tv[0],wtd],[wtd,tv[1],wtd],color=R,ls='--',lw=1)
    ax.scatter(*tv,c=R,s=20);ax.annotate('一次 Bellman 更新',tv,xytext=(.34,.73),fontsize=10,arrowprops={'arrowstyle':'-','color':R},color=R)
    ax.set(xlim=(.3,1.13),ylim=(.3,1.15),xlabel='A 的预测值',ylabel='B 的预测值',title=f'状态权重 ν(A)={p:g}')
    # Check TD fixed point by actual projection iteration, not solving its formula.
    w=0.
    for _ in range(1000):w=p*.9*w+(1-p)
    assert abs(w-wtd)<1e-10
save(fig,'projection-geometry')
# The same value parameters enter two computational paths in a TD residual.
x,xp=np.array([1.]),np.array([2.]);w=np.array([1.]);gam=.9;delta=float(gam*w@xp-w@x)
sg=delta*x;full=delta*(x-gam*xp)
fd=((.5*(gam*((w+1e-6)@xp)-(w+1e-6)@x)**2)-(.5*(gam*((w-1e-6)@xp)-(w-1e-6)@x)**2))/(2e-6)
assert np.allclose(full,-fd)
checks['semi_vs_full']={'delta':delta,'semi_gradient_direction':sg.tolist(),'negative_sample_loss_gradient':full.tolist()}
# Auxiliary weights estimate a normal-equation solution for fixed value weights.
X=np.array([[1.,0.],[1.,1.],[0.,1.]])
nu=np.array([.2,.5,.3]);target=np.array([1.,-.5,2.]);C=X.T@(nu[:,None]*X);d=X.T@(nu*target)
h=np.zeros(2)
for _ in range(2000):h+=.1*(d-C@h)
assert np.allclose(h,np.linalg.lstsq(np.sqrt(nu[:,None])*X,np.sqrt(nu)*target,rcond=None)[0])
checks['auxiliary_weights']=h.tolist()
# Exact episodic gradient outcomes, before taking any samples.
prob,est=enumerate_estimates(th)
fig,ax=plt.subplots(figsize=(7.5,3.5));colors=[I,T,R]
for k in range(3):
    ax.arrow(0,0,*est[k],length_includes_head=True,head_width=.075,color=colors[k],alpha=.7,width=.008)
    ax.annotate(['直接结束，概率 .5','继续后取1，概率 .375','继续后取3，概率 .125'][k],est[k],xytext=(8,4),textcoords='offset points',fontsize=11,color=colors[k])
g=prob@est;ax.scatter(*g,c=G,s=90,zorder=5);ax.annotate('期望梯度 (.125,.1875)',g,xytext=(12,-22),textcoords='offset points',color=G)
ax.axhline(0,c='#dbe4e1');ax.axvline(0,c='#dbe4e1');ax.set(xlim=(-.75,2.5),ylim=(-.5,2.65),xlabel='$\\theta_0$ 的更新方向',ylabel='$\\theta_1$ 的更新方向')
save(fig,'gradient-outcomes')
# Actual batch REINFORCE with a learned Monte Carlo state baseline.
# Policy and baseline are frozen while collecting each batch of 32 episodes.
seeds,batches,batch_size=30,300,32
hist=np.zeros((seeds,batches+1,5))
for seed in range(seeds):
    rng=np.random.default_rng(seed);theta=th.copy();v=np.zeros(2)
    for k in range(batches+1):
        p,q=sigmoid(theta);hist[seed,k]=[p,q,objective(theta),v[0],v[1]]
        if k==batches:break
        gp=np.zeros(2);vsum=np.zeros(2);count=np.zeros(2)
        for _ in range(batch_size):
            go=rng.random()<p
            if not go:
                G0=1.;gp[0]+=(G0-v[0])*(-p)
            else:
                high=rng.random()<q;G0=3. if high else 1.
                gp[0]+=(G0-v[0])*(1-p)
                gp[1]+=(G0-v[1])*(float(high)-q)
                vsum[1]+=G0;count[1]+=1
            vsum[0]+=G0;count[0]+=1
        # Both increments use the frozen values from collection.
        theta+=.2*gp/batch_size
        visited=count>0;v[visited]+=.2*(vsum[visited]/count[visited]-v[visited])
mean=hist.mean(0);se=hist.std(0,ddof=1)/np.sqrt(seeds)
fig,axs=plt.subplots(1,3,figsize=(11.3,3.1));steps=np.arange(batches+1)
for j,color,label in [(0,T,'继续的概率 p'),(1,R,'取3的概率 q')]:
    axs[0].plot(steps,mean[:,j],color=color,label=label);axs[0].fill_between(steps,mean[:,j]-se[:,j],mean[:,j]+se[:,j],color=color,alpha=.15)
axs[0].set(ylim=(0,1.04),ylabel='动作概率');axs[0].legend(fontsize=10)
axs[1].plot(steps,mean[:,2],color=T,label='当前策略的精确 J');axs[1].fill_between(steps,mean[:,2]-se[:,2],mean[:,2]+se[:,2],color=T,alpha=.2);axs[1].axhline(3,ls='--',color=I,label='最优回报 3');axs[1].set(ylabel='期望回报');axs[1].legend(fontsize=10)
axs[2].plot(steps,mean[:,4],color=R,label='学到的 $V(s_1)$');axs[2].plot(steps,1+2*mean[:,1],ls='--',color=I,label='当前策略的真实 $v_\\pi(s_1)$');axs[2].set(ylabel='价值');axs[2].legend(fontsize=9)
for ax in axs:ax.set_xlabel('批次（每批 32 回合）')
save(fig,'policy-learning')
np.savez_compressed(OUT/'policy-learning-runs.npz',history=hist,seeds=np.arange(seeds))
checks['experiment']={'seeds':seeds,'batches':batches,'episodes_per_batch':batch_size,'actor_step_size':.2,'baseline_step_size':.2,'initial_J':float(mean[0,2]),'final_mean_J':float(mean[-1,2]),'final_mean_probabilities':mean[-1,:2].tolist()}
# TD-based actor's direction as the critic's successor estimate changes.
z=np.linspace(0,3.2,180);fig,ax=plt.subplots(figsize=(7.5,2.6));ax.plot(z,.25*(z-1),c=T,lw=2);ax.axhline(0,c=I,lw=.8);ax.axvline(1.5,c=R,ls='--');ax.scatter([0,1.5],[-.25,.125],c=[I,R],zorder=5);ax.annotate('$V(s_1)$=0：减少继续',xy=(0,-.25),xytext=(.2,-.23),fontsize=11);ax.annotate('$V(s_1)$=$v_\\pi(s_1)$=1.5',xy=(1.5,.125),xytext=(1.7,.30),color=R,fontsize=11);ax.set(xlabel='评论者对后继状态的预测 $V(s_1)$',ylabel='$\\theta_0$ 的平均更新方向')
save(fig,'critic-direction')
checks['critic_direction']={'true':.125,'V1_zero':-.25}
(OUT/'checks.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2))
print(json.dumps(checks,ensure_ascii=False,indent=2))
