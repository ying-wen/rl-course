#!/usr/bin/env python3
"""Two-step prediction: representation, replay weighting and bootstrap.
Standard library only. Run from any directory; outputs next to this script.
"""
from pathlib import Path
import argparse, csv, json, math, random, statistics

GAMMA = .9
# Actual deterministic episode A --0--> B --1--> terminal.
EPISODE = [(0, 0., 1, 1), (1, 1., 2, 0)]
RETURNS = [GAMMA, 1.]

def features(s, rich):
    return ([float(s == 0), float(s == 1)] if rich else [1.]) if s < 2 else ([0., 0.] if rich else [0.])

def dot(a, b): return sum(x*y for x, y in zip(a, b))

def expected_update(w, p, rich, method):
    g = [0.] * len(w)
    for s, r, sp, m in EPISODE:
        x, xp = features(s, rich), features(sp, rich)
        target = RETURNS[s] if method == 'MC' else r + GAMMA*m*dot(w, xp)
        for j in range(len(w)): g[j] += (p if s == 0 else 1-p)*(target-dot(w,x))*x[j]
    return g

def train(p, rich, method, seed, steps):
    rng = random.Random(seed); w = [0.]*(2 if rich else 1); curve=[]
    for t in range(steps):
        s = 0 if rng.random() < p else 1
        _, r, sp, m = EPISODE[s]
        x = features(s, rich)
        target = RETURNS[s] if method == 'MC' else r + GAMMA*m*dot(w, features(sp, rich))
        delta = target-dot(w,x)
        alpha = .3/(1+t/50)**.65
        w = [a+alpha*delta*b for a,b in zip(w,x)]
        if t % 500 == 0 or t == steps-1:
            curve.append([t+1]+[dot(w,features(i,rich)) for i in [0,1]])
    return w,curve

def analytic(p, rich, method):
    if rich: return RETURNS[:]
    return [1-.1*p if method == 'MC' else (1-p)/(1-.9*p)]

def tests():
    checks={}
    # Independently backward-compute the full returns from the actual episode.
    g=0.; computed=[]
    for _,r,_,_ in reversed(EPISODE): g=r+GAMMA*g; computed.append(g)
    checks['return_backward']=max(abs(a-b) for a,b in zip(reversed(computed),RETURNS))
    for p in [.5,.9]:
        for rich in [False,True]:
            for method in ['MC','TD']:
                target=analytic(p,rich,method)
                checks[f'fixed_point_{p}_{rich}_{method}']=max(map(abs,expected_update(target,p,rich,method)))
                w=[0.]*len(target)
                for _ in range(10000): w=[a+.2*b for a,b in zip(w,expected_update(w,p,rich,method))]
                checks[f'expected_iteration_{p}_{rich}_{method}']=max(abs(a-b) for a,b in zip(w,target))
        # MC gradient is also independently checked with finite differences.
        w=.3; h=1e-6
        def loss(z): return .5*(p*(.9-z)**2+(1-p)*(1-z)**2)
        checks[f'mc_fd_{p}']=abs((loss(w+h)-loss(w-h))/(2*h)+expected_update([w],p,False,'MC')[0])
    # The best shared representation has unavoidable MSE; one-hot removes it.
    checks['representation_floor']=abs(.5*(.9-.95)**2+.5*(1-.95)**2-.0025)
    # Critic value error vs action derivative error, independent finite difference.
    def qhat(a): return -a*a+.01*math.sin(100*a)
    checks['action_derivative_fd']=abs((qhat(1e-7)-qhat(-1e-7))/(2e-7)-1.)
    assert max(checks.values()) < 1e-7, checks
    return checks

def svg(path, rows):
    # Scientific point plot: analytic values and actual stochastic estimates.
    W,H=1120,560; left,top=95,70; pw=920; ph=365
    y=lambda v:top+ph*(1.15-v)/1.15
    out=[f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" viewBox="0 0 {W} {H}"><rect width="100%" height="100%" fill="white"/>', '<g font-family="Arial,sans-serif" fill="#182e38">', '<text x="45" y="32" font-size="23">Same task: representation, replay distribution, bootstrap</text>']
    for v in [0,.25,.5,.75,1.]:
        out += [f'<path d="M{left} {y(v)}H{left+pw}" stroke="#dddddd"/>',f'<text x="50" y="{y(v)+5}" font-size="17">{v:.2f}</text>']
    colors={'MC':'#087e8b','TD':'#c65335'}
    for group,(p,rich) in enumerate([(.5,False),(.9,False),(.9,True)]):
        x=left+155+group*310
        out.append(f'<text x="{x}" y="470" text-anchor="middle" font-size="20">p(A)={p}, '+('one-hot' if rich else 'shared w')+'</text>')
        for method,dx in [('MC',-50),('TD',50)]:
            rr=[r for r in rows if r['p_A']==p and r['rich']==rich and r['method']==method]
            for state,offset in [(0,-12),(1,12)]:
                vals=[r['values'][state] for r in rr]; mean=statistics.mean(vals); sd=statistics.stdev(vals)
                xx=x+dx+offset; truth=RETURNS[state]
                out += [f'<path d="M{xx} {y(mean-sd)}V{y(mean+sd)}" stroke="{colors[method]}" stroke-width="3"/>',f'<circle cx="{xx}" cy="{y(mean)}" r="6" fill="{colors[method]}"/>',f'<path d="M{xx-7} {y(analytic(p,rich,method)[state if rich else 0])}h14" stroke="black" stroke-width="2"/>']
            out.append(f'<text x="{x+dx}" y="445" text-anchor="middle" font-size="17" fill="{colors[method]}">{method}</text>')
    out += ['<text x="45" y="515" font-size="18">Dots: actual runs, 5 seeds; bars: ±1 sample SD. Black ticks: analytic fixed point.</text>','<text x="45" y="542" font-size="18">Each pair: predictions at A, B. True values: v(A)=0.9, v(B)=1.0. 50,000 updates/run.</text>','</g></svg>']
    path.write_text('\n'.join(out))

def main():
    parser=argparse.ArgumentParser(); parser.add_argument('--steps',type=int,default=50000); parser.add_argument('--out',type=Path,default=Path(__file__).resolve().parent/'approximation-results'); args=parser.parse_args()
    assert args.steps>0; args.out.mkdir(parents=True,exist_ok=True)
    checks=tests(); rows=[]; curves=[]
    for p,rich in [(.5,False),(.9,False),(.9,True)]:
        for method in ['MC','TD']:
            for seed in range(5):
                w,curve=train(p,rich,method,seed,args.steps)
                values=[dot(w,features(i,rich)) for i in [0,1]]
                rows.append(dict(p_A=p,rich=rich,method=method,seed=seed,w=w,values=values,analytic=analytic(p,rich,method)))
                curves += [[p,rich,method,seed]+c for c in curve]
    result=dict(task='A --0--> B --1--> terminal',gamma=GAMMA,steps=args.steps,seeds=list(range(5)),state_sampling='independent replay resampling, P(A)=p; not the altered environment dynamics',checks=checks,runs=rows)
    (args.out/'results.json').write_text(json.dumps(result,indent=2))
    with (args.out/'curves.csv').open('w') as f:
        writer=csv.writer(f); writer.writerow(['p_A','rich','method','seed','updates','V_A','V_B']); writer.writerows(curves)
    svg(args.out/'comparison.svg',rows)
    print(json.dumps({'checks':len(checks),'max_residual':max(checks.values()),'runs':len(rows),'steps_per_run':args.steps,'out':str(args.out)},indent=2))
    for p,rich in [(.5,False),(.9,False),(.9,True)]:
        print(p,'one-hot' if rich else 'shared',[(m, [round(statistics.mean(r['values'][s] for r in rows if r['p_A']==p and r['rich']==rich and r['method']==m),5) for s in [0,1]]) for m in ['MC','TD']])
if __name__=='__main__': main()
