"""Chapter 9: model-free prediction with shared parameters.

Run from any directory: python /.../demos/course15_approximation.py
Dependencies: numpy, matplotlib. Outputs: assets/course15-fa/.
The learner receives sampled transitions/returns, never the model or true values.
Analytic references and independent checks live outside train().
"""
from pathlib import Path
import json
import csv
import random
import argparse
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

OUT = Path(__file__).resolve().parents[1] / "assets" / "course15-fa"
STATES = np.arange(1, 20)
GROUP = np.digitize(STATES, [7, 14])
X = np.eye(3)[GROUP]
COLORS = ["#087E8B", "#C4942A", "#C65335"]
plt.rcParams.update({"font.size": 11, "axes.spines.top": False,
                     "axes.spines.right": False, "pdf.fonttype": 42})


def model_reference():
    """Only the evaluator uses this finite model."""
    p = np.zeros((19, 19))
    r = np.zeros(19)
    r[0], r[-1] = -.5, .5
    for i in range(19):
        for j in [i - 1, i + 1]:
            if 0 <= j < 19:
                p[i, j] = .5
    h = np.eye(19)[9]
    visits = np.linalg.solve(np.eye(19) - p.T, h)
    mu = visits / visits.sum()
    v = np.linalg.solve(np.eye(19) - p, r)
    c = X.T @ (mu[:, None] * X)
    a = X.T @ (mu[:, None] * ((np.eye(19) - p) @ X))
    b = X.T @ (mu * r)
    mc = np.linalg.solve(c, X.T @ (mu * v))
    td = np.linalg.solve(a, b)
    return p, r, visits, mu, v, c, a, b, mc, td


def neural_value_grad(w):
    """Two-parameter smooth predictor; input is the observed state coordinate."""
    u = (STATES - 10) / 10
    t = np.tanh(w[1] * u)
    return w[0] * t, np.stack([t, w[0] * u * (1 - t * t)], axis=1)


def train(episodes, seed, record_every=50):
    """Real episodic experience, every-visit MC and online semi-gradient TD.

    MC uses 1/N per group, exactly maintained as a running sample mean.
    TD uses 0.15/(1+N_group/1000)^0.65. Both start from zero.
    The optional tanh model uses an episode's *sum* of MC gradients / 100,
    evaluated at frozen episode-start weights, not a per-episode mean.
    100 is a fixed scale, not a label or a model-dependent target.
    """
    rng = random.Random(seed)
    mc, td = np.zeros(3), np.zeros(3)
    mc_count, td_count = np.zeros(3), np.zeros(3)
    mc_sum, state_count = np.zeros(3), np.zeros(19)
    nw = np.array([.2, .7])
    checkpoints = [0]
    hist_mc, hist_td, hist_n = [mc.copy()], [td.copy()], [nw.copy()]
    lengths = []
    for ep in range(1, episodes + 1):
        s, trajectory = 10, []
        while True:
            nxt = s + (1 if rng.random() < .5 else -1)
            terminal = nxt in (0, 20)
            reward = (-1. if nxt == 0 else 1.) if terminal else 0.
            g = 0 if s < 7 else (1 if s < 14 else 2)
            future = 0. if terminal else td[0 if nxt < 7 else (1 if nxt < 14 else 2)]
            delta = reward + future - td[g]
            td_count[g] += 1
            alpha = .15 / (1 + td_count[g] / 1000) ** .65
            td[g] += alpha * delta
            trajectory.append(s)
            if terminal:
                break
            s = nxt
        # gamma=1 and only the final reward is nonzero: every G_t=reward.
        counts = np.bincount(trajectory, minlength=21)[1:20]
        group_count = X.T @ counts
        mc_count += group_count
        mc_sum += reward * group_count
        np.divide(mc_sum, mc_count, out=mc, where=mc_count > 0)
        state_count += counts
        if seed == 0:
            pred, grad = neural_value_grad(nw)
            direction = grad.T @ (counts * (reward - pred)) / 100
            nw += .02 / (1 + ep / 3000) ** .5 * direction
        lengths.append(len(trajectory))
        if ep % record_every == 0 or ep == episodes:
            checkpoints.append(ep)
            hist_mc.append(mc.copy()); hist_td.append(td.copy()); hist_n.append(nw.copy())
    return {"episodes": np.array(checkpoints), "mc": np.array(hist_mc),
            "td": np.array(hist_td), "neural": np.array(hist_n),
            "counts": state_count, "mean_length": np.mean(lengths)}


def save(fig, name):
    fig.savefig(OUT / (name + ".pdf"), bbox_inches="tight")
    fig.savefig(OUT / (name + ".png"), dpi=170, bbox_inches="tight")
    plt.close(fig)


def plot_sharing():
    """One update at state 4: one-hot features versus three aggregated groups."""
    from matplotlib import font_manager
    rc = {}
    for font in ["/System/Library/Fonts/PingFang.ttc", "/System/Library/Fonts/STHeiti Light.ttc"]:
        if Path(font).exists():
            font_manager.fontManager.addfont(font)
            rc = {"font.family": ["DejaVu Sans", font_manager.FontProperties(fname=font).get_name()],
                  "axes.unicode_minus": False}
            break
    with plt.rc_context(rc):
        fig, axes = plt.subplots(1,2,figsize=(10.8,3.2))
        for ax, phi, title in zip(axes,[np.eye(19),X],["19 个独立参数（one-hot）", "3 个共享参数（聚合）"]):
            ax.bar(STATES, .2*(phi@phi[3]), color=[COLORS[g] for g in GROUP])
            ax.scatter([4],[.2],marker="*",s=120,color="black",label="采样状态 4")
            ax.set(xlabel="状态",ylabel="预测改变量",ylim=(-.02,.25),title=title,xticks=[1,4,7,10,13,16,19]);ax.legend(fontsize=9)
        fig.tight_layout();save(fig,"sharing")


def checks(ref, runs):
    p, r, visits, mu, v, c, a, b, mc, td = ref
    # Independent gambler's-ruin and visit-flow formulas.
    assert np.max(np.abs(v - (STATES / 10 - 1))) < 1e-12
    assert np.max(np.abs(visits - np.minimum(STATES, 20 - STATES))) < 1e-11
    assert abs(visits.sum() - 100) < 1e-11
    assert np.max(np.abs(mc - [-17/30, 0, 17/30])) < 1e-12
    assert np.max(np.abs(td - [-1/7, 0, 1/7])) < 1e-12
    # Independent enumeration of all possible one-step TD updates.
    w = np.array([-.4, .2, .7]); expected = np.zeros(3)
    for s in range(1, 20):
        for nxt in (s - 1, s + 1):
            reward = -1. if nxt == 0 else (1. if nxt == 20 else 0.)
            target = reward + (X[nxt-1] @ w if 0 < nxt < 20 else 0.)
            expected += mu[s-1] * .5 * (target - X[s-1] @ w) * X[s-1]
    assert np.max(np.abs(expected - (b-a@w))) < 1e-13
    # One-hot limit: both model equations recover the same true value.
    assert np.max(np.abs(np.linalg.solve(np.diag(mu) @ (np.eye(19)-p), mu*r)-v)) < 1e-12
    # Finite differences check the changing nonlinear gradient directions.
    max_fd = 0.
    for nw in [runs[0]["neural"][0], runs[0]["neural"][-1]]:
        _, grad = neural_value_grad(nw)
        for j in range(2):
            d = np.eye(2)[j] * 1e-6
            fd = (neural_value_grad(nw+d)[0]-neural_value_grad(nw-d)[0])/2e-6
            max_fd = max(max_fd, float(np.max(np.abs(fd-grad[:, j]))))
    assert max_fd < 1e-8
    # Analytic MC value-error gradient against finite differences (evaluator).
    def loss(q):
        return .5 * mu @ ((v-X@q)**2)
    fd=np.array([(loss(w+np.eye(3)[j]*1e-6)-loss(w-np.eye(3)[j]*1e-6))/2e-6 for j in range(3)])
    mc_gradient_error=float(np.max(np.abs(fd-X.T@(mu*(X@w-v)))))
    assert mc_gradient_error < 1e-8
    # Boundary 6 -> 7, reward 0: full gradient also differentiates the target.
    x, xp=X[5],X[6]
    def sample_loss(q): return .5 * ((xp-x)@q)**2
    fd=np.array([(sample_loss(w+np.eye(3)[j]*1e-6)-sample_loss(w-np.eye(3)[j]*1e-6))/2e-6 for j in range(3)])
    residual_gradient_error=float(np.max(np.abs(fd-((xp-x)@w)*(xp-x))))
    assert residual_gradient_error < 1e-8
    # Full sample-residual gradient differs from the semi-gradient direction.
    # A transition inside a shared group has x=x', r=0, gamma=1: zero TD update.
    assert np.allclose(X[7]-X[8], 0)
    empirical = sum(z["counts"] for z in runs)
    empirical /= empirical.sum()
    return {"analytic_value_error": float(np.max(np.abs(v-(STATES/10-1)))),
            "analytic_visits_error": float(np.max(np.abs(visits-np.minimum(STATES,20-STATES)))),
            "td_enumeration_error": float(np.max(np.abs(expected-(b-a@w)))),
            "jacobian_finite_difference_error": max_fd,
            "mc_gradient_finite_difference_error": mc_gradient_error,
            "sample_residual_gradient_finite_difference_error": residual_gradient_error,
            "empirical_mu_max_error": float(np.max(np.abs(empirical-mu)))}


def figures(ref, runs):
    p, r, visits, mu, v, c, a, b, mc, td = ref
    fig, ax = plt.subplots(figsize=(11, 2.7))
    for s in range(21):
        color = "#6B7277" if s in (0,20) else COLORS[GROUP[s-1]]
        ax.scatter(s, 0, s=180 if s in (0,20) else 125, color=color, zorder=3)
        ax.text(s, -.22, str(s), ha="center", fontsize=9)
    for s in range(20):
        ax.annotate("", (s+.77,0), (s+.23,0), arrowprops={"arrowstyle":"<->", "color":"#889399"})
    ax.annotate("start", (10,.1), (10,.7), ha="center", arrowprops={"arrowstyle":"->"})
    ax.text(0,.45,"terminal\nreward -1",ha="center"); ax.text(20,.45,"terminal\nreward +1",ha="center")
    for x, text in [(3.5,"group 1: states 1–6"),(10,"group 2: states 7–13"),(16.5,"group 3: states 14–19")]:
        ax.text(x,-.65,text,ha="center",color=COLORS[0 if x<7 else (1 if x<14 else 2)])
    ax.text(10,-1.1,"left / right: 1/2 each  |  other rewards: 0  |  gamma = 1",ha="center")
    ax.set(xlim=(-1.1,21.1),ylim=(-1.25,1));ax.axis("off");save(fig,"task")
    plot_sharing()
    empirical = sum(z["counts"] for z in runs); empirical/=empirical.sum()
    fig,axes=plt.subplots(1,2,figsize=(10.8,3.5))
    axes[0].plot(STATES,v,"k.-",label="true value: s/10 - 1")
    axes[0].step(STATES,X@mc,where="mid",color=COLORS[0],lw=2,label="best 3-group fit")
    axes[0].set(xlabel="state",ylabel="value");axes[0].legend(fontsize=9)
    axes[1].bar(STATES,mu,color=[COLORS[g] for g in GROUP],alpha=.65,label="analytic visit fraction")
    axes[1].plot(STATES,empirical,"k.",label="observed visits, all seeds")
    axes[1].set(xlabel="state",ylabel="mu(s)");axes[1].legend(fontsize=9)
    fig.tight_layout();save(fig,"values-visits")
    fig,axes=plt.subplots(1,2,figsize=(10.8,3.5),sharey=True)
    for ax, target, w, title in [(axes[0],v,mc,"MC: project the true value"),(axes[1],r+p@(X@td),td,"TD: project its own Bellman backup")]:
        ax.plot(STATES,target,"k.-",label="vector being projected")
        ax.step(STATES,X@w,where="mid",lw=2,color=COLORS[0],label="weighted projection")
        for s in range(19):ax.plot([s+1,s+1],[target[s],(X@w)[s]],color=COLORS[GROUP[s]],alpha=.6,lw=1)
        ax.set(xlabel="state",title=title);ax.legend(fontsize=8)
    axes[0].set_ylabel("value / backup");fig.tight_layout();save(fig,"projection")
    eps=runs[0]["episodes"]
    fig,axes=plt.subplots(1,2,figsize=(10.8,3.5))
    final={}
    for name,color,w in [("mc",COLORS[0],mc),("td",COLORS[2],td)]:
        pred=np.array([run[name]@X.T for run in runs]);err=np.sqrt(((pred-v)**2*mu).sum(-1))
        mean=err.mean(0);sd=err.std(0,ddof=1)
        axes[0].plot(eps,mean,color=color,label=name.upper()+" actual learning")
        axes[0].fill_between(eps,mean-sd,mean+sd,color=color,alpha=.15)
        axes[0].axhline(np.sqrt(mu@((X@w-v)**2)),color=color,ls="--",lw=1)
        mean=pred[:,-1].mean(0);sd=pred[:,-1].std(0,ddof=1)
        axes[1].errorbar(STATES+(-.12 if name=="mc" else .12),mean,yerr=sd,fmt="o",ms=3,color=color,label=name.upper()+" learned mean +/- SD")
        axes[1].step(STATES,X@w,where="mid",color=color,ls="--",lw=1)
        final[name]={"mean_weights":np.mean([z[name][-1] for z in runs],0).tolist(),"weight_sd":np.std([z[name][-1] for z in runs],0,ddof=1).tolist(),"mean_rmse":float(err[:,-1].mean()),"reference_rmse":float(np.sqrt(mu@((X@w-v)**2)))}
    axes[0].set(xlabel="training episodes",ylabel="weighted value RMSE",xscale="symlog",xlim=(0,eps[-1]));axes[0].legend(fontsize=8)
    axes[1].plot(STATES,v,"k-",label="true value");axes[1].set(xlabel="state",ylabel="final prediction");axes[1].legend(fontsize=8)
    fig.tight_layout();save(fig,"learning")
    fig,axes=plt.subplots(1,2,figsize=(10.8,3.4))
    grid=np.linspace(-.1,.85,220)
    ve=[];flow=[]
    for k in grid:
        w=np.array([-k,0,k]);ve.append(mu@((v-X@w)**2));flow.append((b-a@w)[2])
    axes[0].plot(grid,ve,color=COLORS[0]);axes[0].axvline(mc[2],ls="--",color=COLORS[0]);axes[0].axvline(td[2],ls="--",color=COLORS[2]);axes[0].set(xlabel="c in weights (-c, 0, c)",ylabel="weighted value error")
    axes[1].plot(grid,flow,color=COLORS[2]);axes[1].axhline(0,color="gray",lw=.7);axes[1].axvline(mc[2],ls="--",color=COLORS[0],label="MC: c = 17/30");axes[1].axvline(td[2],ls="--",color=COLORS[2],label="TD: c = 1/7");axes[1].set(xlabel="c in weights (-c, 0, c)",ylabel="mean TD change in right weight / alpha");axes[1].legend(fontsize=9)
    fig.tight_layout();save(fig,"objective-fixedpoint")
    fig,axes=plt.subplots(1,2,figsize=(10.8,3.3),sharey=True)
    for ax,weights,title in zip(axes,[mu,np.ones(19)/19],["trajectory visits: mu(s)","uniform state sampling: 1/19"]):
        cm=X.T@(weights[:,None]*X);am=X.T@(weights[:,None]*((np.eye(19)-p)@X))
        wm=np.linalg.solve(cm,X.T@(weights*v));wt=np.linalg.solve(am,X.T@(weights*r))
        ax.plot(STATES,v,"k--",label="same true value")
        ax.step(STATES,X@wm,where="mid",color=COLORS[0],label="MC projection")
        ax.step(STATES,X@wt,where="mid",color=COLORS[2],label="TD fixed point")
        ax.set(title=title,xlabel="state");ax.legend(fontsize=8)
    axes[0].set_ylabel("analytic prediction");fig.tight_layout();save(fig,"weighting")
    fig=plt.figure(figsize=(11,3.1))
    grid=fig.add_gridspec(1,4,width_ratios=[1,1,.05,1.15],wspace=.6)
    axes=[fig.add_subplot(grid[0,0]),fig.add_subplot(grid[0,1]),fig.add_subplot(grid[0,3])]
    cax=fig.add_subplot(grid[0,2])
    kernels=[]
    for w in [runs[0]["neural"][0],runs[0]["neural"][-1]]:
        _,j=neural_value_grad(w);kernels.append(j@j.T)
    limit=max(np.abs(k).max() for k in kernels)
    for ax,k,title in zip(axes[:2],kernels,["before MC training","after MC training"]):
        im=ax.imshow(k,origin="lower",extent=(.5,19.5,.5,19.5),cmap="RdBu_r",vmin=-limit,vmax=limit)
        ax.set(title=title,xlabel="sampled state",ylabel="affected state",xticks=[1,10,19],yticks=[1,10,19])
    fig.colorbar(im,cax=cax)
    axes[2].plot(STATES,v,"k--",label="true value")
    for w,color,label in [(runs[0]["neural"][0],"gray","initial"),(runs[0]["neural"][-1],COLORS[0],"trained on returns")]:axes[2].plot(STATES,neural_value_grad(w)[0],color=color,label=label)
    axes[2].set(xlabel="state",title="value function");axes[2].legend(fontsize=8)
    save(fig,"neural-kernel")
    return final


def main():
    parser=argparse.ArgumentParser();parser.add_argument("--episodes",type=int,default=12000);parser.add_argument("--seeds",type=int,default=8)
    args=parser.parse_args()
    if args.episodes < 1 or args.seeds < 2:
        parser.error("use at least one episode and two seeds (plots report sample SD)")
    OUT.mkdir(parents=True,exist_ok=True)
    ref=model_reference();runs=[train(args.episodes,seed) for seed in range(args.seeds)]
    validation=checks(ref,runs);final=figures(ref,runs)
    report={"protocol":{"episodes_per_seed":args.episodes,"seeds":list(range(args.seeds)),"start":10,"gamma":1,"groups":[[1,6],[7,13],[14,19]],"mc_step":"1 / group visits","td_step":"0.15/(1+group visits/1000)^0.65","bands":"sample SD across independent seeds","same_experience_for_mc_td":True},"analytic":{"mu":ref[3].tolist(),"mc_weights":ref[-2].tolist(),"td_weights":ref[-1].tolist(),"expected_episode_length":float(ref[2].sum())},"training":final,"checks":validation,"neural":{"initial":runs[0]["neural"][0].tolist(),"final":runs[0]["neural"][-1].tolist(),"seed":0,"note":"actual episode-return gradient updates; no true-value labels"},"mean_episode_lengths":[float(z["mean_length"]) for z in runs]}
    (OUT/"results.json").write_text(json.dumps(report,indent=2)+"\n")
    np.savez_compressed(OUT/"training-data.npz",episodes=runs[0]["episodes"],mc=np.array([z["mc"] for z in runs]),td=np.array([z["td"] for z in runs]),neural=runs[0]["neural"],counts=np.array([z["counts"] for z in runs]))
    with (OUT/"learning-checkpoints.csv").open("w",newline="") as f:
        writer=csv.writer(f);writer.writerow(["seed","episode","method","w1","w2","w3","weighted_value_rmse"])
        for seed,run in enumerate(runs):
            for method in ["mc","td"]:
                for ep,w in zip(run["episodes"],run[method]):
                    writer.writerow([seed,int(ep),method,*w,float(np.sqrt(ref[3]@((X@w-ref[4])**2)))])
    print(json.dumps(report,indent=2))


if __name__ == "__main__":
    main()
