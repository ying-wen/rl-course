"""Small, exact calculations for chapters 9--11. Python 3 + numpy + matplotlib.

Run from any directory: python demos/value_policy_mechanisms.py
Outputs are mathematical examples, not Atari training results. Each check uses
an independent identity (finite differences, enumeration, or mass conservation).
"""
from pathlib import Path
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'assets' / 'v8-mechanisms'
OUT.mkdir(parents=True, exist_ok=True)
plt.rcParams.update({'font.size': 12, 'axes.spines.top': False,
                     'axes.spines.right': False, 'savefig.bbox': 'tight'})
TEAL, RED, BLUE = '#087e8b', '#c65335', '#4d6893'


def finite_difference(f, x, eps=1e-6):
    result = np.zeros_like(x, dtype=float)
    for k in range(x.size):
        e = np.zeros_like(x); e.flat[k] = eps
        result.flat[k] = (f(x + e) - f(x - e)) / (2 * eps)
    return result


def categorical_project(z, p, reward, discount):
    """Project r + gamma Z onto equally spaced z. Preserve exact-bin mass.

    Clipping at the support endpoints changes the mean; interpolation inside
    the support preserves it. `discount=0` represents a terminal transition.
    """
    target = np.clip(reward + discount * z, z[0], z[-1])
    position = (target - z[0]) / (z[1] - z[0])
    lower, upper = np.floor(position).astype(int), np.ceil(position).astype(int)
    result = np.zeros_like(p, dtype=float)
    for j in range(len(z)):
        if lower[j] == upper[j]:
            result[lower[j]] += p[j]
        else:
            result[lower[j]] += p[j] * (upper[j] - position[j])
            result[upper[j]] += p[j] * (position[j] - lower[j])
    return result


def quantile_loss(theta, tau, y, probs):
    residual = y - theta
    return np.sum(probs * (tau - (residual < 0)) * residual)


def exact_policy_gradient(logits):
    """Three live states, two actions, discounted continuing MDP.

    Solve the value equations exactly. Compare the occupancy-weighted policy
    gradient with a finite-difference derivative of the start-state value.
    """
    gamma = .85
    transition = np.array([[[.7,.3,0],[0,.2,.8]],
                           [[.2,.8,0],[0,.3,.7]],
                           [[.4,0,.6],[.1,.7,.2]]])
    rewards = np.array([[.2,0],[.4,1.1],[1.2,.3]])
    pi1 = 1 / (1 + np.exp(-logits))
    pi = np.stack([1-pi1, pi1], axis=1)
    p_pi = np.einsum('sa,san->sn', pi, transition)
    r_pi = (pi * rewards).sum(1)
    value = np.linalg.solve(np.eye(3)-gamma*p_pi, r_pi)
    mu = np.array([1.,0.,0.])
    # rho counts discounted visits; it sums to 1/(1-gamma).
    rho = np.linalg.solve((np.eye(3)-gamma*p_pi).T, mu)
    q = rewards + gamma * np.einsum('san,n->sa', transition, value)
    grad = rho * pi1 * (1-pi1) * (q[:,1]-q[:,0])
    return float(mu @ value), grad, rho, q


def run():
    checks = {}
    # MSPBE = (b-Aw)^T C^{-1}(b-Aw). No simulator noise in this check.
    phi = np.array([[1.,0],[1.,1],[1.,2]])
    p = np.array([[.2,.8,0],[0,.3,.7],[.6,0,.4]])
    nu = np.array([.6,.3,.1]); reward = np.array([0.,1.,2.])
    c = phi.T @ np.diag(nu) @ phi
    a = phi.T @ np.diag(nu) @ (np.eye(3)-.9*p) @ phi
    b = phi.T @ (nu*reward); w = np.array([.2,-.1])
    loss = lambda w: .5*(b-a@w) @ np.linalg.solve(c, b-a@w)
    h = np.linalg.solve(c, b-a@w)
    np.testing.assert_allclose(-a.T@h, finite_difference(loss,w), atol=1e-8)
    checks['mspbe_gradient_max_error'] = float(np.max(abs(-a.T@h-finite_difference(loss,w))))

    # Two latent processes yield identical iid observed rewards but different VE.
    # gamma=0: one state emits 0/2; two aliased states emit their state reward.
    ws = np.linspace(-.5,2.5,180)
    ve_one=(1-ws)**2; ve_two=(ws**2+(2-ws)**2)/2
    fig, ax=plt.subplots(figsize=(9,3.3))
    ax.plot(ws,ve_one,label='latent VE: one state',color=TEAL,lw=2)
    ax.plot(ws,ve_two,label='latent VE: two aliased states',color=RED,lw=2)
    ax.plot(ws,ve_two,'--',color=BLUE,label='observable return MSE (both)',lw=2)
    ax.axvline(1,color='gray',ls=':');ax.set(xlabel='constant prediction w',ylabel='squared error')
    ax.legend(fontsize=10);fig.savefig(OUT/'observable-objective.pdf');plt.close(fig)
    checks['identifiable_minimizer'] = 1.0

    # Nonuniform replay changes an unweighted expected update.
    gradients=np.array([1.,-2.,4.,-1.]); prob=np.array([.1,.2,.6,.1])
    correction=1/(len(prob)*prob)
    corrected=np.sum(prob*correction*gradients)
    np.testing.assert_allclose(corrected,gradients.mean())
    checks['replay_updates']={'uniform':float(gradients.mean()),
                             'prioritized_unweighted':float(prob@gradients),
                             'prioritized_corrected':float(corrected)}
    fig,axs=plt.subplots(1,2,figsize=(10,3.4))
    x=np.arange(4);axs[0].bar(x-.16,np.full(4,.25),.32,label='uniform',color=TEAL)
    axs[0].bar(x+.16,prob,.32,label='prioritized',color=RED)
    axs[0].set(xlabel='stored transition i',ylabel='sampling probability',xticks=x);axs[0].legend()
    axs[1].bar(['uniform','PER raw','PER corrected'],[gradients.mean(),prob@gradients,corrected],color=[TEAL,RED,BLUE])
    axs[1].set(ylabel='expected scalar update');fig.tight_layout();fig.savefig(OUT/'replay-correction.pdf');plt.close(fig)

    z=np.arange(-2.,3.); probs=np.array([.1,.2,.4,.2,.1])
    projected=categorical_project(z,probs,.4,.7)
    np.testing.assert_allclose(projected.sum(),1)
    np.testing.assert_allclose(z@projected,.4+.7*(z@probs))
    np.testing.assert_allclose(categorical_project(z,probs,1.,0),[0,0,0,1,0])
    rng=np.random.default_rng(901)
    for _ in range(100):
        q=rng.dirichlet(np.ones(5)); r=rng.uniform(-3,3); d=rng.uniform(0,1)
        mass=categorical_project(z,q,r,d)
        np.testing.assert_allclose(mass.sum(),1,atol=1e-12)
        assert np.all(mass>=-1e-12)
        np.testing.assert_allclose(z@mass,q@np.clip(r+d*z,-2,2),atol=1e-12)
    fig,axs=plt.subplots(1,3,figsize=(11,3.3),sharey=True)
    for ax,x,y,title in zip(axs,[z,.4+.7*z,z],[probs,probs,projected],
                          ['next return Z','target 0.4 + 0.7 Z','projected target']):
        ax.vlines(x,0,y,color=TEAL,lw=3);ax.scatter(x,y,color=RED,s=28)
        ax.set(title=title,xlabel='return',ylim=(0,.55));ax.set_xticks(z)
    axs[0].set_ylabel('probability mass');fig.tight_layout();fig.savefig(OUT/'categorical-projection.pdf');plt.close(fig)
    checks['categorical_projection']={'mass':float(projected.sum()),'mean':float(z@projected),'random_checks':100}

    y=np.array([-2.,0.,3.]); yp=np.array([.2,.5,.3]); xs=np.linspace(-3,4,300)
    fig,ax=plt.subplots(figsize=(8.8,3.3))
    for tau,col in zip([.1,.5,.9],[TEAL,BLUE,RED]):
        ax.plot(xs,[quantile_loss(t,tau,y,yp) for t in xs],label=f'tau = {tau}',color=col,lw=2)
        t=.75
        numerical=(quantile_loss(t+1e-6,tau,y,yp)-quantile_loss(t-1e-6,tau,y,yp))/2e-6
        np.testing.assert_allclose(numerical,np.sum(yp*(y<t))-tau,atol=1e-8)
    ax.set(xlabel='predicted quantile',ylabel='expected pinball loss');ax.legend();fig.savefig(OUT/'quantile-loss.pdf');plt.close(fig)
    checks['quantile_derivatives']=3

    logits=np.array([-.4,.7,-.2]); objective,grad,rho,q=exact_policy_gradient(logits)
    numerical=finite_difference(lambda x:exact_policy_gradient(x)[0],logits)
    np.testing.assert_allclose(grad,numerical,atol=1e-8)
    checks['policy_gradient']={'objective':objective,'analytic':grad.tolist(),'finite_difference':numerical.tolist(),
                               'discounted_visits':rho.tolist()}
    fig,axs=plt.subplots(1,2,figsize=(10,3.4))
    axs[0].bar(np.arange(3),rho,color=TEAL);axs[0].set(xlabel='state',ylabel='discounted expected visits',xticks=np.arange(3))
    axs[1].bar(np.arange(3)-.16,grad,.32,label='policy gradient',color=TEAL)
    axs[1].bar(np.arange(3)+.16,numerical,.32,label='finite difference',color=RED)
    axs[1].set(xlabel='parameter (one logit per state)',ylabel='derivative',xticks=np.arange(3));axs[1].legend()
    fig.tight_layout();fig.savefig(OUT/'policy-gradient-check.pdf');plt.close(fig)

    # Exact baseline variance for two-action REINFORCE, one logit, fixed state.
    p=.2; rewards=np.array([0.,1.]); policy=np.array([1-p,p]); score=np.array([-p,1-p])
    optimal=float(np.sum(policy*score**2*rewards)/np.sum(policy*score**2))
    bs=np.linspace(-.2,1.2,200)
    variance=[np.sum(policy*(score*(rewards-b))**2)-(p*(1-p))**2 for b in bs]
    fig,ax=plt.subplots(figsize=(9,3.3));ax.plot(bs,variance,color=TEAL,lw=2)
    ax.axvline(p,color=BLUE,ls='--',label='value baseline E[R] = 0.2')
    ax.axvline(optimal,color=RED,ls='--',label='variance-minimizing baseline = 0.8')
    ax.set(xlabel='action-independent baseline b',ylabel='gradient variance');ax.legend(fontsize=10)
    fig.savefig(OUT/'baseline-variance.pdf');plt.close(fig)
    np.testing.assert_allclose(optimal,.8)
    checks['optimal_baseline']=optimal

    ratios=np.linspace(.4,1.6,200);fig,axs=plt.subplots(1,2,figsize=(10,3.3))
    for ax,adv in zip(axs,[1.,-1.]):
        unclipped=ratios*adv; clipped=np.minimum(unclipped,np.clip(ratios,.8,1.2)*adv)
        ax.plot(ratios,unclipped,'--',color=BLUE,label='r A')
        ax.plot(ratios,clipped,color=TEAL,lw=2,label='PPO surrogate')
        ax.axvline(.8,color='gray',ls=':');ax.axvline(1.2,color='gray',ls=':')
        ax.set(title=f'advantage = {adv:+.0f}',xlabel='probability ratio r',ylabel='objective contribution');ax.legend(fontsize=10)
    fig.tight_layout();fig.savefig(OUT/'ppo-clipping.pdf');plt.close(fig)
    (ROOT/'demos'/'value-policy-results.json').write_text(json.dumps(checks,indent=2)+'\n')
    print(json.dumps(checks,indent=2))


if __name__=='__main__':
    run()
