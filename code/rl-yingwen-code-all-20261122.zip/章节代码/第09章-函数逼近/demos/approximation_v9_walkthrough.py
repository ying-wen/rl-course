"""Exact, inspectable examples for Chapter 9. Run from any directory.

The figures distinguish an actual parameter update, an analytic counterexample,
and previously recorded Monte Carlo/TD runs. No figure is a claimed benchmark.
"""
from pathlib import Path
import json
import os
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'assets/v9-approximation'
OUT.mkdir(parents=True, exist_ok=True)
font_candidates = [os.environ.get('CRL_CJK_FONT', ''),
                   '/System/Library/Fonts/PingFang.ttc',
                   '/System/Library/Fonts/STHeiti Medium.ttc',
                   '/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc']
for font in filter(None, font_candidates):
    if Path(font).exists():
        font_manager.fontManager.addfont(font)
        plt.rcParams['font.family'] = font_manager.FontProperties(fname=font).get_name()
        break
plt.rcParams.update({'font.size': 12, 'axes.spines.top': False, 'axes.spines.right': False,
                     'axes.unicode_minus': False, 'pdf.fonttype': 42})
TEAL, RED, INK = '#087E8B', '#C65335', '#182E38'
checks = {}
# One ReLU unit. Coordinates are parameters (output weight, input weight, bias).
x = np.array([-1., 0., 1.])
w = np.array([1., 1., -.2])
def value(w, x):
    return w[0] * np.maximum(w[1] * x + w[2], 0.)
def jacobian(w, x):
    z = w[1] * x + w[2]
    active = z > 0
    return np.column_stack((np.maximum(z, 0), w[0] * x * active, w[0] * active))
# A genuine squared-error update at x=1, fixed target U=2.
J = jacobian(w, x)
w_new = w + .25 * (2 - value(w, 1.)) * J[-1]
assert np.allclose(w_new, [1.24, 1.3, .1])
for weights in [w, w_new]:
    fd = np.column_stack([(value(weights + 1e-6 * e, x) - value(weights - 1e-6 * e, x)) / 2e-6 for e in np.eye(3)])
    checks['jacobian_' + str(weights.tolist())] = float(np.max(np.abs(fd - jacobian(weights, x))))
    assert checks['jacobian_' + str(weights.tolist())] < 1e-8
K, K_new = J @ J.T, jacobian(w_new, x) @ jacobian(w_new, x).T
fig, axes = plt.subplots(1, 3, figsize=(11.4, 3.15), gridspec_kw={'width_ratios': [1.25, 1, 1]})
xx = np.linspace(-1.2, 1.4, 240)
axes[0].plot(xx, value(w, xx), color=INK, label='更新前')
axes[0].plot(xx, value(w_new, xx), color=TEAL, label='更新后')
axes[0].scatter([1], [2], marker='*', s=150, c=RED, label='训练样本 (1, 2)')
axes[0].scatter([0], [value(w_new, 0)], c=TEAL)
axes[0].set(xlabel='状态输入 s', ylabel='预测值', title='只在 s=1 取得一个目标')
axes[0].legend(fontsize=9)
for ax, M, title in zip(axes[1:], [K, K_new], ['更新前的梯度内积', '更新后的梯度内积']):
    ax.imshow(M, cmap='Blues', vmin=0, vmax=max(K.max(), K_new.max()))
    ax.set(xticks=range(3), yticks=range(3), xticklabels=['−1','0','1'], yticklabels=['−1','0','1'], xlabel='被更新的状态', ylabel='受影响的状态', title=title)
    for (i,j), v in np.ndenumerate(M):
        ax.text(j, i, f'{v:.2f}', ha='center', va='center', color='white' if v>2 else INK)
fig.tight_layout(); fig.savefig(OUT/'nonlinear-sharing.pdf'); fig.savefig(OUT/'nonlinear-sharing.png', dpi=180); plt.close(fig)
# Lower value error can reverse a correct greedy ordering.
truth = np.array([1., .8]); estimates = [np.array([.7, .6]), np.array([.9, .95])]
fig, axes = plt.subplots(1,2,figsize=(9.5,2.8), sharey=True)
control = []
for ax, q, label in zip(axes, estimates, ['估计甲', '估计乙']):
    mse = np.mean((q-truth)**2); a = int(np.argmax(q)); ret = truth[a]
    control.append({'values':q.tolist(), 'mse':float(mse), 'greedy_action':a, 'return':float(ret)})
    ax.bar([0,1], q, color=[TEAL if i==a else '#C5DADD' for i in [0,1]], width=.52)
    for i in [0,1]:
        ax.plot([i-.31,i+.31], [truth[i]]*2, color=INK, lw=2)
        ax.text(i,q[i]+.025,f'{q[i]:.2f}',ha='center',fontsize=11)
    ax.set(xticks=[0,1],xticklabels=[r'动作 $a_1$',r'动作 $a_2$'], ylim=(0,1.25), title=f'{label}：均方误差 {mse:.5f}')
    ax.text(.5,1.14,f'贪心动作 a{a+1}，真实期望回报 {ret:g}',ha='center',fontsize=11,color=TEAL)
axes[0].set_ylabel('动作价值估计；黑线为真值')
fig.tight_layout(); fig.savefig(OUT/'value-error-control.pdf'); fig.savefig(OUT/'value-error-control.png',dpi=180);plt.close(fig)
assert control[1]['mse'] < control[0]['mse'] and control[1]['return'] < control[0]['return']
# Double sampling: a single state's next feature is 0 or 2, equiprobably.
# Current feature=1, gamma=.5, reward=0. At w=1: delta and derivative both [-1,0].
delta = .5 * np.array([0.,2.]) - 1
derivative = delta.copy()
same_sample = float(np.mean(delta*derivative))
independent = float(np.mean(np.outer(delta,derivative)))
assert same_sample == .5 and independent == .25
checks['double_sampling']={'sample_half_square_gradient':same_sample,'bellman_half_square_gradient':independent}
# Replot existing recorded training runs, preserving seed spread and fixed points.
data = json.loads((ROOT/'demos/approximation-results/results.json').read_text())
fig, axes = plt.subplots(1,3,figsize=(11.4,2.7),sharey=True)
for ax,(p,rich,title) in zip(axes,[(.5,False,'共享一个参数，P(A)=0.5'),(.9,False,'共享一个参数，P(A)=0.9'),(.9,True,'独立参数，P(A)=0.9')]):
    for k,(method,color) in enumerate([('MC',TEAL),('TD',RED)]):
        runs=[r for r in data['runs'] if r['p_A']==p and r['rich']==rich and r['method']==method]
        vals=np.array([r['values'] for r in runs]); xpos=np.array([0,1])+(k-.5)*.13
        exact=np.array(runs[0]['analytic']); exact=np.repeat(exact,2) if len(exact)==1 else exact
        ax.errorbar(xpos,vals.mean(0),yerr=vals.std(0,ddof=1),fmt='o',c=color,label=method,capsize=3)
        for xx,yy in zip(xpos,exact): ax.plot([xx-.09,xx+.09],[yy,yy],c=color,lw=1)
    ax.axhline(.9,c=INK,ls=':',lw=1);ax.axhline(1,c=INK,ls='--',lw=1)
    ax.set(xticks=[0,1],xticklabels=['A','B'],ylim=(.4,1.07),title=title)
axes[0].set_ylabel('学习后的价值估计'); axes[0].legend(fontsize=10,loc='lower left')
fig.tight_layout();fig.savefig(OUT/'projection-runs.pdf');fig.savefig(OUT/'projection-runs.png',dpi=180);plt.close(fig)
report={'checks':checks,'nonlinear':{'before':w.tolist(),'after':w_new.tolist(),'values_before':value(w,x).tolist(),'values_after':value(w_new,x).tolist(),'kernel_before':K.tolist(),'kernel_after':K_new.tolist()},'control':control,'training_data_source':'demos/approximation-results/results.json; existing 5-seed, 50000-update runs'}
(OUT/'calculations.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print(json.dumps({'figures':3,'checks':checks,'control':control},ensure_ascii=False,indent=2))
