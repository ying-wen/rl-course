"""Linear TD, GTD2, TDC and ETD(0), with explicit old-parameter updates.

Two observable states have features x=1 and x=2. Action 0 goes to state 0;
action 1 goes to state 1. All rewards are zero; gamma=.9. The target always
chooses action 1; the behavior chooses it with probability .05 in both states.
The behavior covers both actions and both states. Under its stationary
distribution C=1.15 and A=-.74. Ordinary off-policy TD has an unstable mean
update despite the true value being exactly representable by w=0.

Run: python demos/linear_offpolicy_prediction.py
The plotted curves are actual sampled updates, 32 seeds, 6000 transitions.
ETD(0) is provided as a step function but is not part of this small comparison.
"""
from pathlib import Path
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parents[1]


def td_step(w, x, reward, xp, rho, gamma, alpha):
    delta=reward+gamma*w*xp-w*x
    return w+alpha*rho*delta*x


def gtd2_step(w,h,x,reward,xp,rho,gamma,alpha,beta):
    delta=reward+gamma*w*xp-w*x
    u=x*h
    # Both right-hand sides use w,h from BEFORE this interaction's update.
    return w+alpha*rho*(x-gamma*xp)*u, h+beta*(rho*delta-u)*x


def tdc_step(w,h,x,reward,xp,rho,gamma,alpha,beta):
    delta=reward+gamma*w*xp-w*x
    u=x*h
    return w+alpha*rho*(delta*x-gamma*xp*u), h+beta*(rho*delta-u)*x


def etd0_step(w,followon,previous_rho,x,reward,xp,rho,gamma,alpha,interest=1.):
    # For constant gamma. Start with followon=0 and previous_rho=0.
    followon_new=interest+gamma*previous_rho*followon
    delta=reward+gamma*w*xp-w*x
    return w+alpha*delta*rho*followon_new*x,followon_new


def run():
    gamma=.9;alpha=.001;beta=.01
    distribution=np.array([.95,.05]);features=np.array([1.,2.])
    c=float(distribution@(features**2))
    a=float(distribution@(features*(features-gamma*2)))
    np.testing.assert_allclose([a,c],[-.74,1.15])
    # Independent enumeration of the four (state, behavior action) outcomes.
    w=.7;h=-.3;expected=np.zeros(4)
    for s in range(2):
        for action in range(2):
            prob=distribution[s]*distribution[action];rho=20. if action==1 else 0.
            gw,gh=gtd2_step(w,h,features[s],0.,features[action],rho,gamma,alpha,beta)
            tw,th=tdc_step(w,h,features[s],0.,features[action],rho,gamma,alpha,beta)
            expected+=prob*np.array([(gw-w)/alpha,(gh-h)/beta,(tw-w)/alpha,(th-h)/beta])
    cross=float(distribution@features)*2
    analytic=[a*h,-a*w-c*h,-a*w-gamma*cross*h,-a*w-c*h]
    np.testing.assert_allclose(expected,analytic,atol=1e-12)
    # Check follow-on timing separately from the value update.
    ew,ef=etd0_step(.7,2.,.5,1.,0.,2.,20.,.9,.001)
    np.testing.assert_allclose([ef,ew],[1.9,.7+.001*(1.26-.7)*20*1.9])

    runs=32;steps=6000
    rngs=[np.random.default_rng(1000+s)for s in range(runs)]
    # All algorithms receive exactly the same fixed-behavior samples per seed.
    wtd=np.ones(runs);wg=np.ones(runs);wt=np.ones(runs);hg=np.zeros(runs);ht=np.zeros(runs)
    state=np.array([int(rng.random()<.05)for rng in rngs])
    rows=[];curves=[]
    for t in range(steps+1):
        if t%50==0:
            rmse=np.sqrt(c*np.stack([wtd,wg,wt])**2)
            curves.append(rmse.copy())
            rows.append([t,*rmse.mean(axis=1)])
        if t==steps:break
        action=np.array([int(rng.random()<.05)for rng in rngs]);x=features[state];xp=features[action]
        rho=np.where(action==1,20.,0.)
        wtd=td_step(wtd,x,0.,xp,rho,gamma,alpha)
        wg,hg=gtd2_step(wg,hg,x,0.,xp,rho,gamma,alpha,beta)
        wt,ht=tdc_step(wt,ht,x,0.,xp,rho,gamma,alpha,beta)
        state=action
    rows=np.array(rows);curves=np.array(curves);out=ROOT/'demos/linear-offpolicy-results';out.mkdir(exist_ok=True)
    np.savetxt(out/'mean-rmse.csv',rows,delimiter=',',header='transitions,td,gtd2,tdc',comments='')
    np.savez(out/'final-weights.npz',td=wtd,gtd2=wg,tdc=wt)
    np.save(out/'seed-rmse.npy',curves)
    fig,ax=plt.subplots(figsize=(9,3.2))
    for j,(label,col)in enumerate([('off-policy TD','#c65335'),('GTD2','#087e8b'),('TDC','#4d6893')],1):
        ax.semilogy(rows[:,0],rows[:,j],label=label,color=col,lw=2)
        ax.fill_between(rows[:,0],np.quantile(curves[:,j-1,:],.25,axis=1),np.quantile(curves[:,j-1,:],.75,axis=1),color=col,alpha=.12)
    ax.set(xlabel='real transitions per run',ylabel='mean RMSE (32 seeds)');ax.legend()
    ax.spines[['top','right']].set_visible(False);fig.tight_layout()
    figure_dir = ROOT / 'assets' / 'v8-mechanisms'
    figure_dir.mkdir(parents=True, exist_ok=True)
    fig.savefig(figure_dir / 'linear-offpolicy.pdf')
    plt.close(fig)
    report=dict(A=a,C=c,seeds=runs,transitions=steps,alpha=alpha,beta=beta,
                final_mean_rmse=dict(zip(['td','gtd2','tdc'],rows[-1,1:].tolist())),
                expected_update_error=float(np.max(abs(expected-analytic))))
    (out/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))


if __name__=='__main__':run()
