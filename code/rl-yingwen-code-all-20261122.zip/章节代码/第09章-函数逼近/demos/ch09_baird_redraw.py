"""Baird 反例重算（第 9 章 ch09-baird 页的中文重画用）。
11-21 审阅站请求 r1121-113341 新增。设定按 Sutton 与 Barto 第二版 §11.2：
7 个状态、8 个参数，奖励全为零，gamma=.99，alpha=.01，初值 w=(1,1,1,1,1,1,10,1)。
目标策略只选实线（必到下层态 7）；行为策略以 1/7 选实线、6/7 选虚线（等概率到上层 6 态）。
输出 pgfplots 坐标串，粘贴进 new-slides/ch09-revision/ch09-baird.tex。
运行：python3 demos/ch09_baird_redraw.py
"""
import numpy as np

X = np.zeros((7, 8))
for i in range(6):
    X[i, i], X[i, 7] = 2, 1
X[6, 6], X[6, 7] = 1, 2
GAMMA, ALPHA = .99, .01
W0 = np.array([1, 1, 1, 1, 1, 1, 10, 1.])


def expected_sweeps(n=1000):
    """半梯度期望更新（DP）：七个起点等权，目标沿实线到态 7。"""
    w, out = W0.copy(), [W0.copy()]
    for _ in range(n):
        v = X @ w
        w = w + ALPHA / 7 * X.T @ (GAMMA * v[6] - v)
        out.append(w.copy())
    return np.array(out)


def sampled_td(n=1000, seed=0):
    """半梯度离策略 TD(0)，按行为策略采样，rho=7（实线）或 0（虚线）。"""
    rng = np.random.default_rng(seed)
    w, s, out = W0.copy(), rng.integers(7), [W0.copy()]
    for _ in range(n):
        if rng.random() < 1 / 7:
            s2, rho = 6, 7.
        else:
            s2, rho = rng.integers(6), 0.
        w = w + ALPHA * rho * (GAMMA * X[s2] @ w - X[s] @ w) * X[s]
        s = s2
        out.append(w.copy())
    return np.array(out)


def coords(arr, col, step):
    return ' '.join(f'({k},{arr[k, col]:.1f})' for k in range(0, len(arr), step))


if __name__ == '__main__':
    dp, td = expected_sweeps(), sampled_td()
    print('DP 1000 轮：', dp[-1].round(2))
    print('TD 1000 步：', td[-1].round(2))
    for c in range(6):
        print(f'% TD w{c+1}\n' + coords(td, c, 20))
    print('% TD w7\n' + coords(td, 6, 50))
    print('% TD w8\n' + coords(td, 7, 10))
    print('% DP w1..w6\n' + coords(dp, 0, 25))
    print('% DP w7\n' + coords(dp, 6, 100))
    print('% DP w8\n' + coords(dp, 7, 25))
