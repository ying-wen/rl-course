"""第 9 章 9.2 节两张实验图：学习曲线（course15-fa-learning）与学得的预测（ch09-learned-values）。

11-21 审阅站请求 r1121-113341：独立运行从 8 次增到 30 次；学习曲线右端标注改为两种解的解析误差
（MC .174、TD .325），曲线为实测；字体用 demos/plot_fonts.py 的课件字体。
训练过程直接调用 course15_approximation.train()，协议不变：从状态 10 出发，三组聚合，
MC 步长 1/N，TD 步长 0.15/(1+N/1000)^0.65，同一条轨迹同时供两种方法使用。
运行：python3 demos/ch09_learning_figures.py   输出 assets/ch09-revision/learning.png、values.png，
并在 assets/ch09-revision/learning-30runs.json 写出所用数字。
"""
from pathlib import Path
import json
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter, FixedLocator

import course15_approximation as c
from plot_fonts import use_course_fonts, no_leading_zero, CJK_FAMILY

OUT = Path(__file__).resolve().parents[1] / "assets" / "ch09-revision"
SEEDS = 30
EPISODES = 12000
TEAL, RED, INK, MUTED = "#087E8B", "#B5532B", "#3F4A50", "#9AA3A8"


def main():
    use_course_fonts()
    plt.rcParams.update({"axes.spines.top": False, "axes.spines.right": False,
                         "font.size": 10, "axes.labelsize": 10.5,
                         "xtick.labelsize": 9.5, "ytick.labelsize": 9.5})
    p, r, visits, mu, v, C, A, b, mc_w, td_w = c.model_reference()
    X = c.X
    runs = [c.train(EPISODES, seed) for seed in range(SEEDS)]
    eps = runs[0]["episodes"]
    report = {"seeds": SEEDS, "episodes": EPISODES}

    # ---- 学习曲线 ----
    fig, ax = plt.subplots(figsize=(6.4, 2.25))
    keep = eps >= 50
    for name, color, w in [("mc", TEAL, mc_w), ("td", RED, td_w)]:
        W = np.array([z[name] for z in runs])
        err = np.sqrt((((W @ X.T) - v) ** 2 * mu).sum(-1))
        mean, sd = err.mean(0), err.std(0, ddof=1)
        ax.plot(eps[keep], mean[keep], color=color, lw=1.4, label=name.upper())
        ax.fill_between(eps[keep], (mean - sd)[keep], (mean + sd)[keep], color=color, alpha=.15, lw=0)
        ref = float(np.sqrt(mu @ ((X @ w - v) ** 2)))
        ax.hlines(ref, 45, EPISODES, color=color, ls="--", lw=.8)
        ax.text(EPISODES * 1.08, ref, no_leading_zero(round(ref, 3)), color=color,
                va="center", fontsize=9.5)
        report[name] = {"final_rmse_mean": float(mean[-1]), "final_rmse_sd": float(sd[-1]),
                        "solution_rmse": ref}
    ax.set_xscale("log")
    ax.xaxis.set_major_locator(FixedLocator([50, 200, 1000, 4000, 12000]))
    ax.xaxis.set_major_formatter(FuncFormatter(lambda x, _: f"{int(x):,}"))
    ax.xaxis.set_minor_formatter(FuncFormatter(lambda x, _: ""))
    ax.yaxis.set_major_formatter(FuncFormatter(no_leading_zero))
    ax.set_xlim(45, EPISODES * 1.6)
    ax.set_xlabel("训练回合数（对数刻度）", fontfamily=CJK_FAMILY)
    ax.set_ylabel("加权均方根误差", fontfamily=CJK_FAMILY)
    ax.grid(axis="y", color="#E3E7E9", lw=.6)
    ax.legend(frameon=False, ncol=2, loc="center right", bbox_to_anchor=(.86, .5))
    fig.savefig(OUT / "learning.png", dpi=220, bbox_inches="tight")
    plt.close(fig)

    # ---- 学得的预测 ----
    fig, ax = plt.subplots(figsize=(6.4, 2.2))
    S = c.STATES
    ax.plot(S, v, color=INK, lw=1.3, label="真实价值")
    for name, color, w, dx in [("mc", TEAL, mc_w, -.14), ("td", RED, td_w, .14)]:
        fin = np.array([z[name][-1] for z in runs]) @ X.T
        ax.errorbar(S + dx, fin.mean(0), yerr=fin.std(0, ddof=1), fmt="o", ms=3,
                    color=color, elinewidth=.9, capsize=1.5, label=name.upper())
        ax.step(S, X @ w, where="mid", color=color, ls=":", lw=.8)
        W = np.array([z[name][-1] for z in runs])
        report[name].update({"final_weights_mean": W.mean(0).tolist(),
                             "final_weights_sd": W.std(0, ddof=1).tolist(),
                             "final_weights_se": (W.std(0, ddof=1) / np.sqrt(SEEDS)).tolist()})
    for xb in (6.5, 13.5):
        ax.axvline(xb, color=MUTED, ls=":", lw=.8)
    ax.set_xticks([1, 6, 7, 10, 13, 14, 19])
    ax.yaxis.set_major_formatter(FuncFormatter(no_leading_zero))
    ax.set_xlabel("状态", fontfamily=CJK_FAMILY)
    ax.set_ylabel("价值", fontfamily=CJK_FAMILY)
    ax.grid(axis="y", color="#E3E7E9", lw=.6)
    ax.legend(frameon=False, ncol=3, loc="upper left", prop={"family": CJK_FAMILY, "size": 9.5})
    fig.savefig(OUT / "values.png", dpi=220, bbox_inches="tight")
    plt.close(fig)

    # 右组权重在末 2,000 回合内的波动（单次运行内的样本标准差，再对运行取平均）
    W = np.array([z["td"] for z in runs])
    tail = eps > EPISODES - 2000
    report["td"]["right_weight_within_run_sd_last2000"] = float(W[:, tail, 2].std(1, ddof=1).mean())
    report["td"]["final_step_size_right_group"] = .15 / (1 + 21 * EPISODES / 1000) ** .65
    (OUT / "learning-30runs.json").write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n")
    print(json.dumps(report, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
