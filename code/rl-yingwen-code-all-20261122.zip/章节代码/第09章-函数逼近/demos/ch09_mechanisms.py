# -*- coding: utf-8 -*-
"""第 9 章机制页的数值：特征波及、傅里叶拟合、步长规则、目标随参数移动、
线性 TD 的平均动力学、三缺一、两阶段训练的遗忘与 SGD/Adam 步长。

主算例：状态 0..20 的随机游走，0 和 20 终止，左端回报 -1、右端 +1，gamma=1，
从 10 出发；v_pi(s)=s/10-1，访问权重 mu(s)=min(s,20-s)/100。
运行：python3 demos/ch09_mechanisms.py   输出 demos/ch09-mechanisms-results/results.json
"""
import json, os
import numpy as np

S = np.arange(1, 20)                      # 非终止状态
MU = np.minimum(S, 20 - S) / 100.0
VPI = S / 10.0 - 1.0
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "ch09-mechanisms-results")


# ---------- 特征 ----------
def onehot(s):
    x = np.zeros(19); x[s - 1] = 1; return x

def agg(s):
    x = np.zeros(3); x[0 if s <= 6 else (1 if s <= 13 else 2)] = 1; return x

L1 = [(1, 4), (5, 8), (9, 12), (13, 16), (17, 19)]
L2 = [(1, 2), (3, 6), (7, 10), (11, 14), (15, 18), (19, 19)]
def tile(s):
    return np.array([1.0 if a <= s <= b else 0.0 for a, b in L1 + L2])

CENTERS = list(range(1, 20, 2))           # 粗编码：10 个区间，中心 1,3,...,19，半径 3
def coarse(s):
    return np.array([1.0 if abs(s - c) <= 3 else 0.0 for c in CENTERS])

def fourier(n):
    return lambda s: np.cos(np.pi * np.arange(n + 1) * s / 20.0)

def X(feat, states=S):
    return np.array([feat(s) for s in states])


def spread():
    out = {}
    for name, f in [("onehot", onehot), ("agg", agg), ("coarse", coarse), ("tile", tile), ("fourier5", fourier(5))]:
        x16 = f(16)
        k = X(f) @ x16 / (x16 @ x16)
        out[name] = [round(float(v), 3) for v in k]
    return out


def wls(feat, target=VPI, w=MU):
    Xm = X(feat)
    W = np.diag(w)
    th = np.linalg.solve(Xm.T @ W @ Xm, Xm.T @ W @ target)
    pred = Xm @ th
    ve = float(np.sum(w * (pred - target) ** 2))
    return th, pred, ve


def fourier_fits():
    res = {}
    for n in (1, 3, 5):
        _, pred, ve = wls(fourier(n))
        res[str(n)] = {"pred": [round(float(p), 3) for p in pred], "rmsve": round(float(np.sqrt(ve)), 4)}
    # 一条弯曲的真值：同一游走，gamma=0.9
    g = 0.9
    P = np.zeros((19, 19)); r = np.zeros(19)
    for i, s in enumerate(S):
        for sp in (s - 1, s + 1):
            if sp == 0: r[i] += 0.5 * -1
            elif sp == 20: r[i] += 0.5 * 1
            else: P[i, sp - 1] += 0.5
    v09 = np.linalg.solve(np.eye(19) - g * P, r)
    res["v_gamma09"] = [round(float(v), 3) for v in v09]
    for n in (1, 3, 5):
        _, pred, ve = wls(fourier(n), target=v09)
        res["g09_" + str(n)] = {"pred": [round(float(p), 3) for p in pred], "rmsve": round(float(np.sqrt(ve)), 4)}
    return res


def step_rule(tau=10):
    rows = {}
    for name, f in [("onehot", onehot), ("agg", agg), ("coarse", coarse), ("tile", tile), ("fourier5", fourier(5))]:
        Xm = X(f)
        exx = float(MU @ np.sum(Xm * Xm, axis=1))
        a = 1.0 / (tau * exx)
        x16 = f(16)
        rows[name] = {"E_xx": round(exx, 3), "alpha": round(a, 4), "x16x16": round(float(x16 @ x16), 3),
                      "move16_at_alpha": round(float(a * x16 @ x16), 3),
                      "move16_at_0.1": round(float(0.1 * x16 @ x16), 3)}
    return rows


def overshoot(k=8):
    """在同一状态反复更新、目标不动：误差每步乘以 1-f，f=alpha*x^T x。"""
    return {str(f): [round((1 - f) ** i, 4) for i in range(k + 1)] for f in (0.5, 1.0, 1.5, 2.2)}


def chase():
    """一次半梯度更新后同一转移的 TD 误差：delta+ = delta*[1 - alpha*|x|^2*(1-rho)]."""
    cases = {}
    a = 0.1
    # 聚合 13->14，w=(-.2,0,.2)
    w = np.array([-.2, 0, .2]); x, xp = agg(13), agg(14)
    d = 0 + xp @ w - x @ w; w2 = w + a * d * x; d2 = xp @ w2 - x @ w2
    cases["agg_13_14"] = dict(delta=round(float(d), 4), delta_after=round(float(d2), 4),
                              pred=[round(float(x @ w), 4), round(float(x @ w2), 4)],
                              target=[round(float(xp @ w), 4), round(float(xp @ w2), 4)])
    # 瓦片 15->16，以 MC 解为初值再加扰动：取 w 使 v(15)=0, v(16)=0.2
    Xt = X(tile)
    w = np.linalg.lstsq(Xt, VPI, rcond=None)[0]
    x, xp = tile(15), tile(16)
    d = xp @ w - x @ w; w2 = w + a * d * x; d2 = xp @ w2 - x @ w2
    cases["tile_15_16"] = dict(share=float(x @ xp), xx=float(x @ x), delta=round(float(d), 4), delta_after=round(float(d2), 4),
                               pred=[round(float(x @ w), 4), round(float(x @ w2), 4)],
                               target=[round(float(xp @ w), 4), round(float(xp @ w2), 4)])
    # 两状态例 s0->s1，w=1，gamma=.9
    g = .9; wv = 1.0
    d = g * 2 * wv - wv; wv2 = wv + a * d * 1; d2 = g * 2 * wv2 - wv2
    cases["two_state"] = dict(delta=round(d, 4), delta_after=round(d2, 4), pred=[1, round(wv2, 4)], target=[1.8, round(1.8 * wv2, 4)])
    return cases


def mean_dynamics():
    """聚合主算例的 A, b；在 w1 固定于 TD 解时 (w2,w3) 平面上的平均更新场与轨迹。"""
    A = np.zeros((3, 3)); b = np.zeros(3)
    for i, s in enumerate(S):
        x = agg(s)
        for sp in (s - 1, s + 1):
            if sp in (0, 20):
                r = -1 if sp == 0 else 1; xp = np.zeros(3)
            else:
                r = 0; xp = agg(sp)
            A += MU[i] * 0.5 * np.outer(x, x - xp)
            b += MU[i] * 0.5 * r * x
    wtd = np.linalg.solve(A, b)
    wmc, _, _ = wls(agg)
    sym = np.linalg.eigvalsh((A + A.T) / 2)
    eig = np.linalg.eigvals(A)
    # 场：在 w1=wtd[0] 的切片上
    field = []
    for u in np.linspace(-.6, .6, 7):
        for v in np.linspace(-.2, 1.0, 7):
            w = np.array([wtd[0], u, v])
            dw = b - A @ w
            field.append([round(float(u), 3), round(float(v), 3), round(float(dw[1]), 4), round(float(dw[2]), 4)])
    # 轨迹（期望更新，alpha=5；左组参数固定在 TD 解）
    trajs = []
    for st in [(-.5, 1.0), (.5, 1.0), (.5, -.15), (-.5, -.15)]:
        w = np.array([wtd[0], st[0], st[1]]); tr = [[round(float(w[1]), 3), round(float(w[2]), 3)]]; dist = []
        for k in range(120):
            w = w + 5.0 * (b - A @ w)
            w[0] = wtd[0]
            if k % 6 == 5: tr.append([round(float(w[1]), 3), round(float(w[2]), 3)])
        trajs.append(tr)
    # 切片上的距离曲线（alpha=5），起点 (w2,w3)=(-.5,1)
    w = np.array([wtd[0], -.5, 1.0]); dist = []
    for k in range(121):
        if k % 6 == 0: dist.append(round(float(np.linalg.norm(w - wtd)), 4))
        w = w + 5.0 * (b - A @ w); w[0] = wtd[0]
    B = A[1:, 1:]
    ang = []
    for th in np.linspace(0, 2 * np.pi, 721):
        y = np.array([np.cos(th), np.sin(th)]); z = B @ y
        ang.append(np.degrees(np.arccos(y @ z / np.linalg.norm(z))))
    return dict(max_angle=round(float(max(ang)), 1), A=np.round(A, 4).tolist(), b=np.round(b, 4).tolist(), w_td=np.round(wtd, 4).tolist(),
                w_mc=np.round(wmc, 4).tolist(), sym_eig=np.round(sym, 4).tolist(),
                eig=[str(np.round(e, 4)) for e in eig], field=field, trajs=trajs, dist=dist)


def triad():
    a, g = .1, .9
    res = {}
    # 原例：w+ = w + a*sum mu(s)*(g*2w - x(s)w)*x(s)
    res["all_three"] = round(1 + a * (.95 * (1.8 - 1) * 1 + .05 * (1.8 - 2) * 2), 4)
    res["no_offpolicy"] = round(1 + a * (1.0 * (1.8 - 2) * 2), 4)              # 同策略：起点全在 s1
    res["no_bootstrap"] = round(1 + a * (.95 * (0 - 1) * 1 + .05 * (0 - 2) * 2), 4)
    # 表格：两个参数 v0, v1，平均更新矩阵
    M = np.eye(2) + a * np.array([[-.95, .95 * g], [0, .05 * (g - 1)]])
    res["tabular_eig"] = [round(float(e), 4) for e in np.linalg.eigvals(M)]
    return res


# ---------- 两阶段训练 ----------
class MLP:
    def __init__(self, rng, h=32):
        self.W1 = rng.normal(0, 1.0, (h, 1)); self.b1 = rng.normal(0, .5, h)
        self.W2 = rng.normal(0, 1 / np.sqrt(h), h); self.b2 = 0.0
    def params(self): return [self.W1, self.b1, self.W2]
    def fwd(self, s):
        z = (s / 10.0 - 1.0)
        self.z = z; self.hh = np.tanh(self.W1[:, 0] * z + self.b1)
        return float(self.W2 @ self.hh + self.b2)
    def grads(self, s):
        self.fwd(s)
        dh = self.W2 * (1 - self.hh ** 2)
        return [np.outer(dh, [self.z]), dh, self.hh.copy()], 1.0
    def predict_all(self): return np.array([self.fwd(s) for s in S])


def two_stage(runs=20, steps=4000, seed=1):
    """第一阶段只在左半 1..9 上训练，第二阶段只在右半 11..19 上训练；目标取真值以排除回报噪声。
    记录左半的均方根误差。replay：第二阶段每次以 1/2 概率改用第一阶段的状态。"""
    left = np.arange(1, 10); right = np.arange(11, 20)
    rng0 = np.random.default_rng(seed)
    def ret(rng, s): return float(VPI[s - 1])
    rec_every = 100
    names = ["tile", "fourier5", "mlp_sgd", "mlp_adam", "mlp_sgd_replay"]
    curves = {n: np.zeros(2 * steps // rec_every + 1) for n in names}
    for run in range(runs):
        seeds = rng0.integers(0, 2 ** 31, 2)
        for n in names:
            rng = np.random.default_rng(seeds[0])
            if n in ("tile", "fourier5"):
                f = tile if n == "tile" else fourier(5)
                Xall = X(f); exx = float(MU @ np.sum(Xall * Xall, axis=1)); a = 1 / (20 * exx)
                w = np.zeros(Xall.shape[1])
                pred = lambda: Xall @ w
            else:
                net = MLP(np.random.default_rng(seeds[1]))
                m = [np.zeros_like(p) for p in net.params()]; v = [np.zeros_like(p) for p in net.params()]; tstep = [0]
                pred = net.predict_all
            k = 0
            curves[n][k] += np.sqrt(np.mean((pred()[left - 1] - VPI[left - 1]) ** 2)); k += 1
            for t in range(2 * steps):
                if t < steps or (n == "mlp_sgd_replay" and rng.random() < .5):
                    s = int(rng.choice(left))
                else:
                    s = int(rng.choice(right))
                G = ret(rng, s)
                if n in ("tile", "fourier5"):
                    x = Xall[s - 1]; w += a * (G - x @ w) * x
                else:
                    gs, gb = net.grads(s); err = G - net.fwd(s)
                    if n == "mlp_adam":
                        tstep[0] += 1; lr = .003; b1, b2 = .9, .999
                        for i, (p, gq) in enumerate(zip(net.params(), gs)):
                            gg = -err * gq
                            m[i] = b1 * m[i] + (1 - b1) * gg; v[i] = b2 * v[i] + (1 - b2) * gg * gg
                            mh = m[i] / (1 - b1 ** tstep[0]); vh = v[i] / (1 - b2 ** tstep[0])
                            p -= lr * mh / (np.sqrt(vh) + 1e-8)
                    else:
                        lr = .02
                        for p, gq in zip(net.params(), gs):
                            p += lr * err * gq
                if (t + 1) % rec_every == 0:
                    curves[n][k] += np.sqrt(np.mean((pred()[left - 1] - VPI[left - 1]) ** 2)); k += 1
    return {n: [round(float(c / runs), 4) for c in cv] for n, cv in curves.items()}, rec_every


def adam_scale():
    """单个参数、恒定梯度 g：SGD 每步移动 lr*g，Adam 稳态每步移动约 eta。"""
    gs = [0.01, 0.03, 0.1, 0.3, 1, 3, 10]
    lr, eta = .1, .01
    out = []
    for g in gs:
        m = v = 0.0; step = 0
        for t in range(1, 201):
            m = .9 * m + .1 * g; v = .999 * v + .001 * g * g
            step = eta * (m / (1 - .9 ** t)) / (np.sqrt(v / (1 - .999 ** t)) + 1e-8)
        out.append([g, round(lr * g, 4), round(float(step), 5)])
    return out


def main():
    os.makedirs(OUT, exist_ok=True)
    res = {}
    res["spread"] = spread()
    res["fourier"] = fourier_fits()
    res["step_rule"] = step_rule()
    res["overshoot"] = overshoot()
    res["chase"] = chase()
    res["mean_dynamics"] = mean_dynamics()
    res["triad"] = triad()
    res["two_stage"], res["two_stage_every"] = two_stage()
    res["adam_scale"] = adam_scale()
    with open(os.path.join(OUT, "results.json"), "w", encoding="utf-8") as fh:
        json.dump(res, fh, ensure_ascii=False, indent=1)
    for k, v in res.items():
        if k == "two_stage":
            for n, c in v.items(): print(k, n, c[:3], "...", c[len(c)//2-1:len(c)//2+2], "...", c[-3:])
        elif k == "mean_dynamics":
            print({kk: vv for kk, vv in v.items() if kk not in ("field", "trajs")})
        else:
            print(k, v)


if __name__ == "__main__":
    main()
