"""Chapter 9: exact update, projection, off-policy, and control calculations.

Run: python /absolute/path/to/demos/v19_approximation.py
NumPy + Matplotlib only; outputs assets/v19-approximation/.
No old experiment or asset is changed. Curves here are exact finite-model
calculations, not newly collected learning curves.
"""
from pathlib import Path
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch, Circle
from course15_approximation import model_reference, X, STATES, GROUP

OUT = Path(__file__).resolve().parents[1] / 'assets/v19-approximation'
OUT.mkdir(parents=True, exist_ok=True)
TEAL, RED, GOLD, INK = '#087E8B', '#C65335', '#C4942A', '#182E38'
COLORS = [TEAL, GOLD, RED]
plt.rcParams.update({'font.size': 13, 'axes.spines.top': False,
                     'axes.spines.right': False, 'pdf.fonttype': 42})

def save(fig, name):
    fig.savefig(OUT / f'{name}.pdf', bbox_inches='tight')
    fig.savefig(OUT / f'{name}.png', dpi=180, bbox_inches='tight')
    plt.close(fig)

def aggregation_checks():
    p, r, visits, mu, truth, c, a, b, mc, td = model_reference()
    bellman = r + p @ (X @ td)
    residual = bellman - X @ td
    weighted = mu * residual
    # Independent enumeration: one transition at a time, no Bellman matrices.
    enumerated = np.zeros(19)
    for s in range(1, 20):
        for nxt in (s-1, s+1):
            reward = -1. if nxt == 0 else (1. if nxt == 20 else 0.)
            tail = 0. if nxt in (0,20) else td[GROUP[nxt-1]]
            enumerated[s-1] += .5 * mu[s-1] * (reward + tail - td[GROUP[s-1]])
    assert np.allclose(weighted, enumerated, atol=1e-14)
    assert np.allclose(X.T @ weighted, 0, atol=1e-14)
    assert np.allclose(weighted[[0,5,6,12,13,18]], [-3/700,3/700,-1/200,1/200,-3/700,3/700])
    projection = X @ np.linalg.solve(c, X.T * mu)
    assert np.max(abs(projection @ bellman - X @ td)) < 1e-13
    assert np.max(abs(projection @ truth - X @ mc)) < 1e-13
    # Fixed-point map in the symmetric one-dimensional family, independently
    # obtained by taking the visit-weighted average of each group.
    cs = np.linspace(0,.65,200)
    mapped=[]
    for v in cs:
        backup=r+p@(X@np.array([-v,0,v]))
        mapped.append(np.average(backup[GROUP==2], weights=mu[GROUP==2]))
    mapped=np.array(mapped)
    assert np.max(abs(mapped-(1/42+5*cs/6))) < 1e-13
    assert abs(1/42/(1-5/6)-1/7)<1e-13
    # Full residual and stopped-target derivatives by independent finite difference.
    w=np.array([-.4,.2,.7]);x=X[5];xp=X[6];delta=(xp-x)@w
    target=xp@w
    def loss(q): return .5*((xp-x)@q)**2
    def frozen_loss(q): return .5*(target-x@q)**2
    full=np.array([(loss(w+1e-6*e)-loss(w-1e-6*e))/2e-6 for e in np.eye(3)])
    semi=np.array([(frozen_loss(w+1e-6*e)-frozen_loss(w-1e-6*e))/2e-6 for e in np.eye(3)])
    assert np.max(abs(full+delta*(x-xp)))<1e-9
    assert np.max(abs(semi+delta*x))<1e-9
    fig, axes=plt.subplots(2,1,figsize=(11,3.8),sharex=True,gridspec_kw={'height_ratios':[1.25,1]})
    for ax in axes:
        for lo,hi,color in [(0.5,6.5,TEAL),(6.5,13.5,GOLD),(13.5,19.5,RED)]:ax.axvspan(lo,hi,color=color,alpha=.06)
    axes[0].step(STATES,X@td,where='mid',lw=2.4,color=TEAL,label=r'$\hat v=\Phi w_{TD}$')
    axes[0].plot(STATES,bellman,'o-',ms=4,color=INK,label=r'$T_\pi\hat v$')
    axes[0].set(ylabel='Value / target',ylim=(-.68,.68))
    axes[0].legend(loc='upper center',ncol=2,fontsize=11)
    axes[1].axhline(0,color=INK,lw=.7)
    axes[1].vlines(STATES,0,weighted,color=[COLORS[g] for g in GROUP],lw=3)
    axes[1].scatter(STATES,weighted,c=[COLORS[g] for g in GROUP],s=24,zorder=3)
    for lo,hi,label in [(1,6,'sum = 0'),(7,13,'sum = 0'),(14,19,'sum = 0')]:
        axes[1].text((lo+hi)/2,.0061,label,ha='center',fontsize=11)
    axes[1].set(ylabel=r'$\mu(s)\,\bar\delta(s)$',xlabel='State',xticks=[1,6,7,10,13,14,19],ylim=(-.0062,.0081))
    fig.tight_layout(pad=.5);save(fig,'projection-balance')
    fig,ax=plt.subplots(figsize=(6.0,3.4))
    ax.plot(cs,cs,color='#919a9d',ls='--',label=r'identity $c$')
    ax.plot(cs,mapped,color=TEAL,lw=2,label=r'$F(c)=1/42+5c/6$')
    trace=[17/30]
    for _ in range(7):trace.append(1/42+5*trace[-1]/6)
    cur=trace[0]
    for nxt in trace[1:]:
        ax.plot([cur,cur,nxt],[cur,nxt,nxt],color=RED,lw=1.3);cur=nxt
    ax.scatter([1/7,17/30],[1/7,17/30],color=[TEAL,RED],zorder=4)
    ax.annotate(r'$c_{TD}=1/7$',(1/7,1/7),(.27,.09),arrowprops={'arrowstyle':'->','color':TEAL},color=TEAL,fontsize=11)
    ax.annotate(r'$c_{MC}=17/30$',(17/30,17/30),(.20,.59),arrowprops={'arrowstyle':'->','color':RED},color=RED,fontsize=11)
    ax.set(xlabel='Current right-group value c',ylabel='Projected Bellman target F(c)',xlim=(0,.65),ylim=(0,.65))
    ax.legend(loc='upper left',fontsize=10);fig.tight_layout();save(fig,'fixedpoint-map')
    return {'mc_weights':mc.tolist(),'td_weights':td.tolist(),'weighted_bellman_residual':weighted.tolist(),
            'group_weighted_residual':(X.T@weighted).tolist(),'enumeration_max_error':float(max(abs(enumerated-weighted))),
            'full_gradient_fd_error':float(max(abs(full+delta*(x-xp)))),'semigradient_fd_error':float(max(abs(semi+delta*x))),
            'projected_iteration_c':trace,'projected_map_slope':5/6,'projected_map_intercept':1/42}

def offpolicy_checks():
    # Complete continuing MDP reused from linear_offpolicy_prediction.py: a0 -> s0, a1 -> s1.
    # Target always a1. Behavior chooses a0 with p and a1 with 1-p at BOTH states.
    # Independent state-transition samples with stationary distribution give this
    # deterministic mean operator; curves below iterate that mean operator.
    p=.95;gamma=.9;alpha=.001;phi=np.array([1.,2.]);mu=np.array([p,1-p])
    A=sum(mu[s]*(1-p)*(1/(1-p))*phi[s]*(phi[s]-gamma*phi[1]) for s in [0,1])
    assert abs(A-(.4-1.2*p))<1e-14
    transition=np.tile(mu,(2,1));assert np.allclose(mu@transition,mu)
    assert np.allclose([0,0],np.linalg.solve(np.eye(2)-gamma*np.array([[0,1],[0,1]]),[0,0]))
    # Matrix computation independent of state-action enumeration.
    A_matrix=phi@(np.diag(mu)@(np.eye(2)-gamma*np.array([[0,1],[0,1]])))@phi
    assert abs(A-A_matrix)<1e-14
    from linear_offpolicy_prediction import td_step
    enumerated_step=0.
    for state in range(2):
        for action in range(2):
            rho=0. if action==0 else 1/(1-p)
            enumerated_step+=mu[state]*mu[action]*td_step(1.,phi[state],0.,phi[action],rho,gamma,alpha)
    assert abs(enumerated_step-(1-alpha*A))<1e-14
    table_A=np.diag(mu)@(np.eye(2)-gamma*np.array([[0,1],[0,1]]))
    table_radius=float(max(abs(np.linalg.eigvals(np.eye(2)-alpha*table_A))))
    assert table_radius < 1
    # No bootstrap: regression on the known zero return has positive curvature C.
    C=float(mu@(phi**2));assert abs(C-1.15)<1e-13
    t=np.arange(0,4001,100);curves={'offpolicy_TD':(1-alpha*A)**t,'onpolicy_TD':(1-alpha*.4)**t,'return_regression':(1-alpha*C)**t}
    fig,axes=plt.subplots(1,2,figsize=(11,3.3),gridspec_kw={'width_ratios':[1.3,1]})
    ax=axes[0];pos={0:(0,0),1:(3.5,0)}
    for s,(x,y) in pos.items():
        ax.add_patch(Circle((x,y),.42,fc='white',ec=INK,lw=1.4,zorder=3));ax.text(x,y,f'$s_{s}$',ha='center',va='center',fontsize=19)
        ax.text(x,-.72,r'$\hat v=w$' if s==0 else r'$\hat v=2w$',ha='center',fontsize=14)
    for start,end,rad,color,label,xy in [((.42,.07),(3.08,.07),-.25,TEAL,'$a_1$',(1.75,.75)),((3.08,-.07),(.42,-.07),-.25,RED,'$a_0$',(1.75,-.72)),((-.25,.34),(.25,.34),-2.8,RED,'$a_0$',(0,1.05)),((3.25,.34),(3.75,.34),-2.8,TEAL,'$a_1$',(3.5,1.05))]:
        ax.add_patch(FancyArrowPatch(start,end,connectionstyle=f'arc3,rad={rad}',arrowstyle='-|>',mutation_scale=13,lw=2,color=color));ax.text(*xy,label,color=color,ha='center',fontsize=13)
    ax.text(1.75,-1.32,r'$R_t=0,\ \gamma=0.9,\ v_\pi=(0,0)$',ha='center',fontsize=13)
    ax.set(xlim=(-.9,4.4),ylim=(-1.5,1.45));ax.axis('off')
    xx=np.arange(2);axes[1].bar(xx-.18,mu,width=.36,color=RED,label='Behavior occupancy')
    axes[1].bar(xx+.18,[0,1],width=.36,color=TEAL,label='Target occupancy')
    for x,y in zip(xx-.18,mu):axes[1].text(x,y+.035,f'{y:.2f}',ha='center',fontsize=12)
    axes[1].set(xticks=xx,xticklabels=['$s_0$','$s_1$'],ylim=(0,1.4),ylabel='Stationary probability')
    axes[1].legend(fontsize=10,loc='upper left');fig.tight_layout();save(fig,'deadly-task')
    fig,axes=plt.subplots(1,2,figsize=(11,3.3))
    ps=np.linspace(0,.999,201);gain=.4-1.2*ps
    axes[0].plot(ps,gain,color=INK,lw=2);axes[0].axhline(0,color='#999999',lw=.8)
    axes[0].axvspan(1/3,1,color=RED,alpha=.07)
    axes[0].scatter([.95],[-.74],color=RED,zorder=3);axes[0].annotate(r'$p=.95:\ A=-.74$',(.95,-.74),(.30,-.55),arrowprops={'arrowstyle':'->','color':RED},fontsize=12)
    axes[0].text(.61,.18,'TD mean update expands',color=RED,ha='center',fontsize=11)
    axes[0].set(xlabel=r'Behavior $p=b(a_0\mid s)$',ylabel=r'$A=.4-1.2p$',xlim=(0,1),ylim=(-.85,.45))
    for name,color,label in [('offpolicy_TD',RED,'Off-policy TD'),('onpolicy_TD',TEAL,'On-policy TD'),('return_regression',GOLD,'Zero-return fit')]:axes[1].plot(t,curves[name],lw=2,color=color,label=label)
    axes[1].set(xlabel='Exact mean-operator iterations',ylabel=r'$w_k$  (initial $w_0=1$)',yscale='log')
    axes[1].legend(fontsize=10);fig.tight_layout();save(fig,'deadly-gain')
    return {'task':'all rewards 0; a0 -> s0; a1 -> s1; target a1 always','behavior_a0':p,'behavior_stationary':mu.tolist(),
            'rho_a1':1/(1-p),'rho_a0':0,'A_enumerated':A,'A_matrix':float(A_matrix),
            'table_expected_update_spectral_radius':table_radius,'gain_offpolicy':1-alpha*A,
            'gain_onpolicy':1-alpha*.4,'gain_return_regression':1-alpha*C,'iteration_protocol':'deterministic exact mean operator, not sampled learning',
            'curves':{name:y.tolist() for name,y in curves.items()}}

def walk_policy(pr):
    P=np.zeros((19,19));r=np.zeros(19)
    for i in range(19):
        for delta,prob in [(-1,1-pr[i]),(1,pr[i])]:
            j=i+delta
            if 0<=j<19:P[i,j]+=prob
            else:r[i]+=prob*(-1 if j<0 else 1)
    visits=np.linalg.solve(np.eye(19)-P.T,np.eye(19)[9]);v=np.linalg.solve(np.eye(19)-P,r)
    # Gambler's ruin with nonconstant right probabilities: independent recurrence.
    scale=np.r_[1.,np.cumprod((1-pr)/pr)]
    right=np.cumsum(scale)[:-1]/sum(scale)
    assert np.max(abs(v-(2*right-1)))<1e-8
    return visits/visits.sum(),float(visits.sum()),float(v[9])

def control_checks():
    # Same 19 states and exit rewards; actions now choose left/right.
    # One specified transition, then two frozen policies are evaluated analytically.
    q=np.array([[.5,.0],[.15,.1],[.0,.5]])
    qnext=q.copy();delta=q[2,1]-q[1,1];qnext[1,1]+=.5*delta
    assert np.allclose(qnext[1],[.15,.3])
    eps=.2
    def right_probs(w):return eps/2+(1-eps)*(w[GROUP,1]>w[GROUP,0])
    old,new=right_probs(q),right_probs(qnext)
    assert np.allclose(new-old,(GROUP==1)*.8)
    mu0,n0,j0=walk_policy(old);mu1,n1,j1=walk_policy(new)
    assert np.all(mu0 >= 0) and np.all(mu1 >= 0)
    assert abs(mu0.sum()-1)<1e-13 and abs(mu1.sum()-1)<1e-13
    fig,axes=plt.subplots(1,3,figsize=(12,2.65),gridspec_kw={'width_ratios':[.85,1.2,1.25]})
    xx=np.arange(2)
    axes[0].bar(xx-.17,q[1],width=.34,color=INK,label='Before')
    axes[0].bar(xx+.17,qnext[1],width=.34,color=TEAL,label='After')
    axes[0].set(xticks=xx,xticklabels=['Left','Right'],ylabel='Q in shared group 2',ylim=(0,.42))
    axes[0].legend(fontsize=10)
    axes[1].step(STATES,old,where='mid',color=INK,lw=2,label='Before')
    axes[1].step(STATES,new,where='mid',color=TEAL,lw=2,label='After')
    axes[1].axvspan(6.5,13.5,color=GOLD,alpha=.12)
    axes[1].set(xlabel='State',ylabel='P(right), epsilon = 0.2',ylim=(0,1),xticks=[1,7,10,13,19])
    axes[2].plot(STATES,mu0,'o-',ms=3,color=INK,label='Old policy')
    axes[2].plot(STATES,mu1,'o-',ms=3,color=TEAL,label='Updated policy')
    axes[2].set(xlabel='State',ylabel='Expected visit fraction',xticks=[1,7,10,13,19]);axes[2].legend(fontsize=10)
    fig.tight_layout(pad=.6);save(fig,'control-distribution')
    return {'sample':[13,'right',0,14,'right'],'alpha':.5,'epsilon':eps,'delta':delta,'q_before':q.tolist(),'q_after':qnext.tolist(),
            'right_probability_before':old.tolist(),'right_probability_after':new.tolist(),
            'visit_fraction_before':mu0.tolist(),'visit_fraction_after':mu1.tolist(),
            'expected_episode_length_before':n0,'expected_episode_length_after':n1,
            'start_return_before':j0,'start_return_after':j1,
            'evaluation':'two frozen epsilon-greedy policies, analytically evaluated; not a Sarsa training result'}

if __name__=='__main__':
    report={'aggregation':aggregation_checks(),'offpolicy':offpolicy_checks(),'control':control_checks()}
    (OUT/'calculations.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
    print(json.dumps({k: {x:v for x,v in d.items() if not isinstance(v,list) and x!='curves'} for k,d in report.items()},indent=2))
