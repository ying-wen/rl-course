# 第 9 章　函数逼近：程序

本目录可以单独运行：在本目录下执行下面的命令即可，结果写回本目录的 `assets/`。目录由 `rl-course/tools/export_chapter_code.py` 从课程目录生成，改程序请改课程目录里的原件，再重新导出。

## 准备

```sh
python3 -m pip install -r requirements.txt
```

需要的第三方包：matplotlib、numpy、torch。复现附录要求 Python 3.10 或更新版本；核验时用的版本见下表。

## 运行（与复现附录相同）

```sh
python demos/course15_approximation.py
python3 demos/ch09_mechanisms.py
python demos/v19_approximation.py
python3 demos/deep_v13_connections.py
python demos/v18_methods.py
python demos/approximation_v9_walkthrough.py
python demos/value_policy_mechanisms.py
python demos/linear_offpolicy_prediction.py
```

## 本目录的程序

| 程序 | 说明 | 核验 |
|---|---|---|
| `demos/course15_approximation.py` | Chapter 9: model-free prediction with shared parameters. | 通过（17 秒） |
| `demos/deep_v13_connections.py` | Recompute the numerical mechanisms used in Chapters 9--12. | 通过（2 秒） |
| `demos/ch09_mechanisms.py` | 第 9 章机制页的数值：特征波及、傅里叶拟合、步长规则、目标随参数移动、 | 通过（20 秒） |
| `demos/v18_methods.py` | One-update scientific diagrams for chapters 7--11; no training runs. | 通过（3 秒） |
| `demos/v19_approximation.py` | Chapter 9: exact update, projection, off-policy, and control calculations. | 通过（3 秒） |
| `demos/approximation_v9_walkthrough.py` | Exact, inspectable examples for Chapter 9. Run from any directory. | 通过（2 秒） |
| `demos/linear_offpolicy_prediction.py` | Linear TD, GTD2, TDC and ETD(0), with explicit old-parameter updates. | 通过（1 秒） |
| `demos/value_policy_mechanisms.py` | Small, exact calculations for chapters 9--11. Python 3 + numpy + matplotlib. | 通过（1 秒） |
| `demos/ch09_baird_redraw.py` | Baird 反例重算（第 9 章 ch09-baird 页的中文重画用）。 | 通过（0 秒） |
| `demos/approximation_lab.py` | Two-step prediction: representation, replay weighting and bootstrap. | 通过（3 秒） |
| `demos/core_v10_learning.py` | Chapter 9/11 calculations, diagrams, and a small REINFORCE experiment. | 通过（4 秒） |
| `demos/ch09_learning_figures.py` | 第 9 章 9.2 节两张实验图：学习曲线（course15-fa-learning）与学得的预测（ch09-learned-values）。 | 通过（48 秒） |

被上面程序 import 的本课模块：`demos/course15_traces.py`、`demos/dqn_model_v11.py`、`demos/mud_world.py`、`demos/plot_fonts.py`、`demos/ppo_sac_v11_lab.py`、`demos/sample14_pg.py`、`demos/sample14_sac.py`、`demos/v17_methods.py`。

表中后 4 个程序复现附录本章一节没有列出，来自课件、阅读稿、CODE-MAP 或文件名前缀（第三部分另含学习器阶梯）。

## 复现附录本章一节

本章的随机游走学习曲线、一次更新的波及与步长表、两状态离策略任务的平均倍数与 GTD 实验，以及学右忘左的遗忘曲线，都来自本课的程序。Mountain Car 的价值曲面、Baird 反例与投影几何图取自原书和 RLSS 课件，没有对应程序。

| 位置 | 结果 | 设置 | 程序 | 数据与输出 |
|---|---|---|---|---|
| 章首；9.1 节；9.2 节；9.3 节 | 19 状态随机游走与三组参数图；状态 4 一次更新在 one-hot 与聚合表示中的传播；真值、最佳三个常数与访问频率；两种投影；沿对称方向的价值误差与 TD 平均方向；只改状态权重的两组解析解（右组 MC 解 $17/30\to.65$，TD 平衡值 $1/7\to1/2$） | 本课的计算：19 个非终止状态，起点 10，退出奖励 $\mp1$，$\gamma=1$，状态分 1–6、7–13、14–19 三组；$\mu(s)=\min(s,20-s)/100$；解析参照只用于评价 | `demos/course15_approximation.py` | `assets/course15-fa/results.json`；图见 `assets/course15-fa/README.md`（task、sharing、values-visits、projection、objective-fixedpoint、weighting） |
| 9.1 节“瓦片编码与局部泛化” | 输入 $s=.53$ 激活四个格子，$\delta=2,\alpha=.05$ 后每个权重 $+.1$，起点价值 $+.4$，共享两格的状态 $+.2$ | 本课的计算：四层错位的瓦片网格，各自独立权重，一次线性更新（函数 `tile_features`） | `demos/deep_v13_connections.py` | `assets/deep-v13/checks.json`（`tile_update`）；`assets/deep-v13/tile-generalization.png` |
| 9.1 节“傅里叶基”“一次更新波及哪里”“步长怎样定”“目标跟着预测移动”；课件 ch09-fourier、ch09-spread、ch09-step-size、ch09-target-moves | 傅里叶 1、3、5 阶加权 RMSE：$\gamma=.9$ 时 $.092,.045,.023$，$\gamma=1$ 时 $.040,.013,.006$；五种特征在状态 16 的波及柱图（傅里叶 5 阶在 1、2 处约 $.24,.12$）；步长表（粗编码 $\mathbb E[\mathbf x^\top\mathbf x]=3.44,\alpha=.029$；傅里叶 $3.26,.031$）；两状态例 $.8\to.864$ | 本课的计算：主算例的精确加权最小二乘与单次更新，$\tau=10$；无采样 | `demos/ch09_mechanisms.py` | `demos/ch09-mechanisms-results/results.json`（`fourier`、`spread`、`step_rule`、`chase`） |
| 9.1 节“半梯度的求导路径” | 同一转移后聚合价值函数的变化：两种更新都把第一组从 $-.4$ 提到 $-.34$，完整残差梯度还把第二组从 $.2$ 降到 $.14$ | 本课的计算：$\delta=.6,\alpha=.1$ 的一次更新，有限差分核对梯度 | `demos/v18_methods.py` | `assets/v18-methods/report.json`（`semigradient`）；`assets/v18-methods/semigradient-values.png` |
| 9.2 节“平均更新的向量场”；9.3 节“夹角为何小于直角”；课件 ch09-vector-field、ch09-why-converge | 平均更新 $\mathbf b_0-\mathbf A\mathbf w$ 的箭头图，箭头指向 TD 固定点 $(0,1/7)$；从四角出发的平均更新路径；最大夹角 $47^\circ$ | 本课的计算：主算例三组聚合特征下的 $\mathbf A,\mathbf b_0$，确定性平均更新迭代 | `demos/ch09_mechanisms.py` | `demos/ch09-mechanisms-results/results.json`（`mean_dynamics`） |
| 9.2 节“MC 投影、TD 固定点与学习曲线”；课件 course15-fa-learning、ch09-learned-values；9.3 节与自测题 6 | 学习曲线与学得价值：最终平均权重 MC $(-.568,-.002,.560)$、TD $(-.156,-.020,.130)$；平均价值 RMSE $.174$ 与 $.326$，解析参照 $.17359$ 与 $.32492$；误差界实测比值约 $3.50$；访问频率与解析 $\mu$ 的最大差约 $2.79\times10^{-4}$ | 本课的模拟：每次运行中每次访问 MC（步长 $1/N$）与半梯度 TD（步长 $.15/(1+N/1000)^{.65}$）读取相同轨迹，均从零开始，每次 12,000 回合，每 50 回合记录一次；独立重复 8 次，阴影为样本标准差 | `demos/course15_approximation.py` | `assets/course15-fa/results.json`；`assets/course15-fa/learning-checkpoints.csv`；`assets/course15-fa/training-data.npz`；`assets/course15-fa/learning.png` |
| 9.2 节；9.4 节；9.5 节“一次共享更新怎样改变采样” | TD 固定点的 Bellman 目标与逐状态加权残差；精确投影算子迭代；两状态任务及平稳访问概率；行为状态权重与平均更新系数（$\alpha=.001$ 时同策略 $1-.4\alpha$、回报回归 $1-1.15\alpha$）；控制例中第二组右动作权重 $.1\to.3$，起点回报约 $-.9997\to.9997$ | 本课的计算：有限模型上的精确平均算子与解析评价，未训练智能体；控制例 $\alpha=.5,\varepsilon=.2$ | `demos/v19_approximation.py` | `assets/v19-approximation/calculations.json`；图 projection-balance、fixedpoint-map、deadly-task、deadly-gain、control-distribution（同目录） |
| 9.4 节“三缺一就稳”；课件 ch09-triad-minus-one、course24-triad-ablation | 两状态任务平均倍数：三项都有 $1.074$，去掉离策略 $.96$，去掉自举 $.885$，表格两个方向 $.905$ 与 $.9995$；临界概率 $p=1/3$ | 本课的计算：行为在两处选 $a_0$ 的概率 $.95$，$\alpha=.1$，精确期望更新 | `demos/ch09_mechanisms.py` | `demos/ch09-mechanisms-results/results.json`（`triad`） |
| 9.5 节“预测准确性与控制表现” | 单步决策两套估计：甲 $(.7,.6)$ 均方误差 $.065$、选 $a_1$；乙 $(.9,.95)$ 均方误差 $.01625$、回报降到 $.8$ | 本课的计算：两动作期望奖励 $1$ 与 $.8$，等权误差 | `demos/approximation_v9_walkthrough.py` | `assets/v9-approximation/calculations.json`（`control`）；`assets/v9-approximation/value-error-control.png` |
| 9.5 节“参数资格迹”前的非线性例 | 一次运行中 $(w_1,w_2)$ 从 $(.2,.7)$ 学到约 $(1.115,1.053)$；第 16 格与第 4 格的梯度内积训练前 $-.168$、12,000 回合后 $-.524$ | 本课的模拟：两参数 tanh 预测器，只用实际退出回报作标签，每回合累计梯度除以 100 后更新；种子 0 的一次运行 | `demos/course15_approximation.py` | `assets/course15-fa/results.json`（`neural`）；`assets/course15-fa/training-data.npz`；`assets/course15-fa/neural-kernel.png` |
| 9.6 节“半梯度、残差梯度和可获得的数据” | 后继特征等概率为 0 或 2 的例子：样本半平方损失的梯度乘积平均 $.5$，期望 TD 误差平方的梯度 $.25$ | 本课的计算：四种等概率配对的枚举 | `demos/approximation_v9_walkthrough.py` | `assets/v9-approximation/calculations.json`（`checks.double_sampling`） |
| 9.6 节“梯度TD与强调式TD”；课件 core-v8-offpolicy-experiment | 第 6,000 步按行为状态分布计算的价值 RMSE：TD $88.36$，GTD2 $.0659$，TDC $.0611$ | 本课的模拟：两状态任务，奖励恒为零，三种方法从 $w=1$ 出发并读取同一条行为轨迹，$\alpha=.001$，$\beta=.01$，$\mathbf h$ 初值为零，每次 6,000 步；独立重复 32 次，阴影为四分位带 | `demos/linear_offpolicy_prediction.py` | `demos/linear-offpolicy-results/report.json`；`demos/linear-offpolicy-results/mean-rmse.csv`；`assets/v8-mechanisms/linear-offpolicy.pdf` |
| 9.6 节“最小二乘TD（LSTD）” | 两状态例的 LSTD 样本方程 $A=1.1,b=1$，解 $w\approx.909$，MC 解 $.95$ | 本课的计算：线性方程求解与零平均 TD 误差核对 | `demos/deep_v13_connections.py` | `assets/deep-v13/checks.json`（`lstd`） |
| 9.7 节“隐藏状态价值的不可辨识性” | 可见预测目标相同而隐藏状态真值不同的误差曲线 | 本课的计算：精确的可观测性算例，不含训练 | `demos/value_policy_mechanisms.py` | `assets/v8-mechanisms/observable-objective.pdf`；讲义用其 PNG 版 `assets/course15-fa/observable-objective.png` |
| 9.8 节“学右忘左”“SGD 与 Adam”；课件 ch09-net-forgetting、ch09-net-optimizer | 左半误差（4000 步 / 8000 步）：瓦片编码 $.048/.062$，傅里叶 5 阶 $.006/.189$，网络 SGD $.014/.156$，回放一半 $.014/.010$；Adam（$\eta=.003$）从 $.007$ 升到约 $.10$，之后在 $.07$ 附近；SGD 与 Adam 单步移动对照 | 本课的模拟：主算例，目标取真值，前 4000 步只更新左半 1–9，后 4000 步只更新右半 11–19；网络 32 个 tanh 隐单元，SGD 步长 $.02$；线性特征取 $\tau=20$；独立重复 20 次 | `demos/ch09_mechanisms.py` | `demos/ch09-mechanisms-results/results.json`（`two_stage`、`adam_scale`） |

运行：
```sh
python demos/course15_approximation.py
python3 demos/ch09_mechanisms.py
python demos/v19_approximation.py
python3 demos/deep_v13_connections.py
python demos/v18_methods.py
python demos/approximation_v9_walkthrough.py
python demos/value_policy_mechanisms.py
python demos/linear_offpolicy_prediction.py
```

外部代码与公开数据（出处）：Mountain Car 剩余代价曲面（Sutton 与 Barto，第 2 版，图 10.1，摘录于 assets/deep-v13/sutton-mountain-car-fig10-1.png 与 assets/ch09-revision/mountain.pdf）；Baird 反例（Sutton，RLSS Lecture 04-1）；投影几何原图（Sutton 与 Barto，图 11.3）；积木任务与属性规划原图（Zhang 等，Composable Planning with Attributes，图 1，由 demos/course_v12_visuals.py 按 `--source-crops` 裁取）。

## 参考数据

`assets/`（以及 `demos/NN-results/`）下复制了 31 个数据文件（json、csv 等），即课程目前使用的结果；图片没有复制，运行程序会重新画出。重跑会覆盖这些文件，可以先另存一份再对照。
