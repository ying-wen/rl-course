# 第 19 章　通用价值函数：程序

本目录可以单独运行：在本目录下执行下面的命令即可，结果写回本目录的 `assets/`。目录由 `rl-course/tools/export_chapter_code.py` 从课程目录生成，改程序请改课程目录里的原件，再重新导出。

## 准备

```sh
python3 -m pip install -r requirements.txt
```

需要的第三方包：matplotlib、numpy。复现附录要求 Python 3.10 或更新版本；核验时用的版本见下表。

## 运行（与复现附录相同）

```sh
python3 demos/crl_joint_v12.py
python3 demos/v18_systems.py
python3 demos/door_signal.py --reliability 3/4
python3 demos/ch19_warehouse_main.py         # 写 assets/ch19-warehouse-questions
python3 demos/ch19_warehouse_extra.py
python3 demos/ch19_warehouse_redundancy.py
python3 demos/ch19_warehouse_long.py         # 10 万步，较慢
python3 demos/ch19_open_worlds.py pilot      # 10 对预试
python3 demos/ch19_open_worlds.py full 100   # 写 assets/ch19-open-worlds
python3 demos/crl_ladder_learners.py --exp ch19 --seeds 60 --seed0 100 --steps 2000000 --tag formal   # 四区仓库阶梯，写 assets/crl-ladder-world/runs/formal-ch19.json
python3 demos/crl_ladder_figures.py ch19           # 写 assets/crl-ladder-world/fig/ladder-ch19.png
```

## 本目录的程序

| 程序 | 说明 | 核验 |
|---|---|---|
| `demos/crl_joint_v12.py` | One continuing navigation task, learned skills, GVFs and rate-aware planning. | 通过（180 秒） |
| `demos/v18_systems.py` | Small CPU checks and teaching figures for the v18 systems/continual review. | 通过（3 秒） |
| `demos/door_signal.py` | A cue, a decision, and a delayed alarm in the course's delivery task. | 通过（0 秒） |
| `demos/ch19_warehouse_questions.py` | Warehouse (ch15-18 main example) with auxiliary GVF questions read by the controller at J. | 通过（0 秒） |
| `demos/ch19_warehouse_main.py` | All numbers for chapter 19.6 pages.  Usage: python3 exp19.py [T_long] | 通过（76 秒） |
| `demos/ch19_warehouse_extra.py` | Extra numbers: final held questions, proxy 'use' of six fixed questions, surprise strip, paired wins. | 通过（24 秒） |
| `demos/ch19_warehouse_redundancy.py` | — | 通过（6 秒） |
| `demos/ch19_warehouse_long.py` | Open problem 22 setting: K=8, T=1e5, 30 pairs, random vs surprise proposer. | 通过（228 秒） |
| `demos/ch19_open_worlds.py` | Chapter 19 open problem: worlds A and B that can separate ways of proposing questions. | 通过（268 秒） |
| `demos/crl_ladder_learners.py` | 四区仓库的学习器阶梯（例子方案第三步）。 | 超时：300 秒内未跑完（启动正常） |
| `demos/crl_ladder_figures.py` | 阶梯世界（四区仓库）阅读稿用图：地图与各章“占天花板”条形。 | 通过（1 秒） |
| `demos/crl_ladder_world.py` | 四区仓库：第三部分的能力阶梯世界（环境与精确参照）。 | 通过（16 秒） |
| `demos/crl_ladder_world_checks.py` | 四区仓库的独立检查（照 v12 的做法：手算、枚举、独立实现互查）。 | 通过（16 秒） |
| `demos/crl_ladder_power.py` | 四区仓库学习器阶梯：试点估 σ_Δ 定种子数，正式跑后出第 24 章的账本。 | 通过（0 秒） |
| `demos/crl_ladder_ceiling.py` | 四区仓库学习器阶梯：每个试验条件的“天花板”，供账本算“离最优还差多少”。 | 超时：300 秒内未跑完（启动正常） |
| `demos/crl_ladder_diagnostics.py` | 四区仓库阶梯的诊断与改法（11-20）。 | 通过（0 秒） |

表中后 5 个程序复现附录本章一节没有列出，来自课件、阅读稿、CODE-MAP 或文件名前缀（第三部分另含学习器阶梯）。

## 第三部分的学习器阶梯（例子方案第三步）

四区仓库世界与 L0–L10 阶梯学习器。每章一个实验，三档：没有、设计者给定、从经验学到。比较都是配对的：同一种子下两档用同一份世界随机数。

```sh
python3 demos/crl_ladder_world.py --fast                     # 各区参考线，写 reference.json（全量去掉 --fast）
python3 demos/crl_ladder_world_checks.py                     # 世界本身的核对
python3 demos/crl_ladder_ceiling.py                          # 各条件的天花板（ε-软最好率），写 ceiling.json
python3 demos/crl_ladder_learners.py --exp ch19 --seeds 2 --steps 200000 --procs 2 --tag smoke   # 冒烟：写 assets/crl-ladder-world/runs/smoke-ch19.json
python3 demos/crl_ladder_learners.py --exp ch19 --seeds 60 --seed0 100 --steps 2000000 --tag formal   # 正式设置（种子数与 runs/ 里的正式记录相同）
python3 demos/crl_ladder_power.py ledger --runs formal-ch19     # 配对差与 95% 区间，写 ledger-formal-ch19.json
python3 demos/crl_ladder_figures.py ch19                       # 阅读稿用的地图与条形图（读账本）
```

参考记录在 `assets/crl-ladder-world/runs/`（随本目录复制）。正式设置一章要跑数十分钟到数小时；冒烟一行只确认程序能走通。正式结果与读法见 `assets/crl-ladder-world/README.md` 第八节，改进与诊断见第九节。

## 复现附录本章一节

本章来自本课程序的结果有：19.3 节的实际行程与路线传播图，19.4 节门口实验的探索概率，19.6 节的仓库实验（含四区仓库上的阶梯实验），以及开放问题一节的世界甲、乙。

其余数字由正文推导直接算出，包括 19.1 节的 65/32 与 2/8，19.3 节的 TD 表 .60 → .40、2.00 → 2.25 与 $v(A)=5$ 时的目标 6、7 和更新值 5.2、5.4，19.4 节比率为 4 的一步中的 .64、2.2、1.6，19.5 节期限、预算与不完全核验下的概率，19.3 节延伸中事件概率的 .08 与 .54，19.4 节延伸门口例的 $-.20$ 与 .30，19.7 节重新计价的 $9-6p$、$6-2p$ 与交点 $p=.75$。19.1 节的八步轨迹信号图和 19.2 节的三种学法图是手绘 SVG，没有绘图程序。19.4 节中 Horde 的 85 ms 来自所引文献。

| 位置 | 结果 | 设置 | 程序 | 数据与输出 |
|---|---|---|---|---|
| 19.3 同一次访问上的 TD 与蒙特卡洛目标 | 第 39,997 步仍在 A、第 40,003 步到 C 的实际行程，时长样本 7 | 本课的模拟：三站连续配送（Y 形格，打滑概率 .1，C 站到站奖励在第 60,000 步由 3 降为 .1），每次运行 120,000 个原始转移、不回放、不重置；不规划、规划、冻结三种条件，独立重复 8 次。正文取规划条件种子 0 的这一段 | `demos/crl_joint_v12.py` | `assets/crl-joint-v12/raw-planning-seed0.npz`、`assets/crl-joint-v12/manifest.json` |
| 19.3 自举信息沿路线的传播 | 第 1、6、30 次去 C 之后的时长与奖励预测曲线；第一次到 C 只使 $c_3$ 处奖励预测变为 .6 | 本课的计算：A 到 C 的确定性去程 6 步，末步奖励 3，到 C 时延续为 0；表格初值为 0，步长 .2；200 次往返共 2,400 个原始转移，其中 1,200 个去程转移更新两个头；在第 1、6、30、200 次后取快照；确定性计算 | `demos/v18_systems.py` | `assets/v18-systems/gvf-route-learning.png`、`assets/v18-systems/gvf-route-updates.csv`、`assets/v18-systems/gvf-roundtrip-transitions.csv`、`assets/v18-systems/checks.json` |
| 19.4 节延伸“门口的目标策略覆盖、预测选取与测试”中的门口实验 | 贪心选绕行时仍以 $.1\times.5=.05$ 的概率探索直行 | 本课的模拟：每趟门口选路以概率 .1 探索，探索时以 .5 的概率直行，其余按当前动作价值（按读到的标记分组的样本均值）贪心；完整路线作为一次选择，只用所选路线的反馈学习；保留与不保留线索两组各走至多 512 趟，独立重复 64 次 | `demos/door_signal.py` | `assets/door-signal/reader.json` |
| 19.6 节“两种提出方式的实验”（课件 `ch19-discovery-experiment`） | 前 3000 步全程回报：无辅助 1887、设计者给出 3202、意外触发 3311、看见指示 3321；意外触发减随机提出 $646\pm115$（$\pm$ 后为标准误，95% 区间 411 到 880） | 本课的模拟：仓库 $D\to J$，转角处线性 Sarsa 读预测问题的答案，8 个槽，门槛 1，每 100 步替换一次；30 对独立运行 | `demos/ch19_warehouse_questions.py`、`demos/ch19_warehouse_main.py` | `assets/ch19-warehouse-questions/ch19_warehouse_main.json` |
| 19.6 节“有用怎么量”的代理表与“两种提出方式的实验”（课件 `ch19-question-replace`、`ch19-discovery-experiment`） | 六个问题的代理，单独读入与六个同读两种（如两步内到 $B$ 为 2.29 与 1.06）；持有有用问题的运行比例：意外触发从第 100 步起全部持有，随机提出到第 3000 步为 87%；$10^5$ 步长程中差停在 735 附近，末一万步两者每步奖励都是 1.24。`ch19_warehouse_redundancy.py` 的两项同读与只读一项对照（多 81，标准误 17）现行讲义与课件未用 | 同上一行的仓库，30 对 | `demos/ch19_warehouse_extra.py`、`demos/ch19_warehouse_redundancy.py`、`demos/ch19_warehouse_long.py` | `assets/ch19-warehouse-questions/ch19_warehouse_extra.json`、`assets/ch19-warehouse-questions/ch19_warehouse_redundancy.json`、`assets/ch19-warehouse-questions/ch19_warehouse_long.json` |
| 开放问题“能分开提出方式的世界”：世界甲与奖励噪声 | $D_2$ 阶段意外触发减只给 $D_1$ 为 1010（985 到 1034）；七种做法分三段的全程回报；$\sigma_r=0,.5,1,2$ 时的优势、候选数与有用比例 | 本课的模拟：$B\to D_1\to D_2\to J$，每 3000 步换一次哪一格如实显示；学习器同 19.6 节；学习进度按误差平方快、慢滑动平均之差替换；10 对预试定数，100 对独立运行 | `demos/ch19_open_worlds.py` | `assets/ch19-open-worlds/ch19-open-worlds-pilot.json`、`assets/ch19-open-worlds/ch19-open-worlds-results.json` |
| 开放问题“能分开提出方式的世界”：世界乙 | 组合提出减单项 892（865 到 919）；上限减组合提出 108（72 到 144） | 本课的模拟：选路由两格读数的异或决定；组合提出以 .2 的概率把已留问题拼成双起点问题；100 对独立运行；端到端循环编码器未跑 | `demos/ch19_open_worlds.py` | 同上一行 |
| 19.6 节（课件 `ch19-ladder`） | 六十个种子都挑中“到充电桩的步数”这一问题，与设计者给定的问题结果相同；换成模型后 lifetime 率多 .0054 | 本课的模拟：四区仓库，200 万步，规律 R0，60 个种子；天花板 .1134 | `demos/crl_ladder_learners.py` 实验 `ch19` | `assets/crl-ladder-world/runs/formal-ch19.json`、`assets/crl-ladder-world/fig/ladder-ch19.png` |

运行：
```sh
python3 demos/crl_joint_v12.py
python3 demos/v18_systems.py
python3 demos/door_signal.py --reliability 3/4
python3 demos/ch19_warehouse_main.py         # 写 assets/ch19-warehouse-questions
python3 demos/ch19_warehouse_extra.py
python3 demos/ch19_warehouse_redundancy.py
python3 demos/ch19_warehouse_long.py         # 10 万步，较慢
python3 demos/ch19_open_worlds.py pilot      # 10 对预试
python3 demos/ch19_open_worlds.py full 100   # 写 assets/ch19-open-worlds
python3 demos/crl_ladder_learners.py --exp ch19 --seeds 60 --seed0 100 --steps 2000000 --tag formal   # 四区仓库阶梯，写 assets/crl-ladder-world/runs/formal-ch19.json
python3 demos/crl_ladder_figures.py ch19           # 写 assets/crl-ladder-world/fig/ladder-ch19.png
```

## 参考数据

`assets/`（以及 `demos/NN-results/`）下复制了 154 个数据文件（json、csv 等），即课程目前使用的结果；图片没有复制，运行程序会重新画出。重跑会覆盖这些文件，可以先另存一份再对照。
