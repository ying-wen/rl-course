# -*- coding: utf-8 -*-
import numpy as np, json, ch19_warehouse_questions as m
from pathlib import Path
_OUT = Path(__file__).resolve().parent.parent / 'assets' / 'ch19-warehouse-questions' / 'ch19_warehouse_redundancy.json'
_OUT.parent.mkdir(parents=True, exist_ok=True)
N=30; T=3000
def J(f): return np.array([m.run(T,100+i,500+i,fixed=f)['J'] for i in range(N)])
a=J([('D','L','B',2),('D','L','W',2)]); b=J([('D','L','B',2)]); c=J([('D','L','W',2)])
d=a-b
r=dict(both=float(a.mean()),B_only=float(b.mean()),W_only=float(c.mean()),both_minus_B=float(d.mean()),se=float(d.std(ddof=1)/np.sqrt(N)))
json.dump(r,open(_OUT, 'w'),indent=1); print(r)
