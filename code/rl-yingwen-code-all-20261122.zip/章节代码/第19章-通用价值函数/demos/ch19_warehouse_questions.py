# -*- coding: utf-8 -*-
"""Warehouse (ch15-18 main example) with auxiliary GVF questions read by the controller at J.

World: D (indicator s in {L,R} visible) -> J; at J action a: a==s -> B (+4), else W (0);
W -> C (+1); C -> B (0); B -> D (0, new indicator).  A 'TV' bit (fair coin) is shown every step.
Designer-given controller state: current observation only (no memory of s at J).
Question q=(start position, target action at J, target label, horizon d): from the start position,
following 'target action at J', does label appear within d steps?  Answer table V_q[obs at start].
The latest answer at the start is carried until the next query; the controller at J reads
x=[1, p_1..p_K] (linear Sarsa(0), normalized step).  Values truncate at arrival to B (trip return).
"""
import numpy as np, sys, json

POS = ['D', 'J', 'W', 'C', 'B']
OBS = ['DL', 'DR', 'J', 'W', 'C', 'B']
LABELS = ['D', 'J', 'B', 'W', 'C', 'TV']
GRAMMAR = [(s, a, y, d) for s in POS for a in 'LR' for y in LABELS for d in (1, 2, 3, 4)]
QSTAR = ('D', 'L', 'B', 2)


def obs_of(pos, s):
    return ('DL' if s == 0 else 'DR') if pos == 'D' else pos


class Q:
    __slots__ = ('spec', 'V', 'open', 'p', 'pbar', 'use', 'age')

    def __init__(self, spec):
        self.spec = spec; self.V = {o: 0.0 for o in OBS}; self.open = []
        self.p = 0.0; self.pbar = 0.0; self.use = 0.0; self.age = 0


def run(T, wseed, aseed, mode='none', fixed=(), K=8, alpha=.1, aq=.1, eps=.1,
        theta=1.0, Tr=100, Amin=300, read=True, oracle=False, record=False, trace=False):
    """mode: 'none' (fixed questions only), 'random', 'surprise'."""
    wr = np.random.default_rng(wseed)          # world: indicator per trip, TV per step
    lights = wr.integers(2, size=T + 5)
    tv = wr.integers(2, size=T + 5)
    ar = np.random.default_rng(aseed)          # agent: exploration and proposals
    slots = [Q(sp) for sp in fixed] + ([] if mode == 'none' else [None] * K)
    nf = len(slots) + 1 + (1 if oracle else 0)
    w = np.zeros((2, nf))
    V = {'DL': 0.0, 'DR': 0.0, 'W': 0.0, 'C': 0.0}
    trip = 0; s = lights[0]; pos = 'D'
    dl = np.zeros(T); rew = np.zeros(T); useful_held = np.zeros(T, dtype=bool) if record else None
    hist = []                                  # (pos, action at J or None) for look-back
    proposals = 0; useful_props = 0
    log = []

    def feat():
        x = np.zeros(nf); x[0] = 1.0
        for i, q in enumerate(slots):
            if q is not None and read:
                x[1 + i] = q.p
        if oracle:
            x[-1] = 1.0 if s == 0 else 0.0
        return x

    def is_useful(spec):
        st, a, y, d = spec
        if st != 'D' or y == 'TV':
            return False
        # answer under s=L vs s=R differs?
        return answer(spec, 0) != answer(spec, 1)

    def start_query(q, o):
        q.open.append([o, 0])
        q.p = q.V[o]

    a_prev = None; xJ = None
    for t in range(T):
        o = obs_of(pos, s)
        # open queries for questions starting here
        for q in slots:
            if q is not None and q.spec[0] == pos:
                start_query(q, o)
        # act
        if pos == 'J':
            xJ = feat()
            qa = w @ xJ
            if ar.random() < eps or qa[0] == qa[1]:
                a = int(ar.integers(2))
            else:
                a = int(np.argmax(qa))
            act = 'LR'[a]
            # usage statistics
            for i, q in enumerate(slots):
                if q is not None:
                    q.pbar += .01 * (q.p - q.pbar)
                    q.use += .01 * (abs((w[0, 1 + i] - w[1, 1 + i]) * (q.p - q.pbar)) - q.use)
            if a == s:
                nxt, r, term = 'B', 4.0, True
            else:
                nxt, r, term = 'W', 0.0, False
        else:
            act = None
            if pos == 'D':
                nxt, r, term = 'J', 0.0, False
            elif pos == 'W':
                nxt, r, term = 'C', 1.0, False
            elif pos == 'C':
                nxt, r, term = 'B', 0.0, True
            else:  # B
                nxt, r, term = 'D', 0.0, False
        rew[t] = r
        # TD error of main learner (trip return, truncated at B)
        delta = 0.0
        if pos == 'J':
            target = r + (0.0 if term else V[nxt])
            delta = target - w[a] @ xJ
            w[a] += alpha * delta * xJ / (xJ @ xJ)
        elif pos in ('W', 'C'):
            target = r + (0.0 if term else V[nxt])
            delta = target - V[pos]; V[pos] += alpha * delta
        elif pos == 'D':
            # next is J: bootstrap on greedy-free estimate of value at J under current features
            pass
        # world transition
        newtrip = (pos == 'B')
        if newtrip:
            trip += 1; s = lights[trip]
        prev_pos = pos; pos = nxt
        if pos == 'J' and prev_pos == 'D':
            # delta for D->J computed with the action chosen next step: use mean of Q(J,.)
            xx = feat(); vj = (w @ xx).mean()
            od = 'DL' if s == 0 else 'DR'
            delta = vj - V[od]; V[od] += alpha * delta
        dl[t] = delta
        hist.append((prev_pos, act))
        if trace:
            log.append((t, 'step', prev_pos, act, pos))
        # advance open queries
        for q in slots:
            if q is None:
                continue
            st, qa_, y, d = q.spec
            keep = []
            for qq in q.open:
                o0, n = qq
                if prev_pos == 'J' and act != qa_:
                    continue  # target action not taken: no sample for this question
                n += 1
                hit = (tv[t + 1] == 1) if y == 'TV' else (pos == y)
                if hit or n >= d:
                    Y = 1.0 if hit else 0.0
                    q.V[o0] += aq * (Y - q.V[o0])
                else:
                    keep.append([o0, n])
            q.open = keep
            q.age += 1
        # proposals
        if mode != 'none':
            free = [i for i, q in enumerate(slots) if q is None]
            active = set(q.spec for q in slots if q is not None)
            if free:
                spec = None
                if mode == 'random':
                    while True:
                        spec = GRAMMAR[ar.integers(len(GRAMMAR))]
                        if spec not in active:
                            break
                elif abs(delta) > theta and len(hist) >= 4:
                    k = int(ar.integers(1, 5))
                    win = hist[-k:]
                    st = win[0][0]
                    acts = [x[1] for x in win if x[1] is not None]
                    qa_ = acts[0] if acts else 'LR'[ar.integers(2)]
                    spec = (st, qa_, pos, k)
                    if spec in active:
                        spec = None
                if spec is not None:
                    i = free[0]; slots[i] = Q(spec); w[:, 1 + i] = 0.0
                    proposals += 1; useful_props += is_useful(spec)
                    if trace:
                        log.append((t, 'add', spec))
            # replacement
            if t % Tr == 0 and not free:
                cands = [i for i, q in enumerate(slots) if q.age >= Amin]
                if cands:
                    i = min(cands, key=lambda i: slots[i].use)
                    if trace:
                        log.append((t, 'drop', slots[i].spec, round(slots[i].use, 4)))
                    slots[i] = None; w[:, 1 + i] = 0.0
        if record:
            useful_held[t] = any(q is not None and is_useful(q.spec) for q in slots)
        hist = hist[-6:]
    out = dict(J=rew.sum(), rew=rew, delta=dl, proposals=proposals, useful_props=useful_props,
               final=[q.spec if q else None for q in slots])
    if record:
        out['held'] = useful_held
    if trace:
        out['log'] = log
    return out


def answer(spec, sL):
    """exact answer from start position with indicator s (0=L,1=R) for non-TV labels."""
    st, a, y, d = spec
    s = sL
    # deterministic path from st following target action at J; new indicator after B is unknown -> prob
    def paths(pos, s, n, known):
        # returns probability label y seen within n steps
        if n == 0:
            return 0.0
        if pos == 'D':
            nxt = 'J'
        elif pos == 'J':
            if not known:
                # indicator unknown: average over s
                return .5 * paths_j(0, n) + .5 * paths_j(1, n)
            nxt = 'B' if 'LR'.index(a) == s else 'W'
        elif pos == 'W':
            nxt = 'C'
        elif pos == 'C':
            nxt = 'B'
        else:
            nxt = 'D'
        if nxt == y:
            return 1.0
        return paths(nxt, s, n - 1, known and pos != 'B')

    def paths_j(s2, n):
        nxt = 'B' if 'LR'.index(a) == s2 else 'W'
        if nxt == y:
            return 1.0
        return paths(nxt, s2, n - 1, True)
    return paths(st, s, d, st == 'D')


if __name__ == '__main__':
    print(len(GRAMMAR), sum(1 for g in GRAMMAR if g[0] == 'D' and g[2] != 'TV' and answer(g, 0) != answer(g, 1)))
