# -*- coding: utf-8 -*-
"""All numbers for chapter 19.6 pages.  Usage: python3 exp19.py [T_long]"""
import sys, json
import numpy as np
import ch19_warehouse_questions as m
from pathlib import Path
_OUT = Path(__file__).resolve().parent.parent / 'assets' / 'ch19-warehouse-questions' / 'ch19_warehouse_main.json'
_OUT.parent.mkdir(parents=True, exist_ok=True)

N = 30
T = 3000
W = 100
out = {}


def ma(x):
    return np.convolve(x, np.ones(W) / W, mode='valid')


def curve(rews):
    M = ma(np.mean(rews, 0))
    return [[int(t + W), round(float(M[t]), 3)] for t in range(0, len(M), 100)]


def paired(a, b):
    d = np.asarray(a) - np.asarray(b)
    return dict(mean=float(d.mean()), se=float(d.std(ddof=1) / np.sqrt(len(d))),
                ci95=[float(d.mean() - 2.045 * d.std(ddof=1) / np.sqrt(len(d))),
                      float(d.mean() + 2.045 * d.std(ddof=1) / np.sqrt(len(d)))])


def runs(**cfg):
    return [m.run(cfg.pop('T', T) if 'T' in cfg else T, 100 + i, 500 + i, **cfg) for i in range(N)]


# (a) with / without auxiliary prediction
A = {}
A['none'] = runs()
A['notread'] = runs(fixed=[m.QSTAR], read=False)
A['read'] = runs(fixed=[m.QSTAR])
A['oracle'] = runs(oracle=True)
out['a'] = {k: dict(J=float(np.mean([o['J'] for o in v])), se=float(np.std([o['J'] for o in v]) / np.sqrt(N)),
                    curve=curve([o['rew'] for o in v]),
                    absdelta_last1000=float(np.mean([np.abs(o['delta'][-1000:]).mean() for o in v])))
            for k, v in A.items()}
out['a']['read_minus_none'] = paired([o['J'] for o in A['read']], [o['J'] for o in A['none']])
out['a']['notread_minus_none'] = paired([o['J'] for o in A['notread']], [o['J'] for o in A['none']])

# usefulness U(q) = paired J difference, for representative questions; plus prediction error
QS = [('D', 'L', 'B', 2), ('D', 'L', 'W', 2), ('J', 'L', 'B', 1), ('J', 'L', 'D', 1), ('D', 'L', 'TV', 1), ('W', 'L', 'C', 1)]
base = [o['J'] for o in A['none']]
out['U'] = {}
for q in QS:
    R = runs(fixed=[q])
    out['U'][str(q)] = paired([o['J'] for o in R], base)

# (b) proposers, same budget
for TT in (T, 10000):
    B = {}
    for mode in ('random', 'surprise'):
        B[mode] = [m.run(TT, 100 + i, 500 + i, mode=mode, record=True) for i in range(N)]
    res = {}
    for mode, v in B.items():
        J = np.array([o['J'] for o in v])
        first = [int(np.argmax(o['held'])) for o in v if o['held'].any()]
        res[mode] = dict(J=float(J.mean()), se=float(J.std() / np.sqrt(N)),
                         proposals=float(np.mean([o['proposals'] for o in v])),
                         useful_frac=float(np.sum([o['useful_props'] for o in v]) / np.sum([o['proposals'] for o in v])),
                         held_frac=float(np.mean([o['held'].mean() for o in v])),
                         held_end=float(np.mean([o['held'][-1] for o in v])),
                         held_curve=[[int(t), round(float(np.mean([o['held'][t] for o in v])), 3)] for t in range(0, TT, 100)],
                         first_useful_median=float(np.median(first)) if first else None,
                         curve=curve([o['rew'] for o in v]) if TT == T else None)
    res['diff'] = paired([o['J'] for o in B['surprise']], [o['J'] for o in B['random']])
    out['b%d' % TT] = res

# sensitivity at T=3000: theta, K, lookback fixed
sens = {}
for th in (0.5, 1.5, 2.5):
    R = [m.run(T, 100 + i, 500 + i, mode='surprise', theta=th) for i in range(N)]
    sens['theta=%g' % th] = float(np.mean([o['J'] for o in R]))
for K in (4, 16):
    for mode in ('random', 'surprise'):
        R = [m.run(T, 100 + i, 500 + i, mode=mode, K=K) for i in range(N)]
        sens['K=%d %s' % (K, mode)] = float(np.mean([o['J'] for o in R]))
out['sens'] = sens

# noisy TV: surprise in bits and learning progress for two questions, predictor init .5, alpha .1
def tv_stats(q, nwin=6, per=50, seed=1):
    rng = np.random.default_rng(seed)
    # queries for q from D: outcome depends on indicator for q*, coin for TV
    p = {0: .5, 1: .5}; losses = []
    for i in range(nwin * per):
        s = int(rng.integers(2))
        if q == 'TV':
            Y = int(rng.integers(2)); key = 0
        else:
            Y = 1 if s == 0 else 0; key = s
        pp = min(max(p[key], .01), .99)
        losses.append(-np.log2(pp if Y else 1 - pp))
        p[key] += .1 * (Y - p[key])
    L = np.array(losses).reshape(nwin, per).mean(1)
    return [round(float(x), 3) for x in L]
tvs = {}
for q in ('TV', 'qstar'):
    Ls = np.mean([tv_stats(q, seed=s) for s in range(200)], 0)
    tvs[q] = dict(loss_by_50_queries=[round(float(x), 3) for x in Ls],
                  progress=[round(float(Ls[i] - Ls[i + 1]), 3) for i in range(len(Ls) - 1)])
out['tv'] = tvs

json.dump(out, open(_OUT, 'w'), indent=1, ensure_ascii=False)
print(json.dumps({k: v for k, v in out.items() if k not in ('a',)}, indent=1, ensure_ascii=False)[:6000])
for k, v in out['a'].items():
    if isinstance(v, dict) and 'J' in v:
        print(k, round(v['J'], 1), round(v['se'], 1), 'abs delta', round(v['absdelta_last1000'], 3))
    else:
        print(k, v)
