# -*- coding: utf-8 -*-
"""Chapter 19 open problem: worlds A and B that can separate ways of proposing questions.

Run:  python3 demos/ch19_open_worlds.py pilot   # 10 pairs per contrast, prints sigma of paired differences
      python3 demos/ch19_open_worlds.py full N  # N pairs, writes demos/ch19-open-worlds-results.json

Warehouse with two indicator cells on the way to the junction:
  B -> D1 -> D2 -> J;  at J: correct side -> B (+4, trip ends); wrong side -> W (0) -> C (+1) -> B (0).
Each D cell shows one bit.  A 'TV' bit (fair coin) is shown every step.
World A (alternating): the side is shown truthfully at D1 during steps [0,P), at D2 during [P,2P),
  at D1 again during [2P,3P); the other cell shows an independent coin.  Phase is fixed at trip start.
World B (xor): side = bit(D1) xor bit(D2); both bits are fair coins.
Controller: linear Sarsa(0) at J on x = [1, p_1..p_K] (+ oracle side bit for the upper bound),
normalized step alpha=.1, epsilon=.1.  Questions as in chapter 19: (start, target action at J,
label, horizon d); answer table indexed by the observation at the start.  A start may be a pair
(D1, D2): then the table is indexed by both bits seen in the current trip (combination proposals).
Optional reward noise sigma_r is added to the reward the learner sees; J counts the true reward.
"""
import json
import sys
from pathlib import Path

import numpy as np

POS = ['D1', 'D2', 'J', 'W', 'C', 'B']
LABELS = ['D1', 'D2', 'J', 'B', 'W', 'C', 'TV']
GRAMMAR = [(s, a, y, d) for s in POS for a in 'LR' for y in LABELS for d in (1, 2, 3, 4)]
NEXT = {'B': 'D1', 'D1': 'D2', 'D2': 'J', 'W': 'C', 'C': 'B'}
P = 3000


def exact(start, a, y, d, side):
    """Answer when following a at J; when a is the wrong side the path goes to W."""
    pos = start
    for _ in range(d):
        if pos == 'J':
            pos = 'B' if 'LR'.index(a) == side else 'W'
        else:
            pos = NEXT[pos]
        if pos == y:
            return 1.0
    return 0.0


def is_useful(spec, world, truthful):
    """Does the answer differ across the values of the start key?  (TV never; non-D starts never.)"""
    st, a, y, d = spec
    if y == 'TV':
        return False
    starts = st if isinstance(st, tuple) else (st,)
    if not set(starts) <= {'D1', 'D2'}:
        return False
    first = starts[-1]   # the query opens at the last cell of the start
    if world == 'A':
        if truthful not in starts:
            return False
        return exact(first, a, y, d, 0) != exact(first, a, y, d, 1)
    if set(starts) != {'D1', 'D2'}:
        return False
    return exact(first, a, y, d, 0) != exact(first, a, y, d, 1)


class Q:
    __slots__ = ('spec', 'start', 'V', 'open', 'p', 'pbar', 'use', 'age', 'ef', 'es')

    def __init__(self, spec):
        self.spec = spec
        st = spec[0]
        self.start = st[-1] if isinstance(st, tuple) else st   # query opens at the last cell
        self.V = {}; self.open = []
        self.p = 0.0; self.pbar = 0.0; self.use = 0.0; self.age = 0
        self.ef = 0.25; self.es = 0.25


def run(T, wseed, aseed, world='A', mode='none', fixed=(), K=8, alpha=.1, aq=.1, eps=.1,
        theta=1.0, Tr=100, Amin=300, oracle=False, sigma_r=0.0, replace='use', pcomb=0.0,
        period=P):
    """mode: 'none' | 'random' | 'surprise'.  replace: 'use' | 'lp' (learning progress).
    pcomb: probability that a proposal combines two held D-questions into a pair-start question."""
    wr = np.random.default_rng(wseed)
    nt = T + 5
    side_t = wr.integers(2, size=nt)      # per trip
    coin_t = wr.integers(2, size=nt)      # per trip: the non-truthful bit (A) or bit of D1 (B)
    tv = wr.integers(2, size=nt)          # per step
    noise = wr.normal(size=nt) * sigma_r  # per step
    ar = np.random.default_rng(aseed)
    slots = [Q(sp) for sp in fixed] + ([] if mode == 'none' else [None] * K)
    nf = len(slots) + 1 + (1 if oracle else 0)
    w = np.zeros((2, nf))
    V = {}
    trip = 0; pos = 'B'
    rew = np.zeros(T)
    held = np.zeros(T, dtype=bool)
    hist = []
    proposals = 0; useful_props = 0

    def new_trip(t):
        nonlocal side, bits, truthful
        side = int(side_t[trip])
        if world == 'A':
            truthful = 'D1' if (t // period) % 2 == 0 else 'D2'
            other = int(coin_t[trip])
            bits = {'D1': side, 'D2': other} if truthful == 'D1' else {'D1': other, 'D2': side}
        else:
            truthful = None
            b1 = int(coin_t[trip])
            bits = {'D1': b1, 'D2': b1 ^ side}

    side = 0; bits = {}; truthful = None
    new_trip(0)
    pos = 'D1'

    def obs(p):
        return p + str(bits[p]) if p in ('D1', 'D2') else p

    def key(q):
        st = q.spec[0]
        if isinstance(st, tuple):
            return tuple(bits[c] for c in st)
        return obs(st)

    def feat():
        x = np.zeros(nf); x[0] = 1.0
        for i, q in enumerate(slots):
            if q is not None:
                x[1 + i] = q.p
        if oracle:
            x[-1] = 1.0 if side == 0 else 0.0
        return x

    xJ = None
    for t in range(T):
        o = obs(pos)
        for q in slots:
            if q is not None and q.start == pos:
                k = key(q)
                q.open.append([k, 0])
                q.p = q.V.get(k, 0.0)
        if pos == 'J':
            xJ = feat()
            qa = w @ xJ
            if ar.random() < eps or qa[0] == qa[1]:
                a = int(ar.integers(2))
            else:
                a = int(np.argmax(qa))
            act = 'LR'[a]
            for i, q in enumerate(slots):
                if q is not None:
                    q.pbar += .01 * (q.p - q.pbar)
                    q.use += .01 * (abs((w[0, 1 + i] - w[1, 1 + i]) * (q.p - q.pbar)) - q.use)
            if a == side:
                nxt, r, term = 'B', 4.0, True
            else:
                nxt, r, term = 'W', 0.0, False
        else:
            act = None
            nxt = NEXT[pos]
            r = 1.0 if pos == 'W' else 0.0
            term = pos == 'C'
        rew[t] = r
        rl = r + noise[t]
        delta = 0.0
        if pos == 'J':
            target = rl + (0.0 if term else V.get(nxt, 0.0))
            delta = target - w[a] @ xJ
            w[a] += alpha * delta * xJ / (xJ @ xJ)
        elif pos in ('W', 'C'):
            target = rl + (0.0 if term else V.get(nxt, 0.0))
            delta = target - V.get(pos, 0.0); V[pos] = V.get(pos, 0.0) + alpha * delta
        prev_pos = pos; pos = nxt
        if prev_pos == 'B':
            trip += 1; new_trip(t + 1)
        if prev_pos == 'D1':
            o2 = obs('D2')
            delta = V.get(o2, 0.0) - V.get(o, 0.0); V[o] = V.get(o, 0.0) + alpha * delta
        elif prev_pos == 'D2':
            vj = (w @ feat()).mean()
            delta = vj - V.get(o, 0.0); V[o] = V.get(o, 0.0) + alpha * delta
        hist.append((prev_pos, act))
        # advance open queries
        for q in slots:
            if q is None:
                continue
            st, qa_, y, d = q.spec
            keep = []
            for qq in q.open:
                k, n = qq
                if prev_pos == 'J' and act != qa_:
                    continue
                n += 1
                hit = (tv[t + 1] == 1) if y == 'TV' else (pos == y)
                if hit or n >= d:
                    Y = 1.0 if hit else 0.0
                    v = q.V.get(k, 0.0)
                    err = (Y - v) ** 2
                    q.ef += .1 * (err - q.ef); q.es += .01 * (err - q.es)
                    q.V[k] = v + aq * (Y - v)
                else:
                    keep.append([k, n])
            q.open = keep
            q.age += 1
        # proposals
        if mode != 'none':
            free = [i for i, q in enumerate(slots) if q is None]
            active = set(q.spec for q in slots if q is not None)
            if free:
                spec = None
                if pcomb > 0 and ar.random() < pcomb:
                    ds = [q.spec for q in slots if q is not None and not isinstance(q.spec[0], tuple)
                          and q.spec[0] in ('D1', 'D2') and q.spec[2] != 'TV']
                    d1 = [s for s in ds if s[0] == 'D1']; d2 = [s for s in ds if s[0] == 'D2']
                    if d1 and d2:
                        s1 = d1[ar.integers(len(d1))]; s2 = d2[ar.integers(len(d2))]
                        spec = (('D1', 'D2'), s2[1], s2[2], s2[3])
                        if spec in active:
                            spec = None
                elif mode == 'random':
                    while True:
                        spec = GRAMMAR[ar.integers(len(GRAMMAR))]
                        if spec not in active:
                            break
                elif abs(delta) > theta and len(hist) >= 4:
                    k = int(ar.integers(1, 5))
                    win = hist[-k:]
                    st = win[0][0]
                    acts = [x[1] for x in win if x[1] is not None]
                    qa_ = acts[0] if acts else 'LR'[ar.integers(2)]
                    spec = (st, qa_, pos, k)
                    if spec in active:
                        spec = None
                if spec is not None:
                    i = free[0]; slots[i] = Q(spec); w[:, 1 + i] = 0.0
                    proposals += 1; useful_props += is_useful(spec, world, truthful)
            if t % Tr == 0 and not free:
                cands = [i for i, q in enumerate(slots) if q.age >= Amin and i >= len(fixed)]
                if cands:
                    if replace == 'lp':
                        i = min(cands, key=lambda i: abs(slots[i].es - slots[i].ef))
                    else:
                        i = min(cands, key=lambda i: slots[i].use)
                    slots[i] = None; w[:, 1 + i] = 0.0
        held[t] = any(q is not None and is_useful(q.spec, world, truthful) for q in slots)
        hist = hist[-6:]
    return dict(rew=rew, held=held, proposals=proposals, useful_props=useful_props)


Q1 = ('D1', 'L', 'B', 3)
Q2 = ('D2', 'L', 'B', 2)
QX = (('D1', 'D2'), 'L', 'B', 2)

LEARNERS_A = {
    'none': dict(),
    'D1only': dict(fixed=[Q1]),
    'both': dict(fixed=[Q1, Q2]),
    'surprise': dict(mode='surprise'),
    'random': dict(mode='random'),
    'lp': dict(mode='random', replace='lp'),
    'oracle': dict(oracle=True),
}
LEARNERS_B = {
    'none': dict(),
    'single': dict(mode='surprise'),
    'comb': dict(mode='surprise', pcomb=.2),
    'designer_pair': dict(fixed=[QX]),
    'oracle': dict(oracle=True),
}
CONTRASTS_A = [('surprise', 'D1only'), ('surprise', 'both'), ('surprise', 'random'), ('surprise', 'lp')]
CONTRASTS_B = [('comb', 'single'), ('single', 'none'), ('oracle', 'comb')]


def block(world, learners, n, T, extra=None, base=100):
    out = {}
    for name, kw in learners.items():
        kw = dict(kw); kw.update(extra or {})
        R = [run(T, base + i, base + 5000 + i, world=world, **kw) for i in range(n)]
        nph = T // P
        J = np.array([[o['rew'][k * P:(k + 1) * P].sum() for k in range(nph)] for o in R])
        out[name] = dict(J=J, held=np.mean([o['held'].mean() for o in R]),
                         held_phase=[float(np.mean([o['held'][k * P:(k + 1) * P].mean() for o in R])) for k in range(nph)],
                         proposals=float(np.mean([o['proposals'] for o in R])),
                         useful=float(np.sum([o['useful_props'] for o in R]) / max(1, np.sum([o['proposals'] for o in R]))))
    return out


def paired(a, b):
    d = np.asarray(a, float) - np.asarray(b, float)
    n = len(d); s = d.std(ddof=1) if n > 1 else 0.0
    from math import sqrt
    tcrit = {10: 2.262, 20: 2.093, 30: 2.045, 40: 2.023, 50: 2.010, 60: 2.001, 80: 1.990, 100: 1.984}
    tc = tcrit.get(n, 1.96 if n > 100 else 2.0)
    se = s / sqrt(n)
    return dict(mean=float(d.mean()), sd=float(s), se=float(se), ci95=[float(d.mean() - tc * se), float(d.mean() + tc * se)],
                wins=int((d > 0).sum()), n=n)


def summarize(res, contrasts):
    s = {}
    for name, r in res.items():
        J = r['J']
        s[name] = dict(J_phase=[float(x) for x in J.mean(0)], se_phase=[float(x) for x in J.std(0, ddof=1) / np.sqrt(len(J))],
                       J_total=float(J.sum(1).mean()), held_phase=r['held_phase'], proposals=r['proposals'], useful=r['useful'])
    for a, b in contrasts:
        nph = res[a]['J'].shape[1]
        s['%s-%s' % (a, b)] = dict(phase=[paired(res[a]['J'][:, k], res[b]['J'][:, k]) for k in range(nph)],
                                    total=paired(res[a]['J'].sum(1), res[b]['J'].sum(1)))
    return s


def main():
    what = sys.argv[1] if len(sys.argv) > 1 else 'pilot'
    n = int(sys.argv[2]) if len(sys.argv) > 2 else 10
    out = {}
    T = 3 * P
    resA = block('A', LEARNERS_A, n, T)
    out['A'] = summarize(resA, CONTRASTS_A)
    out['A_noise'] = {}
    for sr in (0.5, 1.0, 2.0):
        r = block('A', {k: LEARNERS_A[k] for k in ('D1only', 'both', 'surprise', 'oracle')}, n, T, extra=dict(sigma_r=sr))
        out['A_noise'][str(sr)] = summarize(r, [('surprise', 'D1only'), ('surprise', 'both'), ('oracle', 'surprise')])
    resB = block('B', LEARNERS_B, n, P)
    out['B'] = summarize(resB, CONTRASTS_B)
    path = Path(__file__).resolve().parent.parent / 'assets' / 'ch19-open-worlds' / ('ch19-open-worlds-%s.json' % ('pilot' if what == 'pilot' else 'results'))
    path.parent.mkdir(parents=True, exist_ok=True)
    json.dump(out, open(path, 'w'), indent=1, ensure_ascii=False)
    for wk in ('A', 'B'):
        for k, v in out[wk].items():
            if 'J_phase' in v:
                print(wk, '%-14s' % k, [round(x) for x in v['J_phase']], 'se', [round(x) for x in v['se_phase']],
                      'held', [round(x, 2) for x in v['held_phase']], 'props %.1f useful %.2f' % (v['proposals'], v['useful']))
            else:
                print(wk, '%-14s' % k, 'total %.0f sd %.0f se %.0f' % (v['total']['mean'], v['total']['sd'], v['total']['se']),
                      'phases', [(round(p['mean']), round(p['sd'])) for p in v['phase']])
    for sr, s in out['A_noise'].items():
        for k, v in s.items():
            if 'J_phase' in v:
                print('A sr=%s %-10s' % (sr, k), [round(x) for x in v['J_phase']], 'props %.1f useful %.2f' % (v['proposals'], v['useful']))
            else:
                print('A sr=%s %-16s' % (sr, k), 'total %.0f sd %.0f' % (v['total']['mean'], v['total']['sd']),
                      'phases', [(round(p['mean']), round(p['sd'])) for p in v['phase']])


if __name__ == '__main__':
    main()
