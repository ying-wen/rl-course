# -*- coding: utf-8 -*-
"""Open problem 22 setting: K=8, T=1e5, 30 pairs, random vs surprise proposer."""
import json, numpy as np, ch19_warehouse_questions as m
from pathlib import Path
_OUT = Path(__file__).resolve().parent.parent / 'assets' / 'ch19-warehouse-questions' / 'ch19_warehouse_long.json'
_OUT.parent.mkdir(parents=True, exist_ok=True)
T = 100000; N = 30; res = {}
B = {mo: [m.run(T, 100 + i, 500 + i, mode=mo, record=True) for i in range(N)] for mo in ('random', 'surprise')}
for mo, v in B.items():
    J = np.array([o['J'] for o in v])
    res[mo] = dict(J=float(J.mean()), se=float(J.std() / np.sqrt(N)), rate_last10k=float(np.mean([o['rew'][-10000:].mean() for o in v])),
                   proposals=float(np.mean([o['proposals'] for o in v])),
                   useful_frac=float(sum(o['useful_props'] for o in v) / sum(o['proposals'] for o in v)),
                   held_frac=float(np.mean([o['held'].mean() for o in v])))
d = np.array([a['J'] - b['J'] for a, b in zip(B['surprise'], B['random'])])
res['diff'] = dict(mean=float(d.mean()), se=float(d.std(ddof=1) / np.sqrt(N)), wins=int((d > 0).sum()))
json.dump(res, open(_OUT, 'w'), indent=1)
print(json.dumps(res, indent=1))
