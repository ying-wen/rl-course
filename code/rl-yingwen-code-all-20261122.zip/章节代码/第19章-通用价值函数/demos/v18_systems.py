#!/usr/bin/env python3
"""Small CPU checks and teaching figures for the v18 systems/continual review.

The GVF example is a fresh tabular calculation on the course's deterministic
A--C route. The seven-step event is extracted from preserved v12 training data;
no old experiment is retrained. Run from any directory using this file's path.
"""
from pathlib import Path
import argparse, csv, hashlib, json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties, fontManager
ROOT=Path(__file__).resolve().parents[1]
for name in ['/System/Library/Fonts/PingFang.ttc','/System/Library/Fonts/STHeiti Medium.ttc']:
    if Path(name).exists():
        fontManager.addfont(name);plt.rcParams['font.family']=FontProperties(fname=name).get_name();break
plt.rcParams.update({'axes.spines.top':False,'axes.spines.right':False,'axes.unicode_minus':False,'font.size':20})
TEAL='#087E8B';RED='#C65335';GOLD='#C4942A';GREY='#61757D'


def run(out):
    out.mkdir(parents=True,exist_ok=True)
    checks=[]
    def check(name,ok,**evidence):
        assert bool(ok),(name,evidence)
        checks.append(dict(name=name,passed=True,**evidence))
    def save(fig,name):
        fig.savefig(out/f'{name}.pdf',bbox_inches='tight')
        fig.savefig(out/f'{name}.png',bbox_inches='tight',dpi=180)
        plt.close(fig)

    # Each outbound segment follows pi_C. The return to A is real motion but
    # is outside this prediction's target behavior and is not used for TD.
    reward=np.array([0.,0.,0.,0.,0.,3.]);truth_T=np.arange(6,0,-1.)
    truth_R=np.array([sum(reward[k:]) for k in range(6)])
    T=np.zeros(7);R=np.zeros(7);rows=[];snap={0:(T.copy(),R.copy())}
    stream=[];position=0
    for trip in range(1,201):
        for s in range(6):
            assert position==s
            position=s+1
            stream.append(dict(t=len(stream),position=s,next_position=position,reward=float(reward[s]),target_policy_sample=1))
            cont=float(s<5);oldT=T[s];oldR=R[s]
            targetT=1+cont*T[s+1];targetR=reward[s]+cont*R[s+1]
            T[s]=oldT+.2*(targetT-oldT);R[s]=oldR+.2*(targetR-oldR)
            rows.append(dict(trip=trip,state=s,reward=reward[s],continuation=cont,old_T=oldT,target_T=targetT,new_T=T[s],old_R=oldR,target_R=targetR,new_R=R[s]))
        if trip in (1,6,30,200):snap[trip]=(T.copy(),R.copy())
        # Execute every return edge; no reset and no target-policy TD update.
        for s in range(6,0,-1):
            assert position==s
            position=s-1
            stream.append(dict(t=len(stream),position=s,next_position=position,reward=float(position==0),target_policy_sample=0))
    check('gvf_time_direct_suffix_return',np.allclose(T[:6],truth_T,atol=1e-7),max_error=float(abs(T[:6]-truth_T).max()))
    check('gvf_reward_direct_suffix_return',np.allclose(R[:6],truth_R,atol=1e-7),max_error=float(abs(R[:6]-truth_R).max()))
    check('first_pass_reward_reaches_only_last_predictor',np.allclose(snap[1][1],[0,0,0,0,0,.6,0]),first_pass=snap[1][1].tolist())
    check('target_stops_at_C_without_environment_terminal',rows[5]['target_T']==1 and rows[5]['target_R']==3 and rows[5]['continuation']==0)
    with (out/'gvf-route-updates.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
    check('full_roundtrip_stream_continuity',len(stream)==2400 and all(a['next_position']==b['position'] for a,b in zip(stream,stream[1:])) and position==0,transitions=len(stream))
    check('return_motion_is_excluded_from_target_updates',sum(x['target_policy_sample'] for x in stream)==len(rows)==1200 and sum(x['reward'] for x in stream)==800)
    with (out/'gvf-roundtrip-transitions.csv').open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=stream[0]);writer.writeheader();writer.writerows(stream)
    labels=['A','a','路口','c1','c2','c3']
    fig,axs=plt.subplots(1,2,figsize=(12,3),layout='constrained')
    for ax,index,truth,title in [(axs[0],0,truth_T,'到 C 的剩余时间'),(axs[1],1,truth_R,'到 C 前的外部奖励')]:
        for n,col in [(1,GREY),(6,GOLD),(30,TEAL)]:ax.plot(range(6),snap[n][index][:6],'-o',ms=5,label=f'{n} 次',c=col)
        ax.plot(range(6),truth,'k--',lw=1,label='真值')
        ax.set(xticks=range(6),xticklabels=labels,title=title,xlabel='预测起点（抵达 C 后停止）',ylim=(-.1,6.4) if index==0 else (-.1,3.4))
        ax.tick_params(labelsize=18);ax.grid(alpha=.18)
        if index==0:ax.legend(fontsize=16,loc='upper right',ncol=2)
    save(fig,'gvf-route-learning')

    raw_path=ROOT/'assets/crl-joint-v12/raw-planning-seed0.npz'
    data=np.load(raw_path);raw=data['transitions'];event=json.loads((ROOT/'assets/crl-joint-v12/one-real-transition.json').read_text())[0]
    end=int(event['t']);start=end-int(event['tau']);segment=raw[start:end]
    check('preserved_event_matches_raw_trajectory',len(segment)==7 and np.isclose(segment[:,6].sum(),event['G']) and segment[-1,7]==1 and segment[:-1,7].sum()==0,start=start,end=end)
    positions=np.r_[segment[0,0],segment[:,4]].astype(int)
    check('real_event_includes_one_no_motion_step',positions.tolist()==[0,0,1,2,4,5,6,7],positions=positions.tolist())
    for name,alpha,target in [('skill',.16,-1),('gvf_reward',.08,3),('gvf_duration',.08,1)]:
        actual=event[name+'_old']+alpha*(target-event[name+'_old'])
        check(name+'_update_from_terminal_target',np.isclose(actual,event[name+'_new']),new=actual)
    delta=event['G']-event['rho_old']*event['tau']+event['Q_next_max']-event['Q_old']
    check('option_delta_and_real_Q_update',np.isclose(delta,event['delta_smdp']) and np.isclose(event['Q_old']+.08*delta,event['Q_after_real_before_normalization']),delta=delta)
    check('completed_model_mean_update',all(np.isclose(event['model_'+q+'_old']+.08*(event[v]-event['model_'+q+'_old']),event['model_'+q]) for q,v in [('R','G'),('T','tau')]))
    fig,axs=plt.subplots(2,1,figsize=(12,3),height_ratios=[1,1.4],layout='constrained')
    ax=axs[0];names={0:'A',1:'a',2:'路口',4:'c1',5:'c2',6:'c3',7:'C'}
    ax.plot(range(8),np.zeros(8),'o',c=TEAL,ms=7)
    for k in range(7):
        ax.annotate('',(k+.91,0),(k+.1,0),arrowprops=dict(arrowstyle='->',color=GREY if k==0 else TEAL))
        ax.text(k+.5,.10,'原地' if k==0 else '东',ha='center',fontsize=18)
    for k,p in enumerate(positions):ax.text(k,-.14,names[p],ha='center',va='top',fontsize=18)
    ax.text(0,.40,'启动去 C',ha='left',c=TEAL,fontsize=18);ax.text(7,.40,'到 C；再次选择目标',ha='right',c=TEAL,fontsize=18)
    ax.set(xlim=(-.4,7.4),ylim=(-.48,.6));ax.axis('off')
    ax=axs[1];x=np.arange(1,8)
    ax.bar(x,segment[:,6],.4,color=GOLD,label='本步外部奖励')
    ax.plot(x,np.cumsum(segment[:,6]),'-o',c=RED,ms=4,label='累计奖励 G')
    ax.plot(x,x,'-o',c=TEAL,ms=4,label='累计原子步 τ')
    ax.set(xticks=x,xticklabels=[str(k) for k in x],ylabel='奖励 / 原子步',xlabel='本次执行的原子步',ylim=(0,8.5))
    ax.legend(loc='upper left',fontsize=16,ncol=3);ax.grid(alpha=.15)
    ax.annotate('本次完成：G=3，τ=7',xy=(7,7),xytext=(4.6,7.8),fontsize=18)
    save(fig,'joint-event-timeline')
    # An undiscounted option model retains the endpoint distribution.
    # Endpoints and durations are correlated; linearity still gives equality.
    joint_p=np.array([.25,.75]);joint_G=np.array([2.,4.]);joint_tau=np.array([1.,3.])
    endpoint_h=np.array([5.,-1.]);rho=.4
    sample_mean=sum(float(p)*(float(g)-rho*float(t)+float(h)) for p,g,t,h in zip(joint_p,joint_G,joint_tau,endpoint_h))
    model_mean=joint_p@joint_G-rho*(joint_p@joint_tau)+joint_p@endpoint_h
    check('random_option_endpoint_expectation',np.isclose(sample_mean,model_mean) and not np.isclose(model_mean,joint_p@joint_G-rho*(joint_p@joint_tau)+endpoint_h[0]),sample_target_mean=float(sample_mean),model_target=float(model_mean))
    # IQL V is an expectile; it is not the value of the extracted policy.
    q=np.array([0.,2.]);tau=.75;v=1.5;prob=np.exp(q)/np.exp(q).sum()
    derivative=.25*v-.75*(2-v)
    check('iql_expectile_vs_extracted_policy_value',abs(derivative)<1e-12 and not np.isclose(prob@q,v),expectile=v,policy=prob.tolist(),policy_value=float(prob@q))
    # Fixed-data, fixed-eta meta derivative of the full two-update sequence.
    def inner(eta):
        a=np.exp(eta);w=0.;H=0.;loss=0.;grad=0.
        for y in [1.,0.,.5]:
            loss+=.5*(w-y)**2;grad+=(w-y)*H
            Hnext=(1-a)*H+a*(y-w);wnext=w+a*(y-w)
            H,w=Hnext,wnext
        return loss,grad
    eta=np.log(.2);eps=1e-6;loss,g=inner(eta);fd=(inner(eta+eps)[0]-inner(eta-eps)[0])/(2*eps)
    check('meta_prediction_error_precedes_current_inner_update',np.isclose(g,fd,atol=1e-9),gradient=g,finite_difference=fd)
    result=dict(scope='Finite tabular prediction and independent arithmetic; preserved training event re-rendered, no large training.',checks=checks,gvf=dict(truth_T=truth_T.tolist(),truth_R=truth_R.tolist(),alpha=.2,outbound_transitions=1200,physical_transitions_including_return=2400),preserved_event=event,input_sha256={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (raw_path,ROOT/'assets/crl-joint-v12/one-real-transition.json')})
    (out/'checks.json').write_text(json.dumps(result,indent=2,ensure_ascii=False))
    print(json.dumps(dict(passed=len(checks),output=str(out)),ensure_ascii=False))

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--out',type=Path,default=ROOT/'assets/v18-systems');args=p.parse_args();run(args.out.resolve())
