# -*- coding: utf-8 -*-
"""Extra numbers: final held questions, proxy 'use' of six fixed questions, surprise strip, paired wins."""
import json, collections, numpy as np, ch19_warehouse_questions as m
from pathlib import Path
_OUT = Path(__file__).resolve().parent.parent / 'assets' / 'ch19-warehouse-questions' / 'ch19_warehouse_extra.json'
_OUT.parent.mkdir(parents=True, exist_ok=True)
N = 30; T = 3000; out = {}
# final held under surprise / random
for mo in ('surprise', 'random'):
    c = collections.Counter(); nu = []
    for i in range(N):
        o = m.run(T, 100 + i, 500 + i, mode=mo)
        fin = [s for s in o['final'] if s]
        nu.append(sum(1 for s in fin if s[0] == 'D' and s[2] != 'TV' and m.answer(s, 0) != m.answer(s, 1)))
        for s in fin:
            if s[0] == 'D' and s[2] != 'TV' and m.answer(s, 0) != m.answer(s, 1): c[str(s)] += 1
    out['final_useful_' + mo] = dict(mean_useful_held=float(np.mean(nu)), common=c.most_common(6))
# proxy use for six fixed questions read together vs one at a time
QS = [('D', 'L', 'B', 2), ('D', 'L', 'W', 2), ('J', 'L', 'B', 1), ('J', 'L', 'D', 1), ('D', 'L', 'TV', 1), ('W', 'L', 'C', 1)]
# instrument: run once per world, then read use from slots by re-running with a patched run that returns slots
import types
def run_use(q_list, i):
    # replicate run() with mode 'none' and capture use via trace of final weights: easiest is monkeypatch Q to keep references
    refs = []
    orig = m.Q
    class Q2(orig):
        __slots__ = ()
        def __init__(self, spec):
            orig.__init__(self, spec); refs.append(self)
    m.Q = Q2
    try:
        o = m.run(T, 100 + i, 500 + i, fixed=q_list)
    finally:
        m.Q = orig
    return [r.use for r in refs], o['J']
alone = {}; together = []
for q in QS:
    alone[str(q)] = float(np.mean([run_use([q], i)[0][0] for i in range(N)]))
tog = np.mean([run_use(QS, i)[0] for i in range(N)], 0)
out['use_alone'] = alone
out['use_together'] = {str(q): float(u) for q, u in zip(QS, tog)}
out['J_together'] = float(np.mean([run_use(QS, i)[1] for i in range(N)]))
# surprise strip, no aux, steps 2000..2023, run 0
o = m.run(T, 100, 500)
out['strip'] = [round(float(x), 2) for x in o['delta'][2000:2024]]
# paired wins b3000
a = [m.run(T, 100 + i, 500 + i, mode='surprise')['J'] for i in range(N)]
b = [m.run(T, 100 + i, 500 + i, mode='random')['J'] for i in range(N)]
out['wins3000'] = int(sum(x > y for x, y in zip(a, b)))
json.dump(out, open(_OUT, 'w'), indent=1, ensure_ascii=False)
print(json.dumps(out, indent=1, ensure_ascii=False))
