"""Intentional TD(0), Sharifnassab et al. (2026), sec. 4, eqs. 6–7.
Compare two linear parameterizations on one terminal transition. The figure
illustrates that single write, not a training run or the full deep optimizer.
Run: python demos/intentional_td_scale.py [--plot]
"""
from fractions import Fraction as F
from pathlib import Path
import sys

def writes(x, nu=F(2, 5)):
    w, target = F(0), F(1)
    delta = target - w * x
    assert x != 0
    step_sizes = (nu, nu / x**2)
    return tuple(x * (w + step * delta * x) - x*w for step in step_sizes)

def main():
    rows = [writes(F(x)) for x in (1,2)]
    assert rows == [(F(2,5), F(2,5)), (F(8,5), F(2,5))]
    print('            fixed step   intentional step')
    for x,row in enumerate(rows,1): print(f'x = {x}         {float(row[0]):.1f}             {float(row[1]):.1f}')
    if '--plot' not in sys.argv: return
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from plot_fonts import chinese_font
    font=chinese_font()
    out=Path(__file__).resolve().parents[1]/'assets/ch07-research'
    out.mkdir(parents=True,exist_ok=True)
    fig,axes=plt.subplots(1,2,figsize=(10,2.35))
    for j,(ax,title) in enumerate(zip(axes,['固定参数步长 α = 0.4','指定预测变化 νδ = 0.4'])):
        ax.set_title(title,fontproperties=font,fontsize=13,color='#20383f')
        ax.axvline(1,color='#53616a',ls=':',lw=1.4)
        ax.text(1.02,1.47,'目标 1',fontproperties=font,fontsize=9,color='#53616a')
        for i,(x,y) in enumerate([(1,1),(2,0)]):
            end=float(rows[i][j])
            color=('#17696e','#a14c24')[i]
            ax.plot([0,end],[y,y],lw=5,solid_capstyle='round',color=color)
            ax.plot([end],[y],'o',ms=8,color=color)
            ax.text(end+.07,y,f'{end:g}',fontsize=12,va='center',color=color)
        ax.set_xlim(-.04,1.87);ax.set_ylim(-.5,1.74)
        ax.set_xticks([0,.4,1,1.6]);ax.set_yticks([1,0],['x = 1','x = 2']);ax.tick_params(length=0,labelsize=10)
        for edge in ['top','right','left']:ax.spines[edge].set_visible(False)
        ax.set_xlabel('更新后的预测',fontproperties=font,fontsize=10)
        ax.spines['bottom'].set_color('#b2bdbd')
    fig.subplots_adjust(left=.065,right=.99,top=.8,bottom=.26,wspace=.27)
    for ext in ['pdf','svg']:fig.savefig(out/('intentional-scale.'+ext),bbox_inches='tight')
    plt.close(fig)

if __name__=='__main__': main()
