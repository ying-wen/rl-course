"""Redraw the frozen-table forward/backward TD-error weight matrix.

Run from rl-course: python demos/course21_trace_matrix.py
Requires numpy and matplotlib; no learner, environment, or training is run.
The four-transition trajectory and frozen values match course15_traces.py.
Exact Fraction arithmetic computes every displayed weight and TD error.
"""
from fractions import Fraction
from pathlib import Path
import json

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

from plot_fonts import use_course_fonts, CJK_FAMILY, no_leading_zero

OUT = Path(__file__).resolve().parents[1] / 'assets/course21-traces'
INK, MUTED, LIGHT = '#182e38', '#61757d', '#f3f5f5'


def compute():
    gamma, lam = Fraction(9, 10), Fraction(4, 5)
    states = ('S7', 'S4', 'S4', 'S4', 'G')
    rewards = (0, 0, 0, 1)
    frozen = {'S7': Fraction(2, 5), 'S4': Fraction(1, 2), 'G': Fraction(0)}
    errors = [Fraction(r) + gamma * frozen[states[t + 1]] - frozen[states[t]]
              for t, r in enumerate(rewards)]
    weights = [[(gamma * lam) ** (t - k) if t >= k else Fraction(0)
                for t in range(4)] for k in range(4)]
    row_errors = [sum(weights[k][t] * errors[t] for t in range(4))
                  for k in range(4)]
    assert errors == [Fraction(1, 20), Fraction(-1, 20),
                      Fraction(-1, 20), Fraction(1, 2)]
    assert row_errors == [Fraction(10919, 62500), Fraction(433, 2500),
                          Fraction(31, 100), Fraction(1, 2)]
    return states, errors, weights, row_errors


def weight_label(value):
    if value == 1:
        return '1'
    return f'{float(value):.4f}'.rstrip('0').rstrip('.').lstrip('0')


def main():
    states, errors, weights, row_errors = compute()
    OUT.mkdir(parents=True, exist_ok=True)
    # 11-21 r1121-112610: course fonts (Latin Modern Sans + FandolHei) and
    # Chinese axis labels drawn in the figure, so the slide needs no white
    # boxes pasted over English labels. Shown about 4.9 cm high on the slide.
    use_course_fonts()
    plt.rcParams.update({'font.size': 18,
                         'text.color': INK, 'axes.labelcolor': INK,
                         'xtick.color': INK, 'ytick.color': INK})
    fig, ax = plt.subplots(figsize=(5.4, 4.6))
    data = np.asarray([[float(x) for x in row] for row in weights])
    mask = np.tril(np.ones((4, 4), dtype=bool), -1)
    cmap = plt.get_cmap('YlGnBu').copy()
    cmap.set_bad(LIGHT)
    ax.imshow(np.ma.array(data, mask=mask), cmap=cmap, vmin=0, vmax=1,
              interpolation='nearest', aspect='equal')
    for k in range(4):
        for t in range(k, 4):
            ax.text(t, k, weight_label(weights[k][t]), ha='center', va='center',
                    color='white' if data[k, t] >= .7 else INK, fontsize=20)
    ax.set_xticks(range(4))
    ax.set_xticklabels([rf'$\delta_{t}$' + '\n' + '$=' + no_leading_zero(float(error)) + '$'
                        for t, error in enumerate(errors)], fontsize=18,
                       linespacing=1.3)
    ax.set_yticks(range(4))
    ax.set_yticklabels([rf'$k={k}:\ S_{{{states[k][1:]}}}$' for k in range(4)],
                       fontsize=18)
    ax.tick_params(axis='both', which='both', length=0, pad=10)
    ax.set_xlabel('后来的误差 $t$', fontsize=18, labelpad=8,
                  fontfamily=CJK_FAMILY)
    ax.set_ylabel('较早的访问 $k$', fontsize=18, labelpad=8,
                  fontfamily=CJK_FAMILY)
    ax.set_xticks(np.arange(-.5, 4, 1), minor=True)
    ax.set_yticks(np.arange(-.5, 4, 1), minor=True)
    ax.grid(which='minor', color='white', linewidth=1.2)
    for spine in ax.spines.values():
        spine.set_color(MUTED)
        spine.set_linewidth(.7)
    for ext in ('pdf', 'png'):
        fig.savefig(OUT / f'credit-matrix.{ext}', bbox_inches='tight',
                    facecolor='white', dpi=200)
    plt.close(fig)
    record = {'scope': 'Exact frozen-table calculation, not online learning or training.',
              'gamma': .9, 'lambda': .8, 'states': states,
              'frozen_values': {'S7': .4, 'S4': .5, 'G': 0},
              'td_errors': [float(x) for x in errors],
              'weights': [[float(x) for x in row] for row in weights],
              'row_lambda_return_errors': [float(x) for x in row_errors],
              'rounding': 'Cell labels use up to four decimal places; calculation retains exact Fractions.',
              'source': 'Sutton & Barto Chapter 12; same four-step task as course15_traces.py.'}
    (OUT / 'credit-matrix.json').write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps({'td_errors': record['td_errors'],
                      'row_lambda_return_errors': record['row_lambda_return_errors']}))


if __name__ == '__main__':
    main()
