"""Editable diagrams for n-step returns and eligibility traces.

Run from rl-course: python demos/course21_trace_visuals.py
The diagrams use the same four observed transitions as course15_traces.py.
These are exact algorithm executions, not new training experiments.
The n-step/mixture diagrams adapt the organization of Sutton & Barto
Figures 7.1 and 12.1; all task values are computed here.
"""
from pathlib import Path
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Circle, Rectangle, FancyArrowPatch
from course15_traces import (accumulating, frozen_forward, frozen_backward,
                             FIXED_STATES, FIXED_REWARDS, FEATURES)

OUT = Path(__file__).resolve().parents[1] / 'assets/course21-traces'
INK, TEAL, GOLD, RED, MUTED = '#182e38', '#087e8b', '#c4942a', '#c65335', '#61757d'
plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 14,
                     'text.color': INK, 'pdf.fonttype': 42})


def save(fig, name):
    fig.savefig(OUT / f'{name}.pdf', bbox_inches='tight', facecolor='white')
    fig.savefig(OUT / f'{name}.png', bbox_inches='tight', facecolor='white', dpi=180)
    plt.close(fig)


def arrow(ax, a, b, color=TEAL, lw=2, **kw):
    ax.add_patch(FancyArrowPatch(a, b, arrowstyle='-|>', mutation_scale=14,
                                color=color, lw=lw, **kw))


def node(ax, x, y, label, terminal=False, color=TEAL):
    shape = (Rectangle((x-.14, y-.14), .28, .28, fc='#e6f3f2', ec=color, lw=2)
             if terminal else Circle((x, y), .14, fc='white', ec=color, lw=2))
    ax.add_patch(shape)
    ax.text(x, y, label, ha='center', va='center', fontsize=11)


def return_trees(targets, weights=None):
    fig, ax = plt.subplots(figsize=(13.4, 4.1))
    ax.set(xlim=(-.55, 12.45), ylim=(-.65, 3.6)); ax.axis('off')
    labels = ['$S_7$', '$S_4$', '$S_4$', '$S_4$', '$G$']
    for col, n in enumerate(range(1, 5)):
        x = col*3.5
        heading = f'{n}-step TD' if n < 4 else 'Monte Carlo'
        ax.text(x, 3.35, heading, ha='center', fontsize=16, weight='bold')
        for t in range(n+1):
            y = 2.85 - .55*t
            node(ax, x, y, labels[t], terminal=(t==4), color=GOLD if t==n and n<4 else TEAL)
            if t < n:
                arrow(ax, (x, y-.15), (x, y-.4), lw=1.8)
                ax.text(x+.28, y-.275, f'$R_{t+1}={int(FIXED_REWARDS[t])}$',
                        ha='left', va='center', fontsize=12, color=RED if t==3 else MUTED)
        y = 2.85 - .55*n
        if n < 4:
            ax.text(x+.34, y, '$V=.5$', color=GOLD, fontsize=13, va='center')
        else:
            ax.text(x+.34, y, '$V=0$', color=MUTED, fontsize=13, va='center')
        ax.text(x, -.08, f'$G_0^{{({n})}}={targets[n-1]:.4g}$',
                ha='center', fontsize=16, color=INK)
        if weights is not None:
            ax.text(x, -.5, rf'$\times\ {weights[n-1]:.3g}$', color=RED,
                    ha='center', fontsize=17, weight='bold')
    return fig


def trace_snapshots(records):
    fig, ax = plt.subplots(figsize=(13, 3.6))
    ax.set(xlim=(-1.15, 11.15), ylim=(-.6, 3.0)); ax.axis('off')
    for t, row in enumerate(records):
        x = 3*t
        state = '$S_7$' if t == 0 else '$S_4$'
        ax.text(x, 2.7, f'$t={t}$', ha='center', fontsize=16)
        node(ax, x, 2.2, state)
        if t < 3:
            arrow(ax, (x+.25, 2.2), (x+2.7, 2.2), lw=1.6)
            ax.text(x+1.5, 2.42, '$R=0$', ha='center', fontsize=12, color=MUTED)
        ax.add_patch(Rectangle((x-.92, -.4), 1.84, 2.05, ec='#d8e3e4', fc='#f7faf9', lw=1))
        for k, key, color in [(0, 'z_S7', TEAL), (1, 'z_S4', GOLD)]:
            y = 1.15 - 1.1*k; value = row[key]
            radius = .3*np.sqrt(value) if value > 0 else 0
            ax.add_patch(Circle((x, y), radius, fc=color, alpha=.22, ec=color, lw=1.5))
            ax.text(x, y, f'{value:.4g}', ha='center', va='center', fontsize=14, weight='bold')
    ax.text(-1.05, 1.15, '$z(S_7)$', ha='right', va='center', fontsize=15, color=TEAL)
    ax.text(-1.05, .05, '$z(S_4)$', ha='right', va='center', fontsize=15, color=GOLD)
    save(fig, 'trace-snapshots')


def reward_maps(td0, tdl):
    fig, axes = plt.subplots(1, 3, figsize=(11.8, 4.1))
    panels = [('Before terminal reward', np.zeros(2)), ('TD(0)', td0),
              (r'$TD(\lambda),\ \lambda=.8$', tdl)]
    for ax, (title, vals) in zip(axes, panels):
        ax.set(xlim=(-.3, 2.2), ylim=(-.15, 3.4), aspect='equal'); ax.axis('off')
        for y, name, v in [(0, '$S_7$', vals[0]), (1, '$S_4$', vals[1]), (2, '$G$', None)]:
            fc = '#e6f3f2' if v is None else plt.cm.YlGnBu(v/.55)
            ax.add_patch(Rectangle((0, y), 1.65, .95, ec='white', fc=fc, lw=2))
            ax.text(.15, y+.72, name, fontsize=14, color='white' if v is not None and v>.3 else INK)
            if v is not None:
                ax.text(.85, y+.37, f'{v:.4f}', ha='center', fontsize=18,
                        weight='bold', color='white' if v>.3 else INK)
        arrow(ax, (1.82, .45), (1.82, 1.35), lw=1.5)
        arrow(ax, (1.82, 1.55), (1.82, 2.5), color=RED, lw=1.5)
        ax.text(.85, 2.36, '$R_4=1$', ha='center', color=RED, fontsize=16)
        ax.set_title(title, fontsize=15, pad=5)
    save(fig, 'terminal-value-maps')


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    gamma, lam, alpha = .9, .8, .2
    values = np.array([.4, .5]); states = FIXED_STATES; rewards = FIXED_REWARDS
    targets = np.array([sum(gamma**j*rewards[j] for j in range(n))
                        + (gamma**n*values[states[n]] if n < len(rewards) else 0)
                        for n in range(1, len(rewards)+1)])
    weights = np.array([1-lam, (1-lam)*lam, (1-lam)*lam**2, lam**3])
    mix = weights @ targets
    np.testing.assert_allclose(targets, [.45, .405, .3645, .729])
    np.testing.assert_allclose(weights.sum(), 1)
    np.testing.assert_allclose(mix, .574704)
    forward, returns = frozen_forward(states, rewards, values, alpha, gamma, lam)
    backward = frozen_backward(states, rewards, values, alpha, gamma, lam)
    np.testing.assert_allclose(forward, backward, atol=2e-14)
    np.testing.assert_allclose(returns[0], mix)
    save(return_trees(targets), 'nstep-trees')
    save(return_trees(targets, weights), 'lambda-trees')
    zero, records = accumulating(FEATURES[states], rewards, [0, 0], alpha, gamma, lam)
    one, _ = accumulating(FEATURES[states], rewards, [0, 0], alpha, gamma, 0.)
    np.testing.assert_allclose(zero[-1], [.0746496, .44768], atol=2e-14)
    np.testing.assert_allclose(one[-1], [0., .2], atol=2e-14)
    trace_snapshots(records); reward_maps(one[-1], zero[-1])
    result = {'nstep_returns': targets.tolist(), 'lambda_weights': weights.tolist(),
              'lambda_return': mix, 'frozen_forward_equals_backward': True,
              'terminal_td0_values': one[-1].tolist(), 'terminal_tdl_values': zero[-1].tolist(),
              'trace_snapshots': records,
              'sources': ['Sutton & Barto, Figures 7.1, 12.1, 12.4 and 12.5',
                          'course15_traces.py: same task, transitions and update functions'],
              'scope': 'Exact four-transition execution; no stochastic training or performance comparison.'}
    (OUT/'calculations.json').write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps({k:result[k] for k in ['nstep_returns','lambda_return','terminal_td0_values','terminal_tdl_values']}))


if __name__ == '__main__':
    main()
