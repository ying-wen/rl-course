"""Chapter 7, slide course15-trace-nstep-learning: two figures in the slide fonts.

11-21 审阅站请求 r1121-112610：原页左图裁自 learning-n.pdf（DejaVu、英文轴名加白块），
右图是 Sutton 与 Barto 图 7.2 的位图。本脚本只写两个新文件，不覆盖其他章节的图：
  assets/course15-traces/learning-n-cn.pdf   泥地，alpha=.05，n=1,4,16 的学习曲线
  assets/course15-traces/random-walk-nstep-cn.pdf   19 状态随机游走，前 10 回合平均 RMSE 对 alpha
左图读 course15_traces.py 已写出的 training-values.csv（64 个种子、200 回合、零初值）。
右图按 Sutton 与 Barto 图 7.2 的设定重算：19 个非终止状态，左端 -1、右端 +1，gamma=1，
零初值，每组 (n, alpha) 100 次运行、每次 10 回合，误差为 19 个状态的均方根误差，
对 10 回合与 100 次运行取平均。

Run: python demos/ch07_nstep_learning_cn.py
"""
from __future__ import annotations
import csv
import json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent))
from plot_fonts import use_course_fonts, CJK_FAMILY, no_leading_zero

TEAL, RED, GOLD, INK, MUTED = '#087e8b', '#c65335', '#c4942a', '#182e38', '#61757d'
ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'assets/course15-traces'
TRUTH = np.array([9 / 19, 10 / 19])


def mud_curves():
    rows = {}
    with (OUT / 'training-values.csv').open() as f:
        for r in csv.DictReader(f):
            if r['kind'] != 'n' or float(r['alpha']) != .05:
                continue
            n = int(float(r['parameter']))
            rows.setdefault(n, {}).setdefault(int(r['seed']), {})[int(r['episode'])] = (float(r['S7']), float(r['S4']))
    curves = {}
    for n, by_seed in rows.items():
        seeds = sorted(by_seed)
        eps = sorted(by_seed[seeds[0]])
        arr = np.array([[by_seed[s][e] for e in eps] for s in seeds])  # seeds x episodes x 2
        err = np.sqrt(np.mean((arr - TRUTH) ** 2, axis=2))
        m = err.mean(axis=0)
        se = err.std(axis=0, ddof=1) / np.sqrt(len(seeds))
        curves[n] = (np.array(eps), m, se, len(seeds))
    return curves


def random_walk(n_states=19, runs=100, episodes=10, seed=0):
    ns = [1, 2, 4, 8, 16, 32, 64, 128, 256, 512]
    alphas = np.round(np.arange(0, 1.0001, .1), 2)
    truth = np.arange(-(n_states - 1), n_states, 2) / (n_states + 1)
    rng = np.random.default_rng(seed)
    start = n_states // 2
    # Pre-sample episodes so every (n, alpha) sees the same data in a run.
    data = []
    for _ in range(runs):
        run = []
        for _ in range(episodes):
            s = start; states = [s]
            while 0 <= s < n_states:
                s += 1 if rng.random() < .5 else -1
                states.append(s)
            run.append(states)
        data.append(run)
    err = np.zeros((len(ns), len(alphas)))
    # Online n-step TD (Algorithm 7.1): update tau=t-n+1 after each transition.
    for i, n in enumerate(ns):
        for j, a in enumerate(alphas):
            tot = 0.
            for run in data:
                V = np.zeros(n_states)
                for states in run:
                    T = len(states) - 1
                    rew = [0.] * (T + 1)
                    rew[T] = 1. if states[T] == n_states else -1.
                    t = 0
                    while True:
                        tau = t - n + 1
                        if tau >= 0:
                            h = min(tau + n, T)
                            G = sum(rew[k] for k in range(tau + 1, h + 1))
                            if h < T:
                                G += V[states[h]]
                            V[states[tau]] += a * (G - V[states[tau]])
                        if tau == T - 1:
                            break
                        t += 1
                    tot += np.sqrt(np.mean((V - truth) ** 2))
            err[i, j] = tot / (runs * episodes)
    return ns, alphas, err


def main():
    ok = use_course_fonts()
    fmt = FuncFormatter(no_leading_zero)
    curves = mud_curves()
    fig, ax = plt.subplots(figsize=(4.2, 2.6))
    for c, n in zip((TEAL, RED, GOLD), (1, 4, 16)):
        ep, m, se, k = curves[n]
        ax.plot(ep, m, color=c, lw=1.8, label=f'$n={n}$')
        ax.fill_between(ep, m - se, m + se, color=c, alpha=.15, lw=0)
    ax.set_xlim(1, 200); ax.set_ylim(0, .53)
    ax.set_xlabel('已完成回合数', fontfamily=CJK_FAMILY, fontsize=9)
    ax.set_ylabel('S7、S4 的均方根误差', fontfamily=CJK_FAMILY, fontsize=9)
    ax.yaxis.set_major_formatter(fmt); ax.tick_params(labelsize=8)
    ax.legend(fontsize=8, frameon=False)
    for s in ('top', 'right'):
        ax.spines[s].set_visible(False)
    fig.tight_layout(); fig.savefig(OUT / 'learning-n-cn.pdf', bbox_inches='tight', facecolor='white'); plt.close(fig)
    summary = {f'n={n}': {f'ep{e}': round(float(curves[n][1][e - 1]), 4) for e in (1, 10, 50, 200)} for n in (1, 4, 16)}

    ns, alphas, err = random_walk()
    fig, ax = plt.subplots(figsize=(4.2, 2.6))
    cmap = plt.get_cmap('viridis')
    for i, n in enumerate(ns):
        keep = err[i] < .55
        ax.plot(alphas[keep], err[i][keep], color=cmap(i / (len(ns) - 1)), lw=1.4)
        last = np.where(keep)[0][-1]
        if n == 512:
            continue  # 256 与 512 的点几乎重合，合用一个标签
        lab = '256, 512' if n == 256 else f'{n}'
        ax.text(alphas[last] + .015, err[i][last], lab, fontsize=7, color=cmap(i / (len(ns) - 1)), va='center')
    ax.set_xlim(0, 1.08); ax.set_ylim(.25, .55)
    ax.set_xlabel('步长 $\\alpha$', fontfamily=CJK_FAMILY, fontsize=9)
    ax.set_ylabel('前 10 回合的均方根误差', fontfamily=CJK_FAMILY, fontsize=9)
    ax.xaxis.set_major_formatter(fmt); ax.yaxis.set_major_formatter(fmt); ax.tick_params(labelsize=8)
    ax.text(.98, .03, '曲线旁的数是 $n$', transform=ax.transAxes, ha='right', va='bottom', fontsize=8, fontfamily=CJK_FAMILY, color=MUTED)
    for s in ('top', 'right'):
        ax.spines[s].set_visible(False)
    fig.tight_layout(); fig.savefig(OUT / 'random-walk-nstep-cn.pdf', bbox_inches='tight', facecolor='white'); plt.close(fig)
    best = {int(n): [float(alphas[int(np.argmin(err[i]))]), round(float(err[i].min()), 4)] for i, n in enumerate(ns)}
    print(json.dumps({'fonts_ok': ok, 'mud_alpha_.05': summary, 'random_walk_best_alpha_and_rmse': best}, indent=1))


if __name__ == '__main__':
    main()
