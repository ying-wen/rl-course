"""Reproduce the chapter 7 diagrams on one trajectory with exact rational arithmetic.

Run without arguments for the numerical comparison. Add --figures to regenerate
the three PDF figures. The frozen-table calculations isolate one update at a
time; the online run reads its updated table before each new transition.
"""
from argparse import ArgumentParser
from fractions import Fraction as F
from pathlib import Path

STATES = ("S7", "S4", "S4", "S4", "G")
REWARDS = (0, 0, 0, 1)
INITIAL = {"S7": F(2, 5), "S4": F(1, 2), "G": F(0)}
GAMMA, LAMBDA, ALPHA = F(9, 10), F(4, 5), F(1, 5)
OUT = Path(__file__).resolve().parents[1] / "assets" / "trace-credit-lens"


def nstep(k, n):
    stop = k + n
    observed = sum(GAMMA**i * REWARDS[k + i] for i in range(n))
    return observed + GAMMA**n * INITIAL[STATES[stop]]


def horizons(k):
    length = len(REWARDS) - k
    for n in range(1, length + 1):
        remaining = LAMBDA ** (n - 1)
        weight = remaining if n == length else remaining * (1 - LAMBDA)
        yield n, weight, nstep(k, n)


def run(decay=LAMBDA, online=False):
    """Generate the departure-state trace before writing this transition's error."""
    values = INITIAL.copy()
    trace = {s: F(0) for s in INITIAL if s != "G"}
    rows = []
    for t, reward in enumerate(REWARDS):
        state, successor = STATES[t:t + 2]
        delta = reward + GAMMA * values[successor] - values[state]
        for s in trace:
            trace[s] = GAMMA * decay * trace[s] + int(s == state)
        changes = {s: ALPHA * delta * z for s, z in trace.items()}
        rows.append((delta, trace.copy(), changes))
        if online:
            for s, change in changes.items():
                values[s] += change
    return rows, values


def verify():
    rows, _ = run()
    one_step, _ = run(decay=0)
    forward = {"S7": F(0), "S4": F(0)}
    for k, state in enumerate(STATES[:-1]):
        terms = list(horizons(k))
        assert sum(w for _, w, _ in terms) == 1
        target = sum(w * ret for _, w, ret in terms)
        residual = sum((GAMMA * LAMBDA)**(t - k) * rows[t][0]
                       for t in range(k, len(REWARDS)))
        assert target - INITIAL[state] == residual
        forward[state] += ALPHA * residual
    for s in forward:
        assert sum(dv[s] for _, _, dv in rows) == forward[s]
    assert rows[1][0] == F("-.05") and rows[3][0] == F(".5")
    assert rows[-1][1] == {"S7": F(".373248"), "S4": F("2.2384")}
    assert rows[1][2] == {"S7": F("-.0072"), "S4": F("-.01")}
    assert rows[3][2] == {"S7": F(".0373248"), "S4": F(".22384")}
    assert one_step[3][2] == {"S7": 0, "S4": F(".1")}
    return rows


def figures(rows):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.patches import Rectangle
    from matplotlib.font_manager import FontProperties
    from plot_fonts import use_course_fonts, CJK_FAMILY

    # 11-21: slide fonts (Latin Modern Sans + FandolHei) instead of STHeiti.
    OUT.mkdir(exist_ok=True, parents=True)
    use_course_fonts()
    cn = FontProperties(family=['Latin Modern Sans', CJK_FAMILY])
    nz = lambda txt: txt[1:] if txt.startswith("0.") else txt   # course rule: .72, not 0.72
    ink, muted, teal, gold, pink = "#163338", "#597276", "#087c80", "#a75b20", "#aa4b49"
    highlight = ["#24797b", "#479799", "#8bbdbc", "#b0692e"]

    def label(ax, x, y, txt, size=13, color=ink, **more):
        ax.text(x, y, txt, fontsize=size, fontproperties=cn, color=color,
                ha=more.pop("ha", "center"), va="center", **more)

    def canvas(width, height, xmax, ymax):
        fig, ax = plt.subplots(figsize=(width, height))
        fig.subplots_adjust(left=.008, right=.993, bottom=.04, top=.975)
        ax.set(xlim=(0, xmax), ylim=(0, ymax))
        ax.axis("off")
        return fig, ax

    def save(fig, name):
        fig.savefig(OUT / (name + ".pdf"), metadata={"CreationDate": None, "ModDate": None})
        plt.close(fig)

    # Width of each interval encodes how much of the mixture stops at this horizon.
    fig, ax = canvas(11.5, 2.35, 100, 22)
    start, width = 4., 92.
    label(ax, start, 19.8, "同一次 S7 访问", 14, ha="left")
    label(ax, start + width, 19.8, "权重总和 = 1", 13, ha="right", color=muted)
    for (n, weight, ret), color in zip(horizons(0), highlight):
        span = width * float(weight)
        ax.add_patch(Rectangle((start, 12.3), span-.2, 4.0, color=color, ec="none"))
        label(ax, start+span/2, 14.3, f"{float(weight)*100:g}%", color=ink if n==3 else "white")
        label(ax, start+span/2, 8.2, ("一步" , "两步", "三步", "到终点")[n-1])
        label(ax, start+span/2, 3.6, nz(f"{float(ret):.4f}".rstrip("0")), color=color, size=14)
        start += span
    save(fig, "horizon-mixture")

    # Each colored segment is the surviving eligibility of a particular visit.
    fig, ax = canvas(11.5, 3.0, 100, 27)
    xs = [20., 41., 62., 83.]
    visit_colors = ["#52738d", "#087d7d", "#a96a2e", "#4a6e50"]
    for t, x in enumerate(xs):
        label(ax,x,25,f"t = {t}    {STATES[t]}",15,color=visit_colors[t])
        if t < 3:
            ax.annotate("",(x+15.4,25),(x+6.6,25),
                        arrowprops={"arrowstyle":"->","color":muted,"lw":1.3})
    for s, y in [("S7",15.),("S4",6.7)]:
        label(ax, 1.4,y+1.5,"迹 "+s,14,ha="left")
        for t, x in enumerate(xs):
            left = x-7.4
            ax.plot([left,left+15],[y,y],color="#c9d8d6",lw=.7)
            for k in range(t+1):
                if STATES[k]!=s: continue
                share=float((GAMMA*LAMBDA)**(t-k))*6.6
                color=visit_colors[k]
                ax.add_patch(Rectangle((left,y+.18),share,2,facecolor=color,edgecolor="w",lw=.65))
                left+=share
            label(ax,x,y-2.55,nz(f"{float(rows[t][1][s]):.3f}".rstrip("0").rstrip(".")),12,color=muted)
    save(fig,"visit-strips")

    # Compare writes with a common pre-update value table, including its sign.
    fig, axs = plt.subplots(1, 2, figsize=(11.6,2.95))
    fig.subplots_adjust(left=.13,right=.976,top=.76,bottom=.22,wspace=.69)
    zeros,_=run(decay=0)
    for ax,t,goal in zip(axs,(1,3),(False,True)):
        states = ["S7","S4"]
        offsets=(-.18,.18)
        for j,s in enumerate(states):
            for off,row,color in zip(offsets,(zeros[t],rows[t]),("#9caeae",teal)):
                val=float(row[2][s]);y=1-j+off
                ax.barh(y,val,height=.29,color=color)
                if val==0:ax.plot(0,y,"o",color=color,markersize=3,clip_on=False)
                sign="+" if val>0 else "−" if val<0 else ""
                fmt=nz(f"{abs(val):.3g}")
                ax.annotate(sign+fmt,(val,y),xytext=((4 if val>=0 else -4),0),
                            textcoords="offset points",ha="left" if val>=0 else "right",
                            va="center",size=10.5,color=ink)
        ax.axvline(0,color=muted,lw=.9)
        ax.set(ylim=(-.53,1.53),xlim=(-.016,.0035) if not goal else (-.02,.30),yticks=(0,1))
        ax.set_yticklabels(("S4","S7"),color=ink,fontsize=13)
        ax.set_xticks([])
        ax.tick_params(length=0)
        for spine in ax.spines.values(): spine.set_visible(False)
        ax.set_title(("打滑回到 S4     δ = −.05","从 S4 到达终点     δ = +.5")[goal],
                     fontproperties=cn,fontsize=14,color=(pink if not goal else gold),pad=8)
    for x,col,txt in [(.35,"#9caeae","TD(0)"),(.53,teal,"TD(.8)")]:
        fig.add_artist(Rectangle((x,.057),.027,.038,transform=fig.transFigure,fc=col,ec="none"))
        fig.text(x+.037,.076,txt,va="center",fontsize=12,color=ink)
    save(fig,"signed-writes")


if __name__ == "__main__":
    parser=ArgumentParser(description=__doc__)
    parser.add_argument("--figures", action="store_true")
    args=parser.parse_args()
    records=verify()
    for t,(delta,z,change) in enumerate(records):
        print(f"t={t}  delta={float(delta):+.3f}  z={[float(v) for v in z.values()]}"
              f"  changes={[float(v) for v in change.values()]}")
    if args.figures:
        figures(records)
