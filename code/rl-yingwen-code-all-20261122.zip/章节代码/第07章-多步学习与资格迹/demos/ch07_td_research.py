"""Two local calculations for the chapter on eligibility traces.

QRC: RLJ 2025, equation (26), first transition after trace reset.
CET: ICLR 2026, section 3, unit-area continuous-time impulse responses.
Usage: python3 demos/ch07_td_research.py [--output DIRECTORY]
"""
from argparse import ArgumentParser
from math import factorial
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from plot_fonts import use_course_fonts, CJK_FAMILY, no_leading_zero

TEAL = "#136e70"
OCHRE = "#ac6521"
INK = "#1c333b"
GRID = "#d4e0de"
# 11-21 r1121-112610：图内字体改为课程字体（LM Sans + FandolHei）；图幅缩小，使投影后刻度不小于 7pt。


def qrc_directions():
    gamma = 0.9
    current_grad = np.array([1., 0.])
    next_grad = np.array([2., 1.])
    # One available action at the successor makes the greedy continuation unique.
    def td_error(w):
        return 1. + gamma * (next_grad @ w) - current_grad @ w

    w = np.zeros(2)
    delta = td_error(w)
    residual_grad = gamma * next_grad - current_grad
    h = 1.0
    # At the first step z_q = grad q and z_h = h. These are Eq. (26)'s
    # terms as evaluated by the author's qrc.py, before the step size.
    plain = delta * current_grad
    corrected = plain - h * current_grad - h * residual_grad
    np.testing.assert_allclose(corrected, plain - gamma * h * next_grad)
    for direction in (plain, corrected):
        eta = 1e-5
        derivative = (td_error(w + eta * direction) - td_error(w - eta * direction)) / (2 * eta)
        np.testing.assert_allclose(derivative, residual_grad @ direction)
    return plain, corrected, residual_grad


def delay_kernels(lag):
    # Both kernels have unit integral and mean age 5. The 5-stage cascade peaks at T = 4.
    stages, target_delay = 5, 4.0
    rate = (stages - 1) / target_delay
    mean = stages / rate
    single = np.exp(-lag / mean) / mean
    cascade = (rate ** stages / factorial(stages-1)) * lag ** (stages-1) * np.exp(-rate*lag)
    return single, cascade


def text(ax, x, y, words, size=10, color=INK, cjk=True, **kw):
    if cjk:
        kw["fontfamily"] = CJK_FAMILY
    ax.text(x, y, words, fontsize=size, color=color, **kw)


def save(fig, output, name):
    for fmt in ("svg", "pdf"):
        fig.savefig(output / (name + "." + fmt), bbox_inches="tight", pad_inches=.06)
    plt.close(fig)


def plot_gradient(output):
    plain, corrected, _ = qrc_directions()
    fig, ax = plt.subplots(figsize=(2.63, 1.5))
    ax.set_aspect("equal")
    ax.set_xlim(-1.15, 1.32)
    ax.set_ylim(-1.22, .45)
    ax.axhline(0, lw=.9, color=GRID)
    ax.axvline(0, lw=.9, color=GRID)
    for vector, color in [(plain, OCHRE), (corrected, TEAL)]:
        ax.annotate("", xy=vector, xytext=(0, 0),
                    arrowprops=dict(arrowstyle="-|>", color=color, lw=2.0, mutation_scale=11))
    ax.plot([plain[0],corrected[0]], [plain[1], corrected[1]], ls="--", lw=1, color="#91a5a4")
    ax.plot(0,0,marker="o",ms=3.5,color=INK)
    text(ax, .45, .135, r"Q($\lambda$)", color=OCHRE, cjk=False)
    text(ax, -1.12, -1.12, r"QRC($\lambda$)", color=TEAL, cjk=False)
    text(ax, .22, -.58, "目标项的校正", size=9.5, color="#516a6a")
    ax.text(1.16,.06,r"$w_1$",fontsize=10,color=INK)
    ax.text(.05,.29,r"$w_2$",fontsize=10,color=INK)
    text(ax,-.1,.12,"0",size=9,cjk=False)
    ax.axis("off")
    save(fig, output, "qrc-directions")


def plot_delay(output):
    lag = np.linspace(0, 13, 1301)
    single, cascade = delay_kernels(lag)
    fig, ax = plt.subplots(figsize=(2.9, 1.5))
    ax.plot(lag,single,color=OCHRE,lw=1.8)
    ax.plot(lag,cascade,color=TEAL,lw=2.0)
    chosen = 400
    ax.vlines(4,0,cascade[chosen],colors=TEAL,lw=.9,linestyles=":")
    ax.plot(4,cascade[chosen],"o",color=TEAL,ms=3.5)
    ax.set_xlim(-.1,12.3); ax.set_ylim(0,.238)
    ax.spines[["top","right"]].set_visible(False)
    ax.spines[["bottom","left"]].set_color(GRID)
    ax.set_xticks([0,1,4,8,12]); ax.set_yticks([0,.1,.2])
    ax.tick_params(axis="both",labelsize=8.5,color=GRID)
    ax.yaxis.set_major_formatter(plt.FuncFormatter(no_leading_zero))
    ax.set_xlabel("距当前误差信号的时间",fontfamily=CJK_FAMILY,color=INK,fontsize=9.5)
    ax.set_ylabel("相对权重",fontfamily=CJK_FAMILY,color=INK,fontsize=9.5)
    text(ax,.3,.205,"单指数",color=OCHRE,size=9.5)
    text(ax,4.6,.20,"五级串联",color=TEAL,size=9.5)
    save(fig,output,"delay-kernels")


def main():
    parser=ArgumentParser()
    parser.add_argument("--output",type=Path,default=Path(__file__).resolve().parents[1]/"assets/ch07-research")
    output=parser.parse_args().output
    output.mkdir(parents=True,exist_ok=True)
    directions= qrc_directions()
    derivative=np.array([directions[2] @ v for v in directions[:2]])
    np.testing.assert_allclose(derivative,[.8,-1.45])
    t=np.linspace(0,160,160001)
    a,b=delay_kernels(t)
    for h in (a,b):
        np.testing.assert_allclose(np.sum((h[1:] + h[:-1]) * np.diff(t) / 2),1.,atol=1e-7)
        np.testing.assert_allclose(np.sum((h[1:]*t[1:] + h[:-1]*t[:-1]) * np.diff(t) / 2),5.,atol=1e-6)
    np.testing.assert_allclose(t[np.argmax(b)],4.)
    print("Q / QRC directions:", directions[:2], "change in sample TD error per unit step:",derivative)
    print("CET peak age:", t[np.argmax(b)], "single vs cascade weights at ages 1 and 4:",delay_kernels(np.array([1.,4.])))
    use_course_fonts()
    plot_gradient(output)
    plot_delay(output)


if __name__ == "__main__":
    main()
