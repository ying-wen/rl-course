"""Chapter 7, slides course15-trace-lambda-learning and course15-trace-value-maps.

11-21 审阅站请求 r1121-112610：原页图为 learning-lambda.pdf 与 value-maps.pdf
（DejaVu 字体、英文标签，页面上用白块覆盖）。本脚本只写新文件，不覆盖其他图：
  assets/course15-traces/learning-lambda-cn.pdf   泥地，alpha=.05 与 .2，lambda=0,.8,1
  assets/course15-traces/lambda-value-table.json  lambda=0,.8 在第 1、10、200 回合的
                                                   S7、S4 平均估值（alpha=.05）
数据读 course15_traces.py 已写出的 training-values.csv（64 个种子、200 回合、零初值、
普通在线累积迹，各 lambda 共用同一批经验）。不重新训练。

Run: python demos/ch07_lambda_learning_cn.py
"""
from __future__ import annotations
import csv
import json
import sys
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter
sys.path.insert(0, str(Path(__file__).resolve().parent))
from plot_fonts import use_course_fonts, CJK_FAMILY, no_leading_zero

TEAL, RED, GOLD, INK, MUTED = '#087e8b', '#c65335', '#c4942a', '#182e38', '#61757d'
ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'assets/course15-traces'
TRUTH = np.array([9 / 19, 10 / 19])
LAMBDAS = (0., .8, 1.)


def load():
    rows = {}
    with (OUT / 'training-values.csv').open() as f:
        for r in csv.DictReader(f):
            if r['kind'] != 'lambda':
                continue
            key = (float(r['alpha']), float(r['parameter']))
            rows.setdefault(key, {}).setdefault(int(r['seed']), {})[int(r['episode'])] = (
                float(r['S7']), float(r['S4']))
    arrays = {}
    for key, by_seed in rows.items():
        seeds = sorted(by_seed)
        eps = sorted(by_seed[seeds[0]])
        arrays[key] = (np.array(eps), np.array([[by_seed[s][e] for e in eps] for s in seeds]))
    return arrays


def main():
    ok = use_course_fonts()
    plt.rcParams.update({'text.color': INK, 'axes.labelcolor': INK,
                         'xtick.color': INK, 'ytick.color': INK})
    fmt = FuncFormatter(no_leading_zero)
    arrays = load()
    fig, axs = plt.subplots(1, 2, figsize=(7.6, 2.75), sharey=True)
    summary = {}
    for ax, alpha in zip(axs, (.05, .2)):
        for c, lam in zip((TEAL, RED, GOLD), LAMBDAS):
            ep, arr = arrays[(alpha, lam)]
            err = np.sqrt(np.mean((arr - TRUTH) ** 2, axis=2))
            m = err.mean(axis=0)
            se = err.std(axis=0, ddof=1) / np.sqrt(len(err))
            ax.plot(ep, m, color=c, lw=1.8, label=f'$\\lambda={no_leading_zero(lam)}$')
            ax.fill_between(ep, m - se, m + se, color=c, alpha=.15, lw=0)
            summary[f'alpha={alpha},lambda={lam:g}'] = {
                f'ep{e}': round(float(m[e - 1]), 4) for e in (1, 10, 50, 200)}
            summary[f'alpha={alpha},lambda={lam:g}']['mean_ep101_200'] = round(float(m[100:].mean()), 4)
        ax.set_xlim(1, 200); ax.set_ylim(0, .78)
        ax.set_title(f'$\\alpha={no_leading_zero(alpha)}$', fontsize=15)
        ax.set_xlabel('已完成回合数', fontfamily=CJK_FAMILY, fontsize=15)
        ax.yaxis.set_major_formatter(fmt); ax.tick_params(labelsize=14)
        for s in ('top', 'right'):
            ax.spines[s].set_visible(False)
    axs[0].set_ylabel('S7、S4 的均方根误差', fontfamily=CJK_FAMILY, fontsize=15)
    axs[0].legend(fontsize=14, frameon=False, loc='upper right')
    # Mark the lambda=1 level that the alpha=.2 panel keeps after episode 100.
    plateau = summary['alpha=0.2,lambda=1']['mean_ep101_200']
    axs[1].axhline(plateau, xmin=0, xmax=1, color=INK, ls=(0, (2, 2)), lw=.9)
    axs[1].text(198, .70, f'$\\lambda=1$：后 100 回合均值 {no_leading_zero(round(plateau, 2))}',
                ha='right', va='bottom', fontsize=13, color=GOLD, fontfamily=CJK_FAMILY)
    fig.tight_layout(w_pad=1.2)
    fig.savefig(OUT / 'learning-lambda-cn.pdf', bbox_inches='tight', facecolor='white')
    plt.close(fig)

    table = {}
    for lam in (0., .8):
        ep, arr = arrays[(.05, lam)]
        mean = arr.mean(axis=0)
        table[f'lambda={lam:g}'] = {f'ep{e}': [round(float(v), 4) for v in mean[e - 1]]
                                    for e in (1, 10, 200)}
    record = {'scope': 'alpha=.05, mean over 64 seeds of the S7, S4 estimates after the episode; '
                       'zero initial values; ordinary online accumulating trace.',
              'truth': {'S7': 9 / 19, 'S4': 10 / 19}, 'values_S7_S4': table}
    (OUT / 'lambda-value-table.json').write_text(json.dumps(record, indent=1, ensure_ascii=False) + '\n')
    print(json.dumps({'fonts_ok': ok, 'rmse': summary, 'values': table}, indent=1))


if __name__ == '__main__':
    main()
