"""Sarsa(λ), accumulating traces. Reproduce Sutton & Barto, Example 12.1.

Run: python3 demos/ch07_sarsa_lambda.py
The supplied policy follows the path in the figure so that all methods see the
same experience. Passing an epsilon-greedy choose_action implements control.
Coordinates count columns from the left and rows from the top, starting at 0.
"""

from collections import defaultdict
from math import isclose


def sarsa_lambda_episode(initial_state, choose_action, step, q, *, alpha, gamma, lam):
    """Update q in place for one episode. step returns (next_state, reward, terminal)."""
    state = initial_state
    action = choose_action(state, q)
    traces = defaultdict(float)
    while True:
        next_state, reward, terminal = step(state, action)
        if terminal:
            next_action = None
            next_value = 0.0
        else:
            next_action = choose_action(next_state, q)
            next_value = q.get((next_state, next_action), 0.0)
        pair = (state, action)
        delta = reward + gamma * next_value - q.get(pair, 0.0)
        for seen in traces:
            traces[seen] *= gamma * lam
        traces[pair] += 1
        for seen, weight in traces.items():
            q[seen] = q.get(seen, 0.0) + alpha * delta * weight
        if terminal:
            return
        state, action = next_state, next_action


START = (1, 4)
GOAL = (6, 4)
PATH = "RRURUURRRDDRDDLLU"
MOVE = {"R": (1, 0), "L": (-1, 0), "U": (0, -1), "D": (0, 1)}


def step_on_grid(state, action):
    dx, dy = MOVE[action]
    successor = state[0] + dx, state[1] + dy
    terminal = successor == GOAL
    return successor, float(terminal), terminal


def reproduce_figure():
    gamma, alpha = 1.0, 1.0  # Relative arrow lengths; the final action has length 1.
    state = START
    visited = []
    for action in PATH:
        visited.append((state, action))
        state, _, terminal = step_on_grid(state, action)
    assert terminal and len(set(visited)) == len(visited)

    predictions = {}
    for lam in (0.0, 0.9):
        actions = iter(PATH)
        q = {}
        sarsa_lambda_episode(START, lambda state, q: next(actions), step_on_grid,
                             q, alpha=alpha, gamma=gamma, lam=lam)
        assert next(actions, None) is None
        for k, pair in enumerate(visited):
            assert isclose(q[pair], (gamma * lam) ** (len(visited) - 1 - k))
        predictions[lam] = q

    print("step  (col,row)  action  one-step  ten-step  Sarsa(0.9)")
    for k, (state, action) in enumerate(visited):
        pair = state, action
        # With γ=1 and zero initial estimates, each of the last ten returns is 1.
        ten_step = float(len(visited) - k <= 10)
        print(f"{k+1:>4}  {str(state):>9}     {action}     "
              f"{predictions[0.0][pair]:.2f}      {ten_step:.2f}       "
              f"{predictions[0.9][pair]:.4f}")


if __name__ == "__main__":
    reproduce_figure()
