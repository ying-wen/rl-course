"""Chapter 7: lambda sweep for three eligibility traces on the mud self-loop.

Standalone: python3 demos/ch07_trace_sweep.py --out demos/ch07-trace-sweep-results
Dependencies: numpy. Fixed policy S7 -> S4; at S4 the upward move succeeds
with probability .1, otherwise the agent stays in S4. Only entering G pays 1;
gamma = .9. Tabular online TD(lambda) with accumulating, replacing, and true
online (Dutch) traces; zero initial values; all methods and all lambdas share
the same episodes for each seed. Metric: RMSE over (S7, S4) against the exact
values (.4737, .5263), averaged over episodes 1..E, then over seeds.
"""
from __future__ import annotations
import argparse, json
from pathlib import Path
import numpy as np

GAMMA = .9
TRUE = np.array([.9 * .1 / (1 - .81), .1 / (1 - .81)])  # S7, S4


def episode(rng):
    s, r = [0, 1], [0.]
    while True:
        done = rng.random() < .1
        s.append(2 if done else 1); r.append(float(done))
        if done:
            return s, r


def run(eps, kind, alpha, lam):
    v = np.zeros(3)  # index 2 = terminal, stays 0
    err = []
    for s, r in eps:
        e = np.zeros(3)
        for t in range(len(r)):
            st, nx = s[t], s[t + 1]
            delta = r[t] + GAMMA * v[nx] - v[st]
            if kind == 'acc':
                e *= GAMMA * lam; e[st] += 1
                v += alpha * delta * e
            elif kind == 'rep':
                e *= GAMMA * lam; e[st] = 1
                v += alpha * delta * e
            v[2] = 0.
        err.append(np.sqrt(np.mean((v[:2] - TRUE) ** 2)))
    return np.array(err)


def true_online(eps, alpha, lam):
    v = np.zeros(3); err = []
    for s, r in eps:
        z = np.zeros(3); v_old = 0.
        for t in range(len(r)):
            st, nx = s[t], s[t + 1]
            x = np.zeros(3); x[st] = 1.
            vs = v[st]; vn = 0. if nx == 2 else v[nx]
            delta = r[t] + GAMMA * vn - vs
            z = GAMMA * lam * z + (1 - alpha * GAMMA * lam * z[st]) * x
            v = v + alpha * (delta + vs - v_old) * z - alpha * (vs - v_old) * x
            v_old = vn
        err.append(np.sqrt(np.mean((v[:2] - TRUE) ** 2)))
    return np.array(err)


def main():
    ap = argparse.ArgumentParser(); ap.add_argument('--out', required=True)
    ap.add_argument('--seeds', type=int, default=100); ap.add_argument('--episodes', type=int, default=200)
    a = ap.parse_args(); out = Path(a.out); out.mkdir(parents=True, exist_ok=True)
    lams = [0, .2, .4, .6, .8, .9, .95, 1.]
    res = {}
    for alpha in (.05, .2):
        for kind in ('acc', 'rep', 'dutch'):
            for lam in lams:
                m = []; last = []
                for seed in range(a.seeds):
                    rng = np.random.default_rng(seed)
                    eps = [episode(rng) for _ in range(a.episodes)]
                    e = true_online(eps, alpha, lam) if kind == 'dutch' else run(eps, kind, alpha, lam)
                    m.append(e.mean()); last.append(e[-1])
                res[f'{alpha}|{kind}|{lam}'] = dict(mean=float(np.mean(m)), se=float(np.std(m) / np.sqrt(len(m))), final=float(np.mean(last)))
    (out / 'summary.json').write_text(json.dumps(dict(settings=vars(a) | dict(lams=lams, gamma=GAMMA, true=TRUE.tolist()), results=res), indent=1))
    for k, v in res.items():
        print(k, round(v['mean'], 4), round(v['final'], 4))


if __name__ == '__main__':
    main()
