# 资格迹图示来源

- `sutton-forward.pdf`：Sutton & Barto, *Reinforcement Learning: An Introduction*, 2nd edition, Figure 12.4，印刷页292；用户提供 RLbook2020.pdf 的PDF第314页。原图裁切，未改图内内容。
- `sutton-backward.pdf`：同书 Figure 12.5，印刷页293；PDF第315页。原图裁切，未改图内内容。
- `nstep-trees.pdf`、`lambda-trees.pdf`：参考同书 Figure 7.1、12.1 的时间展开方式重新绘制。任务、数值及中文解释由本课给出。
- `trace-snapshots.pdf`、`terminal-value-maps.pdf`：本课同一条四步轨迹上的实际算法计算。由 `demos/course21_trace_visuals.py` 调用 `demos/course15_traces.py` 的更新函数生成。
- `calculations.json` 保存回报、混合权重、资格迹与价值更新结果。这些图是单条轨迹的确定计算，并非训练性能对比。

书籍入口：http://incompleteideas.net/book/the-book-2nd.html

`credit-matrix.pdf`：冻结同一张价值表的前向/后向权重矩阵；`demos/course21_trace_matrix.py` 使用有理数逐项计算，列标签将误差编号和数值分行显示。

- `sutton-nstep-spectrum.png` 和 `sutton-lambda-spectrum.png` 为 Sutton 与 Barto 第 2 版原图 7.1、12.1 的图内裁切。源为 RLbook2020.pdf 的 PDF 页 164、311（印刷页 142、289），以 3.8 倍绘制。裁切矩形左上与右下分别为 (106, 252, 362, 479) 和 (149, 355, 390, 576)，单位为 PDF 点。图中圆圈、动作点和权重均保留。
