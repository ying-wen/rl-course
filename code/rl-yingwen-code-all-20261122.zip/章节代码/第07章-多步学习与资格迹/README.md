# 第 7 章　多步学习与资格迹：程序

本目录可以单独运行：在本目录下执行下面的命令即可，结果写回本目录的 `assets/`。目录由 `rl-course/tools/export_chapter_code.py` 从课程目录生成，改程序请改课程目录里的原件，再重新导出。

## 准备

```sh
python3 -m pip install -r requirements.txt
```

需要的第三方包：matplotlib、numpy。复现附录要求 Python 3.10 或更新版本；核验时用的版本见下表。

## 运行（与复现附录相同）

```sh
python3 demos/course15_traces.py
python3 demos/ch07_nstep_learning_cn.py
python3 demos/course21_trace_visuals.py
python3 demos/course21_trace_matrix.py
python3 demos/trace_credit_lens.py --figures
python3 demos/classic_v13_mechanisms.py
python3 demos/ch07_trace_sweep.py --out demos/ch07-trace-sweep-results
python3 demos/ch07_sarsa_lambda.py
python3 demos/control_record.py
python3 demos/ch07_td_research.py
python3 demos/intentional_td_scale.py --plot
```

## 本目录的程序

| 程序 | 说明 | 核验 |
|---|---|---|
| `demos/course21_trace_visuals.py` | Editable diagrams for n-step returns and eligibility traces. | 通过（2 秒） |
| `demos/course15_traces.py` | Chapter 7: n-step TD, accumulating traces, and true-online TD(lambda). | 通过（11 秒） |
| `demos/ch07_nstep_learning_cn.py` | Chapter 7, slide course15-trace-nstep-learning: two figures in the slide fonts. | 通过（27 秒） |
| `demos/trace_credit_lens.py` | Reproduce the chapter 7 diagrams on one trajectory with exact rational arithmetic. | 通过（1 秒） |
| `demos/course21_trace_matrix.py` | Redraw the frozen-table forward/backward TD-error weight matrix. | 通过（1 秒） |
| `demos/classic_v13_mechanisms.py` | Exact teaching calculations for MDPs, TD, traces, and model-based planning. | 通过（3 秒） |
| `demos/ch07_trace_sweep.py` | Chapter 7: lambda sweep for three eligibility traces on the mud self-loop. | 通过（45 秒） |
| `demos/ch07_sarsa_lambda.py` | Sarsa(λ), accumulating traces. Reproduce Sutton & Barto, Example 12.1. | 通过（0 秒） |
| `demos/control_record.py` | 泥地第 6、7 章：运行 python demos/control_record.py（只用标准库）。 | 通过（0 秒） |
| `demos/ch07_td_research.py` | Two local calculations for the chapter on eligibility traces. | 通过（1 秒） |
| `demos/intentional_td_scale.py` | Intentional TD(0), Sharifnassab et al. (2026), sec. 4, eqs. 6–7. | 通过（1 秒） |
| `demos/ch07_lambda_learning_cn.py` | Chapter 7, slides course15-trace-lambda-learning and course15-trace-value-maps. | 通过（1 秒） |

被上面程序 import 的本课模块：`demos/mud_world.py`、`demos/plot_fonts.py`。

表中后 1 个程序复现附录本章一节没有列出，来自课件、阅读稿、CODE-MAP 或文件名前缀（第三部分另含学习器阶梯）。

## 复现附录本章一节

本章的多步目标、$\lambda$ 权重、资格迹账本、真在线 TD 的逐前缀对照和离策略两步枚举，都在同一条四步泥地轨迹 S7→S4→S4→S4→G 或已知模型上精确计算，多数用有理数运算。各种方法用同一条轨迹，它们的数可以逐项对照。7.5 节例 12.1 路线上的三种 Sarsa 与 7.6 节三页研究算例也是精确计算，各取自己的小例子。学习曲线、价值图和三种迹的扫描表来自模拟，学习曲线独立重复 64 次。

| 位置 | 结果 | 设置 | 程序 | 数据与输出 |
|---|---|---|---|---|
| 7.1 节（课件 `course15-trace-targets`） | 一、二、三步目标与完整回报 .45、.405、.3645、.729；目标树图 | 冻结表 $V(\mathrm{S7})=.4,V(\mathrm{S4})=.5$，$\gamma=.9$，固定四步轨迹；有限算术，无训练 | `demos/course21_trace_visuals.py` | `assets/course21-traces/nstep-trees.png`、`assets/course21-traces/calculations.json`（`nstep_returns`） |
| 7.1 节“等待时间与尾值误差”（课件 `course15-trace-distribution`） | S4 一步目标均值 .505、方差约 .0272；两步目标均值 .50905、方差约 .0466；目标分布图 | 尾值 $V(\mathrm{S4})=.5$，按模型对全部后果求期望的精确计算 | `demos/course15_traces.py` | `assets/course15-traces/target-distribution.png`、`assets/course15-traces/report.json`（`target_distributions`） |
| 7.1 节“实验：$n$ 的选择”（课件 `course15-trace-nstep-learning`，现用两图） | 左：泥地 $\alpha=.05$ 下 $n=1,4,16$ 的误差曲线，第 10 回合 .316、.225、.220，第 200 回合 .042、.065、.085；右：19 状态随机游走前 10 回合平均误差对 $\alpha$ | 左图读下一行 course15_traces.py 写出的 training-values.csv（64 次独立运行），不重训；右图按 Sutton 与 Barto 图 7.2 的设定重算，每组 $(n,\alpha)$ 100 次独立运行 | `demos/ch07_nstep_learning_cn.py` | `assets/course15-traces/learning-n-cn.pdf`、`assets/course15-traces/random-walk-nstep-cn.pdf` |
| 7.1 节“多步更新的执行时刻”（课件 `course15-trace-nstep-learning` 的旧图） | $n=1,4,16$ 的预测误差曲线 | 本课的模拟：固定向上策略，零初值，步长 .05 与 .2，各方法在同一次重复中读相同回合，每次 200 回合，独立重复 64 次（种子偏移 150700）；阴影为一个标准误 | `demos/course15_traces.py` | `assets/course15-traces/learning-n.png`、`assets/course15-traces/training-values.csv`、`assets/course15-traces/report.json`（`experiment`、`learning_summary`） |
| 7.2 节“$\lambda$-回报的水桶”（课件 `course15-trace-lambda`） | $\lambda=.8$ 的四个权重 .2、.16、.128、.512，$G_0^\lambda=.574704$；权重区间图 | 同一冻结表与轨迹，有理数精确运算 | `demos/trace_credit_lens.py`；`demos/course21_trace_visuals.py` | `assets/trace-credit-lens/horizon-mixture.png`、`assets/course21-traces/calculations.json`（`lambda_weights`、`lambda_return`）；程序写 PDF，讲义用同名 PNG |
| 7.3 节“一个新误差分给哪些状态”（课件 `course15-trace-fading`）；“迹的胶片：一回合的账本” | 末步 S7 的迹 .373248、S4 的迹 2.2384；S7 随末步误差提高 .0373；账本中逐步的 $\delta_t$、$e_t$ 与 $\alpha\delta_te_t$，两格总增量 .0349408 与 .19664 | 冻结表 (.4,.5)，$\alpha=.2$，$\gamma\lambda=.72$；有理数精确运算，并核对前向 $\lambda$-回报误差等于后向迹的累计 | `demos/trace_credit_lens.py` | `assets/trace-credit-lens/visit-strips.png`、`assets/trace-credit-lens/signed-writes.png`；逐步数值只在终端输出 |
| 7.3 节“同一张表，两种加法”（课件 `course15-trace-matrix`） | TD 误差 .05、−.05、−.05、.5；行和 .174704、.1732、.31、.5；S4 末列 1.1192 | 同一冻结表，$\gamma=.9,\lambda=.8$；有理数逐项计算，无训练 | `demos/course21_trace_matrix.py` | `assets/course21-traces/credit-matrix.png`、`assets/course21-traces/credit-matrix.json` |
| 7.3 节“一个新误差分给哪些状态”末段（课件 `course15-trace-lambda-learning`、`course15-trace-value-maps`） | 不同步长与 $\lambda=0,.8,1$ 下的预测误差曲线；价值图 | 与 7.1 节的学习曲线同一批运行：每次 200 回合，独立重复 64 次 | `demos/course15_traces.py` | `assets/course15-traces/learning-lambda.png`、`assets/course15-traces/value-maps.png`、`assets/course15-traces/training-values.csv` |
| 7.4 节（课件 `ch07-online-three`、`course15-trace-true-online-code`） | 冻结表整回合更新后 $V(\mathrm{S4})=.6966$；普通累积迹第三步 .473144、终止后 .7090；在线前向参照与真在线 TD 均为 .6713；四个前缀的对照图 | 初值 (.4,.5)，$\alpha=.2,\lambda=.8$，同一四步轨迹；程序另以随机线性特征逐前缀核对真在线递推 | `demos/course15_traces.py` | `assets/course15-traces/online-equivalence.png`、`assets/course15-traces/prefixes.json`、`assets/course15-traces/four-step-trace.csv`、`assets/course15-traces/report.json`（`frozen_final`、`ordinary_final`、`true_online_final`） |
| 7.3 节“在线前向目标与 Dutch 迹” | Dutch 迹在第三步 S4 为 1.576，终点前为 1.907776 | 同一轨迹与初值，$\alpha=.2,\lambda=.8$；另做 120 组随机线性特征的独立核对 | `demos/classic_v13_mechanisms.py` | `assets/classic-v13/results.json`（`traces.true_online_diagnostics`） |
| 7.3 节“原地打转时的三种迹”（课件 `ch07-trace-sweep`） | 两格均方根误差在全部回合上的平均：$\alpha=.2,\lambda=.8$ 时累积 .2658、Dutch .1484、替换 .1035；$\lambda=1$ 时 .5349、.2027、.1038；$\alpha=.05,\lambda=1$ 时 .1530、.1070、.0692 | 本课的模拟：固定向上策略，零初值，表格在线 TD($\lambda$)，三种迹与 $\lambda\in\{0,.2,.4,.6,.8,.9,.95,1\}$ 在同一次重复中共用回合，步长 .05 与 .2，每次 200 回合，独立重复 100 次（种子 0–99） | `demos/ch07_trace_sweep.py` | `demos/ch07-trace-sweep-results/summary.json` |
| 7.5 节（课件 `course15-trace-sarsa-traces`） | Sutton 与 Barto 例 12.1 路线上一步 Sarsa、十步 Sarsa 与 Sarsa(.9) 对各状态动作对的增量 | 固定 17 步路线，$\gamma=1$，$\alpha=1$，零初值，累积迹；有限算术，无训练；图为原书插图 | `demos/ch07_sarsa_lambda.py` | 只在终端输出，不写文件 |
| 7.5 节“后续动作由谁产生”（课件 `course15-trace-offpolicy`、`course15-trace-tree`） | 两步 Sarsa 的比率 $2\times2=4$，Expected Sarsa 的比率 2；所有两步记录上直接平均、比率校正与树回退的目标均值 | 冻结 Q 表 (.5,.1,.2,.7)，行为 $b=(.05,.05,.05,.85)$，目标 $\pi=(.1,0,0,.9)$；转移概率与奖励取自 `mud_world.outcomes`，分数精确运算 | `demos/control_record.py` | 只在终端输出，不写文件 |
| 7.6 节“自举目标也依赖参数”（课件 `ch07-td-research-gradient`） | 普通半梯度方向使样本 TD 误差增加 $.8\alpha$；QRC 校正方向使残差减少 $1.45\alpha$ | $\hat q=w_1$，$\hat q'=2w_1+w_2$，$\mathbf w=(0,0)$，$R=1$，$\gamma=.9$，$H_t=1$；单条转移的精确计算 | `demos/ch07_td_research.py` | `assets/ch07-research/qrc-directions.svg`、`assets/ch07-research/qrc-directions.pdf` |
| 7.6 节“Intentional TD：用预测的单位规定步长”（课件 `ch07-intentional-td`） | 固定参数步长下特征 1 与 2 的预测增加量 .4 与 1.6；按预测变化规定步长时均为 .4 | 单条终止转移，初始参数 0，目标 1，$\nu=.4$；有理数运算，无训练 | `demos/intentional_td_scale.py` | `assets/ch07-research/intentional-scale.svg`、`assets/ch07-research/intentional-scale.pdf` |
| 7.6 节“已知反馈延迟下的时间选择”（课件 `ch07-td-research-delay`） | 平均时间 5 的单指数迹与五级串联迹：距今 1 时 .164 与 .015，距今 4 时 .090 与 .195，串联峰值在 4 | 面积为 1 的连续时间脉冲响应，数值积分核对面积与平均时间 | `demos/ch07_td_research.py` | `assets/ch07-research/delay-kernels.svg`、`assets/ch07-research/delay-kernels.pdf` |

外部代码（出处）：QRC($\lambda$) 的作者实现，Elelimy 等的 [gtd_algos 仓库中的 qrc.py](https://github.com/esraaelelimy/gtd_algos/blob/76293dea9b2129d55e08bfb4178618a0a26c2dd8/gtd_algos/src/algorithms/qrc.py)；Intentional TD 的作者实现 [Intentional_RL](https://github.com/sharifnassab/Intentional_RL)；连续时间资格迹的作者实验 [CET](https://github.com/avecplezir/CET/tree/f2a624b422ebf0cc01904d6b3cf73a2582d1fcfa/RL)。MinAtar 上的回报曲线取自 Elelimy 等的论文，本课没有重跑。例 12.1 的网格图、前向与后向视角图、$n$ 步与 $\lambda$ 谱图取自 Sutton 与 Barto 第 2 版。

运行：
```sh
python3 demos/course15_traces.py
python3 demos/ch07_nstep_learning_cn.py
python3 demos/course21_trace_visuals.py
python3 demos/course21_trace_matrix.py
python3 demos/trace_credit_lens.py --figures
python3 demos/classic_v13_mechanisms.py
python3 demos/ch07_trace_sweep.py --out demos/ch07-trace-sweep-results
python3 demos/ch07_sarsa_lambda.py
python3 demos/control_record.py
python3 demos/ch07_td_research.py
python3 demos/intentional_td_scale.py --plot
```

## 参考数据

`assets/`（以及 `demos/NN-results/`）下复制了 10 个数据文件（json、csv 等），即课程目前使用的结果；图片没有复制，运行程序会重新画出。重跑会覆盖这些文件，可以先另存一份再对照。
