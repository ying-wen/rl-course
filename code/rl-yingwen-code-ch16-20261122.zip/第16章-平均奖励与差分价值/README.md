# 第 16 章　平均奖励与差分价值：程序

本目录可以单独运行：在本目录下执行下面的命令即可，结果写回本目录的 `assets/`。目录由 `rl-course/tools/export_chapter_code.py` 从课程目录生成，改程序请改课程目录里的原件，再重新导出。

## 准备

```sh
python3 -m pip install -r requirements.txt
```

需要的第三方包：matplotlib、numpy。复现附录要求 Python 3.10 或更新版本；核验时用的版本见下表。

## 运行（与复现附录相同）

```sh
python3 demos/sample14_average_option.py    # 写 assets/sample14-avg-option，可用 --out 另写
python3 demos/door_signal.py --option-time  # 只打印
python3 demos/crl_v8_mechanisms.py --figures # 写 assets/crl-v8
python3 demos/crl_v10_derivations.py        # 写 assets/crl-v10
python3 demos/ch16_lit_access_control.py    # 文献原型：接入控制，写 assets/ch16-lit-access-control
python3 demos/ch16_lit_two_loop.py          # 文献原型：Two Loop，写 assets/ch16-lit-two-loop
python3 demos/ch16_r21_figs.py              # 写 assets/ch16-r21
python3 demos/ch16_r21_numbers.py           # 只打印
python3 demos/crl_ladder_learners.py --exp ch16 --seeds 20 --seed0 100 --steps 2000000 --tag formal   # 四区仓库阶梯，写 assets/crl-ladder-world/runs/formal-ch16.json
python3 demos/crl_ladder_figures.py ch16           # 写 assets/crl-ladder-world/fig/ladder-ch16.png
```

## 本目录的程序

| 程序 | 说明 | 核验 |
|---|---|---|
| `demos/sample14_average_option.py` | Three-station worked example: rate -> differential TD -> learned option model -> action. | 通过（10 秒） |
| `demos/door_signal.py` | A cue, a decision, and a delayed alarm in the course's delivery task. | 通过（0 秒） |
| `demos/crl_v8_mechanisms.py` | Small, reproducible calculations for CRL teaching; not a full research agent. | 通过（4 秒） |
| `demos/crl_v10_derivations.py` | Small exact calculations accompanying chapter 14's v10 derivations. | 通过（4 秒） |
| `demos/ch16_lit_access_control.py` | 第 16 章文献原型：接入控制排队（Sutton 与 Barto 第 2 版例 10.2）。 | 通过（125 秒） |
| `demos/ch16_lit_two_loop.py` | 第 16 章文献原型：Two Loop（Wan、Naik 与 Sutton，ICML 2021，第 5 节）。 | 通过（1 秒） |
| `demos/ch16_r21_figs.py` | 第 16 章章首与 16.1–16.2 的三张教学图。 | 通过（2 秒） |
| `demos/ch16_r21_numbers.py` | 11-21 请求 r1121-131027（第 16 章章首与 16.1–16.2）：仓库链上各量的精确计算。 | 通过（0 秒） |
| `demos/crl_ladder_learners.py` | 四区仓库的学习器阶梯（例子方案第三步）。 | 超时：300 秒内未跑完（启动正常） |
| `demos/crl_ladder_figures.py` | 阶梯世界（四区仓库）阅读稿用图：地图与各章“占天花板”条形。 | 通过（3 秒） |
| `demos/crl_ladder_world.py` | 四区仓库：第三部分的能力阶梯世界（环境与精确参照）。 | 通过（65 秒） |
| `demos/crl_ladder_world_checks.py` | 四区仓库的独立检查（照 v12 的做法：手算、枚举、独立实现互查）。 | 通过（52 秒） |
| `demos/crl_ladder_power.py` | 四区仓库学习器阶梯：试点估 σ_Δ 定种子数，正式跑后出第 24 章的账本。 | 通过（0 秒） |
| `demos/crl_ladder_ceiling.py` | 四区仓库学习器阶梯：每个试验条件的“天花板”，供账本算“离最优还差多少”。 | 超时：300 秒内未跑完（启动正常） |
| `demos/crl_ladder_diagnostics.py` | 四区仓库阶梯的诊断与改法（11-20）。 | 通过（0 秒） |

被上面程序 import 的本课模块：`demos/plot_fonts.py`。

表中后 5 个程序复现附录本章一节没有列出，来自课件、阅读稿、CODE-MAP 或文件名前缀（第三部分另含学习器阶梯）。

## 第三部分的学习器阶梯（例子方案第三步）

四区仓库世界与 L0–L10 阶梯学习器。每章一个实验，三档：没有、设计者给定、从经验学到。比较都是配对的：同一种子下两档用同一份世界随机数。

```sh
python3 demos/crl_ladder_world.py --fast                     # 各区参考线，写 reference.json（全量去掉 --fast）
python3 demos/crl_ladder_world_checks.py                     # 世界本身的核对
python3 demos/crl_ladder_ceiling.py                          # 各条件的天花板（ε-软最好率），写 ceiling.json
python3 demos/crl_ladder_learners.py --exp ch16 --seeds 2 --steps 200000 --procs 2 --tag smoke   # 冒烟：写 assets/crl-ladder-world/runs/smoke-ch16.json
python3 demos/crl_ladder_learners.py --exp ch16 --seeds 20 --seed0 100 --steps 2000000 --tag formal   # 正式设置（种子数与 runs/ 里的正式记录相同）
python3 demos/crl_ladder_power.py ledger --runs formal-ch16     # 配对差与 95% 区间，写 ledger-formal-ch16.json
python3 demos/crl_ladder_figures.py ch16                       # 阅读稿用的地图与条形图（读账本）
```

参考记录在 `assets/crl-ladder-world/runs/`（随本目录复制）。正式设置一章要跑数十分钟到数小时；冒烟一行只确认程序能走通。正式结果与读法见 `assets/crl-ladder-world/README.md` 第八节，改进与诊断见第九节。

## 复现附录本章一节

本章来自本课程序的结果有：三站路线的四张图与差分 TD 运行，门口任务的两个奖励率，16.5 节的奖励中心化曲线与逐点数值，16.7 节两状态配送链上的一次行动者–评论者更新，接入控制与 Two Loop 两个文献原型，课件中仓库链的奖励率、折扣值与差分价值的图和数，以及 16.5 节四区仓库上折扣与平均奖励学习器的阶梯实验。仓库链的数在七状态模型上精确求解，不含随机性。

仓库轨迹的奖励率与差分价值（含差分价值图）、三站配送等概率选路的 $13/45$ 与 $4/15$、16.4 节仓库上相对价值迭代的区间 $[2685/2048,\,683/512]$、16.5 节仓库上 $\gamma=.9$ 与 $.99$ 的 $-.583$、$-.621$ 与常数 $23/64$、差分 Q 一节的上限 $1.238$ 与最优总奖励 $13\,333$、16.6 节的翻转阈值与 $\sigma\sqrt{\beta/(2-\beta)}$ 一列、$\alpha\to0$ 时的 $\pm2\varepsilon/7$ 精确解，由正文推导直接算出。控制关系图 `control.svg` 为示意图，不含计算结果。16.5 节“差分 Q 学习与折扣 Q 学习的一次比较”与 16.6 节的几处模拟，程序暂未收入本附录。

| 位置 | 结果 | 设置 | 程序 | 数据与输出 |
|---|---|---|---|---|
| 16.1 节“单链任务的奖励率与状态访问频率”与“原始时间与路线奖励率”；16.2 节“三站路线的差分值与周期残差”；16.5 节“三站往返上的差分 TD 运行” | 两条往返路线的到站与奖励时间线；A–C 与 A–B 往返的长期斜率 $1/3$ 与 $.2$，三个起始相位的累计奖励；十二个相位上的差分价值（抵达 C 前一格 $5/3$，刚到 C 为 $-1$）与周期残差；差分 TD 前几步的 $.3$、$.03$、$-.003$、$.0297$，率估计趋近 $1/3$，完整 18,000 次更新后率误差小于 $10^{-7}$、规范化价值误差小于 $10^{-6}$ | 本课的计算：八格三站路网，每条边占一个原始步；A–C–A 往返十二步，到 C 得 $3$、回 A 得 $1$；A–B–A 往返六步，到 B 得 $.2$、回 A 得 $1$；差分价值由 Poisson 方程取 $\tilde v_\pi(A)=0$ 求解，并对每个相位、0 到 60 步的有限和逐一核对；差分 TD 在固定 A–C 往返上沿一条轨迹更新 18,000 次，价值步长 $.1$、率步长 $.01$，全零初值；确定性计算，无随机重复 | `demos/sample14_average_option.py` | `assets/sample14-avg-option/sample14-avg-timeline.png`、`assets/sample14-avg-option/sample14-avg-slopes.png`、`assets/sample14-avg-option/sample14-avg-bias-period.png`、`assets/sample14-avg-option/sample14-avg-td-learning.png`；逐步记录 `assets/sample14-avg-option/sample14-avg-td-updates.csv`；设置与汇总 `assets/sample14-avg-option/sample14-manifest.json` |
| 16.1 节“原始时间与路线奖励率” | 宽门直行、窄门绕行的长期率 $.15$；一律直行 $-.10$ | 本课的计算：每个门口宽窄独立等可能，线索准确；直行时宽门、窄门的报警概率为 $1/10$、$1/2$，奖励 $1-4\times$报警，期望分别为 $.60$、$-1$；绕行得 $0$；每趟两个原始步；有理数精确计算，无随机重复 | `demos/door_signal.py`（`--option-time`） | 不写文件，结果打印在终端 |
| 16.5 节“奖励中心化与价值尺度” | 三站循环（奖励 $0,0,1$）上未中心化的 $v_\gamma(A)$ 随 $\gamma$ 增大，$\gamma=.99$ 时 $32.999$；减去 $r(\pi)/(1-\gamma)$ 后 $A$ 为 $-.334$，三站分别趋于 $-1/3$、$0$、$1/3$ | 本课的计算：三状态确定性循环，$r(\pi)=1/3$；$\gamma$ 取 $.1$、$.3$、$.5$、$.7$、$.9$、$.95$、$.99$、$.999$，解线性方程求折扣价值与中心化价值，并核对两者之差为 $r(\pi)/(1-\gamma)$；确定性计算，无随机重复 | `demos/crl_v8_mechanisms.py` | `assets/crl-v8/discount-centering.csv`；`--figures` 时写 `assets/crl-v8/reward-centering.png`；核对记录 `assets/crl-v8/checks.json` |
| 16.7 节“平均奖励策略梯度与差分TD”与“策略更新与经验分布”（图 `policy-and-data.png`） | 梯度式与有限差分在 $\theta=0$ 时都为 $2/15$；一次更新后 $\tilde V(A)=.04$、$\bar R=.804$；配送概率 $.5\to.524979$，$d_\pi(B)$ 由 $.333333$ 变为 $.344253$，真实率由 $.8$ 变为 $.813104$，差分价值差由 $1.2$ 变为 $1.186896$ | 本课的计算：两状态配送链，在 A 选 F 留在 A 得 $.4$、选 D 到 B 得 $0$，B 回 A 得 $2$；策略 $p=\sigma(\theta)$，$\theta=0$；用旧评论者与旧率处理一次 D 转移，行动者步长 $.5$、价值步长 $.1$、率步长 $.01$；$\theta$ 在 $[-3,3]$ 上取 121 点画固定策略的率与 $d_\pi(B)$；确定性计算，无随机重复 | `demos/crl_v10_derivations.py` | `assets/crl-v10/results.json`（`delivery` 一项）、`assets/crl-v10/policy-and-data.csv`、`assets/crl-v10/policy-and-data.png` |
| 16.5 节“接入控制排队”与“差分 Q 与 RVI Q” | 精确：最优率 $2.748$，最优策略外加 $\varepsilon=.1$ 探索 $2.647$，来者全收 $2.181$；最优门槛（优先级 1 一律拒，2 要剩至少 4 台，4、8 有空就收）。书例重跑：200 万步时 $\bar R$ 读数 $2.14$–$3.06$，均值 $2.67$，后 100 万步每步实收 $2.64$。Wan 等 §3 重跑：8 万步平均每步实收差分 Q $2.58$、RVI 常见参照 $2.60$、全表均值 $2.52$、罕见参照 $2.15$ | 书例 10.2：10 台服务器，付 $1/2/4/8$，忙的每台每步以 $.06$ 空出，先收客再空出，队首优先级均匀抽取；精确值为已知模型上的相对价值迭代。书例重跑：差分 Sarsa 表格版，$\alpha=.01$，率步长 $.01$，$\varepsilon=.1$，零初值，10 次独立运行各 200 万步。Wan 等：差分 Q 与 RVI Q（参照取单个状态动作对或全表均值），$\alpha=.025$，$\eta=.125$，$\varepsilon=.1$，30 次独立运行各 8 万步，每 2000 步记一点 | `demos/ch16_lit_access_control.py` | `assets/ch16-lit-access-control/results.json` |
| 16.5 节“Two Loop” | 三种策略的率 $1/5$、$2/5$、$3/10$；各一半策略下 $d\cdot v=0$ 的差分价值 $[-1/5,-7/5,-11/10,-4/5,-1/2,3/5,9/10,6/5,3/2]$；折扣下偏爱向右需 $\gamma>2^{-1/4}\approx.841$；平移后的价值误差降到 $.1$ 以下：差分 TD 约 $340$ 步，平均代价 TD 约 $630$ 步，1 万步时 $.007$ 与 $.011$ | Wan 等 §5 的 Two Loop：9 个状态，状态 0 向左得 $1$ 进 5 步环，向右得 $0$ 进另一 5 步环、回 0 时得 $2$；有理数精确计算。预测：评价各一半策略，差分 TD（$\alpha=.2$，$\eta=.25$）与平均代价 TD（$\alpha=.1$，$\eta=.125$），步长每步乘 $.9995$，零初值，30 次独立运行各 1 万步；误差先减 $c=\sum_z d_\pi(z)\tilde V(z)$ 再按 $d_\pi$ 加权求均方根 | `demos/ch16_lit_two_loop.py` | `assets/ch16-lit-two-loop/results.json` |
| 16.1 节（课件 `ch15-f02-rate`）；16.2 节（课件 `ch16-r21-bias-relation`） | 奖励率的滑动累计图、三种评分对照图、差分价值与折扣价值的关系图 | 本课的计算：仓库链上策略“转角总向左”的精确计算，无训练 | `demos/ch16_r21_figs.py` | `assets/ch16-r21/rate-running.pdf`、`assets/ch16-r21/three-scores.pdf`、`assets/ch16-r21/bias-discount.pdf` |
| 16.1 节（课件 `ch16-r21-rate-discount`）；16.2 节（课件 `ch15-f02-bias`、`ch16-r21-poisson-chain`） | 仓库链的奖励率与折扣值；差分价值中的 $23/64$ 与 .92；泊松方程链例的 $5/8$ | 本课的计算：七状态仓库链，奖励记在离开状态的那一步，精确求解 | `demos/ch16_r21_numbers.py` | 只在终端输出，不写文件 |
| 16.5 节（课件 `ch16-ladder`） | $\gamma=.9$ 学成后仍差天花板一成；$\gamma=.99$ 与学 $\bar R$ 学成后一样；差别按 Holm 校正判断 | 本课的模拟：四区仓库，200 万步不复位，付款规律固定为 R0，20 个种子 | `demos/crl_ladder_learners.py` 实验 `ch16` | `assets/crl-ladder-world/runs/formal-ch16.json`、`assets/crl-ladder-world/fig/ladder-ch16.png` |

运行：
```sh
python3 demos/sample14_average_option.py    # 写 assets/sample14-avg-option，可用 --out 另写
python3 demos/door_signal.py --option-time  # 只打印
python3 demos/crl_v8_mechanisms.py --figures # 写 assets/crl-v8
python3 demos/crl_v10_derivations.py        # 写 assets/crl-v10
python3 demos/ch16_lit_access_control.py    # 文献原型：接入控制，写 assets/ch16-lit-access-control
python3 demos/ch16_lit_two_loop.py          # 文献原型：Two Loop，写 assets/ch16-lit-two-loop
python3 demos/ch16_r21_figs.py              # 写 assets/ch16-r21
python3 demos/ch16_r21_numbers.py           # 只打印
python3 demos/crl_ladder_learners.py --exp ch16 --seeds 20 --seed0 100 --steps 2000000 --tag formal   # 四区仓库阶梯，写 assets/crl-ladder-world/runs/formal-ch16.json
python3 demos/crl_ladder_figures.py ch16           # 写 assets/crl-ladder-world/fig/ladder-ch16.png
```

## 参考数据

`assets/`（以及 `demos/NN-results/`）下复制了 112 个数据文件（json、csv 等），即课程目前使用的结果；图片没有复制，运行程序会重新画出。重跑会覆盖这些文件，可以先另存一份再对照。
