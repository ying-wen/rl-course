"""第 16 章章首与 16.1–16.2 的三张教学图。

Run from rl-course:
    python demos/ch16_r21_figs.py

Writes
    assets/ch16-r21/rate-running.pdf   (page ch15-f02-rate)
    assets/ch16-r21/three-scores.pdf   (page ch15-f02-criteria)
    assets/ch16-r21/bias-discount.pdf  (page ch16-r21-bias-relation)

11-21 审阅站请求 r1121-131027（第 16 章，1535、1536、1537 的图示）。
所有数字由 demos/ch16_r21_numbers.py 中的仓库链精确计算，策略为“转角总向左”。
"""
from pathlib import Path
import sys

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter, FixedLocator

sys.path.insert(0, str(Path(__file__).resolve().parent))
from plot_fonts import use_course_fonts, CJK_FAMILY, no_leading_zero  # noqa: E402
from ch16_r21_numbers import chain, stationary, disc, bias_ref, ix  # noqa: E402

TEAL, RED, GOLD, MUTED, INK = "#096B76", "#AA412D", "#A27618", "#52666E", "#182E38"
OUT = Path(__file__).resolve().parent.parent / "assets" / "ch16-r21"
NLZ = FuncFormatter(no_leading_zero)
PLAIN = FuncFormatter(lambda x, _p=None: f'{x:g}')


def log_ticks(ax):
    ax.xaxis.set_major_locator(FixedLocator([1, 10, 100, 1000]))
    ax.xaxis.set_major_formatter(PLAIN)
    ax.xaxis.set_minor_formatter(FuncFormatter(lambda x, _p=None: ''))

P, r = chain(False)
RATE = stationary(P) @ r          # 5/8


def m_seq(z, T):
    """m_t(z) = E[R_{t+1} | Z_0 = z], t = 0..T-1."""
    x = np.eye(7)[ix[z]]; out = []
    for _ in range(T):
        out.append(x @ r); x = x @ P
    return np.array(out)


def rate_running(with_discount=True, name='rate-running.pdf', size=(4.6, 2.75)):
    T = 1000
    fig, ax = plt.subplots(figsize=size)
    starts = [('D_L', '$D_L$', GOLD), ('B', '$B$', TEAL), ('C', '$C$', RED)]
    Ts = np.arange(1, T + 1)
    for z, lab, c in starts:
        ces = np.cumsum(m_seq(z, T)) / Ts
        ax.plot(Ts, ces, color=c, lw=1.4, label=f'从 {lab} 起：前 $T$ 步平均')
    gs = 1 - np.logspace(0, -3, 120)
    gs = gs[(gs > 0) & (gs < 1)]
    for z, lab, c in starts if with_discount else []:
        ab = [(1 - g) * disc(P, r, g)[ix[z]] for g in gs]
        ax.plot(1 / (1 - gs), ab, color=c, lw=1.0, ls=(0, (3, 2)), alpha=.9)
    ax.axhline(RATE, color=INK, lw=.7)
    ax.text(260, RATE + .05, '$r(\\pi)=5/8$', fontsize=8, color=INK)
    ax.set_xscale('log'); log_ticks(ax)
    ax.set_xlim(1, 1000); ax.set_ylim(0, 1.45)
    if with_discount:
        ax.set_xlabel('步数 $T$（实线）　有效期限 $1/(1-\\gamma)$（虚线）', fontfamily=CJK_FAMILY, fontsize=8)
    else:
        ax.set_xlabel('步数 $T$', fontfamily=CJK_FAMILY, fontsize=8)
    ax.set_ylabel('每步奖励', fontsize=8)
    ax.yaxis.set_major_formatter(NLZ)
    ax.tick_params(labelsize=7)
    ax.legend(fontsize=7, frameon=False, loc='upper right', prop={'family': CJK_FAMILY, 'size': 7})
    if with_discount:
        ax.text(30, .18, '虚线：$(1-\\gamma)\\,v_\\gamma(z)$', fontsize=7.5, color=MUTED, fontfamily=CJK_FAMILY)
    for s in ('top', 'right'):
        ax.spines[s].set_visible(False)
    fig.tight_layout(pad=.3)
    fig.savefig(OUT / name)
    plt.close(fig)


def three_scores():
    T = 60
    Ts = np.arange(1, T + 1)
    fig, axs = plt.subplots(1, 3, figsize=(7.2, 2.15))
    g = .9
    for z, lab, c in [('B', '$B$', TEAL), ('C', '$C$', RED)]:
        m = m_seq(z, T)
        axs[0].plot(Ts, np.cumsum(m), color=c, lw=1.3, label=f'从 {lab} 起')
        axs[1].plot(Ts, np.cumsum(m * g ** np.arange(T)), color=c, lw=1.3)
        axs[2].plot(Ts, np.cumsum(m) / Ts, color=c, lw=1.3)
        vg = disc(P, r, g)[ix[z]]
        axs[1].axhline(vg, color=c, lw=.6, ls=':')
    axs[0].set_title('前 $T$ 步总和', fontfamily=CJK_FAMILY, fontsize=8.5)
    axs[1].set_title('折扣和，$\\gamma=.9$', fontfamily=CJK_FAMILY, fontsize=8.5)
    axs[2].set_title('前 $T$ 步平均', fontfamily=CJK_FAMILY, fontsize=8.5)
    axs[0].text(4, 32, '随 $T$ 无限增长', fontsize=7.5, color=MUTED, fontfamily=CJK_FAMILY)
    axs[1].text(22, 3.0, '极限 5.83 与 5.25\n$\\gamma=.99$ 时变成 62.1 与 61.5', fontsize=7, color=MUTED,
                fontfamily=CJK_FAMILY, linespacing=1.3)
    axs[2].axhline(RATE, color=INK, lw=.7)
    axs[2].text(18, .9, '都趋于 $5/8$，与 $\\gamma$ 无关', fontsize=7.5, color=MUTED, fontfamily=CJK_FAMILY)
    axs[2].set_ylim(0, 1.2)
    axs[0].legend(fontsize=7, frameon=False, loc='lower right', prop={'family': CJK_FAMILY, 'size': 7})
    for ax in axs:
        ax.set_xlim(0, T); ax.tick_params(labelsize=7)
        ax.set_xlabel('$T$', fontsize=8)
        ax.yaxis.set_major_formatter(NLZ)
        for s in ('top', 'right'):
            ax.spines[s].set_visible(False)
    fig.tight_layout(pad=.3, w_pad=1.2)
    fig.savefig(OUT / 'three-scores.pdf')
    plt.close(fig)


def bias_discount():
    h = bias_ref(P, r, RATE)       # 取 B 为 0
    gs = 1 - np.logspace(0, -3, 160)
    gs = gs[(gs > 0) & (gs < 1)]
    H = 1 / (1 - gs)
    V = np.array([disc(P, r, g) for g in gs])
    fig, ax = plt.subplots(figsize=(4.4, 2.3))
    show = [('J_L', '$J_L$', TEAL, 0), ('D_L', '$D_L$', '#5FA8B0', 0), ('W', '$W$', GOLD, .08),
            ('C', '$C$', RED, .02), ('J_R', '$J_R$', INK, -.1), ('D_R', '$D_R$', MUTED, 0)]
    for z, lab, c, dy in show:
        ax.plot(H, V[:, ix[z]] - V[:, ix['B']], color=c, lw=1.3)
        ax.axhline(h[ix[z]], color=c, lw=.6, ls=(0, (3, 2)))
        ax.text(1150, h[ix[z]] + dy, lab, fontsize=7.5, va='center', color=c)
    for g in (.9, .99):
        ax.axvline(1 / (1 - g), color=MUTED, lw=.5, ls=':')
        ax.text(1 / (1 - g) * 1.06, 3.85, f'$\\gamma={no_leading_zero(g)}$', fontsize=7, color=MUTED)
    ax.set_xscale('log'); log_ticks(ax); ax.set_xlim(1, 1000); ax.set_ylim(-2.1, 4.2)
    ax.set_xlabel('有效期限 $1/(1-\\gamma)$', fontfamily=CJK_FAMILY, fontsize=8)
    ax.set_ylabel('$v_\\gamma(z)-v_\\gamma(B)$', fontsize=8)
    ax.yaxis.set_major_formatter(NLZ); ax.tick_params(labelsize=7)
    ax.text(1.25, -1.95, '虚线：差分价值 $\\tilde v_\\pi(z)$，取 $\\tilde v_\\pi(B)=0$', fontsize=7,
            color=MUTED, fontfamily=CJK_FAMILY)
    for s in ('top', 'right'):
        ax.spines[s].set_visible(False)
    fig.tight_layout(pad=.3)
    fig.savefig(OUT / 'bias-discount.pdf')
    plt.close(fig)


def discount_weights():
    """未来各步的权重：(1-gamma)gamma^t 与 1/T，叠在从 B 出发的 m_t 上。"""
    T = 40
    t = np.arange(T)
    fig, ax = plt.subplots(figsize=(4.2, 2.2))
    m = m_seq('B', T)
    ax2 = ax.twinx()
    ax2.bar(t, m, width=.6, color=MUTED, alpha=.28, zorder=0)
    ax2.set_ylim(0, 4.6); ax2.set_ylabel('$m_t(B)$', fontsize=8, color=MUTED)
    ax2.tick_params(labelsize=7, colors=MUTED)
    for g, c in ((.9, RED), (.95, GOLD)):
        ax.plot(t, (1 - g) * g ** t, color=c, lw=1.4, marker='o', ms=2,
                label=f'折扣 $(1-\\gamma)\\gamma^t$，$\\gamma={no_leading_zero(g)}$')
    ax.plot(t, np.full(T, 1 / T), color=TEAL, lw=1.6, label='前 $T$ 步平均 $1/T$，$T=40$')
    ax.set_zorder(ax2.get_zorder() + 1); ax.patch.set_visible(False)
    ax.set_xlim(-.6, T - .4); ax.set_ylim(0, .105)
    ax.set_xlabel('第 $t$ 步', fontfamily=CJK_FAMILY, fontsize=8)
    ax.set_ylabel('权重', fontsize=8)
    ax.yaxis.set_major_formatter(NLZ); ax.tick_params(labelsize=7)
    ax.legend(fontsize=7, frameon=False, loc='upper right', prop={'family': CJK_FAMILY, 'size': 7})
    for a in (ax, ax2):
        a.spines['top'].set_visible(False)
    fig.tight_layout(pad=.3)
    fig.savefig(OUT / 'discount-weights.pdf')
    plt.close(fig)


if __name__ == '__main__':
    use_course_fonts()
    OUT.mkdir(parents=True, exist_ok=True)
    rate_running(); rate_running(False, 'rate-cesaro.pdf', (4.2, 2.6))
    three_scores(); bias_discount(); discount_weights()
    print('wrote', sorted(p.name for p in OUT.iterdir()))
