# -*- coding: utf-8 -*-
"""第 16 章文献原型：Two Loop（Wan、Naik 与 Sutton，ICML 2021，第 5 节）。

状态 0 有两个动作：向左得 +1，进入 1→2→3→4→0 的环；向右得 0，进入 5→6→7→8→0 的环，
8→0 一步得 +2。其他状态只有一个动作。两环各 5 步。

1. 精确计算：一直向左、一直向右、各一半三种策略的奖励率；各一半策略的差分价值
   （取平稳分布加权和为 0 的那一组）；折扣目标下向右更好所需的折扣率下限。
2. 重跑论文的同策略预测实验：评价各一半策略，差分 TD 与平均代价 TD，
   30 次独立运行 × 10,000 步，零初值，步长每步乘 0.9995；
   误差用 RMSVE(TVR)：先减去按平稳分布加权的平移，再按平稳分布加权求均方根。

用法：python3 demos/ch16_lit_two_loop.py
结果写 assets/ch16-lit-two-loop/results.json。
"""
import argparse
import json
import os
import time
from fractions import Fraction as Fr

import numpy as np

NS = 9


def chain(p_right):
    """返回转移矩阵 T 与每状态期望奖励 r（Fraction）。"""
    T = [[Fr(0)] * NS for _ in range(NS)]
    r = [Fr(0)] * NS
    pl = 1 - p_right
    T[0][1] += pl
    r[0] += pl * 1
    T[0][5] += p_right
    for s in (1, 2, 3):
        T[s][s + 1] = Fr(1)
    T[4][0] = Fr(1)
    for s in (5, 6, 7):
        T[s][s + 1] = Fr(1)
    T[8][0] = Fr(1)
    r[8] = Fr(2)
    return T, r


def solve_fr(A, b):
    n = len(A)
    M = [row[:] + [b[i]] for i, row in enumerate(A)]
    for c in range(n):
        p = next(i for i in range(c, n) if M[i][c] != 0)
        M[c], M[p] = M[p], M[c]
        piv = M[c][c]
        M[c] = [x / piv for x in M[c]]
        for i in range(n):
            if i != c and M[i][c] != 0:
                f = M[i][c]
                M[i] = [a - f * bb for a, bb in zip(M[i], M[c])]
    return [M[i][n] for i in range(n)]


def exact(p_right):
    """平稳分布 d、率 r、满足 d·v=0 的差分价值 v（精确有理数）。
    只在常返状态上解；暂态（如一直向左时的 5–8）d=0，价值由递推补上。"""
    T, r = chain(p_right)
    # 平稳分布：d T = d，sum d = 1；用 n+1 个方程中去掉一个
    A = [[T[j][i] - (1 if i == j else 0) for j in range(NS)] for i in range(NS)]
    A[-1] = [Fr(1)] * NS
    b = [Fr(0)] * (NS - 1) + [Fr(1)]
    try:
        d = solve_fr(A, b)
    except StopIteration:
        d = None
    rate = sum(di * ri for di, ri in zip(d, r))
    # Poisson：v = r - rate + T v，加 d·v = 0；替换状态 0 的方程
    A2 = [[(1 if i == j else 0) - T[i][j] for j in range(NS)] for i in range(NS)]
    b2 = [r[i] - rate for i in range(NS)]
    A2[0] = d[:]
    b2[0] = Fr(0)
    v = solve_fr(A2, b2)
    return d, rate, v


def run_pred(kind, alpha0, eta, runs, steps, seed, decay=0.9995):
    rng = np.random.default_rng(seed)
    d, rate, v = exact(Fr(1, 2))
    d = np.array([float(x) for x in d])
    v = np.array([float(x) for x in v])
    rate = float(rate)
    V = np.zeros((runs, NS))
    Rb = np.zeros(runs)
    s = np.zeros(runs, dtype=int)
    idx = np.arange(runs)
    nxt_fixed = np.array([0, 2, 3, 4, 0, 6, 7, 8, 0])
    rmsve = np.zeros(steps)
    rre = np.zeros(steps)
    alpha = alpha0
    for t in range(steps):
        right = rng.random(runs) < 0.5
        s2 = np.where(s == 0, np.where(right, 5, 1), nxt_fixed[s])
        r = np.where((s == 0) & ~right, 1.0, 0.0) + np.where(s == 8, 2.0, 0.0)
        delta = r - Rb + V[idx, s2] - V[idx, s]
        V[idx, s] += alpha * delta
        if kind == 'differential':
            Rb += eta * alpha * delta
        else:  # Tsitsiklis 与 Van Roy 的平均代价 TD
            Rb += eta * alpha * (r - Rb)
        s = s2
        alpha *= decay
        c = V @ d
        err = V - c[:, None] - v[None, :]
        rmsve[t] = np.sqrt((err ** 2 @ d)).mean()
        rre[t] = ((rate - Rb) ** 2).mean()
    return rmsve, rre


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--runs', type=int, default=30)
    ap.add_argument('--steps', type=int, default=10_000)
    ap.add_argument('--out', default=os.path.join(os.path.dirname(__file__), '..', 'assets', 'ch16-lit-two-loop'))
    args = ap.parse_args()
    t0 = time.time()
    out = {'exact': {}}
    for name, p in (('always_left', Fr(0)), ('always_right', Fr(1)), ('random_half', Fr(1, 2))):
        d, rate, v = exact(p)
        out['exact'][name] = {'rate': str(rate), 'rate_float': float(rate),
                              'd': [str(x) for x in d], 'v_dv0': [str(x) for x in v]}
    # 折扣：V(左) = 1/(1-g^5)，V(右) = 2 g^4/(1-g^5)；向右更好 iff g > 2^(-1/4)
    out['exact']['discount_threshold_right_better'] = 2 ** (-0.25)
    out['setting'] = {'runs': args.runs, 'steps': args.steps, 'policy': 'random 0.5 at state 0',
                      'step_decay_per_step': 0.9995, 'init': 0.0,
                      'differential_td': {'alpha': 0.2, 'eta': 0.25},
                      'average_cost_td': {'alpha': 0.1, 'eta': 0.125}}
    curves = {}
    for j, (kind, a, e) in enumerate((('differential', 0.2, 0.25), ('average_cost', 0.1, 0.125))):
        rm, rr = run_pred(kind, a, e, args.runs, args.steps, seed=50 + j)
        pts = sorted(set([0, 9, 24, 49, 99, 149, 199, 299, 399, 499, 749, 999, 1499, 1999, 2999, 3999, 4999, 7499]
                          + list(range(999, args.steps, 1000)) + [args.steps - 1]))
        pts = [p for p in pts if p < args.steps]
        curves[kind] = {'t': [p + 1 for p in pts], 'rmsve_tvr': [float(rm[p]) for p in pts],
                        'rre': [float(rr[p]) for p in pts],
                        'mean_rmsve_over_run': float(rm.mean()),
                        'first_step_rmsve_below_0.1': int(np.argmax(rm < 0.1) + 1) if (rm < 0.1).any() else None,
                        'final_rmsve': float(rm[-1]), 'final_rre': float(rr[-1])}
        print(kind, curves[kind]['mean_rmsve_over_run'], curves[kind]['first_step_rmsve_below_0.1'],
              curves[kind]['final_rmsve'], curves[kind]['final_rre'])
    out['prediction'] = curves
    out['seconds'] = time.time() - t0
    os.makedirs(args.out, exist_ok=True)
    with open(os.path.join(args.out, 'results.json'), 'w', encoding='utf-8') as fh:
        json.dump(out, fh, ensure_ascii=False, indent=1)
    print(json.dumps(out['exact'], ensure_ascii=False))
    print('seconds', out['seconds'])


if __name__ == '__main__':
    main()
