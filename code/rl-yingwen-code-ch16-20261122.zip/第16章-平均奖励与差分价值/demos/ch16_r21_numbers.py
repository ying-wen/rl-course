"""11-21 请求 r1121-131027（第 16 章章首与 16.1–16.2）：仓库链上各量的精确计算。
状态顺序 B, D_L, D_R, J_L, J_R, W, C；奖励记在离开该状态的那一步上。"""
import numpy as np
from fractions import Fraction as F

S = ['B', 'D_L', 'D_R', 'J_L', 'J_R', 'W', 'C']
ix = {s: i for i, s in enumerate(S)}


def chain(turn_with_light=False):
    P = np.zeros((7, 7)); r = np.zeros(7)
    P[ix['B'], ix['D_L']] = P[ix['B'], ix['D_R']] = .5
    P[ix['D_L'], ix['J_L']] = 1; P[ix['D_R'], ix['J_R']] = 1
    P[ix['J_L'], ix['B']] = 1; r[ix['J_L']] = 4
    if turn_with_light:
        P[ix['J_R'], ix['B']] = 1; r[ix['J_R']] = 4
    else:
        P[ix['J_R'], ix['W']] = 1
    P[ix['W'], ix['C']] = 1; r[ix['W']] = 1
    P[ix['C'], ix['B']] = 1
    return P, r


def stationary(P):
    n = len(P); A = np.vstack([P.T - np.eye(n), np.ones(n)])
    b = np.zeros(n + 1); b[-1] = 1
    return np.linalg.lstsq(A, b, rcond=None)[0]


def disc(P, r, g):
    return np.linalg.solve(np.eye(len(P)) - g * P, r)


def bias_ref(P, r, rate, ref='B'):
    """Poisson 方程 v = r - rate + P v，取 v(ref)=0。"""
    n = len(P); A = np.eye(n) - P; b = r - rate
    A = np.vstack([A, np.eye(n)[ix[ref]]]); b = np.append(b, 0)
    return np.linalg.lstsq(A, b, rcond=None)[0]


if __name__ == '__main__':
    for twl in (False, True):
        P, r = chain(twl); d = stationary(P); rate = d @ r
        print('turn_with_light' if twl else 'always_left', 'rate', rate)
        print(' d', dict(zip(S, np.round(d, 4))))
        h = bias_ref(P, r, rate); print(' bias(B=0)', dict(zip(S, np.round(h, 4))))
        hc = h - d @ h; print(' bias(d^T h=0)', dict(zip(S, np.round(hc, 4))), 'shift', d @ h)
        for g in (.9, .99, .999):
            v = disc(P, r, g)
            print(f'  g={g} v', dict(zip(S, np.round(v, 4))))
            print(f'   (1-g)v', dict(zip(S, np.round((1 - g) * v, 4))), 'd.v*(1-g)', round(d @ v * (1 - g), 6))
            print(f'   v - rate/(1-g)', dict(zip(S, np.round(v - rate / (1 - g), 4))))
            print(f'   v-v(B)', dict(zip(S, np.round(v - v[0], 4))))
    P, r = chain(False)
    # Cesaro running averages
    for z in ('B', 'C', 'D_L', 'W'):
        x = np.eye(7)[ix[z]]; tot = 0; out = {}
        for t in range(1, 1001):
            tot += x @ r; x = x @ P
            if t in (3, 8, 10, 20, 40, 80, 200, 1000): out[t] = round(tot / t, 4)
        print('Cesaro', z, out)
    # deviation sum lim E sum (R - rate) from B, check convergence
    x = np.eye(7)[0]; tot = 0
    for t in range(400): tot += x @ r - 5 / 8; x = x @ P
    print('partial centered sum from B, T=400', tot)
    # eigenvalues
    print('eig P', np.round(np.linalg.eigvals(P), 4))
