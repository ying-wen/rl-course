# -*- coding: utf-8 -*-
"""第 16 章文献原型：接入控制排队（Sutton 与 Barto 第 2 版例 10.2）。

三部分：
1. 精确计算：已知模型上做相对价值迭代，求最优奖励率、最优策略，
   并求“全部接受”与“最优策略加 0.1 探索”的精确奖励率；
2. 例 10.2 的设定重跑：表格差分 Sarsa，alpha=0.01，beta=0.01，epsilon=0.1，
   每次 2,000,000 步；
3. Wan、Naik 与 Sutton（ICML 2021）第 3 节的设定重跑：差分 Q 学习与三种参照的
   RVI Q 学习，alpha=0.025，eta=0.125，epsilon=0.1，每次 80,000 步、30 次独立运行。

用法：python3 demos/ch16_lit_access_control.py [--sb-runs 10] [--sb-steps 2000000]
结果写 assets/ch16-lit-access-control/results.json。
"""
import argparse
import json
import os
import time

import numpy as np

N_SERVERS = 10
PAYS = np.array([1.0, 2.0, 4.0, 8.0])
P_FREE = 0.06
NF, NK, NA = N_SERVERS + 1, 4, 2  # 空闲台数 0..10，优先级 4 种，动作 拒绝/接受


def binom_pmf(n, p):
    from math import comb
    return np.array([comb(n, j) * p ** j * (1 - p) ** (n - j) for j in range(n + 1)])


def build_model():
    """P[f, a, f'] 与 R[f, k, a]；优先级下一步均匀、与动作无关。"""
    P = np.zeros((NF, NA, NF))
    R = np.zeros((NF, NK, NA))
    for f in range(NF):
        for a in range(NA):
            acc = 1 if (a == 1 and f > 0) else 0
            f1 = f - acc
            busy = N_SERVERS - f1
            pmf = binom_pmf(busy, P_FREE)
            for j, pr in enumerate(pmf):
                P[f, a, f1 + j] += pr
            for k in range(NK):
                R[f, k, a] = PAYS[k] * acc
    return P, R


def q_backup(P, R, V):
    """V[f, k] -> Q[f, k, a] 的期望备份（不减率）。"""
    EV = V.mean(axis=1)  # 下一优先级均匀
    nxt = P @ EV  # [f, a]
    return R + nxt[:, None, :]


def rvi(P, R, iters=20000, tol=1e-13):
    V = np.zeros((NF, NK))
    for _ in range(iters):
        Q = q_backup(P, R, V)
        TV = Q.max(axis=2)
        d = TV - V
        lo, hi = d.min(), d.max()
        V = TV - TV[N_SERVERS, 3]
        if hi - lo < tol:
            break
    Q = q_backup(P, R, V)
    return 0.5 * (lo + hi), Q


def policy_rate(P, R, pi):
    """pi[f, k, a] 为动作概率；返回精确奖励率与平稳分布 d[f, k]。"""
    n = NF * NK
    T = np.zeros((n, n))
    r = np.zeros(n)
    for f in range(NF):
        for k in range(NK):
            i = f * NK + k
            for a in range(NA):
                w = pi[f, k, a]
                if w == 0:
                    continue
                r[i] += w * R[f, k, a]
                for f2 in range(NF):
                    for k2 in range(NK):
                        T[i, f2 * NK + k2] += w * P[f, a, f2] / NK
    A = np.vstack([T.T - np.eye(n), np.ones(n)])
    b = np.zeros(n + 1)
    b[-1] = 1
    d = np.linalg.lstsq(A, b, rcond=None)[0]
    return float(d @ r), d.reshape(NF, NK)


def greedy_pi(Q, eps=0.0):
    pi = np.zeros((NF, NK, NA))
    g = Q.argmax(axis=2)
    for f in range(NF):
        for k in range(NK):
            pi[f, k, :] = eps / NA
            pi[f, k, g[f, k]] += 1 - eps
    return pi


def thresholds(Q):
    """每个优先级：至少要有几台空闲才接受（贪心，接受严格更大）。"""
    out = {}
    for k in range(NK):
        acc = [f for f in range(1, NF) if Q[f, k, 1] > Q[f, k, 0]]
        out[int(PAYS[k])] = (min(acc) if acc else None)
    return out


def step_env(rng, f, k, a):
    acc = ((a == 1) & (f > 0)).astype(int)
    r = PAYS[k] * acc
    f1 = f - acc
    freed = rng.binomial(N_SERVERS - f1, P_FREE)
    return r, f1 + freed, rng.integers(0, NK, size=f.shape)


def choose(rng, Qsa, eps):
    """Qsa: [runs, 2]；随机打破平局的 epsilon-贪心。"""
    n = Qsa.shape[0]
    g = np.where(Qsa[:, 1] > Qsa[:, 0], 1,
                 np.where(Qsa[:, 1] < Qsa[:, 0], 0, rng.integers(0, 2, size=n)))
    explore = rng.random(n) < eps
    return np.where(explore, rng.integers(0, 2, size=n), g)


def run_sb(runs, steps, seed, alpha=0.01, beta=0.01, eps=0.1, every=20000):
    """例 10.2：表格差分 Sarsa（R̄ <- R̄ + beta*delta）。"""
    rng = np.random.default_rng(seed)
    idx = np.arange(runs)
    Q = np.zeros((runs, NF, NK, NA))
    Rbar = np.zeros(runs)
    f = np.full(runs, N_SERVERS)
    k = rng.integers(0, NK, size=runs)
    a = choose(rng, Q[idx, f, k], eps)
    trace, win = [], np.zeros(runs)
    for t in range(1, steps + 1):
        r, f2, k2 = step_env(rng, f, k, a)
        a2 = choose(rng, Q[idx, f2, k2], eps)
        delta = r - Rbar + Q[idx, f2, k2, a2] - Q[idx, f, k, a]
        Rbar += beta * delta
        Q[idx, f, k, a] += alpha * delta
        win += r
        f, k, a = f2, k2, a2
        if t % every == 0:
            trace.append((t, Rbar.mean(), Rbar.min(), Rbar.max(), (win / every).mean(), Rbar.round(4).tolist()))
            win[:] = 0
    return Q, Rbar, trace


def run_wan(kind, runs, steps, seed, alpha=0.025, eta=0.125, eps=0.1, window=2000, ref=None):
    """kind: 'diffq' 或 'rvi'；ref 为 (f, k, a) 或 'mean'。"""
    rng = np.random.default_rng(seed)
    idx = np.arange(runs)
    Q = np.zeros((runs, NF, NK, NA))
    Rbar = np.zeros(runs)
    f = np.full(runs, N_SERVERS)  # 论文：开始时 10 台全空
    k = rng.integers(0, NK, size=runs)
    rewards = np.zeros((steps, runs))
    for t in range(steps):
        a = choose(rng, Q[idx, f, k], eps)
        r, f2, k2 = step_env(rng, f, k, a)
        nxt = Q[idx, f2, k2].max(axis=1)
        if kind == 'diffq':
            delta = r - Rbar + nxt - Q[idx, f, k, a]
            Rbar += eta * alpha * delta
        else:
            fref = Q.reshape(runs, -1).mean(axis=1) if ref == 'mean' else Q[idx, ref[0], ref[1], ref[2]]
            delta = r - fref + nxt - Q[idx, f, k, a]
        Q[idx, f, k, a] += alpha * delta
        rewards[t] = r
        f, k = f2, k2
    cs = np.cumsum(rewards, axis=0)
    pts = list(range(window, steps + 1, window))
    curve = [float(((cs[p - 1] - (cs[p - window - 1] if p > window else 0)) / window).mean()) for p in pts]
    se = [float(((cs[p - 1] - (cs[p - window - 1] if p > window else 0)) / window).std(ddof=1) / np.sqrt(runs)) for p in pts]
    overall = rewards.mean(axis=0)
    return Q, pts, curve, se, overall


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--sb-runs', type=int, default=10)
    ap.add_argument('--sb-steps', type=int, default=2_000_000)
    ap.add_argument('--wan-runs', type=int, default=30)
    ap.add_argument('--wan-steps', type=int, default=80_000)
    ap.add_argument('--out', default=os.path.join(os.path.dirname(__file__), '..', 'assets', 'ch16-lit-access-control'))
    args = ap.parse_args()
    t0 = time.time()
    P, R = build_model()
    out = {'setting': {'servers': N_SERVERS, 'pays': PAYS.tolist(), 'p_free': P_FREE,
                       'order': 'accept -> busy servers each free w.p. 0.06 -> new uniform priority'}}

    # 1. 精确
    rstar, Qstar = rvi(P, R)
    r_opt, d_opt = policy_rate(P, R, greedy_pi(Qstar))
    r_opt_eps, _ = policy_rate(P, R, greedy_pi(Qstar, eps=0.1))
    allacc = np.zeros((NF, NK, NA)); allacc[:, :, 1] = 1
    r_all, _ = policy_rate(P, R, allacc)
    out['exact'] = {'r_star_rvi': rstar, 'r_star_policy': r_opt, 'r_opt_eps0.1': r_opt_eps,
                    'r_accept_all': r_all, 'opt_thresholds_min_free_to_accept': thresholds(Qstar),
                    'opt_visit_free_ge_9': float(d_opt[9:].sum()), 'opt_visit_free_10': float(d_opt[10].sum())}
    print('exact', json.dumps(out['exact'], ensure_ascii=False))

    # 2. 例 10.2
    t1 = time.time()
    Qsb, Rbar_sb, trace = run_sb(args.sb_runs, args.sb_steps, seed=1610)
    rates = []
    for i in range(args.sb_runs):
        rr, _ = policy_rate(P, R, greedy_pi(Qsb[i]))
        rr_e, _ = policy_rate(P, R, greedy_pi(Qsb[i], eps=0.1))
        rates.append((rr, rr_e, thresholds(Qsb[i])))
    out['sb_example_10_2'] = {
        'runs': args.sb_runs, 'steps': args.sb_steps, 'alpha': 0.01, 'beta': 0.01, 'eps': 0.1,
        'final_Rbar': Rbar_sb.tolist(), 'final_Rbar_mean': float(Rbar_sb.mean()),
        'greedy_rate_exact': [x[0] for x in rates], 'eps_greedy_rate_exact': [x[1] for x in rates],
        'thresholds': [x[2] for x in rates],
        'Q_at_10_free_[priority][reject,accept]': Qsb[:, N_SERVERS].round(3).tolist(),
        'trace_every_20000': [{'t': t, 'Rbar_mean': m, 'Rbar_min': lo, 'Rbar_max': hi, 'reward_rate_mean': w,
                               'Rbar_runs': rr}
                              for (t, m, lo, hi, w, rr) in trace],
        'Rbar_sd_across_runs_pooled_after_1M': float(np.sqrt(np.mean([np.var(rr, ddof=1) for (t, m, lo, hi, w, rr) in trace if t > 1_000_000]))),
        'Rbar_time_mean_after_1M': float(np.mean([m for (t, m, lo, hi, w, rr) in trace if t > 1_000_000])),
        'reward_per_step_after_1M': float(np.mean([w for (t, m, lo, hi, w, rr) in trace if t > 1_000_000])),
        'share_of_Rbar_readings_le_2.31_after_1M': float(np.mean([x <= 2.31 for (t, m, lo, hi, w, rr) in trace if t > 1_000_000 for x in rr])),
        'seconds': time.time() - t1}
    print('sb', out['sb_example_10_2']['final_Rbar_mean'], np.mean([x[0] for x in rates]), time.time() - t1)

    # 3. Wan 等 2021 第 3 节
    t2 = time.time()
    wan = {'runs': args.wan_runs, 'steps': args.wan_steps, 'alpha': 0.025, 'eta': 0.125, 'eps': 0.1, 'window': 2000}
    configs = [('diffq', None, 'Differential Q'),
               ('rvi', (2, 3, 1), 'RVI Q, ref = (2 free, priority 8, accept)'),
               ('rvi', 'mean', 'RVI Q, ref = mean of all Q'),
               ('rvi', (10, 3, 1), 'RVI Q, ref = (10 free, priority 8, accept)')]
    for j, (kind, ref, name) in enumerate(configs):
        Q, pts, curve, se, overall = run_wan(kind, args.wan_runs, args.wan_steps, seed=2021 + j, ref=ref)
        gr = [policy_rate(P, R, greedy_pi(Q[i]))[0] for i in range(args.wan_runs)]
        wan[name] = {'curve_t': pts, 'curve_mean': curve, 'curve_se': se,
                     'mean_reward_over_run': float(overall.mean()),
                     'mean_reward_over_run_se': float(overall.std(ddof=1) / np.sqrt(len(overall))),
                     'final_greedy_rate_exact_mean': float(np.mean(gr)),
                     'final_greedy_rate_exact_min': float(np.min(gr))}
        print(name, wan[name]['mean_reward_over_run'], curve[-1], np.mean(gr), time.time() - t2)
    wan['seconds'] = time.time() - t2
    out['wan2021_section3'] = wan
    out['total_seconds'] = time.time() - t0
    os.makedirs(args.out, exist_ok=True)
    with open(os.path.join(args.out, 'results.json'), 'w', encoding='utf-8') as fh:
        json.dump(out, fh, ensure_ascii=False, indent=1)
    print('total seconds', out['total_seconds'])


if __name__ == '__main__':
    main()
