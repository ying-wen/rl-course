"""A cue, a decision, and a delayed alarm in the course's delivery task.

python demos/door_signal.py --reliability .75
python demos/door_signal.py --option-time
python demos/door_signal.py --export assets/door-signal/reader.json

Normal routes take two physical steps. The option-time comparison adds a wait.
Door conditions are redrawn independently.
Training sees only the cue available at decision time and the chosen reward.
"""
import argparse
import json
import math
import random
from fractions import Fraction
from pathlib import Path
from statistics import mean, stdev

ALARM = (Fraction(1, 10), Fraction(1, 2))  # Wide / narrow, if going straight.
BUDGETS = (0, 8, 32, 128, 512)
SEEDS = 64


def exact(q, remember):
    """Condition on what can be read before the decision. All branches are exact."""
    q = Fraction(q)
    if not 0 <= q <= 1:
        raise ValueError('Cue accuracy must lie in [0, 1].')
    groups = [[Fraction(0) for _ in ALARM] for _ in range(2 if remember else 1)]
    for door in range(2):
        for cue in range(2):
            probability = (q if cue == door else 1 - q) / 2
            groups[cue if remember else 0][door] += probability
    rows = []
    for weights in groups:
        mass = sum(weights)
        alarm = sum(p * danger for p, danger in zip(weights, ALARM)) / mass
        straight = 1 - 4 * alarm
        rows.append(dict(mass=mass, wide=weights[0] / mass, alarm=alarm,
                         straight=straight, best=max(straight, 0)))
    best = sum(row['mass'] * row['best'] for row in rows)
    # Forecast error for the hypothetical choice 'straight' under squared loss.
    brier = sum(row['mass'] * row['alarm'] * (1-row['alarm']) for row in rows)
    return rows, best, brier


def evaluate(estimates, rows):
    """Greedy policy with frozen estimates, scored on the actual door distribution."""
    return sum(float(row['mass'] * row['straight']) for value, row in zip(estimates, rows)
               if value > 0)


def learn(q, remember, seed, rows):
    """Learn the unknown straight-route return. The detour's zero reward is given."""
    world = random.Random(2 * seed)
    behavior = random.Random(2 * seed + 1)
    count = [0] * len(rows)
    reward_sum = [0] * len(rows)
    estimates = [0.] * len(rows)
    earned = 0
    checkpoints = {0: (0., 0.)}
    for t in range(1, max(BUDGETS) + 1):
        # Common potential outcomes across conditions. Only the chosen reward is used.
        door = int(world.random() >= .5)
        cue = door if world.random() < q else 1 - door
        would_alarm = world.random() < float(ALARM[door])
        key = cue if remember else 0
        explore = behavior.random() < .1
        random_straight = behavior.random() < .5
        straight = random_straight if explore else estimates[key] > 0
        reward = 1 - 4 * int(would_alarm) if straight else 0
        earned += reward
        if straight:
            count[key] += 1
            # Integer rewards keep exact ties at zero under every visit order.
            reward_sum[key] += reward
            estimates[key] = reward_sum[key] / count[key]
        if t in BUDGETS:
            checkpoints[t] = (evaluate(estimates, rows), earned / t)
    return checkpoints


def summarize(values):
    return dict(mean=mean(values), se=stdev(values)/math.sqrt(len(values)))


def condition(q, remember):
    rows, best, brier = exact(q, remember)
    runs = [learn(float(q), remember, seed, rows) for seed in range(SEEDS)]
    courses = {}
    for steps in BUDGETS:
        frozen, online = zip(*(r[steps] for r in runs))
        courses[steps] = dict(frozen=summarize(frozen),
                              online=summarize(online) if steps else None)
    return dict(rows=[{k: float(v) for k, v in row.items()} for row in rows],
                best=float(best), brier=float(brier), training=courses)


def compare_option_time():
    """Use the lecture's accurate cue and iid doors. Reward is paid on arrival."""
    rows, reward_per_trip, _ = exact(1, remember=True)
    duration = 2
    straight_reward = sum(row['mass'] * row['straight'] for row in rows)
    rate = reward_per_trip / duration  # Wide: straight. Narrow: detour.
    entrance = [row['best'] - duration * rate for row in rows]
    mean_next = sum(row['mass'] * value for row, value in zip(rows, entrance))
    assert mean_next == 0  # Reference choice: the next iid entrance has mean value zero.

    # Check both primitive Bellman equations even after changing the value origin.
    for shift in (0, 1):
        for row, value in zip(rows, entrance):
            mid = row['best'] - rate + mean_next + shift
            assert value + shift == -rate + mid

    print('固定策略，每原始步的长期奖励率')
    print('  每次直行:', straight_reward / duration)
    print('  宽直窄绕:', rate)
    print('下个路口的期望差分价值取 0；宽、窄路口的值:', *(str(v) for v in entrance))
    print('窄门只执行这一次绕行，到下个路口恢复宽直窄绕')
    scores = []
    for steps in (2, 3):
        score = 0 - steps * rate + mean_next
        scores.append(score)
        print(f'  {steps} 步，奖励和 0，评分 {score}')
    print('  多等一步，本次评分的变化:', scores[1] - scores[0])

    # A permanent change affects the clock on every narrow arrival.
    mean_duration = duration + rows[1]['mass']
    new_rate = reward_per_trip / mean_duration
    print('每逢窄门都多等一步：平均耗时', mean_duration, '，每原始步的新率', new_rate)
    print('  长期奖励率的变化:', new_rate - rate)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--reliability', type=Fraction, help='Cue accuracy (default .75).')
    parser.add_argument('--option-time', action='store_true',
                        help='Recompute the fixed-policy rates and two option durations with an accurate cue.')
    parser.add_argument('--export', type=Path)
    args = parser.parse_args()
    if args.option_time:
        if args.reliability is not None or args.export is not None:
            parser.error('--option-time uses the lecture’s fixed accurate cue and prints its own table.')
        compare_option_time()
        return
    if args.reliability is None:
        args.reliability = Fraction(3, 4)
    if not 0 <= args.reliability <= 1:
        parser.error('Cue accuracy must lie in [0, 1].')
    if args.export:
        # Prior odds and the best route are independent of an unread cue's accuracy.
        data = {'seeds': SEEDS, 'blind': condition(Fraction(1, 2), False), 'observed': {}}
        for tick in range(20, 41):
            data['observed'][tick] = condition(Fraction(tick, 40), True)
        args.export.parent.mkdir(parents=True, exist_ok=True)
        args.export.write_text(json.dumps(data, separators=(',', ':'), allow_nan=False)+'\n')
    else:
        for name, keep in [('unavailable at decision', False), ('remembered', True)]:
            case = condition(args.reliability, keep)
            print(name, 'best reward/trip:', case['best'], 'Brier risk:', case['brier'])
            for budget in BUDGETS:
                row = case['training'][budget]
                print(budget, 'trips; frozen policy:', round(row['frozen']['mean'], 4),
                      'reward/trip while learning:', None if not budget else round(row['online']['mean'], 4))


if __name__ == '__main__':
    main()
