"""Discover and test one reusable delivery skill on a single continuing trajectory.

Run: python3 demos/crl_skill_discovery_trial.py
All variants share a world seed and clock-indexed random numbers. The world
contains five short ordered corridors. The learner observes state identity,
primitive actions, reward, and a marker only on reaching its delivery pad.
"""
import argparse
import csv
import json
import math
import random
from collections import Counter
from dataclasses import dataclass, field
from pathlib import Path
from statistics import mean, stdev

import numpy as np


ARMS = 5
DEPTH = 3
PER_ARM = DEPTH + 1
STATES = 1 + ARMS * PER_ARM
TRIAL_CAP = 24
WARM = 256
PERIOD = 512
TRAIN = 64
WINDOW = 128
DEFAULT_T = 8192
PRIMARY_GROUPS = ("ranked", "uniform", "atomic", "reader_off", "informed")
GROUPS = PRIMARY_GROUPS + ("ranked_eps", "reader_off_eps")
ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "assets/crl-skill-discovery-trial"


class World:
    def __init__(self, seed, steps):
        rng = random.Random(100000 + seed)
        self.markers = rng.sample(range(ARMS), ARMS)
        self.payoff = rng.sample([1., 2., 3., 4., 6.], ARMS)
        self.fast_action = [rng.randrange(2) for _ in range(STATES)]
        self.uniforms = np.random.default_rng(200000 + seed).random((steps, 5))
        self.state = 0

    def step(self, action, t):
        state = self.state
        if state == 0:
            self.state = 1 + action * PER_ARM
            return self.state, 0., None
        arm, stage = divmod(state - 1, PER_ARM)
        if stage == DEPTH:
            self.state = 0                      # The conveyor trip takes a real step.
            return 0, 0., None
        p = .9 if action == self.fast_action[state] else .3
        if self.uniforms[t, 0] < p:
            self.state = state + 1
            if stage + 1 == DEPTH:
                return self.state, self.payoff[arm], self.markers[arm]
        return self.state, 0., None


def action_count(state):
    if state == 0:
        return ARMS
    return 1 if (state - 1) % PER_ARM == DEPTH else 2


def pick(values, u):
    maximum = max(values)
    ties = [i for i, value in enumerate(values) if value == maximum]
    return ties[min(int(u * len(ties)), len(ties) - 1)]


@dataclass
class ObservedMarker:
    first_action: int
    terminal: int
    times: int = 0
    reward: float = 0.
    duration: float = 0.


@dataclass
class Skill:
    goal: int
    first_action: int
    # The initiation set is the depot. At junctions these two counts estimate
    # the probability of progress before a stall under the chosen command.
    visits: dict = field(default_factory=dict)
    advances: dict = field(default_factory=dict)
    policy: dict = field(default_factory=dict)
    frozen: bool = False
    count: int = 0
    reward_sum: float = 0.
    time_sum: float = 0.
    ends: Counter = field(default_factory=Counter)

    def freeze(self):
        for state, counts in self.visits.items():
            probs = [(self.advances[state][a] + 1) / (n + 2) for a, n in enumerate(counts)]
            self.policy[state] = probs.index(max(probs))
        self.frozen = True

    def command(self, s, u, v):
        if s == 0:
            return self.first_action
        if self.frozen:
            return self.policy.get(s, 0)
        counts = self.visits.setdefault(s, [0, 0])
        advances = self.advances.setdefault(s, [0, 0])
        if u < .25:
            return int(2 * v)
        return pick([(k + 1) / (n + 2) for k, n in zip(advances, counts)], v)

    def score(self, q, rate):
        """A one-step SMDP lookahead in units of external reward."""
        assert self.count > 0
        continuation = sum(count * (max(q[s]) if s else 0.) for s, count in self.ends.items())
        return (self.reward_sum - rate * self.time_sum + continuation) / self.count


def run(seed, group, limit, trace=None):
    world = World(seed, limit)
    q = [[0.] * action_count(s) for s in range(STATES)]
    seen = {}
    incumbent, candidate, acting = None, None, None
    purpose = None
    skill_time, skill_reward = 0, 0.
    trip_start, trip_action = 0, 0
    rate, total = 0., 0.
    c = Counter()
    chosen = Counter()
    checkpoints = []
    for t in range(limit):
        s = world.state
        _, ux, ua, urank, utie = world.uniforms[t]
        age = (t - WARM) % PERIOD
        enabled = t >= WARM and group != "atomic"
        if enabled and age == 0 and seen:
            available = sorted(m for m in seen if incumbent is None or m != incumbent.goal)
            if available:
                # Both selectors calculate these priorities. The uniform group
                # disregards their order. The proposal takes no simulator calls.
                priorities = []
                for m in available:
                    record = seen[m]
                    priorities.append((record.reward - rate * record.duration) / record.times
                                      + max(q[record.terminal]))
                if group == "informed":
                    # Additional design information: the rank of the delivery
                    # payoff, but no shortcut to the internal motion policy.
                    priorities = [world.payoff[world.markers.index(m)] for m in available]
                ix = int(urank * len(available)) if group == "uniform" else pick(priorities, urank)
                g = available[ix]
                candidate = Skill(g, seen[g].first_action)
                c["proposals"] += 1
                if trace is not None and "first_proposal" not in trace:
                    trace["first_proposal"] = dict(t=t, candidates=available, scores=priorities,
                                                   selected=g, first_action=candidate.first_action)
                c["proposal_scores"] += len(available)
        if enabled and age == TRAIN and candidate:
            candidate.freeze()
        if enabled and age == WINDOW and candidate:
            if candidate.count:
                replace = incumbent is None
                if incumbent:
                    c["selection_model_reads"] += 2
                    replace = candidate.score(q, rate) > incumbent.score(q, rate)
                if replace:
                    incumbent = candidate
                    if trace is not None and "first_retention" not in trace:
                        trace["first_retention"] = dict(t=t, goal=incumbent.goal, commands=incumbent.policy.copy(),
                                                        completed=incumbent.count,
                                                        reward=incumbent.reward_sum/incumbent.count,
                                                        duration=incumbent.time_sum/incumbent.count,
                                                        end_counts=dict(incumbent.ends))
                    c["replacements"] += 1
            candidate = None

        if s == 0:
            trip_start = t
            # A skill can already be running when a phase starts. Every
            # execution ends on a marker or timeout; initiation is depot-only.
            assert acting is None
            enough = (age < TRAIN and TRAIN - age >= TRIAL_CAP) or (
                TRAIN <= age < WINDOW and WINDOW - age >= TRIAL_CAP)
            if enabled and candidate and enough:
                acting = candidate
                purpose = "estimate" if candidate.frozen else "train"
            elif t >= WARM and incumbent is not None:
                c["eligible_calls"] += 1
                c["behavior_model_reads"] += 1
                score = incumbent.score(q, rate)
                if group not in ("reader_off", "reader_off_eps") and ux >= .1 and score > max(q[0]):
                    acting, purpose = incumbent, "deploy"
                    c["model_selected_calls"] += 1
                    primitive = pick(q[0], utie)
                    c["model_changed_first_action"] += int(incumbent.first_action != primitive)
                    if trace is not None and "first_behavior_read" not in trace:
                        trace["first_behavior_read"] = dict(t=t, goal=incumbent.goal, rate=rate,
                            model_count=incumbent.count, expected_reward=incumbent.reward_sum/incumbent.count,
                            expected_duration=incumbent.time_sum/incumbent.count, end_counts=dict(incumbent.ends),
                            expected_continuation=sum(n * (max(q[z]) if z else 0.) for z,n in incumbent.ends.items())/incumbent.count,
                            primitive_scores=q[0].copy(), primitive_command=primitive,
                            skill_score=score, skill_command=incumbent.first_action)
            if acting:
                skill_time, skill_reward = 0, 0.
                chosen[purpose] += 1
        if acting is None:
            action = (int(ua * len(q[s])) if t < WARM or ux < .1 else pick(q[s], utie))
        else:
            action = acting.command(s, ux, ua)
        # Follow-up intervention after the five planned contrasts: retain
        # the primitive controller's exploration probability inside the option.
        # The completion model observes that same stochastic policy in trials.
        if group in ("ranked_eps", "reader_off_eps") and purpose in ("estimate", "deploy") and s and ux < .1:
            action = int(ua * len(q[s]))
        if purpose == "deploy" and s != 0:
            primitive_greedy = pick(q[s], utie)
            primitive_sampled = int(ua * len(q[s])) if ux < .1 else primitive_greedy
            c["different_inner_action"] += int(action != primitive_greedy)
            c["different_sampled_inner_action"] += int(action != primitive_sampled)
            if trace is not None and "changed_internal_command" not in trace and action != primitive_sampled:
                trace["changed_internal_command"] = dict(t=t,goal=acting.goal,state=s,skill_command=action,
                                                          primitive_greedy=primitive_greedy,primitive_sampled=primitive_sampled)
        if s == 0:
            trip_action = action
        successor, reward, marker = world.step(action, t)
        if t >= WARM and age < WINDOW:
            c["window_reward"] += reward
        else:
            c["outside_window_reward"] += reward
        if marker is not None:
            if trace is not None and "first_encounter" not in trace:
                trace["first_encounter"] = dict(t=t, marker=marker, initial_command=trip_action,
                                                end=successor, duration=t-trip_start+1, reward=reward)
            c["deliveries"] += 1
            record = seen.setdefault(marker, ObservedMarker(trip_action, successor))
            assert record.first_action == trip_action
            record.times += 1
            record.reward += reward
            record.duration += t - trip_start + 1

        # The cycle reference h(depot)=0 keeps action scores comparable.
        # Positive-recurrent tours close at the same depot. The empirical
        # reward rate is the current opportunity-cost estimate, shared by both
        # primitive and temporally extended action evaluations.
        old = q[s][action]
        continuation = max(q[successor]) if successor else 0.
        q[s][action] += .15 * (reward - rate + continuation - old)
        c["primitive_updates"] += 1
        if acting:
            skill_time += 1
            skill_reward += reward
            c[purpose + "_steps"] += 1
            c[purpose + "_reward"] += reward
            if purpose == "train" and s:
                acting.visits[s][action] += 1
                acting.advances[s][action] += int(successor != s)
            if marker == acting.goal or skill_time == TRIAL_CAP:
                c[purpose + "_ends"] += 1
                c[purpose + "_hits"] += int(marker == acting.goal)
                if (trace is not None and purpose == "deploy" and "first_behavior_read" in trace
                        and t-skill_time+1 == trace["first_behavior_read"]["t"]):
                    trace["outcome_of_first_behavior_read"] = dict(t=t, goal=acting.goal, reward=skill_reward,
                                                              duration=skill_time, end=successor)
                if purpose in ("estimate", "deploy"):
                    acting.count += 1
                    acting.reward_sum += skill_reward
                    acting.time_sum += skill_time
                    acting.ends[successor] += 1
                    c["completed_model_updates"] += 1
                acting, purpose = None, None
        total += reward
        rate = total / (t + 1)
        if (t+1) % PERIOD == 0 or t+1 == limit:
            checkpoints.append((t+1, total))
    assert c["primitive_updates"] == limit
    assert c["window_reward"] + c["outside_window_reward"] == total
    if group == "atomic":
        assert not c["proposals"] and not c["model_selected_calls"]
    if group in ("reader_off", "reader_off_eps"):
        assert not c["model_selected_calls"]
    blocks = math.ceil((limit - WARM) / PERIOD)
    assert c["train_steps"] + c["estimate_steps"] <= WINDOW * blocks
    assert max((c["proposal_scores"], 0)) <= ARMS * blocks
    return dict(seed=seed, group=group, total=total, rate=rate, discovered=len(seen),
                **{k:c[k] for k in ("proposals","proposal_scores","replacements","primitive_updates",
                "train_steps","estimate_steps","deploy_steps","estimate_ends","estimate_hits","deploy_ends",
                "deploy_hits","eligible_calls","behavior_model_reads","model_selected_calls",
                "selection_model_reads","completed_model_updates","deliveries","model_changed_first_action","different_inner_action",
                "different_sampled_inner_action","train_reward","estimate_reward","deploy_reward","window_reward","outside_window_reward")}), checkpoints


def write_csv(path, rows):
    with path.open("w", newline="") as f:
        out = csv.DictWriter(f, fieldnames=list(rows[0]))
        out.writeheader()
        out.writerows(rows)


def summarize(rows, group, reference, key):
    a = {r["seed"]:r[key] for r in rows if r["group"] == group}
    b = {r["seed"]:r[key] for r in rows if r["group"] == reference}
    differences = [a[i] - b[i] for i in sorted(a)]
    se = stdev(differences) / math.sqrt(len(differences))
    # For the default 64 pairs t(.975; 63) = 1.99834054.
    # Use the regularized-beta identity for other sample sizes as well.
    from mpmath import betainc
    df = len(differences) - 1
    low, high = 0., 16.
    for _ in range(42):
        mid = (high + low) / 2
        tail = .5 * betainc(df/2, .5, 0, df/(df+mid*mid), regularized=True)
        if tail > .025:
            low = mid
        else:
            high = mid
    radius = (low+high)/2 * se
    estimate = mean(differences)
    return dict(mean=estimate, se=se, lo=estimate-radius, hi=estimate+radius)


def figure(curves, rows, output):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    plt.rcParams.update({"font.family":["Songti SC","DejaVu Sans"],"axes.unicode_minus":False})
    fig, (left, right) = plt.subplots(1, 2, figsize=(10, 3.8), layout="constrained")
    colors = {"ranked":"#16736f","uniform":"#c86e36","atomic":"#323e54","reader_off":"#8c628f"}
    labels = {"ranked":"按预期收益选候选","uniform":"均匀选候选","atomic":"仅原子动作","reader_off":"断开规划读出"}
    for group in colors:
        ticks = sorted({r["step"] for r in curves})
        vals = [mean(r["reward"]/step for r in curves if r["step"]==step and r["group"]==group) for step in ticks]
        left.plot(ticks, vals, label=labels[group], color=colors[group], lw=2)
    left.set(title="从第一次行动计入主奖励", xlabel="原始交互步", ylabel="累计奖励 / 已用步数")
    left.legend(frameon=False, fontsize=9)
    compares = [("ranked","uniform"),("ranked","atomic"),("ranked","reader_off"),("ranked_eps","reader_off_eps")]
    for y, (learner, ref) in enumerate(compares):
        diff = summarize(rows,learner,ref,"rate")
        right.errorbar(diff["mean"], y, xerr=diff["hi"]-diff["mean"], fmt="o", color=colors.get(ref,"#3e7991"), capsize=4)
    right.axvline(0,color="#777",lw=.8)
    right.set(yticks=list(range(4)),yticklabels=["减均匀选择","减仅原子动作","减断开规划读出","同探索率：读出减断开"],
              title="候选排序组的配对收益差",xlabel="奖励 / 原始步，95% 配对区间")
    for ax in (left,right):
        ax.spines[["top","right"]].set_visible(False)
        ax.grid(axis="x" if ax is right else "y", alpha=.15)
    for ext in ("png","pdf"):
        fig.savefig(output/f"discovery-comparison.{ext}",dpi=170)
    plt.close(fig)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seeds",type=int,default=64)
    parser.add_argument("--steps",type=int,default=DEFAULT_T)
    parser.add_argument("--output",type=Path,default=OUTPUT)
    args=parser.parse_args()
    if args.seeds < 2 or args.steps <= WARM:
        parser.error("Use at least two seeds and more than 256 steps.")
    args.output.mkdir(parents=True,exist_ok=True)
    rows, curves, events = [], [], {}
    for seed in range(args.seeds):
        for group in GROUPS:
            row, trace=run(seed,group,args.steps,events if (seed==0 and group=="ranked") else None)
            rows.append(row)
            curves.extend(dict(seed=seed,group=group,step=s,reward=r) for s,r in trace)
    (args.output/"seed-0-events.json").write_text(json.dumps(events,indent=2)+"\n")
    write_csv(args.output/"runs.csv",rows)
    write_csv(args.output/"curves.csv",curves)
    summary=dict(seeds=args.seeds,steps=args.steps,primary_threshold=.01,
                 groups={g:{k:mean(r[k] for r in rows if r["group"]==g)
                            for k in rows[0] if k not in ("seed","group")} for g in GROUPS},
                 paired={g:summarize(rows,"ranked",g,"rate") for g in PRIMARY_GROUPS if g!="ranked"},
                 followup_exploration_matched=summarize(rows,"ranked_eps","reader_off_eps","rate"))
    (args.output/"summary.json").write_text(json.dumps(summary,indent=2)+"\n")
    figure(curves,rows,args.output)
    print(json.dumps(summary["paired"],indent=2))


if __name__ == "__main__":
    main()
