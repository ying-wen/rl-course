# -*- coding: utf-8 -*-
"""第 21 章文献原型：Sutton、Precup 与 Singh (1999) 的四房间。

出处：R. S. Sutton, D. Precup, S. Singh. Between MDPs and semi-MDPs: A framework
for temporal abstraction in reinforcement learning. Artificial Intelligence 112
(1999) 181-211。图 4（同步值迭代，O=A 对 O=H，目标 G1）、图 6（SMDP Q 学习）。

论文设定（按文献核对报告）：每格一个状态；上下左右四个动作，以 2/3 概率按意图
移动，否则各以 1/9 移向另外三个方向，撞墙原地不动；每个房间 2 个通往走廊的
option，共 8 个（H）；option 策略沿最短路走向目标走廊、避开另一个走廊，房间内
beta=0，房间外 beta=1；G1 在走廊上，G2 在房间中部；gamma=0.9。

本课自定（论文图中位置按图重画，网格尺寸待核）：
- 104 格的 13x13 布局；G1 取东侧走廊，G2 取右下房间中部一格；
- 进入目标得 +1，其余转移为 0，目标为终止状态；
- “准确”分两档记：|V_k(s) - V*(s)| 不超过 V*(s) 的 10% 或 1%，V* 为同一 option 集下
  迭代到收敛的值（论文按图示判读，没有数值门槛）；
- option 内部策略：在本房间内对“到目标走廊得 1、落到另一走廊得 0”做
  gamma=0.99 的值迭代，取贪心动作（即在随机滑动下走近路并避开另一走廊）。
- 图 6 的幕数论文核对报告未给出，本课每种组合跑 RUNS 次独立运行、每次 EPISODES 幕。

只用 numpy。用法：
    python3 demos/ch21_lit_fourrooms.py [运行次数，默认 30] [幕数，默认 1000]
输出写 assets/ch21-lit-fourrooms/results.json。
"""
import json, os, sys, time
import numpy as np

LAYOUT = [
    "#############",
    "#.....#.....#",
    "#.....#.....#",
    "#...........#",
    "#.....#.....#",
    "#.....#.....#",
    "##.####.....#",
    "#.....###.###",
    "#.....#.....#",
    "#.....#.....#",
    "#...........#",
    "#.....#.....#",
    "#############",
]
H, W = len(LAYOUT), len(LAYOUT[0])
CELLS = [(r, c) for r in range(H) for c in range(W) if LAYOUT[r][c] == "."]
IDX = {rc: i for i, rc in enumerate(CELLS)}
N = len(CELLS)
MOVES = [(-1, 0), (1, 0), (0, -1), (0, 1)]          # 上 下 左 右
GAMMA = 0.9

HALL = {"N": (3, 6), "W": (6, 2), "E": (7, 9), "S": (10, 6)}
# 房间：左上 TL、右上 TR、左下 BL、右下 BR；每个房间的两个走廊
ROOMS = {
    "TL": (lambda r, c: 1 <= r <= 5 and 1 <= c <= 5, ("N", "W")),
    "TR": (lambda r, c: 1 <= r <= 6 and 7 <= c <= 11, ("N", "E")),
    "BL": (lambda r, c: 7 <= r <= 11 and 1 <= c <= 5, ("W", "S")),
    "BR": (lambda r, c: 8 <= r <= 11 and 7 <= c <= 11, ("E", "S")),
}
G1 = IDX[HALL["E"]]
G2 = IDX[(9, 9)]
START = IDX[(1, 1)]


def det_next(i, a):
    r, c = CELLS[i]
    dr, dc = MOVES[a]
    rc = (r + dr, c + dc)
    return IDX.get(rc, i)


NEXT = np.array([[det_next(i, a) for a in range(4)] for i in range(N)])
# 随机滑动：意图 2/3，其余三个方向各 1/9
P = np.zeros((N, 4, N))
for i in range(N):
    for a in range(4):
        for b in range(4):
            P[i, a, NEXT[i, b]] += 2 / 3 if b == a else 1 / 9


def room_cells(name):
    f = ROOMS[name][0]
    return [IDX[rc] for rc in CELLS if f(*rc)]


def build_options():
    """8 个走廊 option：(房间, 目标走廊, 另一走廊, 起始集, 内部策略)。"""
    opts = []
    for name, (_, halls) in ROOMS.items():
        room = room_cells(name)
        for tgt in halls:
            other = [h for h in halls if h != tgt][0]
            t, o = IDX[HALL[tgt]], IDX[HALL[other]]
            inside = set(room)
            # 内部策略：到 t 得 1，到 o 或房间外得 0，gamma=0.99
            v = np.zeros(N)
            for _ in range(500):
                q = np.einsum("ian,n->ia", P, v)
                vn = np.zeros(N)
                for s in inside:
                    vn[s] = q[s].max()
                vn[t] = 1.0
                vn[o] = 0.0
                v = 0.99 * vn
                v[t] = 1.0
            q = np.einsum("ian,n->ia", P, v)
            pol = {s: int(np.argmax(q[s])) for s in list(inside) + [o]}
            init = sorted(inside | {o})
            opts.append(dict(room=name, tgt=t, other=o, inside=inside, init=init, pol=pol))
    return opts


OPTS = build_options()


def option_model(opt, goal):
    """折扣模型：R_o(s) 与 P_o(x|s)（含 gamma^k），s 取起始集。目标为终止。"""
    inside = sorted(s for s in opt["inside"] if s != goal)
    pos = {s: k for k, s in enumerate(inside)}
    m = len(inside)
    # 房间内继续：线性方程 (I - gamma*Pin) X = 立即项
    A = np.eye(m)
    rvec = np.zeros(m)
    T = np.zeros((m, N))          # 终止在房间外 x 的折扣概率
    for s in inside:
        a = opt["pol"][s]
        for x in range(N):
            p = P[s, a, x]
            if p == 0:
                continue
            if x == goal:
                rvec[pos[s]] += p * 1.0
            elif x in pos:
                A[pos[s], pos[x]] -= GAMMA * p
            else:
                T[pos[s], x] += GAMMA * p
    Rin = np.linalg.solve(A, rvec)
    Pin = np.linalg.solve(A, T)
    R, Pm = {}, {}
    for s in opt["init"]:
        if s == goal:
            continue
        if s in pos:
            R[s], Pm[s] = Rin[pos[s]], Pin[pos[s]]
        else:                      # 从另一走廊出发：先走一步
            a = opt["pol"][s]
            r, pv = 0.0, np.zeros(N)
            for x in range(N):
                p = P[s, a, x]
                if p == 0:
                    continue
                if x == goal:
                    r += p
                elif x in pos:
                    r += GAMMA * p * Rin[pos[x]]
                    pv += GAMMA * p * Pin[pos[x]]
                else:
                    pv[x] += GAMMA * p
            R[s], Pm[s] = r, pv
    return R, Pm


def models(goal, use_a, use_h):
    """每个状态的可用选择列表：(奖励, 折扣转移向量)。"""
    ch = [[] for _ in range(N)]
    if use_a:
        for s in range(N):
            if s == goal:
                continue
            for a in range(4):
                pv = GAMMA * P[s, a].copy()
                r = P[s, a, goal]
                pv[goal] = 0.0
                ch[s].append((r, pv))
    if use_h:
        for opt in OPTS:
            R, Pm = option_model(opt, goal)
            for s, r in R.items():
                pv = Pm[s].copy()
                pv[goal] = 0.0
                ch[s].append((r, pv))
    return ch


def value_iteration(ch, iters):
    V = np.zeros(N)
    hist = [V.copy()]
    for _ in range(iters):
        Vn = np.zeros(N)
        for s in range(N):
            if ch[s]:
                Vn[s] = max(r + pv @ V for r, pv in ch[s])
        V = Vn
        hist.append(V.copy())
    return hist


def planning(goal, use_a, use_h, iters=40):
    ch = models(goal, use_a, use_h)
    hist = value_iteration(ch, 400)
    Vstar = hist[-1]
    acc, acc10, nz = [], [], []
    for k in range(iters + 1):
        V = hist[k]
        err = [abs(V[s] - Vstar[s]) / Vstar[s] for s in range(N) if s != goal]
        acc.append(int(sum(e <= 0.01 for e in err)))
        acc10.append(int(sum(e <= 0.10 for e in err)))
        nz.append(int(sum(1 for s in range(N) if s != goal and V[s] > 1e-12)))
    first_all = next((k for k, a in enumerate(acc) if a == N - 1), None)
    first_all10 = next((k for k, a in enumerate(acc10) if a == N - 1), None)
    return dict(within1pct=acc, within10pct=acc10, nonzero=nz, iters_all_within1pct=first_all,
                iters_all_within10pct=first_all10,
                v_start=float(Vstar[START]), vstar=[float(x) for x in Vstar])


# ---------------- 图 6：SMDP Q 学习 ----------------
def choice_list(goal, use_a, use_h):
    """每个状态可选的 (类型, 编号)。"""
    ch = [[] for _ in range(N)]
    for s in range(N):
        if use_a:
            ch[s] += [("a", a) for a in range(4)]
        if use_h:
            ch[s] += [("o", k) for k, o in enumerate(OPTS) if s in o["init"]]
    return ch


def step(rng, s, a):
    u = rng.random()
    if u < 2 / 3:
        b = a
    else:
        b = [x for x in range(4) if x != a][int((u - 2 / 3) * 9) % 3]
    return int(NEXT[s, b])


def run_option(rng, s, k, goal):
    opt = OPTS[k]
    ret, disc, n = 0.0, 1.0, 0
    first = True
    while True:
        a = opt["pol"].get(s, int(rng.integers(4)))
        s2 = step(rng, s, a)
        n += 1
        if s2 == goal:
            return ret + disc, s2, n, disc * GAMMA
        disc *= GAMMA
        s = s2
        if s not in opt["inside"]:
            return ret, s, n, disc


def smdp_q(rng, goal, use_a, use_h, alpha, episodes, eps=0.1, cap=20000):
    ch = choice_list(goal, use_a, use_h)
    Q = [np.zeros(len(c)) for c in ch]
    steps = np.zeros(episodes)
    for ep in range(episodes):
        s, n_ep = START, 0
        while s != goal and n_ep < cap:
            q = Q[s]
            if rng.random() < eps:
                j = int(rng.integers(len(q)))
            else:
                m = q.max()
                js = np.flatnonzero(q == m)
                j = int(js[rng.integers(len(js))])
            kind, x = ch[s][j]
            if kind == "a":
                s2 = step(rng, s, x)
                n = 1
                r = 1.0 if s2 == goal else 0.0
                disc = GAMMA
            else:
                r, s2, n, disc = run_option(rng, s, x, goal)
            target = r + (0.0 if s2 == goal else disc * Q[s2].max())
            q[j] += alpha * (target - q[j])
            s = s2
            n_ep += n
        steps[ep] = n_ep
    return steps


def main():
    runs = int(sys.argv[1]) if len(sys.argv) > 1 else 30
    episodes = int(sys.argv[2]) if len(sys.argv) > 2 else 1000
    t0 = time.time()
    out = dict(n_cells=N, layout=LAYOUT, start=CELLS[START], G1=CELLS[G1], G2=CELLS[G2],
               gamma=GAMMA, runs=runs, episodes=episodes)
    plan = {}
    for gname, g in (("G1", G1), ("G2", G2)):
        for oname, ua, uh in (("A", 1, 0), ("H", 0, 1), ("AuH", 1, 1)):
            res = planning(g, ua, uh)
            res.pop("vstar")
            plan[f"{gname}_{oname}"] = res
    out["planning"] = plan
    alphas = {("G1", "A"): 1 / 8, ("G1", "H"): 1 / 16, ("G1", "AuH"): 1 / 8,
              ("G2", "A"): 1 / 8, ("G2", "H"): 1 / 8, ("G2", "AuH"): 1 / 4}
    learn = {}
    rng = np.random.default_rng(20261119)
    for gname, g in (("G1", G1), ("G2", G2)):
        for oname, ua, uh in (("A", 1, 0), ("H", 0, 1), ("AuH", 1, 1)):
            al = alphas[(gname, oname)]
            S = np.array([smdp_q(rng, g, ua, uh, al, episodes) for _ in range(runs)])
            mean = S.mean(0)
            se = S.std(0, ddof=1) / np.sqrt(runs)
            marks = [1, 10, 100, episodes]
            learn[f"{gname}_{oname}"] = dict(
                alpha=al,
                steps_at={str(m): [float(mean[m - 1]), float(se[m - 1])] for m in marks},
                last100=[float(S[:, -100:].mean()), float(S[:, -100:].mean(1).std(ddof=1) / np.sqrt(runs))],
                curve_log=[[int(e), float(mean[e - 1])] for e in sorted(set(
                    np.unique(np.round(np.logspace(0, np.log10(episodes), 25)).astype(int))))],
            )
            print(gname, oname, learn[f"{gname}_{oname}"]["steps_at"], f"{time.time()-t0:.1f}s", flush=True)
    out["learning"] = learn
    out["seconds"] = round(time.time() - t0, 1)
    d = os.path.join(os.path.dirname(__file__), "..", "assets", "ch21-lit-fourrooms")
    os.makedirs(d, exist_ok=True)
    with open(os.path.join(d, "results.json"), "w") as f:
        json.dump(out, f, ensure_ascii=False, indent=1)
    for k, v in plan.items():
        print(k, "all<=10% at", v["iters_all_within10pct"], "all<=1% at", v["iters_all_within1pct"],
              "<=10%", v["within10pct"][:6], "nz", v["nonzero"][:6], "V(start)", round(v["v_start"], 4))
    print("seconds", out["seconds"])


if __name__ == "__main__":
    main()
