"""第 21 章四区仓库：各档选项相对只用原始动作的 lifetime 奖励率差（差值点图）。

11-21 请求 r1121-133138（p1790）：把六根同长横条换成差值点图。
数据：assets/crl-ladder-world/runs/formal-ch21.json（49 个种子，200 万步），
与 crl_ladder_power.py 同一种配对 t 区间。只读已有运行结果，不重新跑实验。
输出：assets/crl-ladder-world/fig/ch21-ladder-dots.pdf，并打印各点的数值。
"""
import json
import math
import os
import sys

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from plot_fonts import use_course_fonts, no_leading_zero, CJK_FAMILY  # noqa: E402
from crl_ladder_power import t975  # noqa: E402

ROOT = os.path.dirname(HERE)
RUN = os.path.join(ROOT, "assets", "crl-ladder-world", "runs", "formal-ch21.json")
OUT = os.path.join(ROOT, "assets", "crl-ladder-world", "fig", "ch21-ladder-dots.pdf")

TIERS = [("given", "给定 8 个走廊选项"), ("learned-sub", "学到的子目标"),
         ("learned-eig2", "本征选项 2 个"), ("learned-eig4", "本征选项 4 个"),
         ("learned-eig8", "本征选项 8 个")]
CONDS = [("h0.001", "规律约每 1000 步一换", "#1f7a7a"), ("h0.01", "约每 100 步一换", "#b8860b")]


def load():
    with open(RUN, encoding="utf-8") as f:
        d = json.load(f)
    out = {}
    for r in d["results"]:
        out[(r["name"], r["seed"])] = r["rate"]
    return out


def paired(data, a, b):
    seeds = sorted({s for (n, s) in data if n == a} & {s for (n, s) in data if n == b})
    x = np.array([data[(a, s)] - data[(b, s)] for s in seeds])
    n = len(x)
    half = t975(n - 1) * x.std(ddof=1) / math.sqrt(n)
    return float(x.mean()), float(half), n


def main():
    data = load()
    rows = []
    for c, _, _ in CONDS:
        for t, _ in TIERS:
            m, h, n = paired(data, f"ch21/{c}/{t}", f"ch21/{c}/none")
            rows.append((c, t, m, h, n))
            print(f"{c:7s} {t:13s} {m:+.5f} ± {h:.5f}  n={n}")

    use_course_fonts()
    fig, ax = plt.subplots(figsize=(4.6, 2.5))
    ys = np.arange(len(TIERS))[::-1]
    for k, (c, lab, col) in enumerate(CONDS):
        off = .14 if k == 0 else -.14
        for i, (t, _) in enumerate(TIERS):
            _, _, m, h, _ = next(r for r in rows if r[0] == c and r[1] == t)
            ax.errorbar(m, ys[i] + off, xerr=h, fmt="o", ms=4, color=col, capsize=2, lw=1.1,
                        label=lab if i == 0 else None)
    ax.axvline(0, color="#555555", lw=.8)
    ax.axvspan(-.002, .002, color="#e6e6e6", lw=0, zorder=0)
    ax.set_yticks(ys)
    ax.set_yticklabels([lab for _, lab in TIERS], fontsize=8)
    ax.set_xlim(-.003, .003)
    ax.set_xticks([-.003, -.002, -.001, 0, .001, .002, .003])
    ax.xaxis.set_major_formatter(FuncFormatter(no_leading_zero))
    ax.tick_params(axis="x", labelsize=8)
    ax.set_xlabel("lifetime 奖励率差（减去只用原始动作），每步", fontsize=8, fontfamily=CJK_FAMILY)
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    ax.legend(fontsize=7, frameon=False, loc="lower left", bbox_to_anchor=(0, 1.0), ncol=2,
              handletextpad=.3, columnspacing=1.0)
    fig.tight_layout(pad=.3)
    fig.savefig(OUT)
    print("saved", OUT)


if __name__ == "__main__":
    main()
