#!/usr/bin/env python3
"""Small, reproducible calculations for CRL teaching; not a full research agent.
Run from any directory. Dependencies: numpy; --figures also needs matplotlib.
"""
from pathlib import Path
import argparse, csv, json, math
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'assets/crl-v8'
OUT.mkdir(parents=True,exist_ok=True)
checks=[]
def check(name, condition, **details):
    assert condition, (name,details)
    checks.append(dict(name=name,passed=True,**details))
def csvsave(name, rows):
    with (OUT/name).open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def rates():
    P=np.roll(np.eye(3),1,axis=1);r=np.array([0.,0.,1.]);rho=1/3
    rows=[]
    for g in [.1,.3,.5,.7,.9,.95,.99,.999]:
        v=np.linalg.solve(np.eye(3)-g*P,r)
        vc=np.linalg.solve(np.eye(3)-g*P,r-rho)
        check('reward_centering_'+str(g),np.max(abs(v-vc-rho/(1-g)))<1e-9)
        rows.append(dict(gamma=g,valueA=v[0],centeredA=vc[0],centeredB=vc[1],centeredC=vc[2]))
    check('abelian_relative_limit',np.max(abs(np.array([rows[-1]['centeredA'],rows[-1]['centeredB'],rows[-1]['centeredC']])-np.array([-1/3,0,1/3])))<.001)
    csvsave('discount-centering.csv',rows)
    # Average-reward control: lazy 3-cycle vs .4 local reward at A.
    Pc=.2*np.eye(3)+.8*P;rc=.8*np.array([0.,0.,2.])
    h=np.zeros(3);history=[]
    for k in range(150):
        route=rc+Pc@h;local=.4+h[0]
        f=route.copy();f[0]=max(route[0],local)
        newrho=f[0];h=f-f[0]
        history.append(dict(iteration=k+1,rho=newrho,hB=h[1],hC=h[2]))
    check('relative_value_iteration',abs(newrho-8/15)<1e-9 and np.max(abs(h-[0,2/3,4/3]))<1e-8)
    csvsave('relative-value-iteration.csv',history)
    # A fixed low discount does not optimize the rate: .4 each step vs 0,0,2 cycle.
    g=.3;short=.4/(1-g);long=2*g*g/(1-g**3)
    check('discount_can_reverse_rate',short>long and 2/3>.4,discount_local=short,discount_cycle=long)
    return rows,history

def grid_sr_and_option():
    rng=np.random.default_rng(141908)
    states=[(x,y) for y in range(5) for x in range(9) if x!=4 or y==2]
    idx={s:i for i,s in enumerate(states)};n=len(states)
    actions=[(1,0),(0,1),(-1,0),(0,-1)]
    nxt=np.zeros((n,4),dtype=int)
    for i,(x,y) in enumerate(states):
        for a,(dx,dy) in enumerate(actions):nxt[i,a]=idx.get((x+dx,y+dy),i)
    P=np.zeros((n,n))
    for i in range(n):
        for a in range(4):P[i,nxt[i,a]]+=.25
    check('grid_uniform_reversible',np.max(abs(P-P.T))<1e-14)
    gamma=.9;exact=np.linalg.solve(np.eye(n)-gamma*P,np.eye(n))
    M=np.zeros((n,n));visits=np.zeros(n);s=idx[(0,0)];eye=np.eye(n);curve=[]
    for t in range(1,200001):
        sp=nxt[s,rng.integers(4)];visits[s]+=1
        alpha=.8/visits[s]**.55
        M[s]+=alpha*(eye[s]+gamma*M[sp]-M[s]);s=sp
        if t%5000==0:curve.append(dict(transitions=t,relative_error=float(np.linalg.norm(M-exact)/np.linalg.norm(exact))))
    check('sr_exact_bellman',np.max(abs(exact-eye-gamma*P@exact))<1e-12)
    check('sr_all_states_visited',min(visits)>0,min_visits=int(min(visits)))
    vals,vecs=np.linalg.eig(M);order=np.argsort(-vals.real)
    j=order[1];check('learned_nonconstant_eigenvector_real',abs(vals[j].imag)<1e-8)
    e=vecs[:,j].real;e=e/np.linalg.norm(e)
    if e[idx[(8,4)]]<e[idx[(0,0)]]:e=-e
    # This Q-learning uses the learned eigenvector, not exact state values.
    q=np.zeros((n,4));go=.95;transitions=0
    for episode in range(12000):
        s=int(rng.integers(n))
        for t in range(100):
            a=int(rng.integers(5)) if rng.random()<.2 else (int(np.argmax(q[s])) if max(q[s])>1e-10 else 4)
            if a==4:break
            sp=nxt[s,a];intrinsic=e[sp]-e[s]
            q[s,a]+=.2*(intrinsic+go*max(0.,max(q[sp]))-q[s,a]);transitions+=1;s=sp
    # Independently solve the same discovered subtask for comparison.
    v=np.zeros(n)
    for k in range(2000):
        qexact=e[nxt]-e[:,None]+go*v[nxt];vnew=np.maximum(0,qexact.max(axis=1))
        if np.max(abs(vnew-v))<1e-13:break
        v=vnew
    qerr=float(np.max(abs(np.maximum(0,q.max(axis=1))-vnew)))
    traj=[];s=int(np.argmin(e));seen=set()
    while len(traj)<101:
        traj.append(s)
        if max(q[s])<=1e-8 or s in seen:break
        seen.add(s);s=int(nxt[s,np.argmax(q[s])])
    rows=[]
    for i,(x,y) in enumerate(states):
        a=int(np.argmax(q[i]));stop=max(q[i])<=1e-8
        rows.append(dict(state=i,x=x,y=y,eigenfeature=e[i],value=max(0.,max(q[i])),stop=int(stop),dx=0 if stop else actions[a][0],dy=0 if stop else actions[a][1]))
    csvsave('sr-learning.csv',curve);csvsave('eigenoption-map.csv',rows)
    csvsave('eigenoption-trajectory.csv',[dict(t=t,state=i,x=states[i][0],y=states[i][1]) for t,i in enumerate(traj)])
    result=dict(seed=141908,states=n,sr_policy='uniform primitive actions',sr_transitions=200000,sr_discount=gamma,sr_final_relative_error=curve[-1]['relative_error'],option_episodes=12000,option_transitions=transitions,option_discount=go,option_alpha=.2,option_epsilon=.2,option_resets='uniform nonterminal candidate states; terminate action; 100-step sampling cutoff',option_value_error=qerr,trajectory_length=len(traj)-1,trajectory_terminated=bool(max(q[traj[-1]])<=1e-8),candidate_source='second largest real eigenvector of sampled TD successor matrix')
    return rows,curve,traj,states,result

def optimizer():
    raw=[.2]*8+[20.]+[.2]*30+[-8.]+[-.2]*20
    v=0.;alpha=.05;beta=.9;rows=[]
    for t,u in enumerate(raw):
        v=max(beta*v,abs(u));d=alpha*u/(v+1e-8)
        rows.append(dict(t=t,increment=u,scale=v,sgd=alpha*u,controlled=d))
    check('streaming_coordinate_bound',max(abs(r['controlled']) for r in rows)<alpha)
    csvsave('streaming-optimizer.csv',rows);return rows

def metatrace_check():
    # Fixed trajectory, fixed linear features and fixed beta. Then trace derivatives
    # vanish and sensitivity is exact. This is not full AC Metatrace.
    phi=[np.array([1.,.2]),np.array([.3,1.]),np.array([1.,-.4]),np.array([.2,.5])]
    rewards=[.3,-.1,1.];gamma=.9;lam=.7;beta=-2.
    def run(b,derivative=False):
        a=np.exp(b);w=np.zeros(2);H=np.zeros(2);z=np.zeros(2)
        for t,r in enumerate(rewards):
            z=gamma*lam*z+phi[t];d=r+w@(gamma*phi[t+1]-phi[t])
            H=H+a*z*(d+(gamma*phi[t+1]-phi[t])@H)
            w=w+a*d*z
        return H if derivative else w
    H=run(beta,True);fd=(run(beta+1e-6)-run(beta-1e-6))/2e-6
    check('linear_td_meta_sensitivity',np.max(abs(H-fd))<1e-9,analytic=H.tolist(),finite_difference=fd.tolist())

def renewal():
    # Two ReLU features, no biases, x=y=1. Both initial input weights are -1.
    # Replace one incoming weight by .5 and set its outgoing weight to 0 at t=10.
    w=np.array([-1.,-1.]);v=np.array([1.,1.]);wr=w.copy();vr=v.copy();rows=[]
    for t in range(60):
        if t==10:wr[0]=.5;vr[0]=0.
        pred=float(v@np.maximum(w,0));pr=float(vr@np.maximum(wr,0))
        rows.append(dict(t=t,fixed_prediction=pred,renewed_prediction=pr,renewed_input=wr[0],renewed_output=vr[0]))
        for wi,vi in [(w,v),(wr,vr)]:
            h=np.maximum(wi,0);err=float(vi@h)-1;oldv=vi.copy()
            vi-=.1*err*h;wi-=.1*err*oldv*(wi>0)
    check('dead_features_have_zero_gradient',np.all(w==[-1,-1]) and np.all(v==[1,1]))
    check('replacement_allows_later_learning',rows[10]['renewed_prediction']==0 and rows[-1]['renewed_prediction']>.99)
    csvsave('feature-renewal.csv',rows);return rows

def model_and_questions():
    # Scalar planner example: data arrive at A, after option started in A, via B.
    # Its learned fixed tail value is 5 for this one planning update.
    gamma=.9;sample_R=-1-gamma;tau=3;tail=5.;oldr=-2.2;oldp=.6;alpha=.2
    newr=oldr+alpha*(sample_R-oldr);newp=oldp+alpha*(gamma**tau-oldp)
    oldq=oldr+oldp*tail;newq=newr+newp*tail;alternative=.9
    check('one_feedback_changes_planned_choice',oldq<alternative<newq,old=oldq,new=newq,alternative=alternative)
    # Value-error action-gap guarantee: two equal-sized model errors cannot
    # reverse a gap greater than 2*epsilon.
    check('action_gap_example',(.1+.1)<(.8-.5))
    # Continuation 1, zero cumulant: return=0 but Bellman has all constants.
    P=np.array([[0,1],[1,0.]])
    check('integrability_not_unique_bellman',np.allclose(P@np.ones(2),np.ones(2)))
    return dict(task_td=dict(reward=0,rho_old=.2,h_B_old=.4,h_A_old=.1,delta=-.5,h_B_new=.35,rho_new=.195),gvf_time=dict(old=2,target=1,new=1.8),gvf_energy=dict(old=.5,target=.3,new=.46),option_model=dict(tau=tau,discount=gamma,reward_sample=sample_R,old_r=oldr,new_r=newr,old_p=oldp,new_p=newp,tail_value=tail,old_planner_value=oldq,new_planner_value=newq,alternative_value=alternative))

def figures(rate_rows,rvi,grid,curve,traj,states,opt,renew):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from matplotlib.patches import Rectangle
    from matplotlib.font_manager import FontProperties
    font=Path('/System/Library/Fonts/STHeiti Light.ttc')
    if font.exists():plt.rcParams['font.family']=FontProperties(fname=str(font)).get_name()
    plt.rcParams.update({'axes.unicode_minus':False,'font.size':11,'svg.fonttype':'path','axes.spines.top':False,'axes.spines.right':False})
    teal,red,gold='#087E8B','#C65335','#C4942A'
    def save(fig,name):
        fig.savefig(OUT/(name+'.svg'),bbox_inches='tight');fig.savefig(OUT/(name+'.png'),dpi=180,bbox_inches='tight');plt.close(fig)
    fig,ax=plt.subplots(1,2,figsize=(10,3.5),layout='constrained')
    ax[0].plot([r['gamma'] for r in rate_rows],[r['valueA'] for r in rate_rows],'-o',color=teal);ax[0].set(xlabel='折扣率 gamma',ylabel='未中心化价值 v(A)',yscale='log')
    for key,col in [('centeredA',teal),('centeredB',gold),('centeredC',red)]:ax[1].plot([r['gamma'] for r in rate_rows],[r[key] for r in rate_rows],'-o',color=col,label=key[-1])
    ax[1].set(xlabel='折扣率 gamma',ylabel='减去共同奖励率后的折扣价值');ax[1].legend(frameon=False);save(fig,'reward-centering')
    fig,ax=plt.subplots(figsize=(7,3.3),layout='constrained');ax.plot([r['transitions'] for r in curve],[r['relative_error'] for r in curve],color=teal);ax.set(xlabel='真实原子转移次数',ylabel='后继矩阵相对误差',title='同一条随机策略轨迹上的逐行TD估计');ax.grid(alpha=.2);save(fig,'sr-learning')
    fig,axs=plt.subplots(1,2,figsize=(11,4),layout='constrained')
    for ax in axs:
        ax.set(xlim=(0,9),ylim=(0,5),aspect='equal');ax.set_xticks([]);ax.set_yticks([])
        for y in range(5):
            if y!=2:ax.add_patch(Rectangle((4,y),1,1,color='#182E38'))
    es=np.array([r['eigenfeature'] for r in grid]);norm=plt.Normalize(es.min(),es.max());cm=plt.get_cmap('coolwarm')
    for row in grid:
        x,y=row['x'],row['y'];axs[0].add_patch(Rectangle((x,y),1,1,color=cm(norm(row['eigenfeature'])),ec='white'))
        axs[1].add_patch(Rectangle((x,y),1,1,color='#eaf4f3',ec='white'))
        if row['stop']:axs[1].plot(x+.5,y+.5,'o',color=red,ms=5)
        else:axs[1].arrow(x+.5-.18*row['dx'],y+.5-.18*row['dy'],.36*row['dx'],.36*row['dy'],head_width=.12,head_length=.1,color=teal,length_includes_head=True)
    xs=[states[i][0]+.5 for i in traj];ys=[states[i][1]+.5 for i in traj];axs[1].plot(xs,ys,'--',color=gold,lw=2);axs[1].plot(xs[0],ys[0],'s',color=gold)
    axs[0].set_title('从TD后继矩阵取得的非平凡特征');axs[1].set_title('以特征增量为奖励学得的策略与轨迹');fig.colorbar(plt.cm.ScalarMappable(norm=norm,cmap=cm),ax=axs[0],shrink=.8);save(fig,'eigenoption')
    fig,axs=plt.subplots(1,2,figsize=(10,3.4),layout='constrained')
    axs[0].plot([r['t'] for r in opt],[r['increment'] for r in opt],color=red,label='原增量 u');axs[0].plot([r['t'] for r in opt],[r['scale'] for r in opt],color=teal,label='逐坐标尺度 v');axs[0].legend(frameon=False)
    axs[1].plot([r['t'] for r in opt],[r['sgd'] for r in opt],color=red,label='固定步长');axs[1].plot([r['t'] for r in opt],[r['controlled'] for r in opt],color=teal,label='衰减最大值控制');axs[1].set(ylim=(-.09,.09));axs[1].axhline(.05,ls=':',color=gold);axs[1].axhline(-.05,ls=':',color=gold);axs[1].legend(frameon=False)
    for ax in axs:ax.set_xlabel('更新次数');ax.grid(alpha=.2)
    axs[0].set_ylabel('原增量及尺度');axs[1].set_ylabel('参数增量（纵轴仅显示局部范围）');save(fig,'streaming-optimizer')
    fig,ax=plt.subplots(figsize=(7.5,3.5),layout='constrained');ax.plot([r['t'] for r in renew],[r['fixed_prediction'] for r in renew],color=red,label='保持两个失活特征');ax.plot([r['t'] for r in renew],[r['renewed_prediction'] for r in renew],color=teal,label='第10次更新前替换一个特征');ax.axhline(1,color=gold,ls='--',label='目标1');ax.axvline(10,color='gray',ls=':');ax.set(xlabel='观测与更新次数',ylabel='预测');ax.legend(frameon=False);save(fig,'feature-renewal')

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--figures',action='store_true');args=parser.parse_args()
    rate_rows,rvi=rates();grid,curve,traj,states,srmeta=grid_sr_and_option();opt=optimizer();metatrace_check();renew=renewal();event=model_and_questions()
    (OUT/'one-interaction.json').write_text(json.dumps(event,indent=2)+'\n')
    (OUT/'checks.json').write_text(json.dumps(checks,indent=2)+'\n')
    (OUT/'manifest.json').write_text(json.dumps(dict(sr_option=srmeta,scope='Local teaching calculations and sampled tabular subtask learning; no full Stream-X, Metatrace AC, DiscoRL or CBP reproduction',checks=len(checks)),indent=2)+'\n')
    if args.figures:figures(rate_rows,rvi,grid,curve,traj,states,opt,renew)
    print(json.dumps(dict(checks_passed=len(checks),sr_option=srmeta),indent=2))
