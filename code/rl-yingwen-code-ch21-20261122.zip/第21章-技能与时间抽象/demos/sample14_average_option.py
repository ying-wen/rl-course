#!/usr/bin/env python3
"""Three-station worked example: rate -> differential TD -> learned option model -> action.
Run from ANY directory: python /absolute/path/sample14_average_option.py
Requires numpy and matplotlib. No downloads, no simulator package.
Default output: ../assets/sample14-avg-option/ (relative to this source).

Phase 1 explicitly permits subtask resets to learn three given goals; policies freeze.
Phase 2 is one continuing trajectory: six initial coverage options, then model planning.
Only COMPLETED option models feed the planner. No atomic GVF or meta-learner is claimed.
The environment changes C's reward at atomic time 244, without notifying the learner.
This deterministic mechanism experiment is not a benchmark of learning algorithms.
"""
from pathlib import Path
import argparse, csv, itertools, json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

TEAL, ORANGE, INK, GRAY = '#087E8B', '#C65335', '#182E38', '#89979C'
# Same physical graph in every figure. Nodes are not privileged labels for the planner.
NAMES = ['A','a','J','B','c1','c2','c3','C']
XY = np.array([[-2,0],[-1,0],[0,0],[0,1],[1,0],[2,0],[3,0],[4,0]],float)
EDGES = [(0,1),(1,2),(2,3),(2,4),(4,5),(5,6),(6,7)]
ADJ = [[v for a,b in EDGES for u,v in [(a,b),(b,a)] if u==s] for s in range(8)]
STATIONS = [0,3,7]
LABELS = ['A','B','C']
AC = [0,1,2,4,5,6,7,6,5,4,2,1]
AC_R = np.array([0,0,0,0,0,3,0,0,0,0,0,1.],float)


def write_csv(path, rows):
    with open(path,'w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)


def bfs_distance(goal):
    # Independent graph-theoretic check: never used by the trained policy or planner.
    d=np.full(8,np.inf);d[goal]=0;queue=[goal]
    for u in queue:
        for v in ADJ[u]:
            if np.isinf(d[v]):d[v]=d[u]+1;queue.append(v)
    return d


def train_given_goals(seed=1429):
    """Tabular shortest-time subtask Q-learning; explicit resets, -1 each atomic step."""
    rng=np.random.default_rng(seed);qs=[];logs=[];snapshots={}
    for gi,goal in enumerate(STATIONS):
        q=np.full((8,8),-np.inf)
        for s in range(8):q[s,ADJ[s]]=0.
        for episode in range(1,2401):
            s=int(rng.choice([i for i in range(8) if i!=goal]))
            for k in range(150):
                # Repeated visits with exploration; no shortest-path oracle in behavior.
                a=int(rng.choice(ADJ[s])) if rng.random()<.3 else int(np.argmax(q[s]))
                stop=a==goal;old=float(q[s,a])
                target=-1.+(0. if stop else float(np.max(q[a])))
                q[s,a]+= .25*(target-old)
                logs.append(dict(goal=LABELS[gi],episode=episode,state=NAMES[s],next=NAMES[a],
                                 internal=-1,terminal=int(stop),old=old,target=target,new=float(q[s,a])))
                s=a
                if stop:break
            # A cap is a collection truncation, not terminal: the last update bootstraps.
            if goal==7 and episode in [1,20,2400]:snapshots[episode]=q.copy()
        qs.append(q)
    errors=[]
    for gi,goal in enumerate(STATIONS):
        d=bfs_distance(goal)
        errors.append(max(abs(float(np.max(qs[gi][s]))+d[s]) for s in range(8) if s!=goal))
        for start in STATIONS:
            if start==goal:continue
            s=start;n=0
            while s!=goal and n<100:s=int(np.argmax(qs[gi][s]));n+=1
            assert n==int(d[start]),(goal,start,n,d[start])
    assert max(errors)<1e-6
    return qs,logs,snapshots,errors


def differential_td():
    """Fixed A-C round trip. The phase is part of state (direction matters)."""
    h=np.zeros(12);rho=0.;rows=[]
    # Solve Poisson independently of the TD update; h[0]=0 fixes the arbitrary constant.
    P=np.roll(np.eye(12),1,axis=1)
    M=np.column_stack([np.ones(12),np.eye(12)-P])
    M=np.vstack([M,np.r_[0,1,np.zeros(11)]])
    sol=np.linalg.solve(M,np.r_[AC_R,0]);true_rho,true_h=sol[0],sol[1:]
    for t in range(18000):
        s=t%12;sp=(s+1)%12;r=float(AC_R[s])
        # ONE residual, using BOTH old estimates. Only then write either quantity.
        old_rho=rho;old_h=float(h[s]);old_next=float(h[sp])
        delta=r-old_rho+old_next-old_h
        h[s]=old_h+.1*delta;rho=old_rho+.01*delta
        rows.append(dict(t=t,state_phase=s,next_phase=sp,reward=r,rho_old=old_rho,
                         h_old=old_h,h_next_old=old_next,delta=delta,rho_new=rho,h_new=float(h[s]),
                         h_C_minus_A=float(h[6]-h[0]),h_before_C_minus_A=float(h[5]-h[0])))
    assert abs(rho-1/3)<1e-7
    assert np.max(np.abs((h-h[0])-true_h))<1e-6, ((h-h[0])-true_h).tolist()
    # Finite-sum check for every phase and every horizon through five complete periods.
    err=0.
    for s in range(12):
        for T in range(61):
            reward=sum(AC_R[(s+k)%12] for k in range(T))
            err=max(err,abs(reward-(T*true_rho+true_h[s]-true_h[(s+T)%12])))
    assert err<1e-12
    return rows,true_rho,true_h,err


def solve_model(r,ell,p):
    """Exact planning on LEARNED 3x2 SMDP data. No environment or distances queried.
    Each row gives a completed-option reward, duration, and endpoint distribution.
    Enumerate 8 policies; evaluate rho/h, then check Bellman optimality for all choices.
    """
    allowed=[[j for j in range(3) if j!=i] for i in range(3)]
    for policy in itertools.product(*allowed):
        mat=np.zeros((4,4));rhs=np.zeros(4)
        for i,j in enumerate(policy):
            mat[i,0]=ell[i,j];mat[i,1:]=np.eye(3)[i]-p[i,j];rhs[i]=r[i,j]
        mat[3,1]=1 # h(A)=0
        rho,*hh=np.linalg.solve(mat,rhs);h=np.array(hh)
        scores=np.full((3,3),-np.inf)
        for i in range(3):
            for j in allowed[i]:scores[i,j]=r[i,j]-rho*ell[i,j]+p[i,j]@h
        if np.max(np.max(scores,axis=1)-h)<1e-9:
            return float(rho),h,scores,np.array(policy)
    raise AssertionError('No Bellman-optimal policy found')


def independent_cycle_rate(r,ell):
    # Ratio of sums on every possible simple recurrent cycle: independent of linear solve.
    rates=[]
    for length in [2,3]:
        for cy in itertools.permutations(range(3),length):
            edges=list(zip(cy,cy[1:]+cy[:1]))
            rates.append(sum(r[i,j] for i,j in edges)/sum(ell[i,j] for i,j in edges))
    return max(rates)


def continuing_run(qs,freeze_model=False,horizon=600):
    r=np.zeros((3,3));ell=np.zeros((3,3));p=np.zeros((3,3,3));seen=np.eye(3,dtype=bool)
    # Actual uninterrupted coverage walk: A -> B -> C -> A -> C -> B -> A, 28 steps.
    coverage=[1,2,0,2,1,0]
    pos=0;station=0;t=0;event=0;trajectory=[];events=[];decisions=[];model_updates=[]
    model_snapshots={};last_station=0
    while t<horizon:
        full=bool(np.all(seen))
        if full:
            rho,h,scores,policy=solve_model(r,ell,p)
            assert abs(rho-independent_cycle_rate(r,ell))<1e-10
            goal=int(policy[station]);source='learned_model'
            decisions.append(dict(t=t,state=LABELS[station],choice=LABELS[goal],rho=rho,
                 score_A=None if station==0 else float(scores[station,0]),
                 score_B=None if station==1 else float(scores[station,1]),
                 score_C=None if station==2 else float(scores[station,2]),
                 h_A=float(h[0]),h_B=float(h[1]),h_C=float(h[2])))
        else:goal=coverage[event];source='coverage'
        start=station;begin=t;G=0.;tau=0;path=[NAMES[pos]]
        # Call-and-return: retain goal until its target station is reached.
        while pos!=STATIONS[goal]:
            nxt=int(np.argmax(qs[goal][pos]));external=0.
            if nxt in STATIONS:
                arrival=STATIONS.index(nxt)
                if arrival!=last_station:
                    external=[1.,.2,.1 if t>=244 else 3.][arrival]
                    last_station=arrival
            trajectory.append(dict(t=t,option_event=event,start=LABELS[start],goal=LABELS[goal],
                 state=NAMES[pos],next=NAMES[nxt],internal=-1,external=external,duration=1,
                 stop=int(nxt==STATIONS[goal])))
            pos=nxt;t+=1;tau+=1;G+=external;path.append(NAMES[pos])
            assert tau<50
        station=goal
        old_r=float(r[start,goal]);old_t=float(ell[start,goal]);old_p=p[start,goal].copy()
        # Last completed sample (alpha=1): deliberate deterministic example, no noise averaging.
        # The frozen-reader comparison learns the initial model, then stops writing it.
        if not(freeze_model and full):
            r[start,goal]=G;ell[start,goal]=tau;p[start,goal]=np.eye(3)[goal];seen[start,goal]=True
        model_updates.append(dict(event=event,t=t,start=LABELS[start],goal=LABELS[goal],
            G=G,tau=tau,endpoint=LABELS[station],r_old=old_r,r_new=float(r[start,goal]),
            ell_old=old_t,ell_new=float(ell[start,goal]),p_old=old_p.tolist(),p_new=p[start,goal].tolist()))
        events.append(dict(event=event,start_t=begin,end_t=t,start=LABELS[start],goal=LABELS[goal],
                           G=G,tau=tau,path='>'.join(path),selection=source))
        if t==28:model_snapshots['before']=(r.copy(),ell.copy(),p.copy())
        if full and r[0,2]==.1 and r[1,2]==.1 and 'after' not in model_snapshots:
            model_snapshots['after']=(r.copy(),ell.copy(),p.copy())
        event+=1
    return trajectory,events,decisions,model_updates,model_snapshots


# Mathtext strings do not use per-glyph font fallback, so labels mixing CJK and $...$ name a CJK font.
CJK='Hiragino Sans GB'


def style():
    # Presentation only: CJK-capable font list (per-glyph fallback), ASCII minus.
    plt.rcParams.update({'font.size':15,'axes.titlesize':18,'axes.labelsize':15,
         'xtick.labelsize':13,'ytick.labelsize':13,'legend.fontsize':13,
         'font.family':['DejaVu Sans','Hiragino Sans GB','Heiti TC','Arial Unicode MS'],
         'axes.unicode_minus':False,'mathtext.fontset':'dejavusans',
         'axes.spines.top':False,'axes.spines.right':False,
         'text.color':INK,'axes.labelcolor':INK,'axes.edgecolor':GRAY,
         'pdf.fonttype':42,'savefig.facecolor':'white'})


def save(fig,out,name):
    fig.savefig(out/(name+'.pdf'),bbox_inches='tight',pad_inches=.15)
    fig.savefig(out/(name+'.png'),dpi=180,bbox_inches='tight',pad_inches=.15);plt.close(fig)


def graph(ax,route=None,color=TEAL,values=None):
    for u,v in EDGES:ax.plot(XY[[u,v],0],XY[[u,v],1],color='#D6DEE0',lw=4,zorder=0)
    for s,(x,y) in enumerate(XY):
        ax.scatter(x,y,s=380 if s in STATIONS else 100,c='white',edgecolors=INK,zorder=3)
        if s in STATIONS:ax.text(x,y,NAMES[s],ha='center',va='center',fontsize=13,zorder=4)
        elif s==2:ax.annotate('J',(x,y),xytext=(13,-10),textcoords='offset points',ha='left',va='top',fontsize=14)
        if values is not None and np.isfinite(values[s]):ax.annotate(f'{values[s]:.1f}',(x+(.38 if s==2 else 0),y),xytext=(0,12 if s in STATIONS else 7),textcoords='offset points',ha='center',va='bottom',color=TEAL)
    if route:
        for u,v in zip(route[:-1],route[1:]):
            delta=XY[v]-XY[u]
            ax.annotate('',xy=XY[u]+.78*delta,xytext=XY[u]+.2*delta,
                        arrowprops=dict(arrowstyle='->',lw=3,color=color),zorder=5)
    ax.set_aspect('equal');ax.set_xlim(-2.45,4.45);ax.set_ylim(-.65,1.6);ax.axis('off')


def figures(out,td,rho,h,qs,snaps,trajectory,events,decisions,updates,models,frozen):
    style()
    fig,ax=plt.subplots(figsize=(12,3.8));graph(ax)
    for idx,txt in [(0,'到站奖励 1'),(3,'到站奖励 0.2'),(7,'到站奖励 3 → 0.1')]:
        x,y=XY[idx];ax.text(x+(.25 if idx==7 else 0),y+(.35 if idx!=3 else .28),txt,ha='center',color=ORANGE)
    ax.text(-1,-.5,'2 个原始步',ha='center');ax.text(.18,.5,'1 个原始步',ha='left',va='center');ax.text(2,-.5,'4 个原始步',ha='center')
    save(fig,out,'sample14-avg-map')
    fig,axs=plt.subplots(2,1,figsize=(12,4.4),sharex=True)
    for ax,name,positions,rewards,color in [
        (axs[0],'A–C–A',AC+[0],AC_R,TEAL),
        (axs[1],'A–B–A–B–A',[0,1,2,3,2,1,0,1,2,3,2,1,0],np.array([0,0,.2,0,0,1]*2),ORANGE)]:
        ax.plot(range(13),[XY[s,0]+.25*XY[s,1] for s in positions],'-o',color=color,lw=2)
        for t1,s in enumerate(positions):
            if s in STATIONS:ax.annotate(NAMES[s],(t1,XY[s,0]+.25*XY[s,1]),xytext=(0,10),textcoords='offset points',ha='center')
        for k,r in enumerate(rewards,1):
            if r:ax.text(k,-2.75,f'+{r:g}',ha='center',va='top',color=color)
        ax.set_ylim(-4.6,5.5);ax.set_yticks([]);ax.set_ylabel(name);ax.spines['left'].set_visible(False)
        ax.grid(axis='x',alpha=.18);ax.set_xticks(range(13))
    axs[-1].set_xlabel('原始步（每条边占一步）');fig.tight_layout();save(fig,out,'sample14-avg-timeline')
    fig,axs=plt.subplots(1,2,figsize=(12,4))
    T=np.arange(73)
    for rr,label,c in [(AC_R,'A–C 往返：长期率 1/3',TEAL),(np.array([0,0,.2,0,0,1]),'A–B 往返：长期率 0.2',ORANGE)]:
        total=np.r_[0,np.cumsum(np.resize(rr,72))];axs[0].step(T,total,where='post',label=label,c=c,lw=2)
    axs[0].set(xlabel='原始步',ylabel='累计外部奖励');axs[0].legend();axs[0].grid(alpha=.15)
    for offset,label,c in [(0,'从 A 出发（相位 0）',TEAL),(5,'抵达 C 前一格（相位 5）',ORANGE),(6,'从 C 出发（相位 6）',GRAY)]:
        total=np.r_[0,np.cumsum([AC_R[(offset+k)%12] for k in range(36)])]
        axs[1].step(range(37),total,where='post',label=label,c=c,lw=2)
    axs[1].plot(range(37),np.arange(37)/3,':',c=INK,label='斜率 1/3（T/3）')
    axs[1].set(xlabel='原始步',ylabel='累计外部奖励');axs[1].set_title('同一长期率，不同起始相位',fontsize=15)
    axs[1].legend(fontsize=11,loc='lower right');axs[1].grid(alpha=.15)
    fig.tight_layout();save(fig,out,'sample14-avg-slopes')
    fig,axs=plt.subplots(1,2,figsize=(12,3.8))
    axs[0].plot(range(13),np.r_[h,h[0]],'-o',color=TEAL,lw=2)
    axs[0].set_xlabel('A–C–A 往返上的相位');axs[0].set_ylabel(r'差分价值 $\tilde v_\pi$，取 $\tilde v_\pi(A)=0$',fontfamily=CJK);axs[0].set_xticks([0,6,12],['A','C','A'])
    axs[0].set_ylim(-1.35,2.2)
    axs[0].annotate('抵达 C 前一格',xy=(5,h[5]),xytext=(2.6,2.0),ha='center',arrowprops=dict(arrowstyle='->',color=GRAY),fontsize=13)
    T=np.arange(37);tot=np.r_[0,np.cumsum(np.resize(AC_R,36))]
    axs[1].step(T,tot-T/3,where='post',color=ORANGE,lw=2)
    axs[1].set(xlabel='有限时域 T',ylabel='累计奖励 − T/3')
    axs[1].axhline(0,c=GRAY,lw=1)
    for ax in axs:ax.grid(alpha=.2)
    fig.tight_layout();save(fig,out,'sample14-avg-bias-period')
    fig,axs=plt.subplots(1,2,figsize=(12,3.8));ts=[r['t']+1 for r in td]
    axs[0].plot(ts,[r['rho_new'] for r in td],c=TEAL,lw=2,label=r'率估计 $\bar R$');axs[0].axhline(rho,c=INK,ls='--',label='真值 1/3');axs[0].legend(loc='lower right',prop={'family':CJK,'size':13})
    axs[0].set_xlabel('实际 TD 更新次数');axs[0].set_ylabel(r'率估计 $\bar R$',fontfamily=CJK)
    for key,true,label,c in [('h_C_minus_A',h[6],r'$\tilde V(C)-\tilde V(A)$',TEAL),('h_before_C_minus_A',h[5],r'$\tilde V$(C 前一格)$-\tilde V(A)$',ORANGE)]:
        axs[1].plot(ts,[r[key] for r in td],label=label,c=c,lw=2);axs[1].axhline(true,c=c,ls='--',alpha=.5)
    axs[1].set(xlabel='实际 TD 更新次数',ylabel='价值差');axs[1].legend(loc='center right',prop={'family':CJK,'size':12})
    for ax in axs:ax.set_xlim(0,4000);ax.grid(alpha=.2)
    fig.tight_layout();save(fig,out,'sample14-avg-td-learning')
    fig,axs=plt.subplots(3,1,figsize=(12,5.4))
    for ax,ep in zip(axs,[1,20,2400]):
        q=snaps[ep];vals=np.max(q,axis=1);vals[7]=0;graph(ax,values=vals)
        for s in range(8):
            if s==7:continue
            a=int(np.argmax(q[s]));d=XY[a]-XY[s]
            ax.annotate('',xy=XY[s]+.8*d,xytext=XY[s]+.15*d,arrowprops=dict(arrowstyle='->',lw=2,color=ORANGE))
        ax.set_aspect('auto');ax.set_ylim(-.55,2.1)
        ax.text(-2.4,1.8,f'目标 C：第 {ep} 段',color=INK,fontsize=16)
    fig.tight_layout();save(fig,out,'sample14-option-skill')
    chosen=next(e for e in events if e['start']=='A' and e['goal']=='C')
    trace=[r for r in trajectory if r['option_event']==chosen['event']]
    fig,axs=plt.subplots(4,1,figsize=(12,5.6),sharex=True,gridspec_kw={'height_ratios':[1.4,1,1,1]})
    labels=[trace[0]['state']]+[r['next'] for r in trace]
    axs[0].plot(range(7),np.zeros(7),'-o',c=TEAL,lw=3)
    for k,label in enumerate(labels):axs[0].text(k,.17,label,ha='center',fontsize=17)
    axs[0].set_ylim(-.4,.6);axs[0].set_yticks([]);axs[0].set_ylabel('位置',fontsize=13)
    for ax,key,name,col in zip(axs[1:],['internal','external','duration'],['内部信号','主奖励','时间计数'],[TEAL,ORANGE,GRAY]):
        vs=[r[key] for r in trace];ax.bar(np.arange(1,7),vs,width=.6,color=col)
        ax.set_ylabel(name,fontsize=13);ax.axhline(0,c=GRAY,lw=.5);ax.set_yticks(sorted(set([0]+vs)))
        for k,v in enumerate(vs,1):ax.text(k,v+(.1 if v>=0 else -.18),f'{v:g}',ha='center',va='bottom' if v>=0 else 'top',fontsize=12)
        ax.set_ylim(min(-.4,min(vs)-.55),max(vs)+.65)
    axs[-1].set_xticks(range(7));axs[-1].set_xlabel(f'自 t = {chosen["start_t"]} 起的原始步（一次完整的技能执行）')
    fig.tight_layout();fig.align_ylabels(axs);save(fig,out,'sample14-option-three-signals')
    fig,axs=plt.subplots(1,2,figsize=(12,4.1))
    for ax,key in zip(axs,['before','after']):
        rr,ll,pp=models[key];ro,hh,score,pol=solve_model(rr,ll,pp)
        route=[0,1,2,4,5,6,7,6,5,4,2,1,0] if key=='before' else [0,1,2,3,2,1,0]
        graph(ax,route=route,color=TEAL if key=='before' else ORANGE)
        ax.set_title(f'{"变化前" if key=="before" else "变化后"}：长期率 {ro:.3f}')
    fig.tight_layout();save(fig,out,'sample14-option-policy-change')
    fig,axs=plt.subplots(2,1,figsize=(12,5.2),gridspec_kw={'height_ratios':[1,1.6]})
    for trace,label,c in [(trajectory,'持续更新模型',TEAL),(frozen,'冻结模型',GRAY)]:
        rseq=[r['external'] for r in trace if r['t']<600];axs[1].plot(np.arange(len(rseq)+1),np.r_[0,np.cumsum(rseq)],c=c,label=label,lw=2)
    relevant=[e for e in events if 215<=e['start_t']<=300]
    for e in relevant:
        axs[0].plot([e['start_t'],e['end_t']],[LABELS.index(e['start']),LABELS.index(e['goal'])],'-o',c=TEAL,lw=2)
        axs[0].text((e['start_t']+e['end_t'])/2,(LABELS.index(e['start'])+LABELS.index(e['goal']))/2+.1,f'{e["G"]:g}',fontsize=10,
                    ha='center',va='center',bbox=dict(boxstyle='round,pad=.15',fc='white',ec='none',alpha=.9),zorder=5)
    axs[0].set(yticks=[0,1,2],yticklabels=LABELS,ylabel='到达站点',xlabel='原始时间（标注为各段完成时的段奖励）')
    axs[0].set_xlim(215,304);axs[0].axvline(244,ls='--',c=ORANGE)
    axs[1].axvline(244,ls='--',c=ORANGE);axs[1].set(xlabel='原始时间',ylabel='累计外部奖励');axs[1].legend(fontsize=12)
    for ax in axs:ax.grid(alpha=.15)
    fig.tight_layout();fig.align_ylabels(axs);save(fig,out,'sample14-option-behavior')
    fig,ax=plt.subplots(figsize=(10.5,3.7));x=np.arange(2);width=.32
    for k,key,c in [(0,'before',TEAL),(1,'after',ORANGE)]:
        ro,hh,scores,pol=solve_model(*models[key]);vals=scores[0,[1,2]];xs=x+(k-.5)*width
        ax.bar(xs,vals,width,label='变化前模型' if key=='before' else '变化后模型',color=c,zorder=2)
        for xi,v in zip(xs,vals):
            if abs(v)<1e-12:
                # A zero-height bar is invisible: draw a thick bar-width cap and a hollow marker at 0.
                ax.plot([xi-width/2,xi+width/2],[0,0],c=c,lw=5,solid_capstyle='butt',zorder=3)
                ax.plot([xi],[0],'o',ms=9,mfc='white',mec=c,mew=2.5,zorder=4)
            ax.text(xi,(0.06 if abs(v)<1e-12 else v-.04),f'{round(v,3)+0:g}',ha='center',va='bottom' if abs(v)<1e-12 else 'top',fontsize=13,color=c)
    ax.axhline(0,c=GRAY,lw=.7,zorder=1);ax.set_ylim(-1.5,.3);ax.set_xticks(x,['A 处：去 B','A 处：去 C'])
    ax.set_ylabel(r'规划分数 $r_o-r(\mu)\,\ell_o+\sum_y P_o \tilde v$',fontsize=14,fontfamily=CJK);ax.legend(loc='lower left');fig.tight_layout();save(fig,out,'sample14-option-reader')
    fig,axs=plt.subplots(2,1,figsize=(12,4.6))
    for ax,route,title in [(axs[0],[0,1,2,4,5,6,7],'调用后返回（call-and-return）：保持目标 C，直到技能停止'),(axs[1],[0,1,2,3],'逐步重新激活：在 J 得到新信息，立即改去 B')]:
        graph(ax,route=route);ax.set_aspect('auto');ax.scatter(*XY[2],s=650,facecolors='none',edgecolors=ORANGE,lw=2,zorder=6)
        ax.set_title(title,fontsize=16,loc='left')
    fig.tight_layout();save(fig,out,'sample14-option-semantics')
    fig,ax=plt.subplots(figsize=(11,3.4));duration=np.linspace(1,6,80)
    # Hold rho and all h fixed; isolate duration error in the B option.
    score_b=.2-duration/3+1/3
    ax.plot(duration,score_b,c=TEAL,lw=3,label='去 B 的预测分数')
    ax.axhline(0,c=ORANGE,lw=2,label='去 C 的分数');ax.axvline(3,c=GRAY,ls='--')
    ax.scatter([3],[.2-1+1/3],c=TEAL,s=70);ax.set_xlabel(r'去 B 的预测时长 $\hat\ell_{o_B}(A)$（真值 3）',fontfamily=CJK);ax.set_ylabel(r'A 处规划分数' '\n' r'（固定 $r(\mu)$ 与 $\tilde v$）',fontfamily=CJK)
    ax.legend();ax.grid(alpha=.15);fig.tight_layout();save(fig,out,'sample14-option-duration-error')


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--out',type=Path,default=Path(__file__).resolve().parents[1]/'assets'/'sample14-avg-option');args=ap.parse_args()
    out=args.out;out.mkdir(parents=True,exist_ok=True)
    qs,skill_logs,snaps,errors=train_given_goals();td,rho,h,telerr=differential_td()
    tr,ev,de,up,models=continuing_run(qs);frozen,*_=continuing_run(qs,freeze_model=True)
    before=solve_model(*models['before']);after=solve_model(*models['after'])
    assert before[3][0]==2 and after[3][0]==1
    assert before[0]==1/3 or abs(before[0]-1/3)<1e-12
    assert abs(after[0]-.2)<1e-12
    changed=next(d for d in de if d['t']>=244 and d['state']=='A' and d['choice']=='B')
    # Counterfactual READ test at the same A boundary: old/new learned models change the action.
    assert changed['choice']=='B' and LABELS[before[3][0]]=='C'
    assert all(e['tau']==len(e['path'].split('>'))-1 for e in ev)
    for e in ev:
        records=[r for r in tr if r['option_event']==e['event']]
        assert abs(sum(x['external'] for x in records)-e['G'])<1e-12
    write_csv(out/'sample14-avg-td-updates.csv',td)
    write_csv(out/'sample14-option-skill-updates.csv',skill_logs)
    write_csv(out/'sample14-option-trajectory.csv',tr)
    write_csv(out/'sample14-option-events.csv',ev)
    write_csv(out/'sample14-option-decisions.csv',de)
    (out/'sample14-option-model-updates.json').write_text(json.dumps(up,indent=2))
    write_csv(out/'sample14-option-frozen-trajectory.csv',frozen)
    manifest=dict(seed=1429,subtask_episodes_per_goal=2400,subtask_resets_allowed=True,
      subtask_transitions=len(skill_logs),subtask_value_max_abs_errors=errors,
      frozen_goal_policies=True,continuing_resets=0,change_atomic_time=244,coverage_atomic_steps=28,
      actual_atomic_steps=len(tr),option_events=len(ev),td_updates=len(td),td_alpha=.1,td_eta=.01,
      poisson_rate=rho,poisson_h=h.tolist(),finite_sum_max_abs_error=telerr,
      completed_model_stepsize=1,planner='8-policy SMDP enumeration and Bellman check',
      planned_rate_before=before[0],planned_rate_after=after[0],
      first_changed_A_decision=changed,
      actual_reward_first_600=sum(x['external'] for x in tr if x['t']<600),
      frozen_reward_first_600=sum(x['external'] for x in frozen if x['t']<600),
      readout_intervention={'same_state':'A','old_model_choice':'C','updated_model_choice':'B'},
      scope='Deterministic given-goal mechanism example. No GVF, meta, representation or skill discovery in the control loop.')
    (out/'sample14-manifest.json').write_text(json.dumps(manifest,indent=2))
    figures(out,td,rho,h,qs,snaps,tr,ev,de,up,models,frozen)
    print(json.dumps(manifest,indent=2))

if __name__=='__main__':main()
