# -*- coding: utf-8 -*-
"""第 21 章文献原型：Machado、Bellemare 与 Bowling (2017) 的 eigenoption 扩散时间。

出处：M. C. Machado, M. G. Bellemare, M. Bowling. A Laplacian Framework for Option
Discovery in Reinforcement Learning. ICML 2017。图 1（三个确定性 MDP）、图 6（扩散时间）。

论文结论（按文献核对报告，只作定性对照）：option 很少时反而不利于探索，数量足够时
显著缩短扩散时间；只用瓶颈 option 会延长扩散时间（图 6d）。

本课自定（论文 4-room 的格数未核，这里用第 21 章的 104 格四房间布局）：
- 确定性移动，撞墙原地不动；
- 由相邻关系建无向图，取归一化拉普拉斯 L = D^{-1/2}(D-A)D^{-1/2} 最小的若干个
  非零特征值的特征向量 phi；每个方向取 u = D^{-1/2} phi 的正反两向，各得一项
  eigenoption（k 项 option 用 k/2 个特征向量）；
- 内部价值：Q_u(z,a) = [u(z') - u(z)] + gamma_o * max{0, max_a' Q_u(z',a')}，
  gamma_o = 0.9；max_a Q_u(z,a) > 0 处可启动，其余处停止；
- 瓶颈 option：每个房间各两项，沿最短路走到本房间的一个走廊（共 8 项）；
- 扩散时间：每次在“4 个原始动作 + 当前可启动的 option”中等概率选一个，option 走到
  停止为止，途中经过目标就算到达；对所有起点、终点对求期望步数的平均（解线性方程，
  无随机误差）。

只用 numpy。用法：
    python3 demos/ch21_lit_eigenoption.py
输出写 assets/ch21-lit-eigenoption/results.json。
"""
import json, os, time
import numpy as np

LAYOUT = [
    "#############",
    "#.....#.....#",
    "#.....#.....#",
    "#...........#",
    "#.....#.....#",
    "#.....#.....#",
    "##.####.....#",
    "#.....###.###",
    "#.....#.....#",
    "#.....#.....#",
    "#...........#",
    "#.....#.....#",
    "#############",
]
H, W = len(LAYOUT), len(LAYOUT[0])
CELLS = [(r, c) for r in range(H) for c in range(W) if LAYOUT[r][c] == "."]
IDX = {rc: i for i, rc in enumerate(CELLS)}
N = len(CELLS)
MOVES = [(-1, 0), (1, 0), (0, -1), (0, 1)]
NEXT = np.array([[IDX.get((r + dr, c + dc), i) for dr, dc in MOVES]
                 for i, (r, c) in enumerate(CELLS)])
GAMMA_O = 0.9

HALL = {"N": (3, 6), "W": (6, 2), "E": (7, 9), "S": (10, 6)}
ROOMS = {
    "TL": (lambda r, c: 1 <= r <= 5 and 1 <= c <= 5, ("N", "W")),
    "TR": (lambda r, c: 1 <= r <= 6 and 7 <= c <= 11, ("N", "E")),
    "BL": (lambda r, c: 7 <= r <= 11 and 1 <= c <= 5, ("W", "S")),
    "BR": (lambda r, c: 8 <= r <= 11 and 7 <= c <= 11, ("E", "S")),
}


def laplacian_dirs():
    A = np.zeros((N, N))
    for i in range(N):
        for j in NEXT[i]:
            if j != i:
                A[i, j] = 1.0
    deg = A.sum(1)
    Dm = np.diag(deg ** -0.5)
    L = Dm @ (np.diag(deg) - A) @ Dm
    lam, vec = np.linalg.eigh(L)
    u = Dm @ vec                       # u = D^{-1/2} phi
    return lam, u


def option_path(Q, s, cap=400):
    """从 s 按贪心走到停止，返回途经的状态序列（不含 s）。"""
    path = []
    for _ in range(cap):
        q = Q[s]
        if q.max() <= 1e-12:
            break
        s = int(NEXT[s, int(np.argmax(q))])
        path.append(s)
    return path


def eigenoption(u):
    Q = np.zeros((N, 4))
    for _ in range(2000):
        V = np.maximum(0.0, Q.max(1))
        Qn = (u[NEXT] - u[:, None]) + GAMMA_O * V[NEXT]
        if np.abs(Qn - Q).max() < 1e-12:
            Q = Qn
            break
        Q = Qn
    return {s: option_path(Q, s) for s in range(N) if Q[s].max() > 1e-12}


def bfs_dist(target, allowed):
    dist = {target: 0}
    frontier = [target]
    while frontier:
        nxt = []
        for x in frontier:
            for y in NEXT[x]:
                y = int(y)
                if y in allowed and y not in dist:
                    dist[y] = dist[x] + 1
                    nxt.append(y)
        frontier = nxt
    return dist


def bottleneck_options():
    opts = []
    for name, (f, halls) in ROOMS.items():
        room = {IDX[rc] for rc in CELLS if f(*rc)}
        for h in halls:
            t = IDX[HALL[h]]
            d = bfs_dist(t, room | {t})
            paths = {}
            for s in room:
                path, x = [], s
                while x != t:
                    x = min((int(y) for y in NEXT[x] if int(y) in d), key=lambda y: d[y])
                    path.append(x)
                paths[s] = path
            opts.append(paths)
    return opts


def diffusion_time(options):
    """options: 列表，每项为 {起点: 途经状态序列}。返回所有有序对的平均期望步数。"""
    choices = []
    for s in range(N):
        cs = [[int(NEXT[s, a])] for a in range(4)]
        cs += [o[s] for o in options if s in o and len(o[s]) > 0]
        choices.append(cs)
    total, cnt = 0.0, 0
    for g in range(N):
        M = np.eye(N)
        b = np.zeros(N)
        for s in range(N):
            if s == g:
                continue
            n = len(choices[s])
            for path in choices[s]:
                if g in path:
                    b[s] += (path.index(g) + 1) / n
                else:
                    b[s] += len(path) / n
                    M[s, path[-1]] -= 1.0 / n
        M[g] = 0.0
        M[g, g] = 1.0
        b[g] = 0.0
        T = np.linalg.solve(M, b)
        total += T.sum()
        cnt += N - 1
    return total / cnt


def main():
    t0 = time.time()
    lam, u = laplacian_dirs()
    # 第 1 个特征值为 0（常数方向），从第 2 个起取
    eig_opts = []
    for j in range(1, 1 + 64):
        eig_opts.append(eigenoption(u[:, j]))
        eig_opts.append(eigenoption(-u[:, j]))
    res = dict(n_cells=N, layout=LAYOUT, gamma_o=GAMMA_O)
    res["primitive_only"] = diffusion_time([])
    bott = bottleneck_options()
    res["bottleneck_8"] = diffusion_time(bott)
    ks = [2, 4, 8, 16, 32, 64, 128]
    res["eigen"] = {str(k): diffusion_time(eig_opts[:k]) for k in ks}
    # 第几个方向的 option 第一次停在门口（走廊格）
    halls = {IDX[h] for h in HALL.values()}
    first_door = None
    for j in range(len(eig_opts)):
        ends = {p[-1] for p in eig_opts[j].values() if p}
        if ends & halls:
            first_door = j
            break
    res["first_option_ending_at_doorway"] = (first_door // 2 + 1, "+" if first_door % 2 == 0 else "-") if first_door is not None else None
    res["eigen_option_mean_len"] = {str(k): float(np.mean([np.mean([len(p) for p in o.values()]) for o in eig_opts[:k]])) for k in ks}
    res["seconds"] = round(time.time() - t0, 1)
    d = os.path.join(os.path.dirname(__file__), "..", "assets", "ch21-lit-eigenoption")
    os.makedirs(d, exist_ok=True)
    with open(os.path.join(d, "results.json"), "w") as f:
        json.dump(res, f, ensure_ascii=False, indent=1)
    print(json.dumps({k: v for k, v in res.items() if k != "layout"}, ensure_ascii=False, indent=1))


if __name__ == "__main__":
    main()
