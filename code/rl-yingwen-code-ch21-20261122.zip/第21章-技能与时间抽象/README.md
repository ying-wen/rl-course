# 第 21 章　技能与时间抽象：程序

本目录可以单独运行：在本目录下执行下面的命令即可，结果写回本目录的 `assets/`。目录由 `rl-course/tools/export_chapter_code.py` 从课程目录生成，改程序请改课程目录里的原件，再重新导出。

## 准备

```sh
python3 -m pip install -r requirements.txt
```

需要的第三方包：matplotlib、mpmath、numpy。复现附录要求 Python 3.10 或更新版本；核验时用的版本见下表。

## 运行（与复现附录相同）

```sh
python3 demos/sample14_average_option.py           # 写 assets/sample14-avg-option
python3 demos/crl_v8_mechanisms.py --figures       # 写 assets/crl-v8，含 sr-learning.png
python3 demos/crl_skill_discovery_trial.py         # 64 对 × 8192 步，写 assets/crl-skill-discovery-trial
python3 demos/ch21_lit_fourrooms.py        # 文献原型：四房间，写 assets/ch21-lit-fourrooms
python3 demos/ch21_lit_eigenoption.py      # 文献原型：eigenoption，写 assets/ch21-lit-eigenoption
python3 demos/crl_ladder_learners.py --exp ch21 --seeds 49 --seed0 100 --steps 2000000 --tag formal   # 写 assets/crl-ladder-world/runs/formal-ch21.json
python3 demos/crl_ch21_ladder_dots.py      # 读 formal-ch21.json，写 assets/crl-ladder-world/fig/ch21-ladder-dots.pdf
```

## 本目录的程序

| 程序 | 说明 | 核验 |
|---|---|---|
| `demos/sample14_average_option.py` | Three-station worked example: rate -> differential TD -> learned option model -> action. | 通过（22 秒） |
| `demos/crl_v8_mechanisms.py` | Small, reproducible calculations for CRL teaching; not a full research agent. | 通过（9 秒） |
| `demos/crl_skill_discovery_trial.py` | Discover and test one reusable delivery skill on a single continuing trajectory. | 通过（31 秒） |
| `demos/ch21_lit_fourrooms.py` | 第 21 章文献原型：Sutton、Precup 与 Singh (1999) 的四房间。 | 通过（54 秒） |
| `demos/ch21_lit_eigenoption.py` | 第 21 章文献原型：Machado、Bellemare 与 Bowling (2017) 的 eigenoption 扩散时间。 | 通过（2 秒） |
| `demos/crl_ladder_learners.py` | 四区仓库的学习器阶梯（例子方案第三步）。 | 超时：300 秒内未跑完（启动正常） |
| `demos/crl_ch21_ladder_dots.py` | 第 21 章四区仓库：各档选项相对只用原始动作的 lifetime 奖励率差（差值点图）。 | 出错 |
| `demos/crl_ladder_world.py` | 四区仓库：第三部分的能力阶梯世界（环境与精确参照）。 | 通过（30 秒） |
| `demos/crl_ladder_world_checks.py` | 四区仓库的独立检查（照 v12 的做法：手算、枚举、独立实现互查）。 | 通过（24 秒） |
| `demos/crl_ladder_power.py` | 四区仓库学习器阶梯：试点估 σ_Δ 定种子数，正式跑后出第 24 章的账本。 | 通过（0 秒） |
| `demos/crl_ladder_ceiling.py` | 四区仓库学习器阶梯：每个试验条件的“天花板”，供账本算“离最优还差多少”。 | 超时：300 秒内未跑完（启动正常） |
| `demos/crl_ladder_figures.py` | 阶梯世界（四区仓库）阅读稿用图：地图与各章“占天花板”条形。 | 通过（1 秒） |
| `demos/crl_ladder_diagnostics.py` | 四区仓库阶梯的诊断与改法（11-20）。 | 通过（0 秒） |

被上面程序 import 的本课模块：`demos/plot_fonts.py`。

表中后 6 个程序复现附录本章一节没有列出，来自课件、阅读稿、CODE-MAP 或文件名前缀（第三部分另含学习器阶梯）。

## 第三部分的学习器阶梯（例子方案第三步）

四区仓库世界与 L0–L10 阶梯学习器。每章一个实验，三档：没有、设计者给定、从经验学到。比较都是配对的：同一种子下两档用同一份世界随机数。

```sh
python3 demos/crl_ladder_world.py --fast                     # 各区参考线，写 reference.json（全量去掉 --fast）
python3 demos/crl_ladder_world_checks.py                     # 世界本身的核对
python3 demos/crl_ladder_ceiling.py                          # 各条件的天花板（ε-软最好率），写 ceiling.json
python3 demos/crl_ladder_learners.py --exp ch21 --seeds 2 --steps 200000 --procs 2 --tag smoke   # 冒烟：写 assets/crl-ladder-world/runs/smoke-ch21.json
python3 demos/crl_ladder_learners.py --exp ch21 --seeds 49 --seed0 100 --steps 2000000 --tag formal   # 正式设置（种子数与 runs/ 里的正式记录相同）
python3 demos/crl_ladder_power.py ledger --runs formal-ch21     # 配对差与 95% 区间，写 ledger-formal-ch21.json
python3 demos/crl_ladder_figures.py ch21                       # 阅读稿用的地图与条形图（读账本）
```

参考记录在 `assets/crl-ladder-world/runs/`（随本目录复制）。正式设置一章要跑数十分钟到数小时；冒烟一行只确认程序能走通。正式结果与读法见 `assets/crl-ladder-world/README.md` 第八节，改进与诊断见第九节。

## 复现附录本章一节

本章来自本课程序的结果有：去 $C$ 子任务的训练快照与三路信号，双房间后继表示的误差，21.6 节技能去留的配对实验，四房间与 eigenoption 两个文献原型，以及 21.6 节四区仓库上不规划时三种选项与原始动作的阶梯比较；差值点图只读已有的运行记录。

“技能省在哪里”的走廊均值 $110$ 与 $2^{-10}$、$17/24$、$-5+2\times2$ 等小算例由正文推导直接算出。章首四房间同步值迭代的 20 轮与 8240 次备份，程序暂未收入本附录。Option-Critic、Eigenoptions 与 DCEO 的实现是原作者的代码，出处见表后。

| 位置 | 结果 | 设置 | 程序 | 数据与输出 |
|---|---|---|---|---|
| 21.2 节“随机执行时长与差分TD目标”“内部奖励、任务奖励与执行时长” | 去 $C$ 子任务第 1、20、2400 段训练后的内部动作价值快照；自 $t=14$ 起一次 $A\to C$ 执行的位置、内部信号、主奖励与时间计数（到 $C$ 一步奖励 3，共 6 步） | 本课的确定性模拟（种子 1429）：三站线路，部署前为三个目的站各练 2,400 个可重置回合，按每步 $-1$ 的内部信号学习，$\varepsilon=.3$，内部步长 $.25$，每回合至多 150 步，共 33,965 个原始步；部署后环境连续运行，不重置 | `demos/sample14_average_option.py` | `assets/sample14-avg-option/sample14-manifest.json`；`assets/sample14-avg-option/sample14-option-skill-updates.csv`；`assets/sample14-avg-option/sample14-option-events.csv`；图 `assets/sample14-avg-option/sample14-option-skill.png`、`assets/sample14-avg-option/sample14-option-three-signals.png` |
| 21.5 节“子目标的五种来源”后“技能占用有限容量的机会成本” | 双房间 41 个状态上的访问估计，20 万次转移后相对真后继矩阵的误差 $.0380$ | 本课的模拟（种子 141908）：均匀随机原始动作，$\gamma=.9$，逐状态步长 $.8/N(s)^{.55}$ 的 TD 更新；真后继矩阵只用于评价 | `demos/crl_v8_mechanisms.py` | `assets/crl-v8/sr-learning.csv`；`assets/crl-v8/manifest.json`（`sr_option`） |
| 21.6 节“技能的去留”（课件 ch21-keep-drop） | 每条 lifetime 排序试练减只用原始动作：试练窗口内 $-342.5\,[-376.2,-308.9]$，窗口外 $+167.8\,[73.9,261.7]$，净值 $-174.7\,[-300.7,-48.7]$，折合每步 $-.0213\,[-.0367,-.0059]$；练习约 1082 步、其间实收约 950；排序减均匀每步 $+.0848\,[.0700,.0995]$ | 本课的模拟：仓库连五条支路，每条深 3 步，到站奖励为 $1,2,3,4,6$ 的随机排列；差分 Q 学习，步长 $.15$，探索率 $.1$；一个技能名额；前 256 步共同随机探索，此后每 512 步开一个 128 步试练窗口（64 步练、64 步估计）；每条 lifetime 8192 步，配对 lifetime 独立重复 64 次，95% 配对 $t$ 区间。窗口内外的分解取 `runs.csv` 中 `window_reward`、`outside_window_reward` 两列逐种子相减 | `demos/crl_skill_discovery_trial.py` | `assets/crl-skill-discovery-trial/runs.csv`；`assets/crl-skill-discovery-trial/summary.json`；`assets/crl-skill-discovery-trial/protocol.md`；`assets/crl-skill-discovery-trial/README.md` |
| 21.2 节（课件 ch21-lit-fourrooms） | 同步值迭代准确格数（H 5 轮、A 29 轮）；SMDP Q 学习首幕与末百幕步数（G1/G2 × A、H、A∪H） | 本课的模拟：104 格四房间，动作 2/3 按意图、各 1/9 滑向其余三向，8 项门口技能，$\gamma=.9$；规划为确定的计算；学习 $\varepsilon=.1$，步长取原文各组最佳，30 次独立运行，各 1000 幕 | `demos/ch21_lit_fourrooms.py` | `assets/ch21-lit-fourrooms/results.json` |
| 21.5 节（课件 ch21-lit-eigenoption） | 扩散时间：动作 620.8，$k=2$ 至 128 项 eigenoption，瓶颈 option 1864.1；第 5 个特征向量的停点 | 本课的计算：同一布局、确定性移动，归一化拉普拉斯特征向量正反两向，内部折扣 .9；解线性方程，无随机误差 | `demos/ch21_lit_eigenoption.py` | `assets/ch21-lit-eigenoption/results.json` |
| 21.6 节（课件 `ch21-ladder`） | 不规划时，三种选项与只用原始动作的 lifetime 奖励率差都在 $\pm.002$ 以内（差值点图） | 本课的模拟：四区仓库，200 万步，49 个种子，同种子配对 t 区间；点图只读已有运行记录 | `demos/crl_ladder_learners.py` 实验 `ch21`；`demos/crl_ch21_ladder_dots.py` | `assets/crl-ladder-world/runs/formal-ch21.json`、`assets/crl-ladder-world/fig/ch21-ladder-dots.pdf` |

运行：
```sh
python3 demos/sample14_average_option.py           # 写 assets/sample14-avg-option
python3 demos/crl_v8_mechanisms.py --figures       # 写 assets/crl-v8，含 sr-learning.png
python3 demos/crl_skill_discovery_trial.py         # 64 对 × 8192 步，写 assets/crl-skill-discovery-trial
python3 demos/ch21_lit_fourrooms.py        # 文献原型：四房间，写 assets/ch21-lit-fourrooms
python3 demos/ch21_lit_eigenoption.py      # 文献原型：eigenoption，写 assets/ch21-lit-eigenoption
python3 demos/crl_ladder_learners.py --exp ch21 --seeds 49 --seed0 100 --steps 2000000 --tag formal   # 写 assets/crl-ladder-world/runs/formal-ch21.json
python3 demos/crl_ch21_ladder_dots.py      # 读 formal-ch21.json，写 assets/crl-ladder-world/fig/ch21-ladder-dots.pdf
```

外部代码（出处）：21.4 节 Option-Critic 的四房间迁移实验链接到作者仓库 jeanharb/option_critic 中的 `transfer.py`；21.5 节 Eigenoptions 一节的实现见 Machado 等的仓库 mcmachado/options，DCEO 一节见 mklissa/dceo。

## 参考数据

`assets/`（以及 `demos/NN-results/`）下复制了 115 个数据文件（json、csv 等），即课程目前使用的结果；图片没有复制，运行程序会重新画出。重跑会覆盖这些文件，可以先另存一份再对照。
