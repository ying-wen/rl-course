"""Choose an installed CJK font for the Chinese teaching figures."""
import os
from pathlib import Path
from matplotlib import font_manager


def chinese_font():
    """Return FontProperties; CRL_CJK_FONT can select a local .ttf/.otf/.ttc."""
    explicit = os.environ.get('CRL_CJK_FONT')
    if explicit:
        path = Path(explicit).expanduser()
        if not path.is_file():
            raise FileNotFoundError(path)
        font_manager.fontManager.addfont(str(path))
        return font_manager.FontProperties(fname=str(path))
    # Preserve the font used for the supplied figures when it is available.
    mac_font = Path('/System/Library/Fonts/STHeiti Light.ttc')
    if mac_font.is_file():
        return font_manager.FontProperties(fname=str(mac_font))
    preferred = ['Noto Sans CJK SC', 'Source Han Sans SC', 'Microsoft YaHei',
                 'PingFang SC', 'SimHei', 'WenQuanYi Zen Hei', 'FandolHei']
    for name in preferred:
        for entry in font_manager.fontManager.ttflist:
            if entry.name == name:
                return font_manager.FontProperties(fname=entry.fname)
    raise RuntimeError('Install Noto Sans CJK SC or set CRL_CJK_FONT to a Chinese font file.')


# 11-21 审阅站请求 r1121-110741（第 4 章总评·排版②）：图内字体与课件一致。
TEXLIVE_FONTS = [
    'fonts/opentype/public/lm/lmsans10-regular.otf',
    'fonts/opentype/public/lm/lmsans10-bold.otf',
    'fonts/opentype/public/lm/lmsans10-oblique.otf',
    'fonts/opentype/public/fandol/FandolHei-Regular.otf',
    'fonts/opentype/public/fandol/FandolHei-Bold.otf',
]


CJK_FAMILY = 'FandolHei'


def use_course_fonts():
    """Use the slide fonts in matplotlib: Latin Modern Sans for Latin text and
    digits, FandolHei for Chinese. Size rule for callers: a figure of width W
    inches shown at width w cm on the slide scales text by w/(2.54*W); pick
    font sizes so ticks land at >= 7pt and labels at >= 8pt after scaling.
    A label that mixes Chinese with $math$ is typeset by mathtext with one
    font only, so pass fontfamily=CJK_FAMILY to that call, e.g.
    ax.set_xlabel('轮数 $k$', fontfamily=CJK_FAMILY).
    Returns True when all fonts were found."""
    import subprocess
    import matplotlib.pyplot as plt
    found = []
    try:
        root = subprocess.run(['kpsewhich', '-var-value=TEXMFDIST'],
                              capture_output=True, text=True).stdout.strip()
    except OSError:
        root = ''
    for rel in TEXLIVE_FONTS:
        path = Path(root) / rel if root else None
        if path and path.is_file():
            font_manager.fontManager.addfont(str(path))
            found.append(rel)
    plt.rcParams.update({'font.family': ['Latin Modern Sans', 'FandolHei'],
                         'mathtext.fontset': 'custom',
                         'mathtext.rm': 'Latin Modern Sans',
                         'mathtext.it': 'Latin Modern Sans:oblique',
                         'mathtext.bf': 'Latin Modern Sans:bold',
                         'pdf.fonttype': 42})
    return len(found) == len(TEXLIVE_FONTS)


def no_leading_zero(x, _pos=None):
    """Tick formatter: .5 rather than 0.5, matching the slide text."""
    s = f'{x:g}'
    if s.startswith('0.'):
        return s[1:]
    if s.startswith('-0.'):
        return '-' + s[2:]
    return s
