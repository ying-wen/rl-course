"""11-21 请求 r1121-124959（第 14 章 14.5 节）各页数字的复算。

不作图，只打印：
  emb-imagination      吸收态例子的回报误差与误差界 H(H+1)/2 * eps
  ch14-imagine-practice T=100 与 H=5 的误差界
  ch14-model-judge     N 个标准正态最大值的期望 m_N（数值积分）
  ch14-sys-wam-rank    m_N 换算的 delta 估计
  emb-domain-randomization 地面 x 策略 表的期望成功率
  emb-occupancy        沿新策略轨迹的优势与伸缩求和
"""
import math


def _pdf(x):
    return math.exp(-x * x / 2) / math.sqrt(2 * math.pi)


def _cdf(x):
    return .5 * (1 + math.erf(x / math.sqrt(2)))


def imagination(eps=.01):
    print("emb-imagination：真机每步得 1，模型每步以 eps 漏到零分吸收态")
    for H in (5, 10, 15, 20, 25, 30):
        err = sum(1 - (1 - eps) ** k for k in range(1, H + 1))
        bound = H * (H + 1) / 2 * eps
        print(f"  H={H:2d}  误差={err:.4f}  界={bound:.4f}  比={err / bound:.3f}  线性={H * eps:.2f}")


def imagine_practice(eps=.01, T=100, H=5):
    print("ch14-imagine-practice：")
    print(f"  T={T}: 界={T * (T + 1) / 2 * eps:.2f}（回报范围 0..{T}）  H={H}: 界={H * (H + 1) / 2 * eps:.2f}")


def m_N(N):
    # 复合 Simpson 积分，区间 [-12, 12]，步长 1e-3
    a, b, n = -12.0, 12.0, 24000
    h = (b - a) / n
    f = lambda x: x * N * _pdf(x) * _cdf(x) ** (N - 1)
    tot = f(a) + f(b)
    for i in range(1, n):
        tot += (4 if i % 2 else 2) * f(a + i * h)
    return tot * h / 3


def model_judge():
    print("ch14-model-judge：m_N = E[max of N 个标准正态]")
    for N in (2, 5, 10, 100, 1000):
        print(f"  N={N:4d}  m_N={m_N(N):.4f}  log10 N={math.log10(N):.3f}")


def domain_randomization():
    print("emb-domain-randomization：高、低摩擦各 .5")
    p_hi = .5
    steady = (.7, .7)
    fast = (.9, .4)
    probe_cost = .02
    rows = {
        "稳步": p_hi * steady[0] + (1 - p_hi) * steady[1],
        "快步": p_hi * fast[0] + (1 - p_hi) * fast[1],
        "先试一步再选": p_hi * max(steady[0], fast[0]) + (1 - p_hi) * max(steady[1], fast[1]) - probe_cost,
    }
    for k, v in rows.items():
        print(f"  {k}: {v:.2f}")
    # 宽度的作用：低摩擦比例 q 变化时，不读历史的最优策略
    for q in (0, .2, .4, .5, .6, .8):
        s = .7
        f = (1 - q) * .9 + q * .4
        print(f"  低摩擦占 {q:.1f}: 稳步 {s:.2f} 快步 {f:.2f} -> 不读历史选 {'快步' if f > s else '稳步'}")


def occupancy():
    print("emb-occupancy：新策略的一条确定轨迹，奖励只在第 5 步（成功记 1）")
    v = [.50, .55, .75, .60, .70, 0.0]   # 基线价值 v_pi(h_i)，截止处为 0
    R = [0, 0, 0, 0, 1]
    A = [R[i] + v[i + 1] - v[i] for i in range(5)]
    for i, a in enumerate(A):
        print(f"  步 {i}: R={R[i]}  v(h_i)={v[i]:.2f}  v(h_i+1)={v[i + 1]:.2f}  A={a:+.2f}")
    print(f"  优势之和={sum(A):.2f}  J(pi')-J(pi)={sum(R) - v[0]:.2f}")


if __name__ == "__main__":
    imagination()
    imagine_practice()
    model_judge()
    domain_randomization()
    occupancy()
