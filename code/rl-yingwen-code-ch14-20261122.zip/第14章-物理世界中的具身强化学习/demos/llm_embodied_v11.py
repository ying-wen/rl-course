#!/usr/bin/env python3
"""Four finite checks for chapter 13; no LLM or robot training.

python3 demos/llm_embodied_v11.py          # standard library, JSON and CSV
python3 demos/llm_embodied_v11.py --figures # additionally requires matplotlib
Paths are relative to this file, so both commands work from any directory.
"""
import argparse
import csv
import itertools
import json
import math
from pathlib import Path


def close(a, b, tol=1e-8):
    assert abs(a - b) < tol, (a, b)


def fd(f, x, h=1e-6):
    return (f(x + h) - f(x - h)) / (2 * h)


def group_gradient(ys, p, kind):
    """r=y, score=d log Bernoulli(sigmoid(theta))/d theta = y-p."""
    n = len(ys)
    mean = sum(ys) / n
    std = math.sqrt(sum((y - mean) ** 2 for y in ys) / n)
    if kind == 'rloo':
        weights = [y - (sum(ys) - y) / (n - 1) for y in ys]
    elif kind == 'centered':
        weights = [y - mean for y in ys]
    elif kind == 'standardized':
        weights = [(y - mean) / std if std else 0.0 for y in ys]
    else:
        weights = list(ys)
    return sum(w * (y - p) for w, y in zip(weights, ys)) / n


def enumerate_groups(p, n=4):
    kinds = ['rloo', 'centered', 'standardized']
    result = {k: 0.0 for k in kinds}
    for ys in itertools.product([0, 1], repeat=n):
        prob = math.prod(p if y else 1 - p for y in ys)
        for kind in kinds:
            result[kind] += prob * group_gradient(ys, p, kind)
    return result


def gaussian_logpdf(x, mean, variance):
    return -.5 * (math.log(2 * math.pi * variance) + (x - mean) ** 2 / variance)


def run(out, figures=False):
    out.mkdir(parents=True, exist_ok=True)
    rows = []
    for i in range(1, 100):
        p = i / 100
        ans = enumerate_groups(p)
        true = p * (1 - p)
        close(ans['rloo'], true)
        close(ans['centered'], .75 * true)
        # Independent derivative of success probability, rather than score algebra.
        theta = math.log(p / (1 - p))
        close(fd(lambda z: 1 / (1 + math.exp(-z)), theta), true)
        rows.append([p, true, ans['rloo'], ans['centered'], ans['standardized']])
    with (out / 'group-expectations.csv').open('w', newline='') as f:
        w = csv.writer(f)
        w.writerow(['success_p', 'true_gradient', 'rloo', 'centered', 'standardized'])
        w.writerows(rows)
    sample = [0, 1, 1, 0]
    sample_g = {k: group_gradient(sample, .5, k)
                for k in ['rloo', 'centered', 'standardized']}
    close(sample_g['rloo'], 1 / 3)
    close(sample_g['centered'], .25)
    close(sample_g['standardized'], .5)

    # Two-token sequences: old Bernoulli(.5), target Bernoulli(.8).
    ratios = []
    for ys in itertools.product([0, 1], repeat=2):
        ratio = math.prod((.8 if y else .2) / .5 for y in ys)
        ratios.append({'tokens': list(ys), 'old_probability': .25,
                       'exact_ratio': ratio, 'gspo_weight': math.sqrt(ratio)})
    close(sum(x['exact_ratio'] * .25 for x in ratios), 1.)
    close(sum(x['gspo_weight'] * .25 for x in ratios), .9)

    # Positive-advantage clipping: behavior .2, proximal .4, current .44.
    naive = lambda q: min(q / .2, max(.8, min(1.2, q / .2)))
    decoupled = lambda q: 2 * min(q / .4, max(.8, min(1.2, q / .4)))
    close(fd(naive, .44), 0.)
    close(fd(decoupled, .44), 5.)

    # Latent path: z1~N(theta,.25), a~N(z1,.25), reward=-(a-.5)^2.
    # Marginal a~N(theta,.5); exact expected return = -(theta-.5)^2-.5.
    z1, action, theta = .2, .6, 0.
    path_logp = lambda th: gaussian_logpdf(z1, th, .25) + gaussian_logpdf(action, z1, .25)
    marginal_logp = lambda th: gaussian_logpdf(action, th, .5)
    close(fd(path_logp, theta), .8)
    close(fd(marginal_logp, theta), 1.2)
    # Independent deterministic integration of the path-score estimator.
    h = .05
    grid = [i * h for i in range(-80, 81)]
    integrated = 0.
    for e1 in grid:
        for e2 in grid:
            a = theta + e1 + e2
            density = math.exp(gaussian_logpdf(e1, 0, .25) + gaussian_logpdf(e2, 0, .25))
            integrated += density * (-(a - .5) ** 2) * (e1 / .25) * h * h
    expected = lambda th: -(th - .5) ** 2 - .5
    close(integrated, fd(expected, theta), 1e-7)
    results = {
        'status': 'pass',
        'scope': 'Exact enumeration, finite differences and Gaussian quadrature; no model training.',
        'group_size': 4,
        'sample_rewards': sample,
        'sample_gradients': sample_g,
        'expected_at_p_half': enumerate_groups(.5),
        'sequence_ratios': ratios,
        'gspo_expected_weight': .9,
        'async_positive_advantage': {'naive_value': naive(.44), 'decoupled_value': decoupled(.44),
                                    'naive_derivative': fd(naive, .44), 'decoupled_derivative': fd(decoupled, .44)},
        'latent_path': {'z1': z1, 'executed_action': action, 'path_score': .8, 'marginal_score': 1.2,
                        'expected_reward_gradient_fd': fd(expected, theta),
                        'path_gradient_quadrature': integrated},
    }
    (out / 'checks.json').write_text(json.dumps(results, indent=2) + '\n')
    if figures:
        render(rows, sample_g, out)
    print(json.dumps(results, indent=2))


def render(rows, sample_g, out):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from matplotlib import font_manager
    font = Path('/System/Library/Fonts/Supplemental/Arial Unicode.ttf')
    if font.exists():
        font_manager.fontManager.addfont(str(font))
        plt.rcParams['font.family'] = font_manager.FontProperties(fname=str(font)).get_name()
    plt.rcParams.update({'font.size': 12, 'axes.spines.top': False, 'axes.spines.right': False,
                         'axes.unicode_minus': False, 'svg.fonttype': 'path'})
    ink, teal, red, gold = '#182e38', '#087e8b', '#c65335', '#c4942a'
    fig, axes = plt.subplots(1, 2, figsize=(12.4, 4.1), gridspec_kw={'width_ratios': [1, 1.25]})
    ax = axes[0]
    ax.set_title('同一批结果：0, 1, 1, 0', color=ink, loc='left')
    vals = [sample_g[k] for k in ['centered', 'rloo', 'standardized']]
    ax.barh(['组均值中心化', '留一基线 RLOO', '再除组标准差'], vals, color=[gold, teal, red], height=.54)
    for j, v in enumerate(vals): ax.text(v + .012, j, f'{v:.3f}', va='center', color=ink)
    ax.set_xlim(0, .61); ax.set_xlabel('本批 logit 梯度'); ax.invert_yaxis()
    ax.text(.01, -.32, 'p = 0.5；每条回答 score = y − p\n不含KL、裁剪与长度归一化', transform=ax.transAxes, fontsize=11, color=ink)
    ax = axes[1]
    ax.set_title('枚举全部16组：期望方向', color=ink, loc='left')
    xs = [r[0] for r in rows]
    ax.plot(xs, [r[1] for r in rows], color=ink, lw=4, alpha=.25, label='真实梯度 p(1−p)')
    ax.plot(xs, [r[2] for r in rows], color=teal, lw=2, linestyle='--', label='RLOO')
    ax.plot(xs, [r[3] for r in rows], color=gold, lw=2, label='组均值中心化')
    ax.plot(xs, [r[4] for r in rows], color=red, lw=2, label='再除组标准差')
    ax.set_xlabel('下一次生成正确程序的概率 p'); ax.set_ylabel('期望 logit 梯度')
    ax.set_xlim(0, 1); ax.set_ylim(0, .47); ax.legend(fontsize=10, frameon=False, loc='upper left')
    fig.subplots_adjust(bottom=.25, left=.14, right=.98, top=.86, wspace=.43)
    for ext in ['png', 'pdf', 'svg']:
        fig.savefig(out / f'group-gradients.{ext}', dpi=180, facecolor='white', bbox_inches='tight')
    plt.close(fig)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, default=Path(__file__).resolve().parents[1] / 'assets/llm-embodied-v11')
    parser.add_argument('--figures', action='store_true')
    args = parser.parse_args()
    run(args.output, args.figures)
