"""14.4 误差会不会累积：三条误差带（11-21 请求 r1121-124959，第 1355 页）。

与示范轨迹的偏差 d_t 按 d_{t+1} = c * d_t + eps 演化，每步新增偏差 eps：
  c = L > 1  底层不稳定：d_t = eps (L^t - 1)/(L - 1)，指数放大；
  c = 1      没有纠正（积分）：d_t = eps t，线性；累计损失 sum_t eps t ~ eps H^2 / 2；
  c = rho<1  增量稳定：d_t = eps (1 - rho^t)/(1 - rho) <= eps/(1 - rho)。
运行：python3 demos/ch14_s4_error_bands.py  →  assets/ch14-r21/error-bands.pdf
"""
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter
from plot_fonts import use_course_fonts, no_leading_zero, CJK_FAMILY

EPS, L, RHO, H = .01, 1.05, .9, 100
ROOT = Path(__file__).resolve().parents[1]


def deviation(c, t):
    d = np.zeros_like(t, dtype=float)
    for i in range(1, len(t)):
        d[i] = c * d[i - 1] + EPS
    return d


def main():
    use_course_fonts()
    t = np.arange(H + 1)
    unstable, integ, stable = deviation(L, t), deviation(1., t), deviation(RHO, t)
    # 闭式核对
    assert np.allclose(integ, EPS * t)
    assert np.allclose(unstable, EPS * (L ** t - 1) / (L - 1))
    assert np.allclose(stable, EPS * (1 - RHO ** t) / (1 - RHO))
    ymax = 1.3
    fig, ax = plt.subplots(figsize=(3.9, 2.35))
    cols = {'u': '#B23A3A', 'i': '#C08A1E', 's': '#1F7A7A'}
    for d, c in ((unstable, cols['u']), (integ, cols['i']), (stable, cols['s'])):
        dd = np.minimum(d, ymax)
        ax.fill_between(t, -dd, dd, color=c, alpha=.18, lw=0)
        ax.plot(t, dd, color=c, lw=1.3)
        ax.plot(t, -dd, color=c, lw=1.3)
    ax.axhline(0, color='#333333', lw=1.1)
    t_out = int(np.argmax(unstable > ymax))
    ax.text(3, .95, f'不稳定 $L={L:g}$\n$t={t_out}$ 起出图', color=cols['u'],
            fontsize=8.5, fontfamily=CJK_FAMILY, va='center')
    ax.text(84, .93, r'无纠正 $\varepsilon t$', color=cols['i'], fontsize=8.5,
            fontfamily=CJK_FAMILY, ha='center')
    ax.text(70, .2, rf'增量稳定 $\rho={no_leading_zero(RHO)}$：$\leq \varepsilon/(1-\rho)$'
            rf'$={no_leading_zero(EPS / (1 - RHO))}$', color=cols['s'], fontsize=8.5,
            fontfamily=CJK_FAMILY, ha='center')
    ax.text(2, -1.18, rf'示范轨迹（$d=0$），每步新增偏差 $\varepsilon={no_leading_zero(EPS)}$',
            fontsize=8, fontfamily=CJK_FAMILY, color='#333333')
    ax.set_xlim(0, H); ax.set_ylim(-ymax, ymax)
    ax.set_xlabel('时间步 $t$', fontsize=9, fontfamily=CJK_FAMILY)
    ax.set_ylabel('与示范的偏差 $d_t$', fontsize=9, fontfamily=CJK_FAMILY)
    ax.yaxis.set_major_formatter(FuncFormatter(no_leading_zero))
    ax.tick_params(labelsize=8)
    for s in ('top', 'right'):
        ax.spines[s].set_visible(False)
    fig.tight_layout(pad=.3)
    out = ROOT / 'assets/ch14-r21/error-bands.pdf'
    out.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(out)
    print(out, 'unstable d_H=%.2f integ d_H=%.2f stable d_H=%.4f t_out=%d'
          % (unstable[-1], integ[-1], stable[-1], t_out))


if __name__ == '__main__':
    main()
