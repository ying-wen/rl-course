"""Two classroom figures for section 14.3 (measurement of reward).

Run from rl-course:
    python demos/ch14_r21_measurement.py

Writes
    assets/ch14-r21/shaping-potential.pdf  (page emb-reward-shaping)
    assets/ch14-r21/audit-weights.pdf      (page ch14-random-audit)

11-21 审阅站请求 r1121-124959（第 14 章，1335 与 1341 的图示建议）。
All numbers are teaching values computed here; none come from a paper.
"""
from pathlib import Path
import sys

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter

sys.path.insert(0, str(Path(__file__).resolve().parent))
from plot_fonts import use_course_fonts, CJK_FAMILY, no_leading_zero  # noqa: E402

TEAL = "#1f7a7a"
GOLD = "#b8860b"
RED = "#b03a2e"
MUTED = "#7f8c8d"
OUT = Path(__file__).resolve().parent.parent / "assets" / "ch14-r21"


def shaping_example():
    """Plug-insertion path: camera distance d_i (cm) at six decisions.

    Phi(h_i, L_i) = -.1 d_i while L_i > 0, and Phi = 0 once L <= 0 (after
    the deadline).  The task reward is 1 only at delivery (last decision).
    """
    d = np.array([6, 4, 5, 3, 1, 0], dtype=float)
    phi = -.1 * d
    phi_next = np.append(phi[1:], 0.0)        # after the last decision L <= 0
    F = phi_next - phi
    R = np.zeros_like(d)
    R[-1] = 1.0
    Rs = R + F
    assert abs(Rs.sum() - (R.sum() - phi[0])) < 1e-12
    return d, phi, F, R, Rs


def plot_shaping():
    d, phi, F, R, Rs = shaping_example()
    i = np.arange(len(d))
    fig, (a1, a2) = plt.subplots(1, 2, figsize=(6.4, 1.5),
                                 gridspec_kw={"width_ratios": [1, 1.25]})
    # left: potential along the path, with the value after the deadline
    a1.step(np.append(i, len(d)), np.append(phi, 0.0), where="post",
            color=TEAL, lw=1.4)
    a1.plot(i, phi, "o", color=TEAL, ms=3.5)
    a1.plot([len(d)], [0.0], "o", mfc="white", mec=TEAL, ms=3.5)
    a1.annotate("截止后 Φ = 0", (len(d), 0), (4.55, -.27),
                fontsize=8.5, color=MUTED, fontfamily=CJK_FAMILY,
                arrowprops=dict(arrowstyle="-", color=MUTED, lw=.6))
    a1.annotate("退后一步", (2, phi[2]), (2.35, -.58), fontsize=8.5,
                color=RED, fontfamily=CJK_FAMILY,
                arrowprops=dict(arrowstyle="-", color=RED, lw=.6))
    a1.set_ylim(-.68, .1)
    a1.set_xlim(-.4, len(d) + .4)
    a1.set_xticks(range(len(d) + 1))
    a1.set_xlabel("决策序号 $i$", fontfamily=CJK_FAMILY, fontsize=9)
    a1.set_title("势 Φ = -.1 × 距离（厘米）", fontfamily=CJK_FAMILY,
                 fontsize=9, color=TEAL, loc="left")
    # right: per-step rewards before and after shaping
    w = .38
    a2.bar(i - w / 2, R, w, color=MUTED, alpha=.55, label="验收奖励 $R_i$")
    a2.bar(i + w / 2, Rs, w, color=TEAL, label="塑形后 $R_i'$")
    for k in i:
        a2.text(k + w / 2, Rs[k] + (.03 if Rs[k] >= 0 else -.12),
                no_leading_zero(round(Rs[k], 2)), ha="center", fontsize=7.5,
                color=TEAL)
    a2.axhline(0, color=MUTED, lw=.6)
    a2.set_ylim(-.25, 1.25)
    a2.set_xticks(i)
    a2.set_xlabel("决策序号 $i$", fontfamily=CJK_FAMILY, fontsize=9)
    a2.text(.02, .97, "$\\sum R_i=1$，$\\sum R_i'=1.6$，差 $-\\Phi(h_0,T)$ = .6",
            transform=a2.transAxes, va="top", fontsize=8.5,
            fontfamily=CJK_FAMILY)
    leg = a2.legend(loc="center left", fontsize=8, frameon=False,
                    bbox_to_anchor=(0, .55), prop={"family": CJK_FAMILY,
                                                   "size": 8})
    for ax in (a1, a2):
        ax.yaxis.set_major_formatter(FuncFormatter(no_leading_zero))
        ax.tick_params(labelsize=8)
        for sp in ("top", "right"):
            ax.spines[sp].set_visible(False)
    fig.tight_layout(pad=.3, w_pad=1.2)
    fig.savefig(OUT / "shaping-potential.pdf")
    plt.close(fig)
    print("shaping: F =", np.round(F, 2), "sum R' =", round(Rs.sum(), 2))


def audit_population():
    """12 plugs: 8 look good (7 conduct), 4 look suspicious (1 conducts)."""
    Y = np.array([1] * 7 + [0] + [1] + [0] * 3)
    s = np.array([.25] * 8 + [.75] * 4)
    return Y, s


def plot_audit(draws=200_000, seed=0):
    Y, s = audit_population()
    N = len(Y)
    rng = np.random.default_rng(seed)
    D = rng.random((draws, N)) < s
    ht = (D * Y / s).sum(1) / N
    k = D.sum(1)
    ok = k > 0
    naive = (D * Y).sum(1)[ok] / k[ok]
    var_exact = (Y * (1 - s) / s).sum() / N ** 2
    print("audit: true", round(Y.mean(), 3), "HT mean", round(ht.mean(), 3),
          "HT sd", round(ht.std(), 3), "exact sd", round(np.sqrt(var_exact), 3),
          "naive mean", round(naive.mean(), 3), "naive sd", round(naive.std(), 3))

    fig, (a1, a2) = plt.subplots(1, 2, figsize=(6.4, 1.35),
                                 gridspec_kw={"width_ratios": [1.3, 1]})
    rows = [("按 $1/s$ 加权", ht, TEAL, 1.0), ("受验件直接平均", naive, RED, 0.0)]
    for name, est, col, y in rows:
        m, sd = est.mean(), est.std()
        a1.plot([m - sd, m + sd], [y, y], color=col, lw=2.2, alpha=.55,
                solid_capstyle="butt")
        a1.plot(m, y, "o", color=col, ms=5)
        a1.text(-.08, y, name, ha="right", va="center", fontsize=8.5,
                color=col, fontfamily=CJK_FAMILY)
        a1.text(min(m, Y.mean() - .22), y + .2, f"均值 {no_leading_zero(round(m, 2))}，"
                f"标准差 {no_leading_zero(round(sd, 2))}", ha="center",
                fontsize=7.5, color=col, fontfamily=CJK_FAMILY)
    a1.axvline(Y.mean(), color="black", lw=.8, ls="--")
    a1.text(Y.mean() + .02, -.55, "真值 .67", fontsize=8,
            fontfamily=CJK_FAMILY)
    a1.set_ylim(-.62, 1.38)
    a1.set_xlim(0, 1.1)
    a1.set_yticks([])
    a1.spines["left"].set_visible(False)
    a1.set_xlabel("一次抽验的导通率估计：均值与 ±1 标准差", fontfamily=CJK_FAMILY,
                  fontsize=9)

    # right: standard error of the weighted mean, uniform s, n = 100, p = .7
    p, n = .7, 100
    inv = np.linspace(1, 10, 200)
    se = np.sqrt((p * inv - p * p) / n)
    a2.plot(inv, se, color=GOLD, lw=1.4)
    for sv in (1, .5, .25, .1):
        v = np.sqrt((p / sv - p * p) / n)
        a2.plot(1 / sv, v, "o", color=GOLD, ms=3.5)
        off = (-1.6, -.05) if sv == .1 else (.25, -.045)
        a2.annotate(f"$s$ = {no_leading_zero(sv)}", (1 / sv, v),
                    (1 / sv + off[0], v + off[1]), fontsize=7.5)
    a2.set_xlabel("单件权重 $1/s$", fontfamily=CJK_FAMILY, fontsize=9)
    a2.set_ylabel("标准误", fontfamily=CJK_FAMILY, fontsize=9)
    a2.set_title("100 件、导通率 .7", fontfamily=CJK_FAMILY, fontsize=8.5,
                 loc="left", color=MUTED)
    a2.set_ylim(0, .3)
    for ax in (a1, a2):
        ax.xaxis.set_major_formatter(FuncFormatter(no_leading_zero))
        ax.yaxis.set_major_formatter(FuncFormatter(no_leading_zero))
        ax.tick_params(labelsize=8)
        for sp in ("top", "right"):
            ax.spines[sp].set_visible(False)
    fig.tight_layout(pad=.3, w_pad=1.2)
    fig.savefig(OUT / "audit-weights.pdf")
    plt.close(fig)
    for sv in (1, .5, .25, .1):
        print(f"  s={sv}: se={np.sqrt((p / sv - p * p) / n):.4f}")


if __name__ == "__main__":
    use_course_fonts()
    OUT.mkdir(parents=True, exist_ok=True)
    plot_shaping()
    plot_audit()
