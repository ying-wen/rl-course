# 第 14 章　物理世界中的具身强化学习：程序

本目录可以单独运行：在本目录下执行下面的命令即可，结果写回本目录的 `assets/`。目录由 `rl-course/tools/export_chapter_code.py` 从课程目录生成，改程序请改课程目录里的原件，再重新导出。

## 准备

```sh
python3 -m pip install -r requirements.txt
```

需要的第三方包：matplotlib、numpy；只有个别程序需要的：PIL（draw_mixed_trace.py、r1lite_response.py）、duckdb（extract_mixed_trace.py、r1lite_response.py）、playwright（print_figures.py）。复现附录要求 Python 3.10 或更新版本；核验时用的版本见下表。

## 运行（与复现附录相同）

```sh
python3 textbook/embodied/src/layer_latency.py         # 只打印
python3 textbook/embodied/src/extract_mixed_trace.py   # 从 Hugging Face 下载指定修订的源文件；需 duckdb、ffmpeg、ffprobe
python3 textbook/embodied/src/draw_mixed_trace.py
python3 textbook/embodied/src/r1lite_response.py       # 可加 --capture-from、--wrist-video 重新摘录
python3 demos/llm_embodied_v11.py --figures            # 写 assets/llm-embodied-v11
python3 demos/ch14_s4_error_bands.py                   # 写 assets/ch14-r21/error-bands.pdf
python3 demos/ch14_s5_r21_numbers.py                   # 只打印
python3 textbook/embodied/src/physical_diagnosis20.py
python3 textbook/embodied/src/physical_discovery11.py
```

## 本目录的程序

| 程序 | 说明 | 核验 |
|---|---|---|
| `demos/llm_embodied_v11.py` | Four finite checks for chapter 13; no LLM or robot training. | 通过（1 秒） |
| `demos/ch14_s4_error_bands.py` | 14.4 误差会不会累积：三条误差带（11-21 请求 r1121-124959，第 1355 页）。 | 通过（1 秒） |
| `demos/ch14_s5_r21_numbers.py` | 11-21 请求 r1121-124959（第 14 章 14.5 节）各页数字的复算。 | 通过（0 秒） |
| `textbook/embodied/src/layer_latency.py` | 分层系统的三个算例（第 14 章“按时间尺度分层”一小节）。 | 通过（77 秒） |
| `textbook/embodied/src/extract_mixed_trace.py` | Extract the fixed R1Lite episode and three synchronized head-camera frames. | 需要联网从 Hugging Face 下载源文件，核验时跳过 |
| `textbook/embodied/src/draw_mixed_trace.py` | Draw the intervention evidence from the packaged frames and numeric record. | 需要可选包 playwright（见 requirements.txt 的注释行），核验环境未装 |
| `textbook/embodied/src/r1lite_response.py` | One-interval prediction on one public R1Lite trajectory, without task rewards. | 通过（1 秒） |
| `textbook/embodied/src/physical_diagnosis20.py` | A continuing workcell with ambiguous grasp failures. Run with Python 3 + NumPy. | 通过（5 秒） |
| `textbook/embodied/src/physical_discovery11.py` | Continuous workcell. Run python3 src/physical_discovery11.py from any directory. | 通过（10 秒） |
| `demos/ch14_r21_measurement.py` | Two classroom figures for section 14.3 (measurement of reward). | 通过（1 秒） |

被上面程序 import 的本课模块：`demos/plot_fonts.py`、`textbook/embodied/src/draw_physical_world.py`、`textbook/embodied/src/print_figures.py`。

表中后 1 个程序复现附录本章一节没有列出，来自课件、阅读稿、CODE-MAP 或文件名前缀（第三部分另含学习器阶梯）。

## 复现附录本章一节

本章来自本课程序的结果有：14.1 节的时延与镇定边界；14.3 节公开真机记录 R1Lite 的接管片段及其逐帧时钟；14.4 节模仿误差的三条误差带；14.5 节生成路径梯度的数值核对，以及想象回报误差与模型评判几页的复算；14.7 节两页部署实验（同样工时下的诊断方式、lifetime 内的技能发现）。

人工接管加权中的 $.78\to.60$、语言智能体重试一例（$.57\to.83$、$1.135$）、吞吐表（$162$、$192$、$124.6$、$106.7$、$13.8$、$26.7$）、系统 3 的定价例、探测价值 $.11$、数据飞轮一例（$.664$、$.738$）与自测题中的数，由正文推导直接算出。UniVTAC、HIL-SERL、Veo、RLT、QT-Opt、Helix 等系统的数字引自文献，不列入表中。

接口图 `interface.svg` 与信用分配图 `credit.svg` 由 `textbook/embodied/src/draw.py` 绘制；物理时间与重置、问题设定核、视觉语言动作命令接口三张示意图只有图文件。这些图都不含计算结果。

| 位置 | 结果 | 设置 | 程序 | 数据与输出 |
|---|---|---|---|---|
| 14.1 节“第二种划分：按时间尺度分层”；课件 emb-layers-latency | $\omega=\sqrt{g/z}=3.30\,\mathrm{s^{-1}}$；时延 1 毫秒、20 毫秒、100 毫秒、1 秒时偏差放大 $1.003$、$1.07$、$1.39$、$27.2$ 倍；带时延比例反馈下，$\omega\ell=.3$ 时 $K$ 可取 1 到 4.6，$\omega\ell=.9$ 时只剩 1 到 1.14，$\omega\ell\ge1$ 时无增益可镇定；接触力超调 20 毫秒为 20 牛、1 秒为 1,000 牛 | 本课的计算：线性倒立摆发散分量，质心高 $.90$ 米，$g=9.81$；反馈 $p(t)=K\,\xi(t-\ell)$，初值与历史均取 $\xi=1$，欧拉积分步长 $10^{-4}$ 秒、共 20 秒，末 $20\%$ 时段 $\lvert\xi\rvert$ 峰值小于 $.5$ 判为镇定；$K$ 取 $1.02$ 到 $4.98$、间隔 $.02$；$\omega\ell$ 取 $.3$、$.6$、$.9$、$1.1$、$1.5$；接触刚度 $10^4$ 牛每米、接近速度 $.1$ 米每秒；确定性计算，无随机重复 | [embodied/src/layer_latency.py](embodied/src/layer_latency.py) | 不写文件，结果打印在终端 |
| 14.3 节“部分验收与人工接管”（图 `mixed-trace.svg`） | R1Lite 第 0 段共 473 帧、每秒 15 帧；第 0–368 帧由策略控制，第 369–404 帧人工接管，第 405–472 帧交还策略；头部相机第 355、397、423 帧；第 14 个关节分量的命令与读数曲线 | 公开真机记录的逐帧摘录：BodenAI RW-RL-HIL-Dataset，修订 `9290f5a96dc91ea58256e81d9ce2dd9621890b51`，第 0 段；摘录时核对源文件的 SHA-256；`action.qpos` 与 `observations.state.qpos` 取第 14 个分量；无模拟，无随机重复 | [embodied/src/extract_mixed_trace.py](embodied/src/extract_mixed_trace.py)（摘录与选帧，需 duckdb、ffmpeg、ffprobe）；[embodied/src/draw_mixed_trace.py](embodied/src/draw_mixed_trace.py)（作图） | 摘录 [embodied/data/mixed-trace.csv](embodied/data/mixed-trace.csv)，来源与字段说明 [embodied/data/mixed-trace-source.json](embodied/data/mixed-trace-source.json)，选帧 [embodied/data/mixed-trace-frame-355.jpg](embodied/data/mixed-trace-frame-355.jpg)、[-397](embodied/data/mixed-trace-frame-397.jpg)、[-423](embodied/data/mixed-trace-frame-423.jpg)；图 [embodied/figures/mixed-trace.svg](embodied/figures/mixed-trace.svg) |
| 课件 emb-record-clock、emb-mixed-trajectory、emb-response-target（14.3–14.5 节） | 第 391 帧命令由 $100$ 降为 $0$，读数由第 390 帧的 $96.72$ 降到第 397 帧的 $6.16$，两帧相隔 $.400$ 秒；采集时钟上第 390、391、397 帧分别为 $26.00$、$26.07$、$26.47$ 秒；第 404 帧之后的一段间隔约 $2.27$ 秒；第 390、397、423 帧右腕画面 | 本课的计算：同一段 R1Lite 公开记录，读取采集时钟与第 14 个关节分量，逐帧对照命令与读数，并以接管前 368 对等间隔的自主相邻帧用最小二乘拟合一步响应预测，再分人工接管（35 对）与交还后（67 对）两段，与沿用上一帧读数的预测比较平均绝对误差；确定性计算，无随机重复 | [embodied/src/r1lite_response.py](embodied/src/r1lite_response.py) | 输入 [embodied/data/r1lite-acquisition-clock.csv](embodied/data/r1lite-acquisition-clock.csv)、[embodied/data/mixed-trace.csv](embodied/data/mixed-trace.csv)、[embodied/data/r1lite-visible-outcome.json](embodied/data/r1lite-visible-outcome.json)、右腕画面 [embodied/data/r1lite-right-wrist-390.jpg](embodied/data/r1lite-right-wrist-390.jpg)、[-397](embodied/data/r1lite-right-wrist-397.jpg)、[-423](embodied/data/r1lite-right-wrist-423.jpg)；输出 [embodied/data/r1lite-response-results.json](embodied/data/r1lite-response-results.json)、[embodied/figures/r1lite-acquisition-response.svg](embodied/figures/r1lite-acquisition-response.svg) |
| 14.5 节“视觉语言动作模型的微调路线”（链接“生成路径梯度的数值核对”） | 隐变量路径得分 $.8$ 与边缘得分 $1.2$ 不同；按路径求积的梯度约为 $1.0$，与有限差分梯度一致 | 本课的计算：$z_1\sim\mathcal N(\theta,.25)$，$a\sim\mathcal N(z_1,.25)$，奖励 $-(a-.5)^2$，$\theta=0$；数值求积与有限差分对照；程序另含三项有限核对；确定性计算，无随机重复 | `demos/llm_embodied_v11.py` | `assets/llm-embodied-v11/checks.json`、`assets/llm-embodied-v11/group-expectations.csv`；加 `--figures` 时另写 `assets/llm-embodied-v11/group-gradients.png` |
| 课件 emb-intervention-yield（14.7 节） | 频繁漂移情形下，自适应诊断减固定周期校准为 $10.51\ [9.78,\,11.24]$；减只靠反馈、无专门探测为 $.57\ [-.16,\,1.29]$ | 本课的模拟：合成工位，每班 160 个时刻，前瞻 14 步；固定周期在 $(8,16,32,64,\text{不校准})$ 中按 64 个拟合种子（0–63）选定，频繁情形选中 16；在 512 个留出的配对班次（种子 10000–10511）上评价，即独立重复 512 次；频繁情形每时刻磨损与漂移的发生率为 $.018$ 与 $.025$；区间为配对差值的 $1.96$ 倍标准误 | [embodied/src/physical_diagnosis20.py](embodied/src/physical_diagnosis20.py) | [embodied/data/physical-diagnosis20.json](embodied/data/physical-diagnosis20.json)（`frequent` 一项）；[embodied/figures/physical-diagnosis20.svg](embodied/figures/physical-diagnosis20.svg) |
| 课件 emb-lifetime（14.7 节） | 第 3600 步的净收益：自行发现技能 $659.5$，原始动作 Q 学习 $412.8$，固定两种事件 $226.1$；前 600 步 $11.8$ 对 $16.0$ | 本课的模拟：不重置的合成工位，lifetime 3600 个时刻；第 600 步提名候选、第 1200 步结束练习，第 1500 步起出现新的复合订单；每条命令代价 $.025$，失败代价 $.15$，恢复占 2 个时刻；规划折扣 $.96$；8 种方法在 72 个配对种子（5100–5171）上各独立重复 72 次；区间为 Student-$t$ $95\%$ 区间 | [embodied/src/physical_discovery11.py](embodied/src/physical_discovery11.py)（作图调用同目录的 `draw_physical_world.py`） | [embodied/data/physical_discovery11.json](embodied/data/physical_discovery11.json)、[embodied/data/physical_discovery11_pairs.csv](embodied/data/physical_discovery11_pairs.csv)；[embodied/figures/physical-discovery11.svg](embodied/figures/physical-discovery11.svg) |
| 14.4 节（课件 `ch14-sys-stable-imitation`） | 三条误差带：$c=L>1$ 指数放大，$c=1$ 线性增长，$\rho<1$ 有界于 $\varepsilon/(1-\rho)$；$H=100$ 时 $\varepsilon H(H-1)/2=4950\varepsilon$ | 本课的计算：偏差按 $d_{t+1}=c\,d_t+\varepsilon$ 递推，无训练 | `demos/ch14_s4_error_bands.py` | `assets/ch14-r21/error-bands.pdf` |
| 14.5 节（课件 `emb-imagination`、`ch14-model-judge`） | 吸收态例子的回报误差与误差界：20 步 1.973 对 2.10，30 步 4.230 对 4.65；$N$ 个标准正态最大值的期望 $m_N$：.56（$N=2$）、1.54（10）、2.51（100）、3.24（1000）；同程序另打印 `ch14-imagine-practice`、`ch14-sys-wam-rank`、`emb-domain-randomization`、`emb-occupancy` 各页的数 | 本课的计算，数值积分，无训练 | `demos/ch14_s5_r21_numbers.py` | 只在终端输出，不写文件 |

外部代码（出处）：HIL-SERL 的 `train_rlpd.py`（rail-berkeley/hil-serl，提交 `c32939b`）。公开数据：BodenAI 等发布的 RW-RL-HIL-Dataset（CC BY 4.0），R1Lite 两行所用记录均取自该数据集的上述修订。

运行：
```sh
python3 textbook/embodied/src/layer_latency.py         # 只打印
python3 textbook/embodied/src/extract_mixed_trace.py   # 从 Hugging Face 下载指定修订的源文件；需 duckdb、ffmpeg、ffprobe
python3 textbook/embodied/src/draw_mixed_trace.py
python3 textbook/embodied/src/r1lite_response.py       # 可加 --capture-from、--wrist-video 重新摘录
python3 demos/llm_embodied_v11.py --figures            # 写 assets/llm-embodied-v11
python3 demos/ch14_s4_error_bands.py                   # 写 assets/ch14-r21/error-bands.pdf
python3 demos/ch14_s5_r21_numbers.py                   # 只打印
python3 textbook/embodied/src/physical_diagnosis20.py
python3 textbook/embodied/src/physical_discovery11.py
```

## 参考数据

`assets/`（以及 `demos/NN-results/`）下复制了 32 个数据文件（json、csv 等），即课程目前使用的结果；图片没有复制，运行程序会重新画出。重跑会覆盖这些文件，可以先另存一份再对照。
