"""Draw the chapter's physical clock, reported ablation endpoints, and acquisition diagram."""
from pathlib import Path
from xml.etree.ElementTree import Element, SubElement, ElementTree

OUT = Path(__file__).resolve().parents[1] / "figures"
INK, TEAL, AMBER, GREY, LIGHT = "#183640", "#14796f", "#ac541c", "#546971", "#d7e3df"
FONT = "PingFang SC, Noto Sans CJK SC, Microsoft YaHei, sans-serif"

def svg(name, description, height):
    root = Element("svg", xmlns="http://www.w3.org/2000/svg", viewBox=f"0 0 860 {height}", role="img",
                   attrib={"aria-labelledby":"title desc"})
    SubElement(root, "title", id="title").text = name
    SubElement(root, "desc", id="desc").text = description
    box(root, 0, 0, 860, height, "#fafbf8")
    return root

def text(root,x,y,label,size=19,color=INK,weight="400",anchor="start"):
    SubElement(root,"text",x=str(x),y=str(y),fill=color,attrib={"font-family":FONT,"font-size":str(size),"font-weight":weight,"text-anchor":anchor}).text=label

def box(root,x,y,w,h,fill,stroke="none",radius=0):
    SubElement(root,"rect",x=str(x),y=str(y),width=str(w),height=str(h),rx=str(radius),fill=fill,stroke=stroke)

def line(root,x1,y1,x2,y2,color=GREY,width=2,dash="none"):
    SubElement(root,"line",x1=str(x1),y1=str(y1),x2=str(x2),y2=str(y2),stroke=color,attrib={"stroke-width":str(width),"stroke-dasharray":dash})
def dot(root,x,y,r,color):
    SubElement(root,"circle",cx=str(x),cy=str(y),r=str(r),fill=color)
def path(root,d,stroke,fill="none",width=3):
    SubElement(root,"path",d=d,fill=fill,stroke=stroke,attrib={"stroke-width":str(width),"stroke-linejoin":"round","stroke-linecap":"round"})
def save(name,root):
    ElementTree(root).write(OUT/name,encoding="utf-8",xml_declaration=True)

def stream():
    r=svg("统计窗口结束，物理过程继续","机器人搬运时物体掉落，随后搜索、取回并回到工作。失手和恢复的时间由同一经验流承担。",305)
    text(r,24,34,"工作、失手与恢复共用一只时钟",25,INK,"650")
    box(r,112,55,360,32,"#dfede9");box(r,472,55,352,32,"#edf0f5")
    text(r,292,77,"观察窗口一",16,TEAL,"600","middle");text(r,648,77,"观察窗口二",16,INK,"600","middle")
    line(r,472,87,472,250,GREY,1.5,"5 5")
    text(r,22,127,"物体",17,GREY);text(r,22,207,"机器人",17,GREY)
    # The moving square falls to floor and is later retrieved.
    path(r,"M 112 121 H 321 Q 344 121 362 157 H 600 Q 629 157 650 121 H 822",TEAL,width=4)
    for x,y in [(185,121),(362,157),(552,157),(691,121)]:box(r,x-6,y-6,12,12,"#fbfbf5",TEAL)
    text(r,182,108,"携带",15,TEAL);text(r,349,115,"掉落",15,AMBER);text(r,516,142,"仍在地上",15,TEAL);text(r,674,108,"重新持有",15,TEAL)
    for x,w,label,col in [(112,213,"搬运",TEAL),(325,178,"搜索",AMBER),(503,147,"重新抓取",AMBER),(650,174,"继续工作",TEAL)]:
        box(r,x,182,w-2,35,col,radius=4);text(r,x+w/2,206,label,16,"white","600","middle")
    line(r,112,240,818,240);path(r,"M 813 235 L 822 240 L 813 245",GREY,width=2)
    text(r,825,264,"物理时间",15,GREY,"400","end")
    text(r,24,285,"若在掉落后由人归位再开局，访问的状态、恢复时间和承担后果的人都已改变。",17,INK)
    save("physical-stream.svg",r)

def ablation():
    r=svg("人类视频规模与三项评估", "同一套72个任务，四组规模。两行VLM评进度，一行人工判定真机成功。数据见技术报告图10、附录C.1.5。",355)
    text(r,24,35,"同一组 72 项任务，三个不同的测量",25,INK,"650")
    cols=[(355,"0"),(505,"870"),(655,"8,100"),(800,"84,400")]
    text(r,24,81,"多视角人体视频（小时）",17,GREY)
    for x,lab in cols: text(r,x,81,lab,18,GREY,"650","middle")
    for y,name,sub,values,color in [
            (138,"生成视频的任务进度","视觉语言模型评分",[64,66,72,77],GREY),
            (212,"真机录像的任务进度","同一评分器",[50,58,61,70],TEAL),
            (286,"真机完成率","人工判定目标是否达到",[18,27,28,41],AMBER)]:
        text(r,24,y-6,name,19,INK,"600");text(r,24,y+16,sub,15,GREY)
        for (x,_),v in zip(cols,values):
            box(r,x-42,y+7,84,5,LIGHT,radius=2);box(r,x-42,y+7,84*v/100,5,color,radius=2)
            text(r,x,y-2,f"{v}%",21,color,"650","middle")
    text(r,24,333,"每个训练条件各一个模型。非零组共享预训练起点，数据用量与训练步数共同变化。",16,INK)
    save("physical-data-scaling.svg",r)

def evidence():
    r=svg("物理动作怎样得到独立验证","同一物体，看到抬升、发出夹持参考、由目标身体以不同命令执行，以及持续部署。其经验可回答不同的问题。",370)
    text(r,24,35,"同一抓取，四种可检验的判断",25,INK,"650")
    # Visual key: gripper, square object, surface, alternative command, recorded outcome.
    for i,(label,caption) in enumerate([("看见物体抬起","可预测运动阶段"),("记录夹爪命令","可模仿示范动作"),("目标机器人试抓","可比较命令后果"),("持续运行与恢复","可评价长期净收益")]):
        x=20+i*211;box(r,x,60,192,232,["#edf3f0","#edf3f0","#f8f1e8","#f8f1e8"][i],radius=7)
        text(r,x+96,88,label,18,INK,"650","middle")
        line(r,x+22,195,x+170,195,GREY,2)
        if i<=1:
            path(r,f"M{x+75} 125 v20 h8 M{x+117} 125 v20 h-8",TEAL,width=4)
            box(r,x+82,142,28,22,"#d5a16e",AMBER);line(r,x+96,166,x+96,187,AMBER,2,"4 3")
            if i==1: text(r,x+96,115,"开度、位姿",14,TEAL,anchor="middle")
        elif i==2:
            for d,yy in [(53,143),(135,179)]:
                path(r,f"M{x+d-18} 120 v17 h5 M{x+d+18} 120 v17 h-5",TEAL,width=3)
                box(r,x+d-10,yy,20,16,"#d5a16e",AMBER)
            text(r,x+96,114,"A               B",14,TEAL,anchor="middle")
        else:
            path(r,f"M{x+23} 141 h29 l18 41 h34 l19 -41 h38",TEAL,width=3)
            for d,yy in [(51,141),(91,182),(137,141)]:dot(r,x+d,yy,4,AMBER)
        text(r,x+96,226,caption,17,INK,"550","middle")
        text(r,x+96,261,["人体 / 视频","手持 / 遥操作","已覆盖的动作","按时钟累计"][i],15,GREY,anchor="middle")
    text(r,24,324,"前两种资料可构造策略先验；不同命令在目标身体上产生的差异需要行动条件的反馈。",17)
    text(r,24,350,"一次失手若影响以后的工作，还需记录恢复与再次尝试。",17)
    save("experience-ladder.svg",r)

if __name__=="__main__":
    stream();ablation();evidence()
