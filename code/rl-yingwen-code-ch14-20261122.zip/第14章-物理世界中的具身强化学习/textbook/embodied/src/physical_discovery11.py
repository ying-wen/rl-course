"""Continuous workcell. Run python3 src/physical_discovery11.py from any directory.

The agent observes pose cues, provisional contact bits, latched contact bits,
the current order and an acceptance receipt. Hidden wiring and the acceptance
law belong to the simulator. Only explicitly informed comparators receive useful event names;
the calibrated controller also receives the motor wiring. Each failed actuation, service and recovery uses time.
"""
import csv
import json
import math
import random
from collections import Counter, defaultdict
from pathlib import Path
from statistics import mean, stdev

from draw_physical_world import AMBER, GREY, INK, TEAL, box, dot, line, path, save, svg, text

ROOT = Path(__file__).resolve().parents[1]
MOVES = range(3)
CHANNELS = range(4)             # three contact channels, one stand-alone indicator
NOMINATE = 600                 # primitive clock ticks, including recovery
PRACTICE_END = 1200
NOVEL = 1500
HORIZON = 3600
SEEDS = tuple(range(5100, 5172))
METHODS = ('discover', 'fixed', 'given', 'predictable', 'primitive', 'given_early', 'undirected', 'oracle_skill')
CHECKS = (300, 600, 900, 1200, 1500, 2400, 3600)
GAMMA = .96                    # planner discounts by physical ticks
COMMAND_COST = .025
FAIL_COST = .15


class Cell:
    """One lifetime. Exogenous disturbances have common tapes indexed by clock."""
    def __init__(self, seed):
        rng = random.Random(seed)
        self.wiring = [rng.sample(range(3), 3) for _ in range(2)]
        self.contacts = rng.sample(list(CHANNELS), 3)
        self.indicator = next(i for i in CHANNELS if i not in self.contacts)
        self.useful = self.contacts[:2]
        self.cues = rng.choices((0, 1), k=HORIZON + 20)
        self.disturb = [rng.random() for _ in self.cues]
        self.slip = [rng.random() for _ in self.cues]
        self.lights = [rng.random() < .92 for _ in self.cues]
        self.orders = rng.choices((0, 1), k=HORIZON + 1)
        self.order_id = 0
        self.order = (self.orders[0],)
        self.contact = self.latch = None
        self.t = 0
        self.net = 0.
        self.at = {}
        self.clock = Counter()
        self.completed = self.novel_completed = 0
        self.commands = self.services = self.failures = self.gross = 0

    def signals(self):
        ready = set() if self.latch is None else {self.latch}
        touch = set() if self.contact is None else {self.contact}
        if self.lights[self.t]:
            touch.add(self.indicator)
            ready.add(self.indicator)
        return touch, ready

    def tick(self, phase, payoff):
        if self.t == HORIZON:
            return
        self.clock[phase] += 1
        self.net += payoff
        self.t += 1
        if self.t in CHECKS:
            self.at[self.t] = self.net

    def move(self, action, phase):
        t = self.t
        self.commands += 1
        channel = self.contacts[self.wiring[self.cues[t]][action]]
        if self.slip[t] < .08:
            channel = None
        self.latch = channel if channel == self.contact else None
        self.contact = channel
        self.tick(phase, -COMMAND_COST)

    def service(self, phase):
        """Service releases the fixture mechanically. A failure occupies two recovery ticks."""
        goal = self.order[0]
        ok = self.disturb[self.t] < (.94 if self.latch == self.useful[goal] else .18)
        finished = ok and len(self.order) == 1
        self.services += 1
        self.failures += int(not ok)
        payoff = 0. if ok else -FAIL_COST
        if finished:
            payoff = self.order_value
            self.gross += payoff
        self.tick(phase, payoff)
        self.contact = self.latch = None
        if ok and not finished:
            self.order = self.order[1:]
        if finished:
            if self.order_value == 2:
                self.novel_completed += 1
            self.completed += 1
            self.order_id += 1
            start = self.orders[self.order_id]
            self.paired_order = self.t >= NOVEL
            self.order = (start, 1-start) if self.paired_order else (start,)
        if not ok:
            for _ in range(2):
                self.tick('recovery', 0.)
        return int(ok)

    @property
    def order_value(self):
        return 2 if getattr(self, 'paired_order', False) else 1


class Experience:
    def __init__(self):
        self.moves = Counter()
        self.touches = Counter()
        self.service_trials = Counter()
        self.receipts = Counter()
        self.easy_hits = Counter()
        self.steps = 0
        self.calibrated_motor = None

    def move(self, env, a, phase, learn=True):
        cue = env.cues[env.t]
        env.move(a, phase)
        touched, ready = env.signals()
        if learn:
            self.moves[cue, a] += 1
            for j in CHANNELS:
                self.touches[cue, a, j] += int(j in touched)
                self.easy_hits[j] += int(j in ready)
            self.steps += 1

    def audition(self, env, rng):
        """Independent random motor commands, then always obtain the product receipt."""
        for _ in range(2):
            if env.t == HORIZON:
                return
            self.move(env, rng.randrange(3), 'screen')
        if env.t == HORIZON:
            return
        _, ready = env.signals()
        g = env.order[0]
        ok = env.service('screen')
        for j in CHANNELS:
            key = (g, j, j in ready)
            self.service_trials[key] += 1
            self.receipts[key] += ok

    def reachable(self, z, a, j):
        return (1+self.touches[z, a, j])/(2+self.moves[z, a])

    def nominate(self, method):
        if method == 'predictable':
            # Minimum estimated Bernoulli variance of the unconditional latch reading.
            p = {j:(1+self.easy_hits[j])/(2+self.steps) for j in CHANNELS}
            return sorted(CHANNELS, key=lambda j:p[j]*(1-p[j]))[:2]
        def score(j):
            control = mean(max(self.reachable(z,a,j) for a in MOVES)
                           - min(self.reachable(z,a,j) for a in MOVES) for z in (0,1))
            lift = []
            for g in (0,1):
                rates = [(1+self.receipts[g,j,k])/(2+self.service_trials[g,j,k])
                         for k in (False,True)]
                # Downweight rare positive events: a nomination still needs actual trials.
                n = self.service_trials[g,j,True]
                lift.append(max(0.,rates[1]-rates[0]) * n/(n+3))
            return control*max(lift)
        return sorted(CHANNELS, key=score, reverse=True)[:2]

    def skill(self, env, j, rng, phase, train, directed):
        """pi_j, beta_j: motor command depends on current cue; test latch after every step."""
        for _ in range(5):
            if env.t == HORIZON or j in env.signals()[1]:
                break
            cue = env.cues[env.t]
            if self.calibrated_motor is not None:
                a = self.calibrated_motor[cue,j]
            elif not directed or (train and rng.random() < .18):
                a = rng.randrange(3)
            else:
                a = max(MOVES, key=lambda a:(self.reachable(cue,a,j), rng.random()))
            self.move(env, a, phase, learn=train)


class OutcomeModel:
    """Pool each option's duration and terminal sensor reading across work orders.
    Fit acceptance probability separately from the service receipts.
    """
    def __init__(self):
        self.endpoints = defaultdict(Counter)
        self.attempts = Counter()
        self.receipts = Counter()
        self.cache = {}

    def add(self, g, j, moves, endpoint, ok):
        self.endpoints[j][moves, endpoint] += 1
        self.attempts[g,endpoint] += 1
        self.receipts[g,endpoint] += ok
        self.cache.clear()

    def decide(self, order, stake, actions):
        key = (tuple(order), stake)
        if key not in self.cache:
            after = 0.
            for k,g in enumerate(reversed(order)):
                values = {}
                for j in actions:
                    n = sum(self.endpoints[j].values())
                    if not n:
                        continue
                    immediate = fail_weight = 0.
                    for (moves,endpoint), count in self.endpoints[j].items():
                        mass = count/n
                        p = (1+self.receipts[g,endpoint])/(2+self.attempts[g,endpoint])
                        motion_cost = -COMMAND_COST*sum(GAMMA**i for i in range(moves))
                        receipt = stake if k == 0 else GAMMA*after
                        immediate += mass*(motion_cost + GAMMA**moves*(p*receipt-(1-p)*FAIL_COST))
                        # Failed service and two recovery ticks precede a fresh decision.
                        fail_weight += mass*(1-p)*GAMMA**(moves+3)
                    values[j] = immediate/(1-fail_weight)
                best = max(values, key=values.get) if values else -1
                after = values.get(best,0.)
            self.cache[key] = best
        return self.cache[key]


def deploy(seed, method):
    env = Cell(seed)
    agent = Experience()
    model = OutcomeModel()
    rng = random.Random(seed + 700000)
    early = method in ('given_early','oracle_skill')
    if method != 'primitive' and not early:
        while env.t < NOMINATE:
            agent.audition(env,rng)
    selected = ()
    if method in ('discover','predictable','undirected'):
        selected = tuple(sorted(agent.nominate(method)))
    elif method in ('given','given_early','oracle_skill'):
        selected = tuple(sorted(env.useful))               # names only; initial motor policy is untrained
    elif method == 'fixed':
        selected = (0,1)                           # chosen before the sensor-wiring permutation
    if method == 'oracle_skill':
        # Privileged, hand-supplied sensor meanings AND actuator calibration.
        # Service probabilities, option durations and high-level actions remain unknown.
        agent.calibrated_motor = {(z,j):env.wiring[z].index(env.contacts.index(j))
                                  for z in (0,1) for j in selected}
    actions = (-1,) + selected
    uses = Counter()
    visited = Counter()
    successful = Counter()
    flat_q = defaultdict(lambda:[0.]*4)
    previous = None
    while env.t < HORIZON:
        if method == 'primitive':
            # Flat SMDP Q-learning; all three motor commands and service are available.
            # Reuse the same per-stage state across single and compound work orders.
            s = (env.order[0], env.cues[env.t],
                 *[tuple(sorted(x)) for x in env.signals()])
            if previous is not None and env.t < NOVEL:
                p,a,r,d = previous
                flat_q[p][a] += .24*(r+GAMMA**d*max(flat_q[s])-flat_q[p][a])
            a = (rng.randrange(4) if env.t < NOVEL and rng.random()<.25
                 else max(range(4), key=lambda a:(flat_q[s][a], rng.random())))
            start, old = env.t, env.net
            if a == 3:
                env.service('service')
            else:
                env.move(a,'motor')
            previous = (s,a,env.net-old,env.t-start)
            continue
        stage_start = 0 if early else NOMINATE
        fit_end = stage_start + (0 if method == 'oracle_skill' else 300)
        phase = 'practice' if env.t < fit_end + 300 else 'deploy'
        # Each model is calibrated on disjoint, subsequent calls of its frozen controller.
        # During practice there is exploration only in the first half.
        calibration = phase == 'practice' and env.t >= fit_end
        j = rng.choice(actions) if phase == 'practice' else model.decide(env.order,env.order_value,actions)
        goal, start = env.order[0], env.t
        if j >= 0:
            agent.skill(env,j,rng,phase,train=env.t < fit_end,directed=method != 'undirected')
        if env.t == HORIZON:
            break
        moves = env.t-start
        hit = j >= 0 and j in env.signals()[1]
        endpoint = tuple(sorted(env.signals()[1]))
        ok = env.service(phase)
        if calibration:
            model.add(goal,j,moves,endpoint,ok)
        if env.t > NOVEL and phase == 'deploy':
            uses[goal,j] += 1
            if j>=0:
                visited[j] += 1
                successful[j] += int(hit)
    assert env.t == sum(env.clock.values()) == HORIZON
    assert env.commands + env.services + env.clock['recovery'] == HORIZON
    assert abs(env.net - (env.gross-COMMAND_COST*env.commands-FAIL_COST*env.failures)) < 1e-7
    assert all(t in env.at for t in CHECKS)
    assert len(set(selected)) == len(selected)
    return dict(seed=seed,method=method,selected=''.join(map(str,selected)),
                useful=''.join(map(str,env.useful)),overlap=len(set(selected)&set(env.useful)),
                gross=env.gross,commands=env.commands,services=env.services,failures=env.failures,
                novel_orders=env.novel_completed, skill_calls=sum(visited.values()),
                skill_hits=sum(successful.values()), screen=env.clock['screen'],
                practice=env.clock['practice'], recovery=env.clock['recovery'],
                **{f'net_{t}':round(env.at[t],6) for t in CHECKS},
                novel_net=round(env.net-env.at[NOVEL],6))


def interval(xs):
    return [round(mean(xs),3), round(1.994*stdev(xs)/math.sqrt(len(xs)),3)]


def aggregate(rows):
    arms = {m:[r for r in rows if r['method']==m] for m in METHODS}
    keys = [f'net_{t}' for t in CHECKS]+['novel_net','novel_orders','screen','practice','recovery','skill_calls','overlap']
    return {m:dict(means={k:interval([r[k] for r in rs]) for k in keys},
                   discovery_minus_this={k:interval([d[k]-r[k] for d,r in zip(arms['discover'],rs)])
                                         for k in keys if k.startswith('net_') or k=='novel_net'},
                   both_selected=sum(r['overlap']==2 for r in rs),
                   option_hit_rate=(sum(r['skill_hits'] for r in rs)/sum(r['skill_calls'] for r in rs)
                                    if sum(r['skill_calls'] for r in rs) else None))
            for m,rs in arms.items()}


def figure(agg):
    r=svg('技能发现与固定技能的全程净收益',
          '合成工位，72 个配对种子。左侧为累积净收益，右侧为自主发现减去各方案的配对均值与95%区间。',440)
    text(r,22,36,'技能发现的全程净收益',24,INK,'650')
    text(r,22,65,'合成无重置工位　72 个配对部署　每次失败需两个恢复时步',16,GREY)
    colors={'discover':TEAL,'fixed':'#455f88','given':AMBER,'given_early':'#875383'}
    names={'discover':'自主发现','fixed':'固定通道','given':'预知通道','given_early':'预知、免筛选'}
    left,top,bottom,right=57,105,312,409
    max_y=max(agg[m]['means'][f'net_{HORIZON}'][0] for m in colors)*1.05
    y=lambda v:bottom-(v+70)/(max_y+70)*(bottom-top)
    x=lambda t:left+(right-left)*t/HORIZON
    box(r,x(0),top,x(NOMINATE)-x(0),bottom-top,'#edf0f2')
    box(r,x(NOMINATE),top,x(PRACTICE_END)-x(NOMINATE),bottom-top,'#f4eddf')
    line(r,left,y(0),right,y(0),GREY,1)
    for h in (0,1500,3600):
        line(r,x(h),top,x(h),bottom,GREY,1,'3 4')
        text(r,x(h),333,str(h),14,GREY,anchor='middle')
    text(r,left,92,'从第一个时步累计的净收益',16,INK,'600')
    for value in (0,round(max_y/2,-1),round(max_y,-1)):
        text(r,left-5,y(value)+5,str(int(value)),12,GREY,anchor='end')
    for m,c in colors.items():
        pts=[(x(0),y(0))]+[(x(t),y(agg[m]['means'][f'net_{t}'][0])) for t in CHECKS]
        path(r,'M'+' L'.join(f'{a:.2f} {b:.2f}' for a,b in pts),c,width=2.5)
    text(r,445,92,'3,600 步内的配对净收益差（95% 区间）',16,INK,'600')
    methods=('fixed','given','given_early','oracle_skill','predictable','primitive','undirected')
    labels=('固定通道','预知通道','预知、免筛选','预知且已会操作','低预测方差','平坦 Q 学习','随机局部动作')
    bounds=[agg[m]['discovery_minus_this']['net_3600'] for m in methods]
    low=min(0,min(v-e for v,e in bounds))-15
    high=max(0,max(v+e for v,e in bounds))+15
    fx=lambda v:552+(v-low)/(high-low)*235
    line(r,fx(0),109,fx(0),299,GREY,1.4,'4 4')
    for i,(m,label,(v,e)) in enumerate(zip(methods,labels,bounds)):
        cy=119+i*29
        text(r,445,cy+5,label,14,INK)
        line(r,fx(v-e),cy,fx(v+e),cy,TEAL,3)
        dot(r,fx(v),cy,4,TEAL)
        text(r,842,cy+5,f'{v:+.0f}',14,INK,anchor='end')
    for val in (-200,0,200,400,600):
        if low < val < high:
            text(r,fx(val),314,str(val),11,GREY,anchor='middle')
    text(r,445,336,'左侧为对照占优，右侧为自主发现占优。',14,GREY)
    for i,(m,c) in enumerate(colors.items()):
        xx=26+(i%2)*204; yy=361+(i//2)*25
        line(r,xx,yy-5,xx+22,yy-5,c,3)
        text(r,xx+29,yy,names[m],15,INK)
    text(r,445,365,'蓝灰段筛选，浅黄段练习与估计技能模型。',14,GREY)
    text(r,445,389,'第 1,500 步后到达的新订单需连续完成两道工序。',14,GREY)
    text(r,22,425,'回报含完成订单所得、控制动作成本和失败损失；恢复期间无法生产。',15,INK)
    save('physical-discovery11.svg',r)


if __name__ == '__main__':
    rows=[deploy(seed,m) for seed in SEEDS for m in METHODS]
    with (ROOT/'data/physical_discovery11_pairs.csv').open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=rows[0].keys());writer.writeheader();writer.writerows(rows)
    agg=aggregate(rows)
    (ROOT/'data/physical_discovery11.json').write_text(json.dumps(
        {'synthetic':True,'seeds':list(SEEDS),'checkpoints':CHECKS,'n':len(SEEDS),
         'physical_budget':{'horizon':HORIZON,'nomination':NOMINATE,'motor_practice':300,
                            'calibration':300,'compound_orders_after':NOVEL,
                            'command_cost':COMMAND_COST,'failure_cost':FAIL_COST,'recovery_ticks':2},
         'planning_discount':GAMMA,'interval_unit':'seed',
         'statistics':'[mean, half width of paired or across-seed Student t 95% CI]',
         'summary':agg},ensure_ascii=False,indent=2)+'\n')
    figure(agg)
    for m in METHODS:
        print(m,agg[m]['means']['net_3600'],agg[m]['discovery_minus_this']['net_3600'],
              agg[m]['means']['novel_net'],agg[m]['both_selected'])
