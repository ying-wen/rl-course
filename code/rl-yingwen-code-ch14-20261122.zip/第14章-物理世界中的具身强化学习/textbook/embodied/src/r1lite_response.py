"""One-interval prediction on one public R1Lite trajectory, without task rewards.

Run from any directory with NumPy, matplotlib and Pillow installed:
    python3 src/r1lite_response.py

To re-extract the acquisition clock from the publisher's episode_000000.parquet,
add --capture-from <path>. That optional step requires duckdb.
To re-extract the right-wrist photos from its pinned video, add
--wrist-video <path>. That optional step requires ffmpeg.
"""
import argparse
import csv
import hashlib
import json
from pathlib import Path
import subprocess

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
CAPTURE = DATA / "r1lite-acquisition-clock.csv"
FIGURE = ROOT / "figures/r1lite-acquisition-response.svg"


def extract_clock(path, metadata):
    import duckdb

    expected = next(value for key, value in metadata["input_sha256"].items() if key.endswith(".parquet"))
    if hashlib.sha256(path.read_bytes()).hexdigest() != expected:
        raise ValueError("The input does not match the published episode.")
    with duckdb.connect() as db:
        rows = db.execute(
            "SELECT frame_index, capture_time FROM read_parquet(?) ORDER BY frame_index", [str(path)]
        ).fetchall()
    with CAPTURE.open("w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["frame", "elapsed_capture_s"])
        t0 = rows[0][1]
        writer.writerows((i, f"{t - t0:.8f}") for i, t in rows)


def extract_wrist(path):
    notes = json.loads((DATA / "r1lite-visible-outcome.json").read_text())
    if hashlib.sha256(path.read_bytes()).hexdigest() != notes["sha256_right_wrist_mp4"]:
        raise ValueError("The right-wrist video does not match the published episode.")
    for frame in notes["selected_frames"]:
        subprocess.run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-i", str(path),
                        "-vf", f"select=eq(n\\,{frame})", "-frames:v", "1", "-q:v", "3", "-y",
                        str(DATA / f"r1lite-right-wrist-{frame}.jpg")], check=True)


def read_columns():
    with CAPTURE.open() as f:
        clocks = list(csv.DictReader(f))
    with (DATA / "mixed-trace.csv").open() as f:
        rows = list(csv.DictReader(f))
    if [int(row["frame"]) for row in rows] != [int(row["frame"]) for row in clocks]:
        raise ValueError("Frame indices do not match.")
    time = np.array([float(row["elapsed_capture_s"]) for row in clocks])
    command = np.array([float(row["action_qpos_14"]) for row in rows])
    position = np.array([float(row["observation_qpos_14"]) for row in rows])
    human = np.array([row["intervention"] == "1" for row in rows])
    return time, command, position, human


def fit_and_test(time, command, position, human, fps):
    indices = np.arange(len(time) - 1)
    regular = np.isclose(np.diff(time), 1 / fps, atol=1e-5)
    same_source = human[:-1] == human[1:]
    train = regular & same_source & (indices < np.flatnonzero(human)[0])
    design = np.column_stack([np.ones(len(indices)), position[:-1], command[:-1]])
    target = position[1:]
    coefficients = np.linalg.lstsq(design[train], target[train], rcond=None)[0]
    predicted = design @ coefficients
    results = []
    for source, selected in [("intervention", human[:-1]), ("handed_back", ~human[:-1] & ~train)]:
        mask = regular & same_source & selected
        results.append({
            "source": source,
            "n": int(mask.sum()),
            "mae_persistence": float(np.mean(abs(position[:-1][mask] - target[mask]))),
            "mae_action_conditioned": float(np.mean(abs(predicted[mask] - target[mask]))),
        })
    gaps = [dict(after_frame=int(i), elapsed_capture_s=float(time[i + 1] - time[i]))
            for i in indices[~regular]]
    return dict(training_pairs=int(train.sum()), coefficients=coefficients.tolist(),
                evaluation=results, nonuniform_intervals=gaps)


def draw(time, command, position, results):
    import matplotlib
    matplotlib.use("Agg")
    from matplotlib import pyplot as plt, font_manager
    from PIL import Image

    for file in ("FandolHei-Regular.otf", "FandolHei-Bold.otf"):
        path = subprocess.check_output(["kpsewhich", file], text=True).strip()
        if path:
            font_manager.fontManager.addfont(path)
    plt.rcParams.update({"font.family": ["FandolHei", "DejaVu Sans"], "svg.fonttype": "path",
                         "font.size": 13, "axes.spines.top": False, "axes.spines.right": False})
    teal, sienna, blue = "#126660", "#984316", "#214e77"
    fig = plt.figure(figsize=(10.2, 7.25))
    grid = fig.add_gridspec(4, 3, height_ratios=(1.28, 1.28, 1.26, .72),
                            left=.11, right=.986, top=.94, bottom=.035, hspace=.48, wspace=.09)
    for i, (frame, desc) in enumerate([(355, "策略执行"), (397, "人工接管"), (423, "交还策略")]):
        ax = fig.add_subplot(grid[0, i])
        with Image.open(DATA / f"mixed-trace-frame-{frame}.jpg") as frame_image:
            ax.imshow(frame_image)
        ax.set_title(f"{desc}   {time[frame]:.2f} s", loc="left", pad=6,
                     fontsize=14, color=sienna if i == 1 else teal)
        ax.text(.03, .05, f"第 {frame} 帧", transform=ax.transAxes, va="bottom", color="white",
                fontsize=10, bbox={"facecolor": "#142331", "alpha": .85, "edgecolor": "none", "pad": 2})
        ax.set_axis_off()
        if i == 0:
            ax.text(-.035, .5, "头部\n相机", transform=ax.transAxes, ha="right", va="center", size=12)
        wrist = fig.add_subplot(grid[1, i])
        with Image.open(DATA / f"r1lite-right-wrist-{frame}.jpg") as frame_image:
            wrist.imshow(frame_image)
        if i == 0:
            wrist.text(-.035, .5, "右腕\n相机", transform=wrist.transAxes,
                       ha="right", va="center", size=12)
        if frame == 423:
            wrist.annotate("外露的纸巾", xy=(287,194), xytext=(332,100), color="white", fontsize=10,
                           arrowprops=dict(arrowstyle="->",color="white",lw=1.5),
                           bbox=dict(facecolor="#263947",alpha=.84,edgecolor="none",pad=2))
        wrist.set_axis_off()
    ax = fig.add_subplot(grid[2, :])
    ax.axvspan(time[369], time[404], color="#f9e3d2", zorder=-3)
    ax.axvspan(time[404], time[405], color="#e9edf0", zorder=-3)
    for start, end in [(0, 405), (405, len(time))]:
        sel = slice(start, end)
        ax.step(time[sel], command[sel], where="post", color=teal, lw=2.1,
                label="命令" if start == 0 else None)
        ax.plot(time[sel], position[sel], color=blue, ls="--", lw=2.1,
                label="传感读数" if start == 0 else None)
    ax.set_xlim(23.2, 30.7)
    ax.set_ylim(-10, 111)
    ax.set_yticks([0, 50, 100])
    ax.set_ylabel("第 14 维\n原始数值", rotation=0, labelpad=17, fontsize=12)
    ax.set_xlabel("距首帧的采集时间（秒）", fontsize=12)
    ax.grid(axis="y", color="#d1d9dc", lw=.7)
    ax.set_axisbelow(True)
    ax.text((time[404]+time[405])/2, 52, "两帧相隔 2.27 s\n中间没有记录",
            ha="center", va="center", fontsize=12, color="#314250",
            bbox={"facecolor":"#e9edf0","edgecolor":"none","pad":2})
    ax.legend(loc="upper left", bbox_to_anchor=(0,1.35), ncol=2, frameon=False,
              markerfirst=True, handlelength=2.5, fontsize=12)
    ax.text(time[369], 108, "接管", ha="center", va="bottom", color=sienna, fontsize=11)
    ax.text(time[405], 108, "交还", ha="center", va="bottom", color=teal, fontsize=11)
    panel = fig.add_subplot(grid[3, :])
    panel.set_axis_off()
    panel.text(0, .90, "同一次记录的一步预测误差", color="#18384a", size=14, weight="bold")
    panel.text(0, .50, "训练　自主前段 368 对相邻帧", color="#33474d", size=12)
    panel.text(0, .15, "指标　平均绝对误差（原始数值）", color="#33474d", size=11)
    for col, (label, item) in enumerate(zip(("接管段", "交还后"), results["evaluation"])):
        x = .435 + .292 * col
        panel.text(x, .89, f"{label}　{item['n']} 对", color=sienna if col == 0 else teal,
                   size=13, weight="bold")
        panel.text(x, .50, f"沿用当前读数　{item['mae_persistence']:.2f}", color="#33474d", size=12)
        panel.text(x, .15, f"加上本步命令　{item['mae_action_conditioned']:.2f}", color="#33474d", size=12)
    fig.savefig(FIGURE)
    plt.close(fig)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--capture-from", type=Path)
    parser.add_argument("--wrist-video", type=Path)
    args = parser.parse_args()
    metadata = json.loads((DATA / "mixed-trace-source.json").read_text())
    if args.capture_from:
        extract_clock(args.capture_from, metadata)
    if args.wrist_video:
        extract_wrist(args.wrist_video)
    t, u, o, human = read_columns()
    results = fit_and_test(t, u, o, human, metadata["fps"])
    (DATA / "r1lite-response-results.json").write_text(
        json.dumps(results, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    draw(t, u, o, results)


if __name__ == "__main__":
    main()
