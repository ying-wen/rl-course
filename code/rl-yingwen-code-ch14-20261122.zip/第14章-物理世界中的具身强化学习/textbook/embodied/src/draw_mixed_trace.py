"""Draw the intervention evidence from the packaged frames and numeric record."""
import csv
from pathlib import Path
import subprocess

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.offsetbox import AnchoredText
from PIL import Image

from print_figures import print_files

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
POLICY, HUMAN, OBS = "#196763", "#a84d12", "#285786"


def main():
    for family in ("FandolHei-Regular.otf", "FandolHei-Bold.otf"):
        font = subprocess.check_output(["kpsewhich", family], text=True).strip()
        if font:
            font_manager.fontManager.addfont(font)
    plt.rcParams.update({"font.family": ["FandolHei", "DejaVu Sans"], "svg.fonttype": "path",
                         "axes.spines.top": False, "axes.spines.right": False,
                         "axes.unicode_minus": False, "font.size": 12})
    with (DATA / "mixed-trace.csv").open() as stream:
        rows = list(csv.DictReader(stream))
    t = [float(row["dataset_time_s"]) for row in rows]
    command = [float(row["action_qpos_14"]) for row in rows]
    measured = [float(row["observation_qpos_14"]) for row in rows]

    fig = plt.figure(figsize=(10.8, 4.48))
    fig.subplots_adjust(.084,.11,.975,.91,wspace=.055,hspace=.55)
    grid = fig.add_gridspec(2,3,height_ratios=(1.09,1))
    for column,(frame,description) in enumerate([(355,"策略执行"),(397,"人工接管"),(423,"交还策略")]):
        ax = fig.add_subplot(grid[0,column])
        with Image.open(DATA / f"mixed-trace-frame-{frame}.jpg") as im:
            ax.imshow(im)
        color = HUMAN if rows[frame]["intervention"] == "1" else POLICY
        ax.set_title(f"{description}　{t[frame]:.2f} s",loc="left",fontsize=13,color=color,pad=4)
        ax.add_artist(AnchoredText(f"帧 {frame}",loc="lower left",borderpad=.25,pad=.15,
                                   frameon=False,prop={"size":10,"color":"white",
                                                       "bbox":{"facecolor":"#222222","alpha":.70,"edgecolor":"none","pad":2}}))
        ax.set_axis_off()

    ax = fig.add_subplot(grid[1,:])
    ax.axvspan(t[369],t[405],color="#fbe4d2",zorder=-2)
    ax.plot(t,command,color=POLICY,lw=2.5,label="下发命令",zorder=2)
    ax.plot(t,measured,color=OBS,ls="--",lw=2.1,label="传感读数",zorder=3)
    ax.set_xlim(22.5,29.5); ax.set_ylim(-8,110)
    ax.set_yticks([0,50,100]); ax.set_ylabel("第14维\n记录值",rotation=0,labelpad=22,fontsize=11)
    ax.set_xlabel("数据集时间（秒）",fontsize=11,labelpad=1)
    ax.spines["bottom"].set_color("#70848a");ax.spines["left"].set_color("#70848a")
    ax.grid(axis="y",color="#d4dbdd",lw=.6,zorder=-1);ax.set_axisbelow(True)
    for i,source,label in [(369,HUMAN,"接管 24.60 s"),(405,POLICY,"交还 27.00 s")]:
        ax.axvline(t[i],color=source,lw=1,ls=":",zorder=1)
        ax.text(t[i],1.033,label,color=source,fontsize=11,
                ha="center",transform=ax.get_xaxis_transform())
    ax.legend(loc="lower left",fontsize=10,frameon=True,edgecolor="#dddddd",
              framealpha=.94,handlelength=2.5,ncol=2)
    fig.savefig(ROOT / "figures/mixed-trace.svg")
    plt.close(fig)
    print_files(ROOT / "figures",["mixed-trace"])


if __name__ == "__main__":
    main()
