"""Extract the fixed R1Lite episode and three synchronized head-camera frames.

Requires duckdb, ffmpeg and ffprobe. Usage: python3 src/extract_mixed_trace.py
The source repository, revision and input hashes identify one published deployment.
"""
import csv
import hashlib
import json
from pathlib import Path
import subprocess
import tempfile
import urllib.request

import duckdb

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
DATASET = "https://huggingface.co/datasets/BodenAI/RW-RL-HIL-Dataset"
REVISION = "9290f5a96dc91ea58256e81d9ce2dd9621890b51"
TASK = "replace_tissue_box_and_pull_out_first_tissue"
PARQUET = TASK + "/data/chunk-000/episode_000000.parquet"
VIDEO = TASK + "/videos/chunk-000/observation.images.cam_high/episode_000000.mp4"
HASHES = {
    PARQUET: "2df19151db7abde503bf4ebd2979655ce8987537bb1926190af688ab33d436cb",
    VIDEO: "4d43d8569577c6d64905d8cb366597b2d949d7eac461fcb1defbbcbdbf5be21b",
}
SELECTED_FRAMES = [355, 397, 423]


def load(path):
    url = f"{DATASET}/resolve/{REVISION}/{path}"
    with urllib.request.urlopen(url, timeout=45) as response:
        contents = response.read()
    if path in HASHES and hashlib.sha256(contents).hexdigest() != HASHES[path]:
        raise ValueError(f"SHA-256 mismatch: {path}")
    return contents


def main():
    data_dir = DATA
    data_dir.mkdir(exist_ok=True)
    episode = json.loads(load(TASK + "/meta/episodes.jsonl").splitlines()[0])
    info = json.loads(load(TASK + "/meta/info.json"))
    with tempfile.TemporaryDirectory() as directory:
        parquet = Path(directory) / "episode.parquet"
        parquet.write_bytes(load(PARQUET))
        with duckdb.connect() as db:
            rows = db.execute(
                """SELECT frame_index,timestamp,control_source,intervention,
                          "action.qpos"[14],"observations.state.qpos"[14]
                   FROM read_parquet(?) WHERE episode_index=0 ORDER BY frame_index""",
                [str(parquet)],
            ).fetchall()
        video = Path(directory) / "head.mp4"
        video.write_bytes(load(VIDEO))
        video_meta = json.loads(subprocess.check_output([
            "ffprobe", "-v", "error", "-show_entries", "stream=nb_frames,r_frame_rate",
            "-select_streams", "v:0", "-of", "json", str(video),
        ]))["streams"][0]
        assert len(rows) == episode["length"] == int(video_meta["nb_frames"]) == 473
        assert info["fps"] == 15 and video_meta["r_frame_rate"] == "15/1"
        assert [row[0] for row in rows] == list(range(473))
        assert all(abs(t-i/15) < 1e-7 for i,t,*_ in rows)
        assert len(episode["intervention_ranges"]) == 1
        interval = episode["intervention_ranges"][0]
        assert (interval["start_frame"], interval["end_frame"]) == (369,404)
        assert all(flag == (369 <= i <= 404) and (source == "intervention") == flag
                   and source in ("policy","intervention") for i,_,source,flag,*_ in rows)
        for frame in SELECTED_FRAMES:
            subprocess.run([
                "ffmpeg", "-hide_banner", "-loglevel", "error", "-i", str(video),
                "-vf", f"select=eq(n\\,{frame})", "-frames:v", "1", "-q:v", "3",
                "-y", str(data_dir / f"mixed-trace-frame-{frame}.jpg"),
            ], check=True)
    with (data_dir / "mixed-trace.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(["frame","dataset_time_s","control_source","intervention",
                         "action_qpos_14","observation_qpos_14"])
        for frame,t,source,intervention,command,position in rows:
            writer.writerow([frame,f"{t:.8f}",source,int(intervention),
                             f"{command:.8f}",f"{position:.8f}"])
    manifest = {
        "dataset": DATASET, "revision": REVISION, "release_commit_utc": "2026-09-17T10:14:16Z",
        "credit": "Boden Intelligence; Junpu Innovation Center; MINT Lab, Shanghai Jiao Tong University",
        "license": "CC BY 4.0", "license_url":"https://creativecommons.org/licenses/by/4.0/",
        "input_sha256": HASHES, "episode_metadata": episode, "fps": info["fps"],
        "parquet_fields": [name for name in info["features"] if not name.startswith("observation.images.")],
        "source_convention": {"policy": "deployed policy", "intervention":"human correction"},
        "plotted_component": "14th element of action.qpos and observations.state.qpos (one-based); names and units unspecified",
        "frame_source": VIDEO, "selected_video_frames_zero_based": SELECTED_FRAMES,
        "modifications": "Selected three video frames, converted to JPEG; excerpted one native coordinate from the matched Parquet.",
        "time_axis": "retained episode time at 15 Hz",
        "missing": ["reward","done","task success","takeover reason","unexecuted policy proposal"],
    }
    (data_dir / "mixed-trace-source.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    print(f'{len(rows)} frames, {sum(row[3] for row in rows)} under human control.')


if __name__ == "__main__":
    main()
