"""A continuing workcell with ambiguous grasp failures. Run with Python 3 + NumPy.

Every policy has the same observations, closed-loop skills and access to maintenance.
The analytical response model is supplied. Bayesian filtering is online; neither
the response model nor the motor skills are learned in this experiment.

K[a,y,i,j] = P(observation y, next state j | current state i, action a).
An observation belongs to the current workpiece. During an action, hazards evolve
in physical time. A successful delivery loads the next piece, and a service
finishes by restoring its own component. These two operations each leave the
rest of the workcell in place.

Planning scores a small class of contingent plans over the next min(14, time
left) ticks. With work or service now, a plan can include one service of each
type before repeatedly applying one skill. A dedicated test now can choose
any such plan conditional on its result. All later real observations trigger
replanning. Fixed-period rules are implemented at the execution clock; the
local score does not anticipate future compulsory appointments.

"""
from itertools import product
from pathlib import Path
import json
import xml.etree.ElementTree as ET

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
TICKS = 160
LOOKAHEAD = 14
FIT = tuple(range(64))
TEST = tuple(range(10000, 10512))
PERIODS = (8, 16, 32, 64, 0)  # 0 = no scheduled intervention
PARAMS = {"slow": (.0015, .002), "frequent": (.018, .025)}
STATES = np.asarray(list(product(range(2), repeat=3)), dtype=int)
ITEM, PAD, ZERO = STATES.T
ACTIONS = ("standard", "compliant", "pad_test", "zero_test", "replace", "calibrate")
STD, ALT, PAD_TEST, ZERO_TEST, REPLACE, CALIBRATE = range(6)
DURATION = np.array([1, 1, 1, 1, 4, 3])
FEE = np.array([0., 0., .06, .06, .55, .35])
P_ITEM = np.array([.08, .72])  # P(next piece slippery | current piece type)
START_ITEM = .20
P_SUCCESS = np.array([
    np.where((ITEM + PAD + ZERO) == 0, .94, .28),
    np.where((PAD + ZERO) > 0, .27, np.where(ITEM > 0, .86, .71))
])
RAW_OBS = np.vstack((P_SUCCESS, np.where(PAD, .91, .09), np.where(ZERO, .94, .06)))
SCHEMES = ("adaptive", "fixed_probe", "fixed_cal", "fixed_both")


def kernels(hazards, response=RAW_OBS):
    """K[a,y,i,j] includes both likelihood and ensuing state transition."""
    K = np.zeros((6, 2, 8, 8))
    for a in range(6):
        wear, drift = 1. - (1. - np.array(hazards)) ** DURATION[a]
        for i, (piece, pad, zero) in enumerate(STATES):
            py = response[a,i] if a < REPLACE else 1.
            for y, likelihood in enumerate((1. - py, py)):
                p = P_ITEM[piece] if a < PAD_TEST and y == 1 else piece
                w = 0. if a == REPLACE else pad + (1. - pad) * wear
                d = 0. if a == CALIBRATE else zero + (1. - zero) * drift
                K[a,y,i,:] = likelihood * np.where(ITEM,p,1.-p) * np.where(PAD,w,1.-w) * np.where(ZERO,d,1.-d)
    assert np.allclose(K.sum(axis=(1,3)), 1.)
    return K


def planning_model(K):
    """Exact returns of restricted plans: at most two services, then one fixed skill."""
    P = K.sum(axis=1)
    plans = [(service, skill) for service in ((), (REPLACE,), (CALIBRATE,),
                                                (REPLACE, CALIBRATE), (CALIBRATE, REPLACE))
             for skill in (STD,ALT)]
    actions = np.array([sr[0] if sr else a for sr,a in plans])
    V = np.zeros((LOOKAHEAD+1,len(plans),8))
    valid = np.zeros((LOOKAHEAD+1,len(plans)),dtype=bool)
    work = np.zeros((LOOKAHEAD+1,2,8))
    for h in range(1,LOOKAHEAD+1):
        for a in (STD,ALT):
            work[h,a] = 1.15 * P_SUCCESS[a] - .15 + P[a] @ work[h-1,a]
        for j,(sr,a) in enumerate(plans):
            left = h-sum(DURATION[s] for s in sr)
            if left < 1:
                continue
            v = work[left,a]
            for s in reversed(sr):
                v = P[s] @ v - FEE[s]
            V[h,j] = v
            valid[h,j] = True
    return V,valid,actions


def choose(b,t,scheme,due_probe,due_cal,K,plan):
    """Probe value compares future conditional choices against direct action."""
    h = min(LOOKAHEAD,TICKS-t)
    V,valid,first = plan
    fixed_probe = scheme in ("fixed_probe", "fixed_both")
    fixed_cal = scheme in ("fixed_cal", "fixed_both")
    # A prescheduled calibration replaces discretionary calibration. All methods
    # can change skills, replace a pad, and choose the more informative test.
    available = valid[h].copy()
    if fixed_cal:
        available[4:] = False  # includes every plan with a calibration
    scores = (b @ V[h].T)[:,available]
    choice = np.argmax(scores,axis=1)
    best, actions = scores.max(axis=1), first[available][choice].copy()
    if h >= 2:
        avail_next = valid[h-1].copy()
        if fixed_cal:
            avail_next[4:] = False
        next_v = V[h-1,avail_next].T
        probe = []
        for a in (PAD_TEST,ZERO_TEST):
            # bK_y is unnormalised. Its maximum expected plan value already
            # includes P(y|b,a); no division by small posterior probabilities.
            ev = sum(((b @ K[a,y]) @ next_v).max(axis=1) for y in (0,1)) - FEE[a]
            probe.append(ev)
        ps = np.stack(probe,axis=1)
        use = (due_probe <= t) if fixed_probe else ps.max(axis=1) > best
        actions[use] = PAD_TEST + ps[use].argmax(axis=1)
    if fixed_cal and t + DURATION[CALIBRATE] <= TICKS:
        actions[due_cal <= t] = CALIBRATE
    return actions


def tape(seeds, hazards):
    def one(seed):
        gen = np.random.default_rng(seed)
        return (gen.random(TICKS+1),gen.random((TICKS,2)),gen.random((TICKS,3)))
    items, breakdown, obs = [np.stack(c) for c in zip(*(one(seed) for seed in seeds))]
    pieces = np.zeros_like(items,dtype=int)
    pieces[:,0] = items[:,0] < START_ITEM
    for j in range(1,TICKS+1):
        pieces[:,j] = items[:,j] < P_ITEM[pieces[:,j-1]]
    return pieces, breakdown < np.array(hazards), obs


def simulate(data, K, plan, scheme, periods=(0,0), keep_trace=False, response=RAW_OBS):
    pieces,hazards,noise = data
    n = len(pieces)
    b = np.zeros((n,8))
    b[:,[0,4]] = [1.-START_ITEM,START_ITEM]
    next_t, completed, failures = (np.zeros(n,dtype=int) for _ in range(3))
    pad,zero = (np.zeros(n,dtype=bool) for _ in range(2))
    counts = np.zeros((n,6),dtype=int)
    net = np.zeros(n)
    due_probe = np.full(n,periods[0] or TICKS+1)
    due_cal = np.full(n,periods[1] or TICKS+1)
    trace = []
    for t in range(TICKS):
        ready = np.where(next_t == t)[0]
        if not len(ready):
            continue
        acts = choose(b[ready],t,scheme,due_probe[ready],due_cal[ready],K,plan)
        for a in range(6):
            at = ready[acts == a]
            if not len(at):
                continue
            dt = DURATION[a]
            assert t+dt <= TICKS
            pi = pieces[at,completed[at]]
            truth = 4*pi + 2*pad[at] + zero[at]
            if a < REPLACE:
                channel = 0 if a < PAD_TEST else a-1
                y = (noise[at,t,channel] < response[a,truth]).astype(int)
            else:
                y = np.ones(len(at),dtype=int)
            reward = (1.15*y-.15) if a < PAD_TEST else np.full(len(at),-FEE[a])
            if a < PAD_TEST:
                completed[at] += y
                failures[at] += 1-y
            if a in (PAD_TEST,ZERO_TEST) and periods[0]:
                due_probe[at] = t+periods[0]
            if a == CALIBRATE and periods[1]:
                due_cal[at] = t+periods[1]
            counts[at,a] += 1
            net[at] += reward
            next_t[at] = t+dt
            if keep_trace and at[0] == 0:
                prior = (b[0] @ STATES).tolist()
                post_observation = b[0] * K[a,y[0]].sum(axis=1)
                post_observation /= post_observation.sum()
            for outcome in np.unique(y):
                idx = at[y == outcome]
                after = b[idx] @ K[a,outcome]
                b[idx] = after/after.sum(axis=1,keepdims=True)
            pad[at] |= hazards[at,t:t+dt,0].any(axis=1)
            zero[at] |= hazards[at,t:t+dt,1].any(axis=1)
            if a == REPLACE:
                pad[at] = False
            if a == CALIBRATE:
                zero[at] = False
            if keep_trace and at[0] == 0:
                trace.append(dict(t=int(t),duration=int(dt),a=ACTIONS[a],y=int(y[0]),
                                  prior=mround(prior),post_observation=mround(post_observation @ STATES),
                                  next_b=mround(b[0] @ STATES),net=round(float(net[0]),3)))
    assert np.all(next_t == TICKS) and np.all(counts @ DURATION == TICKS)
    assert np.allclose(net,completed-.15*failures-counts @ FEE)
    assert np.allclose(b.sum(axis=1),1)
    return net,completed,failures,counts,trace


def mround(v):
    return [round(float(x),4) for x in v]


def tune(scheme,data,K,plan,require_probe=False):
    candidates = tuple(p for p in PERIODS if p) if require_probe else PERIODS
    probes = candidates if scheme in ("fixed_probe","fixed_both") else (0,)
    cals = PERIODS if scheme in ("fixed_cal","fixed_both") else (0,)
    scored = []
    for p,c in product(probes,cals):
        net,*_ = simulate(data,K,plan,scheme,(p,c))
        scored.append((float(net.mean()),p,c))
    val,p,c = max(scored)  # deterministic ties
    return (p,c),round(val,3)



def reliability_stress():
    """Degrade only the real zero-test channel. No refit on held-out shifts."""
    hazards = PARAMS["frequent"]
    data = tape(TEST,hazards)
    nominal = kernels(hazards)
    nom_plan = planning_model(nominal)
    out = {}
    for reliability in (.70,.50):
        response = RAW_OBS.copy()
        response[ZERO_TEST] = np.where(ZERO,reliability,1.-reliability)
        actual = kernels(hazards,response)
        actual_plan = planning_model(actual)
        policies = (("assumes_094",nominal,nom_plan,"adaptive"),
                    ("known_reliability",actual,actual_plan,"adaptive"),
                    ("no_dedicated_probe",actual,actual_plan,"fixed_probe"))
        nets, details = {}, {}
        for key,K,plan,scheme in policies:
            net,done,fail,counts,_ = simulate(data,K,plan,scheme,response=response)
            nets[key] = net
            details[key] = dict(net=round(net.mean(),3),mean_completed=round(done.mean(),3),
                                mean_failures=round(fail.mean(),3),
                                mean_action_counts=dict(zip(ACTIONS,mround(counts.mean(axis=0)))))
        differences = {}
        for name,first,second in (("known_minus_misspecified","known_reliability","assumes_094"),
                                  ("known_minus_no_probe","known_reliability","no_dedicated_probe"),
                                  ("misspecified_minus_no_probe","assumes_094","no_dedicated_probe")):
            pair = nets[first]-nets[second]
            margin = 1.96*pair.std(ddof=1)/np.sqrt(len(TEST))
            differences[name] = dict(mean=round(pair.mean(),3),
                                     paired_mc95=mround([pair.mean()-margin,pair.mean()+margin]))
        out[f"{reliability:.2f}"] = dict(policies=details,differences=differences)
    return out

def run():
    res = {}
    for name,hazards in PARAMS.items():
        K = kernels(hazards)
        plan = planning_model(K)
        fit, test = tape(FIT,hazards),tape(TEST,hazards)
        rows = {}
        for key in (*SCHEMES,"fixed_positive_probe"):
            scheme = "fixed_probe" if key == "fixed_positive_probe" else key
            periods,train_score = tune(scheme,fit,K,plan,key == "fixed_positive_probe")
            net,done,fail,counts,trace = simulate(test,K,plan,scheme,periods,scheme=="adaptive")
            if scheme == "adaptive":
                reference = net
                first_trace = trace
            paired = reference-net
            margin = 1.96*paired.std(ddof=1)/np.sqrt(len(TEST))
            rows[key] = dict(interval_probe=periods[0],interval_calibration=periods[1],
                 fit_mean=train_score,net=round(net.mean(),3),sd=round(net.std(ddof=1),3),
                 mean_completed=round(done.mean(),3),mean_failures=round(fail.mean(),3),
                 mean_action_counts=dict(zip(ACTIONS,mround(counts.mean(axis=0)))),
                 adaptive_minus_baseline=round(paired.mean(),3),
                 paired_mc95=mround([paired.mean()-margin,paired.mean()+margin]))
        res[name] = dict(wear_drift_per_tick=hazards,results=rows,first_test_trace=first_trace)
    return dict(ticks=TICKS,lookahead=LOOKAHEAD,fit_seeds=[FIT[0],FIT[-1]],
                evaluation_seeds=[TEST[0],TEST[-1]],candidate_periods=PERIODS,
                initial_slippery=START_ITEM,next_slippery_by_current=P_ITEM.tolist(),
                state_order=["slippery","worn","offset"],duration=DURATION.tolist(),
                fee=FEE.tolist(),success=P_SUCCESS.tolist(),observation_positive=RAW_OBS.tolist(),
                order=ACTIONS,regimes=res,zero_test_reliability_stress=reliability_stress())


def figure(results):
    """One physical interface, one observed intervention, and held-out shifts."""
    width, height = 880, 836
    root = ET.Element("svg", xmlns="http://www.w3.org/2000/svg", viewBox=f"0 0 {width} {height}",
                      width=str(width), height=str(height), role="img")
    ET.SubElement(root, "title").text = "抓取失败的鉴别与无重置作业的全程净收益"
    ET.SubElement(root, "desc").text = (
        "标准抓取对三种单一异常给出相同失败概率。测指垫、核零点分别区分磨损和漂移。"
        "图示留出班次10000的实际模拟轨迹，以及每种策略在512个同工时留出班次的表现。"
    )
    ink, muted, linec = "#152e40", "#4d6272", "#b5c7cf"
    cold, hot, green = "#22608c", "#a65329", "#166a62"

    def put(tag, **attrs):
        return ET.SubElement(root, tag, {k.replace("_","-"):str(v) for k,v in attrs.items()})

    def txt(x,y,value,size=16,color=ink,weight=400,anchor="start"):
        el = put("text",x=x,y=y,fill=color,font_size=size,font_weight=weight,text_anchor=anchor,
                 font_family="PingFang SC, Noto Sans CJK SC, Microsoft YaHei, sans-serif")
        el.text=str(value)

    def rect(x,y,w,h,fill,stroke="none",r=0):
        put("rect",x=x,y=y,width=w,height=h,rx=r,fill=fill,stroke=stroke)

    def line(x,y,x2,y2,color=linec,sw=1.4):
        put("line",x1=x,y1=y,x2=x2,y2=y2,stroke=color,stroke_width=sw,stroke_linecap="round")

    def dot(x,y,r,color):
        put("circle",cx=x,cy=y,r=r,fill=color)

    rect(0,0,width,height,"white")
    txt(27,36,"同一次抓取失败，三种可能的物理变化",26,ink,650)
    txt(28,66,"标准抓取失败概率 0.72。工件、指垫或零点中仅一项异常时，这个读数完全相同。",17)
    cards = ((28,"工件表面变化","标准 / 柔顺成功率","0.28 / 0.86","复用柔顺抓取"),
             (311,"指垫磨损","测垫显示磨损","0.91","更换指垫，再操作"),
             (594,"传感器零点漂移","零点检查呈阳性","0.94","重新标定，再操作"))
    for j,(x,title,label,value,decision) in enumerate(cards):
        rect(x,89,259,151,"#f4f8fa","#d7e3e8",8)
        txt(x+15,117,title,18,ink,650)
        if j==0:
            for i in range(4):
                line(x+182+i*9,108,x+190+i*9,101,green,2)
            line(x+177,114,x+225,114,green,4)
        if j==1:
            line(x+173,101,x+223,101,green,3)
            for i in range(4):
                line(x+178+i*12,105,x+178+i*12,109+(i%2)*4,green,4)
        if j==2:
            line(x+172,110,x+228,110,green,2)
            for i in range(5):
                line(x+176+i*11,105,x+176+i*11,110,green,1.5)
            dot(x+207,106,4,hot)
        txt(x+15,148,label,15,muted)
        txt(x+15,178,value,23,green,650)
        line(x+15,192,x+242,192)
        txt(x+15,219,decision,17,ink,560)
    txt(28,270,"探测只增加观测。换垫和标定改变其中一个部件。多种异常可以并存。",15,muted)
    line(28,288,851,288)
    txt(28,321,"同一作业流中的一次标定",22,ink,650)
    txt(28,345,"较高故障率，首个留出班次。横向长度表示实际占用工时。",15,muted)
    trace = results["regimes"]["frequent"]["first_test_trace"]
    first_test = next(e for e in trace if e["a"] == "zero_test")
    t0 = first_test["t"]
    events = [e for e in trace if t0-2<=e["t"]<=t0+4]
    for e in events:
        t = e["t"]
        x = 33+(t-t0+2)*115
        result = {"compliant":("柔顺抓取", "成功" if e["y"] else "失败"),
                  "zero_test":("核零点","阳性" if e["y"] else "阴性"),
                  "calibrate":("重新标定", "3 步")}[e["a"]]
        w=115*e["duration"]-5
        fill = "#e7f3ef" if e["a"]=="compliant" and e["y"] else (
               "#faeee7" if e["a"]=="compliant" else "#e3edf5")
        rect(x,377,w,66,fill,"none",5)
        txt(x+w/2,403,result[0],16,ink,550,"middle")
        txt(x+w/2,428,result[1],15,muted,400,"middle")
        txt(x,369,t,14,muted)
    txt(838,369,events[-1]["t"]+1,14,muted,400,"end")
    service = next(e for e in events if e["a"]=="calibrate")
    txt(32,472,f'核零点前后，漂移概率 {first_test["prior"][2]:.2f} → {first_test["post_observation"][2]:.2f}。'
        f'标定完成后漂移概率为零，磨损概率仍为 {service["next_b"][1]:.2f}。',16)
    line(28,495,851,495)
    txt(28,529,"相同 160 个时步内的净收益",22,ink,650)
    txt(28,554,"每次交付 +1，失败 −0.15，另扣干预成本。标定或换垫时，工位无法交付。",15,muted)
    column = (("adaptive","按价值选择"),("fixed_probe","定期探测¹"),("fixed_positive_probe","定期探测（须测）"),
              ("fixed_cal","定期标定"),("fixed_both","两者定期"))
    xlo,xhi=244,760
    def px(n): return xlo+(n-65)/50*(xhi-xlo)
    for num in (70,80,90,100,110):
        x=px(num)
        line(x,583,x,753,"#dee8ec",1)
        txt(x,580,num,14,muted,400,"middle")
    for i,(key,name) in enumerate(column):
        y=604+i*34
        txt(32,y+5,name,16,ink,600 if i==0 else 400)
        low=results["regimes"]["slow"]["results"][key]["net"]
        high=results["regimes"]["frequent"]["results"][key]["net"]
        line(px(high),y,px(low),y,"#b1bfc8",2)
        dot(px(high),y,5.4,hot)
        dot(px(low),y,5.4,cold)
        txt(px(high)-11,y+5,f"{high:.1f}",14,hot,600,"end")
        txt(px(low)+11,y+5,f"{low:.1f}",14,cold,600)
    dot(39,775,5,hot);txt(52,780,"较高故障率",15,hot,550)
    dot(176,775,5,cold);txt(189,780,"较低故障率",15,cold,550)
    txt(344,780,"每点为 512 个留出班次的均值。",15,muted)
    txt(29,811,"¹ 调参允许不做专门探测，两种工况均选中这一频率。抓取成败仍用于更新信念。",15,muted)
    ET.ElementTree(root).write(ROOT/"figures/physical-diagnosis20.svg",encoding="utf-8",xml_declaration=True)


if __name__ == "__main__":
    result = run()
    out = ROOT/"data/physical-diagnosis20.json"
    out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    figure(result)
    print(f"Written {out.name} and physical-diagnosis20.svg")
