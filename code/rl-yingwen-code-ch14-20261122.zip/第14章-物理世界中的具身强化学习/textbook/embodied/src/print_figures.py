"""Print path-outlined Matplotlib SVGs as vector PDFs (no system CJK fonts required)."""
import base64
from pathlib import Path
from xml.etree import ElementTree as ET
from playwright.sync_api import sync_playwright
def print_files(directory,names):
    with sync_playwright() as p:
        mac='/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'
        b=p.chromium.launch(executable_path=mac if Path(mac).exists() else None)
        page=b.new_page()
        for name in names:
            f=directory/(name+'.svg');svg=ET.fromstring(f.read_bytes())
            w,h=map(float,svg.attrib['viewBox'].split()[2:])
            url='data:image/svg+xml;base64,'+base64.b64encode(f.read_bytes()).decode()
            # Print within an HTML document to avoid the browser's SVG document zoom.
            page.set_content(f'<style>@page{{size:{w}pt {h}pt;margin:0}}*{{margin:0;padding:0}}img{{display:block;width:{w}pt;height:{h}pt}}</style><img src="{url}">')
            page.wait_for_function('document.images[0].complete && document.images[0].naturalWidth>0')
            page.pdf(path=str(directory/(name+'.pdf')),print_background=True,prefer_css_page_size=True)
        b.close()
if __name__=='__main__': print_files(Path(__file__).resolve().parents[1]/'figures',('aloha','probe'))
