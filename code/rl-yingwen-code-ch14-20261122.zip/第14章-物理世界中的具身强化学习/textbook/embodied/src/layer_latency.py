"""分层系统的三个算例（第 14 章“按时间尺度分层”一小节）。

1. 发散模态：线性倒立摆的发散分量 xi 满足 d xi/dt = omega (xi - p)。
   纠正动作要过 ell 秒才生效，其间扰动放大 exp(omega*ell) 倍。
2. 带时延的比例反馈 p(t) = K xi(t-ell)：扫描增益，检验 omega*ell < 1 是能否镇定的分界。
3. 接触：以速度 v 接近刚度 k_e 的表面，力的超调约为 k_e * v * ell。

只用标准库，可重复运行：python3 layer_latency.py
"""
import math

G = 9.81
Z = 0.90                      # 质心高度，米
OMEGA = math.sqrt(G / Z)      # 发散速率，1/秒


def growth(ell):
    return math.exp(OMEGA * ell)


def stable_with_delay(ell, gain, t_end=20.0, dt=1e-4):
    """d xi/dt = omega*xi - gain*omega*xi(t-ell)，欧拉积分；返回末段幅值是否小于初值。"""
    n_delay = max(1, int(round(ell / dt)))
    hist = [1.0] * (n_delay + 1)
    xi = 1.0
    steps = int(t_end / dt)
    peak_late = 0.0
    for i in range(steps):
        delayed = hist[0]
        xi = xi + dt * OMEGA * (xi - gain * delayed)
        hist.pop(0)
        hist.append(xi)
        if abs(xi) > 1e6:
            return False
        if i > steps * 0.8:
            peak_late = max(peak_late, abs(xi))
    return peak_late < 0.5


def any_gain_stabilizes(ell):
    gains = [1.0 + 0.02 * j for j in range(1, 200)]
    return [g for g in gains if stable_with_delay(ell, g)]


if __name__ == "__main__":
    print(f"质心高 {Z} m，omega = {OMEGA:.2f} /s，时间常数 {1/OMEGA:.3f} s")
    print("\n1. 纠正生效前扰动的放大倍数 exp(omega*ell)")
    for ell in (0.001, 0.005, 0.02, 0.1, 0.3, 1.0):
        g = growth(ell)
        print(f"   ell = {ell*1000:7.0f} ms   放大 {g:8.3f}   1 cm 的扰动变为 {g:7.2f} cm")
    half_foot = 0.10
    print(f"   脚掌半长 {half_foot*100:.0f} cm：1 cm 扰动仍可在脚掌内纠正的最大时延 "
          f"{math.log(half_foot/0.01)/OMEGA*1000:.0f} ms")

    print("\n2. 带时延的比例反馈：是否存在能镇定的增益")
    for prod in (0.3, 0.6, 0.9, 1.1, 1.5):
        ell = prod / OMEGA
        gs = any_gain_stabilizes(ell)
        rng = f"增益 {gs[0]:.2f}–{gs[-1]:.2f}" if gs else "无"
        print(f"   omega*ell = {prod:.1f} (ell = {ell*1000:5.0f} ms)   可镇定：{rng}")

    print("\n3. 接触力超调 k_e * v * ell（k_e = 1e4 N/m，v = 0.1 m/s）")
    for ell in (0.001, 0.02, 0.1, 1.0):
        print(f"   ell = {ell*1000:6.0f} ms   超调 {1e4*0.1*ell:7.1f} N")
