# 具身强化学习的经验来源与实验条件，2016–2026

这些研究都试图让机器人根据经验改善行为，能够使用的经验却很不相同。阅读一项结果时，先确定机器人所能选择的命令，再确定经验中有无实发命令、可测的后果和委托者的评价。最后看作者在记录上预测了什么，在真机上实际比较了什么。这几项信息决定了一个结果能否用来改进另一台机器的控制策略。

所选材料截至 2026 年 11 月 12 日。以下按信息条件分组，组内按原论文或项目首次公开的大致时间排列。选入有明确的学习对象、公开实验或可检查的数据字段的工作。公司披露的实验按作者报告解读，单次演示、仿真、离线测量与实机对照各有其适用范围。

真机材料分别对应下列问题。控制权限和任务覆盖见[控制接口与可达性](reading.html#physical-task-coverage)，能否从示范识别动作后果见[数据覆盖与辨识](reading.html#physical-acquisition-comparison)，技能执行中的状态抽象见[时间抽象与技能规划](reading.html#sensorimotor-planning)，无重置时的适应收益见[全程评价](reading.html#physical-budget-deployment)。各机构的硬件、训练资料与验收条件集中在[实机比较附录](reading.html#embodied-system-comparison)。

讲座按其解释的决定放入正文。可从[接触模式与动作响应](reading.html#physical-control-limits)、[用传感器作为预测目标](reading.html#physical-sensorimotor-predictions)、[模拟环境与智能体内部的规划模型](reading.html#physical-world-model-purpose)以及[规划中被放大的估值误差](reading.html#physical-aloha-ranking)进入；各处均附原讲座或当堂讲义。温颖所讨论的经验复用另见[交班时保留的知识](reading.html#physical-persistent-evaluation)。

[测量与控制的价值](reading.html#physical-information-for-action)对照 [ASID 主动辨识](https://arxiv.org/html/2404.12308v2#S5.SS5)与 [TacThru 的同轨迹输入对照](https://arxiv.org/html/2512.09851v2#S5.SS2)。[仪器、末端与持续部署](reading.html#physical-instrumented-agent)结合 [RFusion](https://www.mit.edu/~fadel/papers/RFusion-paper.pdf)、[UMI](https://arxiv.org/html/2402.10329v1#S5.SS2) 和[工业臂误差补偿](https://doi.org/10.1109/TASE.2023.3328835)，给出各自的计量单位与实机比较条件。

实机评价有两种不同的采样单位。RoboArena 在同一试验条件下双盲比较两项策略，Liao 等人固定策略并主动选取下一组配置。前者估计成对偏好，后者估计工况条件下的得分。两者的试次分布与现场来料分布可以不同。[实机研究的控制条件](reading.html#embodied-system-comparison) · [RoboArena](https://proceedings.mlr.press/v305/atreya25a.html) · [主动选择实机测试条件](https://arxiv.org/html/2607.14439v1#S4)

## 一　真机试错、离线策略改进与结果核验

| 工作 | 由经验估计的量 | 物理试验支持的结论 |
|---|---|---|
| **2016　大规模手眼协调** | 多台机械臂实际试抓，从图像与候选运动预测最终抓取的成功概率，用预测引导闭环修正。 | 可从不同机器的抓取经验学习视觉伺服。完成判据和机械臂的操作分布限定了预测的含义。[Levine 等，论文](https://arxiv.org/abs/1603.02199) |
| **2017　HER** | 给已有转移更换目标，按确实到达的状态重算目标条件奖励，使一次经验可训练多个目标。 | 所用目标能从状态判定，且更换目标不改已记录动作的物理转移。真实物体受损或舒适程度若不能事后判定，无法照此产生标签。[Andrychowicz 等，论文与目标条件实验](https://arxiv.org/abs/1707.01495) |
| **2018　QT-Opt** | 由大量成功及失败抓取学习动作价值。价值迭代把终点验收与较早的控制动作联系起来。 | 实机有专门设计的回投检测及复位条件。可研究重抓对成功率的作用；验收器漏检和更换任务后的回报须另外检查。[Kalashnikov 等，论文及附录 D](https://proceedings.mlr.press/v87/kalashnikov18a.html) |
| **2020　AWAC 与离线保守价值学习** | AWAC 用离策略 critic 估计优势，对数据中的动作作加权回归，再补入实际执行。CQL 在 Bellman 拟合外加入价值正则，使数据外的高估更少影响动作选择。 | AWAC 有转阀、开抽屉和灵巧操作等真机对照。CQL 的下界有其建模与估计条件，真实接触风险仍须测量。[AWAC 方法与机器人实验](https://awacrl.github.io/) · [CQL 原论文](https://proceedings.neurips.cc/paper/2020/file/0d2b2061826a5df3221116a5085a6052-Paper.pdf) |
| **2021–2022　MT-Opt** | 终态成功检测器让一次轨迹可以回答多个相关目标；数据共享与任务重平衡分别改变哪些转移参与价值更新。 | 在同一批离线数据和计算预算下，每任务每方案各做 100 次实机评价。把所有任务无差别共享并未给出最佳成绩。[原文表 2、4](https://proceedings.mlr.press/v164/kalashnikov22a/kalashnikov22a.pdf) · [六种训练分布的实机对照图](reading.html#physical-practice-distribution) |
| **2022–2023　DayDreamer** | 用真机命令和相机等观测学习潜在动力学，在模型预测的未来上优化策略。 | 四类物理机器人上的训练说明可以把部分试错转移到模型内。训练所需的真机反馈、机械接口及模型误差随平台改变。[Wu 等，论文](https://proceedings.mlr.press/v205/wu23c.html) |
| **2024 起　HIL-SERL** | 人给正负例训练二元奖励分类器，示范初始化回放，在线用真实执行、接管和稀疏奖励继续学习。 | 公开实验另列自主运行与抗扰录像。接管能让训练访问更多可恢复状态；估计完全自主回报时须区分由谁完成恢复。[作者的训练步骤、论文与代码](https://hil-serl.github.io/) |
| **2024–2025　RLDG、ConRFT** | RLDG 先用真机强化学习训练单项精密操作的专门策略，再用其轨迹微调通用策略；ConRFT 先以一致性目标离线微调 VLA，再在人工接管下在线强化微调。 | RLDG 报告成功率比用人工示范训练最多高 40%；ConRFT 在 8 项接触任务上平均成功 96.3%，在线阶段 45 至 90 分钟。前者的增益要与同等数量的高质量示范对照，后者依赖人工接管与奖励判定。[RLDG，arXiv:2412.09858](https://arxiv.org/abs/2412.09858) · [ConRFT，arXiv:2502.05450](https://arxiv.org/abs/2502.05450) |
| **2025　RECAP / $\pi^*_{0.6}$** | 对示范、纠正和策略轨迹进行价值估计与优势标记，再训练以优势为条件的动作分布。 | 实机可比较处理速度和成功情况。要把正向条件解释为动作改进，需要标记能区分同一历史下的自主续行价值。[方法与实验](https://arxiv.org/abs/2511.14759) · [Physical Intelligence 技术博客](https://www.pi.website/blog/pistar06) |
| **2025　SimpleVLA-RL、RL4VLA** | 以任务成败为结果奖励，对 VLA 作组相对策略更新或 PPO 更新；后者用共享主干的价值头估计优势。 | SimpleVLA-RL 在 LIBERO 上由 91.0% 升至 99.1%，单条示范起点由 48.9% 升至 96.9%，真机四项任务由 17.5% 升至 38.5%。RL4VLA 在 ManiSkill 抓放中报告 PPO 在执行与语义类变化上的泛化优于监督微调，视觉类变化相当。两者主要在可复位仿真中完成，成功率为零的任务得不到梯度。[SimpleVLA-RL，arXiv:2509.09674](https://arxiv.org/abs/2509.09674) · [RL4VLA，arXiv:2505.19789](https://arxiv.org/abs/2505.19789) |
| **2026　AgiBot World，Theme 3** | 首批 14 项任务、11,430 条记录，区分示范、自主执行和人工纠正。作者单列自主成功 1,024 条、失败 1,369 条，并提供进度、错误及干预标注。 | 可以研究不同来源的访问分布及接管后的结果。对从未执行过的命令，数据量和子任务切分均不产生新的干预样本。[智元的采集说明](https://www.agibot.com/article/231/detail/95.html) · [发布字段](https://huggingface.co/datasets/agibot-world/AgiBotWorld2026/blob/cf9841dffaa4bb6a7b226a30b145e4fa5127a064/ReinforcementLearning/README_THEME_3.md) |
| **2026　Chef Robotics 食品操作模型** | 料盘深度图与舀取命令之后记录秤重及余料表面。同一台设备可长期提供有物理单位的动作后果。 | 重量读数可检验分量预测。操作者希望多准确、容许多慢，还要由用途指定。报告说明车队采集和模型训练过程，闭环收益要在实际策略执行时比较。[公司 11 月 2 日的技术说明](https://www.chefrobotics.ai/post/building-a-world-model-for-food-manipulation-part-2-the-training-flywheel) |

**物理目标、成功判据与控制。** [Summers 与 Lygeros](https://www.sciencedirect.com/science/article/pii/S0005109810003547)区分期限内首次到达和指定时刻到达，给出相应的动态规划递推。[Ravens 原始实现](https://github.com/google-research/ravens/blob/master/ravens/tasks/task.py)可直接比较任务评分与使用模拟器特权信息的示范控制器。[NIST 插销实机试验](https://tsapps.nist.gov/publication/get_pdf.cfm?pub_id=922206)给出固定到位深度下搜索时间对定位误差的敏感性。[Tedrake 的双积分器](https://underactuated.mit.edu/dp.html)解释为什么能经过某个位置与能在该处静止要求不同的控制权限。

## 二　仿真训练、学习模型与实机迁移

| 工作 | 模型提供的信息 | 返回真机时要检验的关系 |
|---|---|---|
| **2016　Visual Foresight** | 从机器人动作与视频训练动作条件预测器，用预测像素运动选取达到目标的推移动作。 | 规划要求候选动作在图像上的影响可预测。额外使用真机执行，可以检查在模型中优选的动作能否实际推动物体。[Finn 与 Levine，论文](https://arxiv.org/abs/1610.00696) |
| **2018–2019　Dactyl 与自动域随机化** | 仿真器提供可重演的手指控制、物体姿态与奖励。改变质量、摩擦等条件训练能适应多种动力学的策略。 | 同一灵巧手的实机重定向与魔方实验检验训练分布的可迁移性。新材料能否由模拟器的参数族表示，仍是经验问题。[灵巧手重定向](https://arxiv.org/abs/1808.00177) · [魔方与自动域随机化](https://arxiv.org/abs/1910.07113) |
| **2020–2021　四足运动控制与 RMA** | 仿真可提供地形、负载等特权变量。RMA 以近期本体感觉和动作历史推断适配量，供步态策略使用。 | 实地行走检验策略在身体和地形改变时能否及时调整。在固定权重下依据近期历史适配，与下一次部署仍保留的参数学习是两个实验。[Lee 等，ANYmal](https://arxiv.org/abs/2010.11251) · [RMA，原文、真机录像与代码](https://ashish-kmr.github.io/rma-legged-robots/) |
| **2023　DreamerV3** | 从观测和动作学习离散潜在状态的循环模型，在想象轨迹上用 λ-回报训练行动者与评论家，固定超参数用于多类基准。 | 在 Minecraft 中从零获得钻石，说明模型内学习可覆盖长程稀疏奖励。返回真机时，模型误差在策略访问的新状态上会累积，需要真机资料持续校正。[Hafner 等，arXiv:2301.04104](https://arxiv.org/abs/2301.04104) · [Nature 2025](https://doi.org/10.1038/s41586-025-08744-2) |
| **2023　人形机器人的强化学习行走** | 在大规模随机化仿真中训练读取观测-动作历史的因果 Transformer 策略，靠上下文适应未见的动力学。 | 零样本部署到全尺寸人形，在多种户外地面行走。随机化范围未覆盖的接触和损伤仍会失效，历史能辨认的只是在训练分布内可区分的工况。[Radosavovic 等，arXiv:2303.03381](https://arxiv.org/abs/2303.03381) |
| **2024　RoboCasa** | 生成可重置的厨房场景，提供人工与合成示范，可在同一模拟初态比较多条分支。 | 布局、任务数与真机接触保真度可分别增长。部署前仍需核对目标机器的传感器、执行器和关键接触结果。[项目的数据集说明](https://robocasa.ai/docs/build/html/datasets/datasets_overview.html) |
| **2025　V-JEPA 2-AC** | 一般视频提供视觉表征，约 62 小时带动作的机器人数据训练动作条件预测器；给定目标图像后在潜在空间规划。 | 实验中有相机和中间目标设置，规划计算占用物理时间。目标图像能区分的后果才直接进入该控制目标。[原文，表 2–3 与真机规划](https://arxiv.org/html/2506.09985v1) |
| **2025　ASAP、BeyondMimic** | ASAP 先在仿真中训练动作跟踪策略，再用真机轨迹学习补偿动作的增量模型 $\Delta a$，在修正后的仿真中微调；BeyondMimic 在仿真中训练可跟踪多种人体动作的全身策略。 | ASAP 的真机对照只与未修正的基线比较，并依赖动作捕捉；BeyondMimic 显示一份跟踪策略可执行多段高动态动作。两者都要在目标身体上检验关节限位、接触与损伤。[ASAP，arXiv:2502.01143](https://arxiv.org/abs/2502.01143) · [BeyondMimic，arXiv:2508.08241](https://arxiv.org/abs/2508.08241) |
| **2025　DreamGen、Ctrl-World、WMPO** | DreamGen 微调视频世界模型生成新行为的视频，再用逆动力学模型补出动作作训练资料；Ctrl-World 是可控多视角世界模型，用于模型内评价策略和筛选成功想象轨迹；WMPO 在像素世界模型中作在线组相对更新。 | DreamGen 在 GR1 人形上把 14 项新行为的成功率由 11.2% 提高到 43.2%，生成资料耗费大量计算；Ctrl-World 再现了策略表现的趋势，但模型内的绝对成功率偏低、不再现重试。接触物理的偏差限制了模型内排序的可靠性。[DreamGen，arXiv:2505.12705](https://arxiv.org/abs/2505.12705) · [Ctrl-World，arXiv:2510.10125](https://arxiv.org/abs/2510.10125) · [WMPO，arXiv:2511.09515](https://arxiv.org/abs/2511.09515) |
| **2025　Genie 3** | 从文本提示生成可交互的 720p、24 帧每秒环境，几分钟内保持一致，供 SIMA 等智能体在其中执行目标。 | 官方说明可交互时长和动作空间有限，多智能体交互与真实地理位置的准确性也有限，尚无机器人控制的真机检验。[Google DeepMind 官方博客](https://deepmind.google/discover/blog/genie-3-a-new-frontier-for-world-models/) |
| **2026　WoVR+** | 用真实运行训练多视角、含本体观测的动作条件世界模型和奖励模型，然后在其中通过 RL 更新 VLA。 | 在六项操作上做匹配的真机评测，使模型内优化与实际策略回报可以对照。从中间阶段启动模拟并不保证真机策略能自主到达该阶段。[论文，实验与消融](https://arxiv.org/html/2610.17922v1) |
| **2026　Skild Physical Self-Play** | 仿真中的双足足球对手会随策略改变，进球目标为双方提供可计算反馈。 | 公司公开了从模拟训练到真机对局的演示。模拟自对弈时长、实机适应时长、实机重复对抗成绩是不同的测量。[Skild AI 研究博客](https://skild.ai/blogs/physical-self-play) |

**仿真经验与世界模型的使用条件。** [仿真经验与控制](reading.html#physical-world-model-uses)分别讨论仿真经验的生成方式、命令条件规划与闭环评价。以下工作适合按可操作的变量对照阅读。

| 来源与用途 | 训练或评价所用的量 | 实机检验 |
|---|---|---|
| [RoboCasa365](https://robocasa.ai/)、[MimicGen](https://mimicgen.github.io/)、[DexMimicGen](https://dexmimicgen.github.io/) | 改变场景初态、复用和重组示范，执行后按模拟器判据记录成功。 | 检查传感映射、控制器和接触是否匹配；单独查验失败与恢复分支的覆盖。 |
| [SIMPLER](https://simpler-env.github.io/)、[Cosmos Transfer](https://research.nvidia.com/publication/2025-03_cosmos-transfer-1-world-world-transfer-adaptive-multi-control-physical-ai) | 前者同时对齐视觉与控制响应，后者按结构条件生成不同外观。 | 固定实发命令时比较末端或物体响应，固定几何时比较视觉策略的选令。 |
| [DreamGen](https://arxiv.org/html/2505.12705v1)、[DreamZero](https://arxiv.org/html/2602.15922v1) | 前者为生成视频推断伪动作，再训练策略；后者联合生成动作与视频。 | 记录在目标身体上实际执行的命令和验收。分别报告阶段进度与整项完成。 |
| [EgoSteer，表 2(c)、10–11](https://arxiv.org/html/2607.09701v2#S6.SS4)、[DOS W1，表 15](https://arxiv.org/html/2610.21915v1#A2.SS7.T15) | 两项研究在训练中增加未来特征监督，部署时直接输出动作。 | 前者共用预训练数据与微调集，后者还匹配了优化步数。哪些效应涉及动作提议，见[同一预算下的实机对照](reading.html#physical-fixed-budget-ablation)。 |
| [GR00T 2，附录 F.4](https://research.nvidia.com/labs/gear/gr00t-2/assets/gr00t2_whitepaper.pdf#page=92) | 插接任务中，在共同监督起点上分别采用组相对策略更新和成功轨迹自模仿。 | 区别在成败反馈进入参数更新的位置；直接策略更新与成功筛选都用到了自主探索。见[回报条件化与真机后训练](reading.html#physical-reward-conditioned-actor)。 |
| [HWM](https://arxiv.org/html/2604.03208v2)、[DreamDojo](https://arxiv.org/html/2602.06949v1) | 前者用长、短时间尺度分别选子目标和动作；后者从策略提议的动作中用预测后果择优。 | 与同一身体上直接执行的候选策略对比，另报告规划时延与新观测到来后的改令权限。 |
| [WorldGym](https://arxiv.org/html/2506.00613v3)、[Genie 3](https://deepmind.google/blog/genie-3-a-new-frontier-for-world-models/)、[Genie 4](https://deepmind.google/blog/genie-4-a-new-generation-of-world-simulation/) | WorldGym 让策略在动作条件模型中闭环运行，并按可见结果评分。生成环境所接受的键控或文字动作有自身语义。 | 检查同任务内的策略排序及相应动作接口。文字指令造成的画面变化不能标定给定关节命令的接触效果。 |

## 三　视频、人体示范与机器人命令的对应

| 工作 | 已有的测量或标签 | 迁移时需要的条件 |
|---|---|---|
| **2023　ACT 与 Diffusion Policy** | ALOHA 记录双臂遥操作示范，ACT 预测多步动作块。Diffusion Policy 以条件去噪学习连续动作分布，滚动执行动作序列。 | 二者都要求示范命令与目标机器动作对应。控制中的误差还取决于执行多少步才重新接收观测、部署会进入哪些示范外状态。[ACT 与 ALOHA](https://tonyzhaozh.github.io/aloha/) · [Diffusion Policy](https://diffusion-policy.cs.columbia.edu/) |
| **2023–2024　Open X-Embodiment、DROID** | 前者汇集多种身体和动作接口；后者用相对统一的机械臂和采集配置扩大环境、操作者和物体范围。 | 数据规模可以扩大同接口下的观测覆盖，也可以扩大身体种类。后者额外要求命令单位、时间和控制语义能够对应。[Open X-Embodiment](https://robotics-transformer-x.github.io/) · [DROID](https://droid-dataset.github.io/) |
| **2023–2024　UMI、HumanPlus、RH20T** | 手持夹爪提供相对位姿与开度；人体动捕提供全身参考；RH20T 同步记录真机视觉、动作、力与声音。 | 改变身体会改变参考可跟踪的范围和实际接触力。UMI 的时延消融与同权重控制对照可分辨其中一项误差。[UMI](https://arxiv.org/abs/2402.10329) · [HumanPlus](https://humanoid-ai.github.io/) · [RH20T](https://rh20t.github.io/) |
| **2025　TRI 与 Boston Dynamics 的 Atlas 行为模型** | 全身 VR 遥操作结合模型预测控制器采集示范。图像、本体感觉与语言条件进入动作生成器，按 30 Hz 给出全身动作。 | 上肢平台资料与可迈步的全身资料共享部分手部动作；涉及支撑面、平衡和迈步的命令需另一套可执行接口。展示中的高层提示由外部给出。[实机任务、训练与采集接口](https://bostondynamics.com/blog/large-behavior-models-atlas-find-new-footing/) |
| **2026　EgoScale** | 在 20,854 小时第一视角人类视频中提取手部动作监督，再借助人机数据对齐腕部和手指运动。 | 人体运动可以训练动作先验；关节、触觉和物体接触仍属于目标身体。留出新的手形和物体能检验不同层面的泛化。[NVIDIA 研究页](https://research.nvidia.com/labs/gear/egoscale/) |
| **2026　Generalist GEN-1、GEN-1.5** | 多种末端工具用于预训练，GEN-1.5 在十项短程操作上分别测试单次传感运动示范作上下文，以及少量示范后的梯度微调。 | 公司报告前者平均成功率 59%，每任务五分钟示范与十步梯度微调为 83%。数据量与更新方式都变了，不能把差值单独归因于权重更新。换工具改变可施加的接触与力。[跨末端工具](https://generalistai.com/blog/towards-machines-with-a-thousand-hands) · [GEN-1.5，图 2](https://generalistai.com/blog/gen-1.5) |
| **2026　TacClaw-Infinity** | 手持装置记录视觉、接触、语言和动作。研究者在三种机器人上做叠杯、分拣瓶子和擦花瓶测试，比较带触觉与不带触觉的策略。 | 未采集这三种目标机器专用的示范；成功率按具体任务、身体和策略分别报告。触觉对分拣与连续接触的作用可以分别检查。[原文、硬件与实机对照表](https://tacclaw-infinity.github.io/) |
| **2026　Dyna-2、Helix 2.5、GR00T 2** | Dyna 从人体手部跟踪提取伪动作，考察人体数据规模与留出动作误差，另在三种机器人形态的 14 项任务上用相同任务数据后训练再比较实机执行；Figure 将人类预训练带到住宅闭环任务；NVIDIA 联合建模未来视频和动作，并考察人类视频规模。 | 三种指标可逐层比较：留出动作是否预测准确、真机整项工作是否完成，以及固定预算的部署是否会继续学习。GR00T 的报告同时给出模型评分与人工判定，量表须对应其判定对象。[Dyna §3.1–3.4](https://www.dyna.co/dyna-2) · [Figure 住宅实验](https://www.figure.ai/news/helix-2-5-zero-shot-30-home-generalization) · [NVIDIA 技术报告，图 10](https://research.nvidia.com/labs/gear/gr00t-2/assets/gr00t2_whitepaper.pdf) |
| **AnySkin 与 TTP** | 可替换的触觉传感器检验同一策略在更换接触表面后的表现。触觉预训练另可使用人体几何、佩戴设备或仿真接触产生监督。 | 区分换皮后传感响应与摩擦的改变；跨设备训练须说明标签的物理来源，决策时要检验目标手指上的读数。[AnySkin](https://arxiv.org/html/2409.08276v1#S5.SS4) · [TTP](https://arxiv.org/html/2607.01067v1#S3) |

## 四　语言指令、跨身体策略与控制层次

| 工作 | 语言或目标怎样进入控制 | 实证所覆盖的能力 |
|---|---|---|
| **2022　SayCan、RT-1** | SayCan 从技能库中结合语言相关性和已有技能的可行性估值来选技能。RT-1 从指令和图像直接产生动作表示。 | 前者取决于技能库及其价值估计；后者取决于动作训练覆盖。在高层规划失败时，应查清语义选择是否可行、低层是否执行成功。[SayCan](https://say-can.github.io/) · [RT-1](https://robotics-transformer1.github.io/) |
| **2023–2024　RT-2、Octo、OpenVLA** | RT-2 把动作离散化，使示范可与视觉语言训练共享参数；Octo 预训练通用策略并用扩散动作头；OpenVLA 提供可适配的开放 VLA。 | 语言和视觉预训练可改进陌生语义条件下的动作选择。测试应保持末端接口、任务成功定义和微调数据预算明确。[RT-2](https://deepmind.google/blog/rt-2-new-model-translates-vision-and-language-into-action/) · [Octo](https://octo-models.github.io/) · [OpenVLA](https://openvla.github.io/) |
| **2024　$\pi_0$** | 预训练视觉-语言模型加流匹配动作专家，生成连续动作块，以多种机器人示范预训练后按任务后训练。 | 叠衣、组装纸箱等多阶段灵巧任务说明后训练能把预训练的覆盖用于长程操作；评测以作者自定的任务和计分进行。[Black 等，arXiv:2410.24164](https://arxiv.org/abs/2410.24164) |
| **2025–2026　$\pi_{0.5}$、$\pi_{0.7}$** | 从图像、语言、本体与多机器人示范生成连续动作块；新一代使用子目标图、速度和质量等条件，学习混合来源的动作分布。 | 陌生住家的执行检验感知与行为组合的迁移。改变提示后表现提高，可以发生在完全冻结的模型上；检验部署后学习须比较是否保留新经验。[开放世界评测](https://www.pi.website/blog/pi05) · [可控条件、数据与实验](https://www.pi.website/blog/pi07) · [2026 年 10 月企业部署与微调流程](https://www.pi.website/blog/api-beta) |
| **2025　Gemini Robotics 1.5** | 具身推理模型规划并调用动作模型；动作模型在执行前生成中间推理，并用 Motion Transfer 从多身体资料学习。 | 报告称同一模型控制 ALOHA、双臂 Franka 与 Apollo 人形，能把只在一种身体上采集过资料的任务零样本迁移到另一种身体；身体差异更大的人形上效果较弱。[Gemini Robotics Team，arXiv:2510.03342](https://arxiv.org/abs/2510.03342) |
| **2026　Helix 02、Gemini Robotics 2.5** | Figure 的全身系统将感知动作策略与快速控制层结合。DeepMind 与 Apptronik 在汽车配件场景组合高层推理、双手与具身动作模型。 | Figure 提供完整洗碗机操作的无接管演示。DeepMind 报告分拣概念验证的成功率。动作接口、控制周期、被计为一次尝试的单位各异，不能直接横比。[Figure 的控制层与实拍](https://www.figure.ai/news/helix-02) · [Google DeepMind 的生产线试验](https://deepmind.google/blog/gemini-robotics-2-5-accelerates-real-world-physical-intelligence/) |
| **2026　Xiaomi Robotics U0** | 生成不同场景与身体的图像、视频，改变策略训练或测试可用的视觉条件。 | 团队分别评价内容生成和用这些资料训练后的实物操作。只有后者直接测量对物理控制的帮助；图像分数的上升不能替代这一层实验。[小米团队技术报告](https://arxiv.org/abs/2607.11643) |
| **2026　Anthropic Embody 与 Gemini Robotics ER 2** | Embody 改变同一大模型的控制权限，比较直接命令、写控制程序、训练策略和监督现成控制器。ER 2 分别测量进度判别及指挥不同执行者完成任务。 | Embody 的直接控制模拟允许模型思考期间暂停时钟。ER 2 的文本输出经下层 VLA 或人类操作者才成为物理动作。识别准确率、组合系统的闭环成功率与真实反应时间各评价不同对象。[Anthropic 原始测试与时延附录](https://www.anthropic.com/research/claude-plays-robotics) · [DeepMind 模型与分项评测](https://deepmind.google/models/gemini-robotics/embodied-reasoning/) |
| **2026　Microsoft Research，机器人推理卸载** | 在本机、边缘服务器或云端运行同一工作负载，比较模型推理、网络通信、能耗及实际控制表现。 | 一个决策能使用多新的图像，取决于端到端时延。推理加速要与传输往返及电池预算一起比较。[原始测量、任务与硬件配置](https://www.microsoft.com/en-us/research/blog/offloaded-inference-for-real-world-physical-ai-robotics/) |
| **2026　可逆执行映射与相机视角** | 在 Gym Reacher 上改变动作的执行映射或相机视角，考察历史能否帮助推断接口、修正近似策略。 | 第 3 章的显式补偿仅覆盖设定的可逆映射族；第 4 章的多次尝试至少一次成功与单回合成功率有不同分母。曹哲，《跨具身多任务机器人控制策略》，上海交通大学硕士学位论文，2026 年 1 月 26 日，式 (3.8)–(3.11)、表 3.1–3.2、§4.4.2、表 4.3。 |
| **off-DADS、EES 与 π₀.₇** | 分别学习可区分的实机位移、已有技能的参数与练习分配、怎样根据较高层指示完成或组织操作。 | 确定评价时的定位权限、练习工时、是否有人逐步指导。只有整次部署的净收益能回答练习是否回本。[off-DADS](https://arxiv.org/abs/2004.12974) · [EES](https://www.roboticsproceedings.org/rss20/p040.pdf) · [π₀.₇](https://www.pi.website/download/pi07.pdf) |

## 五　失败、核验与持续运行

| 工作 | 放松的条件 | 仍需付出的代价 |
|---|---|---|
| **2020　R3L；2023　RoboCat** | 前者以真实扰动策略创造下次练习的起点，后者由新任务的专门策略补采轨迹并回训通用模型。 | 已指定目标的自主练习，可以分别研究不复位的状态覆盖与跨任务经验重用；任意新任务的偏好仍须由目标来源规定。[R3L](https://bair.berkeley.edu/blog/2020/04/27/ingredients/) · [RoboCat](https://deepmind.google/blog/robocat-a-self-improving-robotic-agent/) |
| **2023　LIBERO** | 130 项仿真操作任务分四组，依次改变空间布局、物体、目标和长程组合，用于终身学习的前向与后向迁移评价。 | 顺序微调在前向迁移上好于所比较的终身学习方法，朴素监督预训练可能损害后续学习。结论来自仿真示范学习，不包括部署中的自主采集。[Liu 等，arXiv:2306.03310](https://arxiv.org/abs/2306.03310) |
| **2024　AutoRT** | 视觉-语言模型描述场景，大语言模型提出任务，再按“机器人宪章”过滤，分派给遥操作、脚本或学习策略，减少每项任务的人工指定。 | 七个月里 53 台机器人采集约 77,000 条轨迹；每位监督者可照看 3 至 5 台移动机器人。自主执行成功率低，共同微调 RT-1 的增益有限，部分不安全任务仍会通过过滤。[Ahn 等，arXiv:2401.12963](https://arxiv.org/abs/2401.12963) |
| **2023　LIRF 与 GEAR** | LIRF 学习在操作后主动施加核验动作以辨别结果，GEAR 以偶尔的人类比较引导机器人探索。 | 核验可能改变正在检验的接触；人工比较有时间和提问成本。直接显示目标达成的传感器、对两个结果的排序和人的规范性偏好需要分别说明。[Huang 等，真机核验](https://proceedings.mlr.press/v205/huang23a.html) · [GEAR](https://guided-exploration-autonomous-rl.github.io/GEAR/) |
| **2024　真机移动操作中的自主练习** | 机器人通过导航与探索重新接近可交互物体，以连续实践改进多个指定的移动操作技能。 | 每次恢复接触都占用机器时间。评估独立技能成功率与无重置系统的全程产出，所需分母不同。[Mendonca 等，论文与录像](https://continual-mobile-manip.github.io/) |
| **2025–2026　RetrDex 与 Robometer** | RetrDex 将目标在遮挡后显露作为可计算反馈，训练主动拨动；Robometer 用轨迹比较、进度及成功监督估计可迁移的奖励。 | 前者可通过实物图像核验显露；后者还须检验评分器改变后，实际部署策略是否取得了更好的物理结果。[RetrDex 真机指标](https://arxiv.org/html/2502.18423v3) · [Robometer 在线策略评测](https://arxiv.org/html/2603.02115v2) |
| **2026　智元 GO-3 Preview** | 团队披露预训练、后训练和部署反馈的分工，报告桌面冰壶、积木及基准测试。 | 对局胜率、基准结果、商用流程演示的试次和初始条件各异。要估计部署经验留下的收益，还需在相同实机、人工和时间预算下比较保留更新与冻结更新。[智元 2026 年 10 月技术说明](https://www.agibot.com/article/231/detail/133.html) |
| **2026　SenseNova 等，通用多模态模型与机器人** | 在不同具身基准和机器人配置中比较工具接口、上下文示范和受限的物理执行时间，也提出按世界时钟继续运行的评测。 | 一个能力指标取决于低层执行器和供给的示范；只有模型输出时不等于物体已按要求变化。研究中的基准、真机及提出的评价原型应分别阅读。[原报告与实验](https://arxiv.org/abs/2610.22471) |
| **2026　Learning While Deploying** | 在 16 台双臂机器人上汇集自主与人工接管经验，以价值估计改进基于流匹配的动作生成策略。论文给出八项工作上的收集、更新和再部署试验。 | 多机并行增加可观察的成功与失败。复位、任务队列及操作者会改变访问分布；车队累计机时与单机无重置运行时长应分别计算。[智元与上海创智学院，原论文的实验协议](https://finch-static.agibot.com/LWD/lwd-paper.pdf#page=8) |
| **2026　VLA 真机持续学习** | 在双臂 PiPER-X 上依次微调 $\pi_{0.5}$，比较顺序微调、经验回放与联合训练，并检验动作归一化统计量的处理。 | 20% 的回放使单臂序列的后向迁移由 −81.0 变为 +1.5，平均成功率高于等步数的联合训练。只有一个平台，回放缓冲随任务数增长。[Zhu 等，arXiv:2605.26820](https://arxiv.org/abs/2605.26820) |
| **2026　ASPIRE** | 学习器把技能程序和使用经验留在可读写的技能库，后续回合可以调用。真机转动魔方的三次运行保留上下文与文字技能。 | 各回合由人复位，成功转面数依次为 3、5、25。若要归因于所学技能，需分别匹配搜索预算、历史、初态和复位时间，再比较冻结或清除技能库。[原论文 §3.7](https://arxiv.org/html/2607.00272v2#S3.SS7) · [作者项目](https://research.nvidia.com/labs/gear/aspire/) |

[ReLMM 实机表 1](https://proceedings.mlr.press/v164/sun22a/sun22a.pdf)在同一房间比较随机与学习的导航、抓取，以及手写控制器。测试分母是每次散放的物体数。三次评测与一次训练的区分，见[移动抓取与持续部署](reading.html#physical-cleanup-deployment)。

这些实验有三种互补的用途。比较传感、时延和动作接口时，可固定策略权重，改变控制环的一个环节。比较训练方法时，可固定装置、动作权限及人工预算，让新策略独立运行。比较持续学习时，还要让不同学习规则承担自己造成的失手和恢复，并在随后出现的工作上评价所保留的能力。

## 接触条件、知识形成与连续作业

- 对照人和机器人感知接触的条件，可先看人体精细抓取怎样同时适应负载与摩擦，再看最近两组改变触觉输入和闭环频率的机器人实验。两组实机分别报告十二项任务与六项基准任务上的结果。指尖信号能否改善策略取决于接触位置、到达时刻和纠正动作。[Johansson 与 Westling](https://pubmed.ncbi.nlm.nih.gov/6499981/) · [T-Rex，数据与消融](https://tactile-reactive-dexterous.github.io/) · [ContactBench](https://arxiv.org/html/2610.24512v1) · [两项实验在正文中的比较](reading.html#physical-wiping-observation)
- 人体示范与目标机器人上的执行反馈提供不同监督。TACROSS 保留机器人轨迹作真实动作监督，人体触觉用于学习事件表示并辅助训练。TouchBridge 通过接触斑块对应，把人体动作转换为机器人示范。四项任务中每策略每任务 20 次实机试验，转换示范训练的平均成功率 72.5%，等量遥操作示范为 77.5%。两者都依赖定义人与机器人接触如何对应，预训练之外仍要验证当前工具能否达到该接触。[TACROSS，2026 年 10 月 8 日](https://arxiv.org/abs/2610.11945) · [TouchBridge，10 月 29 日，§IV](https://arxiv.org/html/2610.40349v1)
- 动作怎样辨识自己的身体，和哪些技能足以在高层规划，分别可见四足机器人损伤后的主动自建模，以及在双臂机器人上从执行记录学习技能前提与效果的实验。前者以候选模型预测的分歧选动作，后者给定低层技能。[Bongard 等，项目与实机录像](https://www.creativemachineslab.com/evolutionary-self-modeling.html) · [Konidaris 等，§5](https://cs.brown.edu/people/gdk/pubs/orig_sym_jair.pdf) · [作业流中的诊断与技能复用](reading.html#physical-diagnosis-control)
- 同工时比较中，Walden 的报告提供按班次采集纠正数据的实例。若探测读数本身随磨损而变，TacO 与九枚重复加载指尖的实验分别提供接触任务和硬件老化的对照。[Walden，多任务学习实验](https://www.waldenrobotics.com/news/lbm-2-0-accelerating-learning-in-deployment) · [TacO 实机任务](https://arxiv.org/html/2605.21976v2) · [指尖耐久性试验](https://arxiv.org/abs/2608.24242) · [阅读稿的同工时比较](reading.html#physical-diagnosis-shift)
