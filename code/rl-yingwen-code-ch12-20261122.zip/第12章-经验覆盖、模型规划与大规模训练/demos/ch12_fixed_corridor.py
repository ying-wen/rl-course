"""Fixed-data control on a four-door corridor. Python standard library.

Rows aggregate actual transitions from 150 complete episodes. Training reads
only these counts. The last-door reward and true transition probability enter
evaluate() for comparison after the policies have been fitted.
"""
from math import exp, isclose

# (exit records, successful forward records, failed forward records).
ROWS = ((25, 100, 25), (25, 60, 15), (10, 40, 10), (40, 0, 0))
EXIT, FORWARD = 0, 1


def reverse_backup(unseen_forward):
    """Exact empirical full backup. Leave the unsupported last action fixed."""
    q = [[1.0, unseen_forward] for row in ROWS]
    for state in reversed(range(len(ROWS) - 1)):
        _, success, failure = ROWS[state]
        q[state][FORWARD] = success / (success + failure) * max(q[state + 1])
    return q


def evaluate(prob_forward, prize, prob_success=.8):
    """Value in the true environment, by backward induction from the last gate."""
    continuation = prize
    for probability in reversed(prob_forward):
        continuation = (1 - probability) + probability * prob_success * continuation
    return continuation


def tabular_cql(penalty=.25, rate=.2, steps=10000, target_period=20):
    """Full batch of the discrete CQL(H) objective, target frozen for 20 steps."""
    q = [[1.0, 5.0] for _ in ROWS]
    number_of_transitions = sum(sum(row) for row in ROWS)
    for step in range(steps):
        if step % target_period == 0:
            target = [row.copy() for row in q]
        for state, (exits, success, failure) in enumerate(ROWS):
            count = sum(ROWS[state])
            behavior = [exits / count, (success + failure) / count]
            forward_target = 0.
            if success:  # Each observed forward success here leads to another state.
                forward_target = success / (success + failure) * max(target[state + 1])
            actions = q[state]
            unnormalized = [exp(v - max(actions)) for v in actions]
            soft = [w / sum(unnormalized) for w in unnormalized]
            for a, y in ((EXIT, 1.), (FORWARD, forward_target)):
                td_grad = behavior[a] * (actions[a] - y)
                reg_grad = penalty * (soft[a] - behavior[a])
                q[state][a] -= rate * count / number_of_transitions * (td_grad + reg_grad)
    return q


def weighted_expectile(observations, tau):
    """Minimizer of the asymmetric squared error for discrete (value,count) pairs."""
    lo, hi = min(value for value, _ in observations), max(value for value, _ in observations)
    for _ in range(60):
        mid = (lo + hi) / 2
        slope = sum(n * (tau if q >= mid else 1 - tau) * (q - mid) for q, n in observations)
        if slope > 0:
            lo = mid
        else:
            hi = mid
    return (lo + hi) / 2


def tabular_iql(tau=.75, beta=3.0):
    """Solve the IQL regressions exactly backward on this acyclic empirical MDP."""
    values, policy = [0.] * len(ROWS), [0.] * len(ROWS)
    for state in reversed(range(len(ROWS))):
        n_exit, success, failure = ROWS[state]
        observations = [(1., n_exit)]
        if success + failure:
            next_value = values[state + 1]
            q_forward = success / (success + failure) * next_value
            observations.append((q_forward, success + failure))
        values[state] = weighted_expectile(observations, tau)
        mass = [n * exp(beta * (q - values[state])) for q, n in observations]
        policy[state] = mass[1] / sum(mass) if len(mass) > 1 else 0.
    return values, policy


def greedy(q):
    # Choose EXIT in a tie.
    return [float(row[FORWARD] > row[EXIT]) for row in q]


def main():
    assert sum(ROWS[0]) == 150
    assert all(ROWS[i][1] == sum(ROWS[i + 1]) for i in range(3))
    assert all(isclose(s / (s + f), .8) for _, s, f in ROWS[:3])
    opt = reverse_backup(5.)
    assert all(isclose(row[1], value) for row, value in zip(opt, (2.56, 3.2, 4., 5.)))
    cql = tabular_cql()
    values, iql = tabular_iql()
    assert isclose(values[2], .875) and iql[3] == 0.
    policies = {'optimistic Q': greedy(opt), 'support constrained': [0.]*4,
                'discrete CQL(H)': greedy(cql), 'IQL': iql}
    for label, pi in policies.items():
        print(f'{label:20s} forward={[round(p,4) for p in pi]} '
              f'good={evaluate(pi,4):.6f} bad={evaluate(pi,0):.6f}')
    print('CQL terminal estimates:', cql[-1])
    print('IQL expectiles:', values)
    assert isclose(evaluate(greedy(opt),4), 4 * .8**4)
    assert isclose(evaluate(iql,4), evaluate(iql,0))
    learned_policy_last = greedy(cql)[-1]
    assert learned_policy_last == 0


if __name__ == '__main__':
    main()
