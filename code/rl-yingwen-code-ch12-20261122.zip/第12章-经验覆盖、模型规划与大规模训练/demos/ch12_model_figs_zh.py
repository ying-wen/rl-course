#!/usr/bin/env python3
"""11-21 请求 r1121-114444：第 12 章 842、843 两页的图改用中文与课件字体重出。

不改原图：新图另存为 *-zh.pdf/png。
- 842（model-v11-task）：读取 demos/dqn_model_v11.py 已保存的
  assets/dqn-model-v11/model-fit-curve.csv 与 model-map.csv，只重画，不重新采样。
- 843（deep-v13-model-selection）：按 demos/deep_v13_connections.py 的
  model_exploitation() 同样的确定性设定重新计算（21 个等距训练动作，最小二乘）。
Run: python3 demos/ch12_model_figs_zh.py
"""
from pathlib import Path
import csv
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent))
from plot_fonts import use_course_fonts, no_leading_zero, CJK_FAMILY

ROOT = Path(__file__).resolve().parents[1]
INK, TEAL, GOLD, RED, MUTED = '#1F2A33', '#087E8B', '#C4942A', '#C65335', '#8A949C'


def tick(x, pos=None):
    return no_leading_zero(x, pos).replace('-', '\u2212')


def read_csv(path):
    with open(path) as f:
        r = csv.reader(f); next(r)
        return np.array([[float(v) for v in row] for row in r])


def fig_842():
    out = ROOT / 'assets/dqn-model-v11'
    curves = read_csv(out / 'model-fit-curve.csv')   # seed, samples, rmse, a, b, c
    pred = read_csv(out / 'model-map.csv')           # x, u, true_mean, learned_mean
    a = curves.reshape(10, 7, 6)
    n = a[0, :, 1]; m = a[:, :, 2].mean(0); s = a[:, :, 2].std(0, ddof=1)
    fig, axs = plt.subplots(1, 2, figsize=(4.2, 2.15), layout='constrained')
    ax = axs[0]
    ax.plot(n, m, color=TEAL, marker='o', ms=3, lw=1.4)
    ax.fill_between(n, np.maximum(1e-4, m - s), m + s, color=TEAL, alpha=.2, lw=0)
    ax.set_xscale('log'); ax.set_yscale('log')
    ax.set_xticks([4, 16, 64, 240]); ax.set_xticklabels(['4', '16', '64', '240'])
    ax.set_xlabel('拟合所用转移数', fontsize=10.5)
    ax.set_ylabel('条件均值误差', fontsize=10.5)
    ax = axs[1]
    for u, color in zip([-1., 0., 1.], [RED, TEAL, GOLD]):
        z = pred[pred[:, 1] == u]
        ax.plot(z[:, 0], z[:, 2], color=color, alpha=.35, lw=3.2)
        ax.plot(z[:, 0], z[:, 3], color=color, ls='--', lw=1.2)
        ax.text(2.08, z[-1, 3], f'$u={u:g}$', color=color, fontsize=9.5, va='center')
    ax.set_xlim(-2, 2.9); ax.set_xticks([-2, 0, 2])
    ax.set_xlabel('当前位置 $x$', fontsize=10.5, fontfamily=CJK_FAMILY)
    ax.set_ylabel('下一位置', fontsize=10.5)
    for ax in axs:
        ax.tick_params(labelsize=9.5)
        ax.spines[['top', 'right']].set_visible(False)
        ax.grid(alpha=.2)
    axs[1].yaxis.set_major_formatter(FuncFormatter(tick))
    fig.savefig(out / 'model-learning-zh.pdf'); fig.savefig(out / 'model-learning-zh.png', dpi=200)
    plt.close(fig)


def fig_843():
    out = ROOT / 'assets/deep-v13'
    train = np.linspace(0., .4, 21); real = lambda a: a - a ** 3
    beta = np.linalg.lstsq(train[:, None], real(train), rcond=None)[0][0]
    grid = np.linspace(0., 1.5, 3001)
    chosen = grid[np.argmax(beta * grid)]
    assert abs(beta - .89928) < 1e-4 and abs(chosen - 1.5) < 1e-9
    fig, ax = plt.subplots(figsize=(5.4, 1.95), layout='constrained')
    ax.axvspan(0, .4, color='#eaf4f3')
    ax.text(.2, -1.75, '已采动作', ha='center', fontsize=10.5, color=TEAL)
    ax.plot(grid, real(grid), c=INK, lw=1.8)
    ax.plot(grid, beta * grid, c=TEAL, lw=1.8)
    ax.scatter(train, real(train), color=GOLD, s=10, zorder=4)
    ax.text(.55, .78, '线性模型 $.899a$', color=TEAL, fontsize=10.5, fontfamily=CJK_FAMILY)
    ax.text(.6, -.62, '真实位移 $a-a^3$', color=INK, fontsize=10.5, fontfamily=CJK_FAMILY)
    ax.annotate('', xy=(chosen, real(chosen)), xytext=(chosen, beta * chosen),
                arrowprops={'arrowstyle': '->', 'color': RED, 'lw': 1.6})
    ax.scatter([chosen, chosen], [beta * chosen, real(chosen)], c=RED, s=22, zorder=5)
    ax.text(1.18, -1.7, '规划选 $a=1.5$\n预测 $1.35$，实得 $-1.88$',
            color=RED, fontsize=10, ha='right', fontfamily=CJK_FAMILY)
    ax.set_xlabel('动作 $a$', fontsize=10.5, fontfamily=CJK_FAMILY)
    ax.set_ylabel('奖励（位移）', fontsize=10.5)
    ax.set_xlim(0, 1.55); ax.set_ylim(-2, 1.6)
    ax.xaxis.set_major_formatter(FuncFormatter(tick))
    ax.yaxis.set_major_formatter(FuncFormatter(tick))
    ax.tick_params(labelsize=9.5)
    ax.spines[['top', 'right']].set_visible(False)
    fig.savefig(out / 'planning-distribution-zh.pdf'); fig.savefig(out / 'planning-distribution-zh.png', dpi=200)
    plt.close(fig)
    print('beta', beta, 'chosen', chosen, 'pred', beta * chosen, 'real', real(chosen), 'in-range', real(.4))


if __name__ == '__main__':
    print('fonts ok:', use_course_fonts())
    fig_842(); fig_843()
