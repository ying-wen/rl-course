#!/usr/bin/env python3
"""Exact teaching examples and credited source crops for the v12 course bridges.

Run from any directory: python3 /absolute/path/to/demos/course_v12_visuals.py
No agents are trained. Probability/loss figures enumerate finite outcomes.
Default execution needs no research directory or source PDFs. To additionally
rebuild the three credited source crops, pass --source-crops and provide the
original PDFs under research/course-v12-source-reads. No network is accessed.
"""
from __future__ import annotations

import itertools
import json
import argparse
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "assets" / "course-v12"
SOURCES = ROOT / "research" / "course-v12-source-reads"
OUT.mkdir(parents=True, exist_ok=True)
TEAL, RED, GOLD, INK = "#087e8b", "#c65335", "#c4942a", "#182e38"
plt.rcParams.update({"font.size": 10, "text.color": INK, "axes.labelcolor": INK,
                     "axes.spines.top": False, "axes.spines.right": False,
                     "pdf.fonttype": 42})


def save(fig, stem):
    for suffix in ("pdf", "png"):
        fig.savefig(OUT / f"{stem}.{suffix}", bbox_inches="tight", dpi=200)
    plt.close(fig)


def battery():
    # L -> deliver (2,L), charge (0,H); H -> deliver (6,L), charge (0,H).
    transition = {("L", "deliver"): (2, "L"), ("L", "charge"): (0, "H"),
                  ("H", "deliver"): (6, "L"), ("H", "charge"): (0, "H")}
    rows = []
    for actions in itertools.product(("deliver", "charge"), repeat=2):
        state, rewards = "L", []
        for action in actions:
            reward, state = transition[state, action]
            rewards.append(reward)
        rows.append({"actions": actions, "rewards": rewards, "return": sum(rewards)})
    # Independent dynamic programming check, over all states and one/two steps.
    v = {s: 0 for s in ("L", "H")}
    for _ in range(2):
        v = {s: max(transition[s, a][0] + v[transition[s, a][1]]
                    for a in ("deliver", "charge")) for s in v}
    assert max(r["return"] for r in rows) == v["L"] == 6
    return rows


def exploration():
    # L terminates with zero; reaching G requires H consecutive R actions.
    # Before any successful episode, both Q estimates are zero and argmax ties
    # go left. epsilon=.2 and uniform exploration over the two actions give pR=.1.
    horizons = np.arange(1, 11)
    epsilon_probability = 0.1 ** horizons
    uniform_probability = 0.5 ** horizons
    enumerated = {}
    for h in horizons:
        mass = 0.0
        for bits in itertools.product((0, 1), repeat=int(h)):
            probability = np.prod([0.1 if b else 0.9 for b in bits])
            if all(bits):
                mass += probability
        assert np.isclose(mass, 0.1 ** h, rtol=1e-12, atol=0)
        enumerated[int(h)] = mass
    fig, ax = plt.subplots(figsize=(5.1, 2.25))
    ax.plot(horizons, epsilon_probability, "o-", color=RED,
            label=r"$\epsilon$-greedy, $\epsilon=.2$, ties go left")
    ax.plot(horizons, uniform_probability, "s-", color=TEAL,
            label="Independent uniform actions")
    ax.set_yscale("log")
    ax.set(xlabel="Consecutive right actions required, H",
           ylabel="Success probability per episode", xticks=[1, 2, 4, 6, 8, 10],
           ylim=(3e-11, 1))
    ax.grid(axis="y", alpha=.18)
    ax.legend(frameon=False, loc="lower left", fontsize=8)
    save(fig, "exploration-probability")
    return {"epsilon": .2, "p_right_before_success": .1,
            "h10_success": float(epsilon_probability[-1]),
            "h10_uniform_success": float(uniform_probability[-1]),
            "enumerated_success_probability": enumerated,
            "condition": "Q initially zero; tie-breaking left; no successful episode yet"}


def offline_validation():
    # Fixed policy, one action, gamma=.9. s0 -> s1/s2 equiprobably with reward0;
    # s1 -> terminal reward0; s2 -> terminal reward2. Validation triples have
    # state probabilities (.9,.05,.05), so all state-action pairs have support.
    gamma = .9
    P = np.array([[0, .5, .5], [0, 0, 0], [0, 0, 0]], dtype=float)
    r = np.array([0, 0, 2], dtype=float)
    truth = np.linalg.solve(np.eye(3) - gamma * P, r)
    assert np.allclose(truth, [.9, 0, 2])
    weights = np.array([.9, .05, .05])
    candidates = {"A: true value": truth, "B: all zero": np.zeros(3)}
    outcomes = [(0, 0, 1, .45), (0, 0, 2, .45),
                (1, 0, None, .05), (2, 2, None, .05)]
    result = {}
    for name, f in candidates.items():
        td_loss = sum(p * (f[s] - reward - (gamma * f[nxt] if nxt is not None else 0)) ** 2
                      for s, reward, nxt, p in outcomes)
        # Independent matrix Bellman-residual calculation.
        residual = f - (r + gamma * P @ f)
        squared_bellman_residual = float(weights @ residual ** 2)
        target_variance = .9 * np.var([gamma * f[1], gamma * f[2]])
        assert np.isclose(td_loss, squared_bellman_residual + target_variance)
        result[name] = {"values": f.tolist(), "holdout_td_loss": float(td_loss),
                        "squared_bellman_residual": squared_bellman_residual,
                        "target_variance": float(target_variance),
                        "initial_value_error_squared": float((f[0] - truth[0]) ** 2)}
    assert np.isclose(result["A: true value"]["holdout_td_loss"], .729)
    assert np.isclose(result["B: all zero"]["holdout_td_loss"], .2)
    fig, ax = plt.subplots(figsize=(4.8, 2.1))
    residuals = [result[n]["squared_bellman_residual"] for n in candidates]
    variances = [result[n]["target_variance"] for n in candidates]
    ax.barh([1, 0], residuals, color=TEAL, height=.45, label="Squared Bellman residual")
    ax.barh([1, 0], variances, left=residuals, color=GOLD, height=.45,
            label="Conditional target variance")
    ax.set(yticks=[1, 0], yticklabels=list(candidates), xlim=(0, .89),
           xlabel="Expected held-out squared TD error")
    for y, n in zip([1, 0], candidates):
        loss = result[n]["holdout_td_loss"]
        ax.text(loss + .018, y, f"{loss:.3f}", va="center")
    ax.legend(frameon=False, loc="lower right", fontsize=8)
    ax.set_ylim(-.7, 1.5)
    save(fig, "offline-validation")
    return {"gamma": gamma, "validation_state_distribution": weights.tolist(),
            "outcome_probabilities": outcomes, "candidates": result}


def source_crops(rebuild=False):
    # Bounding rectangles use PDF points. The source artwork is preserved;
    # no task result or attribution is altered.
    specs = [
        ("zhang-attributes-2018", 2, (54, 80, 566, 225), "attributes-planning",
         "https://proceedings.mlr.press/v80/zhang18k/zhang18k.pdf#page=2",
         "Figure1, authors' block-stacking task and attribute graph"),
        ("martha_white", 4, (0, 0, 1920, 1080), "water-treatment",
         "https://deeprlcourse.github.io/assets/guests/martha_white.pdf#page=4",
         "Task photograph with original ISL Engineering attribution retained"),
        ("berkeley-exploration", 3, (607, 198, 772, 409), "montezuma-task",
         "https://rail.eecs.berkeley.edu/deeprlcourse/static/slides/lec-19.pdf#page=3",
         "Montezuma's Revenge screenshot only; third-party game artwork"),
    ]
    if rebuild:
        missing = [str(SOURCES / f"{name}.pdf") for name, *_ in specs
                   if not (SOURCES / f"{name}.pdf").exists()]
        if missing:
            raise FileNotFoundError("Original PDF files required for --source-crops:\n"
                                    + "\n".join(missing)
                                    + "\nRun without --source-crops to reproduce all numeric examples.")
        import fitz
    records = []
    for name, page, rect, stem, url, desc in specs:
        if rebuild:
            doc = fitz.open(SOURCES / f"{name}.pdf")
            p = doc[page - 1]
            p.get_pixmap(matrix=fitz.Matrix(2.3, 2.3), clip=fitz.Rect(rect)).save(OUT / f"{stem}.png")
        records.append({"asset": f"assets/course-v12/{stem}.png", "source": url,
                        "pdf_page": page, "rectangle_pdf_points": list(rect),
                        "description": desc})
    return records


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-crops", action="store_true",
                        help="Also rebuild credited source crops; needs the original PDFs.")
    args = parser.parse_args()
    try:
        crop_records = source_crops(args.source_crops)
    except FileNotFoundError as exc:
        parser.error(str(exc))
    audit = {"validation_layer": "finite exact enumeration; credited source crop metadata; no training",
             "battery": battery(), "exploration": exploration(),
             "offline_validation": offline_validation(), "source_crops": crop_records,
             "source_crops_rebuilt_this_run": args.source_crops}
    serialized = json.dumps(audit, ensure_ascii=False, indent=2) + "\n"
    path = OUT / "checks.json"
    path.write_text(serialized)
    research = ROOT / "research"
    if research.is_dir():
        (research / "course-v12-checks.json").write_text(serialized)
    print(path)
