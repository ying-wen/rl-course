"""Team baseline, coordination and nontransitive opponents; exact finite checks."""
import json

def payoff(a,b): return 0 if a==b else (1 if (a-b)%3==1 else -1)
def main():
    # Other member's action fixed to 'press'; teammate reward is our own press.
    p=.3; baseline=p
    g=lambda a:a-p
    mean_baseline=sum(pr*baseline*g(a) for a,pr in [(0,1-p),(1,p)])
    gradient=sum(pr*(a-baseline)*g(a) for a,pr in [(0,1-p),(1,p)])
    assert abs(mean_baseline)<1e-12 and abs(gradient-p*(1-p))<1e-12
    response=[0]
    for _ in range(3):
        b=response[-1];response.append(max(range(3),key=lambda a:payoff(a,b)))
    assert response==[0,1,2,0]
    uniform_vs_pure=[sum(payoff(a,b)/3 for a in range(3)) for b in range(3)]
    assert max(map(abs,uniform_vs_pure))<1e-12
    print(json.dumps(dict(counterfactual_baseline_mean=mean_baseline,team_actor_gradient=gradient,coordination_success_probability_10_members=2**-10,best_response_cycle=response,uniform_payoff_vs_each_pure=uniform_vs_pure),indent=2))
if __name__=='__main__':main()
