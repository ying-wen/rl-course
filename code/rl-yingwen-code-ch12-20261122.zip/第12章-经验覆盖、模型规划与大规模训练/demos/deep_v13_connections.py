"""Recompute the numerical mechanisms used in Chapters 9--12.

Run from any directory: python /path/to/deep_v13_connections.py --output-dir runs/deep-v13
NumPy + Matplotlib only. This is a set of exact teaching calculations, not a
benchmark comparison. Each check uses either independent enumeration, finite
differences, or a separate linear solve.
"""
from pathlib import Path
import argparse, json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle

TEAL='#087e8b'; RED='#c65335'; GOLD='#c4942a'; INK='#182e38'
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.spines.top':False,'axes.spines.right':False,'text.color':INK,'axes.labelcolor':INK})

def tile_features(s, n_tilings=4, width=.25):
    """Four disjoint weight banks; one binary feature is active in each."""
    out=np.zeros((n_tilings, 7))
    for k in range(n_tilings):
        j=int(np.floor((s+k*width/n_tilings)/width))+1
        out[k,j]=1
    return out.ravel()

def value(theta,x):
    a,b=theta
    return a*np.tanh(b*x)

def value_grad(theta,x):
    a,b=theta;t=np.tanh(b*x)
    return np.array([t,a*x*(1-t*t)])

def finite_diff(f,w,h=1e-6):
    return np.array([(f(w+np.eye(len(w))[i]*h)-f(w-np.eye(len(w))[i]*h))/(2*h) for i in range(len(w))])

def lstd_moments(x,r,xnext,gamma):
    """Accumulate the sample TD moment equation; no inverse is explicitly formed."""
    A=x.T@(x-gamma*xnext)
    b=x.T@r
    return A,b,np.linalg.solve(A,b)

def frozen_trace_identity(theta,xs,rewards,gamma,lam):
    """Compare forward targets with backward traces at one frozen parameter."""
    n=len(xs);vs=np.array([value(theta,x) for x in xs]+[0.])
    delta=rewards+gamma*vs[1:]-vs[:-1]
    grads=np.array([value_grad(theta,x) for x in xs])
    # Forward view: explicitly form every n-step return, then the lambda mixture.
    forward=np.zeros_like(theta)
    for t in range(n):
        targets=[]
        for k in range(1,n-t+1):
            g=sum(gamma**j*rewards[t+j] for j in range(k))+gamma**k*vs[t+k]
            targets.append(g)
        g_lam=sum((1-lam)*lam**k*targets[k] for k in range(len(targets)-1))+lam**(len(targets)-1)*targets[-1]
        forward+=(g_lam-vs[t])*grads[t]
    z=np.zeros_like(theta);backward=np.zeros_like(theta)
    for d,g in zip(delta,grads):
        z=gamma*lam*z+g
        backward+=d*z
    return forward,backward

def n_step_sarsa_target(rewards, tail_q, gamma):
    """Target at update time: real rewards, then the sampled next-action value.

    rewards contains min(n, T-t) observed rewards. Pass tail_q=0 at a true
    terminal state. The caller computes tail_q with the current pre-update
    weights and the action actually sampled at the endpoint.
    """
    return sum(gamma**k*r for k,r in enumerate(rewards)) + gamma**len(rewards)*tail_q

def parameter_trace_step(trace, gradient, gamma, lam):
    """Store the gradient computed at this time; do not recompute old gradients."""
    return gamma*lam*trace + gradient

def actor_critic_trace_step(zw, ztheta, grad_value, grad_logpi, delta,
                            importance_time, gamma, lam_value, lam_actor,
                            alpha_value, alpha_actor):
    """Book's episodic AC trace recurrence, with I_t=gamma**t.

    Both gradients and delta must be computed before changing either set of
    parameters. Returned parameter increments are applied simultaneously.
    """
    zw_new=parameter_trace_step(zw, grad_value, gamma, lam_value)
    ztheta_new=parameter_trace_step(ztheta, importance_time*grad_logpi, gamma, lam_actor)
    return zw_new,ztheta_new,alpha_value*delta*zw_new,alpha_actor*delta*ztheta_new

def shared_actor_critic(eta=0.,advantage=1.,target=1.,c_value=1.,alpha=.1):
    """One chosen action, pi(1)=sigmoid(eta), V=-eta, stopped advantage."""
    p=1/(1+np.exp(-eta))
    g_actor=-advantage*(1-p)
    g_critic=(-eta-target)*(-1)
    return g_actor,g_critic,eta-alpha*g_actor,eta-alpha*(g_actor+c_value*g_critic)

def fixed_target_outer_iteration(steps=9):
    """Only transition A->B is in D; V(A)=w,V(B)=2w,R=0,gamma=.9.
    Every inner regression is solved exactly: w_next=1.8*w_old.
    """
    w=1.;out=[]
    for k in range(steps):
        y=1.8*w;w_new=y
        out.append([k,w,y,w_new,.5*(w_new-y)**2])
        w=w_new
    return np.array(out)

def model_exploitation():
    """One-step action a changes position by f(a)=a-a^3; reward is new position."""
    train=np.linspace(0.,.4,21);real=lambda a:a-a**3
    beta=np.linalg.lstsq(train[:,None],real(train),rcond=None)[0][0]
    grid=np.linspace(0.,1.5,3001)
    chosen=grid[np.argmax(beta*grid)];true_action=grid[np.argmax(real(grid))]
    return train,real,beta,grid,chosen,true_action

def save(fig,out,name):
    fig.savefig(out/(name+'.pdf'),bbox_inches='tight');fig.savefig(out/(name+'.png'),dpi=180,bbox_inches='tight');plt.close(fig)

def run(out):
    out.mkdir(parents=True,exist_ok=True);checks={}
    s=.53;alpha=.05;error=2.;w=np.zeros(28);w_new=w+alpha*error*tile_features(s)
    us=np.linspace(0,.999,500);delta=np.array([tile_features(u)@w_new for u in us]);overlap=np.array([tile_features(u)@tile_features(s) for u in us])
    assert np.allclose(delta,alpha*error*overlap);assert tile_features(s).sum()==4
    checks['tile_update']={'sample':s,'alpha':alpha,'error':error,'active':4,'change_at_sample':float(tile_features(s)@w_new)}
    fig,(ax,ay)=plt.subplots(2,1,figsize=(10,4.4),gridspec_kw={'height_ratios':[1.2,1]},sharex=True)
    for k in range(4):
        offset=k*.25/4
        for j in range(-1,5):
            left=j*.25-offset
            active=left<=s<left+.25
            ax.add_patch(Rectangle((left,k-.38),.25,.7,facecolor=TEAL if active else '#eaf4f3',edgecolor='white',lw=2))
    ax.axvline(s,color=RED,lw=2);ax.set(xlim=(0,1),ylim=(-.5,3.5),yticks=range(4),yticklabels=['tiling 1','tiling 2','tiling 3','tiling 4']);ax.set_title('Four active weights receive the same TD error')
    ay.plot(us,delta,color=TEAL,lw=2);ay.axvline(s,color=RED,lw=1);ay.set(xlabel='state coordinate',ylabel='change in value',ylim=(0,.46));save(fig,out,'tile-generalization')
    x=np.ones((2,1));xn=np.array([[1.],[0.]]);r=np.array([0.,1.]);A,b,wtd=lstd_moments(x,r,xn,.9)
    mc=np.linalg.lstsq(x,np.array([.9,1.]),rcond=None)[0]
    assert np.allclose(wtd,[10/11]);assert np.allclose(mc,[.95]);assert abs(sum(r+.9*xn[:,0]*wtd[0]-x[:,0]*wtd[0]))<1e-12
    checks['lstd']={'A':A.tolist(),'b':b.tolist(),'w':wtd.tolist(),'mc':mc.tolist()}
    theta=np.array([.7,.9]);xs=np.array([-1.,.2,.7]);rew=np.array([0.,0.,1.]);f,bw=frozen_trace_identity(theta,xs,rew,.9,.8)
    assert np.allclose(f,bw,atol=1e-12)
    assert np.allclose(value_grad(theta,.7),finite_diff(lambda t:value(t,.7),theta),atol=1e-8)
    old=np.array([1.,.5]);new=np.array([1.4,.9]);z_old=.72*value_grad(old,1)+value_grad(new,-1);z_now=.72*value_grad(new,1)+value_grad(new,-1)
    assert np.linalg.norm(z_old-z_now)>.1
    checks['traces']={'forward':f.tolist(),'backward':bw.tolist(),'stored':z_old.tolist(),'recomputed':z_now.tolist()}
    fig,ax=plt.subplots(figsize=(6,3.2))
    for z,c,l in [(z_old,TEAL,'stored past gradient'),(z_now,RED,'past gradient recomputed now')]:
        ax.annotate('',xy=z,xytext=(0,0),arrowprops={'arrowstyle':'->','color':c,'lw':3});ax.scatter(*z,c=c,label=l)
    ax.axhline(0,c='#c5cecf',lw=1);ax.axvline(0,c='#c5cecf',lw=1);ax.set(xlim=(-.5,.05),ylim=(-.25,.06),xlabel='trace component for a',ylabel='trace component for b');ax.legend(loc='lower left',fontsize=9);save(fig,out,'nonlinear-trace')
    outer=fixed_target_outer_iteration();assert np.all(outer[:,4]==0);assert outer[-1,3]>100
    np.savetxt(out/'outer-iteration.csv',outer,delimiter=',',header='iteration,old_w,target,new_w,inner_loss',comments='')
    checks['fixed_target_outer']={'last_w':float(outer[-1,3]),'inner_losses':outer[:,4].tolist()}
    fig,(ax,ay)=plt.subplots(1,2,figsize=(9,3))
    ax.plot(outer[:,0]+1,outer[:,3],'-o',c=RED);ax.set(xlabel='target refresh',ylabel='fitted value at A',title='Outer predictions grow')
    ay.plot(outer[:,0]+1,outer[:,4],'-o',c=TEAL);ay.set(xlabel='target refresh',ylabel='inner regression loss',title='Each inner fit is exact',ylim=(-.02,.1));save(fig,out,'fixed-target-divergence')
    seq=np.array([[5.,0.],[2.,2.]]);discount=np.array([1.,.9]);orig=seq@discount;clipped=np.sign(seq)@discount
    assert np.argmax(orig)!=np.argmax(clipped)
    checks['reward_clipping']={'original':orig.tolist(),'clipped':clipped.tolist()}
    fig,(ax,ay)=plt.subplots(1,2,figsize=(8,3));ax.bar(['A: (5,0)','B: (2,2)'],orig,color=[TEAL,GOLD]);ay.bar(['A: (1,0)','B: (1,1)'],clipped,color=[TEAL,GOLD]);ax.set(title='Original rewards',ylabel='discounted return');ay.set(title='Reward sign clipping',ylabel='discounted return');save(fig,out,'reward-clipping')
    assert np.isclose(n_step_sarsa_target([1.,2.],3.,.9),1+.9*2+.9**2*3)
    assert np.isclose(n_step_sarsa_target([1.,2.],0.,.9),2.8)
    zw,zt,dw,dt=actor_critic_trace_step(np.array([.3]),np.array([-.2]),np.array([1.]),np.array([.5]),.4,.81,.9,.8,.6,.1,.2)
    assert np.allclose(zw,[1.216]) and np.allclose(zt,[.297])
    assert np.allclose(dw,[.04864]) and np.allclose(dt,[.02376])
    checks['n_step_and_ac']={'two_step_target':n_step_sarsa_target([1.,2.],3.,.9),'value_trace':zw.tolist(),'actor_trace':zt.tolist(),'value_increment':dw.tolist(),'actor_increment':dt.tolist()}
    ga,gc,ea,ej=shared_actor_critic();sig=lambda z:1/(1+np.exp(-z))
    obj=lambda e:-np.log(sig(e[0]))+.5*(-e[0]-1)**2
    assert np.allclose(finite_diff(obj,np.array([0.])),[ga+gc]);assert sig(ea)>.5>sig(ej)
    checks['shared_actor_critic']={'actor_grad':ga,'critic_grad':gc,'actor_only_probability':float(sig(ea)),'shared_probability':float(sig(ej))}
    fig,ax=plt.subplots(figsize=(8,2.5));ax.barh(['Actor only','Actor + critic'],[sig(ea),sig(ej)],color=[TEAL,RED]);ax.axvline(.5,c=INK,ls='--');ax.set(xlim=(.47,.53),xlabel='probability of the sampled action after one update');save(fig,out,'shared-encoder')
    train,real,beta,grid,chosen,true_action=model_exploitation()
    assert abs(beta - np.sum(train*real(train))/np.sum(train**2))<1e-12
    assert real(chosen)<0<real(true_action);assert abs(true_action-1/np.sqrt(3))<.001
    checks['model']={'beta':float(beta),'model_action':float(chosen),'actual_reward':float(real(chosen)),'true_optimal_action':float(true_action),'true_optimal_reward':float(real(true_action)),'in_range_action_reward':float(real(.4))}
    fig,ax=plt.subplots(figsize=(8,3.6));ax.axvspan(0,.4,color='#eaf4f3',label='collected action range');ax.plot(grid,real(grid),c=INK,lw=2,label='true effect a - a^3');ax.plot(grid,beta*grid,c=TEAL,lw=2,label='learned linear model');ax.scatter(train,real(train),color=GOLD,s=18,zorder=4);ax.scatter([chosen,chosen],[beta*chosen,real(chosen)],c=RED,s=45,zorder=5);ax.annotate('',xy=(chosen,real(chosen)),xytext=(chosen,beta*chosen),arrowprops={'arrowstyle':'->','color':RED,'lw':2});ax.set(xlabel='action',ylabel='next position = reward');ax.legend(loc='upper left',fontsize=9);save(fig,out,'planning-distribution')
    (out/'checks.json').write_text(json.dumps(checks,indent=2));print(json.dumps(checks,indent=2))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output-dir',type=Path,default=Path(__file__).resolve().parents[1]/'assets/deep-v13');args=p.parse_args();run(args.output_dir)
