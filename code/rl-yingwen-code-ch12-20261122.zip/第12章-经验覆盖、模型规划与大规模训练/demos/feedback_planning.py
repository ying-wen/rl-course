"""第 12 章：两步位置控制。直接运行 python3 demos/feedback_planning.py。

每个首动作对应一组等概率位置。观察位置后，施加一次控制，任务结束。
代价和期望用分数计算；打印时转成小数。
"""

from fractions import Fraction
from statistics import mean


CONTROLS = (-1, 0, 1)
WORLD = {"A": (-1, 1), "B": (Fraction(1, 2),)}
# 均值模型对两个首动作都准确预测 E[X]，但把随机的后果当成确定位置。
MEAN_MODEL = {action: (mean(positions),) for action, positions in WORLD.items()}


def cost(x, u, price):
    return (x + u) ** 2 + price * u ** 2


def open_loop_cost(positions, price):
    """在看到位置前决定第二步：对每个 u 求期望，再找代价最小的 u。"""
    return min(mean(cost(x, u, price) for x in positions) for u in CONTROLS)


def best_control(x, price):
    """在位置 x 已知时决定最后一步；两个模型对此时的代价都完全准确。"""
    return min(CONTROLS, key=lambda u: cost(x, u, price))


def feedback_cost(positions, price):
    """在每个可能位置选择控制，再按各位置的概率平均。"""
    costs = [cost(x, best_control(x, price), price) for x in positions]
    return mean(costs)


def compare(price):
    print(f"\n施力代价系数 k = {float(price):.2f}")
    planners = [
        ("完整分布，开环序列", WORLD, open_loop_cost),
        ("完整分布，反馈计划", WORLD, feedback_cost),
        ("均值模型，反馈计划", MEAN_MODEL, feedback_cost),
    ]
    for name, model, evaluate in planners:
        predicted = {a: evaluate(positions, price) for a, positions in model.items()}
        action = min(predicted, key=predicted.get)

        # 只执行首动作。第二步读到世界实际给出的位置，重新选择 u。
        positions = WORLD[action]
        executed = feedback_cost(positions, price)
        print(f"{name}  预测 A={float(predicted['A']):.2f}、B={float(predicted['B']):.2f}"
              f"  选 {action}  执行后期望代价={float(executed):.2f}")
        for x in positions:
            u = best_control(x, price)
            print(f"    观察 x={float(x):g}，取 u={u}，支付 {float(cost(x, u, price)):.2f}")


if __name__ == "__main__":
    compare(Fraction(15, 100))
    compare(Fraction(40, 100))
