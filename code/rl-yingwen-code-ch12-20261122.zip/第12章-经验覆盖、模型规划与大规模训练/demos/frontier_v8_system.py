#!/usr/bin/env python3
"""Deterministic FIFO queue and recurrent-state tests. Standard library only."""
from pathlib import Path
from collections import deque
import csv,json,argparse

def simulate(incoming,service,seconds=40):
 q=deque();updates=0;rows=[];consumed=[]
 for t in range(seconds):
  for _ in range(incoming):q.append((t,updates))
  ages=[];lags=[]
  for _ in range(min(service,len(q))):
   birth,version=q.popleft();ages.append(t-birth);lags.append(updates-version);updates+=1
  rows.append(dict(second=t+1,backlog=len(q),age=sum(ages)/len(ages),lag=sum(lags)/len(lags)))
  consumed+=ages
 return rows,consumed

def recurrent(alpha,h,obs):
 for x in obs:h=alpha*h+x
 return h

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--out',type=Path,default=Path(__file__).resolve().parent/'frontier-v8-results');args=ap.parse_args();args.out.mkdir(parents=True,exist_ok=True)
 fast,_=simulate(30,20);balanced,_=simulate(20,20)
 for row in fast:assert row['backlog']==10*row['second']
 assert all(row['backlog']==0 and row['age']==0 for row in balanced)
 with (args.out/'queue.csv').open('w') as f:
  w=csv.DictWriter(f,fieldnames=['second','backlog','age','lag']);w.writeheader();w.writerows(fast)
 # Old recurrent state produced under old weights; recomputation under current weights differs.
 prefix=[1,0,1,0];stored=recurrent(.8,0,prefix);exact=recurrent(.5,0,prefix);delta=stored-exact
 burn=[]
 for b in range(7):
  from_old=recurrent(.5,stored,[0]*b);from_full=recurrent(.5,exact,[0]*b)
  err=abs(from_old-from_full);assert abs(err-abs(delta)*.5**b)<1e-12
  burn.append({'burnin':b,'error':err})
 with (args.out/'burnin.csv').open('w') as f:w=csv.DictWriter(f,fieldnames=['burnin','error']);w.writeheader();w.writerows(burn)
 out={'queue_final':fast[-1],'balanced_final':balanced[-1],'old_hidden':stored,'current_hidden':exact,'burnin':burn,'checks':48,'scope':'unit record service; gradient count is one per consumed record; deterministic mechanism only'}
 (args.out/'system.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
if __name__=='__main__':main()
