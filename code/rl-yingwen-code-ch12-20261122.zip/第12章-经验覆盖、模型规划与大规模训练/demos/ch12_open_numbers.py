"""Numbers for the added chapter 12 pages. Python standard library only.

Everything is computed exactly from the four-door corridor counts in
ch12_fixed_corridor.py, or from small matrix games. Run:  python3 ch12_open_numbers.py
"""
from math import exp, log, isclose, sqrt
from itertools import product

from ch12_fixed_corridor import ROWS, evaluate

BEHAVIOR = [(s + f) / sum(row) for row, (_, s, f) in zip(ROWS, ROWS)]  # 5/6, 3/4, 5/6, 0
P_TRUE, PRIZE = .8, 4.


def section(title):
    print('\n== ' + title)


# ---------------------------------------------------------------- 12.1 evaluation
def importance_sampling(target):
    """Ordinary IS on the 150 recorded episodes; target gives P(forward) per door."""
    total, n_episodes = 0., sum(ROWS[0])
    weight = 1.
    for door, (exits, success, failure) in enumerate(ROWS):
        b_f = BEHAVIOR[door]
        # episodes that exit here: weight * (1-pi)/(1-b), return 1
        if exits:
            total += exits * weight * (1 - target[door]) / (1 - b_f)
        # failures here: return 0, contribute nothing
        if success + failure:
            weight *= target[door] / b_f
    return total / n_episodes


def fqe_always_forward(fill):
    """Fitted Q evaluation of 'always forward' on the records; unseen last-door Q is `fill`."""
    q = fill
    for door in reversed(range(3)):
        _, s, f = ROWS[door]
        q = s / (s + f) * q
    return q


def evaluation():
    section('12.1 evaluation is limited by coverage')
    pi3 = [1, 1, 1, 0]
    always = [1, 1, 1, 1]
    w = 1 / (BEHAVIOR[0] * BEHAVIOR[1] * BEHAVIOR[2])
    print(f'pi3 weight = {w:.4f}; IS(pi3) = {importance_sampling(pi3):.4f}; true = {evaluate(pi3, PRIZE):.4f}')
    print(f'IS(always forward) = {importance_sampling(always):.4f}; '
          f'true = {evaluate(always, PRIZE):.4f} (B=4) / {evaluate(always, 0):.4f} (B=0)')
    print(f'IS(behaviour) = {importance_sampling(BEHAVIOR):.4f}; true = {evaluate(BEHAVIOR, PRIZE):.4f}')
    for fill in (0., 1., 4., 5.):
        print(f'FQE(always forward), unseen Q filled with {fill}: {fqe_always_forward(fill):.4f}')
    assert isclose(w, 1.92) and isclose(importance_sampling(pi3), .512)
    assert importance_sampling(always) == 0.
    assert isclose(importance_sampling(BEHAVIOR), evaluate(BEHAVIOR, PRIZE))
    print('log10 weight of always-forward vs doors n (behaviour forward rate .8 / .5):')
    for n in range(1, 9):
        print(f'  n={n}: weight .8 -> {.8 ** -n:7.3f}  .5 -> {.5 ** -n:5.0f}   '
              f'log10 {-n * log(.8, 10):.3f} / {-n * log(.5, 10):.3f}')
    # variance of per-episode IS estimate when target = always forward, behaviour = r each door,
    # true success p=.8 at each door, n doors, prize 1 at the end (reward only on reaching end).
    for r in (.8, .5):
        n = 8
        # weight on full-forward episodes = r^-n, probability of full-forward-success = (r p)^n
        mean = (r * P_TRUE) ** n * r ** -n
        second = (r * P_TRUE) ** n * r ** (-2 * n)
        print(f'  n=8, rate {r}: per-episode mean {mean:.4f}, std {sqrt(second - mean ** 2):.3f}')
    assert isclose(.8 ** -8, 5.9605, rel_tol=1e-4) and .5 ** -8 == 256


# ---------------------------------------------------------------- 12.2 offline improvement
def behaviour_values():
    """Monte Carlo Q and V of the behaviour policy on the records (prob of success = data .8)."""
    v_next, qf, v = None, [0.] * 4, [0.] * 4
    for door in reversed(range(4)):
        _, s, f = ROWS[door]
        if s + f == 0:
            qf[door] = None
            v[door] = 1.
        else:
            qf[door] = s / (s + f) * v[door + 1]
            b = BEHAVIOR[door]
            v[door] = (1 - b) * 1. + b * qf[door]
    return qf, v


def awr_policy(beta):
    qf, v = behaviour_values()
    pol = []
    for door in range(4):
        b = BEHAVIOR[door]
        if qf[door] is None:
            pol.append(0.)
            continue
        wf = b * exp(beta * (qf[door] - v[door]))
        we = (1 - b) * exp(beta * (1. - v[door]))
        pol.append(wf / (wf + we))
    return pol


def decision_transformer(target_return=1):
    """P(forward | door, return-to-go = target) estimated from the records."""
    pol = []
    for door in range(4):
        exits, s, f = ROWS[door]
        later_exit_with_one = sum(ROWS[k][0] for k in range(door + 1, 4))  # all later exits return 1
        forward_hits = later_exit_with_one if s + f else 0
        if target_return == 1:
            pol.append(forward_hits / (forward_hits + exits))
        else:
            pol.append(0.)
    return pol


def offline_improvement():
    section('12.2 offline improvement on one scale')
    qf, v = behaviour_values()
    print('behaviour Q(forward):', [None if q is None else round(q, 4) for q in qf])
    print('behaviour V:', [round(x, 4) for x in v])
    bc = evaluate(BEHAVIOR, PRIZE)
    print(f'behaviour cloning: {bc:.4f} (both worlds {evaluate(BEHAVIOR, 0):.4f})')
    assert isclose(bc, 2 / 3)
    print('AWR, beta -> forward probabilities and true return:')
    curve = []
    for beta in (0, .5, 1, 2, 3, 5, 10, 20):
        pol = awr_policy(beta)
        curve.append((beta, evaluate(pol, PRIZE)))
        print(f'  beta={beta:>4}: {[round(p, 3) for p in pol]} -> {evaluate(pol, PRIZE):.4f}')
    assert isclose(evaluate(awr_policy(1), PRIZE), .708, abs_tol=5e-4)
    assert isclose(evaluate(awr_policy(10), PRIZE), .982, abs_tol=5e-4)
    dt = decision_transformer()
    print(f'DT conditioned on return 1: {[round(p, 4) for p in dt]} -> {evaluate(dt, PRIZE):.4f}')
    assert isclose(evaluate(dt, PRIZE), .719, abs_tol=5e-4)
    # Split of the 150 episodes at x0 by outcome
    exits0, s0, f0 = ROWS[0]
    after = sum(ROWS[k][0] for k in range(1, 4))
    print(f'x0 split: exit {exits0}, forward then return 1: {after}, forward then return 0: {s0 + f0 - after}')
    # What the conditioned policy believes P(return 1 | forward at x0) is, vs truth under that policy
    print(f'  in data P(return 1 | forward at x0) = {after / (s0 + f0):.3f}; exit gives 1 for sure')


# ---------------------------------------------------------------- 12.3 model uncertainty
def beta_quantile(a, b, q, lo=0., hi=1.):
    from math import lgamma
    def cdf(x, steps=4000):
        # simple Simpson integration of the Beta density
        if x <= 0: return 0.
        h = x / steps
        c = exp(lgamma(a + b) - lgamma(a) - lgamma(b))
        f = lambda t: c * t ** (a - 1) * (1 - t) ** (b - 1) if 0 < t < 1 else (c if (a == 1 and t == 0) else 0.)
        s = f(0.) + f(x)
        for i in range(1, steps):
            s += (4 if i % 2 else 2) * f(i * h)
        return s * h / 3
    for _ in range(50):
        mid = (lo + hi) / 2
        if cdf(mid) < q: lo = mid
        else: hi = mid
    return (lo + hi) / 2


def uncertainty():
    section('12.3 two kinds of uncertainty')
    members = 7
    for door, (_, s, f) in enumerate(ROWS):
        a, b = 1 + s, 1 + f
        mean = a / (a + b)
        sd = sqrt(a * b / ((a + b) ** 2 * (a + b + 1)))
        qs = [beta_quantile(a, b, (i + .5) / members) for i in range(members)]
        print(f'door x{door}: counts {s}/{s + f}, posterior mean {mean:.3f}, sd {sd:.3f}, '
              f'members {[round(x, 2) for x in qs]}')
    print('Each member predicts a success probability; all members near .8 means the .8 is aleatoric.')
    print('model error:')
    for ph in (.85, .9):
        for h in (1, 2, 4, 8):
            print(f'  p_hat={ph}, H={h}: plan value {ph ** h * PRIZE:.4f}, true {P_TRUE ** h * PRIZE:.4f}, '
                  f'error {(ph ** h - P_TRUE ** h) * PRIZE:.4f}')
    assert isclose((.9 ** 4 - .8 ** 4) * 4, .986, abs_tol=5e-4)
    for h in (1, 2, 4, 8):
        print(f'  threshold 4^(-1/{h}) = {4 ** (-1 / h):.4f}')
    assert isclose(.9 ** 8 * 4, 1.722, abs_tol=5e-4) and isclose(.8 ** 8 * 4, .671, abs_tol=5e-4)


# ---------------------------------------------------------------- 12.4 value equivalence, search
def value_equivalence():
    section('12.4 what the model needs to predict')
    a = (.8, 4.)
    pb = .9
    bb = 4. * (.8 / .9) ** 4
    for name, (p, prize) in (('true', a), ('other', (pb, bb))):
        vals = [p ** (4 - k) * prize for k in range(4)]
        print(f'{name}: p={p}, B={prize:.4f}, forward-value at x0..x3 {[round(x, 3) for x in vals]}, '
              f'policy {["F" if x > 1 else "E" for x in vals]}')
    assert isclose(pb ** 4 * bb, .8 ** 4 * 4)
    # A model that predicts the wrong p but the right decision boundary
    pc = .7
    print(f'p=.7 with B=4: start forward-value {pc ** 4 * 4:.4f} -> exits; same p, different policy')


def search_improvement():
    section('12.4 search as policy improvement (true corridor model, depth d, leaf value V_pi)')
    def value_of(policy):  # values at x0..x3 plus terminal B
        vals = [0.] * 5
        vals[4] = PRIZE
        for k in reversed(range(4)):
            vals[k] = policy[k] * P_TRUE * vals[k + 1] + (1 - policy[k])
        return vals

    def improve(policy, depth):
        vals = value_of(policy)
        new = []
        for k in range(4):
            # best d-step lookahead: going forward j<d doors then using leaf value, or exit
            # exhaustive over deterministic plans of length <= depth
            best_f, best_e = None, 1.
            def look(pos, d):
                if pos == 4: return PRIZE
                if d == 0: return vals[pos]
                return max(1., P_TRUE * look(pos + 1, d - 1))
            best_f = P_TRUE * look(k + 1, depth - 1)
            new.append(1. if best_f > best_e else 0.)
        return new

    for depth in (1, 2, 4):
        pol = list(BEHAVIOR)
        seq = [evaluate(pol, PRIZE)]
        for it in range(5):
            pol = improve(pol, depth)
            seq.append(evaluate(pol, PRIZE))
        print(f'depth {depth}: start value per round {[round(x, 3) for x in seq]}')


# ---------------------------------------------------------------- 12.5 V-trace on one gate (reference)
# The V-trace numbers live on existing pages (ch12-gate-vtrace); not recomputed here.


# ---------------------------------------------------------------- 12.7 games
RPS = [[0, -1, 1], [1, 0, -1], [-1, 1, 0]]  # row player's payoff; order R, P, S


def exploitability(x):
    best = max(sum(RPS[i][j] * x[j] for j in range(3)) for i in range(3))
    return best  # game value is 0


def games():
    section('12.7 what does learning well mean')
    x = (.5, .25, .25)
    pay = [sum(RPS[i][j] * x[j] for j in range(3)) for i in range(3)]
    print(f'opponent {x}: payoff of R,P,S = {pay}; exploitability {exploitability(x):.3f}')
    assert isclose(exploitability(x), .25)
    for y in ((1, 0, 0), (1 / 3, 1 / 3, 1 / 3)):
        print(f'  {tuple(round(t, 3) for t in y)} exploitability {exploitability(y):.3f}')

    section('12.7 penalty game, independent learners')
    k = -10
    M = [[10, 0, k], [0, 2, 0], [k, 0, 10]]
    for i, name in enumerate('abc'):
        print(f'  action {name}: expected payoff vs uniform partner {sum(M[i]) / 3:.4f}')
    assert isclose(sum(M[1]) / 3, 2 / 3) and sum(M[0]) == 0
    # VDN least-squares fit under uniform data: Q(a,b) ~ u(a) + w(b); greedy picks row/col means
    row = [sum(M[i]) / 3 for i in range(3)]
    col = [sum(M[i][j] for i in range(3)) / 3 for j in range(3)]
    mean = sum(map(sum, M)) / 9
    fit = [[row[i] + col[j] - mean for j in range(3)] for i in range(3)]
    best = max(product(range(3), range(3)), key=lambda ij: fit[ij[0]][ij[1]])
    print(f'  VDN fit (uniform data): {[[round(v, 2) for v in r] for r in fit]}; greedy joint {best}, '
          f'true payoff {M[best[0]][best[1]]}')
    assert best == (1, 1)

    section('12.7 sequential vs simultaneous improvement')
    T = [[0, 1], [1, 0]]  # team reward, both agents receive it
    a = [0, 0]
    sim = [T[a[0]][a[1]]]
    for _ in range(3):
        b0 = max(range(2), key=lambda u: T[u][a[1]])
        b1 = max(range(2), key=lambda u: T[a[0]][u])
        a = [b0, b1]
        sim.append(T[a[0]][a[1]])
    a = [0, 0]
    seq = [T[a[0]][a[1]]]
    for _ in range(3):
        a[0] = max(range(2), key=lambda u: (T[u][a[1]], u == a[0]))
        a[1] = max(range(2), key=lambda u: (T[a[0]][u], u == a[1]))
        seq.append(T[a[0]][a[1]])
    print(f'  simultaneous best responses: team reward per round {sim}')
    print(f'  sequential (agent 1 then agent 2): {seq}')
    assert sim == [0, 0, 0, 0] and seq[1:] == [1, 1, 1]

    section('12.7 population: self-play vs PSRO on RPS')
    def br(y):
        pay = [sum(RPS[i][j] * y[j] for j in range(3)) for i in range(3)]
        m = max(pay)
        return [i for i in range(3) if isclose(pay[i], m)][0]
    names = 'RPS'
    cur, sp = 0, []
    for _ in range(6):
        y = [0, 0, 0]; y[cur] = 1
        sp.append((names[cur], exploitability(y)))
        cur = br(y)
    print('  self-play (latest only):', sp)
    # PSRO with exact meta-Nash on the restricted game
    pop = [0]
    meta = {(0,): (1, 0, 0), (0, 1): (0, 1, 0), (0, 1, 2): (1 / 3, 1 / 3, 1 / 3)}
    for _ in range(3):
        y = meta[tuple(sorted(pop))]
        print(f'  PSRO population {[names[i] for i in sorted(pop)]}: meta-Nash {tuple(round(t, 3) for t in y)}, '
              f'exploitability {exploitability(y):.3f}')
        nxt = br(y)
        if nxt in pop: break
        pop.append(nxt)


def main():
    evaluation()
    offline_improvement()
    uncertainty()
    value_equivalence()
    search_improvement()
    games()


if __name__ == '__main__':
    main()
