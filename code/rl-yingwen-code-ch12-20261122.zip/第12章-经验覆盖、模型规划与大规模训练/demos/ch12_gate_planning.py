"""Fit, plan in, and evaluate the finite gate corridor used in Chapter 12.

Run python3 demos/ch12_gate_planning.py to reproduce the printed results.
Use --figure output.pdf to redraw the planning-horizon plot (Matplotlib).
Extra information supplied for model learning: the goal reward is 4, and
each attempted gate has the same conditional success probability.
"""
from argparse import ArgumentParser
from math import isclose, sqrt
from random import Random

BONUS, EXIT = 4.0, 1.0
TRUE_P = 0.8
# One explicitly constructed calibration batch of genuine gate outcomes.
# It illustrates the estimator conditional on this batch, not its average.
CALIBRATION = (1, 1, 1, 1, 0, 1, 1, 1, 1, 1)


def fit(outcomes):
    """Maximum likelihood for a shared Bernoulli success probability."""
    if not outcomes or any(x not in (0, 1) for x in outcomes):
        raise ValueError('Supply at least one binary attempted-gate outcome.')
    return sum(outcomes) / len(outcomes)


def action(remaining, lookahead, p_hat):
    """Solve the truncated model by backward induction; ties choose exit.

    The boundary is the known value of exiting at the artificial cutoff.
    A successful final crossing pays BONUS immediately and terminates.
    """
    if remaining < 1 or lookahead < 1 or not 0 <= p_hat <= 1:
        raise ValueError('Positive horizons and a probability are required.')
    depth = min(remaining, lookahead)
    value = EXIT
    for gates_left in range(remaining - depth + 1, remaining + 1):
        advance = p_hat * (BONUS if gates_left == 1 else value)
        choice = 'advance' if advance > EXIT else 'exit'
        value = max(EXIT, advance)
    return choice, value


def evaluate(policy, horizon, p_env):
    """True expected start return of the *executed* receding-horizon policy."""
    value = 0.0
    for remaining in range(1, horizon + 1):
        if policy(remaining) == 'exit':
            value = EXIT
        else:
            value = p_env * (BONUS if remaining == 1 else value)
    return value


def sample_episode(policy, gate_uniforms, p_env):
    """Execute one policy against one held-out vector of independent uniforms."""
    remaining = len(gate_uniforms)
    for noise in gate_uniforms:
        if policy(remaining) == 'exit':
            return EXIT
        if noise >= p_env:
            return 0.0
        remaining -= 1
    return BONUS


def experiment(horizon, p_hat, episodes=10000):
    random = Random(12 + horizon)
    # The same held-out gates are used for every policy in this comparison.
    uniforms = [[random.random() for _ in range(horizon)] for _ in range(episodes)]
    rows = []
    for name, depth, model in [('short', 2, p_hat), ('full', horizon, p_hat),
                               ('oracle', horizon, TRUE_P)]:
        def policy(remaining):
            return action(remaining, depth, model)[0]
        predicted = action(horizon, depth, model)[1]
        exact = evaluate(policy, horizon, TRUE_P)
        returns = [sample_episode(policy, u, TRUE_P) for u in uniforms]
        mean = sum(returns) / episodes
        se = sqrt(sum((g - mean)**2 for g in returns) / (episodes*(episodes-1)))
        rows.append((name, policy(horizon), predicted, exact, mean, se))
    return rows


def draw(path, p_hat):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from matplotlib import font_manager as fm
    available = {font.name for font in fm.fontManager.ttflist}
    zh = next((name for name in ('PingFang SC','Arial Unicode MS','Noto Sans CJK SC',
                                 'Songti SC') if name in available), None)
    if zh:
        plt.rcParams['font.family'] = zh
    plt.rcParams.update({'font.size': 10, 'pdf.fonttype': 42, 'axes.spines.top': False,
                         'axes.spines.right': False, 'axes.linewidth': .75})
    teal, gold, ink = '#08757c','#a76619','#273b46'
    fig, ax = plt.subplots(figsize=(6.9, 2.38))
    hs = range(1, 13)
    ax.axhline(EXIT, color=ink, linestyle='--', linewidth=1)
    ax.plot(hs, [BONUS*TRUE_P**h for h in hs], 'o-', color=teal, ms=3.4,
            label='真实环境' if zh else 'environment')
    ax.plot(hs, [BONUS*p_hat**h for h in hs], 's--', color=gold, ms=3.2,
            label='拟合模型' if zh else 'model')
    ax.axvspan(6.5, 12.5, color=gold, alpha=.075)
    ax.annotate('退出得 1' if zh else 'exit: 1', xy=(1.05,1.05), color=ink)
    ax.set(xlim=(.7,12.35),ylim=(0,3.8),xticks=[1,2,4,6,7,8,10,12],yticks=[0,1,2,3])
    ax.set_xlabel('剩余门数' if zh else 'gates remaining')
    ax.set_ylabel('始终前进的期望回报' if zh else 'advance policy return')
    ax.legend(frameon=False, ncol=2, loc='upper right')
    fig.tight_layout(pad=.3)
    fig.savefig(path, bbox_inches='tight', pad_inches=.025)
    plt.close(fig)


def main():
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--figure')
    args = parser.parse_args()
    p_hat = fit(CALIBRATION)
    for h in (4,8):
        # The only useful deterministic alternatives are immediate exit and
        # attempting every remaining gate. Any planned intermediate exit pays p^k.
        for p in (TRUE_P, p_hat):
            assert isclose(action(h,h,p)[1], max(EXIT,BONUS*p**h))
        predicted_error = BONUS*(p_hat-TRUE_P)*sum(
            p_hat**(h-1-i)*TRUE_P**i for i in range(h))
        assert isclose(predicted_error, BONUS*(p_hat**h-TRUE_P**h))
        print(f'H={h}: always advance: real={BONUS*TRUE_P**h:.6f}, '
              f'model={BONUS*p_hat**h:.6f}')
        print('policy   first action   model plan   true return   sample mean   SE')
        for name,first,score,exact,mean,se in experiment(h,p_hat):
            print(f'{name:7} {first:11} {score:10.4f} {exact:12.4f} {mean:12.4f} {se:.4f}')
    if args.figure:
        draw(args.figure,p_hat)


if __name__ == '__main__':
    main()
