#!/usr/bin/env python3
"""Small CPU calculations for the chapter 12--14 logical bridges.

Run from any directory with Python, NumPy and matplotlib. No training service,
external simulator, downloads, or previous output files are required.
Outputs go to --out (default: ../assets/v17-systems relative to this file).
Checks compare distinct calculations: expanded/recursive traces, finite
differences/score derivatives, first-hit sums/Poisson solves, and explicit
duration branches/option kernels. These are finite teaching calculations.
"""
from pathlib import Path
import argparse
import csv
import json
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt


def vtrace(rewards, values, continuation, ratios, gamma=.9, rho_cap=1., c_cap=1.):
    """Targets use the supplied pre-update values, including the cutoff tail."""
    rho = np.minimum(rho_cap, ratios)
    c = np.minimum(c_cap, ratios)
    discounts = gamma * np.asarray(continuation)
    delta = rho * (rewards + discounts * values[1:] - values[:-1])
    targets = np.empty(len(rewards) + 1)
    targets[-1] = values[-1]
    for t in range(len(rewards)-1, -1, -1):
        targets[t] = values[t] + delta[t] + discounts[t]*c[t]*(targets[t+1]-values[t+1])
    actor_weight = rho*(rewards + discounts*targets[1:] - values[:-1])
    return targets, actor_weight


def expanded_vtrace(rewards, values, continuation, ratios, gamma, rho_cap, c_cap):
    """Independent finite sum of all later TD residuals, rather than a scan."""
    result = values.copy()
    for s in range(len(rewards)):
        for t in range(s, len(rewards)):
            prefix = np.prod([gamma*continuation[i]*min(c_cap, ratios[i]) for i in range(s,t)])
            residual = rewards[t]+gamma*continuation[t]*values[t+1]-values[t]
            result[s] += prefix*min(rho_cap, ratios[t])*residual
    return result


def sigmoid(theta):
    return 1/(1+np.exp(-np.asarray(theta)))


def program_logp(theta, paths):
    # First bit chooses '+', second chooses k=1, identically at either prefix.
    p = sigmoid(theta)
    return paths*np.log(p)+(1-paths)*np.log1p(-p)


def grpo_reward_surrogate(theta, paths, old_logp, advantages, clip=.2):
    ratios = np.exp(program_logp(theta, paths)-old_logp)
    term = np.minimum(ratios*advantages[:,None], np.clip(ratios,1-clip,1+clip)*advantages[:,None])
    return term.mean(axis=1).mean()  # same length: two tokens per answer


def run(out):
    out.mkdir(parents=True, exist_ok=True)
    checks = []
    def check(name, condition, **evidence):
        if not bool(condition):
            raise AssertionError((name, evidence))
        checks.append(dict(name=name, passed=True, **evidence))

    r=np.array([1.,2.]); v=np.array([.4,.8,0.]); m=np.array([1.,0.]); ratios=np.array([.5,1.5])
    target, actor_weight=vtrace(r,v,m,ratios)
    check('vtrace_example', np.allclose(target,[1.6,2.,0.]), targets=target.tolist())
    for rho_cap,c_cap in [(1.,1.),(2.,1.),(3.,.4)]:
        for continuation in [np.array([1.,0.]),np.array([1.,1.])]:
            vv=np.array([.4,.8,1.7])
            actual,_=vtrace(r,vv,continuation,ratios,.9,rho_cap,c_cap)
            expected=expanded_vtrace(r,vv,continuation,ratios,.9,rho_cap,c_cap)
            check(f'expanded_trace_{rho_cap}_{c_cap}_{continuation[-1]}',np.allclose(actual,expected),max_error=float(abs(actual-expected).max()))
    onpolicy,_=vtrace(r,np.array([.4,.8,1.7]),np.ones(2),np.ones(2))
    check('cutoff_keeps_tail',np.isclose(onpolicy[0],1+.9*2+.9**2*1.7),target=float(onpolicy[0]))
    terminal,_=vtrace(r,np.array([.4,.8,1.7]),m,np.ones(2))
    check('terminal_removes_tail',np.isclose(terminal[0],2.8),target=float(terminal[0]))
    updated_v=v[:-1]+.1*(target[:-1]-v[:-1])
    p_old=np.array([.25,.75]); logits=np.log(p_old/(1-p_old))
    p_new=sigmoid(logits+.2*actor_weight*(1-p_old))
    # Frozen weights must have the same derivative as the log-prob surrogate.
    eps=1e-6
    fd=np.array([(np.dot(actor_weight,np.log(sigmoid(logits+eps*np.eye(2)[i])))-np.dot(actor_weight,np.log(sigmoid(logits-eps*np.eye(2)[i]))))/(2*eps) for i in range(2)])
    check('vtrace_actor_finite_difference',np.allclose(fd,actor_weight*(1-p_old),atol=1e-9),gradient=fd.tolist())

    paths=np.array([[1.,1.],[1.,0.],[0.,1.],[0.,0.]])
    rewards=np.array([1.,0.,0.,0.]); adv=(rewards-rewards.mean())/rewards.std()
    theta=np.zeros(2); old=program_logp(theta,paths)
    grad=(adv[:,None]*(paths-.5)).mean(axis=0)/2
    fd=np.array([(grpo_reward_surrogate(theta+eps*np.eye(2)[i],paths,old,adv)-grpo_reward_surrogate(theta-eps*np.eye(2)[i],paths,old,adv))/(2*eps) for i in range(2)])
    check('grpo_fixed_batch_gradient',np.allclose(grad,fd,atol=1e-9),gradient=grad.tolist(),advantages=adv.tolist())
    program_p=sigmoid(theta+.8*grad)
    success=float(np.prod(program_p))
    enumeration=sum(float(np.prod(np.where(path,program_p,1-program_p)))*rew for path,rew in zip(paths,rewards))
    check('program_success_after_update',np.isclose(success,enumeration) and success>.25,probabilities=program_p.tolist(),success=success)
    # Clipped positive-advantage action has zero local slope beyond upper bound.
    clip_function=lambda z:min(2*sigmoid(z),1.2)
    clip_fd=(clip_function(1+eps)-clip_function(1-eps))/(2*eps)
    check('positive_advantage_clip_plateau',abs(clip_fd)<1e-10)

    # A-C-A ring has twelve distinct position/direction states.
    ring_r=np.zeros(12);ring_r[5]=3.;ring_r[11]=1.
    P=np.roll(np.eye(12),1,axis=1)
    matrix=np.block([[np.eye(12)-P,np.ones((12,1))],[np.eye(12)[[0]],np.zeros((1,1))]])
    solved=np.linalg.solve(matrix,np.r_[ring_r,0.]); h=solved[:-1]; gain=solved[-1]
    first_hit=np.zeros(12)
    for s in range(1,12):
        first_hit[s]=sum(ring_r[k]-gain for k in range(s,12))
    boundary_residual=np.array([3-6*gain+h[6]-h[0],1-6*gain+h[0]-h[6]])
    check('bias_first_hit_vs_poisson',np.allclose(h,first_hit) and np.allclose(boundary_residual,0),gain=float(gain),h_C=float(h[6]),h_before_C=float(h[5]),max_error=float(abs(h-first_hit).max()),option_boundary_residual=boundary_residual.tolist())
    for horizon in range(61):
        for s in range(12):
            centered=sum(ring_r[(s+k)%12]-gain for k in range(horizon))
            assert np.isclose(centered,h[s]-h[(s+horizon)%12])
    check('finite_horizon_telescoping',True,number_of_cases=12*61)
    # Undiscounted recurrent excess does not converge in ordinary partial sums.
    partial=np.cumsum(np.tile(ring_r-gain,3))
    check('periodic_partial_sum_failure',np.ptp(partial[-12:])>1.,last_cycle_range=float(np.ptp(partial[-12:])))
    previous_error=float('inf')
    for gamma in [.9,.99,.999]:
        discounted=np.linalg.solve(np.eye(12)-gamma*P,ring_r)
        cycles=np.array([sum(gamma**k*ring_r[(s+k)%12] for k in range(12))/(1-gamma**12) for s in range(12)])
        error=float(abs(discounted-discounted[0]-h).max())
        check(f'centered_discount_{gamma}', np.allclose(discounted,cycles) and error<previous_error,error=error,cycle_sum_error=float(abs(discounted-cycles).max()))
        previous_error=error

    # Random duration and endpoint are correlated: retain the joint law.
    gamma=.9; duration=np.array([1,3]); prob=np.array([.5,.5]); endpoint_value=np.array([1.,3.])
    kernel=prob*gamma**duration
    branch_value=float(sum(p*gamma**int(t)*u for p,t,u in zip(prob,duration,endpoint_value)))
    check('discounted_option_kernel',np.isclose(kernel@endpoint_value,branch_value),joint_value=branch_value,incorrect_independent_value=float(kernel.sum()*(prob@endpoint_value)))
    check('mean_duration_discount_is_different',not np.isclose(kernel.sum(),gamma**(prob@duration)),expected_discount=float(kernel.sum()),discount_at_mean_duration=float(gamma**(prob@duration)))
    # Fixed-trajectory hypergradient is a different derivative from a TD trace.
    def scalar_stream(beta):
        w=0.;H=0.;alpha=np.exp(beta)
        for y in [1.,0.]:
            H=(1-alpha)*H+alpha*(y-w)
            w=w+alpha*(y-w)
        return w,H
    beta=np.log(.8); w,H=scalar_stream(beta)
    meta_fd=(scalar_stream(beta+eps)[0]-scalar_stream(beta-eps)[0])/(2*eps)
    check('fixed_trajectory_meta_gradient',np.isclose(H,meta_fd,atol=1e-9) and H<0,w=w,H=H,finite_difference=meta_fd,one_step_trace=1.)

    colors=['#61757D','#C4942A','#087E8B']
    fig,ax=plt.subplots(1,2,figsize=(9.4,2.8),layout='constrained')
    x=np.arange(2)
    for i,(lab,data) in enumerate([('Before',v[:-1]),('Target',target[:-1]),('After one update',updated_v)]):
        ax[0].bar(x+(i-1)*.23,data,.23,label=lab,color=colors[i])
    ax[0].set(xticks=x,xticklabels=['State 0','State 1'],ylabel='Value estimate / target',ylim=(0,2.55))
    ax[0].legend(frameon=False,fontsize=8,loc='upper left')
    ax[1].bar(x-.13,p_old,.26,color=colors[0],label='Before')
    ax[1].bar(x+.13,p_new,.26,color=colors[2],label='After one update')
    ax[1].set(xticks=x,xticklabels=['State 0','State 1'],ylabel='Probability of sampled action',ylim=(0,1))
    ax[1].legend(frameon=False,fontsize=8)
    for a in ax:
        a.spines[['top','right']].set_visible(False)
    for ext in ['pdf','png']:
        fig.savefig(out/f'vtrace-update.{ext}',dpi=160)
    plt.close(fig)
    with (out/'vtrace-update.csv').open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=['state','old_value','target','new_value','old_action_probability','new_action_probability'])
        writer.writeheader()
        for i in range(2):writer.writerow(dict(state=i,old_value=v[i],target=target[i],new_value=updated_v[i],old_action_probability=p_old[i],new_action_probability=p_new[i]))
    result=dict(scope='Finite CPU calculations; no large-scale training or algorithm performance comparison.',checks=checks,vtrace=dict(value_after=updated_v.tolist(),actor_weights=actor_weight.tolist(),probability_after=p_new.tolist()),grpo=dict(gradient=grad.tolist(),success_after=success),bias=dict(gain=float(gain),values=h.tolist()))
    (out/'checks.json').write_text(json.dumps(result,indent=2))
    print(json.dumps(dict(passed=len(checks),outputs=str(out),vtrace=result['vtrace'],grpo=result['grpo']),indent=2))


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out',type=Path,default=Path(__file__).resolve().parents[1]/'assets/v17-systems')
    run(parser.parse_args().out.resolve())
