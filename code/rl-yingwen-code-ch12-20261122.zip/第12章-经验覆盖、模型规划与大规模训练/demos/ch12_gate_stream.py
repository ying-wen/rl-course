"""Finite scheduling experiment, no model fitting. One record = one *real* MDP step.
Reproduce the graph: python3 demos/ch12_gate_stream.py --csv assets/ch12-systems/queue.csv
"""
import argparse
import csv
import math
import random
from collections import deque

def simulate(mode, ticks=40, seed=12):
    """One published policy version per tick (exogenous); 3 active environment slots."""
    rng=random.Random(seed)
    queue=deque()
    state=[0,0,0]
    ages=[]; ratios=[]; rows=[]
    produced=used=dropped=0
    prob=lambda k: 0.2+0.6*k/(ticks-1)
    for k in range(ticks):
        # Idle the third producer in the rate-matched condition BEFORE its environment step.
        for i in range(2 if mode=="matched" else 3):
            x=state[i]; b=prob(k); forward=rng.random()<b
            mu=b if forward else 1-b
            passes=forward and rng.random()<.8
            terminal=not passes or x==3
            reward=(4 if passes and x==3 else 0) if forward else 1
            state[i]=0 if terminal else x+1
            queue.append((k,x,forward,mu,reward,state[i] if not terminal else None))
            produced+=1
        if mode=="fresh":
            while len(queue)>2: queue.popleft(); dropped+=1
        batch=[queue.popleft() for _ in range(2)]
        for v,x,a,mu,r,xnext in batch:
            pi=prob(k) if a else 1-prob(k)
            ages.append(k-v); ratios.append(pi/mu); used+=1
        rows.append((k+1,len(queue),sum(k-item[0] for item in batch)/2))
        assert used+dropped+len(queue)==produced
    return rows,(produced,used,dropped,len(queue),sum(ages)/len(ages),max(ages),sum(abs(math.log(r)) for r in ratios)/len(ratios))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--csv');args=p.parse_args()
    histories={}
    for mode,expected in [('fifo',(120,80,0,40)),('fresh',(120,80,40,0)),('matched',(80,80,0,0))]:
        h,m=simulate(mode);histories[mode]=h
        assert m[:4]==expected and (m[4]>0 if mode=='fifo' else m[4]==0)
        print(mode,'produced, used, discarded, backlog, mean lag, max lag, mean |log ratio|:',m)
    if args.csv:
        with open(args.csv,'w',newline='') as f:
            w=csv.writer(f);w.writerow(['tick','fifo','fresh','matched','fifo_lag'])
            for a,b,c in zip(*histories.values()):w.writerow([a[0],a[1],b[1],c[1],a[2]])
