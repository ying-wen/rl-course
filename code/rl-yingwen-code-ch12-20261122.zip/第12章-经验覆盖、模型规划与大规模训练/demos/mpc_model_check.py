"""Replay the position-control experiment with the published seeds and noise.

Run from any directory: python3 path/to/demos/mpc_model_check.py
Every alternative starts at the frozen controller's observed position at step 80.
Only the simulator and the reference controller know the new dynamics.
"""
import csv
from collections import defaultdict
from itertools import product
from pathlib import Path
from statistics import mean

DATA = Path(__file__).resolve().parents[1] / "assets/dqn-model-v11/mpc-control.csv"
AFTER = (0.85, 0.6, -0.3)
HORIZONS = (1, 2, 4)
SEQUENCES = {h: tuple(product((-1, 0, 1), repeat=h)) for h in HORIZONS}


def successor(x, u, coefficients):
    a, b, c = coefficients
    return a * x + b * u + c


def cost(positions, actions):
    return sum(x*x + 0.15*u*u for x, u in zip(positions, actions))


def predicted_positions(x, actions, model):
    positions = []
    for u in actions:
        x = successor(x, u, model)
        positions.append(x)
    return positions


def best_sequence(x, model, horizon):
    def predicted_cost(actions):
        return cost(predicted_positions(x, actions, model), actions)
    return min(SEQUENCES[horizon], key=predicted_cost)


def execute(x, model, horizon, noise, commit=False):
    """Let only the simulator see the external disturbance at each step."""
    actions, positions = [], []
    for t, disturbance in enumerate(noise):
        if not commit or t % horizon == 0:
            sequence = best_sequence(x, model, horizon)
        u = sequence[t % horizon] if commit else sequence[0]
        x = successor(x, u, AFTER) + disturbance
        actions.append(u)
        positions.append(x)
    return actions, positions


def main():
    per_seed = defaultdict(list)
    with DATA.open(encoding="utf-8", newline="") as stream:
        for row in csv.DictReader(stream):
            if row["method"] == "learned MPC" and int(row["t"]) >= 80:
                per_seed[int(row["seed"])].append(row)

    mean_costs = defaultdict(list)
    for seed, rows in sorted(per_seed.items()):
        assert [int(row["t"]) for row in rows] == list(range(80, 160))
        x = float(rows[0]["x"])
        fitted = tuple(float(rows[0][name]) for name in ("a_used", "b_used", "c_used"))
        # The world is affine with additive action-independent noise. Reusing
        # these innovations defines a paired simulation, including after paths diverge.
        noise = [float(r["next_x"]) - successor(float(r["x"]), float(r["u"]), AFTER)
                 for r in rows]
        for horizon in HORIZONS:
            for name, model in (("frozen", fitted), ("known", AFTER)):
                actions, positions = execute(x, model, horizon, noise)
                mean_costs[horizon, name].append(cost(positions, actions) / len(noise))
                if name == "frozen" and horizon == 4:
                    assert actions == [int(float(r["u"])) for r in rows]
                    assert max(abs(z - float(r["next_x"])) for z, r in zip(positions, rows)) < 1e-10

        actions, positions = execute(x, fitted, 4, noise, commit=True)
        mean_costs[4, "commit"].append(cost(positions, actions) / len(noise))
        if seed == 0:
            predicted = predicted_positions(x, actions[:4], fitted)
            revised, observed = execute(x, fitted, 4, noise[:4])
            print(f"seed 0, step 80, x={x:.6f}; frozen fit: {fitted}")
            print("k   plan  predicted x  committed x     MPC u     MPC x")
            for k in range(4):
                print(f"{k+1} {actions[k]:6d} {predicted[k]:12.5f} {positions[k]:12.5f}"
                      f" {revised[k]:9d} {observed[k]:9.5f}")
            print("4-step costs: predicted / committed / MPC:",
                  *(f"{v:.6f}" for v in (cost(predicted, actions[:4]),
                                         cost(positions[:4], actions[:4]), cost(observed, revised))))

    print(f"\n{len(per_seed)} seeds, common starting position per seed, 80 actual steps. "
          "Mean cost per executed step:")
    print("H   candidates   frozen MPC   known-model MPC")
    for h in HORIZONS:
        print(f"{h} {len(SEQUENCES[h]):12d} {mean(mean_costs[h, 'frozen']):12.6f}"
              f" {mean(mean_costs[h, 'known']):17.6f}")
    print(f"Frozen H=4, commit each block of four: {mean(mean_costs[4, 'commit']):.6f}")


if __name__ == "__main__":
    main()
