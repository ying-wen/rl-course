# 课件图片出处

| 图 | 来源与取图范围 |
|---|---|
| triad-dyad.png | 温颖[《从现代深度强化学习到持续强化学习》](https://yingwen.io/zh/blog/from-modern-deep-rl-to-continual-rl/)插图。“智能体、环境与设计者”展示两种交互的主体部分。|
| concept-crl-setting-axes.pdf | [原 SVG](https://yingwen.io/crl-figures/concept-crl-setting-axes.svg) 等比例转换为矢量 PDF。“有限 MDP 与模型信息”放大 POMDP 和 MDP 的同一格子世界。|
| overview-reward-paths.pdf | [原 SVG](https://yingwen.io/crl-figures/overview-reward-paths.svg) 的两条路径。写在边上的奖励与投影片中使用的数值一致。|
| kris-bigworld.png（上一级目录） | Kris De Asis，[Design for Learning](https://kris.pengy.ca/designforlearning)。[导读所用原图](https://yingwen.io/blog/from-modern-deep-rl-to-continual-rl/kris-design-for-learning-bigworld-original.png)。|
| tic-tac-toe-fig1-1.png | Sutton & Barto，[Reinforcement Learning: An Introduction](https://mitpress.mit.edu/9780262039246/reinforcement-learning/)，第 2 版，图 1.1（印刷页 10）。保留游戏树、交替行动及价值更新箭头。|
| openai-five-fig9.png | Berner et al.，[Dota 2 with Large Scale Deep Reinforcement Learning](https://arxiv.org/pdf/1912.06680#page=34)，图 9。保留全部曲线、坐标、图例和比赛事件标注。|
