# 函数逼近、深度学习与规划的计算图

运行：

```bash
python3 demos/deep_v13_connections.py
# 将结果另存到指定目录
python3 demos/deep_v13_connections.py --output-dir runs/connections
```

依赖：NumPy、Matplotlib。脚本根据自身位置确定默认输出目录，可从任意工作目录运行。`checks.json` 保存数值；`outer-iteration.csv` 保存每轮目标复制后的精确回归结果。以下六组图为原创计算，PDF与PNG包含相同内容。

| 图 | 所解释的问题 | 对应函数与条件 |
|---|---|---|
| `tile-generalization` | 一条经验怎样影响相邻输入 | `tile_features`：四层固定的瓦片网格，各层权重独立；一次线性更新 |
| `nonlinear-trace` | 表示改变后，旧梯度与重算梯度为何不同 | `value_grad`、`parameter_trace_step`：两参数tanh；两组参数由算例指定 |
| `fixed-target-divergence` | 为何每轮损失为零而预测仍发散 | `fixed_target_outer_iteration`：经验只有A→B，两个输出共享一个权重；每轮精确拟合 |
| `reward-clipping` | 奖励裁剪怎样改变策略排序 | 两条确定性两步路径，折扣0.9；比较原奖励与符号奖励 |
| `shared-encoder` | 价值损失怎样直接改变动作概率 | `shared_actor_critic`：单步一致回报目标；策略与价值共用一个参数 |
| `planning-distribution` | 规划怎样查询数据外的模型预测 | `model_exploitation`：真实位移a−a³；在[0,0.4]上拟合，再在[0,1.5]中选择动作 |

这些图分别隔离一项机制。它们不是完整DQN、PPO、SAC或世界模型基准。第10—12章的完整教学训练图仍由 `demos/dqn_model_v11.py` 和相应PPO/SAC实验产生。

`frozen_trace_identity` 从每一种n步回报独立构造前向λ目标，再与后向迹累计比较；`n_step_sarsa_target` 检查末端自举和真正终止；`actor_critic_trace_step` 给出书中回合型actor–critic的两条迹及参数增量。有限差分检查了tanh预测梯度和共享actor–critic导数。LSTD另用线性方程求解及零平均TD误差核对。

## Mountain Car原图

`sutton-mountain-car-fig10-1.pdf/png` 摘录自 Sutton与Barto，*Reinforcement Learning: An Introduction*（第2版），Fig.10.1，纸本第245页。原图展示原书一次学习运行的代价函数；其结果不属于本课程代码复现。教材入口：[原书网站](http://incompleteideas.net/book/the-book-2nd.html)。

图页中的位置、速度与纵轴刻度保留。为适合投影片，仅提取完整图的区域，没有重绘数据。出处也显示在使用它的投影片及讲义中。第三方原图的权利归原作者，不包含在原创代码的MIT许可内。
