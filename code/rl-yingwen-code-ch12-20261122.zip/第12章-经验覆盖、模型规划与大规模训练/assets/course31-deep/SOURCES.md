# 论文原图

| 课件图片 | 图源与取图范围 | 图中测量 |
| --- | --- | --- |
| seaquest-value.png | [Mnih 等，2013，图 3](https://arxiv.org/abs/1312.5602)，全图，原图注见论文 | Seaquest 连续 30 帧内预测的价值及 A、B、C 帧 |
| rainbow-ablation.png | [Hessel 等，2018，图 3](https://arxiv.org/abs/1710.02298)，全图 | 去掉单个组件后，57 款 Atari 游戏人类归一化得分的中位数 |
| sac-humanoid.png | [Haarnoja 等，2018，图 2](https://proceedings.mlr.press/v80/haarnoja18b.html)，全图 | rllab Humanoid 上 SAC 与确定性变体各五次训练的回报 |
| impala-actors.png | [Espeholt 等，2018，图 1](https://proceedings.mlr.press/v80/espeholt18a.html)，左图 | 一个学习器与多个采样者之间的参数和数据传输 |
| overview-shared-features.svg、.png | [温颖，《持续强化学习》〈强化学习问题〉](https://yingwen.io/zh/continual-rl/overview/)，[网站原 SVG](https://yingwen.io/crl-figures/overview-shared-features.svg) | 两个目标 0 和 2 共用一个参数；两次单样本更新分别从最优值 1 出发 |
| hil-reward.png | [Luo 等，HIL-SERL，附录 B 图 24](https://hil-serl.github.io/static/hil-serl-paper.pdf#page=50)，保留上两行的四张照片 | 用于训练成功分类器的内存条插入图像，分别显示成功、未入槽、插错位置和未完全插入 |
