# 第 12 章　经验覆盖、模型规划与大规模训练：程序

本目录可以单独运行：在本目录下执行下面的命令即可，结果写回本目录的 `assets/`。目录由 `rl-course/tools/export_chapter_code.py` 从课程目录生成，改程序请改课程目录里的原件，再重新导出。

## 准备

```sh
python3 -m pip install -r requirements.txt
```

需要的第三方包：matplotlib、numpy；只有个别程序需要的：fitz（course_v12_visuals.py）。复现附录要求 Python 3.10 或更新版本；核验时用的版本见下表。

## 运行（与复现附录相同）

```sh
python3 demos/ch12_fixed_corridor.py
python3 demos/course_v12_visuals.py
python3 demos/ch12_open_numbers.py
python3 demos/offline_support_walkthrough.py
python3 demos/ch12_gate_planning.py
python3 demos/ch12_gate_planning.py --figure gate-horizon.pdf
python3 demos/dqn_model_v11.py
python3 demos/deep_v13_connections.py
python3 demos/mpc_model_check.py
python3 demos/multiscale_models.py
python3 demos/feedback_planning.py
python3 demos/v17_systems.py
python3 demos/ch12_gate_stream.py --csv assets/ch12-systems/queue.csv
python3 demos/frontier_v8_system.py
python3 demos/multiagent_selfplay_check.py
```

## 本目录的程序

| 程序 | 说明 | 核验 |
|---|---|---|
| `demos/ch12_fixed_corridor.py` | Fixed-data control on a four-door corridor. Python standard library. | 通过（0 秒） |
| `demos/course_v12_visuals.py` | Exact teaching examples and credited source crops for the v12 course bridges. | 通过（1 秒） |
| `demos/ch12_open_numbers.py` | Numbers for the added chapter 12 pages. Python standard library only. | 通过（3 秒） |
| `demos/offline_support_walkthrough.py` | Fixed support hole, CQL gradients, IQL and OPE; Python standard library only. | 通过（0 秒） |
| `demos/ch12_gate_planning.py` | Fit, plan in, and evaluate the finite gate corridor used in Chapter 12. | 通过（2 秒） |
| `demos/dqn_model_v11.py` | CPU learning experiments for chapters 10 and 12, not paper reproductions. | 通过（16 秒） |
| `demos/deep_v13_connections.py` | Recompute the numerical mechanisms used in Chapters 9--12. | 通过（3 秒） |
| `demos/mpc_model_check.py` | Replay the position-control experiment with the published seeds and noise. | 通过（0 秒） |
| `demos/multiscale_models.py` | Compare recursive and direct prediction with exactly the same observed paths. | 通过（4 秒） |
| `demos/feedback_planning.py` | 第 12 章：两步位置控制。直接运行 python3 demos/feedback_planning.py。 | 通过（0 秒） |
| `demos/v17_systems.py` | Small CPU calculations for the chapter 12--14 logical bridges. | 通过（1 秒） |
| `demos/ch12_gate_stream.py` | Finite scheduling experiment, no model fitting. One record = one *real* MDP step. | 通过（0 秒） |
| `demos/frontier_v8_system.py` | Deterministic FIFO queue and recurrent-state tests. Standard library only. | 通过（0 秒） |
| `demos/multiagent_selfplay_check.py` | Team baseline, coordination and nontransitive opponents; exact finite checks. | 通过（0 秒） |
| `demos/ch12_model_figs_zh.py` | 11-21 请求 r1121-114444：第 12 章 842、843 两页的图改用中文与课件字体重出。 | 通过（2 秒） |

被上面程序 import 的本课模块：`demos/plot_fonts.py`。

表中后 1 个程序复现附录本章一节没有列出，来自课件、阅读稿、CODE-MAP 或文件名前缀（第三部分另含学习器阶梯）。

## 复现附录本章一节

本章来自本课程序的结果有：四道门走廊上的三组算例（固定数据、模型规划与数据流调度），离线评价与改进的小算例，一维位置控制上的模型拟合与模型预测控制，递归与直接多步预测的比较，V-trace 单批更新，FIFO 队列，以及多人博弈的有限算例。Dyna 结构图、IMPALA 示意图、OpenAI Five 的滞后与复用曲线和 GEAR 吞吐图取自原课件与原论文，不在表中。

| 位置 | 结果 | 设置 | 程序 | 数据与输出 |
|---|---|---|---|---|
| 12.1 节开头；12.2 节表格与 CQL 段落；课件 ch12-corridor-data、deep-offline-worlds、deep-49、offline-support、frontier-v8-cql-derivation、ch12-cql-numbers、deep-offline-iql、frontier-v8-iql-derivation、deep-v10-offline-extract、ch12-offline-policy | 150 个完整回合、350 条转移的计数；四种方法的前进概率与入口回报：普通贪心（未见值 $u=5$）$1.6384$ / $0$，支持内贪心 $1$ / $1$，表格 CQL $.512$ / $.512$，表格 IQL（前进概率 $.657,.550,.733,0$）$.777$ / $.777$；CQL 末门未见动作的估值由 $5$ 降到 $-2.877$ | 本课的计算：四道门走廊，通过率 $.8$，末门奖励 $B=4$ 与 $B=0$ 两个设定；训练只读计数，真实奖励与通过率只用于评价；表格 CQL 系数 $.25$、步长 $.2$、全批 $10^4$ 步、目标每 20 步复制一次；IQL 取 $\tau=.75$、$\beta=3$ | `demos/ch12_fixed_corridor.py` | 终端输出 |
| 12.1 节延伸阅读“留出TD损失与价值误差”；课件 course-v12-offline-validation | 候选 A（真值）留出 TD 损失 $.729$，候选 B（全零）$.2$；平方 Bellman 残差与目标方差的分解 | 本课的计算：三状态有限分支逐项枚举，$\gamma=.9$，验证状态分布 $(.9,.05,.05)$；不做离线训练 | `demos/course_v12_visuals.py` | `assets/course-v12/checks.json`（`offline_validation`）；`assets/course-v12/offline-validation.png` |
| 12.1 节“只评价也要覆盖”；课件 ch12-eval-coverage、ch12-eval-two | 评价 $\pi_3$ 的重要性权重 $1.92$ 与估计 $.512$；八道门时单条权重 $5.96$ 与 $256$、单条估计标准差约 $.99$ 与 $6.55$；拟合 Q 评价在不同未见值下的结果 | 本课的计算：由走廊原始计数精确求和，八道门部分用解析期望与二阶矩 | `demos/ch12_open_numbers.py` | 终端输出 |
| 12.2 节延伸阅读（CQL 梯度与 IQL 提取）；图 offline-support-objectives | 第三个未见动作在 $Q=(0,2,4)$ 下的 CQL 梯度与一次更新；$\tau=.75$ 时 $V=1.5$；频率 $(.9,.1)$ 时提取概率 $(.5491,.4509)$，回报由 $.2$ 变为 $.9017$ | 本课的计算：给定的四条轨迹与 Q 快照，不随机采样、不与环境交互、不训练网络 | `demos/offline_support_walkthrough.py` | 终端输出（JSON）；`assets/v5/deep/offline-support-objectives.svg`；`assets/v5/deep/sources.json` |
| 12.2 节“三个收紧位置与同一把尺子”；课件 ch12-awr-beta、ch12-dt-luck、ch12-score-table | AWR：$\beta=0$ 回报 $.667$，$\beta=10$ 起点前进概率 $.084$、回报 $.982$；决策 Transformer 在 $x_0$ 的前进概率 $.75$ 与数据内成功比例 $.6$，回报 $.719$；两个世界中较差回报的排序（行为克隆 $.667$ 至支持内贪心 $1$） | 本课的计算：以行为策略的价值作优势，由走廊计数精确计算 | `demos/ch12_open_numbers.py` | 终端输出 |
| 12.3 节开头与图“始终前进的回报与门数”；12.4 节表格；课件 deep-48、ch12-gate-fit、ch12-gate-arrival、model-horizon、ch12-gate-decision、mpc-search、ch12-gate-execution | 校准估计 $\widehat p=.9$；成功出关概率高估 $.246$，四道门回报差 $.986$；门槛 $4^{-1/h}$ 为 $.7071$ 与 $.8409$；四道门全长规划分数 $2.6244$、真实回报 $1.6384$、独立执行均值 $1.6300$（标准误 $.0197$）；八道门 $1.7219$、$.6711$、$.6752$（$.0150$） | 本课的模拟：每道门真实通过率 $.8$，校准记录十次通过九次，最大似然拟合；每种门数模拟 10000 个独立回合，同一门数的各策略共用环境随机数（种子 $12+$门数） | `demos/ch12_gate_planning.py` | 终端输出；`--figure` 重绘 `assets/ch12-gates/gate-horizon.pdf` |
| 12.3 节延伸阅读“最小二乘模型估计”；课件 model-v11-task | 条件均值 RMSE 随数据量的曲线；一次典型运行的估计系数 $(.8506,.5992,.1495)$ | 本课的模拟：线性位置动力学，真实系数 $(.85,.6,.15)$，随机动作，每 20 步在 $[-2,2]$ 内重置位置，240 条真实转移，最小二乘拟合；独立重复 10 次，真值只用于评价与绘图 | `demos/dqn_model_v11.py` | `assets/dqn-model-v11/results.json`（`model`）；`assets/dqn-model-v11/model-fit-curve.csv`；`assets/dqn-model-v11/model-real-transitions.csv`；`assets/dqn-model-v11/model-map.csv`；`assets/dqn-model-v11/model-learning.png` |
| 12.3 节延伸阅读“规划查询与模型外推”；课件 deep-v13-model-selection | 无截距拟合斜率 $.89928$；规划选 $a=1.5$，预测奖励约 $1.349$、真实 $-1.875$；限于已采范围选 $.4$，真实 $.336$；真实最优 $a\approx.577$、奖励约 $.385$ | 本课的计算：真实位移 $a-a^3$，在 $[0,.4]$ 均匀取 21 个动作拟合线性模型，再在 $[0,1.5]$ 中选择动作 | `demos/deep_v13_connections.py` | `assets/deep-v13/checks.json`（`model`）；`assets/deep-v13/planning-distribution.png` |
| 12.3 节“多步模型误差的传播”；12.4 节延伸阅读“有限时域模型预测控制”；课件 model-v11-control | 偏置错写时的位置差 $.450,.833,1.158,1.434$；$H=1,2,4$ 时冻结模型的变化后每步代价 $.4227,.4645,.5734$，已知真实模型 $.1109,.1049,.1049$；第 80 步典型运行（$x=.2115$，计划 $(-1,0,0,0)$，预测第四步 $.2188$、预测总代价 $.284$，实际第四步 $-1.1449$、总代价 $3.600$）；每四步执行整段计划的代价 $1.0823$ | 本课的模拟：位置控制，第 80 步外力偏置由 $.15$ 变为 $-.30$；每次运行从冻结控制器在第 80 步的位置出发，在相同的 80 步扰动下比较各控制器；零尾值，独立重复 10 次 | `demos/mpc_model_check.py` | 终端输出；读入 `assets/dqn-model-v11/mpc-control.csv` |
| 12.4 节延伸阅读“有限时域模型预测控制”表格与图；课件 model-v11-control | 变化后每步代价：冻结模型 $.5734$，每步用最近 40 条转移重新拟合 $.1373$，已知真实系数 $.1049$，不施力 $3.4496$；每 10 步分箱的代价曲线 | 本课的模拟：每个控制器从 $x_0=2$ 起执行 160 步，第 80 步偏置改变且状态与模型不重置；向前看 4 步，枚举 81 条开环候选，噪声标准差 $.03$；独立重复 10 次，同一运行内各控制器共用外部扰动 | `demos/dqn_model_v11.py` | `assets/dqn-model-v11/results.json`（`model.results`）；`assets/dqn-model-v11/mpc-control.csv`；`assets/dqn-model-v11/mpc-control.png` |
| 12.3 节“一步模型要保留什么”；课件 continual-onestep-results | 递归一步模型与直接多步模型在 1 至 16 步的条件均值预测误差及 95% 区间，分正确线性类与漏掉截距两种情形 | 本课的模拟：线性动态 $(.9,0,.2)$ 与漏截距情形 $(.8,.2,.1)$，每份数据 32 或 256 条长 16 的轨迹，起点在 $[-1,1]$ 上均匀；两种模型读同一批轨迹；独立生成 300 份训练数据 | `demos/multiscale_models.py` | `demos/multiscale-results/linear-32.csv`；`demos/multiscale-results/omitted_intercept-32.csv`；`demos/multiscale-results/summary.json`；`demos/multiscale-results/manifest.json` |
| 12.3 节“模型的四种用法与两种不确定”；12.4 节“只为决策服务的模型”；课件 ch12-two-uncertainty、ch12-value-equiv-corridor、ch12-search-improve | 末门集成成员的通过率 $.07$ 至 $.93$；模型甲（通过率 $.9$、末门 $2.497$）与模型乙（$.7^4\times4=.96$）的决策；搜索深度 $d=1,2,4$ 时起点价值传到 $1.638$ 所需轮数 | 本课的计算：均匀先验的 Beta 后验，成员取 7 个等分位；其余由走廊精确求和 | `demos/ch12_open_numbers.py` | 终端输出 |
| 12.3 节延伸阅读“随机转移模型”中的价值等价表；12.4 节延伸阅读“有限时域模型预测控制”开头 | 两步位置控制：开环计划选 $B$（代价 $.25$），反馈计划选 $A$（代价 $.15$）；均值模型的预测；施力系数改为 $.4$ 后的选择 | 本课的计算：两步位置控制，代价与期望按分数精确计算 | `demos/feedback_planning.py` | 终端输出 |
| 12.5 节“校正目标如何改变价值与策略”与图“校正标签、价值更新与已采动作概率”；课件 v17-systems-vtrace-update | 标签 $(1.6,2)$；价值 $(.4,.8)\to(.52,.92)$；行动者权重 $(1.2,1.2)$；已选动作概率 $(.25,.75)\to(.2852,.7611)$ | 本课的计算：两状态单批，$\gamma=.9$，$\bar\rho=\bar c=1$，价值步长 $.1$ | `demos/v17_systems.py` | `assets/v17-systems/checks.json`（`vtrace`）；`assets/v17-systems/vtrace-update.csv`；`assets/v17-systems/vtrace-update.png` |
| 12.6 节开头表格；课件 ch12-systems-gates | 三种调度的实际采样、已读、丢弃、留在队列：先进先出 $120,80,0,40$，优先最新 $120,80,40,0$，调低速率 $80,80,0,0$；先进先出读取时平均版本差 $6.66$ | 本课的模拟：走廊实际转移，3 个采样位置，学习器每周期读 2 条，每周期发布一个新策略版本，共 40 周期，随机种子 12；不训练策略 | `demos/ch12_gate_stream.py` | `assets/ch12-systems/queue.csv` |
| 12.6 节“数据年龄与计算组织”与图“FIFO积压”；延伸阅读“序列回放与大模型训练系统”；课件 ch12-systems-gates | 40 秒后积压 $400$ 条、平均年龄 $13$ 秒；循环状态 $1.312$ 与 $.625$，burn-in $n_{\rm b}$ 步后的差 $.687\times.5^{n_{\rm b}}$ | 本课的计算：确定性 FIFO，每秒入队 30 条、消费 20 条，不丢弃；线性递推 $h\leftarrow ah+o$ | `demos/frontier_v8_system.py` | `demos/frontier-v8-results/queue.csv`；`demos/frontier-v8-results/system.json`；`demos/frontier-v8-results/burnin.csv`；`assets/v8-frontier/queue.png` |
| 12.7 节延伸阅读“团队信用与训练对手分布” | 反事实基线的均值为 $0$；十人各以一半概率按下时全按的概率 $2^{-10}$；石头剪刀布的最优反应循环与均匀策略对各纯策略的收益 $0$ | 本课的计算：有限精确枚举 | `demos/multiagent_selfplay_check.py` | 终端输出（JSON） |
| 12.7 节“什么叫学好，以及四种多人算法”；课件 ch12-what-good、ch12-penalty、ch12-vdn-qmix、ch12-seq-update、ch12-psro | 可被利用度；惩罚博弈中对均匀伙伴出 $a$ 平均 $0$、出 $b$ 平均 $.667$；VDN 拟合与贪心联合动作；同时与依次最优反应的团队奖励；PSRO 各轮种群与元纳什解 | 本课的计算：小型矩阵博弈精确计算 | `demos/ch12_open_numbers.py` | 终端输出 |

运行：

```sh
python3 demos/ch12_fixed_corridor.py
python3 demos/course_v12_visuals.py
python3 demos/ch12_open_numbers.py
python3 demos/offline_support_walkthrough.py
python3 demos/ch12_gate_planning.py
python3 demos/ch12_gate_planning.py --figure gate-horizon.pdf
python3 demos/dqn_model_v11.py
python3 demos/deep_v13_connections.py
python3 demos/mpc_model_check.py
python3 demos/multiscale_models.py
python3 demos/feedback_planning.py
python3 demos/v17_systems.py
python3 demos/ch12_gate_stream.py --csv assets/ch12-systems/queue.csv
python3 demos/frontier_v8_system.py
python3 demos/multiagent_selfplay_check.py
```

外部代码与公开数据（出处）：Dyna 结构图（Silver，RL 课程第 8 讲 PDF 第 26 页，assets/silver/dyna-architecture.png）；IMPALA 行动者–学习者示意（Espeholt 等，2018，图 1，assets/course31-deep/impala-actors.png）；OpenAI Five 数据滞后与复用的加速比曲线（Berner 等，2019，附录 M.2 图 22、M.3 图 24，assets/ch12-systems/five-lag.png、five-reuse.png）及训练图 9（assets/course31-intro/openai-five-fig9.png）；GEAR 服务器数与读取吞吐（Wang、Sit 等，ICML 2023，图 5，assets/ch12-systems/gear-read.png；作者代码 github.com/bigrl-team/gear）；HybridFlow 的作者实现 verl（github.com/volcengine/verl）。

## 参考数据

`assets/`（以及 `demos/NN-results/`）下复制了 42 个数据文件（json、csv 等），即课程目前使用的结果；图片没有复制，运行程序会重新画出。重跑会覆盖这些文件，可以先另存一份再对照。
